# HO 566 — delete-rebuild erosion probe across the roster and roll-call syncs (read-only)

The 563/564 finding generalizes past primaries. The rule HO 564 shipped (a sync must never convert absence of evidence into deletion) is enforced nowhere else, and a grep of the delete-rebuild shape across sync code finds it live on three more cron paths. Erosion of this class ran silent for months in primaries and was surfaced by a probe aimed at something else, so this HO is the deliberate version: measure the other paths before anything else is scoped — it ships no guards and fixes nothing.

The three paths, with what a code read already establishes:

1. `lib/committees-sync.ts:305`. Per-committee wipe-and-rewrite of `committee_members`, gated only on `Array.isArray(members)`. An empty array passes the gate; entries without `bioguide` are skipped after the delete. The wipe is documented as intentional for roster departures (correct goal, unguarded failure mode). Runs every 12h across every committee and has not been audited since the layer shipped at HO 143.
2. `lib/votes-sync.ts:322` and `lib/senate-votes-sync.ts:291`. Per-vote `DELETE FROM member_votes` followed by an insert loop with silent skips: missing `bioguideID` (House), resolver miss on lis/last/state (Senate), `normalizePosition` null (both). The "atomic per-vote" batching protects against a partial batch failure, not against an authoritative-looking empty or thin member list. `member_votes` feeds everything HO 523–557 built: participation, MISSED sort, career rates, party splits, `VoteLine`, the motion lines.
3. `lib/amendment-votes-senate.ts:96`. Full Senate-side wipe of `amendment_votes`, then in-DB recompute. Different risk class; included because the instrument is nearly free. The HO 537 header documents this as a pure recompute (no network, atomic batch), so transient erasure is closed by construction and the exposure is silent vocabulary rot: `SENATE_AMDT_QUESTION_LIKE` failing to match a future question format, thinning new links with no error.

(`lib/meetings-sync.ts:214`, the per-event `meeting_bills` delete, is the same family at smaller radius; it gets one count in M5 and nothing else.)

## §0 — Preconditions

1. HO 565 has landed: `docs/roadmap.md`'s newest block covers HO 563/564 ("Also notes now run through HO 564"). If `git log --oneline -3` still tops out at `95fdd10` (HO 564 C2), land 565 first; this handoff's number assumes it.
2. `git fetch && git status` clean, `main` even with `origin/main`, `npm run typecheck` clean.
3. Read before writing anything: `lib/committees-sync.ts` ~L285–330; the write block AND the selection logic (what decides which votes get fetched each run) in both `lib/votes-sync.ts` and `lib/senate-votes-sync.ts`; `lib/amendment-votes-senate.ts` in full including the header comment; `lib/meetings-sync.ts` around L214; `scripts/diagnostic/zero-candidate-primaries-563.ts` as the genre reference.

## §1 — The question

Does the 564 failure class (deletion backed by nothing, or thinning through silent skips) have live victims outside primaries, and for each path is the exposure STANDING (settled units revisited every run) or WINDOWED (units touched only at first write)? The answer decides whether any guard is owed at all and what it must cover. Nothing gets scoped from analogy; the ported-guard lesson from this arc (oddities: a guard can be correct for the wrong failure) is the reason this probe exists.

## §2 — The script

`scripts/diagnostic/delete-rebuild-erosion-566.ts`, read-only, one sitting. Local DB reads plus at most ONE network fetch (M1b's source file). No Congress.gov, Senate.gov, or Ballotpedia calls; M2's expected counts are already stored on the vote rows.

**M1. Committee rosters.**
(a) Every row in `committees` with its `committee_members` count. List zero-member committees by system code and name. Report the roster-size distribution (min / median / max), split main vs subcommittee if the schema distinguishes.
(b) Fetch the same membership source `committees-sync` ingests (read the fetch in the file for the URL), count members per thomas→systemCode with a minimal local parse, and diff: committees present in source but empty in the DB, and committees where the DB count trails the source count by ≥3. Cap listed offenders at 20 so the output stays hand-readable.
(c) `MAX(updated_at)` per committee against the 12h cadence. A committee whose newest row is days old is not being rewritten (the `unknownCommittees` skip, or dropped from source); list them.

**M2. member_votes deficits.** The expected count is stored on the row: deficit = (yea + nay + present + not_voting) − COUNT(member_votes), per vote.
(a) Votes with a positive tally and ZERO `member_votes` rows, split by chamber (full erasure, or never-walked; M3 says which is possible).
(b) The deficit distribution by chamber: 0 / 1–4 / ≥5.
(c) Deficit ≥5 rows listed (cap 20) with id and question.
(d) Surpluses (negative deficit) reported separately; dupes are a different bug and not this HO's.
From the code read, name which deficit causes are structurally benign (Senate resolver miss, null position, missing bioguideID) so the report sizes them rather than treating every nonzero as damage.

**M3. Revisit semantics (code-read deliverable, file:line citations).** For each of `votes-sync` and `senate-votes-sync`: what selects the votes fetched per run, and can a vote already in the DB have its `member_votes` re-deleted on a later tick? Corroborate from data where cheap (e.g. update stamps on old rolls). Output is one word per path, STANDING or WINDOWED, plus the condition if it's conditional. This classification is what turns M2's numbers into meaning.

**M4. amendment_votes drift.** Recompute the Senate link set fresh through the shared leaf (`SENATE_AMDT_QUESTION_LIKE` + `parseSenateAmendmentNumber`, Senate rows via the `votes.chamber` join per the file's own note) and diff against the materialized Senate rows in `amendment_votes`. Expected diff: zero, both directions; that is 537's pure-recompute contract, and this measurement is the contract's first external check. Report counts against the pinned anchors (97 links, 64 procedural residual) with the caveat that anchors age with the corpus while the diff does not.

**M5. One number on the record.** Rows in the meetings table (whatever `meetings-sync` writes) with zero `meeting_bills` rows, split past/future by meeting date. No interpretation owed; the count belongs on the record (the 564 S3 shape).

## §3 — Report

Paste back: every M's numbers, the capped lists, M3's citations, and a one-line exposure classification per path (STANDING / WINDOWED / INERT) with the reason. Classification is reporting, not fix-scoping. Any guard, fix, or repair gets scoped by Corey from these numbers in its own HO.

## §4 — HALT

Commit the diagnostic alone (`diag:` prefix, explicit pathspec, the script file only), `npm run typecheck`, ancestry eyeball (`git log --oneline @{u}..HEAD` = exactly one commit), push, paste the report. Then stop.

## Hard scope guards

1. Read-only end to end. No writes to any table, no schema or migration, no sync/cron/vercel.json touch.
2. No guard code and no fixes ship in this HO, even where M1/M2 find live damage.
3. Network: the single M1(b) fetch and nothing else.
4. The 552/553 `deferred` instrument, the HO 560 settled freeze, and the HO 561 special pass are adjacent and out of scope; don't touch or re-measure them.
5. Nothing noticed in passing gets fixed (the `getPastPrimaries` rule).
6. The diagnostic commit stays strictly separate from any docs; SKILL.md untouched.
