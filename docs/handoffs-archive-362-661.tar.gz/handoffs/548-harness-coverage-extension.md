# HO 548 — harness coverage extension: cache-hit detector + the post-472 surfaces

Confirm the number before saving: the roadmap's latest pointer reads **"Also notes now run through HO 547"**, so this is 548. Do not take the number from an on-disk filename.

## What this is

Test-only work in two commits. **Findings-only — this handoff ships ZERO fixes**, exactly like HO 472. If the new coverage turns up real bugs, they get reported in chat and filed by the HO 549 sweep; fixes are HO 550+. Resist the urge to fix anything you find, however small: a mixed commit here makes the finding un-auditable.

Two gaps, measured against the repo at `53acc7f`:

**Gap 1 — the crawl never exercises a cache hit.** `smoke.spec.ts` does exactly one `page.goto` per route, and `e2e-prod.yml` triggers on `deployment_status`. Every unattended prod crawl therefore runs inside the post-deploy cache-*miss* window, where an `unstable_cache` function builds its value in-process and works. It cannot see a serialization failure on the hit path. That is the HO 533 mechanism verbatim: `getBillAmendmentVotes` returned a `Map`, round-tripped to `{}` on hits, and 500'd every amendment-bearing `/bill/[id]` for ~59 of every 60 minutes — latent since HO 530, shipped three times, because every verification landed in the miss window. A second sequential hit per route closes it.

**Gap 2 — five arcs of interactive surface have no interaction coverage.** `fit-finish.spec.ts` hasn't been extended since HO 472. Grep against the current spec returns zero hits for `RecordTabs`/`rec-tab` (509/510), `/vote/` (540 — not in the smoke `ROUTES` list either, so the newest route has *no* automated coverage at all), `lob-fbar` (544/547), `lob-exp-desc` (545), `bvote` (542), and `mc-rail`/`mc-crow` (515/517).

## Pre-flight — pick the seeds (report them)

The new tests need real ids. Query the DB, don't guess, and put each one in the ship report so a future reader knows what was exercised:

- `SEED_VOTE` — a roll call that **has member positions** (a `votes` row with `member_votes` children). Prefer a Senate one so the positions list is populated and the party split renders.
- `VOTE_BILL` — a bill carrying **both** own passage votes and amendment votes. HO 542 prod-verified `119-hr-8800` (Votes 2 / Amendments 19); confirm it still holds, or pick another.
- `NOVOTE_BILL` — introduced-never-voted, so no VOTES tab renders. HO 542 used `119-hr-3034`; confirm.
- `TABS_MEMBER` — a member whose hub has at least one **zero-count** tab (to exercise the dim-at-zero policy). The existing `SEED_MEMBER` (`A000055`) may already qualify.
- `FILING_UUID` — an `?expanded=` filing whose panel renders **both** a clamped description with a SHOW MORE button and at least one short unclamped one. HO 545 verified `cd77f510…` (31 activities, 21,633 chars, on volume page 1) — re-derive it rather than trusting the truncated id.

Follow the file's existing convention: module consts with `process.env.SEED_X ?? "default"` overrides.

## Commit 1 — the cache-hit detector (`e2e/smoke.spec.ts`)

Inside the existing `route crawl` loop, after the current assertions, hit the same path a second time and assert it independently.

The load-bearing detail is **attribution**: a hit-2 failure has to be distinguishable from a hit-1 failure, or the signal is lost in the noise. The collectors accumulate across both navigations, so mark the array lengths before the second `goto` and assert on the slices past those marks. Log both hits on one line (`[slug] hit1=200 … hit2=500 …`) — "hit 2 500'd where hit 1 200'd" is the exact HO 533 signature and it should be readable straight off the CI log without opening a trace.

Requirements:

- Second navigation is a fresh `page.goto(route.path)`, not `page.reload()` — reload can be served differently and we want the same request shape the first hit made.
- Document status on hit 2 asserted **hard** (`expect(...).toBe(200)`), like hit 1. This is the assertion the whole commit exists for.
- Console / pageerror / bad-subrequest assertions on the hit-2 slice stay `expect.soft`, matching the file's existing posture.
- Same 2.5s settle between.
- Add `{ slug: "vote", path: `/vote/${SEED_VOTE}` }` to `ROUTES` while you're in the file. It inherits the double-hit and lands the newest route in the daily prod crawl.

Honest caveat to put in the code comment: if a route is served from the full-route cache the second hit may not re-enter the component, in which case it proves nothing rather than proving safety. Every route in this list reads `searchParams` or is otherwise dynamic, so the component does re-run — but the comment should say so, so nobody later reads a green hit-2 as a stronger guarantee than it is.

Cost: doubles the crawl to ~52 prod requests. Still gentle, but note the config's "keep the run gentle" comment is now operating at 2×.

## Commit 2 — interaction coverage (`e2e/fit-finish.spec.ts`)

Six areas. Reuse `attachCollectors` / `logClean` / `assertClean` / `settle` and the `GATE_COOKIE` `beforeEach` — no new helpers unless something genuinely repeats three times.

**A. `RecordTabs` on both consumers** (new `test.describe`, tests against `/bill/${VOTE_BILL}` and `/members/${TABS_MEMBER}`).

Four invariants, three of which exist only because HO 509/510 chose them deliberately:

1. `role="tablist"` renders; `.rec-tab` count > 1.
2. **Mount-all**: click a non-active tab, then assert the `.rec-panel` count in the DOM is unchanged and the inactive ones carry `hidden`. The component comments say panels stay mounted specifically so an open row survives a swap — if that ever silently becomes conditional mounting, nothing today catches it.
3. **Scroll reset**: scroll `.rec-body` down, swap tabs, assert `scrollTop === 0`.
4. **Open-row survival**: expand a row inside a panel, swap away, swap back, assert it's still open. If the chosen panel has no expander, `test.skip` — **but the ship report must name every skip**. HO 503's finding was that a skip-on-empty passes while exercising nothing; a silent skip here would reproduce that failure mode inside the very harness meant to prevent it.

Plus the opposite-empty-state policy those two pages deliberately disagree on: the member hub **dims** at zero (`data-empty="true"` on at least one `.rec-tab`), the bill hub **omits** at zero (no `.rec-tab[data-empty]` should exist at all). Assert both directions.

**B. `/vote/[id]`** (HO 540).

Reach it by **navigation**, not a hardcoded href: `/bill/${VOTE_BILL}` → click the VOTES tab → click the first `.bvote-roll` → assert the URL matches `/vote/`. That exercises the HO 542 link and can't rot the way a pasted id would. Then assert on the landed page: `a[href^='/members/']` count > 0 (positions rendered), an `a[href^='/bill/']` back-link present, console clean.

Add a direct-nav test on `SEED_VOTE` as well — the navigation path and the cold entry point are different things and both ship.

The page is Tailwind-utility with no dedicated class hooks, so select on links and text. Don't add classes to the page to make testing easier; that's an app-code change and this handoff ships none.

**C. The `/bill/[id]` no-double-count invariant** (HO 542).

HO 542 verified by hand that `119-hr-8800` renders 21 unique `/vote/` links (2 own + 19 amendment) with no overlap, since House amendment votes carry `bill_id` and would otherwise appear under both tabs. Pin it in its cleanest form: collect every `a[href^='/vote/']` href page-wide and assert `new Set(hrefs).size === hrefs.length`. Then assert `NOVOTE_BILL` renders no tab labelled VOTES.

**D. `/lobbying` fbar** (HO 544/547) — URL-level, cheap.

`/lobbying` renders `.lob-fbar-controls`; the VOLUME segment rebases to `?sort=volume`; `.lob-fbar-linked` toggles `linked=1`; the two compose. Fill `.lob-fbar-search-input` with a term that matches (`boeing`), submit the form, and assert the URL carries `?q=`, that `.lob-fbar-sort-off` has replaced the segment, and that VOLUME is inert (`[aria-disabled="true"]`) — that's the HO 547 search-forces-RECENT rule, which exists because VOLUME+search measured 7.8s cold against a 10s wall. `.lob-fbar-search-clear` returns to the bare feed. `/lobbying?issue=TAX` renders `.lob-fbar-controls` **zero** times (controls are unscoped-only).

**E. `FilingDescription`** (HO 545) — `/lobbying?expanded=${FILING_UUID}`.

At least one `.lob-exp-desc-more` renders with `aria-expanded="false"`; clicking it flips to `true` and adds `.lob-exp-desc--open`; clicking again restores. If two or more buttons render, toggling one leaves the others' `aria-expanded` at `false` (independent per-activity toggles).

The regression that matters: capture document height before and after opening and assert the growth is **bounded** (< ~600px, i.e. the 420px scroll bound plus chrome). HO 545 shipped precisely because the 24k-char monster would otherwise stretch the HO 492/493-tuned page by thousands of pixels; a numeric bound is the only assertion that would catch that bound being removed.

**F. `/news` rails** (HO 515/517).

Bare `/news` renders `.mc-crow` rows and **zero** `.mc-crow.is-sel`. Click a topic row → URL carries `topic=` and **exactly one** `.mc-crow.is-sel` exists page-wide. Then click a member row → URL carries `member=`, no longer carries `topic=`, and still exactly one `is-sel`. That single-selection-across-both-groups rule is the HO 517 invariant and it spans two rail groups that know nothing about each other, which is exactly the kind of thing that regresses quietly.

## Constraints

- **Test files only**: `e2e/smoke.spec.ts` (commit 1), `e2e/fit-finish.spec.ts` (commit 2). No app code, no CSS, no `lib/queries.ts`, no new classes added to make selection easier.
- **Zero fixes.** Findings go in the ship report, not into a diff.
- Never file anything already in `e2e/console-noise.ts` as a finding — `MissingSecret` and the `FilingRow` dup-key are tracked open loops, and the file says so.
- `fit-finish.spec.ts` is **local-only** (BotID withholds the tape from headless prod, and hover cards need a real interactive browser). Run it as the file header documents: `npm run build && npm start`, then `BASE_URL=http://localhost:3000 npx playwright test e2e/fit-finish.spec.ts`. Commit 1's smoke change runs against prod (the config default).
- Explicit pathspec staging. **Show me the full diff hunks for both commits before committing** — commit 1 changes the gate that `e2e-prod.yml` reds on, so it isn't inert.
- Two commits, separately: `test(smoke): HO 548 — second-hit cache-hit assertion + /vote route` and `test(fit-finish): HO 548 — RecordTabs, /vote, lobbying fbar, description toggle, news rails`.
- Fast-forward only, ancestry eyeballed against current HEAD immediately before push.

## Ship report

- The five seeds picked, with the query that picked each.
- Commit 1: whether any route's **hit 2** diverged from hit 1 anywhere — status, console, or subrequests. A clean sweep is a real result; report it as one. Note the new wall-clock for the crawl.
- Commit 2: per area, pass / fail / **skipped**. Name every skip and why — a silent skip is the HO 503 failure mode.
- Findings list, severity-tagged the way HO 240 defined it (P1 wrong data · P2 inconsistent or misleading · P3 cosmetic), one line each: surface · what · expected vs observed · severity. Nothing fixed.
- Confirm test-only: no app, CSS, or query file in either diff.
