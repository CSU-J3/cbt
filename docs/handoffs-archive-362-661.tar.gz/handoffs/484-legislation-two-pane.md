# HO 484 — Reshape /bills (Legislation) into the /members two-pane browser

Confirm next free number: `ls docs/handoffs/ | sort -V | tail` and the roadmap HO pointer. Body assumes 484 (HEAD is HO 483).

`/bills` today renders the HO 187 five-band chrome (`.control-strip` + `.topics-band` + `.legend-pagination-band`) over a full-width paginated list. Reshape it to the **HO 328 `.mc-*` two-pane browser** that `/members` uses: one filter bar → a left rail (312px) + a right content pane (1fr). **The live `/members` IS the pixel reference — no mocks.** Reuse the `.mc-*` system wholesale.

The one thing bills can't mirror: `/members` drops pagination (536 members fit a 600-row scroll). `/bills` is ~15k — **pagination stays**, in the content pane. Everything else transfers.

## Scope

- **BILLS mode only.** NEWS mode (the `/bills?mode=news` sub-view) is untouched this pass; the LEGISLATION/NEWS toggle still switches to it. Only `BillsView` in `app/bills/page.tsx` is reshaped.
- **Bill rows are out of scope.** `BillRowList` renders unchanged — the standing "rows out of scope" convention (HO 187+). Rows already expand with the rich `BillExpandPanel` (HO 317), so functionally they already match the members click-to-expand. This is chrome + a rail, **not** a row rewrite.
- **Desktop-only**, mobile stack deferred — matches `/members`' own state (the `.mc-pane` grid holds below 700 by design).
- **All `BillsView` param logic stays byte-identical**: sanitization, `getFeedBills`, `carry`/`clearFilters`/`clearSearch` building, the president-alias (`isPresidentAlias`/`direction`/`daysSinceMode`), `cluster`, and the NEWS-mode round-trip persistence. You are moving where controls render, not touching the param logic. The only additions are one rail fetch + one rail-row component.

## The rail spine — topics

Committees are to members as topics are to bills: the many-to-many scoping axis already present as the horizontal chip band. **The rail replaces the chip band.** `getTopicDistribution(feedFilters)` already returns `{ topic, count }[]` sorted count DESC and honors the stage filter — a consumer of an existing pass, **no probe**. Chamber-scope the rail to match the members contract ("the chamber control filters both panes"): when a chamber is active, read `getTopicMixByChamber` and take that chamber's per-topic count (re-sort DESC); otherwise `getTopicDistribution`.

**Multi-select** (unlike the committee rail's single-select): clicking a topic toggles its slug in/out of the comma-joined `?topics=` param, so multi-topic filtering (which the chip band had) is preserved and multiple rows can read `is-sel`. `sanitizeTopics` already parses the comma list.

## The build

### Above the pane — thin nav row
The LEGISLATION/NEWS `toggle` node (top-level view switch — the `/members` GroupTabs slot) + the Changes·President·Reports subnav (`GROUP_TABS.feed`). Keep `GroupTabs group="feed"` for group-nav consistency with NEWS mode.

### Filter bar (`.mc-fbar`)
Consolidate the three bands into one strip (border, `border-bottom: none` so it connects to the pane — the `.mc-fbar` idiom). Left: filtered count readout — `getFeedBills` already returns `total`; render `N BILLS` (`.mc-fbar-n` amber number + muted label, tabular). Then `.mc-fbar-spacer`, then the existing controls inline, all unchanged: chamber `SegmentedToggle` (ALL/HOUSE/SENATE), `StageFilter`, sort (`SortDropdown`), `CeremonialToggle`, `SearchBox` in `.mc-fbar-search`, and the `Clear ✕` link when `hasFilters`. These components all already exist — they move from the control-strip into the filter bar as-is.

### Left rail (`.mc-rail`, 312px) — topics
Border-right, bg-panel. Header (`.mc-rail-h`): `TOPICS · N` left. Optional mirror of the member→committee marking: when a bill is expanded, mark its topics with `●` in the rail and append `· ● on N` to the header (the expanded bill's topics are on the `FeedBill`) — ship only if cheap, else bank it.

Rail rows — a new **`TopicRailRow`** client component, mirror of `CommitteeRailRow`: click toggles the slug in `?topics=`, `router.push(..., { scroll: false })`, `is-sel` when the slug is in the active set. Grid is simpler than committee's 5-col (no chamber tag): `[● mark 16px] [name 1fr] [activity bar] [count]`. Name from `topicFullLabel`/`topicLabel` (`lib/topic-colors`); **activity bar filled with `topicColor(slug)`** (not `--stage-committee` — the topic's own color, matching the row tags and the stage legend), 3px, width = `count / railMax`. Count tabular, right. Selected row: reuse `.mc-crow.is-sel` (2px amber-bright left border + amber-bright name).

CSS: reuse `.mc-crow` / `.mc-crow-*` but add a **4-col topic variant** dropping the 30px chamber-tag column — either a `.mc-crow.is-topic` `grid-template-columns` override or a parallel `.mc-trow` block. Your call; keep it in the `.mc-*` section.

### Right content (`.mc-content`)
Top to bottom:
- **Stage-legend strip** (the bills analog of the members topic-key strip): `<StageLegend bare />` in the `.mc-keystrip` slot, with the top `<Pagination inline …>` right-aligned in the same row (the current legend-pagination-band idiom).
- **Context header** (`.mc-ctx`), only when ≥1 topic is selected: the selected topic tag(s) + `· N bills` + `[spacer]` + `× clear topics` (drops `?topics=`). Reuse `.mc-ctx`/`.mc-ctx-*`.
- **The bill list**: `<BillRowList bills={bills} watchedIds={watchedIds} daysSinceMode={daysSinceMode} />` UNCHANGED, then the bottom `<Pagination>`. Carry the existing empty states (the q-miss "[Clear search]" block and the no-match block) over as-is.

**No columnar `.mc-row-hdr`** — the bill rows aren't a clean grid, so a column header would imply a structure they don't follow. The stage legend + context header are the pane's headers.

### The pane
`.mc-pane` grid `312px 1fr` — topics rail left, the content above right. Same border idiom (filter bar `border-bottom: none` connects to the pane).

## Constraints
- Desktop two-pane only. Mobile stack deferred (matches `/members`).
- **Pagination stays** — the one place bills can't mirror `/members` (15k corpus vs 536 members). Pager top (in the legend strip) + bottom (after the list).
- **Bill rows untouched** (`BillRowList` as-is). **NEWS mode untouched** (the toggle still reaches it).
- Rail counts are chamber-scoped but **non-ceremonial even when CEREMONIAL is on** (`getTopicDistribution`/`getTopicMixByChamber` both hardcode ceremonial-exclusion) — acceptable v1 mismatch (the feed still includes ceremonial); flag in the sweep, don't fix here.
- Reuse the `.mc-*` system + `lib/topic-colors`. No new tokens. Monospace throughout.

## Cuts — print consumers before deleting
- The `.control-strip` / `.topics-band` / `.legend-pagination-band` **JSX** in `BillsView` (superseded by the filter bar + pane). Leave the **CSS rules** unless BillsView is their only consumer — grep first; if anything else uses them, flag for the sweep rather than delete blind.
- The horizontal `TopicFilter` chip band (replaced by the rail). Grep `TopicFilter` consumers first — if anything outside `BillsView` imports it, keep the component and just drop it from BillsView's JSX.

## Ship
- Named `git add` (concurrent sessions hold uncommitted files — explicit pathspec, never `-A`). Likely `app/bills/page.tsx`, `components/TopicRailRow.tsx`, `app/globals.css`.
- `tsc` + build clean; fresh `.next`, stylesheet loads.
- **Show the diff and WAIT for approval before committing. No auto-commit.**
- Check ancestry immediately before push (one commit riding, clean fast-forward, concurrent session files untouched). `git push`; `npm run verify:deploy` until served SHA === HEAD.
- Live-verify: filter bar consolidated (count readout + chamber + stage + sort + ceremonial + search all functional); topics rail renders with topic-colored activity bars + counts; clicking a topic scopes the feed and lights `is-sel`; two topics narrow correctly and both read `is-sel`; context header appears with `× clear topics`; a bill row still expands with the rich panel; pagination works top + bottom; LEGISLATION↔NEWS still switches; URL round-trips `?topics` + all existing params (`stage`/`sort`/`chamber`/`q`/`ceremonial`/`cluster`/`sponsor`).
- Docs owed: SKILL (the `/bills` chrome now shares the `/members` `.mc-*` two-pane vocabulary), roadmap (Also block — `/bills` reshaped to the two-pane browser), backlog (the ceremonial-count rail mismatch, the deferred mobile stack, and the optional expanded-bill→rail `●` marking if banked). Flag for the sweep or fold a note.
