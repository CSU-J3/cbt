# HO 448 — Amendments surface: AMENDMENTS section on `/bill/[id]`

The amendments pillar's first surface. HO 447 landed the corpus + join (6,788 amendments, `amended_bill_id` resolving ~100%); this puts it on the bill hub. **Bill-hub section, not a standalone `/amendments` surface** — amendments join a bill 100%, and the pillar exists for floor-stage visibility on a specific bill, so the per-bill floor fight is where the signal is. The aggregate `/amendments` lens (most-amended bills, top amenders, disposition rates) banks as the follow-on fork.

**Why no cost probe / precompute (the 439→440 split does NOT apply here):** amendments is bills-scale — ~6,800 rows total, smaller than `119-hr-1`'s LDA filing set alone (8,048). The LDA cold trap was random row-fetch on a 108k-row table; a per-bill amendments seek behind `idx_amendments_bill` hydrates instantly even for the worst magnet bill. So this is a **live query — no rollup blob, no new cron step, no new nav item** — unlike every `lda_*` surface.

---

## Step 0 — gate the data before wiring a surface onto it (do this FIRST, report, then build)

The corpus must be provably whole before it backs a surface. Two runs, both before any code:

1. **`npm run sync:amendments -- --repair`** — this is the gate. It fetches the live `pagination.count`, enumerates stored-vs-live, fills any missing by id, and exits `complete = storedAfter >= liveCount` (exit 0 on complete, 1 otherwise). It's a full set-difference, so a clean exit proves whole coverage — stronger than a frontier/timestamp proxy. Expected, if last session already ran it: `repaired=0 complete=true`. **If it exits non-complete (holes it couldn't fill), STOP and report** — floor-reset (truncate + `-- --backfill` from the convening floor `2025-01-03`) is the remedy only if repeated `--repair` can't close the gap. This is a DB completion op, not a code change; nothing to commit.
2. **`npx tsx scripts/diagnostic/amendments-coverage-447.ts`** — read-only readout. Report back: stored rows, type split, `amended_bill_id` resolution %, `sponsor_bioguide_id` present %, and the **magnet fan-out** (top-10 bills by amendment count). The fan-out sizes the render cap below and confirms the live ceiling (even the top magnet is a few hundred rows against 6,800 — live holds). Paste it so it's on record.

Report both, then proceed to the build.

---

## The query — `getBillAmendments(billId)` in `lib/queries.ts`

Live, `unstable_cache`, `tags: ["amendments"]` (the tag the HO 447 cron already revalidates — verify it does; if not, that's a one-line cron fix), `revalidate: 3600`. Mirror `getBillLobbying`'s **try/catch → null** discipline (it runs inside the bill page's `Promise.all`; a throw would 500 the whole page, so degrade to a hidden section instead). Use `getDb()` like `getBillLobbying`. No blob, no fallback tier — the query is the whole thing.

```ts
export interface BillAmendment {
  id: string;
  label: string;                       // "SAMDT 2137" — `${amendment_type} ${amendment_number}`
  amendmentType: string;               // SAMDT | HAMDT | SUAMDT
  sponsorBioguideId: string | null;
  sponsorName: string | null;
  sponsorParty: string | null;         // members.party ("D"|"R"|"I"); cast to PartyKey for partyColor()
  sponsorState: string | null;
  purpose: string | null;
  description: string | null;
  latestActionText: string | null;
  latestActionDate: string | null;
  submittedDate: string;
  amendsLabel: string | null;          // resolved parent label for sub-amendments, e.g. "SAMDT 8"
  disposition: "agreed" | "failed" | "other";  // display-only — see note
}
```

Single indexed seek, LEFT JOIN `members` for sponsor party/state, LEFT self-JOIN for the sub-amendment parent label:

```sql
SELECT a.id, a.amendment_type, a.amendment_number,
       a.sponsor_bioguide_id, a.sponsor_name, a.purpose, a.description,
       a.latest_action_text, a.latest_action_date, a.submitted_date,
       a.amends_amendment_id,
       m.party  AS sponsor_party,
       m.state  AS sponsor_state,
       pa.amendment_type   AS parent_type,
       pa.amendment_number AS parent_number
FROM amendments a
LEFT JOIN members    m  ON m.bioguide_id = a.sponsor_bioguide_id
LEFT JOIN amendments pa ON pa.id = a.amends_amendment_id
WHERE a.amended_bill_id = ?
ORDER BY COALESCE(a.latest_action_date, a.submitted_date) DESC, a.amendment_number DESC
```

`rs.rows.length === 0 → return null` (bill has no amendments → section hides). The `COALESCE(...)` recency puts genuine activity first — acted amendments sort by action date, un-acted by submission date, both ISO text so lexicographic == chronological. ~65% carry no top-level action, so they interleave by filing recency instead of all sinking below the ~35% that have acted.

**Disposition is display-only and is NOT the deferred status model.** HO 447 deferred the persisted status model (agreed / failed / withdrawn / ruled out of order) because the tail cases only appear in the per-amendment `actions` sub-resource, which the sync deliberately does not walk. This is a light keyword scan of the **top-level** `latest_action_text` for the colored dot ONLY — the unambiguous cases, everything else neutral. No new column, no `actions` fetch; the tail falls to `other` (honest, never mislabeled — the "wrong is worse than absent" rule). Small pure helper, failed-family tested first so "not agreed to" can't read as "agreed to":

```ts
function deriveDisposition(text: string | null): "agreed" | "failed" | "other" {
  if (!text) return "other";
  const t = text.toLowerCase();
  if (/\bnot agreed to\b|\brejected\b|\bfailed\b|motion to table.*\bagreed to\b/.test(t)) return "failed";
  if (/\bagreed to\b|\badopted\b|\bpassed\b/.test(t)) return "agreed";
  return "other"; // withdrawn / ruled out of order (top-level text rarely carries these) / submitted / pending
}
```

---

## The component — `components/BillAmendments.tsx`

Server component, mirrors `BillLobbying`'s grammar (same border box, top stat line, row dividers). Fed `rows: BillAmendment[]`; the page omits the section when `getBillAmendments` returns null.

- **Border box:** `className="border"` `style={{ borderColor: "var(--border-strong)" }}`.
- **Stat line** (top, `px-[14px] py-[9px] text-[12px] tabular-nums`, `--text-muted`, `borderBottom: 0.5px solid var(--border-strong)`): `{n} amendments · {agreed} agreed · {failed} failed` — counts derived from the rows; drop a bucket when 0.
- **Rows** — one per amendment, `px-[14px]` padded, `0.5px solid var(--border-soft)` between:
  - **Disposition dot** (leading, ~8px): green = agreed, red = failed, `var(--text-muted)` = other. Reuse the codebase's existing stage/status colors (there's a passed/enacted green and a failed/negative red in the stage palette) — don't invent a new palette; only if no ready pair exists, add a minimal `--disposition-agreed` / `--disposition-failed` in `globals.css`.
  - **Label** (mono, `tabular-nums`): `SAMDT 2137`.
  - **Sponsor:** when `sponsorBioguideId` resolves to a member, render the name party-colored via `partyColor(sponsorParty as PartyKey)` from `lib/race-colors.ts`, linked to the member hub — reuse the existing sponsor-name treatment (`SponsorHoverName`) if its prop shape fits, for the hover card. When there's no bioguide (committee/manager amendments), render `sponsorName` as plain `--text-muted`, no link.
  - **Purpose line:** `purpose ?? description`, `text-[13px]` `--text-secondary`, clamp to 2 lines; when both are null, omit the line (don't render an empty row).
  - **Action line:** `latestActionText` + ` · ` + `latestActionDate`, `text-[11px]` `--text-muted`; when absent → muted `Submitted {submittedDate} · no floor action yet`.
  - **Sub-amendment note:** when `amendsLabel` is present, a small `↳ amends {amendsLabel}` in `--text-muted` (flatten, don't nest — ~2.5% of rows).
- **Render cap:** if the Step 0 fan-out shows a magnet bill large enough to be a DOM problem, cap at the top ~60 by the same recency order with a muted `{overflow} more` line. If the max is comfortably small, render all and skip the cap. No `hearings-embed-foot` out — there's no `/amendments` surface to link yet, so omit the foot rather than ship a dead link (add it when the aggregate surface lands).

---

## The section insert — `app/bill/[id]/page.tsx`

- Add `getBillAmendments(bill.id)` to the existing `Promise.all` (beside `getBillLobbying(bill.id)`, ~line 137); destructure `amendments`.
- Place the section **between Hearings and Lobbying** — legislative order is committee → floor → outside influence → summary, and amendments are the floor stage. Mirror the Lobbying block exactly:

```tsx
{amendments ? (
  <>
    <Divider />
    <div className="mb-2 text-[12px] uppercase tracking-[0.5px]" style={labelStyle}>
      Amendments ({amendments.length})
    </div>
    <BillAmendments rows={amendments} />
  </>
) : null}
```

Header count is `amendments.length` — structurally consistent with the rendered rows (same array), so no masthead-incoherence risk.

---

## Explicitly NOT in 448 (so scope doesn't creep)

- **No standalone `/amendments` surface.** Banks as the follow-on fork (aggregate lens: most-amended bills, top amenders, disposition rates, type split).
- **No persisted status/disposition model.** The display-time dot is not it — the real model (agreed / failed / withdrawn / ruled out of order as a computed, persisted field) needs the per-amendment `actions` walk and stays deferred per HO 447.
- **No rollup blob, no new cron step, no new nav item.** Live query on a bills-scale table.
- **No member-hub amendments surface** (amendments a member sponsored, on `/members/[id]`) — a natural third fork off the member spine; banked.

---

## Git discipline

- Plan → diff → **wait for approval.** No auto-commit.
- **Explicit pathspec.** Surface commit = `lib/queries.ts` + `components/BillAmendments.tsx` + `app/bill/[id]/page.tsx` (+ `app/globals.css` only if a disposition-color pair is genuinely needed). All additive; nothing pre-existing depends on the new query. Step 0's `--repair` is a DB completion op — note its result in your report, but it produces no file diff and rides no commit.
- Eyeball ancestry before any push: one commit riding, clean fast-forward, nothing unrelated staged, the concurrent session's files untouched.
- Prod-verify before we call it done: a magnet bill (top of the Step 0 fan-out) renders the section with dispositions; a low-amendment bill renders a short list; a zero-amendment bill 200s with the section absent.

---

read docs/handoffs/448-bill-amendments-surface.md and follow it
