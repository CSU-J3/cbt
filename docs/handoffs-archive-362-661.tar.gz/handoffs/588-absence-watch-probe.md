# HO 588 — Absence-watch rule probe (STEP 0, read-only)

## 0. Why

A new front-page rule surface: a member who has missed ≥ X votes gets promoted onto `/` (an "ABSENCE WATCH" strip, conditional presence — the strip renders only when the rule fires for someone). Before any build code exists, three things need measurement: the threshold X, the rule *shape*, and the read cost of the one data path that doesn't exist yet.

Three candidate rule shapes. The probe measures all three; the build (a later HO, gated on this one) picks from evidence:

- **R1 — cumulative count.** `SUM(not_voting) >= X` over the 119th. The literal ask.
- **R2 — cumulative rate.** `missed_pct >= X%` over the 119th. What the participation layer already computes (`getParticipationStrip`, queries.ts:4547 — cached, args-free, tag `votes`, revalidate 3600). A dashboard consumer shares the existing cache entry, so R1/R2 cost ~zero marginal reads.
- **R3 — recent window.** Missed ≥ k of the chamber's last N roll calls. The "absent NOW" signal. Does not exist anywhere in the codebase; needs a new query, and its cost must be measured before it's proposed.
- **R4 — last seen.** The date of the member's most recent *cast*, and how many chamber roll calls have run since. Not a threshold on its own — it's the column that tells a reader whether a tripped member is chronic-but-present or currently dark. Also doesn't exist; measured in M5.

The design tension R2-vs-R3, stated so the measurements aim at it: a cumulative rule is **sticky** (a member at 29% trips forever, even after returning to the floor) and **blind** (a member at 4% cumulative who missed the last 25 straight never trips). M2's divergence sets measure whether either failure mode is real in the current corpus or hypothetical.

Facts constraining the design — established conventions, do NOT re-derive or relitigate:

- The **delegate carve-out is mandatory** on any rank/threshold surface (the BANKED constraint, HO 527/535): `chamber='house' AND state IN ('DC','AS','GU','MP','PR','VI')`. Delegates are structurally non-voting; they must never appear in a tripped set. Copy the predicate verbatim from `MISSED_CARVE_EXPR` (queries.ts:5834) / the strip's `isDelegate` CASE (queries.ts:4553).
- **`PARTICIPATION_FLOOR = 50`** (a mid-cycle entrant reads a noisy rate off no signal). Same floor here.
- Zero-roster votes **deflate** the denominator (HO 566/567) — the M2 instrument should read 0; if it doesn't, that's a finding, not noise.
- `sync-votes` runs daily at `0 10 * * *`, so the rule's signal is daily-fresh at best. The panel will need an AS OF stamp; M4 measures what it would say.

## 1. Deliverable

**ONE file:** `scripts/diagnostic/absence-watch-588.ts`. Template: `scripts/diagnostic/motion-outcome-model-554.ts` (env/runner shape). **Read-only, non-SELECT-refusing** (the HO 584 wrapper pattern — the db helper refuses anything that isn't a SELECT/EXPLAIN).

Runs against prod Turso via the usual env. Keep it to bounded aggregate SELECTs — no per-member query loops. The cumulative aggregates scan `member_votes` fully, which is what `getParticipationStrip` already does on every regen, so a one-shot probe is acceptable burn; print each query's returned row count anyway (rows read is the live constraint, HO 582).

## 2. Measurements

### M1 — cumulative distribution + threshold sweep (R1/R2)

Population = `getParticipationStrip`'s exact predicate (`is_current=1`, `HAVING COUNT(*) >= 50`), **delegates excluded** from every tripped set via the territorial predicate (report their 6 rows once, separately, so the exclusion is disclosed — never silently dropped).

Per chamber, print:

1. A coarse histogram of missed counts and missed rates (buckets your call, ~8 bins each).
2. The **threshold sweep table** — tripped-member count at each X:
   - R1 count: X ∈ {25, 50, 75, 100, 150}
   - R2 rate: X ∈ {5, 8, 10, 15, 20, 25}%
3. **Top 12 by rate** (non-delegate): name · party · state · chamber · nv/total · rate. This is the real set the mockup's illustrative rows get replaced with.
4. Floor-excluded current members: count, and names if ≤ 12 (they're invisible to the rule; the build discloses this in the footer).

Target reading: a threshold on some shape yielding a **stable 3–12 member panel**. 0–1 means the rule never fires; 30+ means it isn't an alert, it's `/members?sort=missed` again.

### M2 — recency divergence (R3)

Per chamber: take the **last 30 roll calls** by `vote_date` (rides `idx_votes_chamber_date`), join `member_votes` on those vote ids. Per member compute: missed-in-window count, **consecutive-miss streak** walking from the most recent roll backwards (JS-side over the window slice), and `last_voted` date. A member with NO row on a given roll (mid-window entrant, unsworn) counts as **no data, not a miss** — streaks and window counts only count explicit `not_voting` rows. State this rule in the script's header comment.

Print, per chamber:

1. The window's actual date span (30 House rolls can be 3 days in a vote-a-rama; 30 Senate rolls can be a month — the span decides whether a count-window or a date-window is the right build primitive). Also run the same tally over a **21-day date window** as the secondary cut — one extra query, same join shape.
2. Members with window-missed ≥ {10, 20, 30}; streak ≥ {10, 20, 30}.
3. **The divergence sets — the measurement this HO exists for:**
   - **(a) R3-only:** trips window-missed ≥ 20/30 but sits **under 10% cumulative**. "Vanished recently; R2 is blind to them." List them.
   - **(b) R2-only-stale:** ≥ 15% cumulative but **≤ 2 missed in the window**. "Chronic on paper, present on the floor; an R2 alert on them is sticky." List them.
4. `last_voted` for every member who trips any M1 threshold at the 10% tier — distinguishes "chronic 12% who voted yesterday" from "12% and dark since June."

If both divergence sets are empty or near-empty, R2 alone carries the surface and R3 is dropped from the build spec. If (a) is populated, R3 is load-bearing, not decorative.

### M3 — cost (rows read is the currency)

- **(a) R1/R2 reuse path — a code-read, not a measurement.** Confirm and cite: `getParticipationStrip` is `unstable_cache` with key `["getParticipationStrip"]` and no args (queries.ts:4547–4581), so a dashboard consumer shares the `/members` entry — marginal regen cost ≈ 0 beyond today's. One sentence with the line cite in the output.
- **(b) R3 path — the actual measurement.** The window query is NEW. Run it cold: wall ms, returned row count (≈ 30 rolls × chamber membership; print the real number), and `EXPLAIN QUERY PLAN`. Note: `member_votes` carries only `idx_member_votes_bioguide` — a vote_id-keyed join may scan; **report what the planner does, do not fix it** (an index is a build-HO decision, not this probe's).
- **(c) Cadence math.** If R3 ships as its own cached query (tag `votes`, flushed by the daily sync): regens/day × rows/regen = rows/day. Print the number so the build inherits a priced decision, not a vibe.

### M4 — freshness + integrity instruments

1. `MAX(vote_date)` per chamber and its age vs now — what the AS OF stamp would read today.
2. Zero-roster votes (`tally > 0 AND NOT EXISTS member_votes`) — the HO 566 M2 instrument. Expect 0; a non-zero reading deflates every denominator the rule reads and gets reported, not worked around.
3. `SELECT position, COUNT(*) FROM member_votes GROUP BY position` — the closed-vocabulary check (HO 550 pattern). Confirm `not_voting` is the sole miss token; print the full tally.

### M5 — last seen (R4)

**Definition, fixed here so it isn't re-litigated at build time:** last seen = the `vote_date` of the member's most recent roll call where `position != 'not_voting'`. A **Present vote counts as seen** — the member was on the floor, and this matches the HO 524 cast-code convention that folds Present (7/8) into cast rather than miss. Do not narrow this to yea/nay.

`member_votes` carries no date (`vote_id, bioguide_id, position` — migrate.ts:380), so this needs a join to `votes` for `vote_date` + `chamber`.

**The trap this measurement exists to avoid:** a bare "last seen JUN 12" is meaningless during a recess — every member's calendar-days-dark grows uniformly and the whole chamber lights up. The number that carries signal is **roll calls since last cast**, which is zero for everyone during a recess by construction. So measure **both** and print them side by side; the build picks the denominator from evidence, and the date is likely kept only as human-legible garnish beside the roll count.

Per member in the M1 population (non-delegate, floored), print:

1. `last_seen` date, `days_since` (calendar), and `rolls_since` — the count of that chamber's roll calls after `last_seen` on which the member carries an explicit `not_voting` row.
2. The **no-row rule carries over from M2**: rolls where the member has no row at all are not counted as absent. This also makes a zero-roster vote (HO 566/567) structurally invisible here rather than making the entire chamber read as dark — state that in the script header, and note it as a property, not a workaround.
3. Members with **zero casts ever** (`last_seen` NULL): count, and names if ≤ 12. Most should be floor-excluded already; a non-excluded one is a finding.

Then, per chamber:

4. Distribution of `rolls_since` across the whole floored population (≈8 bins). If the tail past ~5 is empty, nobody is currently dark and the column is chronic-context only.
5. **The decisive cross-tab:** for every member tripping the M1 10% tier, their `rolls_since` and `days_since`. If every tripped member sits at `rolls_since ≤ 2`, the panel is a chronic-absentee list and "last seen" is decorative — say so plainly in the verdict. If some sit deep in the tail, last-seen is the column that separates the two stories and the build carries it.
6. `MAX(vote_date)` per chamber (M4.1) minus each member's `last_seen` — sanity check that a member at the chamber max reads `rolls_since = 0`, not 1. Off-by-one here is the kind of thing that ships wrong and reads plausible.

**Cost:** this is a `MAX`/join over the same `member_votes ⋈ votes` shape M3b prices. Report whether it can ride M3b's single query (one window fetch serving strip, streak, and last-seen) or needs its own statement — a build that issues three separate scans of the same join when one would do is the wrong shape, and this is where that's decided.

## 3. Output + verdict

Paste the **full stdout**, then the verdict:

- **GO** if: some threshold on some shape yields a 3–12 member non-delegate set, M4 instruments read clean, and the chosen path's read cost is bounded (R1/R2 ≈ 0 marginal; R3 priced by M3b/c).
- **Rule-shape recommendation:** which of R1 / R2 / R3 (or R2 badge + R3 flag as a hybrid) the data supports, and the concrete X. This is the probe's product.
- **Last-seen call (M5):** carried as a real column, or dropped as decorative — with the `rolls_since` cross-tab as the evidence, and the calendar-vs-rolls denominator named. If it's carried, say whether it rides M3b's query or needs its own.
- **NO-GO / reshape** if every threshold yields 0–1 or 30+, or if M2 shows the cumulative tripped set is entirely the sticky-chronic bucket — in which case the surface is R3-only and the build spec changes shape before it's written.

## 4. Hard scope guards

1. **Read-only.** No writes anywhere, prod DB included. The db wrapper refuses non-SELECT/EXPLAIN.
2. **One new file only.** No `lib/`, no `app/`, no `components/` touches.
3. **No `queries.ts` changes.** Reuse by copying predicate text verbatim INTO the diagnostic with a line-cite comment — never import-and-modify, never widen an existing query.
4. **No index, no migration, no sync/cron/vercel.json touch.** M3b reports the planner's behavior; it does not remediate it.
5. **No UI.** The mockup exists chat-side; the build is a later HO gated on this verdict.
6. **Commit the diagnostic alone** (`diag(dashboard): HO 588 — absence-watch rule probe`), explicit pathspec, `npm run typecheck`, ancestry eyeball (`git log --oneline @{u}..HEAD` = exactly one commit), push fast-forward. Then **HALT** — paste output and verdict, write no build code.
