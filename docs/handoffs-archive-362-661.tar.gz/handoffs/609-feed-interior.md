# HO 609 — P3 slice 2: the feed interior. The right column's rows, per the mock.

HEAD `5fa764b`. Roadmap pointer: "run through HO 606" (608's sweep is deferred to 610 with the rest of P3's). **Next free is 609.**

Read first: the feed region of `docs/design/dashboard-layout-target.html` (`.mv` rows, `.feed`, `.pfoot`), the C1–C8 SKILL section, and the HO 608 handoff's deferral comment on the feed panel's overflow.

**Scope: the right column's interior only.** All three tabs (MOVERS | STALLS | NEW) render through `BillRowList compact`, so this lands once and applies to all three. Nothing outside `.bills`' contents changes.

## 0. One more mock-over-backlog correction, recorded here so the sweep can carry it

Revision-J decision: "date-grouped TODAY / YESTERDAY / EARLIER THIS WEEK." **The committed mock has no date groups in the feed.** The TODAY/YESTERDAY strings in it belong to the hearings panel's day bar (`.hday`); feed rows carry a per-row relative age (`4h`, `10h`) on line 2 instead. Mock wins (the polarization precedent), 610's sweep notes the supersession. Do not build group headers.

## 1. Commit 1 — the row format

The mock row, translated to the house components (this is the target anatomy, verbatim from the mock's `.mv` block):

- **Line 1:** bill id in accent-amber (`HR 9767` style — the display form, not the slug) + title in `--text-primary`, single line, ellipsized.
- **Line 2:** one block-level line, `--text-dim` at `--fs-10`, `white-space:nowrap; overflow:hidden; text-overflow:ellipsis` — **not a flex row**, which by construction removes the whole line from M1's candidate set: colored **stage** tag (`CMTE` dim / `FLOOR` amber / `ENACTED` green, the existing stage tokens) + relative age, `·`, **sponsor** as plain party-colored text (`STEUBE [R-FL]` — color carries the party, no underline, no border, no PartyTag box), `·`, **topics** as plain dim uppercase text (existing `topicLabel` output, no `TopicChips`, no borders).

What leaves the compact variant, each a C3 finding:

1. `TopicChips` (bordered) → plain text as above.
2. The `PartyTag` boxed element → the plain colored sponsor text.
3. The media-attention column (it has no slot in a 27% column; it stays on `/bills`).
4. **The age-heat coloring** (`BillRow.tsx:19–23` paints ages with `--party-republican`). This is C3 noise *and* a semantic misuse of a party token — a red number in this UI reads Republican, not old. In compact rows, age renders dim, full stop. (If the same heat logic colors the full `/bills` variant, leave that variant alone here and put one line in the HALT report so 610's sweep can file it — the token misuse is worth an oddity regardless.)

What stays: the watch star (functional affordance, HO 127), the expand-on-click behavior (HO 164), the row's hover background.

The expander links restyle to the mock's `.pfoot`: `[ + {n} MORE → ]`, pinned at the panel's bottom, keeping each tab's existing target (`/changes` for movers, and whatever stalls/new currently point at — targets don't change, only the dress).

**Implementation seam:** prefer a compact-only rendering path (the `feed-row--compact` branch already exists) over threading more conditionals through the full row. If the cleanest cut is a small dedicated compact-row component that `BillRowList compact` renders, take it — but the full `/bills` row must be untouched either way, and §3 proves it.

`feat(feed): HO 609 — compact rows to the mock's two-line quiet format (C3: chips, PartyTag, media column, age-heat out)`

## 2. Commit 2 — the feed scroll, with its falsification leg

Adopt the mock's mechanics: `.feed { overflow-y:auto; min-height:0 }` inside the sticky column's flex stack (`.bills` is already `flex-direction:column` from 608), `.pfoot` below it so the footer stays pinned while rows scroll.

**The deferred hover-card question gets falsified, not assumed.** HO 300 made the feed panel `overflow-visible` so the sponsor card could escape; internal scroll re-introduces a clipping ancestor. In order:

1. **Reproduce first.** With scroll live, invoke the expanded row / sponsor card from the **last visible row** of a scrolled feed. Screenshot the clip (or the absence of one — the expanded panel may be purely in-flow, in which case it grows the scroll content and nothing clips; that outcome is a PASS and step 2 is skipped).
2. If it clips: re-anchor the card to the viewport — `position:fixed` with coordinates from the trigger's `getBoundingClientRect()`, so no ancestor overflow can cut it. Close/reposition on feed scroll (a scroll listener that dismisses is acceptable and simpler than tracking).
3. **Prove the fix with the same reproduction**, same row, same scroll position, screenshot.

Acceptance: the card is fully visible when invoked from the last visible row of a scrolled feed, at 1440 and 2560. State which of the two outcomes (never-clipped vs. fixed-position) shipped.

`feat(feed): HO 609 — internal feed scroll + pinned pfoot; hover card re-anchored to the viewport` (adjust the second clause to the outcome)

## 3. Scoring and verification

1. `npm run typecheck`, `npm run build` per commit; explicit pathspecs; ancestry eyeball reads exactly two.
2. `--route home` at 2560, before commit 1 and after commit 2. Expected direction: **M3 6.06 → ≤4** (the row keeps id-amber, title-bright, stage-colored, sponsor-party — four own-styled descendants is the design, so ~1–2 is not the target and hitting it would mean something got deleted); **M1 candidate rows down** (line 2 stops being a flex row); **M4 roughly flat** (nothing empty changes here). A big M4 move either way means the scroll change altered panel heights unexpectedly — look before shipping.
3. `--route bills` at 2560, before and after: **every number flat.** This is the proof the full variant didn't drift. Any delta on `/bills` is a stop-and-look, not a note.
4. Eyeball `/` at 1440 and 2560: two-line rows, ellipsis behaving on both lines, pfoot pinned, scroll contained to the feed, star and expand still working, and the falsification screenshots from §2.
5. Push, prod-verify (`/api/version` to the SHA, `/` until converged and holding), then **HALT**. Paste both score tables and the §2 outcome. No hearings work, no packing, no sweep — all 610.

## 4. Guards

1. `/bills` and every non-dashboard surface untouched; §3.3 is the instrument for it.
2. No date groups (§0). No absence work. No hearings interior.
3. `--fs` tokens for any new size in the 9–14px range; the mock's `.833em`-style values map to the nearest token, not to new literals.
4. Two commits, code only, sweep deferred.
