# HO 455 — Nominations data layer: table + persisted disposition + list-driven sync

The nominations pillar's data layer, on the HO 454 GO (1,884 PNs, 833 civilian with 100% disposition coverage, clean 24-value organization facet, viable status model). Mirrors the amendments HO 447 data layer, with two deliberate divergences the probe earned: **list-only** (no detail fetch — the core surface's fields are all list-level) and a **persisted disposition column** (100% coverage + clean vocab, the differentiator vs the amendments status-model NO-GO).

**What the probe fixed that a naive build gets wrong:**
- **`partNumber` composite key.** Citations are `PN{number}-{partNumber}` (e.g. `PN246-17`); the base-part detail endpoint returns a *different* record. The logical key is **`(pn_number, part_number)`**, not `pn_number` alone. The list is part-specific and carries the core fields, so a list-driven sync keys cleanly on the composite.
- **list-vs-detail `updateDate` divergence.** List `updateDate` is a bulk-refresh timestamp (clusters many rows at one time), detail is the real per-record date — the same frontier hazard as amendments (HO 447). Resume on the **list** `updateDate`, inclusive boundary, expect the `--repair` need.

**Scope: list-only.** Committee referral + military nominee-count are detail-only and are **deferred** (the columns exist, nullable, populated by a later detail-hydration HO that also resolves the part-specific-detail fetch and the civilian committee-referral re-measure the probe flagged). v1 stores every list-level field + the computed disposition. Military list PNs are stored as **single collapsed rows** (never explode the ~25k officer nominees); the surface (a later HO) filters to civilian.

---

## 1. Schema — `nominations` table (add to `scripts/migrate.ts`)

House-style, additive, loose links (no enforced FKs — the amendments `cecff19` lesson). `id` mirrors the billId/amendmentId convention, encoding the composite key:

```sql
CREATE TABLE nominations (
  id TEXT PRIMARY KEY,                    -- 119-pn246-17  ({congress}-pn{pn_number}-{part_number})
  congress INTEGER NOT NULL,
  pn_number INTEGER NOT NULL,             -- 246   (composite key part 1)
  part_number TEXT NOT NULL,              -- "17"  (composite key part 2; "00" for base/single-part)
  citation TEXT NOT NULL,                 -- "PN246-17"
  is_military INTEGER NOT NULL,           -- list-level nominationType.isMilitary (authoritative civ/mil flag)
  organization TEXT,                      -- destination agency/dept (the facet; 24 distinct)
  description TEXT,                        -- list-level; carries the CIVILIAN nominee name + position
  disposition TEXT NOT NULL,              -- PERSISTED, computed at sync from latest_action_text (see §2)
  latest_action_text TEXT,                -- 100% present (the amendments contrast)
  latest_action_date TEXT,
  received_date TEXT,
  committee_system_code TEXT,             -- DEFERRED (detail-only): nullable loose link to committees.system_code
  nominee_count INTEGER,                  -- DEFERRED (detail-only): military officer count; NULL in v1
  update_date TEXT NOT NULL,              -- frontier key (LIST updateDate — resume on this, per HO 447)
  raw_json TEXT,                          -- list payload for reprocessing
  ingested_at TEXT
);
CREATE UNIQUE INDEX idx_nominations_pn   ON nominations(congress, pn_number, part_number);
CREATE INDEX idx_nominations_org         ON nominations(organization);
CREATE INDEX idx_nominations_disposition ON nominations(disposition);
CREATE INDEX idx_nominations_military    ON nominations(is_military);
CREATE INDEX idx_nominations_update      ON nominations(update_date DESC);
CREATE INDEX idx_nominations_committee   ON nominations(committee_system_code);
```

`committee_system_code` and `nominee_count` are in the schema now (forward-compatible, so the deferred detail-hydration HO needs no migration) but left NULL by the v1 list-only sync.

---

## 2. Disposition model — `computeNominationDisposition(latestActionText)` (the differentiator)

Deterministic, persisted at sync. The probe's clean 100%-coverage vocabulary maps to a status enum along the confirmation pipeline (Received → Referred → Hearings → Reported → Calendar → Confirmed / Returned / Withdrawn). Put it in `lib/nominations-sync.ts` (or a small `lib/nomination-disposition.ts` if you prefer it testable in isolation):

```ts
export type NominationDisposition =
  | "confirmed" | "returned" | "withdrawn"   // terminal
  | "calendar" | "reported" | "hearings" | "referred" | "received";  // in-pipeline

function computeNominationDisposition(text: string | null): NominationDisposition {
  if (!text) return "received";
  const t = text.toLowerCase();
  // terminal first
  if (/\bconfirmed\b/.test(t)) return "confirmed";
  if (/returned to the president/.test(t)) return "returned";
  if (/\bwithdrawn\b/.test(t)) return "withdrawn";
  // in-pipeline, latest-stage-wins order
  if (/executive calendar/.test(t)) return "calendar";
  if (/ordered.*reported|reported by/.test(t)) return "reported";
  if (/hearings held/.test(t)) return "hearings";
  if (/referred to the committee/.test(t)) return "referred";
  return "received";  // "received in the senate and referred" lead / anything unmatched
}
```

**Report the residual at sync:** count any `latest_action_text` that falls through to the `received` default *without* matching a "received/referred" lead, and log a sample — the probe showed a clean vocab, but the corpus is 1,884 rows and the map should be tuned if the coverage diagnostic (§4) surfaces unmatched terminal phrasing. Unlike amendments, this is a *persisted* column, so the residual matters.

---

## 3. Sync — `lib/nominations-sync.ts` + `scripts/sync-nominations.ts`

Mirror `lib/amendments-sync.ts` structure (inline `fetchJson` 429-backoff + abort, `dbRetry`, resumable frontier, deadline-gated), but **list-only** — no per-PN detail fetch:

- **Endpoint:** `GET {API_BASE}/nomination/{congress}?fromDateTime={frontier}&sort=updateDate+asc&limit=250` (probe-confirmed the params are honored).
- **Per list item:** derive `(pn_number, part_number)` from `number` + `partNumber`, build `id`, read `is_military` from `nominationType`, `organization`, `description`, `latestAction`, `receivedDate`, `updateDate`; compute `disposition`; upsert on `id`. Store the list item as `raw_json`. `committee_system_code`/`nominee_count` left NULL.
- **Military collapse:** a military list PN is one row (the `nominees` array is never fetched/exploded). `is_military = 1`, `nominee_count = NULL` (deferred).
- **Frontier:** resume from `MAX(update_date)` ascending, inclusive boundary (the list `updateDate` clusters on bulk refreshes — same as amendments; the inclusive re-fetch + upsert is idempotent).
- **Modes** (mirror amendments): incremental (cron), `-- --backfill` (full 119th, ~1,884 list-page-driven upserts — far cheaper than amendments since there's no detail fetch; minutes), `-- --repair` (the completion gate: enumerate live `pagination.count` vs stored, fetch any missing by `(number, partNumber)`, loop until `stored >= live` — the ascending frontier can't refill an interior gap the bulk-refresh clustering opens).
- **No `CONGRESS_API_KEY` → throw**; `getCurrentCongress()` for the congress.

Run the backfill + `--repair` after the commit; report `complete` at stored == live.

---

## 4. Cron + coverage diagnostic

- **Cron route** `/api/cron/nominations` — deadline-gated, mirror `/api/cron/amendments`; add to `vercel.json` (a sub-daily/6h cadence is fine — nominations move slower than bills; match the amendments cadence unless the cron budget says otherwise). `revalidateTag("nominations")` for when a surface lands.
- **Coverage diagnostic** `scripts/diagnostic/nominations-coverage-455.ts` (folded into this HO, mirror `amendments-coverage-447.ts`): report stored count vs live `pagination.count`, the civ/mil split (confirm ~833/1,051), the **disposition distribution** (the persisted enum across the corpus — this is the headline stat and the residual check), organization cardinality + top-12, and the `committee_system_code`/`nominee_count` NULL rate (100% NULL in v1, confirming the deferral is clean).

---

## Explicitly NOT in 455 (scope guard)

- **No detail fetch, no committee referral, no military nominee-count** — deferred to a later detail-hydration HO (which resolves the part-specific-detail fetch + the civilian committee-referral re-measure the probe flagged). The columns exist nullable so that HO needs no migration.
- **No surface, no nav item, no query helper** — data layer only. The standalone `/nominations` surface (by agency, by disposition) is the next HO.
- **No member-spine join** — nominees carry no bioguide (probe-confirmed); nominations are standalone.
- **No `recordedVotes`** — nominations don't carry structured `recordedVotes` (probe: 0/80; the roll-call is in `latest_action_text`, a text-parse deferred with the vote-linkage idea if ever wanted).

---

## Git discipline

- Plan → diff → **wait for approval.** No auto-commit.
- **Explicit pathspec**, mirror the amendments arc's two-commit shape:
  - Commit 1 (data layer): `scripts/migrate.ts` + `lib/nominations-sync.ts` + `scripts/sync-nominations.ts` + `app/api/cron/nominations/route.ts` + `vercel.json` + `package.json`. Message: `feat(nominations): data layer — table + disposition + sync + cron (HO 455)`.
  - Commit 2 (diagnostic): `scripts/diagnostic/nominations-coverage-455.ts`. Message: `feat(nominations): coverage diagnostic (HO 455)`.
- The backfill + `--repair` are DB operations (no file diff, no commit) — report the `complete` result and the coverage-diagnostic output in chat.
- Eyeball ancestry before each push: commits riding, clean fast-forward, nothing behind, nothing unrelated staged, the concurrent session's files (`RaceCard.tsx` / `CompetitiveRacesBlock.tsx` / `CompetitiveRacesStrip.tsx` / `globals.css`) untouched and history preserved. Report the remote SHA after each.

---

read docs/handoffs/455-nominations-data-layer.md and follow it
