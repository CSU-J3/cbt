# HO 563 — the 143 zero-candidate past primaries (read-only probe)

HO 559 M2 split the primaries gap into two different bugs and this HO takes the larger one: **143 past-dated contests whose roster was never populated**, 177 of the 181 gap being House. It also sizes the queued House clobber guard, because reading the House sync suggests the two are the same mechanism seen from opposite ends.

Builds nothing. The fix depends entirely on which of three causes M2 returns.

## §0 — Preconditions

1. `git fetch && git status` clean, `main` even with `origin/main`, `git rev-parse HEAD` = `12dc786`.
2. `npm run typecheck` clean.
3. Read: `syncHouseDistricts` in `lib/primaries-sync.ts`, specifically the status fork around L700–775 and the write block that follows it; `scrapeHouseCandidates` in `lib/primary-candidates-scrape.ts` including its disk-cache branch and `isSpecialElectionPage`; `scripts/diagnostic/primaries-voted-classification-559.ts` for the M2 query that produced the 143.

## §1 — The mechanism to test, stated so the probe measures rather than rediscovers

`syncHouseDistricts` forks on scrape status. `special` and `no_page` both `continue` before any write, so neither can create a row or touch an existing roster. `ok` proceeds normally. But **`no_section` and `no_candidates` fall through into the write block**, with a comment saying the row is created deliberately — so a district whose page is reachable but yields no parsable roster gets a `primaries` row created carrying zero candidates.

That is a plausible manufacturer of all 143, and it has a second edge worth more than the first: the write block's **delete-then-insert runs on that same fall-through**. A district that already had a roster, and results, and whose page later stops parsing, gets its roster **deleted and replaced with nothing**. Ballotpedia restructuring a district page after its primary (toward a general-election layout, moving or renaming the `Candidates_and_election_results` anchor) is exactly the trigger.

So the House hazard is erasure where the Senate hazard was substitution, and HO 560's guard would not have caught it: a freeze predicate keyed on "already carries a share" protects resulted rows, but a wiped row has no share left to protect once it happens, and an unresulted row is deliberately left open.

**Do not treat any of that as established.** It is a reading of the control flow, and HO 559 exists because two such readings in a backlog entry were both wrong. M2 is the arbiter.

## §2 — Measurements

Write `scripts/diagnostic/zero-candidate-primaries-563.ts`, **read-only** (no INSERT/UPDATE/DELETE, no schema, no cron, no cache writes). Ballotpedia pacing is **1100ms between fetches**, matching `reingest-primary-slate.ts`.

**M1 — characterize the 143 from the DB alone, no network.** Rows where `election_round='primary'`, `primary_date < date('now')`, and zero `primary_candidates`. Report: total, split senate/house; grouped by state; grouped by `primary_date`; how many districts have **both** their D and R rows empty versus one only; and for each affected state-date, whether **sibling districts in the same state on the same date do have rosters** (whole-state failure versus scattered districts). Also the distribution of `primaries.updated_at` minus `primary_date`, which says how recently the sync last touched these rows.

**M2 — what the scraper returns for them today. This is the deciding measurement.** For every distinct district among the 143 (expect roughly 70, since D and R are two rows per district), call `scrapeHouseCandidates` and bucket the result: `ok` with a candidate count, `no_section`, `no_candidates`, `no_page`, `special`. Print the per-district line, then the bucket totals. Run with `bypassCache: true` so the reading is live.

**M3 — size the erasure hazard.** Among House contests that **currently carry at least one `vote_pct`**, sample across states and dates (cap the sample at 40 districts, stratified so no single state dominates) and report how many now return `no_section` / `no_candidates` / `special` from a live scrape. Every `no_section` / `no_candidates` hit is a roster one cursor visit away from being deleted by the fall-through. Report the count, the states, and whether any of them carry results from a contest that has already been decided.

**M4 — cache participation.** Confirm whether `readCachedHtml` can return anything in the deployed environment (does a `.cache/` directory exist there at all), and on a 5-district sample compare `bypassCache: true` against the default path, reporting any status divergence. The point is to know whether M2's numbers are a property of Ballotpedia or of a local artifact.

**M5 — visit recency versus the cursor.** Print the current cursor value and its unit, and for the M1 districts report how long ago the sync last wrote their `primaries` row. This separates "these are stale and the next visit fixes them" from "these were visited recently and came back empty anyway."

## §3 — HALT, and the fork M2 decides

Commit the diagnostic, report all five blocks, **stop.** No fix in this HO. The three causes take three different fixes and they are not compatible:

- **M2 mostly `ok` with a real roster** → the rows are stale, a normal visit repairs them, and the answer is scheduling, not code. Check against M5 before believing it.
- **M2 mostly `no_section` / `no_candidates`** → the fall-through is manufacturing empties, and the fix is that a non-parsing page must not create a row nor delete an existing roster. That is a behavior change to `syncHouseDistricts` with real blast radius, and it needs its own HO.
- **M2 mostly `no_page` or `special`** → the premise in §1 is wrong, because neither status reaches the write block. Something else made these rows and the probe has to say so plainly rather than reaching for the nearest available explanation.

**M3 sets the House guard's shape independently.** If it returns non-zero, the queued House clobber guard is not the HO 560 predicate ported across, because the failure is erasure rather than substitution, and the guard has to refuse the delete on a non-parsing scrape rather than refuse the rewrite on a settled row.

## §4 — Scope guards

1. **Read-only.** No writes of any kind, including no "obviously correct" repopulation of a district while its page is open in front of you.
2. **No edits to `lib/primaries-sync.ts` or `lib/primary-candidates-scrape.ts`**, including no new export to make the probe tidier. If a helper is unreachable, reimplement the read in the probe and say so.
3. **1100ms between every fetch**, no concurrency. M2 plus M3 is roughly 110 fetches, about two minutes; that is fine and worth doing serially.
4. **No writes to `.cache/`.** M4 reads whether the cache participates; it does not populate it.
5. No cron, `vercel.json`, slice-constant, or seed changes. This HO does not touch the HO 560 or 561 machinery.
6. Do not extend the HO 560 guard to House "while you are in there."

## §5 — Commit + gates

1. `git add scripts/diagnostic/zero-candidate-primaries-563.ts`
2. `diag: HO 563 — zero-candidate past primaries + House erasure-hazard sizing (read-only)`
3. `npm run typecheck` clean, ancestry eyeball (exactly one commit, clean fast-forward), push to `main`.
4. Report the five blocks and halt. No docs commit; the sweep follows the fix.

**Gates:** diff = 1 file, 1 commit · grep the script for `INSERT|UPDATE|DELETE|CREATE|ALTER|writeFile` before pushing and paste the result · no diff under `lib/`, `data/`, `components/`, `app/`, or `vercel.json`.
