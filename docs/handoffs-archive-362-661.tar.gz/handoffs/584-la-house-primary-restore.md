# HO 584 — LA House 2026: the real date, and the senate-proxy convention breaking a second time

## 0. Why this isn't the small data fix the backlog describes

The backlog states the precondition as: remove `LA` from `HOUSE_PRIMARY_SUSPENDED` in the same change that writes a real date, because the set force-NULLs on every tick and is a lock, not a one-time repair. That's correct and necessary. **It is not sufficient, and doing only that re-introduces the HO 577 clobber through the front door.**

Read the two branches at `lib/primaries-sync.ts:1100-1102`. The non-suspended branch is:

```
primary_date = COALESCE(excluded.primary_date, primaries.primary_date),
runoff_date  = excluded.runoff_date,
primary_type = excluded.primary_type
```

`excluded.*` is fed from `calByState` (`:936-950`), which HO 577 narrowed to the clean statewide senate row. **LA has one** — `senate-LA-2026-*`, 2026-05-16, unaffected by the EO and explicitly preserved as a valid source. So the moment the lock comes off, the next primaries tick writes **2026-05-16** into all six LA House rows. And `calByState` carries `primaryType` as well as dates, so the same tick writes LA's *Senate* primary type (the Act 1/640 closed party primary) onto House rows that no longer run party primaries at all. Wrong date and wrong type, from the mechanism HO 577 shipped as the fix.

The underlying convention is the thing that broke. The senate-row-as-proxy design works because a state's regular Senate and House primaries share a date and a system. Louisiana is now the case where that coincidence fails on both axes at once: House is an all-party primary on **2026-11-03**, Senate was a closed party primary on **2026-05-16**. This is the HO 576 rule turning up a second time — there it was "a Senate special is a Senate-only contest, so it is never a valid proxy for a House member's primary"; here it's the same shape with a statute instead of a special. Derive the fix from the convention, not from Louisiana.

## 1. The external facts, with their sourcing and their expiry

Nothing in the repo can rederive these. Verified by search on 2026-07-31.

- **Act 7 of the 2026 Regular Session** replaced the suspended closed partisan House primary. The Louisiana Secretary of State states it directly: U.S. Representatives run in an **open primary election on November 3, 2026** and, if necessary, an **open general election on December 12, 2026**. The SoS page cites Act 7 by name.
- Mechanically it is the historic jungle system restored for U.S. House only: all candidates on one ballot regardless of party, majority wins outright, otherwise the top two advance. HB 842 as amended in conference is the vehicle reported contemporaneously; Act 7 is the enacted citation to use.
- The Senate is untouched — May 16 primary, June 27 runoff, both already run. `senate-LA-2026-*` stays correct and stays a valid `calByState` source for anything that isn't the House.
- The new map (six districts, passed late May, signed by Landry) is enacted. District count is unchanged at 6.
- **Expiry:** litigation was pending over the suspension (the NCJW suit had its TRO denied) and more was expected over the new map. Act 7 and the SoS calendar are the current state as of 2026-07-31. Record that date in the code comment so the next reader knows how old the claim is, and re-check before treating a future discrepancy as a bug.

**The terminology trap, and it is a real one.** Louisiana's own statutory name for its jungle system is the "open primary," and it calls the December contest the "open general," not a runoff. CBT's `primary_type` vocabulary is `open | closed | jungle`, where `open` means party primaries any voter may vote in — which is what SC has, and HO 577 already established that SC's `open` is correct and must not be "repaired." **Writing `open` for LA would make two structurally different systems indistinguishable in the column.** LA gets `jungle`. Put the collision in the comment: a future reader who checks the SoS site will read the word "open" and must not correct the row.

The same mismatch applies to the December date. LA calls it a general; CBT's `runoff_date` means "the contest that resolves this primary when nobody clears a majority," which is exactly what December 12 is. Model it as `runoff_date` and say why in the comment.

## 2. The row shape is already right, for a reason that didn't exist when it was written

`NONPARTISAN_HOUSE_STATES` (`:145`) already contains `LA`, so the sync writes one `house-LA-{DD}-2026-open` row per district — six rows, no party split. That is correct under Act 7.

It got there by a different route. The HO 93.5 comment (`:137-143`) records that the handoff expected closed partisan D/R and that every LA House page on Ballotpedia rendered a single nonpartisan votebox, so the code stored what the source showed. Meanwhile the *handoff's* premise (LA is closed-partisan for 2026, per Act 1/640 of 2024) was correct when written and was undone by Callais and Act 7 — which is why oddities has it filed as a correct-claim-with-an-expiry.

So the set membership is right now and the handoff premise behind it is dead. **Don't re-derive the membership; re-comment it.** Replace the "we store what the source shows / if LA's pages switch to D/R voteboxes, drop LA from this set" note with the statutory basis, and invert the tripwire: under Act 7 there should be no D/R voteboxes for LA House, so the existing structural guard firing (`D/R candidate(s) on a nonpartisan-state page`) now means Act 7 was superseded, not that Ballotpedia drifted.

## STEP 0 — `scripts/diagnostic/la-house-restore-584.ts` (read-only)

Writes nothing. Commit alone, run, report, **HALT.**

**M1 — the six rows as they stand.** `id, district, election_round, primary_date, runoff_date, primary_type, updated_at` for `house-LA-%`, plus candidate counts and any recorded shares per row. Confirm six, confirm `-open`, confirm dates are NULL (the HO 577 repair), and confirm none carries a share. A row carrying a share changes the plan — it would mean something recorded a result for a contest that hasn't happened.

**M2 — what the unlock would actually write.** Read `calByState` for LA exactly as `syncHouseDistricts` builds it and print `primaryDate`, `runoffDate`, `primaryType`. This is the measurement that either confirms or falsifies §0. Expected 2026-05-16 / 2026-06-27 / the Senate's type. **If it comes back anything else, stop and report** — the §0 argument is then wrong and the design below needs rework rather than adaptation.

**M3 — the November-date blast radius.** A `primary_date` in November is unprecedented in this corpus; every other contest is spring or summer. Enumerate the consumers of `primary_date` / `runoff_date` and state, per consumer, what a 2026-11-03 LA row does: `PrimaryTimeline` (`c.date <= todayISO`), the past-by-date and voted-by-results counts, `getPrimaryForRace`'s soonest-future-contest ordering (HO 576) for LA House members, the settled guard (past-dated AND carrying a share), and the special-primary ±7-day trigger (HO 561). Flag anything that assumes a primary precedes the November general or that a runoff precedes its primary's general. **Report, don't fix** — an ordering assumption that breaks is a finding for this HO's build, a rendering preference is not.

**M4 — roster expectation.** Candidate qualifying for a November 3 primary has not happened. Scrape one LA House district live and report the status (`ok` / `no_section` / `no_candidates`). An empty roster here is *honest*, not the HO 563 erasure class, and the HO 564 guard means an empty parse no longer deletes. Confirm that rather than assume it.

## Build (after HALT clears)

**C1 — replace the lock with an override, one mechanism instead of two.** `HOUSE_PRIMARY_SUSPENDED: Set<string>` becomes a per-state override map keyed by state, carrying `{ primaryDate, runoffDate, primaryType }`. LA maps to `{ "2026-11-03", "2026-12-12", "jungle" }`. Suspension is then expressible as an override with NULL dates, so the two special branches at `:1100-1102` collapse to one: **an override, when present, wins over `calByState` for that state's House rows; everything else is unchanged, COALESCE and all.** That is the convention stated as code — a per-state House authority that overrides the senate proxy where the proxy's precondition fails.

Comment it with the derivation, not the instance: the senate row is a proxy for the House date only while both chambers share a date and a system, and any state where that stops being true needs an entry here rather than a new branch.

**C2 — the comments that are now wrong.** The `HOUSE_PRIMARY_SUSPENDED` block (`:147-156`) describes the EO, the July 15 expiry, and defers the real shape to "the follow-up HO" — this is that HO, so it gets rewritten around Act 7 with the 2026-07-31 verification date. The `NONPARTISAN_HOUSE_STATES` LA note (`:137-143`) gets the statutory basis and the inverted tripwire per §2.

**C3 — is a repair needed?** Only if M1 shows rows that the next tick won't correct. If the six rows are NULL-dated and shareless, C1 alone fixes them on the next run and no `--apply` script is warranted. **Do not write a repair script to do what the sync will do**; state that in the ship report as a decision.

## Falsification (before any doc records the override as working)

The override is untriggered the moment it lands, and an untriggered override reads identically to a broken one — the HO 577 settled-guard lesson. Drive the **real** `syncHouseDistricts` against LA and prove three things: the six rows land 2026-11-03 / 2026-12-12 / `jungle`; a control state (any partisan state with a clean senate row) is byte-identical to before; and a scratch run with LA removed from the override map writes 2026-05-16, demonstrating that §0's clobber is real and that the override is what prevents it. Scratch reverted, `git status` clean, nothing committed from it.

## Scope guards

- STEP 0 writes nothing. Diagnostic commit strictly separate from build commits.
- **The new map's boundaries are out of scope.** District geometry (HO 223/224), rosters, and any 2024-margin recompute against redrawn lines are a separate item. This HO touches dates, type, and the override mechanism only.
- No change to `senate-LA-2026-*`, to the Senate path, or to `calByState`'s HO 577 shape (`district IS NULL`, clean statewide row only).
- No change to the HO 577 settled guard, the HO 564 delete-refusal guard, or the HO 560 freeze.
- The 15 gap-states WATCH is untouched — LA is not one of them.
- No migration, no schema change, no cron cadence change.
- Explicit pathspec staging; `npm run typecheck` before pushing; ancestry eyeball; fast-forward only on main. Code and docs never mixed.
- `docs/roadmap.md` is authoritative for the HO number; if it disagrees with this filename, the roadmap wins.
