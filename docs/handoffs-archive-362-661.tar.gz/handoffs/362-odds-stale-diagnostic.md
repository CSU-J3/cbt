# HO 362 — Odds tape reads STALE: diagnose, then fix or report

## Symptom
The dashboard header runs two tapes. The markets tape is fine ("AS OF 3:28 PM CT · CLOSED" is correct after the equity close). The odds tape reads "AS OF 6:08 PM CT · STALE" and stays stale. Odds is the only broken tape. Find why and fix it.

## Verify live state first
Don't trust `/mnt/project`, frozen handoffs, or any wiring claim in this doc as fact. Grep the current tree and confirm against what's deployed. The two tapes wrote at different times (markets 3:28 PM, odds 6:08 PM), so they're on different update paths. Don't assume they share a cron or a fetch.

## Find the root cause
Four candidates. Determine which, with evidence:

1. Freshness logic / threshold. Where does the odds tape decide STALE? What timestamp does it read (last DB write, cache age, a source field) and what's the threshold in minutes? Confirm the AS-OF stamp itself is right: correct timezone, correct source field. A timezone mismatch in the comparison flags fresh data as stale, and this project has hit timezone-stamp bugs before.

2. The odds job isn't running. Kalshi + Polymarket feed the strip. Is the fetch a cron, a route, or populate-on-read with a TTL? When did it last succeed? Check `cron_runs` (or whatever run-log exists) for the odds job's last success and any error rows. Vercel Hobby caps cron at once/day, so if odds need fresher-than-daily they ride GitHub Actions or populate-on-read, not the daily Vercel cron. Confirm which path actually feeds them.

3. Source endpoint dead or changed. Probe the actual Kalshi and Polymarket endpoints the code calls, on the current tier. This must run from Vercel egress, not localhost. Cloud IPs behave differently (FRED `fredgraph.csv` works locally but is blocked from Vercel), so a passing local fetch proves nothing. Use a deployed diagnostic route or function. Report status codes and a sample of the returned shape for each.

4. Fetch succeeds but the write/stamp doesn't update. If the source returns data yet the AS-OF stamp is frozen, the write path or the timestamp update is failing silently.

## Fix or report
- Threshold mis-tune, wrong timezone in the comparison, cron schedule, or write-path bug: fix in place. State exactly what you changed and to what value.
- Source endpoint dead or schema-changed: STOP and report findings. Do not improvise a replacement source or stand up a new API. I'll scope the re-wire.

## Constraints
- Probe third-party sources from deployment egress, not local. Dead-source history for context: OpenSecrets (Apr 2025), FMP `/api/v4/` congress-trading (Aug 2025), Stooq `/q/l/` CSV (~Jun 2026).
- No new third-party source without sign-off.
- No destructive DB ops. Threshold or schema edits are fine; note them.
- Commit by explicit pathspec, never `git add -A`. Re-check HEAD before push to avoid absorbing another session's staged work.
- Remove any temporary probe route after diagnosing, or fold it under `scripts/diagnostic/` if it's worth keeping as a regression probe. Don't leave a one-off probe live in `app/api`.

## If you ship a fix
`tsc` clean → `npm run build` clean → `git push` (named paths) → `npm run verify:deploy` until the served SHA matches HEAD → eyeball the odds tape on prod reading fresh and not STALE. Not shipped until the tape reads fresh.
