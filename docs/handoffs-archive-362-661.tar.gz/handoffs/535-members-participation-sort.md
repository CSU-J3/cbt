# HO 535 — participation sort on the /members roster (119th missed-rate)

The banked participation *sort/rank* (the constraint the HO 523/525 carve-out was written for). HO 527 shipped the **distribution** view (the dotplot); this is the **ranked list** — "who misses the most votes," the cut you can't cleanly pull from a dotplot. Adds a **MISSED** sort segment beside VOLUME / PASS RATE that orders the roster by each member's 119th missed-vote rate, delegates carved out of the ranking (marked, not removed).

**Code build.** A sort key + the query's ORDER-BY branch + a repurposed rate column + the delegate carve-out. **No probe** — the missed-rate is the same per-member aggregate the dotplot already computes (member-scale, ~536 rows); joining it to the roster query is not a cost question. **No `.mc-row` grid change** (see below — the grid is shared). Diff shown before commit; **no doc edits, no SKILL** (its own doc sweep after). **No bar move** — an enabling surface on `/members` (Member depth already 100, the HO 425/527 precedent).

## Baked from the code (facts — do not re-derive)

- **The `.mc-row` grid is SHARED — do NOT touch `grid-template-columns`.** `.mc-row` (5 cols: `1fr 320px 56px 64px 52px`) backs both the `/members` roster **and** `/lobbying`'s `FilingRow` (`components/FilingRow.tsx` — "fell back to the members `.mc-row` grid"). Widening it to a 4th numeric column would reshape the lobbying filing rows — a containment break. So the missed-rate **reuses the existing RATE column** (`.mc-r-num`), swapping its content by sort, rather than adding a column. `.mc-row` / `.mc-r-num` / `/lobbying` stay byte-identical.
- **The roster row has three fixed numeric columns** (app/members/page.tsx `renderRow`): RATE (`rateLabel` = passrate `{round(passrate*100)}%` or `—`) · ENACT (`{enacted} ✓`) · BILLS (`{total}`), with a header row (`.mc-row-hdr`) whose spans read `RATE` / `ENACT` / `BILLS`. The RATE column and its header are what this feature repurposes when the missed sort is active.
- **The sort is `SponsorSort`** (`SPONSOR_SORTS = ["volume","passrate"]`, `lib/queries.ts:5210`), sanitized by `sanitizeSponsorSort`, and driven by a **`SegmentedToggle<"volume"|"passrate">`** (app/members/page.tsx ~476, segments VOLUME / PASS RATE) via `buildSortHref` (~285, which already sets `?sort=<value>` for any non-`volume` value). This is a **different** system from `SortDropdown`/`SortKey` (the bills feed's action/introduced) — don't touch that.
- **`getMembersRanked`** (`lib/queries.ts` ~5330) does the ranking: a `bills_agg` CTE + a `palestine_scorecard` join, `ORDER BY` a `CASE WHEN ? = 'passrate'/'volume' THEN … END DESC` chain with `m.name ASC` as the final tiebreak, args `[...args, sort, sort, sort, pageSize, offset]` (the `sort` value threaded once per CASE). SQLite `DESC` sorts NULL **last** by default — that's how zero-bill members sink on passrate, and it's exactly what we want for delegates/floored on missed.
- **The 119th missed-rate metric** (identical to `getChamberParticipationContext` / the HO 527 dotplot): per current member, `SUM(mv.position='not_voting') / COUNT(*)` over `member_votes`, `HAVING COUNT(*) >= PARTICIPATION_FLOOR` (the exported `PARTICIPATION_FLOOR = 50`). Reuse that constant.
- **The delegate carve-out predicate** (HO 527): `m.chamber='house' AND m.state IN ('DC','AS','GU','MP','PR','VI')` — the 6 non-voting members (no delegate flag exists; that territorial set is the predicate). Their structural not-voting must **not** rank them as the top vote-missers (the HO 527 "population-correctness, not outlier-trimming" oddity). On a *roster* (unlike the dotplot, which drops them), carve them from the **ranking** but keep them in the **list**: expose their rate as NULL so they sort last and display `—`, marked non-voting.

## §1 — Sort key + control

- `lib/queries.ts`: `SPONSOR_SORTS = ["volume", "passrate", "missed"] as const`. `SponsorSort` / `SPONSOR_SORTS_SET` / `sanitizeSponsorSort` all follow from the array — no other change (`"missed"` is now a valid sort; unknown values still fall back to `"volume"`).
- `app/members/page.tsx`: widen `buildSortHref`'s param type to `"volume" | "passrate" | "missed"` (its body already handles any non-`volume` value). Add a third `SegmentedToggle` segment `{ value: "missed", label: "MISSED" }` and widen the toggle's generic to `<"volume" | "passrate" | "missed">`. Order: **VOLUME · PASS RATE · MISSED**.

## §2 — Query (`getMembersRanked`, and mirror into `getCommitteeRoster`)

Add a participation-agg CTE + the ORDER-BY branch + the SELECT column:

- **CTE** (factor a small `participationAggCte` string so both queries share it): `part_agg AS (SELECT mv.bioguide_id AS bid, CAST(SUM(CASE WHEN mv.position='not_voting' THEN 1 ELSE 0 END) AS REAL) / COUNT(*) AS missed_pct FROM member_votes mv GROUP BY mv.bioguide_id HAVING COUNT(*) >= ${PARTICIPATION_FLOOR})`.
- **JOIN + SELECT:** `LEFT JOIN part_agg pa ON pa.bid = m.bioguide_id`, and select the carved rate: `CASE WHEN m.chamber='house' AND m.state IN ('DC','AS','GU','MP','PR','VI') THEN NULL ELSE pa.missed_pct END AS missed_pct`. Delegates → NULL (unranked + `—`); floored/no-votes → NULL (already, via the LEFT JOIN + HAVING).
- **ORDER BY:** add `CASE WHEN ? = 'missed' THEN missed_pct END DESC` as the **first** ORDER-BY term (so it leads when active), before the existing passrate/volume cases; thread one more `sort` into the args (`[...args, sort, sort, sort, sort, pageSize, offset]`). NULL-sorts-last (SQLite default DESC) sinks delegates/floored to the bottom of the missed sort, `m.name ASC` still the final tiebreak.
- **Return type:** add `missedPct: number | null` to `MemberRanking` (mirror the `passrate` null-mapping). 
- **`getCommitteeRoster`** (the scoped-roster path, which shares the `?sort=` control): thread the **same** three additions so the MISSED segment works in the committee view too, not just the full list. If its structure diverges enough that this balloons, ship the full-list `getMembersRanked` v1 and flag the committee-roster mirror back for a fast-follow (don't leave a segment that silently no-ops on committee rosters without saying so) — but the CTE + case should drop in symmetrically.

## §3 — Row + header (repurpose the RATE column, `app/members/page.tsx renderRow` + the header row)

Drive the RATE column off the active `sort`:
- **Value:** `const showMissed = sort === "missed";` The first `.mc-r-num` renders `showMissed ? (m.missedPct === null ? "—" : \`${(m.missedPct*100).toFixed(1)}%\`) : rateLabel`.
- **Color:** when `showMissed`, color by presence/severity — `m.missedPct === null ? "var(--text-dim)" : "var(--accent-amber)"` (amber = the miss metric, distinct from passrate's `--stage-enacted` green; the sort already orders by severity so the top rows are the high missers, no gradient needed). When not missed, keep the existing passrate green/dim.
- **Header:** the `.mc-row-hdr` RATE span reads `MISSED` when `showMissed`, else `RATE` (thread `sort` to wherever the header row renders). ENACT / BILLS headers unchanged.
- **Delegate/floored rows** show `—` in the column (same as passrate-null today) — no separate treatment needed; the NULL rate carries both the sort-sink and the display.
- **Disclosure:** when `showMissed`, add a light note in the roster context/header strip (the `.mc-ctx` "· {rosterTotal} members" area, or beside the sort) — `non-voting delegates unranked` — the HO 527 disclose-the-carve-out posture. One muted clause, only in the missed sort.

## Guardrails + deliverable

- **No probe, no `.mc-row` grid change.** Confirm `.mc-row` / `.mc-r-num` / `.mc-row-hdr` CSS is **untouched** in the diff (the shared-with-lobbying invariant) — this is a TSX-only change plus the query.
- Metric is the **119th missed-rate** (dotplot + B1 parity); the top of the MISSED sort should match the dotplot's right tail (Frederica Wilson ~29% et al., HO 527 §D — voting members, not delegates). A **career** sort is banked (its NULL-coverage set differs — the same reason the dotplot's career toggle is banked).
- Read `/mnt/skills/public/frontend-design/SKILL.md` before the row/header edit.
- **Diff shown before commit.** Explicit pathspec (`lib/queries.ts` + `app/members/page.tsx`, + the `SegmentedToggle`/header files only if they need touching); confirm `.mc-*` CSS and `/lobbying`/`FilingRow` are untouched, `getBillAmendments`-style shared queries clean, concurrent-session files clean. Ancestry eyeball, FF only. **One code commit.** `verify:deploy` + confirm live: MISSED reorders the roster (Wilson-type voting high-missers on top, delegates at the bottom showing `—`, the header reads MISSED), VOLUME/PASS RATE unchanged, and the missed sort's top matches the HO 527 dotplot tail.

## Banked (record in the doc sweep)

- **Career missed-rate sort** — a second participation sort key off `member_career_votes` (the NULL-coverage handling that kept it off the dotplot toggle applies).
- **Career chamber-median context** on the member hub — still the deliberate hold (avoids a 4-stat hero); unchanged by this.

read docs/handoffs/535-members-participation-sort.md and follow it
