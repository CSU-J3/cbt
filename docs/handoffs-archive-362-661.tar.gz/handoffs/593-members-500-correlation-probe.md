# HO 593 — are the prod `#418` fires and the intermittent 500 the same fault?

**Numbering.** Next from `docs/roadmap.md`'s pointer. 592 is the parser-diff probe (`fe35562`); 588 remains the parked absence-watch probe with its block owed. Confirm against the roadmap and `git log`.

**This handoff builds nothing.** Five measurements, then a hard HALT. No fix code, no crawl changes, no read-budget optimisation.

---

## §0 — Why the question changed

Three probes have now falsified the same family:

| hypothesis | status | where |
|---|---|---|
| the markets tape as prod's cause | measured out — fresh-served, sub-second gap | 590 C5 |
| H4 — static prerender + `useSearchParams` skew | falsified — every firing route is `ƒ` | 589 M4 |
| the clock class generally, on fresh-served routes | cannot fire — `control(+0)` never does | 590 C5 |
| H5 — data-dependent invalid HTML nesting | falsified — 0 restructured nodes, 37 routes | 592 M1 |
| the HO 473 SVG `<title>` class | clean at HEAD, static **and** runtime | 592 M2 |
| client-side render-time nondeterminism | nothing node-gating, two independent passes | 590 M3, 592 M3 |

That is the whole *"a client component renders differently than the server did"* family. Every member is dead. The remaining family is that **the server HTML is itself sometimes degraded** — not a component behaving nondeterministically, but a render that didn't complete normally.

Two independent things now point there:

1. **589 M2 already found a 500 inside the failure bucket.** Run `30595816107` was a transient Server-Components 500 with the digest omitted — not a #418 — sitting in the set that had been treated as one intermittent. That was recorded as a sample correction and not pursued.
2. **592 measured `/members` and `/members/pass-rate` 500ing intermittently on prod right now**, load-correlated: 1/10 direct, 2/5 on pass-rate, 0/30 in two calm windows, then both during a full sweep. `/committees` 307s to `/members` and inherits it. `/members` is the heaviest surface in the crawl (12,707 elements, 1,076 rows).

**Read the load result harder than 592 did.** A 20-way concurrent burst on one route came back all-200; a sequential sweep across 37 *distinct* routes fires. Same concurrency, different number of cache keys. That is not a concurrency ceiling — it is **read volume**, and the standing constraint on read volume in this project is the Turso rows-read quota, which prod has already hit once account-wide (SQL reads forbidden, every DB-backed page 500ing while `/api/version` stayed 200).

**The question this HO answers is narrow:** are the prod `args[]=HTML` fires and the intermittent 500 one fault or two? It does not fix either.

---

## STEP 0 — five measurements, then HALT

Script: `scripts/diagnostic/members-500-correlation-593.ts` where a script fits; M4 is CLI work. Commit, then HALT.

### M1 — the cross-tab, from data already on hand

`smoke.spec.ts:199` logs one line per route per run:

```
[slug] hit1=<status> failed=… bad=… console=… pageErr=<n> | hit2=<status> … pageErr=<n>
```

Both the HTTP status and the hydration-error count, side by side. **No instrument change is needed** — this is a grep over the 14-day CI log window.

Build the table: for every run and every route, `hit1`/`hit2` status × `pageErr` count. Then answer:

- Do runs that fired `#418` **also** contain non-200s? On the same route, or different ones?
- Does any route ever show a non-200 and a `pageErr` on the **same hit**?
- Are the two disjoint across the whole window?

Interpretation, stated in advance so the result can't be read to taste:
- **Co-occurring, especially same-run/same-route** → one fault is the live hypothesis and M2–M4 are worth their cost.
- **Disjoint** → two faults. Say so plainly; the `#418` loop stays exactly as open as it is and the 500 becomes its own item.
- **Too few non-200s in-window to tell** → that is the answer. Record the counts and don't infer from three data points.

Also re-check the `pageErr` route set against the 500 route set. If `/president` fires `#418` but never 500s, that is evidence against one-fault, and it must not be quietly dropped the way it was in the 591 draft.

### M2 — characterise the trigger

592's burst-vs-sweep result is the sharpest lead and it was incidental. Make it deliberate. Vary one dimension at a time against prod and record the 500 rate:

- **N distinct routes, sequential** (the sweep shape) — sweep N up and find the knee.
- **N concurrent, one route** (the burst shape, already all-200 at 20) — confirm it stays clean at higher N.
- **N concurrent, N distinct routes** — separates concurrency from key count.
- **`/members` alone, repeated** — does the heaviest route self-trigger, or does it need the rest of the sweep ahead of it?

The prediction under the read-volume reading: rate tracks **distinct cache keys touched**, not request concurrency. If it tracks concurrency instead, the Turso framing is wrong and M4 is a waste — say so before spending it.

Keep this bounded. You are measuring prod, and the measurement is itself the load that causes the fault.

### M3 — capture a digest

592 couldn't get one. Try the channels it didn't:

- Vercel runtime logs for the 500 window (function logs carry the Server Components digest even when the HTML omits it).
- `lib/db.ts` and the HO 238 DB-timeout fast-fail path — does a fast-fail surface as a 500, and does it log anything identifying?
- Whether the 500 is the whole route or a failed segment inside a streamed response. **This is the load-bearing detail for the one-fault question**: a segment that fails after the shell has flushed is precisely the shape that could produce a structurally different tree without any component behaving nondeterministically. A whole-route 500 could not.

### M4 — Turso, per the standing rules

Gated on M2 pointing at read volume. Do not run this if M2 says concurrency.

- `turso auth whoami`, `turso plan show`, `turso org usage`. The **platform CLI keeps working when SQL reads are forbidden** — that is how the last block was diagnosed. **Do not use `turso db inspect`**; in some versions it queries the DB and is the wrong tool under a block.
- **Check the billing-period END DATE before the plan tier.**
- Score any daily number against **day-matched quiet days**, never against the ~88M peak-day figure — that was a spike arc, not a plateau, and the peak day was plausibly inflated by the diagnosing session's own traffic.
- The dashboard's final/current-day point can be a partial bucket. The tell is other flat series collapsing at the same x. Never score the last bar until the following day.
- **Do not optimise anything.** `turso org usage` tells you where reads go; that is the deliverable. Optimising before it answers is the exact mistake the read-budget WATCH records.

### M5 — is this the backlog's filtered-view 500?

592 noted `/members?sort=passrate` is a filtered view and wondered if it's the unfixed filtered-view 500 already in the backlog. **That is a claim, not a fact.** Read the backlog entry, re-verify its reproduction, and report SAME ITEM / DIFFERENT ITEM with evidence. A logged item is a claim — HO 420's Kiley party-flag is the standing precedent for scoping a fix on an unverified logged bug.

---

## HALT

Commit as `diag(prod): HO 593 STEP 0 — members 500 / pageErr correlation`, then stop. Report M1's cross-tab table, M2's trigger curve, M3's digest or its absence, M4 if it ran, and M5's verdict — plus a one-line answer to the title question: **one fault, two faults, or not yet answerable.**

## Scope guards

1. **No fix code**, for either symptom.
2. **No changes to `smoke.spec.ts`, `e2e-prod.yml`, or the crawl cadence.** M1 reads what already exists; changing the instrument mid-measurement destroys comparability with the 14-day window.
3. **Do not close, narrow, or re-frame the `pageErr` OPEN LOOP.** It closes on a named cause for the prod fires plus green runs. A correlation is not a cause.
4. **No read-budget optimisation, no cron cadence changes, no cache tuning.** M4 measures; it does not act.
5. **No unrequested SKILL.md edits.** Report anything SKILL gets wrong and let it be scoped.
6. **Bound the prod load.** M2's measurement is the fault's own trigger — cap it, and state the cap in the report.
