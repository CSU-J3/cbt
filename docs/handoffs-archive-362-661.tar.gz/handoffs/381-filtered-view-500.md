# 381 — Filtered-view 500 fix (diagnose then fix)

**Self-claim:** if `docs/handoffs/381-*.md` exists, bump to the next free number (`ls docs/handoffs/ | sort -V | tail`) and rename before starting.

**Scope:** the smoke crawler (HO 379) found that filtered home and `/bills` views return HTTP 500 in prod. Reproduce both failures locally, fix them, verify locally, show the diff, hold for approval. No commit, no deploy until approved.

## Symptom (HO 379, reproduced with plain `curl --cookie ct_seen=1`, not a headless artifact)

- `/` unfiltered → 200. `/?stage={any of 6}` → 500. `/?topics=defense` → 500.
- `/bills?stage=committee` (~13.7k rows) → 500. `/bills?stage={every lower-volume stage}` → 200.
- `/dashboard-classic?stage=committee` → 500 (shares home's filtered query path).
- Vercel digest 4101894172 on the home case.

Invisible until now because the `/` gate redirects anonymous traffic to `/welcome` and drops the param, so anon curl/monitoring follows the redirect to a 200. Only a cookied user clicking a filter hits it.

## Two distinct root causes — confirm, don't assume

1. **`/bills?stage=committee`, result-size timeout.** Only the high-cardinality bucket fails; every low-volume stage is 200. So the failing work scales with matched-row count: an unbounded aggregation / scan / expansion over the ~13.7k committee rows hitting the 10s Turso request abort. Same class as the breaking-news near-full-table-scan (fixed with an INDEXED BY hint) and the cold-500 audit.
2. **Home, any filter, size-independent throw.** Home 500s even for `stage=president` (one row), so it's not result-size; it's a logic/SQL error in a query `/bills` doesn't run. Home's extra filtered queries are `getTopicDistribution(filters)` (topic treemap), the breaking-news count, and the stage-changes count. Prime suspect `getTopicDistribution(filters)`: `/dashboard-classic` calls it and also 500s, while `/bills` doesn't and only fails on the committee bucket.

## Pinned constraints (Turso planner, from oddities/SKILL)

- INDEXED BY required on bills-table queries; the cold plan is not the warm plan; the stateless planner mis-plans fat tables.
- `stage='committee'` is ~91% selectivity (13,741/15,048), useless as a drive order. An index on `stage` for that bucket is worse than a scan. Drive by `idx_bills_latest_action` (date desc) and filter `stage` in the predicate.
- Covering vs non-covering matters; the cold-500 audit warns on non-covering scans over low-selectivity predicates.
- `GROUP BY` + `json_each` can force replanning even on a hinted query (known oddity), directly relevant to `getTopicDistribution`, which almost certainly `json_each`'s the topics array and `GROUP BY`s it.
- CASE-based `ORDER BY` defeats index short-circuits (73s cold query). Don't introduce one.

## Steps

1. **(Read-only) Reproduce both via `getDb()` locally against the shared prod Turso.** No 10s cap locally, so the timeout-class query runs slow-but-completes (time it, `EXPLAIN QUERY PLAN` it) while the logic-class query throws its real message immediately. That split tells them apart.
   - Home queries with a filter: `getTopicDistribution` with `stage=committee` and again with `topics=defense`; the breaking-news count and stage-changes count with a filter. Capture which throws and the exact error → bug #2.
   - `/bills` filtered query for `stage=committee`: time it + `EXPLAIN QUERY PLAN`, confirm the unbounded / non-covering plan and which index it's missing → bug #1.
   - Paste exceptions + plans before writing fixes.
2. **Fix #1** (`/bills` committee timeout): apply the INDEXED BY hint the EXPLAIN points to (date-driven, stage in predicate), or bound the aggregation if it's unbounded. Re-EXPLAIN + re-time to confirm a cheap cold plan. **If a genuinely new index is required, HALT and surface it before creating it** — it's a DDL write on the shared prod instance.
3. **Fix #2** (home filtered throw): correct the broken filtered path. If it's `getTopicDistribution`'s `json_each` + `GROUP BY` + filter composition, restructure / hint so the filter composes without the replanning error.
4. **Verify locally:** dev server pointed at prod Turso, hit all 6 `/?stage=` variants, a `/?topics=` variant, `/bills?stage=committee`, and `/dashboard-classic?stage=committee`. All 200.
5. **Show the diff. Hold for approval.** No commit, no deploy. After approval + deploy, re-run the crawler's filtered slice against prod to confirm green.

## Out of scope (banked, do not touch)

The `/welcome` gate param-drop (separate redirect/UX fix), the React #418 hydration mismatches, the zero-width PRESIDENT bar click target, CI wiring.

## Report back

The two exceptions/plans found, the fixes applied, local 200 confirmation across all filtered variants, the diff.
