# HO 508 — doc sweep for the `/bill/[id]` redesign (HO 507)

## Why

HO 507 shipped at `eaf79a4` with **no docs in the commit** (by design — the code/docs split). Nothing is on record: the roadmap's `Also` run still ends at HO 504, the backlog still lists the redesign as QUEUED and the `TopicTags` holdout as BANKED, SKILL's `/bill/[id]` entry describes the pre-507 card layout, and the type-vs-SELECT finding is unwritten.

## Ground truth

Clone / hard-reset to `origin/main` first — HEAD should be **`eaf79a4`**. Re-grep every line number below at write time; they're from a clone, not gospel.

**Numbering note, so nobody hunts for missing blocks:** the roadmap pointer reads *"Also notes now run through HO 504"* — correct. **HO 505** was the doc sweep *for* 503–504 (its content IS that block, plus a SKILL testing-section refresh at `2c453af`), and **HO 506** was docs-only (`22fd265`, backlog + oddities, CA-cert pre-flight — no shipped surface, so no roadmap block). Neither is missing. This sweep bumps the pointer **504 → 507** and should say so in one clause (the HO 487 precedent for the skipped 484).

## What shipped at HO 507 (the facts the sweep records)

One commit, six files: `app/bill/[id]/page.tsx` (rewritten), `app/globals.css` (+166, the new `.bdp` scope), `components/BillAmendments.tsx` + `components/BillLobbying.tsx` (internal stat lines removed — folded into the shell headers), `lib/queries.ts` (+3 SELECT columns), `components/TopicTags.tsx` **deleted**.

- The page is now **the feed expand panel's big sibling**: a bordered hero carrying the shared **`BillStageBar`** (imported from `BillExpandPanel`, HO 317) + the `.bxp-body` 1.35fr/1fr grid — SUMMARY prose then RELATED NEWS (`getNewsForBill(bill.id, 5)`, the one added read — the exact query `/api/bill/[id]/panel` already runs) on the left, the boxed `.bxp-metabox` on the right (sponsor member-link · cosponsor support bar · **`TopicChips`** · introduced · last action with the folded 3-line-clamped text · `CONGRESS.GOV ↗`).
- Below: member-hub section shells — **COMMITTEES | HEARINGS side-by-side** (`.bdp-pair`, single-column ≤900px, **lone survivor renders full-width**), **AMENDMENTS** with agreed/failed tallies in the header and a **340px scroll bound** so `119-sconres-7`'s magnet render stops setting page height, **LOBBYING** with filings/clients folded into the header. The standalone `LATEST ACTION` section is gone.
- Footer collapsed to one row: back · no-JS `<details>` raw-JSON toggle · attribution.
- **Containment held:** zero edits to the shared `.bxp-*`/`.v2f-bar` rules; every deviation is additive under the new **`.bdp`** wrapper scope (the HO 486/492/496 pattern). Feed expand panel verified byte-identical.
- **`TopicTags` deleted** — `/bill/[id]` was its last consumer, closing the HO 316 holdout. It used only Tailwind classes, so **no orphaned `globals.css` rules** (verified; don't go hunting).
- **Sponsor double-bracket strip:** `sponsorDisplayName()` is page-only and display-only — it strips the `[P-ST]` embedded in `sponsor_name` so the colored `PartyTag` isn't double-printed. **The query keeps the embedded form** (other consumers may depend on it) — the `BillAmendments` precedent. Verified in the served DOM on `119-sres-807` (Blumenthal → one `[D-CT]` span) and on a district form (`[R-SC-3]` strips clean; `PartyTag` shows the canonical two-part `[R-SC]` per HO 468).

## The edits

### 1. `docs/roadmap.md` — new `Also (HO 507)` block

Append-only: **add** a new block at the end of the `Also` run (immediately before the **Banked / unbuilt** paragraph). Never retro-edit a prior dated block (HO 418 precedent). Close it with **"Also notes now run through HO 507."**

Content to carry: the panel-family framing and why (the summary was buried 6th on the page whose whole job is "WTF is this bill"; the feed's hover panel outclassed the dedicated page — colored stage pipeline vs plain `StageIndicator`, RELATED NEWS present in the panel and absent on the page even though the ⚡ media-attention chip links here); the four condensation moves and their HO 492 precedent; the `.bdp` containment rule and the byte-identical verification; the `TopicTags` deletion closing HO 316; the three-column SELECT addition (§2 below — state the corrected mechanism, not "the type lied"); the display-only sponsor strip. **No theme-% change** — a chrome restructure on an existing surface, matching the HO 486 / 492–493 / 495–496 precedent where every browse-surface redesign held its bar. Note in one clause that **all three category browse surfaces (`/members` 328, `/lobbying` 486, `/bills` 496) plus the detail page now share one design vocabulary** — the arc that started at HO 328 is complete. Docs: HO 508.

### 2. `docs/oddities.md` — one new entry (append at end)

**Write the corrected mechanism, not the one banked in Code's memory.** The banked note says "`BillDetail` casts as `FeedBill & {...}` but the SELECT didn't cover it, so the type lied to tsc." That's the right instinct and the wrong mechanism — a *lie* implies tsc could have caught it. It couldn't:

- `FeedBill` declares `sponsor_bioguide_id?`, `cosponsor_count?`, `stage_changed_at?` as **optional** (`lib/queries.ts:129–140`), deliberately — the HO 188 comment says so: feed-shape queries that don't SELECT them "degrade to null" on `/stale`, `/changes`, `/watchlist`.
- `BillDetail = FeedBill & { raw_json; summary_model; summary_updated_at }` inherits that optionality, so `getBillById`'s hand-assembled object literal **omitting all three typechecks cleanly**. Nothing was lying. The type said *"these may be absent"*, and they were — permanently, for every caller of this function.
- So the failure mode isn't a compile error, it's a **silently-null render**: a new consumer writes `bill.cosponsor_count`, tsc is happy, the support bar renders empty forever. `stage_changed_at` is the sharper case — `BillStageBar` reads it, so the bar would have rendered with no timing rather than not at all.

Title it around that: **an optional field on a shared row type can't tell you whether the SELECT populates it — the check tsc can't run.** The rule: *before consuming an optional `FeedBill` field on a new surface, read the SELECT, not the type.* Cross-reference the **HO 495–496** entry (*The parked `/bills`-redesign plan claimed `getTopicDistribution` "no new query needed"*) — same class on the query-behavior axis, and the same fix: read the implementation, not the prose about it. Note that the HO 507 spec's "everything else the page already fetches" was written off the type and was wrong; Code's diff review caught it, and the fix was three plain `bills` columns on the existing point lookup (no JOIN, no new shape).

### 3. `docs/backlog.md` — two tombstones, one partial strike, one WATCH entry

- **QUEUED ~line 81**, `- **`/bill/[id]` page redesign** (HO 125)…` → strike through and mark **SHIPPED HO 507 (`eaf79a4`)** with a one-line what, pointing at the DONE tombstone.
- **BANKED ~line 115**, the two HO 317 follow-ups → strike **only (b)** (the `/bill/[id]` topic-chip migration — shipped HO 507, `TopicTags` deleted, `TopicChips` in the metabox). **Item (a), the dead-CSS sweep, stays live** — it's a separate open item and 507 orphaned no CSS. Make the item read as partially discharged, don't strike the whole bullet.
- **DONE** — append a tombstone for the redesign: the four condensation moves, the `.bdp` containment rule, the `TopicTags` deletion closing the B6 chip family (topic 316 · ID 466 · stage 467 · party 468 — the last holdout is gone, so the family is now genuinely complete, not "complete except one page"), the SELECT gap → oddities pointer, the sponsor strip. Roadmap: the HO 507 block.
- **WATCH** — add the one owed eyeball: **the `.bdp-pair` ≤900px stack with BOTH sections populated.** The survivor-goes-full-width branch was verified on `119-sconres-7` (committees-only); the both-populated narrow-viewport stack is the case headless didn't exercise visually. *Promote* only if it renders wrong. (Leave the existing "hearings LIVE state" owed-eyeball on the roadmap where it is.)

Do **not** touch the struck HO 287 chip-family block at ~line 74 — its parenthetical about `TopicTags` surviving on `/bill/[id]` is inside already-tombstoned text, which is history.

### 4. `.claude/skills/cbt/SKILL.md` — three edits, **separate commit, diff shown, explicit re-approval**

The SKILL self-mod guard applies: show the diff and **wait** before committing, and never ride it with the other docs.

- **The `/bill/[id]` entry (~line 1401)** is now wrong in structure, not just detail — it describes a card panel with a Sponsor/Introduced/Last action/Stage/Topics field grid and places LOBBYING "after Hearings, before Summary". Rewrite it to the shipped page: the panel-family hero (shared `BillStageBar` + `.bxp-body` grid + `.bxp-metabox`), the `.bdp` scope rule (**additive only — never edit `.bxp-*` for this page's benefit; the feed panel must stay byte-identical**), the section order and the pair/bound/fold behaviors, the one-row footer, `getNewsForBill(bill.id, 5)` as the added read, and the display-only sponsor strip. **Keep** the durable facts already there that still hold: committees section skipped entirely on zero rows, no dedupe on referred-then-reported, `getBillLobbying` null → section omitted.
- **The chip-family section (~line 1515)** still reads *"The lone borderless `TopicTags` holdout is `/bill/[id]` (backlog)"* and describes the id/stage/party chips as unmigrated. Both are stale — the B6 arc closed at HO 468 and the topic holdout closed here. Update to current state and drop the holdout clause.
- **The Tooltip section (~line 1669)** names `TopicTags` as a primitive consumer ("every topic acronym — HLTH/IMM/FIN"). That component no longer exists; **`TopicChips`** carries the `term`-variant tooltip now. Fix the name; the convention itself is unchanged.

**Apply the HO 505 ownership split** while you're in here: oddities OWNS the optional-field/SELECT mechanism (§2). SKILL should *name* it in a clause and point, not restate it. This is the promoted WATCH item and it has now fired once pre-commit — don't be the fifth instance.

## Verification

- `docs/roadmap.md` ends with the new block, the pointer reads 507, and no prior block was edited (`git diff` on the roadmap should be a pure append plus nothing else).
- The two backlog strikes are strikes, not deletions; item (a) of the HO 317 follow-ups still reads as open.
- `grep -rn "TopicTags" docs/ .claude/` returns only historical/struck references, no live claim that it exists.
- No code files in either commit.

## Git discipline

- Clone / hard-reset to `origin/main` first; HEAD `eaf79a4`.
- Explicit pathspec staging; never `git add .`.
- **Two commits, in this order, never combined:**
  1. `docs: sweep the /bill/[id] redesign — roadmap block, the optional-field/SELECT oddity, backlog tombstones (HO 508)` — pathspec `docs/roadmap.md docs/oddities.md docs/backlog.md`.
  2. `docs(skill): refresh the /bill/[id] entry + retire the TopicTags holdout (HO 508)` — pathspec `.claude/skills/cbt/SKILL.md`. **Show me this diff and wait for explicit approval before it lands.**
- Ancestry eyeball before push (`git log --oneline @{u}..HEAD` — exactly the two commits, clean fast-forward, no concurrent-session files). Fast-forward only, no force-push.

## Report back

The roadmap block text, the oddities entry, the backlog diff, and — separately, before committing — the SKILL diff.

---

read docs/handoffs/508-doc-sweep-507.md and follow it
