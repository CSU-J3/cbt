# HO 434 — LDA lobbying source probe

## Why
Starts the LDA lobbying pillar (the roadmap's "best next pillar" call). Before scoping any
data layer, this probe de-risks the one premise the pillar rests on: that LD-2 filings cite
bill numbers we can join to `bills`. That's a claim, not a fact, and it's the same shape as
the news-funnel finding where the shared bill-ID regex hit 0 of 55 RSS subheads. If LDA free
text cites bills as rarely, the pillar's value changes and we scope it differently.

Read-only. No schema, no data written, no new runtime deps. Diagnose first; we scope the
build off your numbers.

## Step 0 — commit gate (first)
1. Report local git state: `git status`, `git stash list`, `git log --oneline origin/main..HEAD`
   (unpushed), `git log --oneline HEAD..origin/main` (behind).
2. Clean tree with nothing unpushed: say so, go to Step 1.
3. Dangling work: list it, propose a commit plan honoring two-commit separation (refactor vs
   feature, docs-only separate from code). Do NOT commit or push. Show the plan + diffs and
   wait for approval.

Untracked `docs/handoffs/*.md` is expected (gitignored since HO 432). Don't flag those.

## Step 1 — host + liveness (read first: the source is mid-migration)
The Senate LDA API is being sunset. Every page banners that `lda.senate.gov` goes away around
06/30–07/31 2026 and the canonical host is now the bare `lda.gov`. Today is past the earlier
cutoff, so assume `lda.senate.gov` may already be dead and build against `lda.gov`.

1. Probe both hosts, record which respond today and whether the legacy host redirects or 404s:
   - `https://lda.gov/api/v1/` (primary)
   - `https://lda.senate.gov/api/v1/` (legacy)
2. The `/api/v1/` root returns a JSON index of endpoints. Record the live base URL and the map
   (expect `filings/`, `registrants/`, `clients/`, `lobbyists/`, `contributions/`,
   `constants/filing/...`).
3. Auth is two modes. Anonymous works with stricter throttling; a key uses
   `Authorization: Token <key>`. Start anonymous for liveness + the small sample. If throttling
   bites, stop and tell me: I'll register (form at `/api/register/`, then POST `/api/auth/login/`
   returns a JSON `key`) and you re-run with the header. Record both rate limits.
4. Pull the taxonomy from `constants/filing/lobbyingactivityissues/` and
   `constants/filing/filingtypes/`. We need the issue-code list downstream.

## Step 2 — sample
1. Query `/filings/` filtered to LD-2 (quarterly activity) for the current window (2025 →
   present). Record the total count for the window and the response/pagination shape. Pull a
   few hundred, not everything.
2. Dump one filing in full (`/filings/{filing_uuid}/`): registrant, client, and the
   `lobbying_activities` array. For each activity capture `general_issue_code`, `description`,
   and the specific-issues free text (that free text is where bill references would live; the
   issue code is a controlled vocab).

## Step 3 — the join test (the point of this probe)
1. Find CBT's existing bill-ID extractor (grep `lib/` for the regex used in reports linking /
   the news funnel, HO 113 and HO 394). Reuse it. Don't write a new regex; reusing it is what
   keeps the rate comparable to the news 0/55 and consistent with how the app links bills.
2. Run it over the specific-issues free text across the sample and measure, with the raw counts
   behind each:
   - % of filings with ≥1 parseable bill ID
   - % of `lobbying_activities` with ≥1 bill ID
   - of extracted IDs, % that join to a `bills` row (current Congress), using the app's
     normalized bill-ID key
3. Hand-read 10–15 specific-issue texts and note how bills are actually referenced (`H.R. 1234`,
   bare titles like "the SUPPORT Act", issue-only with no bill number, etc.). If the machine
   rate and the eyeball disagree, say which and why.

## Deliverable (paste back in chat)
- live host + base URL, auth model, both rate limits, the sunset dates you confirmed
- LD-2 volume for the current window + field shape
- the three join-test numbers with raw counts
- a go / no-go on the bill-number join. If it's weak, the honest fallback: lobbying activity
  bucketed by `general_issue_code` (maps onto our topic taxonomy) as a standalone "what's being
  lobbied" surface, not bill-keyed
- one paragraph scoping the data-layer HO that follows: table shape, sync cadence, join strategy

No writes, no commits in Steps 1–3. LD-203 contributions exist on the same API and could feed
the money/donor surfaces later; note it as banked, don't probe it here.
