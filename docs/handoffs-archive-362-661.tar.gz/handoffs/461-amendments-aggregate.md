# HO 461 — the `/amendments` aggregate surface

The last QUEUED amendments fork. HO 446–448 built the pillar (probe → data layer → bill-hub section), HO 450 the member-hub section, HO 452 retired the persisted-status model NO-GO. Two forks are now live (`/bill/[id]`, `/members/[bioguideId]`); this ships the third and final one: the standalone cross-bill/cross-sponsor lens, the `/lobbying` + `/nominations` class (an aggregate surface, not an entity hub). After this the amendments pillar is feature-complete.

**Framing:** the corpus answer to "what's happening on the floor." The finding this surface exists to show (HO 448): `latest_action_text` is present on only **8.6%** of amendments, and `119-sconres-7` alone carries **1,131 amendments (17% of all 6,788)** — Congress files a mountain of vote-a-rama amendments and votes on almost none. That's the headline.

## The one decision — live vs. blob, gated inline

`/nominations` (SKILL line 1266) reads its full table live via `GROUP BY`, no `dashboard_state` blob, because it's bills-scale (1,879 rows). Amendments is 6,788 — bigger than nominations, 15× smaller than the `lda_*` tables that forced precompute. Both existing amendments surfaces (448/450) went straight to live with no probe on the same reasoning. Expectation: bills-scale-live.

The catch: `disposition` is **display-only-derived** (HO 452 killed the persisted column), so the corpus disposition breakdown scans `latest_action_text` (unindexed) — the one query here that isn't index-covered. The two ranked cuts (by-bill, by-sponsor) ARE covered by `idx_amendments_bill` / `idx_amendments_sponsor`. Per the covering-aggregate discipline (SKILL ~1172): an unbounded `GROUP BY` must be covering to be safe cold.

So **Step 0 is a cold-cost gate, not a separate probe HO** — measure the heaviest cuts against the live 6,788-row table before writing any surface code, and commit to live only if the number clears.

---

## Step 0 — cold-cost gate (do this first, report the number)

Write `scripts/diagnostic/amendments-aggregate-cost-461.ts` (sibling to `amendments-coverage-447.ts` / `amendments-actions-probe-452.ts`). Against **prod Turso**, cold (fresh client, no warm cache), time each of the three unbounded summary cuts and print wall-clock ms:

1. **Disposition scan (the unmeasured one):** `SELECT latest_action_text FROM amendments WHERE latest_action_text IS NOT NULL` — returns ~584 rows but SCANs all 6,788 (row-major storage → each page carries `raw_json`, the LDA-style bloat risk).
2. **By-bill GROUP BY:** `SELECT amended_bill_id, COUNT(*) AS n FROM amendments WHERE amended_bill_id IS NOT NULL GROUP BY amended_bill_id ORDER BY n DESC LIMIT 15` — expect index-only via `idx_amendments_bill`.
3. **By-sponsor GROUP BY:** `SELECT sponsor_bioguide_id, COUNT(*) AS n FROM amendments WHERE sponsor_bioguide_id IS NOT NULL GROUP BY sponsor_bioguide_id ORDER BY n DESC LIMIT 15` — expect index-only via `idx_amendments_sponsor`.

Also print `EXPLAIN QUERY PLAN` for cut 1 (confirm SCAN vs index use).

**Decision rule (report back before proceeding):**
- All three under ~2s → **proceed live** (the expected path — build Steps 1-3 as written).
- Only cut 1 is slow (SCAN hydrating `raw_json`) → add a **partial covering index** and re-measure:
  `CREATE INDEX IF NOT EXISTS idx_amendments_acted ON amendments(latest_action_text) WHERE latest_action_text IS NOT NULL`
  — turns cut 1 into an index-only scan of ~584 entries, no table SCAN, no `raw_json`. This is a pure performance index (the HO 277/340 covering-aggregate fix), **not** a status model — it doesn't reopen HO 452. If this clears, proceed live with the index in Commit 1.
- Cut 1 still slow after the index, or the GROUP BYs blow the `getDb` cap (not expected) → **STOP, report the numbers, do not build.** We pivot to a rollup blob (`amendments_rollup` in `dashboard_state`, computed by the existing `/api/cron/amendments` step), and I'll respec.

Commit the diagnostic in Commit 1 regardless of outcome (the sibling-diagnostic convention).

---

## Step 1 — query layer (`lib/queries.ts`)

Two live `unstable_cache` functions, tag `amendments`, `try/catch → null` (the getBillAmendments discipline). Reuse the module-level `deriveDisposition` already in this file — the summary calls it directly (same module, no export needed).

### `getAmendmentsSummary(): Promise<AmendmentsSummary | null>`

```ts
interface AmendmentsSummary {
  total: number;        // COUNT(*) — all amendments (~6,788)
  acted: number;        // latest_action_text present (~8.6%)
  agreed: number;       // deriveDisposition === "agreed"
  failed: number;       // deriveDisposition === "failed"
  otherActed: number;   // acted − agreed − failed (withdrawn / OOO / pending-with-text)
  filedOnly: number;    // total − acted (the ~91% never called up)
  byChamber: { senate: number; house: number };   // SAMDT+SUAMDT → senate, HAMDT → house
  topBills: { billId: string; billLabel: string; billTitle: string | null; count: number }[];
  topSponsors: { bioguideId: string; name: string; party: PartyKey | null; state: string | null; count: number }[];
}
```

Compose from:
- `SELECT COUNT(*) AS n FROM amendments` → `total`.
- The **Step-0 disposition query** (`SELECT latest_action_text ... WHERE ... IS NOT NULL`) → map each row through `deriveDisposition`, tally: `acted = rows.length`, `agreed`/`failed` by bucket, `otherActed = acted − agreed − failed`. `filedOnly = total − acted`.
- `SELECT amendment_type, COUNT(*) AS n FROM amendments GROUP BY amendment_type` → fold into `byChamber` (SAMDT/SUAMDT→senate, HAMDT→house).
- Top-bills: the Step-0 by-bill GROUP BY (LIMIT 15), then one join query `SELECT id, bill_type, bill_number, title FROM bills WHERE id IN (...)` over just those ≤15 ids; `billLabel` via `formatBillId(bill_type, bill_number)`, `billTitle` nullable. Preserve the count-desc order from the aggregate (the `IN` join won't return ordered — re-sort by the map).
- Top-sponsors: the Step-0 by-sponsor GROUP BY (LIMIT 15), then `SELECT bioguide_id, name, party, state FROM members WHERE bioguide_id IN (...)`; `party` via `normalizePartyVariant`. Same re-sort-by-count note. (Sponsors with a bioguide only — committee/manager amendments with null sponsor drop out of this cut, which is correct; they're counted in `total`.)

Use a `Promise.all` for the independent reads. `TOP_N = 15` as a single const (store == render).

### `getAmendments({ type?, disposition?, bill?, page }): Promise<{ rows: AmendmentListRow[]; total: number; page: number }>`

A filtered, paginated corpus feed ordered `update_date DESC` (idx_amendments_update), `PAGE_SIZE = 25`. This is a **bounded** query (LIMIT + small facets) — the low-risk class, not the Step-0 unbounded one.

```ts
interface AmendmentListRow {
  id: string;
  label: string;                    // "SAMDT 2137"
  amendmentType: string;
  amendedBillId: string | null;
  amendedBillLabel: string | null;  // formatBillId
  sponsorBioguideId: string | null;
  sponsorName: string | null;
  sponsorParty: PartyKey | null;
  sponsorState: string | null;
  purpose: string | null;
  latestActionText: string | null;
  latestActionDate: string | null;
  submittedDate: string;
  amendsLabel: string | null;       // sub-amendment parent, via the pa self-join
  disposition: "agreed" | "failed" | "other";
}
```

Where-builder (each branch a bound arg):
- `type` → `amendment_type = ?` (index-covered).
- `bill` → `amended_bill_id = ?` (index-covered) — the deep-link target from top-bills click.
- `disposition` → **coarse only** in v1: `acted` → `latest_action_text IS NOT NULL`, `filed` → `latest_action_text IS NULL`. Do NOT try to filter agreed/failed in SQL — `deriveDisposition` is JS keyword logic and a LIKE mirror would drift. The per-row dot still shows the fine grain (agreed/failed/other); the coarse filter answers the useful question ("show me only what got voted on"). Fine-grained disposition filtering is a banked follow-up.

Joins: `LEFT JOIN members m` (party/state), `LEFT JOIN bills b` (bill label), `LEFT JOIN amendments pa ON pa.id = a.amends_amendment_id` (parent label) — the getBillAmendments/getMemberAmendments join set, merged (the corpus feed fixes neither bill nor sponsor, so it carries both). Count query mirrors the where-builder without the join/limit.

---

## Step 2 — the surface (`app/amendments/page.tsx` + `components/AmendmentRow.tsx`)

Mirror `app/nominations/page.tsx` structure: `export const dynamic = "force-dynamic"`, `<HeaderBar basePath="/amendments" />`, `await searchParams`, a `filterHref` helper (URL-driven, no client island), empty-state guard, `<Pagination>`.

`SearchParams = { type?, disposition?, bill?, page? }`. Sanitize `type` against `SAMDT|HAMDT|SUAMDT`, `disposition` against `acted|filed`.

Sections top-to-bottom:

1. **Header + blurb.** H1 "Amendments" (amber, the nominations H1 style). Blurb (sans, `--text-muted`, ≤70ch): floor amendments to bills — who's amending what, and the sliver that actually gets voted on. Note most are filed in Senate budget vote-a-ramas and never called up.

2. **By status (the hero).** A segmented bar + stat readout over `total`. Four segments: `agreed` (`--vote-yea`), `failed` (`--vote-nay`), `otherActed` (`--text-secondary`), `filedOnly` (`--bg-row-hover`/muted — this is ~91%, one dominant segment, which is the point). Readout line: `N filed · N acted (X agreed · Y failed · Z other) · N awaiting floor action`, plus a sub-line `N Senate · N House` from `byChamber`. The muted-segment-dominates bar visually states "the floor almost never votes."

3. **Most-amended bills.** Ranked `<Link>` rows → `/bill/[id]`, bar length = `count`, showing `billLabel` + truncated `billTitle` + count. Each row also carries a `filterHref({ bill: id })` affordance so clicking scopes the feed below to that bill (or make the whole row the `/bill/[id]` link and add a small "N amendments →" filter link — your call; the bill hub is the richer destination, so lead with that). Surfaces `119-sconres-7` (1,131) at the top — the vote-a-rama magnets.

4. **Top amenders.** Ranked `<Link>` rows → `/members/[bioguideId]`, bar length = `count`, party-dot + name + `[party-state]` + count. Surfaces Bennet (`B001267`, 271) etc. Reuse the nominations agency-facet bar idiom (inline rows, not a new charting component).

5. **Feed.** Filter chips: type (ALL / SAMDT / HAMDT) + disposition (ALL / ACTED / FILED-ONLY) + a clearable `bill` pill (resolved to `formatBillId`, shown when `?bill=` is set) — the nominations chip idiom. Then the list of `<AmendmentRow>` + `<Pagination>`.

**`AmendmentRow`** (new, server component): a bare row the page maps (the member-page `MemberAmendmentRow` idiom, not the self-boxing `BillAmendments`). Renders the disposition dot + label + party-colored sponsor + amended-bill link (`/bill/[amendedBillId]`) + truncated purpose + date + the `↳ amends {amendsLabel}` sub-amendment note. Re-declare the 3-line `dispositionColor` (agreed→`--vote-yea`, failed→`--vote-nay`, other→`--text-muted`) locally — it's currently local to `BillAmendments.tsx`, and extracting it to a shared module touches two working components, so keep that a banked tidy (Commit-scope discipline: don't fold a refactor into a feature). The dot semantics match the two existing surfaces exactly.

---

## Step 3 — nav (`components/HeaderBar.tsx`)

Add to `NAV_ITEMS`, after the `nominations` entry (grouping the legislative-detail aggregate surfaces):

```ts
{ key: "amendments", href: "/amendments", icon: "Δ", label: "Amendments", tooltip: "Floor amendments — who's amending which bills, and the sliver that gets voted on" },
```

`Δ` (delta = change) reads as amendment and is mono-safe; swap freely if you prefer `§` or `⊕`. Verify `pathToNavKey("/amendments")` returns `"amendments"` and lights the tab (it's a top-level route with a matching key, so the href→key map should cover it — mirror however `nominations` resolves; add a matcher only if the tab doesn't highlight).

---

## Commit plan (spec-driven — plan, diff, approve, no auto-commit)

Two commits, the schema-separate-from-feature split:

1. **Query layer + gate** — `scripts/diagnostic/amendments-aggregate-cost-461.ts`, the two query functions in `lib/queries.ts`, and (only if Step 0 requires it) the `idx_amendments_acted` partial index in `scripts/migrate.ts`. If the index lands, it's a schema change → run `migrate` and note it.
2. **Surface + nav** — `app/amendments/page.tsx`, `components/AmendmentRow.tsx`, the `HeaderBar.tsx` nav entry.

Stage explicit pathspecs only (no glob). Show diffs and wait for approval before each commit. Ancestry eyeball before any push (one commit riding, clean fast-forward, no concurrent-session files touched).

## Verification (prod, after deploy)

Mirror the amendments-arc prod checks — hit the live surface across the shape:
- **Magnet:** `/amendments` loads, "most-amended bills" leads with `119-sconres-7` (~1,131); the status bar's `filedOnly` segment dominates.
- **Filter round-trip:** `?bill=119-sconres-7` scopes the feed; `?disposition=acted` narrows to the ~584 with action; `?type=HAMDT` narrows to House; deep pages (`?page=20`) don't 500 (bounded list).
- **Top amenders:** Bennet (`B001267`) near the top at ~271; row links resolve to `/members/[id]`.
- **Report the Step-0 cold numbers** (the three cuts, and whether `idx_amendments_acted` was needed) so the doc sweep records the live-vs-blob outcome.

## Deferred to the doc sweep (HO 462 — not this handoff)

Don't touch `SKILL.md` / `docs/roadmap.md` here (the SKILL self-mod guard + the feature/sweep separation). The sweep records: the roadmap block (amendments pillar feature-complete, no theme-% change — matching 448/450 and the LDA precedent, since the aggregate is a v1 lens on an existing pillar), the SKILL query-helper entries for `getAmendmentsSummary`/`getAmendments`, the nav glyph, and the Step-0 outcome (live confirmed at N ms, or the index added). Banked from this arc: the fine-grained disposition list filter, the `dispositionColor`/`deriveDisposition` extraction to a shared module, and the HO 452 `recordedVotes` amendment→roll-call-vote lead (still QUEUED, orthogonal).
