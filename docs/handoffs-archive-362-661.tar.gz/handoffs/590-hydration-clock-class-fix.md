# HO 590 — the clock-skew hydration class: rebuild the harness, prove the scope, fix cause #1

**Numbering.** `docs/roadmap.md`'s latest block reads *"Also notes now run through HO 586"* / *"Docs: HO 587."* 588 is the absence-watch probe (`7ce1f0e`, parked), 589 is the pageErr STEP 0 (`259babd`). This is **590**; the doc sweep for 588–590 is 591. Confirm against the roadmap and `git log`, not this filename.

**Prerequisite:** 589 (`259babd`) must be pushed to `origin/main` before this starts. This HO builds on it.

---

## §0 — What 589 settled, and the one thing it got wrong

Settled, and not to be re-litigated:

- `args[]=HTML` is the **structural** variant. `react-dom-client.development.js:5240` fills slot 1 with `fromText ? "text" : "HTML"`; CI captured `HTML`, so the mismatch is element-level.
- Slot 2 (the component-naming diff) is DEV-only — `dev=2 / prod=0` on the link, `dev=1 / prod=0` on the template. The prod message is byte-identical across every structural mismatch in the app, so **message identity carries zero cause-count information**, and the unattended crawl can never name a component as currently built.
- **H4 is falsified.** Every prod-firing route is `ƒ Dynamic`, so `useSearchParams()` gets real params server-side and cannot skew. Dropped as a mechanism.
- **Cause #1 is proven, not correlated.** `MarketsTapeClient` `useState(() => Date.now())` (`:714`) → `stripStale` (`:826`, against `STALE_THRESHOLD_MS = 26h` at `:46`) / `marketHoursClosed` (`:834`) → `itemState` (`:841`) → `dir` → `showSlots = dir !== "stale"` (`:456`) → the `<span className="markets-tape-arrow">` at `:554`. That gates **node existence**, which is what makes it capable of `args[]=HTML` at all. Under a DEV clock skew the arrows collapse and the hydration failure fires; at control it doesn't.
- **Cause #2 exists, is real in prod, is not clock-driven, and is unnamed.** `/members` fired at control+0; `/members/pass-rate` at +2d; both are tapeless. Prod's `committees-redirect` (`smoke.spec.ts:81`, `/committees` → `/members`) corroborates a members-side cause. 25 fresh-context re-tries produced 0 fires.

### The correction that must land before any of this reaches docs

**Code's four runs are not HO 574's four.** Code sampled `30724601882 · 30583714867 · 30572418753 · 30595816107`; HO 574 recorded `30506188415 · 30510430349 · 30470412500 · 30572418753`. One overlaps. So:

- The "`30595816107` is not #418, it's a transient Server-Components 500" correction applies to **589's own fresh sample**, not to HO 574's record. Writing it up as "one of HO 574's four wasn't #418" would be a false correction to an append-only record — the HO 587 misattribution class.
- The fresh sample is worth **more** than the report claims: three of its four runs are ones HO 574 never saw, making it a second, near-disjoint confirmation that the failure is live inside the 14-day window.

### The other thing 589 owes

`home @ +40d: SSR .markets-tape-arrow = 72 → post-hydration = 0 (control+0 = 36)`. **State which count is SSR and which is post-hydration in each case, and reconcile 72 against 36.** The likely explanation is marquee duplication (two stacked `<MarketsTape>` in `DashboardV2Header:147-148`, and/or the scroll loop's duplicated run), but likely isn't measured. The fire plus the collapse proves the mechanism regardless — this is about not inheriting an unexplained integer, the HO 550/553 rule.

### One guard correction, owned on the planning side

HO 589's scope guard told you not to commit the M5 harness. That was wrong: it is the only instrument that can prove this fix, and deleting it means rebuilding it. It gets rebuilt here and **committed**, because a fix whose falsification instrument is scratch is a fix recorded as protection without being fired.

---

## STEP 0 — rebuild the harness, prove the scope, then HALT

Commit as `diag(e2e): HO 590 STEP 0 — clock-skew hydration harness`. **No fix code in this commit.**

### The harness

Rebuild the M5 clock-skew rig as a **committed, local-only** artifact (it needs a local `next dev`, so it cannot ride `e2e-prod.yml` — see guard 4). Playwright 1.61 `page.clock.install({ time })` before `goto`, run against `next dev` so React 19 appends the `describeDiff` output with component names.

Two things it must do that the scratch version didn't:

1. **Detect on the DEV message, not the minified one.** 589's first pass reported NO FIRES because it filtered on the literal `#418` string; DEV emits *"Hydration failed because the server rendered HTML didn't match…"* through `pageerror`. Match on both forms, and log the raw message either way so a future detector bug is visible rather than silent.
2. **Capture the DEV component stack / overlay channel**, not just `err.message`. 589 found React collapses owner frames in `err.stack` (`…`), so the message alone won't name a component — this is the gap that left cause #2 unnamed, and closing it is the harness's main upgrade.

### M1 — re-prove cause #1 at HEAD (the pre-fix red)

`/` at the skew that fired, with the arrow counts stated as SSR vs post-hydration. This is the baseline the fix is measured against; without a recorded red at HEAD, a green after the fix proves nothing.

### M2 — prove or drop the two candidate siblings

589 reported the class firing on `/bill` and `/lobbying` and named `BillExpandPanel:266` and `FilingRow:28` as candidates. **Candidates, not findings.** For each: is the `Date.now()`-derived value gating a *node*, or only a class name / text? Only the node-gating ones can produce `args[]=HTML`, and only those are in scope. Report each as PROVEN-STRUCTURAL or TEXT-ONLY with the gating expression quoted.

Do not widen past these into the 36-row inventory. A row is in scope only if the harness fires on it.

### M3 — the static-route prediction

`/dashboard-v2` is `○ Static` (589 M4) **and** carries the tape, and it is in `ROUTES` (`smoke.spec.ts:84`). If its HTML is prerendered at build time, `now` at SSR is build time and every hydration is days later — so cause #1 predicts it fires on **essentially every** crawl, not intermittently. It is not in the reported prod firing set.

Resolve the discrepancy: does the static prerender actually contain tape items, or does it render the placeholder path where `pct === null` makes `showSlots` false on both sides? Either answer is useful — the first complicates cause #1, the second confirms it and explains the absence. **Do not skip this because it's inconvenient**; a mechanism that mispredicts one route in its own set is a mechanism that isn't fully understood.

### M4 — cause #2, one bounded attempt only

With the harness now capturing the component stack, take **one** bounded pass at `/members` and `/members/pass-rate` at control (no skew) — the condition under which it fired. Cap it; 589 already spent 25 tries. If it doesn't fire, that is a **result, not a gap**, and cause #2 stays unnamed and open. Do not extend this into an open-ended hunt inside a fix HO.

**HALT here.** Report M1–M4 with the scope list before writing any fix code.

---

## The fix (phase 2, after approval)

### Cause #1, the shape

The contract is: **SSR and the first client paint must render byte-identical markup**, with live state arriving on the next commit after mount.

**Recommended: prop-drill a server-computed `nowMs`,** matching the established house pattern — `HearingsTab` passes a server `Date.now()` into `HearingsList` and the value serialises into the RSC payload, so both sides share one number (the HO 489/490 fix). `MarketsTape` is the server wrapper; `nowMs={Date.now()}` there, consumed as the initial state in `MarketsTapeClient`, with the existing 60s interval effect taking over after mount.

Why this over null-until-mounted (the HO 376 shuffle pattern sitting eight lines below at `:726`): it is hydration-safe by construction on **both** render modes — dynamic routes get a fresh per-request value, static ones get a build-time value that is stale but *consistent* — and it avoids a first-paint flash where arrows render and then vanish. The trade is that a cached page's first paint can show a stale-by-one-tick state, corrected on mount. Name that trade in the commit comment.

If M2/M3 turn up something that makes prop-drilling wrong here, say so and take null-until-mounted instead with the reason stated. Don't split the difference.

Apply the same shape to any sibling M2 proved structural. Leave the text-only ones alone — they produce `args[]=text`, which is not this bug.

### Falsification — two-sided, the HO 580 shape

A guard that always bails passes a bail-only test. Prove both directions with the harness:

- **RED at HEAD** (M1): the recorded pre-fix fire, with arrow counts.
- **GREEN after the fix**: same route, same skew, no hydration failure, and the arrow count consistent between SSR and post-hydration.
- **CONTROL**: control+0 still renders the correct live state after mount (the fix must not freeze the tape at the server's clock — the 60s interval still has to take over, or you've traded a hydration bug for a dead staleness indicator).

The third is the one that's easy to skip and is the whole reason prop-drilling has a risk.

### Sequencing, and why cause #1 ships first

Once #1 is fixed, any remaining prod #418 is cause #2 **by elimination**, and the crawl's per-route log line attributes it. Fixing #1 is therefore itself an instrument for #2. But the inverse trap has to be written down: after the fix, a green crawl does **not** mean #2 is fixed — it means #2 didn't fire, and an intermittent's absence reads identical to a fix.

---

## Scope guards

1. **Cause #1 only.** Cause #2 gets one bounded M4 attempt and otherwise stays open and unnamed.
2. **No blanket sweep of the 36-row inventory.** A row enters scope only when the harness fires on it and the gate is proven structural.
3. **No `suppressHydrationWarning`**, and **no new `e2e/console-noise.ts` entry**. That file's WATCH says an entry added to mask a real regression is itself a promotion trigger.
4. **No `e2e-prod.yml` change** — not the cadence, not the concurrency group, not the spec list. The harness needs a local dev server and stays local-only; if wiring it unattended is ever wanted, that's the fit-finish-into-CI decision, which is its own call.
5. **No `productionBrowserSourceMaps` flip.**
6. **Do not close the `pageErr` OPEN LOOP.** Narrow it to cause #2 and record #1 as closed within it. The criterion stays *named cause + green runs*, never green alone.
7. **Commits never mixed:** harness · fix · docs are three commits, docs last and separate. Route the docs commit through a review ref (append-only roadmap block).

---

## Docs owed (HO 591 sweep, not here)

- **Backlog `pageErr` OPEN LOOP:** "the hydration text-content mismatch variant" → **structural**; "single cause" → **≥2 causes, one named and fixed, one unnamed**; the close criterion narrowed to cause #2.
- **Roadmap:** a new append-only block covering 588–590. Never retro-edit the HO 574 block — its "single cause" reading was correct on its evidence and wrong on a fact nobody had (the prod message carries no diff). Record it as superseded in the new block, with the sample-attribution correction from §0 stated so a future reader doesn't mis-credit it to HO 574's runs.
- **H4 recorded as raised-and-falsified**, with the render-mode table as the evidence.
- **Oddities:** two entries. (1) *In a minified React build every structural hydration mismatch emits a byte-identical string — message identity is not cause identity, and an instrument that can only read the message has a ceiling no truncation budget can raise.* (2) *A client component that derives a value from `Date.now()` at render time and uses it to gate whether a node exists is a hydration bug whose firing depends on the page HTML and the hydration clock straddling a threshold — so it is intermittent, invisible locally, and grows its route set with every surface that adds a now-gated node.* Cross-reference the HO 489/490 `nowMs` arc as the existing fix pattern.
- **SKILL:** any line repeating the text-content or single-cause claim; plus the harness's existence and the fact that it is manual/local-only.
