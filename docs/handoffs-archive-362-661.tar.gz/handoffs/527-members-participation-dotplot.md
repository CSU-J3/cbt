# HO 527 — /members participation dotplot (119th missed-rate)

The population cut of the participation arc (522–525). B1/B2 shipped the member-**hub** display (119th rate + chamber median + career rate); this is the `/members` population shape, the exact progression the ideology arc took (member-hub axis 421 → `/members` dotplot 425). It is the participation twin of `IdeologyStrip` — build it as that component's sibling.

**Code build.** One new query (`getParticipationStrip`), one new client component (`ParticipationStrip`), a placement edit on `app/members/page.tsx`, and additive CSS. Diff shown before commit; **no doc edits, no SKILL** (roadmap/backlog/oddities/SKILL fold into a doc sweep after this lands). **Member depth is already 100** — this rides as an enabling surface, no bar move (the HO 425 dotplot precedent, which also held the bar).

**This is a build with a STEP-0 shape gate, not a pure build.** Ideology's domain is a fixed known ±1; a missed-rate domain is not, and the x-axis cap + bin width depend on a distribution we can't see from here. So STEP 0 is a read-only distribution report — run it, paste the numbers, and **STOP for the domain lock** before writing any component. Everything after STEP 0 is spec'd; only the two numeric constants (`CAP`, `BINW`) are held pending that report.

## Baked from the code (facts — do not re-derive)

- **The template is `components/IdeologyStrip.tsx`.** Read it first. It's a `"use client"` hand-rolled SVG Wilkinson dotplot (~180px), NOT the divs+CSS rail, NOT the shared `components/svg/` scaffold (IdeologyStrip is the deliberate scaffold holdout; this sibling is too — the coordinate space is rate × stack height). Reuse its viewBox geometry (`W/H/L/R/T/B/IW/IH/BASE`), its bin→stack→place loop, its hover-tip clamp math, its `median()` import from `@/lib/median`, its hit-target-on-top pattern, and its click-through (`router.push('/members/' + bioguideId)`). Change only what the metric change forces (below).

- **Metric spine = the 119th missed-rate, defined IDENTICALLY to `getChamberParticipationContext` (lib/queries.ts ~6866).** Per current member: `SUM(mv.position = 'not_voting') / COUNT(*)` over `member_votes` joined to `members`, `is_current = 1`, `GROUP BY mv.bioguide_id`, `HAVING total >= PARTICIPATION_FLOOR`. **Reuse the exported `PARTICIPATION_FLOOR` (= 50) constant** — same population, so the strip's client-computed chamber median echoes B1's hub-context number to displayed precision. This is the IdeologyStrip↔band coherence rule applied here: same population + same `median()` = matching ticks by construction. (The career variant — `member_career_votes.career_missed_pct` — is NOT this v1; it's a banked follow-on because its NULL-coverage set, Voteview-missing members drop out, is a different population than the 119th floored set and can't be a client toggle over the same rows.)

- **Delegate carve-out — the load-bearing detail (banked constraint, HO 523/525).** Non-voting delegates are ineligible on final-passage votes, so their `not_voting` is structural, not absenteeism; uncarved they plot as extreme high-missers and blow out the domain. **There is no delegate flag in `members`** — the reliable predicate is the territorial `state` set: `m.chamber = 'house' AND m.state IN ('DC','AS','GU','MP','PR','VI')`. That is exactly the ~6 non-voting House members (5 delegates + the PR resident commissioner); no senators, no other House members share those codes. STEP 0 confirms this set == the non-voters and that they ARE the high outliers. Carve them out of **both the plotted cloud and the median**, and **disclose the excluded count** in the footer (the LDA/nominations disclose-the-exclusion posture; never a silent drop). A member's own hub rate keeps no carve-out (B1/B2) — the carve-out is a *population/rank-surface* rule, and this is the first surface it binds.

- **Query regime:** small-table population read (~537 groups), no `INDEXED BY` / no new index — the `getIdeologyStrip` / polarization-band regime, not the fat-`bills` one. `unstable_cache`, **tag `votes`, `revalidate: 3600`** (match `getChamberParticipationContext` — it refreshes with the votes sync, not the daily member-ideology cadence).

- **Placement idiom (mirror `stripDots` exactly, page.tsx ~137 & ~421):** the strip is fed a pre-filtered array; the page filters the full population by the live chamber toggle (`chamber ? dots.filter(d => d.chamber === chamber) : dots`), so party/state/sort/search can't touch it. Add `getParticipationStrip()` to the same `Promise.all`, derive `partDots` the same way, render `<ParticipationStrip dots={partDots} />` directly after `<IdeologyStrip dots={stripDots} />`.

## STEP 0 — distribution report (read-only, GATE — stop and paste)

Write a throwaway script (stays **untracked** — the 525 cross-check precedent, no committed diagnostic). Over the floored current population (`is_current = 1`, `HAVING total >= 50`, metric = `not_voting/total`), report, **split into non-delegate vs delegate** using the territorial-state predicate above:

1. **Non-delegate missed-rate quantiles, per chamber and pooled:** min, median, p75, p90, p99, max (as %). This sets `CAP`.
2. **The delegate rows explicitly:** name, state, chamber, missed-rate — confirm they exist, that the 6-code set catches them all, and that their rates sit above the non-delegate p99 (i.e. the carve-out is doing real work, not cosmetic).
3. **Counts:** non-delegate N per chamber, delegate N, and anyone floored out (< 50 votes) so we know the plotted-vs-roster gap.

Then STOP. I will lock **`CAP`** (a round number just above the non-delegate max — e.g. max 22% → CAP 25) and **`BINW`** (a round rate giving ~0.5–1pp bins across `0..CAP`), and confirm the shape justifies the dotplot before you write the component. If the non-delegate distribution is a degenerate spike at 0 with two outliers, we reconsider the viz here rather than after building it.

## §1 — Query (`lib/queries.ts`)

Add a sibling to `getIdeologyStrip`:

```ts
export type ParticipationDot = {
  bioguideId: string;
  name: string;
  party: string | null;   // normalized 'R' | 'D' | 'I'
  chamber: string;         // 'house' | 'senate'
  missedPct: number;       // 0–100, not_voting/total * 100
  isDelegate: boolean;     // house + territorial state
};

export const getParticipationStrip = unstable_cache(
  async (): Promise<ParticipationDot[]> => { /* … */ },
  ["getParticipationStrip"],
  { revalidate: 3600, tags: ["votes"] },
);
```

- SQL: the `getChamberParticipationContext` aggregate, but SELECT the per-member row (not just the median) plus `m.name`, `m.party`, `m.chamber`, and a delegate flag: `CASE WHEN m.chamber = 'house' AND m.state IN ('DC','AS','GU','MP','PR','VI') THEN 1 ELSE 0 END AS is_delegate`. Same `JOIN` / `WHERE is_current = 1` / `GROUP BY mv.bioguide_id` / `HAVING total >= PARTICIPATION_FLOOR`.
- Compute `missedPct = nv / total * 100` in JS (guard `total > 0`, already enforced by the floor). Map `is_delegate` (0/1) → boolean.
- No delegate exclusion *here* — the query returns everyone floored; the component excludes delegates from the cloud/median but needs the flag + count to disclose them.

## §2 — Component (`components/ParticipationStrip.tsx`)

A `"use client"` sibling of `IdeologyStrip`. Copy its skeleton; the deltas:

- **x-mapping:** `xs(v) = L + (v / CAP) * IW` where `v` is `missedPct` (0..CAP). No 2% inset (full-width cloud, like IdeologyStrip). Values clamp to `CAP` defensively.
- **Bins:** Wilkinson stack on `BINW` across `0..CAP` (`nbins = Math.round(CAP / BINW)`, `k = clamp(floor(v / BINW))`), same stacking + `step`/`rDot` math.
- **Delegate carve-out:** `const plotted = dots.filter(d => !d.isDelegate)` — bin, place, and median over `plotted` only. `const delegateN = dots.length - plotted.length`.
- **Dots colored by PARTY** (reuse IdeologyStrip's `PARTY_FILL`/`fillFor`) — so party clustering in the high-miss tail is visible (roadmap lens #4, "does noise correlate with party"). Draw order can stay R→I→D or drop the party ordering; party fill is what matters.
- **Median ticks = CHAMBER split, NOT party.** Compute `houseMed`/`senMed` via `median()` over `plotted` filtered by chamber. Render a tick per chamber that has dots, labeled **HSE / SEN** (not D/R), colored **neutral — `var(--accent-amber)` or `var(--text-primary)`, deliberately not party colors** so it never reads as an ideology-style D/R tick. In single-chamber mode only that chamber's members are present (page pre-filters), so only its tick shows; in ALL mode both. This is the participation analog of ideology's D/R ticks — chamber is the meaningful split here (House votes far more often than the Senate, so their baselines differ).
- **No "empty center" annotation** — participation is unimodal-skewed, there's no bimodal gap. Drop that `<text>`. No special tail callout in v1; the cloud + ticks + hover carry it.
- **x-axis ticks:** `0, CAP/4, CAP/2, 3·CAP/4, CAP`, labeled as `%`. End labels **FEWER MISSED** (left) / **MORE MISSED** (right), mirroring LIBERAL/CONSERVATIVE.
- **Hover tip:** `name` line, then `{missedPct.toFixed(1)}% missed` (party-colored value) `· → hub`. Same clamp geometry.
- **Header:** title **PARTICIPATION**, desc `every current member's 119th missed-vote rate · chamber medians ticked`, and a `how it's scored →` tooltip: missed rate = share of the member's 119th roll calls recorded not-voting; non-voting delegates excluded (structurally ineligible on final passage).
- **Footer:** `{plotted.length} members` `· HSE med {houseMed}%` `· SEN med {senMed}%` (each shown only when present) `· {delegateN} delegates excluded (non-voting)` `· HOUSE/SENATE toggle below rescopes this`. Percentages to one decimal.

## §3 — Placement (`app/members/page.tsx`)

- Import `getParticipationStrip` + `ParticipationDot`; import `ParticipationStrip`.
- Add `getParticipationStrip()` to the existing `Promise.all` (beside `getIdeologyStrip()`), destructure `participationDots`.
- `const partDots = chamber ? participationDots.filter(d => d.chamber === chamber) : participationDots;` (mirror `stripDots`).
- Render `<ParticipationStrip dots={partDots} />` **directly after** `<IdeologyStrip dots={stripDots} />`, with a short comment in the HO 425 style.
- **Placement call (the one fork you can veto):** ship it **open**, below IdeologyStrip. Discoverability of a new analytical surface beats compactness, and it sits right under the strip it rescopes with. If the stacked height (two ~180px strips + the collapsed PolarizationOverTime) buries the roster too much on your screen, collapsing it behind a `<details>` (the PolarizationOverTime precedent) is the lever — flag it and I'll respec. Don't collapse it preemptively.

## §4 — CSS (`app/globals.css`)

New `.part-strip-*` scope mirroring `.ideo-strip-*` (head / title / desc / spacer / how / svg / foot / foot-hint). **Additive under the new prefix — do not touch or reuse the `.ideo-strip-*` rules**, so `IdeologyStrip` stays byte-identical. Duplicated structural rules are fine here; shared coupling of two components to one class set is the riding-regression risk we avoid (the containment rule that held through 486/492/496/507/515/517 — confirm the globals.css diff is purely additive).

## Guardrails + deliverable

- **STEP 0 first** — paste the distribution, STOP for the `CAP`/`BINW` lock. Do not write the component before it.
- Read `/mnt/skills/public/frontend-design/SKILL.md` before the component + CSS.
- **Diff shown before commit.** Explicit pathspec only (`lib/queries.ts` + `components/ParticipationStrip.tsx` + `app/members/page.tsx` + `app/globals.css`); confirm the untracked STEP-0 script stays untracked and concurrent-session files are untouched. Ancestry eyeball (`git log --oneline @{u}..HEAD` — one commit riding, clean fast-forward), fast-forward only. **One code commit.**
- After it lands: `verify:deploy`, then confirm live — the strip renders under the ideology strip, the HSE/SEN median ticks land where the hub-context medians say they should, the chamber toggle rescopes it (SEN-only shows one tick, ALL shows both), a delegate does NOT appear in the cloud and the footer discloses the excluded count, and hover → click reaches a member hub. (Headless prod is BotID-blocked on `/members`' tape-bearing chrome — verify via SHA + class presence + local CDP, the standing workaround.)

read docs/handoffs/527-members-participation-dotplot.md and follow it
