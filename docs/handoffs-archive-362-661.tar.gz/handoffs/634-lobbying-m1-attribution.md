# HO 634 — the `/lobbying` M1 attribution: two rows with no owner

HEAD `1e6435a`. Pointer runs through HO 633. **Next free is 634.**

Closes the WATCH at `docs/backlog.md:258`. The permanent-residue register carries `/lobbying` 1 (a column header); a crawl at HO 633 read 3, at 215 / 179 / 129px. The 215 is the register's line. The 179 and 129 are `div.mc-row.lob-filing-row` data rows the register does not cover, and until they have an owner the closing identity is open: site M1 reads **13 with up to 2 unexplained, 15 if they attribute**.

This is measure-only through §4. Nothing commits before the ruling.

---

## Step 0 — three facts established off the repo. Verify, do not re-derive.

**1. No code reached this row after HO 620.** `git log 62c25e4..HEAD -- app/lobbying components/FilingRow.tsx` returns four commits and none of them is lobbying work: three absence-band commits and one `searchMembers` index hint, all in `lib/queries.ts`. `git diff 62c25e4..HEAD -- app/globals.css` changes no `.lob-*` rule and no `.mc-row` rule. The grid that governs this row landed at **HO 614, `13203eb`**, and has not been touched since:

```css
.lob-filing-row {
  grid-template-columns: 16px 52px minmax(0, 340px) auto auto;
  justify-content: start;
}
```

So the register's 1 (priced HO 615, re-affirmed 619, read again in the terminal v4 crawl at 620) and the crawl's 3 at 633 are **four readings of the same CSS**.

**2. Both candidate windows are looking for the wrong kind of object.** The owner's window (HO 597–598) and the reviewer's bound (after HO 620) both assume a commit. No commit in either window reaches this row. The WATCH asks for the two to be reconciled rather than assumed; the reconciliation is that neither contains the change, because the change is not in the code. Confirm that yourself with the two greps above before accepting it.

**3. The 620 baseline log is not in the repo, and the register says it is.** The register entry cites `docs/handoffs/620-artifacts/terminal-crawl-v4.log` as repo-tracked. `git log --all --diff-filter=A -- "docs/handoffs/620-artifacts/*"` returns nothing, and `docs/handoffs/` has been gitignored since HO 604. The per-route detail behind "620 read 1" cannot be re-read from the repo. **Do not plan around that file.** §2 gets the same information a better way, and §5 corrects the claim.

---

## §1 — The mechanism, stated as a prediction to falsify

The 340px cap was derived from data, and the derivation is on the record in the CSS comment above the rule (`app/globals.css` ~6455): rc ink runs **min 239 · median 379 · max 561**; cap = threshold (120) + min-ink (239) − column-gap (14) = 345, taken at **340**; "a row at the narrowest ink gaps 115px."

The rc column is a fixed 340px track and `justify-content: start` collects leftover width *after* the last column, which is the trailing gap C1 does not count. So the chips anchor at 340 plus gaps no matter how short the name is, and the gap between rc ink and the first chip is:

```
gap ≈ 340 − rc_ink + column_gap
```

Which predicts, for the two rows in the WATCH:

| observed gap | implied rc ink |
|---|---|
| 179px | ≈ 173px |
| 129px | ≈ 223px |

**Both below the 239px minimum the cap was sized against.** If that holds, the attribution is: the cap is a constant fitted to one sample's *minimum*, the corpus has since produced filings whose registrant→client ink runs shorter than anything in that sample, and every pixel below 239 goes straight into the gap. No commit, no regression. The data crossed under a constant.

**Falsify it, don't confirm it.** Measure rc ink on the two over-threshold rows and check the arithmetic closes. If either row's ink is ≥ 239, or the arithmetic misses by more than a few px, this hypothesis is dead and §2 decides on its own. While you're in there: `.mc-row` sets `column-gap: 12px` and the derivation says 14. Reconcile or note it. A 2px discrepancy inside a formula whose output was "115px, just under 120" is worth one look.

---

## §2 — The control: same state, two builds

Do not wait for another day's data and do not argue from the record. Crawl `/lobbying` at **`62c25e4`** (HO 620's terminal commit) and at **HEAD**, against the same live DB, minutes apart.

- 620-build reads **3** → the change is DATA, build held constant. Attributed, and §1 explains the mechanism.
- 620-build reads **1** → the change is CODE, data held constant, §1 is wrong, and the two DOMs are then the diff that finds it.

This is the `lda-volume-falsify-597.ts` pattern: run the old and the new against the *same live state* rather than comparing across time, because the corpus grows daily. Same reasoning, layout instead of SQL.

Era wall is satisfied without special handling: instrument v4 landed at `62c25e4` itself, so both readings are v4.

---

## §3 — The distribution, because one reading is a sample

Whatever §1 and §2 return, this count is a function of the 13 filings that happened to be on page 1. Reading it once more yields one more sample. Get the distribution in one session instead:

Crawl `/lobbying?page=2` through `page=5` plus two `?issue=` scoped views on HEAD. Same component, same CSS, six different filing sets. Report M1 count and per-row gap for each, off `m1.rows`.

Then report the **rc ink distribution over all rendered rows** (min / median / max, n) against HO 614's 239 / 379 / 561. That comparison is the number that decides §4, and it is the number the cap was fitted to.

- Count varies across pages → **a fixed px price for this class is not available**, and §4a has to say so rather than pick a representative number.
- Count flat at 2 everywhere → the class has a stable price and §4a is straightforward.

---

## §4 — Three dispositions, costed. Then HALT. Do not pick one.

The arc's permitted forms, with what each actually costs here.

**(a) Accepted residue, priced as a bounded class.** Add a register line for `lob-filing-row`. If §3 shows a distribution, that line cannot be a px constant; it would read as class + bound + the statistic behind the bound. That **amends the register's admission standard** (px, class, price, arithmetic restated), and the fixed-px form is exactly what makes the closing identity checkable arithmetic rather than a judgment. Amending it is the owner's call.

**(b) Worked to zero by lowering the cap.** `gap ≤ 120` for ink ≥ X requires `cap ≤ X + 120 − column_gap`. The cell wraps rather than truncates, which was HO 614's whole point, so the cost is wrapped rows and row height, not clipped names. Run the curve at 340 / 300 / 280 / 260 against current data: cap → (rows wrapped, rows over), plus the row-height and page-height delta.

State the coupling in the report, because it is easy to miss: SKILL records that the rail bound, `PAGE_SIZE=13` and `.lob-sec-scroll` are tuned against each other. A higher wrap rate moves feed height and can push the section headers below the fold, which is the HO 493 tuning this would disturb. (b) costs no truncation and is still not free.

**(c) Worked to zero by dropping the column alignment.** Let the chips pack against the text per row instead of aligning as columns. That kills the gap at its source on every row **and retires the register's `/lobbying` 1 with it**, since the header's 215px exists precisely because a label cannot fill a data-sized column. Cost: the column header stops labelling columns, so it goes or becomes decoration, and the row's scan behaviour changes. That is a ruling off a rendered surface, Corey's, not Code's.

**The HALT prints:** §1's arithmetic (held or died), §2's control result, §3's distribution and ink comparison, and (a)/(b)/(c) each with its measured cost. Nothing commits before the ruling.

---

## §5 — The one correction that ships regardless

The register's citation of `620-artifacts/terminal-crawl-v4.log` as repo-tracked is false; the path was never committed. Correct the backlog line to say the log is local-only and that the 620 reading is regenerable by crawling `62c25e4`, which is what §2 does anyway. A record naming a file nobody can open is worse than one naming none, because the next reader plans around it.

If §1 holds, it is also a third member of a named class and worth an oddities entry at the sweep. HO 494: measured slack is a property of that day's feed, not a constant. HO 631: illustrative mock data never sets a numeric expectation. HO 633 sharpened it to: a mock or specimen is evidence about itself. The sharpening this one offers is narrower and sharper than any of them — **a constant derived from a measured *minimum* is the least stable kind of fitted constant, because a min-statistic over a growing corpus can only move one way.** Write it only if the measurement supports it.

---

## Guards

1. No commit before the HALT ruling. §1 through §3 are measure-only. §5's doc correction rides the sweep, not this pass.
2. **Fixture legs green first on every build crawled**, 18 of 18 exact, before any zero or any moved number is trusted.
3. v4 numbers only; label the era on every table. Both builds here are v4-era, so say so rather than leaving it inferred.
4. Read `m1.rows`, never the summary count. HO 633's precedent: the decomposition is the finding, the count is not.
5. Local production build (`next start`), never `next dev`. Prod `/lobbying` is BotID-blocked to headless (backlog :127) — do not burn a cycle rediscovering that wall.
6. `.mc-row` is shared with `/members` and `/bill/[id]`'s `BillLobbying`. Every rule stays `.lob-*`-scoped per HO 486/492, and if anything ships, `/members` byte-identity is the gate and is verified by render diff, not asserted.
7. Explicit pathspec staging. `npm run typecheck` before any push.

## Ship report

The four things this WATCH needs to close, plus one:

- The attributed cause, with the evidence that attributes it.
- The class's price, or the reason it cannot have a constant one.
- The disposition ruling and what it cost.
- Site M1 arithmetic restated, cited and not subtracted.
- Whether the HO 597–598 window and the after-620 bound are both retired, stated as retired. The WATCH asks for them to be reconciled, and "neither applies" is a reconciliation only if it is written down as one.
