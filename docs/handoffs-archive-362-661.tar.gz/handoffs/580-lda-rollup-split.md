# HO 580 — Stop the LDA rollup and sync competing for one budget

Confirm the number from `docs/roadmap.md`: the pointer runs through **HO 577**, HO 578 was its sweep, HO 579 shipped the FMP plan boundary. So this should be **580**, and **HO 581 sweeps 579 + 580 together** (the multi-arc pattern from 566–568 and 576–577).

Two changes in one route's neighbourhood. Neither is urgent — the LDA key is in and the cron is no longer 504ing — so this is a correctness pass, not a fire.

---

## The finding

`app/api/cron/lda/route.ts` runs the sync, then the `/lobbying` rollup precompute, inside one 300s function. The constants:

- `LDA_BUDGET_MS = 280_000` — stop starting sync pages
- `ROUTE_CEILING_MS = 300_000`
- `ROLLUP_RESERVE_MS = 220_000` — don't *start* the rollup with less than this left

The gate at `:104-105` is `msLeft = 300_000 - elapsed`, and the rollup needs `msLeft >= 220_000`. So **the sync must finish within 80 seconds or the rollup never starts.**

Measured against reality: the last authenticated run made **259 `lda.gov` calls at ~1s each** (Vercel's External APIs panel: 945ms average, P75 1.05s, 0% errors). That's ~259s of network wait, so the rollup was skipped by more than three times the margin.

**The inversion is the point.** The rollup runs only when the sync had nothing to do, and is starved precisely when new filings arrive. The comment at `:45-48` accepts the blob being "a day stale"; the actual behaviour is stale indefinitely until someone runs `npm run lda:rollup` by hand — which is how it was last refreshed (114,048ms, 129,105 filings / 277,703 activities).

Neither component is wrong. They just can't both fit in a window only one of them can win.

---

## Change 1 — the rollup gets its own cron

The rollup needs **no LDA API access at all**. It reads `lda_*` tables and writes the blob. So it doesn't belong in the tail of a budget spent on network round-trips.

- **New route** for the rollup, mirroring `scripts/rollup-lda.ts` (which already runs the same `computeLdaRollup` path through `uncappedLdaClient`). Reuse `lib/lda-rollup`'s exports; don't reimplement the computation.
- It must `revalidateTag("lda")` — that's the thing `scripts/rollup-lda.ts` can't do from a CLI (its header notes the Next-runtime-only constraint), and it's why the manual path needs a follow-up curl. A route can, so wire it.
- **New `vercel.json` entry.** The sync is `0 8 * * *`. Pick a slot ≥1h later that doesn't collide — `0 9` is taken by nominations, and the weekday markets `fmp` pass runs `0,30 13-21 * * 1-5`. `0 10 * * *` looks free; verify against the file rather than trusting this.
- **Remove the rollup block from the sync route** (`:88-136`) along with `ROLLUP_RESERVE_MS`. The sync then owns its full 280s for pages, which is what it actually needs.
- **Preserve the failure property.** The comment at `:49-51` records that a SIGKILL mid-compute leaves the prior blob intact, never a half-written rollup. Confirm that still holds when the compute owns the whole function — it should, since the writes land at the end, but check rather than assume.
- Keep `scripts/rollup-lda.ts` as the manual entry point. It's the backfill escape hatch and this doesn't replace it.

## Change 2 — the retry sleep must respect the deadline

`lib/lda-sync.ts:411` checks `deadlineMs` **before** calling `fetchPage` at `:416`. The 429 retry sleep happens **inside** `fetchPage`. So a check that passes at 279s followed by a `retry-after=39` sleep lands at 318s, past the 300s ceiling, and the function is killed instead of exiting cleanly with `deadlineHit`.

That's what produced the 504 — the observed log line was `[lda] 429 throttled — waiting 39s (retry-after=39)`.

The fix: plumb the deadline into the retry path so a sleep that would cross it doesn't happen. If `Date.now() + sleepMs >= deadlineMs`, stop rather than sleep.

**The critical detail — how it exits.** This must surface as **`deadlineHit`**, not as a `fetchError`. The two go to different places: `deadlineHit` means resume from the DB frontier next run, while a fetch error feeds the error accounting and the cursor logic. Getting this backwards converts a clean pause into a recorded failure, which is the stamp-on-exit family this repo has been bitten by before. Trace where each lands before writing it.

Backfill mode has no deadline (`:308`), so this path must be inert there — no behaviour change to `npm run sync:lda -- --backfill`.

---

## Falsification

**Change 2 is the one that needs it, and it needs it badly.** The LDA key is now in Vercel and the last run showed **0% error rate across 259 calls**, so 429s no longer occur in normal operation. The branch this change adds is therefore untriggered from the moment it lands — the exact state where working and structurally-dead emit identical green.

Scratch only, on current HEAD: force a synthetic 429 with a large `retry-after` against a near-expired `deadlineMs`, and confirm the run **bails without sleeping** and reports `deadlineHit=true` with the fetch-error count unchanged. Revert, `git status` clean, commit nothing from it. If it can't be demonstrated locally, it goes in the HO 581 sweep as **UNPROVEN in a WATCH**, not as protection.

Change 1 needs no scratch — the new cron either fires or it doesn't.

## Scope guards

1. Don't change `LDA_BUDGET_MS`. 280s is right once the rollup isn't competing for it.
2. Don't touch the rollup computation in `lib/lda-rollup.ts`. This moves where it runs, not what it does.
3. Don't touch the sync's page loop beyond the retry-sleep plumbing.
4. No schema change, no migration.
5. Keep `scripts/rollup-lda.ts` working.
6. No docs, no `SKILL.md` — HO 581 sweeps 579 and 580 together.
7. Explicit pathspec staging. Never `git add .`.

## Verification

- `npm run typecheck` clean; `npm run build` clean.
- **The landing instrument for Change 1:** `[lda] rollup skipped (only Nms left…)` disappears from the sync route's log, and the new route logs `rollup ok in Nms` on its own schedule. Then the real one — the blob's freshness advances daily **without anyone running `lda:rollup` by hand**. That reads differently if the work never happened.
- Trigger both routes manually with the Bearer `CRON_SECRET` rather than waiting for the schedule, and confirm the sync's run no longer carries rollup timing at all.
- Confirm `revalidateTag("lda")` fires from the new route — the surface should reflect the new blob without the manual `/api/revalidate` curl.
- Change 2: the falsification transcript above.
- Watch one natural sync run afterwards. `deadlineHit=true` with a large `pagesFetched` is the healthy outcome, not a failure; a 504 means something still overruns.
- Ship: `git push` (fast-forward, ancestry eyeball first), `npm run verify:deploy` until served SHA === HEAD.

## Ship report

- SHA, files, and the cron slot you chose with the collision check.
- Confirmation the sync route no longer references the rollup and `ROLLUP_RESERVE_MS` is gone.
- Change 2: where `deadlineHit` and `fetchError` each land, and why your exit path is the former.
- The falsification transcript, or **UNPROVEN** in those words.
- The first natural run of each route after the deploy.
- Anything else found — file it, don't fix it.
