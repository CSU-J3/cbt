# HO 530 — Senate amendment vote outcomes on `/bill/[id]` (query-only)

The build on the HO 529 verdict. The probe retired the backlog's `/actions`-walk-for-everything premise: **Senate amendment votes join free** through a `votes.question` parse (114 SAMDT, 100% on tracked bills, `member_votes` present), so the "how did the chamber vote on this amendment" surface is **query-only, zero backfill / schema / sync / API** for the Senate — which is the bulk of the real signal (vote-a-ramas; the House barely records amendment votes — HO 461 / 529 §D). **This HO ships the Senate half only.** The House half (GO-WALK — a bounded `/actions` linkage backfill, 529 §C) and the full per-member roll-call drill are banked (below).

**Code build.** One new query (`getBillAmendmentVotes`), a render enhancement to `AmendmentRow` + `BillAmendments`, threaded into the `/bill/[id]` `Promise.all`. No cost gate — 529 already did the feasibility work and the set is tiny (~114 rows corpus-wide, `member_votes` bounded per vote). Diff shown before commit; **no doc edits, no SKILL** (its own doc sweep after, folding the HO 529 probe findings + this surface).

## Baked from HO 529 (facts — do not re-derive or re-probe)

- **The join key is the `votes.question` text, NOT `amendment_designation`.** `votes.amendment_designation` is **dead for amendments** — it only ever holds nomination/treaty designations (the syncs tag amendment votes to the underlying bill or to nothing). Do **not** use it.
- **Senate parse:** a Senate amendment vote's `question` reads `On the Amendment S.Amdt. 14 to S.Amdt. 8 to S. 5` — the **voted** amendment's number is the first one. Regex `^On the Amendment S\.Amdt\. (\d+)\b` → `14`. Match to `amendments WHERE amendment_type='SAMDT' AND amendment_number=14 AND congress=<vote.congress>`. Within a congress the number is unique, so `(congress, amendment_number)` is an unambiguous key — the bill scope comes from `amendments.amended_bill_id`, not the question's trailing `to S. 5`.
- **The tally is on the `votes` row directly** — `yea_count` / `nay_count` / `present_count` / `not_voting_count` + `result`. `member_votes` is only needed for the **party split** (D/R yea-nay), a bounded per-vote aggregate (~100 rows/vote). Coverage: 99–100 members per Senate vote, present.
- **`votes.id` is a TEXT composite** (e.g. `senate-119-1-3`), not an integer — key/join accordingly.
- **An amendment can map to MULTIPLE vote rows** (3 corpus-wide → 2 votes each: a motion-to-table + the substantive vote, or a re-vote). The surface must handle a **list**, not a scalar (render rule below).
- **House is out of scope** — House amendment votes read a generic `On Agreeing to the Amendment` with no number, only `bill_id`, so a text parse can't disambiguate which amendment. That's the banked HO 531 `/actions` linkage walk (GO-WALK, 100% of `recordedVotes.rollNumber` resolve to existing `votes` rows — no member-vote backfill, just a persisted amendment↔vote.id link). Do not attempt House here.

## §1 — Query (`lib/queries.ts`)

Add `getBillAmendmentVotes(billId)` — a **separate** cached query, NOT a widening of `getBillAmendments` (which stays byte-identical; single-consumer, but the parse can't live in its SQL and the separable-addition pattern keeps the existing section zero-risk — the HO 496/512 "new sibling, don't reshape the shared query" discipline). Returns a lookup keyed by amendment id:

```ts
export type AmendmentVote = {
  voteId: string;              // votes.id, e.g. "senate-119-1-3"
  result: string | null;       // votes.result (authoritative outcome)
  yea: number; nay: number; present: number; notVoting: number;
  date: string | null;         // votes.vote_date
  party: { D: { yea: number; nay: number }; R: { yea: number; nay: number }; I: { yea: number; nay: number } };
};
// Map<amendmentId, AmendmentVote[]> — a LIST per amendment (usually 1, rarely 2), most-recent first.
```

Steps inside the one cached function (`try/catch → null`, the `getBillAmendments` discipline — it rides the same page `Promise.all`, a throw would 500 the page):
1. Pull this bill's SAMDT amendments: `SELECT id, amendment_number, congress FROM amendments WHERE amended_bill_id=? AND amendment_type='SAMDT'`. Empty → return an empty map (section renders amendments with no vote lines — not null; null is `getBillAmendments`'s job).
2. Pull the Senate amendment-vote candidates for the congress(es) present: `SELECT id, congress, question, result, vote_date, yea_count, nay_count, present_count, not_voting_count FROM votes WHERE chamber='senate' AND congress IN (…) AND question LIKE 'On the Amendment S.Amdt.%'`. This is ~114 rows corpus-wide — a tiny scan, no `INDEXED BY` needed. Parse each `question` with the regex → `amendment_number`; keep only rows whose `(congress, amendment_number)` matches a bill amendment from step 1.
3. Party split for the matched `vote_id`s: `SELECT mv.vote_id, m.party, mv.position, COUNT(*) c FROM member_votes mv JOIN members m ON m.bioguide_id=mv.bioguide_id WHERE mv.vote_id IN (…) GROUP BY mv.vote_id, m.party, mv.position`. Normalize party via `normalizePartyVariant`; bucket into D/R/I × yea/nay (ignore present/not_voting in the split — the tally already carries them). An empty `IN ()` guard when step 2 matched nothing.
4. Assemble `Map<amendmentId, AmendmentVote[]>`, each list sorted `vote_date DESC`.

`unstable_cache` keyed by billId, **tag `votes`** (so a votes re-sync flushes it), `revalidate: 3600`. The ~114-row scan re-runs per uncached bill page — negligible; do **not** pre-optimize into a shared index blob (bills-scale, the `getBillAmendments` regime).

## §2 — Render (`components/BillAmendments.tsx` + `AmendmentRow.tsx`)

Thread the vote map through without touching `getBillAmendments`:
- `BillAmendments({ rows, votes })` gains a `votes: Map<string, AmendmentVote[]>` prop; it passes each `AmendmentRow` its amendment's `vote = votes.get(a.id)?.[0] ?? null` (the most-recent vote — the list's head).
- `AmendmentRow({ a, vote })` gains the optional `vote`. When present, render a compact vote line under the existing purpose/disposition line:
  - **Tally + result:** e.g. `Agreed 70–25` (use `vote.result` for the verb, the counts for the numbers; en-dash between). Present/not-voting only if non-zero, dimmed.
  - **Party split:** `· D 45–2 · R 25–23` (party-colored via the shared `lib/race-colors` `partyColor`, the HO 468 helper — not a local map; `I` shown only when non-zero). This is the analytical headline — did it pass on party lines.
  - Keep it one dim mono line, `--text-muted` scaffold with party-colored split numbers; it's detail under the row, not a new box.
- **The disposition dot becomes authoritative where a vote exists:** in `BillAmendments`/`AmendmentRow`, if `vote` is present, derive the dot color from `vote.result` (agreed/adopted/passed → the agreed color; rejected/failed/"not agreed"/table-agreed → failed; else neutral) **instead of** `a.disposition` (the keyword scan of `latest_action_text`). Where no vote, `a.disposition` stays the fallback. So the dot stops guessing from action text on the subset where we have the real outcome — a coherence win (a dot reading neutral next to a "70–25 agreed" line would be incoherent). Factor the result→color mapping so it and `dispositionColor` don't drift (a small shared helper, or reuse `deriveDisposition` on the result string — the result vocab overlaps the action-text vocab enough that `deriveDisposition(vote.result)` likely just works; confirm on the sample).
- **Multi-vote edge (3 amendments):** the row shows the head (most-recent) vote. If `votes.get(a.id)!.length > 1`, append a muted ` · +N earlier` after the vote line so the procedural-then-substantive pair isn't silently hidden. Don't build a nested list in v1.
- Where `vote` is null (the vast majority — most amendments never got a floor vote), the row is **byte-identical to today** — no empty "no vote" state (that would be noise on ~99% of rows; the absence is the signal, the HO 527 disclose-vs-omit call: omit here, since "this amendment wasn't voted on" is the common case, not a fact worth stating per row).

## §3 — Page wiring (`app/bill/[id]/page.tsx`)

Add `getBillAmendmentVotes(bill.id)` to the existing `Promise.all`, pass the resulting map to `<BillAmendments rows={…} votes={…} />` inside the `RecordTabs` Amendments tab. `getBillAmendmentVotes` returning `null` (its try/catch) → pass an empty map so the section renders unchanged (the vote lines just don't appear). No change to the tab's presence logic (`getBillAmendments` still governs whether the Amendments tab exists at all).

## Guardrails + deliverable

- No STEP-0 gate — 529 settled feasibility; this is a straight build. But **verify the parse + join on real data during the build**: run the assembled `getBillAmendmentVotes` against a known vote-a-rama bill (e.g. `119-s-5` or whichever bill the 114 SAMDT votes cluster on — 529 can tell you) and confirm the tally matches the `votes` row and the party split sums to yea/nay. Report the check before the render lands.
- Read `/mnt/skills/public/frontend-design/SKILL.md` before the render edit.
- **Diff shown before commit.** Explicit pathspec (`lib/queries.ts` + `components/BillAmendments.tsx` + `components/AmendmentRow.tsx` + `app/bill/[id]/page.tsx`); confirm `getBillAmendments` is untouched and concurrent-session files are clean. Ancestry eyeball, FF only. **One code commit.** `verify:deploy` + confirm live on a vote-a-rama bill's Amendments tab (a Senate amendment shows the tally + party split; a House bill's amendments show no vote line — expected).

## Banked (record in the HO 530 doc sweep)

- **HO 531 — House amendment→vote linkage walk (GO-WALK, 529 §C).** A bounded one-time `/actions` walk over HAMDTs that carry a recorded vote (rare — 17/20 sampled never voted), storing a persisted `amendment_id ↔ vote.id` link; then the House reads the same `member_votes`-already-present path this HO uses for the Senate. A *linkage* backfill, not a member-vote backfill; needs a small persisted link (table or column) + a cron step for new HAMDT votes. Build-ready — no further probe.
- **Full per-member roll-call drill.** v1 ships the party split (the partisan *shape*); the per-member "who voted how" list (all ~100 senators, party-grouped) is the heavier drill — a v2 expand on the amendment row, or a shared roll-call surface if one lands. `member_votes` already has the data.
- **`/amendments` aggregate "voted" cut.** A filter/column on the HO 461 aggregate for amendments that reached a recorded vote (once both chambers' links exist).

read docs/handoffs/530-senate-amendment-votes.md and follow it
