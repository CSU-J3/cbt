# HO 571 — Doc sweep for HO 570 (the cleanup arc)

Confirm the number before saving: the roadmap's latest pointer runs through **HO 568**; HO 569 was its doc sweep, HO 570 was the cleanup arc (`ef36547` … `af8378e`). So this is **571**. Take the number from `docs/roadmap.md`, not from an on-disk filename.

Docs only. No code, no CSS, no spec edits. Two commits, both through the review ref.

**Verify every quoted line and number against the live repo before editing.** This handoff was written from a read of `af8378e`, but a handoff is a claim like any other — that's the whole lesson of the arc you're documenting.

---

## Commit 1 — `docs/roadmap.md` + `docs/backlog.md` + `docs/oddities.md`

### `docs/roadmap.md` — a new "Also (HO 570)" block

**Append-only.** Add a new block at the end of the Status changelog. Do **not** retro-edit the previous block's "Also notes now run through HO 568" clause — the pointer is frozen-per-block, so the 566–568 block must still read 568 after your edit, and yours reads **570**.

The block's real content is not the deletion count. It's that **STEP 0 fired and the target list was wrong.** Lead with that. Cover:

- **The arc:** six cleanups, each deferred to "the next touch" of a file nobody was touching. One pass, six commits, clean per-concern revert boundaries.
- **STEP 0 saved two live surfaces.** The backlog named `.v2f-sponsor*` as dead. `.v2f-sponsor-last` / `--plain` are **live** in `V2FeedList.tsx:123,130`, and the `.v2f-sc-*` card block sitting immediately beside the "these are dead" comment is **live** — rendered by `BillExpandPanel.tsx:224-237`, revealed by `.bxp-sponsor:hover .v2f-sc-card` at `globals.css:4628`. A prefix sweep would have silently killed the sponsor hover card that HO 472 verified. The comment naming the dead set was itself the vector, which is why C1 rewrote it rather than just deleting under it.
- **C1 (`ef36547`)** — 20 dead selectors to zero; `app/globals.css` **9,713 → 9,269 (−444)**; braces balanced 1468/1468. Families: the HO 317 private-Expand orphans, the HO 306 `.hill-band*` family, the HO 366 `/hearings` chrome, the HO 306 list-view filter bar, the HO 367 `.mc-fbar-title`. Record the **flagged deviation**: Code also dropped `.hearings-filter-count` + `.hearings-filter-opt.is-active*` (0 consumers) beyond the handoff's literal list, and said so.
- **C2 (`29a7e66`)** — `getMembersRankedCount` + 8 `lib/hearings` exports (+ `HEARING_TYPES_SET`). **Two kept, and the handoff was wrong about one:** `HEARING_BADGES` produces the live `HearingBadge` type, and **`weekdayOfKey` is live via `mondayOfKey` inside the module** — the planning-side grep excluded `lib/hearings.ts` from its own consumer search and missed it. Code caught it. Worth stating plainly; it's the same class of error as the glob.
- **C3 (`95cf48e`)** — the dup key was **`:96 key={id}` over `billIds`**, not the `:82` issue-code map, and not the line the backlog named. **82 filings in the scoped drill blob carry duplicate bill IDs** because the precomputed `readLdaTables` path has no `SELECT DISTINCT` while the live `hydrateFilings` path does. **State explicitly that the HO 440 distinct-filings ranking is unaffected** — `computeBillDrill` inverts `billsByUuid` through a `Set<string>` (`lda-rollup.ts:459-464`), so a bill repeated inside one filing still contributes that uuid once; the duplication only ever escaped through the `FilingSummary.billIds` display field, which is where it was fixed. Saying this in the block is the point: without it, a future reader finds "82 filings carry duplicate bill IDs" and re-opens a ranking that was never broken. Allowlist entry retired; `MissingSecret` kept.
- **C4 (`c229145`)** — `verify-deploy.ts` exit-code (live-proven, `verify:deploy` exited 0), the `sync-fec.ts:4` stale 1000/hr comment against the real 60/hr tier, the dead `getSponsorStates` probe that produced the HO 404 audit's **false SLOW: 34,656ms**.
- **C5 (`33dfb3e`)** — the repair gate moves from `stored >= pagination.count` to full enumeration (`missing.length === 0`), matching the nominations fix at `e175fd7`; `RepairResult` now carries `distinctLive` + `duplicates`. **Falsified, so record it as proven protection, not a WATCH:** a scratch fetch monkeypatch served the real 6,975-id stored set plus one duplicate with `pagination.count=6976`; the real `repairAmendments` returned `duplicates:1, complete:true` in **pass 1**, where the old gate (`6975 >= 6976`) would have looped to `maxPasses` with `complete:false`. Harness deleted, tree clean, nothing committed from it.
- **C6 (`af8378e`)** — the president predicate-wait (`waitForURL(/[?&]stage=president/)` replacing the 1.5s fixed wait; the `toContain` assertion kept; the crawl settle at `:162-163` and the sites at `:275`/`:308` untouched) plus an explicit `/races` → `/electoral` landing assertion. **Carry Code's correction:** the "HO 502 pattern" the HO 570 handoff told it to extend **does not exist in the file** — `/news` and `/president` became real routes, so there was no per-route `redirectedFrom()` assertion to copy. That claim came from the backlog.
- **The convention problem, stated as a finding.** The ledger's header rule says a backlog line's mechanism is a claim, notes two wrong in three HOs, and says a third makes it a convention problem. This arc produced **two more genuine wrong-mechanism claims** (the `.v2f-sponsor*` glob; the HO 502 redirect pattern), plus stale line numbers in three places. It's past the threshold. Record it here and act on it in the backlog (below) rather than logging another tally mark.
- **No theme-% change.** Cleanup on existing surfaces; no bar moves, no new surface, no migration, no cron change.
- **Numbering:** the **568 → 570 pointer jump skips no block** — HO 569 was the doc sweep for 566–568, and docs-only sweeps are owed no roadmap block (the HO 506/536/553/558/562/565 precedent). Close with `Docs: HO 571.` and `**Also notes now run through HO 570.**`

### `docs/backlog.md` — reconcile in place

**Tombstone to DONE** (DONE is newest-at-top; match the HO 566/567/568 entry shape directly above):

- FIT & FINISH — `FilingRow` duplicate `key` warning
- FIT & FINISH — P3 PRESIDENT stage-click fixed-wait race
- FIT & FINISH — P3 `/races` redirect coverage is implicit
- FIT & FINISH — P3 stale `getSponsorStates` probe in `cold-start-audit-332.ts`
- FIT & FINISH — P3 orphaned `.hearings-*` chrome CSS
- FIT & FINISH — P3 orphaned members-header plumbing (`.mc-fbar-title` + `getMembersRankedCount`)
- BANKED — the HO 317 follow-up **(a)** dead-CSS sweep + unused `lib/hearings` exports. **(b)** closed at HO 507, so this tombstones the item entirely rather than half of it.
- OPEN LOOPS — `scripts/verify-deploy.ts` `process.exit()` → `process.exitCode`
- OPEN LOOPS — stale `sync-fec.ts` "well under 1000/hr" comment
- OPEN LOOPS — `amendments-sync.ts` repair gate keys on `pagination.count`

One tombstone per item, one line of substance each, pointing at HO 570 and the roadmap block. Don't restate the block.

**New entries:**

- **FIT & FINISH · P3 — `#lobby-drill` dangling anchor.** `components/TopicCrosswalk.tsx:153` links to `/lobbying?issue=…#lobby-drill`, but no `id="lobby-drill"` element has existed since the HO 486 `/lobbying` redesign removed it. `e2e/fit-finish.spec.ts:460-470` soft-asserts the scroll-into-view, so the suite carries a standing red. Pre-existing and proven so (absent at `0719678`, and none of HO 570's twelve files touch `TopicCrosswalk`, the lobbying page, or the spec). Two fix options, both named by Code: re-add the id to the scoped drill container, or drop the `#lobby-drill` fragment from the crosswalk href and update the assertion. **Pick one at build time, not here.**
- **FIT & FINISH · P3 — `members-plan-277.ts:50` labels `getSponsorProductivity`**, deleted at HO 328. The sibling label at `:49` was fixed in C2; this one was correctly left out of scope. Same one-line fix on the next touch.
- **WATCH — `billIds` shape asymmetry between the precomputed and live LDA paths.** The precomputed `readLdaTables` path has no `SELECT DISTINCT`; the live `hydrateFilings` path does. The two now converge only because `FilingRow` dedupes at render. **Inert:** the HO 440 distinct-filings ranking is safe by the `Set<string>` inversion in `computeBillDrill` (say so in the entry, so nobody re-opens it). *Promote to a fix* if a second consumer of `FilingSummary.billIds` appears that doesn't dedupe, or if anything ever counts the raw array. *Instrument:* grep consumers of `billIds` outside `FilingRow`.
- **The backlog-claim convention problem — promote from a header note to a real item.** The header rule has now been tripped enough times that "check before building" is doing the work a convention should do. The decision owed is what changes: whether a stale/wrong line gets **corrected in place when a probe disproves it** (the HO 512/514/546 precedent, done ad hoc), whether entries carry a **verified-at** stamp so age is visible, or whether it stays a discipline that depends on someone holding a handoff. Frame it as a decision, not a chore — this is the same shape as the doc-duplication WATCH, which has been promoted-but-unenforced since HO 505.

**WATCH — update, honestly.** There's already a standing position on this and it must not be overwritten: `docs/oddities.md` records at the fit-finish entry that the spec **"still carries the bulk of the guards and stays manual, by design."** That was a deliberate HO 504 call, not an oversight, and `e2e-prod.yml` says in a comment that it runs `smoke.spec.ts` explicitly and never globs `e2e/`. So the update is **not** "we found an unrun suite." It's that the **cost of the manual posture is now demonstrated**: the `#lobby-drill` red sat undetected until someone ran the suite by hand during HO 570. Record the demonstrated cost, and name the three options so the decision is scoped when appetite arrives — add `fit-finish.spec.ts` to `e2e-prod.yml`, promote its stable subset into `smoke.spec.ts`, or keep it manual and stop counting its greens as coverage.

Also correct any backlog line that still describes `e2e/console-noise.ts` as carrying **five** entries or **two** open loops. It's four and one after C3.

### `docs/oddities.md` — append at the end

The file header says append new entries at the end, and the tail entries are the most recent HOs. Follow that, don't reorder. Three entries, each in the file's existing voice (title with HO + month, then one dense paragraph):

1. **A prefix glob is not a dead-code list, and a comment naming a dead set rots into a deletion instruction.** The `.v2f-sponsor*` case, with both halves: `.v2f-sponsor-last` live beside a dead `.v2f-sponsor`, and the `.v2f-sc-*` block living *inside* the comment that declared its neighbourhood dead while actually being reused by `.bxp`. The rule: sweep by enumerated selector, never by prefix; and when a comment records "these are dead, sweep later," it is a claim with a shelf life, so the sweep must rewrite it rather than delete under it. Cross-reference the existing shared-component consumer-enumeration entry.
2. **A render-layer symptom over a data-layer asymmetry — check what actually depends on the shape before assuming either direction.** The `FilingRow` dup key looked cosmetic and was, but only because `computeBillDrill` happened to invert through a `Set`. The reflex reading ("just a React warning") and the alarmed reading ("the ranking is inflated") were both wrong, and the only way to tell was to read the consumer. Note that the two paths still disagree and converge at the renderer.
3. **A guard that only runs when someone runs it.** The demonstrated cost of the deliberate manual posture — a soft-assert red survives indefinitely, because a suite nobody runs doesn't even emit the green that HO 503 warned about. Sibling to the skip-on-empty and close-criterion-that-can't-fail entries; **cross-reference them rather than restating their mechanism.**

Commit: `docs: HO 571 — sweep HO 570 (the cleanup arc: the wrong glob, the dedupe asymmetry, the manual suite)`

---

## Commit 2 — `.claude/skills/cbt/SKILL.md` (its own commit, always)

Two reconciliations, both verified present at `af8378e`:

1. **`:1912`, the console-noise line.** It reads "Two of its five entries are open loops whose fixes should delete them (`MissingSecret`, the `FilingRow` dup-key)." After C3 it's **four entries, one open loop** (`MissingSecret`). Update the counts and drop the dup-key clause; keep the "adding an entry has teeth, not housekeeping" framing, which is still right.
2. **`:1061`, the `sync:amendments --repair` description.** It still says the gate "loops until `stored >= live`" against `pagination.count`. That's what C5 changed. Rewrite it to the full-enumeration gate and mirror the ⚠️ already sitting on the nominations line at `:1063`, which documents the correct shape.

**Apply the ownership split deliberately** — this is the doc-duplication WATCH's fifth-instance rule, and it fires here. `docs/oddities.md` already **owns** the `pagination.count`-overcounts mechanism in a dedicated entry. SKILL should **name it and point**, not restate the duplicate-entry explanation. If you catch yourself writing the same sentence into both files, that's the trigger; cut SKILL's copy to a pointer before the commit lands.

Then grep SKILL for any other reference to what HO 570 deleted — `getMembersRankedCount`, the eight `lib/hearings` exports, and each swept CSS family. The planning-side check found zero hits for all of them, but re-run it rather than trusting this paragraph.

Commit: `docs(skill): HO 571 — console-noise counts + the amendments repair gate on full enumeration`

---

## Ship — review ref, then main

Both commits go through the review ref, per the SKILL-landing gate and the append-only-roadmap rule (a wrong clause in an append-only block is permanent):

1. Commit both locally, explicit pathspec staging, never `git add .`.
2. `git push origin HEAD:refs/heads/571-review`
3. **HALT.** Report the two SHAs and stop. The diff gets read from the ref before anything lands on main.
4. On approval: fast-forward main, then delete the ref.

## Scope guards

1. Docs only. If a `.ts`/`.tsx`/`.css` file appears in either diff, you've gone out of scope.
2. SKILL.md never shares a commit with the other docs.
3. The roadmap block is **append-only** — add a block, never edit a prior one's pointer or clause.
4. Reconcile backlog and SKILL **in place**; append oddities at the end.
5. No new handoff numbers assigned to anything banked here. Items take the next free number when built (the HO 418 don't-pre-number lesson).
6. Don't fix the `#lobby-drill` anchor. File it; that's a code change and this is a doc sweep.

## Verification

- **Roadmap pointer gate:** the previous block still reads "Also notes now run through HO **568**"; exactly one block reads **570**; every distinct N appears exactly once and is monotonic. If the prior block's clause changed, you retro-edited — revert it.
- `git diff --stat` on both commits shows markdown only.
- Every SHA, line number, and figure quoted in the new roadmap block resolves against the repo.
- The three retired/kept-item claims are checkable: `weekdayOfKey` and `HEARING_BADGES` still exist in `lib/hearings.ts`; `.v2f-sc-card` and `.v2f-sponsor-last` still exist in `globals.css`; `console-noise.ts` has four regexes with `MissingSecret` among them.
- No build or deploy verification owed for pure markdown. If anything non-markdown sneaks in, that's a scope failure, not a reason to run `verify:deploy`.

## Ship report

- Two SHAs, files per commit, and the ref name.
- Roadmap: confirmation the prior pointer still reads 568 and the new one reads 570.
- Backlog: the ten tombstones, the four new entries, and the WATCH update — with confirmation the fit-finish entry records the manual posture as **deliberate** and adds the demonstrated cost, rather than reframing it as an oversight.
- Oddities: the three titles as written.
- SKILL: both reconciliations, plus a line on where you applied the ownership split instead of restating oddities.
- Anything in the docs you found stale that isn't in this handoff — list it, don't fix it.
