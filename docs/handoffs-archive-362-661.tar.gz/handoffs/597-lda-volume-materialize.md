# HO 597 — the `/lobbying` VOLUME driver: a bound breach nobody can see

**Numbering.** Next from `docs/roadmap.md`'s pointer, which now reads *"Also notes now run through HO 595"* / *"Docs: HO 596."* HO 588's block remains owed when that arc ships. Confirm against the roadmap and `git log`.

**Task 0 is a record correction, then STEP 0, then HALT.** No fix code before the report.

---

## Task 0 — fix the backlog clause I caused (do this first, own commit)

`docs/backlog.md:66` currently reads: **"The 'degradation, not a crash' framing below is CONTRADICTED BY MEASUREMENT and is retained only as the record of what was believed."**

That is false, and it was my instruction, not your inference. The HO 440/448 guard is shipped and working — `lib/queries.ts:3049-3053` catches the abort, logs `[getRecentFilings] read failed — feed hidden`, and returns `{ items: [], … }` so the rollup, rail, crosswalk and firms still render. "Degradation, not a crash" is an accurate description of a guard that does exactly what it says.

Correct it to what the measurement actually establishes:

- **The cost estimate is contradicted**, not the framing: `~7s worst cold miss` → **20.005s co-located, both `lib/db.ts` attempts lost, 128,702 rows** (worst of three 90s-gapped runs; also 14.55s, 6.95s).
- **The promotion stands on the WATCH's own trigger** — it reads *"promote to a fix if VOLUME ever actually aborts."* It aborts. Promotion earned on its own terms, not by reclassifying the guard.
- Keep the original WATCH text preserved, as it already is.

Same commit, add the finding below, because it changes what this entry is about.

### The finding: the degradation is silent and nothing detects it

The guard returns an empty feed with a **200**. `smoke.spec.ts` asserts status, no failed requests, no console errors, and no `pageErr` — **an empty feed passes all four.** So 593's cross-tab showing `/lobbying` at 0 non-200s across 4,230 route-hit cells is not evidence of health; the route is structurally incapable of reporting this failure to the crawl.

The only instrument the WATCH names is the `[getRecentFilings] read failed` **server-side** `console.error`, which a browser-side crawler cannot see and which nothing currently collects. A user sorting `/lobbying` by VOLUME sees an empty list and cannot distinguish "no filings match" from "the query timed out."

That is the **fifth** instance of the pattern HO 596 documented in oddities entry 4 — an output that reads identical whether or not the work happened — and the first one that has been running in production. Cross-reference it there.

---

## STEP 0 — four measurements, read-only, then HALT

Script: `scripts/diagnostic/lda-volume-cost-597.ts`. Commit, then HALT.

### M1 — how often does this actually fire in prod?

Convert a hypothesis into a rate, using the channel 593 M3 already proved works. Grep Vercel **runtime logs** for `[getRecentFilings] read failed` over the retention window, and check `cron_runs` / runtime-error groups for a `/lobbying` signal as the WATCH suggests.

Report: fires per day, which sort/linked cache keys, and whether it clusters (cold-miss shaped) or is steady. **If it turns out to fire rarely or never in real traffic**, say so plainly — that changes the urgency, and the honest answer is more useful than a justification for work already scoped.

### M2 — the materialization shape, with the consumer analysis 595 taught

The WATCH already names the fix: a **precomputed `activity_count` column on `lda_filings`**, turning VOLUME into a ~45ms indexed walk. Price it against the alternatives rather than inheriting it:

- **Column on `lda_filings`** — tightest, single-table sort, no join at all.
- **Separate `lda_filing_activity_count` table** — the `member_participation` shape from 595.
- **`dashboard_state` blob** — almost certainly out, and say why: VOLUME's `ORDER BY ac.c DESC, f.dt_posted DESC LIMIT ? OFFSET ?` is upstream of pagination, so a blob forces the ordering and paging into JS. Same fork 595 M1 resolved.

**Measure the write cost.** 595 M3's lesson is that the write path is not free — the covering index cost 2× median / 3.4× worst on a delete-and-rebuild. `sync:lda` is a resumable **DB-frontier delete-rebuild**; time the atomic unit before and after, and note that (like `sync:votes`) a second full run may write nothing and therefore cannot measure itself.

### M3 — the RED baseline, co-located, query-level, worst case

Per the new SKILL rule and 594's retraction: **co-located, timed, worst case, not median, not from the laptop.** The backlog entry already carries the warning, and 595 M4's first pass timed a reconstructed query the app never runs. Use the shipped SQL at `lib/queries.ts:3006` verbatim.

### M4 — is VOLUME the only breach on this page?

The guard wraps **only** `getRecentFilings`. The `/lobbying` request path also carries the rollup, the rail, the crosswalk and the firms leaderboard, and 595 M4 already clocked `lda_filings COUNT(*)` at 2.79s. Inventory the rest of the page's queries co-located and cold, ranked against 10s.

If the guard is hiding one failure, the unguarded neighbours are the ones that would 500 the page for real. **Inventory only.**

---

## HALT

Commit as `diag(db): HO 597 STEP 0 — /lobbying VOLUME cost`, then stop. Report M1's prod fire rate, M2's priced options plus a recommendation and the write cost, M3's RED, and M4's ranked inventory.

---

## The build (phase 2, after approval)

### The regression risk that has to be in CONTROL

The current VOLUME query is an **agg-driven INNER JOIN**, and the comment at `:2994` explains why: the INNER JOIN drops ~295 filings with zero `lda_activities` rows, which is safe *only* because they'd carry `activity_count 0`, sort dead last, and fall past the `MAX_FEED_PAGES=40` clamp — so the visible feed matches a LEFT JOIN.

**Materializing onto `lda_filings` changes the join shape into a single-table sort, which reintroduces those ~295 rows.** They should still sort last and still fall past the clamp — but "should" is the word this project doesn't accept. Prove the visible feed is byte-identical, and prove the clamp still holds at the new row count.

### Falsification, four-sided

- **RED** — M3's co-located cold worst.
- **GREEN** — same shape, worst case with the **margin stated as a number**. Report query breaches, not just route status; the route can't report this one anyway.
- **CONTROL** — the visible VOLUME feed fingerprinted before and after, including the first page past the clamp boundary, plus the ~295 zero-activity filings verified still invisible.
- **NEW — fire the degradation path.** Force the guard to trip and confirm whatever instrument you add actually reports it. An untriggered detector is UNPROVEN, and this entire HO exists because a shipped guard has been degrading silently with nothing watching.

## Scope guards

1. **Do not strip the HO 440/448 guard.** The comment says so twice. The fix removes the *need* for it; it does not remove it. A guard that never fires is cheap insurance against the next growth curve.
2. **Do not "fix" the INNER JOIN to a LEFT JOIN.** `:2999` warns explicitly — it reintroduces the automatic-covering-index spike (~18s cold, HO 544) for rows nobody can see.
3. **No laptop-only numbers.** Co-located or it doesn't count.
4. **M4 is inventory.** No widening into the rollup, rail, crosswalk or firms.
5. **Do not touch the `pageErr` #418 OPEN LOOP.**
6. **Migration · writer · rewire · docs are separate commits**, docs last.
7. **No unrequested SKILL.md edits.**

## Owed to the sweep HO

- The Task 0 correction, recorded as a **planning-side error** — a crash was inferred from "both retries lost" without checking for a guard, which is the claim-verification rule applied in the wrong direction.
- The silent-degradation finding as a **sixth instance** under oddities entry 4, with the specific note that `smoke.spec.ts`'s four assertions are all blind to a 200-with-empty-body, so `/lobbying`'s clean record in 593's cross-tab proves nothing about its health.
- Whatever M1 returns for the real-world fire rate, whether or not it justifies the work.
