# HO 430 — ideology-arc tail: shared `median()` extraction + diagnostic caucus-vs-registration fix

Two small, isolated items queued at HO 429 but never written. Both retire loose ends from the ideology arc (419→428). **Two commits, refactor then fix** — they share no code. Both are code-only; **no SKILL edit is required** (see the note in Part A). Diagnose before touching, per house discipline — one of these has a stale premise in the backlog that a real run corrects (Part B).

Re-grep every line number below at write time; they drift.

---

## Part A — extract `lib/median.ts` (refactor, zero behavior change)

### State today
Four byte-identical `median(values: number[]): number | null` definitions. Strict method: sort ascending, empty → `null`, odd → middle, even → mean of the two middle.

- `lib/queries.ts` (~L2705) — consumed **only** by `getMemberIdeology` (~L2755) and `getPolarizationBand` (~L2784)
- `components/IdeologyStrip.tsx` (~L38) — the client island; the only diff from the others is a `s`-vs-`sorted` local name
- `scripts/sync-polarization-history.ts` (~L26)
- `scripts/diagnostic/polarization-history-coverage.ts` (~L28)

The island and the two tsx scripts re-inline it because importing the `queries.ts` copy drags `next/cache` into their bundle. Re-grep first: confirm the four are identical and that no fifth consumer exists.

### Change
1. New leaf module `lib/median.ts` exporting `median(values: number[]): number | null` — the exact strict method above, **zero imports** (no `next/cache`, no React), so server / client-island / node-script can all pull from it.
2. Replace all four inline defs with an import of the leaf module. `lib/queries.ts` and `components/` use `@/`-style imports; `scripts/` use relative `../` — match each file's existing convention.
3. Delete the four local defs.

### Verify — no behavior change is the entire point
- `npm run build` + typecheck clean.
- Run `npx tsx scripts/diagnostic/polarization-history-coverage.ts` — the 119th cross-check must still read history-median == band (live baseline **0.925 / 0.918**, delta 0.000). If it moves, the extraction changed the method — stop and diff.
- Eyeball `/members`: the `IdeologyStrip` dotplot median ticks and the `PolarizationBand` gap render unchanged.

### SKILL — no edit needed
SKILL already calls this "the shared `median()` helper" in the `getMemberIdeology` / `getPolarizationBand` entries, and states the strict method verbatim in the `sync:polarization-history` entry. The extraction makes that "shared" language literally true rather than aspirational — nothing to correct. If you judge a one-line "canonical def in `lib/median.ts`" pointer worthwhile, flag it for re-approval under the self-mod guard; it's optional.

---

## Part B — diagnostic: compare `party_code` against caucus, not registration (fix)

### Diagnose FIRST — the backlog's scope is slightly wrong
`scripts/diagnostic/ideology-coverage-419.ts` maps Voteview `party_code` via `partyLetter()`: 100→D, 200→R, **everything else→I**, then compares against `members.party` by equality. The backlog claims this false-positives on "King, Sanders, now Kiley." **Run it first — it almost certainly does NOT flag King/Sanders today.** Voteview codes genuine independents as `328`, which `partyLetter` already folds to `I`, matching their `members.party='I'` — so they *agree*. The only member that trips it is the **Kiley shape**: registered `I` (switched R→I 2026-03-09) but Voteview codes `200` (R), because DW-NOMINATE `party_code` follows **caucus** and Kiley caucuses R.

```
npx tsx scripts/diagnostic/ideology-coverage-419.ts   # capture the "party_code vs members.party disagreements" block as-is
```

Build the fix against that real list, not the backlog's. Confirm or refute the King/Sanders/Kiley premise in the report.

### The invariant — the load-bearing part
The disagreement line exists to catch genuine anomalies (a sync/ID bug) while suppressing the structural registration-vs-caucus semantic gap. The rule that handles every known case:

> **Flag a member only when Voteview's letter matches *neither* their registration (`members.party`) *nor* their caucus.**

- King / Sanders — VV=I, reg=I → matches registration → not flagged ✓
- Kiley — VV=R, reg=I, caucus=R → matches caucus → not flagged ✓
- a genuinely mis-synced member — VV=D, reg=R, caucus=R → matches neither → **flagged** ✓ (the signal to keep)

Do **not** naively swap "compare against registration" for "compare against caucus" — that newly breaks King/Sanders (VV=I vs caucus=D would disagree). It is *neither-match*, not *caucus-only*.

### Caucus source
The set of independents caucusing with a major party is tiny (currently 3: King→D, Sanders→D, Kiley→R). Your call:

- **(default) a small typed map in the diagnostic** — `const INDEPENDENT_CAUCUS: Record<string, "D" | "R"> = { … }` keyed by bioguide, commented: "only independents caucusing with a major party need an entry; a new one surfaces as a disagreement until added — intended fail-loud." Trivially auditable, no second fetch.
- **(zero-maintenance alternative)** read the caucus from congress-legislators `legislators-current.yaml` — `sync-members.ts` already fetches that file (~L42), so the pattern exists; the sitting term carries a `caucus` field for independents. More robust, a little more code in a read-only script.

Resolve the map keys against real bioguide IDs (`K000401` = Kiley; pull King/Sanders IDs from `members`, don't guess). Note `lib/caucus-config.ts` is the badge layer (Freedom/RSC/Prog/New Dem) — **not** the D/R-caucus map; don't try to reuse it.

### Close criterion
Re-run the diagnostic: the disagreement line reads **0 on a clean roster with independents present** — or lists only genuine anomalies if any exist (there shouldn't be). Relabel the line from the current "ICPSR party-switch quirks (note, not fixed here)" to something like "genuine party mismatches (registration/caucus gap suppressed)".

**Not a `members` fix.** Kiley's `'I'` is correct (closed HO 422 — NOT A BUG). This teaches only the *diagnostic* the caucus-vs-registration distinction. Do not touch `sync-members` or `members.party`.

---

## Commit discipline
Two commits, explicit pathspec, ancestry re-checked before push, no auto-commit, diffs shown:

1. `refactor(ideology): extract shared median() to lib/median.ts` — leaf module + 4 importers + 4 deletions. No behavior change.
2. `fix(diagnostic): ideology-coverage compares party_code vs caucus, not registration (HO 430)` — the neither-match invariant + caucus source + relabel.

No `docs/` in these commits (a sweep folds this later). No schema, no `migrate.ts`, no cron touch.

## Report back
- **Part A:** confirmation the four copies were identical (flag any divergence beyond the `s`/`sorted` name), the post-extraction 119th cross-check number (must equal the band), build/typecheck clean.
- **Part B:** the **before** disagreement list (who actually tripped it — confirm/refute King/Sanders/Kiley), the caucus source chosen and why, the **after** list (0 or genuine-only), and the relabeled line.
- Both diffs.
