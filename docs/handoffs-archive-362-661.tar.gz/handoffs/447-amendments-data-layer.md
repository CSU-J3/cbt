# HO 447 — Amendments data layer (table + sync + cron)

Build the amendments pillar's data layer. Probe (HO 446) came back **GO**: 6,788 amendments in the 119th (SAMDT 6,560 / HAMDT 228 / SUAMDT 0), `amendedBill` present 100% and resolving 100% to tracked bills, rich disposition vocab. This lands the corpus + the join. **No surface, no status model, no rollup** — same as HO 435 landing the LDA corpus before HO 437's surface.

Depends on the HO 446 probe commit being in (`scripts/diagnostic/amendments-probe-446.ts`). Mirror the **`sync:lda` shape** (`lib/lda-sync.ts` + `app/api/cron/lda/route.ts` + the LDA `vercel.json` entries) — self-contained sync lib, DB-derived resume frontier, deadline-gated cron, unbounded CLI backfill.

---

## What the probe locked (don't re-litigate)

- **One FK, no link table.** Sub-amendments carry *both* `amendedBill` and `amendedAmendment`, and the API resolves the ultimate bill transitively (SAMDT 14 → SAMDT 8 → still reports `amendedBill` 119-s-5). So `amended_bill_id` is a plain column; sub-amendment lineage is a nullable **self-FK**, not a many-to-many.
- **Detail hydration is mandatory.** `amendedBill`, `sponsors`, `purpose` are detail-only; the list is thin (SAMDT list items are `{congress,number,type,updateDate,url}`). So the sync fetches list → detail per amendment.
- **Top-level `latestAction` only. No per-amendment `actions` walk.** That keeps the backfill at ~6,800 requests, not ~13,600. The tail disposition phrasing (withdrawn / ruled out of order) that only appears in the `actions` sub-resource is deferred to the status model (below) — v1 stores raw `latest_action_text`, which carries agreed/failed/vote-margin phrasing.
- **Two live types.** SUAMDT is empty in the 119th — keep it in the type domain (reserved), don't special-case it out.
- **Resumable framing required.** Full hydrate ≈ 17 min wall, exceeds one 300s cron and nears the ~5k req/hr key cap → DB-frontier resume like `sync:lda`, not a single-shot cron.

---

## Schema — `scripts/migrate.ts`

Add to the `statements` array (idempotent `IF NOT EXISTS`, matching the bills block). `id` = `` `${congress}-${type.toLowerCase()}-${number}` `` (mirrors `billId`, so `119-samdt-14`); the `type` **column** stays uppercase (`SAMDT`/`HAMDT`/`SUAMDT`) for display/filter. (If you prefer house-style, `type`/`number` → `amendment_type`/`amendment_number` to match `bill_type`/`bill_number` — align in plan mode.)

```
CREATE TABLE IF NOT EXISTS amendments (
  id TEXT PRIMARY KEY,                                   -- 119-samdt-14
  congress INTEGER NOT NULL,
  type TEXT NOT NULL,                                    -- HAMDT | SAMDT | SUAMDT
  number INTEGER NOT NULL,
  chamber TEXT,                                          -- House | Senate
  amended_bill_id TEXT REFERENCES bills(id),            -- resolved ultimate bill; nullable for a rare untracked ref
  amends_amendment_id TEXT REFERENCES amendments(id),   -- sub-amendment lineage; nullable (~2.5%)
  sponsor_bioguide_id TEXT REFERENCES members(bioguide_id), -- nullable (committee/manager amendments)
  sponsor_name TEXT,                                    -- label fallback when no bioguide
  purpose TEXT,                                          -- nullable (~5%)
  description TEXT,                                      -- nullable (~30%)
  latest_action_text TEXT,                               -- nullable (~35% top-level; absent = submitted/pending)
  latest_action_date TEXT,
  submitted_date TEXT NOT NULL,                          -- 100% present
  update_date TEXT NOT NULL,                             -- frontier key
  raw_json TEXT,                                         -- detail payload (NOT the actions sub-resource) for reprocessing
  ingested_at TEXT
)
```
Indexes:
```
CREATE INDEX IF NOT EXISTS idx_amendments_bill    ON amendments(amended_bill_id)
CREATE INDEX IF NOT EXISTS idx_amendments_sponsor ON amendments(sponsor_bioguide_id)
CREATE INDEX IF NOT EXISTS idx_amendments_update  ON amendments(update_date DESC)
CREATE INDEX IF NOT EXISTS idx_amendments_type    ON amendments(type)
```

**Sponsor:** store `sponsor_bioguide_id` (FK) + `sponsor_name` (fallback). Party/state come from the `members` join at read — don't denormalize them (avoids the bills-table drift). `amended_bill_id`: store the constructed id **regardless of resolution** — don't gate the insert on a `bills` lookup (a rare untracked ref should still land the row, resolvable later).

---

## Sync — `lib/amendments-sync.ts` + `scripts/sync-amendments.ts`

Mirror `lib/lda-sync.ts`/`scripts/sync-lda.ts`. Add `"sync:amendments": "tsx scripts/sync-amendments.ts"` to `package.json`.

Endpoints (base `https://api.congress.gov/v3`, `api_key` param, `format=json`, `limit=250`):
- List: `GET /amendment/{congress}?fromDateTime=…&sort=updateDate+asc&limit=250&offset=N`
- Detail: `GET /amendment/{congress}/{type}/{number}` → `{ amendment: {...} }`

Reuse the `lib/sync.ts` mechanics — the `fetchJson` 429-backoff helper, `getCurrentCongress()`, the `billId` construction. Those are module-private in `sync.ts`; **mirror the tiny helpers in `amendments-sync.ts`** rather than exporting from the hot bill-sync path (lower blast radius, matches how `lda-sync` is self-contained). Align in plan mode if you'd rather extract to shared.

**Resume contract (the requirement — mechanism is yours):** DB-derived frontier, **no stored cursor**, idempotent upsert on `id`, deadline-safe. Primary mechanism: frontier = `MAX(update_date)` from `amendments` (empty → 119th convening floor `2025-01-03T00:00:00Z`); fetch `fromDateTime=frontier&sort=updateDate+asc` ascending, hydrate detail, upsert, flush per page; a deadline backstop stops cleanly and the next run re-derives `MAX(update_date)` and continues. `updateDate` always moves forward to ~now on any action, so an ascending `fromDateTime` sweep always re-encounters updated rows — no gap. **Confirm the `/amendment` endpoint honors `sort=updateDate+asc`** from the probe; if not, fall back to an offset walk for the one-shot backfill + a `updateDate desc` stop-at-frontier for incremental (the bill-sync idiom) — either way the contract holds.

Per amendment, from detail: resolve `amended_bill_id` (construct from `amendedBill`), `amends_amendment_id` (construct from `amendedAmendment` if present), `sponsor_bioguide_id`/`sponsor_name` (from `sponsors[0]`), `chamber`, `purpose`, `description`, top-level `latestAction.text`/`.actionDate`, `submittedDate`, `updateDate`, and stash the detail payload in `raw_json`.

**Backfill:** one unbounded local run — `npm run sync:amendments` (~17 min, ~6,816 requests). Then the cron only ever faces the incremental delta at the frontier.

---

## Cron — `app/api/cron/amendments/route.ts` + `vercel.json`

Mirror `app/api/cron/lda/route.ts`: `export const maxDuration = 300`, Bearer `CRON_SECRET` auth, `wrapCronRoute`, budget stop at ~280s (`AMENDMENTS_BUDGET_MS = 280_000`) leaving room for the final flush + cron-log write. **Sync only — no rollup/precompute step** (the LDA cron precomputes its `/lobbying` blob because request-time aggregation is non-viable at 10⁵; amendments are bills-scale, so whether the surface needs precompute is a cold-latency question for the surface handoff, not assumed here). One `revalidateTag("amendments")` at the end (the tag the future surface will read).

`vercel.json`: add the `functions` entry (`"app/api/cron/amendments/route.ts": { "maxDuration": 300 }`, mirroring the lda entry) **and** the `crons` entry:
```
{ "path": "/api/cron/amendments", "schedule": "0 7 * * *" }
```
07:00 UTC — clear of the 06:00 sync and the 08:00 lda cron (summarize `*/10` / news `*/30` also hit :00 but are cheap + overlap-locked; no conflict). Route + sync + `vercel.json` all land together — additive, nothing pre-existing depends on the new cron, so no deploy-ordering hazard (unlike the HO 433 config-before-logic case).

---

## Coverage diagnostic — `scripts/diagnostic/amendments-coverage-447.ts`

After backfill, mirror `lda-coverage-435.ts` (read-only). Report: stored row count vs API `pagination.count` (landed-clean check), % with resolved `amended_bill_id` (against live `bills`), % with a `sponsor_bioguide_id`, the type split, and the **magnet-bill fan-out** — top-10 bills by amendment count (`GROUP BY amended_bill_id`). That fan-out is the surface's cold worst case (a current appropriations/NDAA vehicle may carry hundreds of amendments — the LDA `119-hr-1` trap in a new table); the surface handoff needs it to size its query.

---

## Explicitly NOT in 447 (so scope doesn't creep)

- **No surface.** Placement (a LOBBYING-pattern section on `/bill/[id]` reusing the bill hub, vs. a standalone `/amendments` analytical surface like `/lobbying`) is Corey's call, decided *after* cold-instrumenting the built table. Surface handoff.
- **No status/disposition model.** The `computeStage` analogue (agreed / failed / withdrawn / ruled out of order / pending, deterministic from action text) is its own follow-on — and completeness on the tail cases needs the deferred `actions` walk. v1 stores raw `latest_action_text`.
- **No rollup blob.** Decide at surface time from real cold latency; bills-scale suggests live aggregation may suffice — don't assume either way.
- **No nominations.** The sequenced-later, committee/`/president`-shaped pillar.

---

## Git discipline

- Plan → diff → **wait for approval**. No auto-commit.
- **Explicit pathspec.** Data-layer commit = `scripts/migrate.ts` + `lib/amendments-sync.ts` + `scripts/sync-amendments.ts` + `app/api/cron/amendments/route.ts` + `vercel.json` + `package.json` (the `sync:amendments` line). All additive. Then run `npm run migrate`, run the local backfill, then the coverage diagnostic + findings write-back (second commit or ride — your call, keep it clean).
- Eyeball ancestry before any push: commits riding, clean integrate, nothing unrelated staged.

---

read docs/handoffs/447-amendments-data-layer.md and follow it
