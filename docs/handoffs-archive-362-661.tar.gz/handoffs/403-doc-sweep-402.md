# HO 403 — Doc sweep (HO 402 crosswalk arc)

> Renumber if HEAD has moved past 402. This sweeps a single arc: HO 402 (member ID crosswalk), committed at e664246.

Reconcile the four project docs to reflect the crosswalk arc, **in place — not append**. No code, no schema: HO 402's tables (`member_ids`, `member_fec_ids`), sync script (`sync:crosswalk`), and diagnostic already shipped at e664246 and are live in prod. This sweep moves the arc's durable output out of chat and into the docs, per the OPEN LOOPS rule that nothing lives only in chat.

## Facts to fold in (resolved — transcribe, don't re-derive)

Final post-resync coverage (verbatim from `crosswalk-coverage-402.ts`, live prod):
- members 552 total / 537 current; `member_ids` 537/537 (100% of current).
- with icpsr 320 (59.6%); with ≥1 fec 536 (99.8%); with wikipedia_title 536 (99.8%).
- distinct `fec_candidate_id` 605; agreement 524; disagreement 3; no-crosswalk-row 0; drift 0.

The 3 fuzzy-vs-authoritative disagreements (the actionable output — these are inputs to a future `sync-fec` switch handoff, not fixed here):

| bioguide | member | term | `members.fec_candidate_id` (fuzzy, suspect) | authoritative (crosswalk) |
|---|---|---|---|---|
| G000602 | Laura Gillen (NY-04) | 1st | `H2NY04244` | `H4NY04158` |
| I000058 | Glenn Ivey (MD-04) | 2nd | `H2MD04232` | `H2MD04315` |
| S001224 | Keith Self (TX-03) | 2nd | `H2TX00064` | `H2TX03290` |

Read: Ivey and Self are **second-term** (first terms started 2023), so their fuzzy picks are wrong-registration matches on a seat congress-legislators has had clean data for since 2023 — not upstream lag. Gillen is first-term; her `H2NY04244` is probably her real 2022 NY-04 candidacy that upstream omitted (it lists only her 2024 `H4` registration). Correct the "all freshmen" framing from the ship report.

The `sync:members` staleness instance: James Gallagher (G000607, R, CA-01) won the June 2 special for the late Doug LaMalfa's seat and was sworn in June 10, but was absent from `members` until the HO 402 re-sync. `sync:crosswalk`'s gate correctly refused to invent him (surfaced as `skipped_no_member`), then picked him up once `sync:members` added him.

---

## 1. `docs/backlog.md` — OPEN LOOPS (add three)

Confirm the file/section path first (`grep -n "OPEN LOOPS" docs/backlog.md`), then add in place:

1. **`sync-fec` fuzzy pick suspect for 3 members** — input for a future `sync-fec` switch handoff. Gillen G000602 (fuzzy `H2NY04244` / auth `H4NY04158`), Ivey I000058 (`H2MD04232` / `H2MD04315`), Self S001224 (`H2TX00064` / `H2TX03290`). All three have a non-empty `member_fec_ids` set that doesn't contain the fuzzy pick. Ivey/Self are 2nd-term (wrong-registration matches); Gillen 1st-term (likely a real prior-cycle ID upstream dropped). Surfaced by `crosswalk-coverage-402` disagreement line.
2. **`sync:members` staleness → silent roster gaps.** Manual quarterly-plus sync means mid-Congress special-election winners don't appear in `members` until a re-run (Gallagher CA-01 was the instance, closed HO 402). Standing re-check after any known special election: re-run `sync:members`, then `sync:crosswalk`, and confirm `current` matches congress-legislators' count (537 as of 2026-07-02). Open question each time: is anyone else missing?
3. **`member_social` deferred** (HO 402 non-goal). One file GET (`legislators-social-media.yaml`) + one table the day a consumer exists. No consumer yet — X API is paid/restricted, Bluesky isn't tracked upstream.

## 2. `docs/oddities.md` — durable field notes (add two, optionally three)

Append to the field-notes section (this file is append-style by nature; keep the (HO 402) tag):

1. **congress-legislators `fec` is NOT reliably every career candidate ID** — it's often just the latest registration. Gillen (G000602) lists only her 2024 `H4NY04158` despite a 2022 NY-04 run. A future `sync-fec` switch therefore can't assume the authoritative array is complete when disambiguating to the current-office ID. (HO 402)
2. **`sync:members` is manual; between runs, mid-Congress special-election seatings are absent from `members`.** The crosswalk gate refuses to invent them, so the gap surfaces as `skipped_no_member` in `sync:crosswalk`, never an orphan row. Fix is always `sync:members` re-run → `sync:crosswalk`. (HO 402)
3. *(optional, minor)* FEC candidate IDs persist per-person-per-office across cycles, so distinct `fec_candidate_id` == flattened rows in `member_fec_ids` (605 == fec_rows). No dedupe needed. (HO 402)

## 3. `docs/roadmap.md` — STATUS block

Read the current STATUS block first and report the current value of the line you touch. The ID crosswalk is enabling infrastructure under the **Member** theme: `member_ids` + `member_fec_ids` now bridge bioguide → icpsr (Voteview, 60% native), wikipedia_title (pageviews, ~full), and the authoritative FEC candidate-ID array (money).

It's plumbing, not user-facing completion, so tick **conservatively** — a couple points on the Member line at most, and let the annotation carry the weight. Annotation (fit to the block's style): `ID crosswalk landed — Voteview/pageviews/FEC-money bridges unblocked`. Show current→new in the diff so I can confirm before commit; don't invent a number.

## 4. `SKILL.md` — schema + pipeline (reconcile in place against live state)

`SKILL.md`'s self-modification guard will trip. Re-approve when prompted; do not route around it. Grep live schema/scripts to reconcile rather than trusting any frozen copy.

- **Schema section:** add `member_ids` (bioguide_id PK, scalar external IDs: icpsr/govtrack/lis/thomas/cspan/votesmart/wikidata/wikipedia_title/ballotpedia_title/google_entity_id/opensecrets/maplight/house_history/pictorial, plus `raw_json` full-id-block fidelity copy + `fetched_at`) and `member_fec_ids` (flattened FEC candidate-ID reverse lookup: `(bioguide_id, fec_candidate_id)` PK, `idx_member_fec_ids_cand`). Note both FK to `members` but FKs are **documentation only** under libSQL (`foreign_keys` off); the enforcement is the sync gate.
- **Sync scripts:** add `sync:crosswalk` — mirrors `sync-members` (dotenv-first, `getDb`, one YAML GET of `legislators-current.yaml` + local parse, per-row upsert, no `batch()`). Source: `unitedstates/congress-legislators`, YAML only. Manual cadence, run **right after `sync:members`**. Gate loads all known bioguides and skips+counts non-members, so it's enrichment of the bioguide-keyed roster and never a source of new members.

## Git discipline

Docs-only commit, kept separate from any code commit. Explicit pathspec — `git add SKILL.md docs/roadmap.md docs/backlog.md docs/oddities.md` (confirm exact paths first; `SKILL.md` is repo-root, the other three under `docs/`). Recheck ancestry before push. Show the full diff before committing.

## Files touched

- Edited: `SKILL.md`, `docs/roadmap.md`, `docs/backlog.md`, `docs/oddities.md`.
- No code, no schema, no new files.

## Rollback

Revert the docs-only commit. Nothing else is affected.
