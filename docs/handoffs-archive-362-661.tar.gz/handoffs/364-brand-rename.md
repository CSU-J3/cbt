# HO 364 — Brand rename: CBT → Congressional Terminal

> Claim the next free HO number: `ls docs/handoffs/ | sort -V | tail`. Body assumes 364.

The new domain **congressional-terminal-chi-silk.vercel.app is live and resolving**,
so the URL layer is no longer dangerous — this ships as **one pass**: in-app brand
copy + README + manifest + `metadataBase` + the `verify:deploy` host, all moved to
Congressional Terminal / the new domain. The masthead already reads
`Congressional Terminal:\` (361); this mops up the rest.

**One external gate the live domain does NOT cover: the GitHub OAuth callback URL** —
see HALT below. Everything else is code.

## Premise check first (read-only, report before editing)

1. **`metadataBase`** — 361 may already have set it to the new domain. Grep the root
   layout; report the current value.
2. **`verify:deploy` host** — find the script behind the `verify:deploy` npm script;
   report the host string it polls `/api/version` against (old domain? new?).
3. **Old domain** — from the local machine, `curl -sI https://cbt-chi-silk.vercel.app`
   and the new one: does the old still resolve, or did the project rename kill it? If
   old is dead, every `cbt-chi-silk` reference is already broken — those are the
   priority.
4. **`AUTH_URL` / `NEXTAUTH_URL`** — grep code for either, and note to check Vercel
   env. With `trustHost: true` it's normally unset (derived from the request host); if
   it's pinned to the old domain anywhere, it needs the new value in Vercel Production.

## HALT — GitHub OAuth callback (do before relying on prod sign-in)

NextAuth derives `redirect_uri` from the request host (`trustHost: true`), so on the
live new domain sign-in sends the user to GitHub with
`redirect_uri = https://congressional-terminal-chi-silk.vercel.app/api/auth/callback/github`.
**GitHub rejects any `redirect_uri` not in the OAuth app's allowlist.** If that URL
isn't registered, prod sign-in **is already broken on the new domain** — independent
of this rename, because the domain is already serving.

Confirm in **GitHub → Settings → Developer settings → OAuth Apps → [the app] →
Authorization callback URL** that the new-domain callback is registered. Keep the
localhost callback for dev; leave the old-domain callback registered too (harmless)
until nothing uses the old host. Console action only Corey can do.

The code rename itself touches no auth wiring and is safe to deploy regardless — but
verifying sign-in on the new domain needs this.

## The rename (ships like code)

Two distinct greps — keep them separate:

**A. Brand copy** — word-boundary `\bCBT\b` and `Congress Bill Terminal` →
`Congressional Terminal`.
- **Landmine: never match `CCBT` / Colorado** (the sister project). Word-boundary the
  grep; eyeball every hit before replacing.
- Change (user-facing only): root layout `<title>` / metadata title + OG description,
  `README.md` headings/prose, `manifest.json` (`name`, `short_name`), any "CBT" in
  page copy / footer / about / landing.
- **Do NOT rename** (infra/identifiers, not brand): the repo (`CSU-J3/cbt`),
  `package.json` `name`, internal `cbt`-prefixed file/var names, and the **`SKILL.md`
  frontmatter `name: cbt`** (skill id, not user-facing). Leave these.

**B. Old-domain URLs** — grep `cbt-chi-silk` (distinct from bare `cbt`) →
`congressional-terminal-chi-silk`.
- `metadataBase` (if 361 didn't already), the `verify:deploy` host, any hardcoded
  old-domain URL in README / OG / sitemap / robots.

## Docs (in place)

- **SKILL.md:** resolve 362's "brand in transition" note → brand is Congressional
  Terminal (skill-id frontmatter stays `cbt`). One line.
- **backlog.md OPEN LOOPS:** close the brand/URL rename loop (done here).

## Constraints

- **Word-boundary the CBT grep — never touch CCBT/Colorado.** This is the one thing
  that breaks the sister project. Confirm in the report that no CCBT string changed.
- Leave infra/identifiers (repo, package name, skill id, internal `cbt`-prefixed
  names) — text/brand only.
- Existing tokens, no design change.

## Commit / verify / report

- Shared tree is live: named `git add <file>`, commit by explicit pathspec, re-check
  HEAD before push.
- Push, then `npm run verify:deploy` (now pointing at the new domain) until served
  SHA === HEAD.
- Verify on the **new domain**: renders styled (stylesheet 200, not just route 200);
  root title reads "Congressional Terminal"; manifest name updated; README updated.
  Then **prod sign-in round-trips on the new domain** (the OAuth-callback confirmation
  in practice).
- `grep -ri ccbt` / Colorado — confirm untouched.
- **Report:** premise-check findings (metadataBase + verify:deploy host current
  values, whether the old domain still resolves), the A/B grep hit-lists,
  CCBT-untouched confirmation, OAuth callback status, and the final SHA.
