# HO 557 — the motion-aware Senate amendment-outcome surface (build)

The banked HO 537 M8 surface, GO'd at HO 550, STEP-0'd at HO 554, and reshaped by HO 555. Build it.

**What this ships:** a second line under an amendment — distinct from the existing `VoteLine` — for the ~55 Senate amendments whose only floor roll call is a *motion about* the amendment (tabling, cloture, chair appeal, budget waiver) rather than an up-or-down vote on it. The line states the motion, its tally, and the amendment's implied fate with the polarity corrected (a tabling motion agreed is a **kill**).

**What this does NOT ship — read this before scoping anything:** the disposition dot. HO 555 already fixed the dot for these rows (the "ruled out of order" / "fell" rescue, 80/115). Pre-555 framing said the surface would correct a muted dot; that half is done. The build owes the **evidence line**, not the classification. If you find yourself editing `deriveDisposition`, stop — you're building HO 555 again.

Read `lib/amendment-vote-key.ts` end-to-end before starting. Its scope comment is the mirror image of this HO's job and names the exact model you're implementing.

## §0 — Preconditions

1. `git fetch && git status` clean, `main` even with `origin/main`, `git rev-parse HEAD` = `20833df`.
2. `npm run typecheck` clean before you touch anything.
3. Read: `scripts/diagnostic/motion-outcome-model-554.ts` (the model — classifiers, `impliedFate`, and M4's exact two-statement hydrate), `lib/amendment-vote-key.ts`, `lib/queries.ts` around `getBillAmendmentVotes` (~3236–3400) and `hydratePageAmendmentVotes` (~3686), `components/AmendmentVoteLine.tsx`, `components/AmendmentRow.tsx`, `components/BillAmendments.tsx`.

## §1 — STEP 0: one gate, then HALT

The HO 554 M2 tripwire (dot-vs-implied-fate DISAGREE = 0) was measured against the **pre-555** classifier — the probe re-declares `deriveDisposition` verbatim so it compares against what ships, and what ships changed at `2ce1d6c`. That copy is now stale, which is exactly the condition the HO 556 WATCH names ("any future edit to `deriveDisposition` must update the probe's copy in the same change or it reads a stale classifier"). Discharge it here, as a gate, not as a new probe HO.

**C0 (diagnostic commit, own commit):**

1. In `scripts/diagnostic/motion-outcome-model-554.ts`, replace the re-declared `deriveDisposition` body with the **shipped** version from `lib/queries.ts` (the 555 widening: `ruled out of order` + `\bfell\b` in the failed-family). Keep it re-declared, not imported — it's a pinned comparison baseline, and importing `lib/queries.ts` drags `next/cache` into a node script. Update the comment to say which SHA it mirrors (`2ce1d6c`).
2. Re-run: `npx tsx scripts/diagnostic/motion-outcome-model-554.ts`.
3. **Gate — hard HALT:** `M2 DISAGREE` must be **0**. A non-zero means the 555 widening created a row where the prod dot and the motion imply *opposite* fates on live data — that's a P1-shaped finding and the surface must not be built on top of it. Report the rows and stop.
4. Expected shifts (not gates, just so you can read the output): `DOT-OTHER` should fall sharply from 53 (the 555 rescue is exactly those rows), `AGREE` should rise correspondingly. `ORTHOGONAL`, `MOTION-OTHER`, and `M3 MAX=1` should be unchanged.

Commit as `diag: HO 557 STEP 0 — reconcile the 554 probe's deriveDisposition copy to the shipped classifier (read-only)` with the M2 line in the body. Then **HALT and report** before writing any build code.

## §2 — C1: the leaf, `lib/amendment-motion-key.ts`

A new leaf module **beside** `lib/amendment-vote-key.ts`, not an edit to it. The up-or-down matchers are untouched (scope guard 1).

Port the classifiers **verbatim** from the 554 probe — these exact regexes are what produced the measurements this build rests on, so any "cleanup" invalidates the evidence:

- `SENATE_MOTION_QUESTION_LIKE = "%Amdt%"` — the coarse residual pre-filter, paired with `NOT LIKE SENATE_AMDT_QUESTION_LIKE` (imported from the vote-key leaf) to exclude the up-or-down form. Export both halves of the pair together so a consumer can't apply one without the other.
- `classifyMotion(question): MotionClass | null` — the four anchored forms (`table` / `cloture` / `chair` / `waiver`). **Return `null` for the tail, not a `"tail"` member** — a tail row must be droppable by type, not renderable. Measured tail = 0.
- `parseMotionAmendmentNumber(cls, question): number | null` — the waiver form keys on `Amdt. No. N`, the other three on `S.Amdt. N`. Both resolve into the same Senate `S.Amdt` namespace (HO 550 confirmed by 42/43 sponsor-name match — put that in the comment, it's the non-obvious part).
- `motionOutcome(result): "agreed" | "failed" | "other"`.
- `impliedFate(cls, result)` — **with one rename, which is the module's most important design detail.** The probe returns `"agreed" | "failed" | "orthogonal" | "other"`; ship it as **`"survived" | "killed" | "orthogonal" | "unknown"`**. The mapping is identical (survived ≡ agreed, killed ≡ failed) so HO 550's 96% polarity validation carries over unchanged — this is a label change, not a model change. The reason: `"agreed" | "failed"` is structurally assignable to `AmendmentVote["disposition"]`, so the compiler would happily let someone pass an implied fate into `dispositionColor()` or `voteVerb()` and render "Agreed" on an amendment that merely *survived a tabling motion*. Renaming makes that a type error. The semantics matter too — a failed tabling motion leaves the amendment **pending**, it does not adopt it, so "survived" is the honest word and "agreed" would be a lie.

Polarity, restated so it's in the module and not just in a probe: `table` **inverts** (motion agreed → killed; motion failed → survived); `waiver` is **same-polarity** (waiver agreed → survived the point of order; waiver failed → killed, which is the "ruled out of order by the chair" text HO 555 measured 47 of); `cloture` and `chair` are **orthogonal** — they decide procedure, not the amendment, and must never produce a fate.

Carry a scope comment in the `amendment-vote-key.ts` idiom: what it matches, what it deliberately excludes, the measured counts (table 9 / cloture 4 / chair 1 / waiver 50, tail 0), and a pointer to HO 550/554 for the evidence.

Commit: `feat(amendments): HO 557 C1 — the Senate motion-model leaf`.

## §3 — C2: the query

One new cached sibling in `lib/queries.ts`. **Corpus-wide, no arguments** — the residual is 64 rows total, so a single cache entry serves both consumers and there is no per-bill or per-page key surface to manage.

```ts
export type AmendmentMotion = {
  voteId: string;              // votes.id, TEXT composite
  motion: "table" | "cloture" | "chair" | "waiver";
  result: string | null;
  outcome: "agreed" | "failed" | "other";        // the MOTION's own outcome
  fate: "survived" | "killed" | "orthogonal" | "unknown";  // the AMENDMENT's implied fate
  yea: number; nay: number; present: number; notVoting: number;
  date: string | null;
  party: { D: {yea,nay}, R: {yea,nay}, I: {yea,nay} };
};

export const getSenateAmendmentMotions = unstable_cache(
  async (): Promise<Record<string, AmendmentMotion[]>> => { … },
  ["senate-amendment-motions"],
  { revalidate: 3600, tags: ["amendments", "votes"] },
);
```

A **distinct type from `AmendmentVote`**, deliberately — same reason as the fate rename. Two statements only, both EXPLAIN'd and cold-timed at HO 554 M4:

1. **Residual select** — `SELECT id, congress, question, result, vote_date, yea_count, nay_count, present_count, not_voting_count FROM votes WHERE chamber='senate' AND question LIKE ? AND question NOT LIKE ?`, rides `idx_votes_chamber_date`, **31ms / 64 rows**. No new index, no hint.
2. **Party split** — `member_votes ⋈ members` grouped by `(vote_id, party, position)` over those vote ids, **253ms / 297 rows**. Lift the shape from `hydratePageAmendmentVotes`; guard the empty `IN ()` (SQLite syntax error).

Three things the probe did that the query must **not**:

- **No per-amendment existence lookup.** The probe point-queried `amendments` per row to confirm the id resolves. Skip it — an unresolvable number just produces a record key nobody looks up, and dropping the check removes 64 round-trips. This also means the query never reads `amendments`, so the `amendments` cache tag is there for consumer-coherence, not because of a FROM clause; say so in a comment (the HO 537 tags-follow-the-tables rule, applied honestly).
- **No `MAX(congress)`.** The probe derived congress once from `amendments`; the residual select already returns `votes.congress` per row, so build the key as `${row.congress}-samdt-${n}` — multi-congress safe by construction.
- **No `Map`/`Set`/`Date`** in the return (HO 533). Plain `Record` of plain arrays of plain objects; dates as strings.

Drop a row when `classifyMotion` returns `null` or the number doesn't parse. Sort each amendment's list `date DESC, voteId DESC` (the canonical-first rule the hub and feed already use). `try/catch → {}` — this rides the bill page's `Promise.all` and the `/amendments` page; it must never 500 either.

**On the overflow branch:** M3 measured MAX(motions/amendment) = 1, so a `+N earlier` counter would be structurally unreachable code — exactly the shape the falsification discipline forbids documenting as protection. Don't build one. The render maps over the whole list instead, so a future second motion appears as a second line rather than silently hiding behind an unexercised counter.

Commit: `feat(amendments): HO 557 C2 — getSenateAmendmentMotions`.

## §4 — C3: the component + both render sites

**`components/AmendmentMotionLine.tsx`** — a new sibling of `AmendmentVoteLine.tsx`, **not** a widened `VoteLine` (scope guard 3; `VoteLine`'s verbs are amendment-framed and wrong here — the HO 496/512/515 new-sibling discipline). Export `MotionLine({ motion }: { motion: AmendmentMotion })`.

Same visual idiom as `VoteLine`: one dim mono 11px line, `tabular-nums`, tally links to `/vote/${voteId}`, party split via the shared `partyColor` (HO 468), and **the same all-zero split suppression** as HO 533 — these roll calls can lag `member_votes` too, and a false `D 0–0 · R 0–0` is the same lie here.

Copy:

- Motion label: `table` → "Motion to table", `cloture` → "Cloture", `chair` → "Decision of the chair", `waiver` → "Budget waiver".
- Motion verb from `outcome`: agreed → "agreed", failed → "rejected", other → "voted".
- Fate clause, appended only when `fate` is `survived` or `killed`: ` → amendment killed` / ` → amendment survived`. **`orthogonal` and `unknown` render the tally with no arrow and no fate word** — cloture and chair decide procedure, and claiming a fate there is the precise error this whole model exists to avoid.
- Then the split.

Reads as: `Motion to table agreed 52–47 → amendment killed · D 2–45 · R 50–2` / `Cloture rejected 55–45 · D 45–2 · R 10–43`.

**Suppression — the anchored rule.** A motion line renders only when the amendment has **no anchored decisive vote**. Both render sites already hold that set in hand (`votes[a.id]` on the hub, `a.votes` on the feed), so the check is `list.length === 0` and costs nothing. Consequence worth stating: `VoteLine` and `MotionLine` are **mutually exclusive on a row** — they can never stack, so there's no ordering or double-line question to resolve.

**Site 1 — `components/BillAmendments.tsx`.** The row is an *internal function* in this file (the HO 530 pathspec note: `components/AmendmentRow.tsx` is a different component). Pass the bill's motions down beside `votes` and render `MotionLine` in the same slot `VoteLine` occupies — after the action-text line, before `↳ amends`. The page (`app/bill/[id]/page.tsx`) adds `getSenateAmendmentMotions()` to its existing `Promise.all`.

**Site 2 — `components/AmendmentRow.tsx`.** Same slot, same rule. `getAmendments` is where the feed's rows come from — attach motions **page-scoped in the page component**, not inside `getAmendments` (scope guard 5: that query's `?disposition=` branches, the `voted` EXISTS, and the hydration helper are all untouched, so the counts, chips, and readout stay byte-identical).

**The dot does not move.** `dotDisposition` keeps its existing rule (authoritative from `votes.result` where a vote exists, else the `latest_action_text` scan). A motion never feeds it.

Commit: `feat(amendments): HO 557 C3 — the motion line on /bill/[id] and /amendments`.

## §5 — Hard scope guards

1. **No edit to `lib/amendment-vote-key.ts`.** The up-or-down matchers stay exactly as they are — the whole reason this is a separate model.
2. **No writes.** Nothing materialized into `amendment_votes`, no migration, no new index, no sync or cron change. This is a request-time read.
3. **No edit to `deriveDisposition`, `dispositionColor`, `voteVerb`, or `VoteLine`.**
4. **No dot changes** on any row, either surface.
5. **No change to `getAmendments`' filter semantics** — `?disposition=` (`acted|filed|voted`), the `voted` EXISTS, `hydratePageAmendmentVotes`, the readout counts, the `Voted` chip, and the exclusion-disclosure line all stay as-is. A motion is not a "voted" amendment.
6. **Senate only.** No House motion corpus has been measured; there is no House residual model.
7. **No `/vote/[id]` change.** The motion line links into the page that already renders any roll call.

## §6 — Verification

Local first (dev server, double-hit per the HO 548/549 convention), then prod.

**Branch coverage — every branch has a live instance, so demonstrate, don't assume.** Pull the render set straight from the query and name one row for each, with its rendered text in the ship report:

- `table` + motion agreed → `→ amendment killed`
- `table` + motion failed → `→ amendment survived` — **include `119-samdt-3946` and `119-samdt-3947` specifically.** These are the two "Motion to Table Failed" rows HO 550's polarity validation missed (54/56), so they're the cases most likely to read wrong. Eyeball the text against the amendment's actual `latest_action_text`.
- `waiver` + waiver failed → `→ amendment killed` (should co-occur with a "ruled out of order by the chair" action text and a red dot from HO 555 — a coherence check, not an assertion)
- `cloture` or `chair` → tally, **no arrow, no fate word**
- `unknown` fate (the MOTION-OTHER row, ~`119-samdt-3849`) → tally, no arrow
- **suppression**: one of the 4 anchored amendments renders its `VoteLine` and **no** motion line

The one branch with no live instance is the `classifyMotion → null` tail drop (measured tail = 0). Per the falsification discipline that is **UNPROVEN, not protection** — record it in the doc sweep as a WATCH, don't write it up as a guard.

**Controls (must be byte-identical):** `119-hr-8800` (House amendments — no motion lines anywhere, Amendments tab unchanged), `119-hr-1` (13 existing vote lines), and the `/amendments` hero readout + `Voted` chip + `?disposition=voted` count.

**Prod.** `verify:deploy` for the SHA, then double-hit each surface. Note the convergence rule (HO 555) is **not** in play here: `getSenateAmendmentMotions` is a new cache key with no pre-deploy value, so the line appears on the first read. The existing queries' entries are unchanged. If a *count* somewhere moves, that's a bug, not staleness — scope guard 5 says nothing countable changed.

`npm run typecheck` before every push. Explicit pathspec staging, ancestry eyeball, fast-forward only.

## §7 — Ship report

Per commit: SHA, files, what it does. Then: the C0 M2 gate line verbatim, the six named branch instances with their rendered text, the three control checks, and the live-verified prod SHA. Flag anything that surprised you — the model rests on 64 rows measured twice, and a row that renders oddly is more interesting than a clean sweep.

Docs are HO 558, not this one. Don't touch `docs/`, `SKILL.md`, or the roadmap.
