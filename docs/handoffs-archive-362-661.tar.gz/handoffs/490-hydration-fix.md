# HO 490 — fix the #418 hydration mismatch: clock-explicit relative-age helpers

Fix the root cause found by HO 489: `lib/format.ts` relative-age helpers read `Date.now()` at call time, and they're called inside client components, so server and client render in different buckets and React discards the server HTML.

## The approach — and why not the smaller version

Make the clock an **explicit required parameter** on the three helpers:

```ts
export function formatRelativeAge(iso: string | null | undefined, nowMs: number): string
export function formatRelativeAgeLong(iso: string | null | undefined, nowMs: number): string
export function daysSince(dateStr: string | null | undefined, nowMs: number): number
```

No default value. A default of `Date.now()` would let all 22 existing call sites compile untouched and let this bug walk straight back in the next time someone formats an age in a client component — silently, intermittently, and only in prod. Required means `tsc` rejects it, and typecheck runs in CI as of `3aa677c`. That closes the bug class, not just this instance.

Size (HO 489 + repo scan): `formatRelativeAge` 9 call sites, `formatRelativeAgeLong` 6, `daysSince` 7. Six client components involved: `BillExpandPanel`, `BillExpandedPanel`, `BillRow`, `BillRowList`, `TopStallsList`, `V2FeedList`.

## How the clock gets there

- **Compute `nowMs` once per page**, in the server component that owns the render — not per call site. Several `Date.now()` calls in one render could land in different buckets on their own.
- **Server components**: pass the page's `nowMs` directly.
- **Client components**: receive `nowMs` as a prop from their server parent and thread it down. Prop-drill it; do **not** add a context provider. At this depth explicit props are clearer, and a provider is a client component that would need its own value plumbed in anyway.
- **If any client component turns out to be more than ~3 levels below its server boundary, stop and report** rather than threading a prop through five components. That's a signal the structure needs a different answer and I want to make that call.

Accept that ages are now frozen at render time and won't tick while the page sits open. That's correct for CBT — the data is cron-driven and already stale-by-design between syncs, and there's a LAST SYNC stamp saying so.

## Watch for

- **`daysSince` returns a number, but check what consumes it.** If it selects a `className` or a color, a bucket difference changes the DOM attribute and mismatches exactly like the text does. Same treatment, and worth confirming it was part of the original failure.
- **Don't touch `CyclingTimestamp` / `lib/zone-cycle.ts`.** HO 489 verified they're hydration-safe by construction (SSR and first client paint both render MT; the live zone swaps in `useEffect`). Leave them alone.
- **Don't reach for `suppressHydrationWarning`.** It silences the warning while React still discards server HTML. HO 489 confirmed it appears nowhere in the tree — keep it that way.

## Orphan check (the HO 486 lesson)

`BillExpandPanel.tsx` and `BillExpandedPanel.tsx` both exist, both client, both formatting relative ages. Check whether both are actually imported. If one is orphaned, **delete it in this commit** — the HO 487 oddity says orphans go in the commit that reveals them, because a dead file importing a shared helper poisons the next consumer audit. That's precisely how the `/bill/[id]` regression happened. Report which one, don't just quietly remove it.

## Verification

The HO 489 probe is the acceptance test. Re-run `scripts/diagnostic/hydration-probe-489.ts` with `CLOCK_OFFSET_MS=90060000` against `/bills`, `/changes`, and `/` and confirm **zero** hydration errors where it previously forced them deterministically. A clean natural dev run proves nothing — dev's ~0ms SSR→hydrate gap never straddles a bucket, which is why HO 489 had to force it.

Also confirm `npm run typecheck` passes with no remaining implicit-clock call sites. That's the real proof the sweep is complete.

## Out of scope

- **Markets-hover headless timeout** — HO 489 confirmed it's a `.hover()` interaction issue, not hydration. Separate.
- **Dev `[auth][error] MissingSecret`** — `AUTH_SECRET` lives only in `.env.production.local`. A dev-env config gap, backlog it, don't fix it here.
- **CI Phase 2** — this fix removes one blocker, not all of them. Don't wire e2e to `pull_request` in this HO.

## Git discipline

- Clone / hard-reset to `origin/main` first — HEAD should be **`c7d75f1`** (HO 489 probe).
- Explicit pathspec staging; never `git add .`.
- **Live surface change → show the actual diff and wait for approval before committing.** The `lib/format.ts` signature change plus its call sites is one commit; the orphan deletion rides with it only if the orphan is confirmed.
- `npm run typecheck` clean before push. Ancestry eyeball, fast-forward only, no force-push.
- Commit message: `fix(hydration): make relative-age helpers clock-explicit (HO 490)` — and name the #418 symptom in the body so a future bisect finds it.

## Report back

The `lib/format.ts` diff, how `nowMs` reaches each of the six client components (and any that needed more than ~3 levels of threading), the orphan verdict, and the forced-straddle probe result showing zero hydration errors.

---

read docs/handoffs/490-hydration-fix.md and follow it
