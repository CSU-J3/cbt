# HO 365 — B5 week strip: rich hover card + strip refinements

> Claim the next free HO number; if 365 is taken in `docs/handoffs/`, use the next
> available (`ls docs/handoffs/ | sort -V | tail`) and rename this file.

**Supersedes the strip from HO 283 (WoW deltas) + 284 (HEARINGS metric, flat one-line
popover).** Where this conflicts with 283/284, this handoff wins. Two prior things are
STALE — discard them: the flat 284 popover (replaced wholesale by the richer card below)
and the 283 audit-#8 READ-FULL target ("point at the current week's report" — there is
no current-week report mid-week; see Strip → report link).

Four changes to the `WEEK OF …` strip plus a richer hover card. Every data question is
resolved by the HO 364 probe — build against the premises below, do not re-derive them.
Grep the current strip component first to see what 283/284 left in place (the running-week
headline counts and the three existing deltas already exist), then adapt to the target.

## Resolved premises (HO 364 probe — do not re-derive)

**Windows.** Two windows, easy to conflate:
- *Running window* = the **trailing 7 days** (`[now-7d, now]`), the window the live strip
  headline already uses (283/284). Keep it — do NOT switch to calendar week-to-date. The
  headline counts, the WoW deltas, the card header values, the card breakdowns, and the
  sparkline's current bar all use this window. (An earlier draft of this handoff said
  calendar week-to-date `[Mon→now]` with the current bar "reading low early in the week" —
  that was wrong and is STALE: it regresses 283's deltas to partial-week-vs-full-week,
  which reads ▼ every day until Sunday. Trailing-7d keeps the deltas honest.)
- *Last finalized week* = the most recent `reports` row (currently `2026-06-15`,
  `week_start 2026-06-15` / `week_end 2026-06-21`; today is 2026-06-25 so the current
  06-22 week is mid-flight and the HO 110 guard correctly leaves 06-15 on top). The
  WoW deltas compare the trailing-7d window against the prior trailing-7d window (283
  already does this); the card subline shows the prior-period value with a reference date.
- *Sparkline axis* = the 7 most recent finalized report weeks + the trailing-7d current
  bar (see Sparkline).

**`reports` schema (live):** `slug, week_start, week_end, title, content_md, created_at,
laws_count, intro_count, moves_count`. The three count columns (HO 242, added via
`ensureColumn` ALTER, not in base CREATE) are **frozen** per-week values. 9 rows exist.
- ENACTED series ← `laws_count`, NEW BILLS ← `intro_count`, STAGE TRANSITIONS ← `moves_count`.
- Read: `SELECT week_start, laws_count, intro_count, moves_count FROM reports ORDER BY
  week_start DESC LIMIT 8`. Tiny table, no fat-table risk.
- **No `hearings_count` column exists.** HEARINGS history is derived live (see Decisions).

**READ FULL target:** top `reports` row → `slug` gives the URL `/reports/{slug}`
(`/reports/2026-06-15`); `week_start` gives the label date → `JUN 15 REPORT →`. Both
dynamic, never hardcoded.

**STAGE TRANSITIONS breakdown.** No reusable helper — `gatherReportData`
(`lib/report-generation.ts:668`) computes it inline. The card writes its own query, and
**must use the raw-ISO-range + INDEXED BY form, not the report-gen `date()`-wrapped one**
(the `date(stage_changed_at) BETWEEN …` form mis-plans to a MULTI-INDEX OR and times out
>10s):
```sql
SELECT stage, COUNT(*) FROM bills INDEXED BY idx_bills_stage_changed_at
WHERE stage_changed_at >= ? AND stage_changed_at < ?
  AND (is_ceremonial = 0 OR is_ceremonial IS NULL)
GROUP BY stage
```
~225ms with the hint (the index already exists). Validated: 06-15 week →
committee 16 · other_chamber 3 · floor 3 = 22 = the frozen `moves_count` ✓. Destination
stages are `committee / floor / other_chamber / president / enacted` (`introduced` is not
a destination). `stage_changed_at` is an ISO string; pass raw ISO bounds.

**HEARINGS breakdown + series.** `committee_meetings` (small, ~2,490 rows; immutable
`meeting_date`; indexed `(meeting_date)` and `(chamber, meeting_date)`). Group by
`meeting_type` + `chamber` over the `meeting_date` range — trivial cost, no hint needed.
Distinct `meeting_type` values (whole table): Hearing, Meeting, Markup, Open Hearing,
Open Business Meeting, Closed Hearing, Closed Markup Session, Closed Business Meeting,
Open Markup Session. **Complete 9→3 bucket map (no orphans):**
- HEARINGS ← Hearing, Open Hearing, Closed Hearing
- MARKUPS ← Markup, Open Markup Session, Closed Markup Session
- BUSINESS ← Meeting, Open Business Meeting, Closed Business Meeting

Define this map once as a shared constant. (Validated 06-15 week, Senate-only: Open
Hearing 9 / Open Business Meeting 5 / Closed Business Meeting 3.)

**NEW BILLS breakdown.** No `chamber` column on `bills` — **derive from `bill_type`
prefix** (distinct values: `hconres, hjres, hr, hres, s, sconres, sjres, sres`):
`hr/hres/hjres/hconres → house`, `s/sres/sjres/sconres → senate` (covers all 8,
unambiguous). If a `bill_type → chamber` helper already exists, reuse it rather than
inlining a parallel map. Week's new bills via **`introduced_date`** (immutable; NOT
`update_date`). Top topics: `bills.topics` is a JSON-array TEXT column — aggregate with
SQLite `json_each` (the existing feed pattern, cf. `getTopicDistribution`), and **the
query needs `INDEXED BY idx_bills_introduced_date`** (unhinted it mis-plans and times
out; ~150ms hinted). Labels via **`topicLabel()`** in `lib/topic-colors.ts` (matches the
rest of the app). Validated 06-15: house 60 · senate 2 = 62 = `intro_count` ✓; top-3
technology 10 · government_operations 7 · consumer_protection 7.

**ENACTED breakdown.** Trivial. Week list:
`SELECT bill_type, bill_number FROM bills WHERE stage='enacted' AND latest_action_date >= ?
AND latest_action_date < ?` (enactment-date proxy = `latest_action_date`). Most-recent for
the 0-week degrade: `… WHERE stage='enacted' ORDER BY latest_action_date DESC LIMIT 1`
(live: `s-2`, `2026-06-10`).

## Strip changes (the `WEEK OF …` row)

Single thin full-width row, space-between. Left = week label + 5 metrics in a
middot-separated run. Right = the report link only. One line at full width; FILLER is the
wrap point if tight.

1. **Date format.** `WEEK OF <MON DD>` (month-abbrev + day, e.g. `WEEK OF JUN 22`), not an
   ISO string. Dim, mono, 11px, uppercase, ls 1px. This is a **format-only** change to the
   existing label (the strip already shows `WEEK OF …` over a trailing-7d count — keep the
   window, just reformat the date). Matches the hearings calendar header above it. No
   re-point to last week.

2. **Middots replace pipes.** The four count metrics are separated by a dim `·`
   (`--text-dim`, ~14px each side), replacing the old pipe separators.

3. **Metric format.** Each = value (14px, `--text-primary`, tabular) + label (11px,
   `--text-muted`, uppercase, ls .5px) + WoW delta (11px, tabular). Order:
   **ENACTED · NEW BILLS · STAGE TRANSITIONS · HEARINGS**. The ENACTED value carries a 6px
   `--stage-enacted` dot before the number.

4. **HEARINGS delta.** Ensure HEARINGS carries a WoW delta like the other three (284 added
   the metric; confirm whether it added the delta — if not, add it). HEARINGS delta =
   running-week `committee_meetings` count vs the last-finalized week's count (same live
   source as the series).

5. **FILLER into the run.** Move FILLER from the right cluster to **after HEARINGS**, same
   middot. Keep its mini bar (this is the one composition stat — stays visually distinct):
   30×5px track (fill = filler %, `--text-muted` on `#0e141d`) + `FILLER NN%` (11px
   `--text-muted`) + `· N/M` (`--text-dim`; N = filler bills, M = new bills). This is MOVE 1
   from the mock (bar kept), not the bar-less MOVE 2. FILLER keeps its current behavior; it
   gets **no** hover card (out of scope).

6. **Report link (right cluster, replaces READ FULL).** `<MON DD> REPORT →` →
   `JUN 15 REPORT →`. Points at `/reports/{slug}` of the most recent finalized report;
   label date = that report's `week_start`. Both dynamic. 11px, uppercase, ls 1px,
   `--accent-amber` → `--accent-amber-bright` on hover. This overrides 283 audit #8.

**Delta convention** (reuse the tape up/down tokens): `▲` increase vs last week in `--up`
green, `▼` decrease in `--down` red, dim `±0` for no change. Purely directional —
ENACTED 1→0 is `▼` red even though it isn't "bad".

## Hover card (replaces the flat 284 popover)

Hover any of the **four count metrics** → popover card, anchored under the metric, upward
pointer. FILLER has no card. Shared skeleton top-to-bottom:

- **Header:** metric name, 10px `--accent-amber`, ls 1.5px.
- **Value row:** the trailing-7d value (20px `--text-primary`, tabular) + `▲/▼N vs last wk`
  (12px, colored per the delta convention). This value equals the strip headline.
- **Subline:** `last wk NN · <MON DD>` (11px `--text-dim`) — the prior trailing-7d period's
  value and a reference date for it (the start of that prior 7-day window).
- divider → **8-WEEK TREND:** 8 sparkbars (7px wide, 3px gap, ~24px tall; history `#38414f`,
  current bar `--accent-amber-bright`) + right-aligned `avg N · hi N` over the 8 values.
- divider → **breakdown** (metric-specific, below).

### Sparkline (8 points, per metric)

- **Points 1–7 (history, `#38414f`):** the 7 most recent **finalized** report weeks,
  oldest→newest. ENACTED/NEW BILLS/STAGE TRANSITIONS read the frozen columns from those 7
  rows; HEARINGS counts `committee_meetings` live per each row's `[week_start, week_end]`.
- **Point 8 (current, lit `--accent-amber-bright`):** the **trailing-7-day count** = the
  strip headline number for that metric, so the lit bar equals the header. It's a full
  7-day count, so its height is comparable to the 7 frozen Mon–Sun weeks. Its window
  overlaps the most recent frozen week by a few days — cosmetic for a trend sparkline; do
  not correct it.
- `avg` / `hi` computed across all 8 points.

### Breakdowns (all over the trailing-7d window, matching the headline)

- **STAGE TRANSITIONS → "WHERE THEY WENT":** the full canonical destination ladder, fixed
  five rows in order **→COMMITTEE / →FLOOR / →OTHER CHAMBER / →PRESIDENT / →ENACTED**, each
  a stage-color tick + label + right-aligned count. **Zero-count rows stay, dimmed**
  (`--text-dim`), per the HO 352 ladder convention — fixed rows keep the sum honest and
  surface `president` when bills are awaiting signature. Counts sum to the headline. (Tick +
  count rows only; do **not** reuse the 352 sqrt-bar component.)
- **HEARINGS → "BY TYPE":** HEARINGS / MARKUPS / BUSINESS (the 9→3 bucket map above; sum to
  headline) + an inline `CHAMBER  HOUSE n · SENATE n` line.
- **NEW BILLS → "BY CHAMBER":** HOUSE / SENATE (prefix-derived) + an inline
  `TOP TOPICS  x n · y n · z n` line (top 3, `topicLabel()`).
- **ENACTED:** if 0 over the window, degrade to `NONE REACHED THE PRESIDENT` + inline
  `LAST ENACTED  <ID> · <MON DD>` (the most-recent enacted bill). If >0, list the enacted
  bills (ID + count, same row pattern).

**Card tick colors:** use the existing `--stage-*` tokens (committee, floor, other_chamber,
president, enacted) — the same palette `StageIndicator` renders. Don't hardcode new hexes;
the spec's hexes (committee `#06b6d4`, floor `#fbbf24`, other-chamber `#f59e0b`, president
`#fb923c`, enacted `#10b981`) are documentation of which token. If any existing `--stage-*`
token diverges from these, flag it rather than introducing a new value.

## Decisions of record (resolved here from the probe)

1. **Sparkline: KEEP** — history exists (9 reports), all four metrics resolve cheaply.
2. **HEARINGS series derives live from `committee_meetings`** (probe path b), no migration,
   no report-pipeline or cron change. The table is small and `meeting_date` immutable, so a
   live weekly count won't drift the way `moves` would.
3. **Window = trailing-7-day** for the headline, the deltas, the card header, the
   breakdowns, and the sparkline's current bar — matching the live strip, NOT calendar
   week-to-date. Calendar week-to-date would regress 283's deltas to partial-vs-full (reads
   ▼ every day until Sunday). The sparkline's lit current bar is the trailing-7d count
   (= header), full 7 days, with the 7 frozen Mon–Sun weeks to its left; its window overlaps
   the most recent frozen week by a few days, which is cosmetic. Reuse the existing
   trailing-7d helpers; add no week-to-date helpers. (This corrects this handoff's original
   `[Mon→now]` premise, which Code flagged against the live code.)
4. **Transitions breakdown = full five-row canonical ladder, zeros dimmed**, `president`
   included (the mock's 4 nonzero rows were illustrative and dropped `president`).
5. **Hearings bucket map is the complete 9→3** above (the probe found the spec's draft map
   dropped Closed Hearing and Closed Markup Session).

## Constraints

- Single thin row, **static** — no motion, no animated bars, no transitions, on the strip
  or the card.
- Dark only, existing tokens only, no new palette.
- Everything dynamic: this-week, last-week, 8-week history, all breakdowns, filler %/
  fraction, the report date and slug. Nothing hardcoded.
- Monospace throughout strip + card; `tabular-nums` on all numerics.
- No schema change — every index needed (`idx_bills_stage_changed_at`,
  `idx_bills_introduced_date`, `committee_meetings` indexes) already exists.

## Ship

Sequence the commits in plan mode — a natural split is (1) strip layout (date, middots,
ENACTED dot, FILLER into run, HEARINGS delta, dated report link), (2) the rich hover card +
its queries. Named `git add` per file, never `git add -A`; re-check HEAD before pushing.

Per handoff: `tsc` clean → `npm run build` clean → `git push` → `npm run verify:deploy`
until the served SHA === HEAD. **UI ship — verify the stylesheet loads** (confirm the
`layout.css` hash resolves, or `rm -rf .next` + restart if the dev server's been up a
while); a green `tsc` + 200 + payload does not prove the page rendered styled.

Live-verify on prod:
- Date reads `WEEK OF JUN 22`; metrics middot-separated; ENACTED dot present; FILLER sits
  after HEARINGS with its bar; all four metrics show a correct `▲/▼/±0` delta (confirm the
  `±0` dim state renders if a metric ties last week).
- The report link reads `JUN 15 REPORT →` and lands on `/reports/2026-06-15`.
- Hovering each of the four metrics opens its card: header value = headline, subline dated,
  8-bar sparkline with the current bar lit, and the right breakdown (transitions ladder
  sums to headline with zeros dimmed; hearings by-type + chamber; new-bills chamber +
  top-3 topics; enacted shows the 0-week degrade with `LAST ENACTED s-2 · Jun 10`).
