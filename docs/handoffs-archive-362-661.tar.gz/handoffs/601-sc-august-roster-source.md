# HO 601 — the SC August roster: make the votebox the router, not the page

**Numbering.** Next after HO 600 (`36b7731`). Confirm against `docs/roadmap.md` and `git log`.

**Build, not probe.** HO 600 measured everything a STEP 0 would ask. §2 is a short pre-flight with two hard gates, not a HALT-and-report. There are five days until the election.

---

## §0 — what HO 600 established, not to be re-measured

- `United_States_Senate_special_election_in_South_Carolina,_2026` returns **404**. The URL `senateSpecialPageUrl` builds is wrong for SC and **correct for FL/OH**.
- The August field is published in two places. The regular race page links exactly three parentheticals, one of which is `..._2026_(August_11_Republican_primary)` (200), and the **regular page itself now carries the contest as a fifth votebox**: `class="race_header republican"`, `<h5>Special Republican primary for U.S. Senate South Carolina</h5>`, 10 candidates (Darline Graham, Duke Buckner, Danny Ford, Russell Fry, Mark Lynch, Mark McBride, Ralph Norman, Glenda Gail Parker, Mark Sanford, Sam Shepherd).
- **`parseCandidatesPage` returns 0 rows against it, measured.** `isSpecialElectionPage()` keys on the page `<title>`; a parenthetical title carries no "special election" string while the votebox `<h5>` reads "Special…", so `/special/i.test(h5) !== onSpecialPage` inverts against itself and drops the only box on the page. **Fixing the URL alone would not have worked.**
- Party mapping is fine. The box resolves to `R` off `race_header republican` and never falls through to `open`.
- The trigger fires and the C2 cursor contract holds exactly. But `runSpecialPriorityPass` returns `Promise<string[]>` and discards `fetchFailure`/`settledSkipped`, so three ticks reported `fetchFailures: []` against three real 404s.
- The HO 560 freeze is **untested**, not proven. Two earlier layers refused first: the senate slice has not reached SC since the box appeared, and the page-type gate drops the box from the standard pass too, so `isSettled` is never consulted.

---

## §1 — the design call

**`onSpecialPage` stops being a filter. The votebox `<h5>` becomes the router.**

The current gate asks "does this box's specialness agree with the page's specialness?" and drops the box on disagreement. That question has no correct answer when a contest can appear on a regular page, a parenthetical sub-page, or a special-election page depending on the state's statute. The box's own header is the only signal present in all three cases.

So: a box whose `<h5>` marks it special is a special contest and routes to `senate-{ST}-2026-special-{party}`. A box that does not routes to the base id. Page identity stops deciding whether a box is read at all.

This is what makes the write land on the right row rather than substituting the August field into the settled June one, which is the hazard HO 560 was built for and which arrives live the moment the box stops being dropped.

---

## §2 — pre-flight, two gates

Read-only. Commit as `scripts/diagnostic/special-router-preflight-601.ts`. Report all three; **HALT only on P1 or P2 tripping.**

**P1 (GATE) — does the router change FL/OH?** Do FL and OH carry seeded `-special-` rows? Do their regular pages carry any votebox whose `<h5>` matches `/special/i` today? FL and OH are the states the current URL shape serves correctly, and they must not change behavior. **HALT if the router would alter what either state writes** and the alteration is not obviously correct.

**P2 (GATE) — blast radius across the roster.** Across all 2026 senate states, enumerate every votebox whose `<h5>` matches `/special/i` on the regular page, with its resolved party and the id the router would send it to. Expect SC and possibly FL/OH. **HALT if the router would route a box to an id that is not seeded**, since the HO 561 contract is that the sync writes only seeded special ids and never auto-creates one.

**P3 (report only) — the freeze's input.** Confirm `senate-SC-2026-R` is settled by the HO 560 predicate: past-dated **and** carrying at least one share. Record the current roster fingerprint (count, names, shares, `updated_at`). This is leg 2's before-image.

---

## §3 — the build

**C1 — the router.** In `lib/primary-candidates-scrape.ts`, replace the page-type gate with `<h5>`-based classification. A special-classified box yields the `-special-{party}` id, a regular one the base id, on every page type. `isSpecialElectionPage()` may remain as a diagnostic field but must no longer gate whether a box is parsed. Comment the inversion that made this necessary, with the SC case named, so nobody restores the symmetry check.

**C2 — reach the content.** `runSpecialPriorityPass` currently fetches only `senateSpecialPageUrl`, which 404s for SC. Add a fallback to the state's **regular** page when the special URL misses, still **gated on a seeded `-special-` row existing** for that state, which preserves HO 561's by-construction FL/OH safety. `senateSpecialPageUrl` itself is **not modified**.

**C3 — make the trigger reportable.** Change `runSpecialPriorityPass`'s return from `string[]` to a result object carrying `attemptedIds`, `fetchFailures`, `settledSkipped`, and the resolved source URL per attempt, and forward all of it into the cron payload. **This is not optional.** The WATCH names `fetchFailures` as its evidence and that field is currently structurally incapable of reading FAIL, which is the ledger's own "same-as-success" class living inside the instrument the ledger points at.

---

## §4 — falsification, three legs, all required

**Leg 1, the payoff.** A real run writes **10 rows** to `senate-SC-2026-special-R` matching the published field by name. Not a dry run.

**Leg 2, the freeze, fired deliberately.** After the run, `senate-SC-2026-R` must be byte-identical to P3's fingerprint. **A green diff is not the proof.** HO 600 already showed this row survives for reasons that have nothing to do with the guard, so instrument **which branch fired**: log whether `isSettled` was consulted and refused, versus never reached. If it was never reached, say so plainly and the freeze stays untested rather than being recorded as proven.

**Leg 3, FL/OH regression.** Fingerprint both states' rows before and after. Unchanged, or the router is wrong.

---

## §5 — guards

- **Do not modify `senateSpecialPageUrl`.** It is correct for FL/OH.
- **Write only seeded special ids.** Never auto-create a `-special-` row (HO 561 contract).
- **Never recreate `senate-SC-2026-special-D`.** HO 600 §4 C3 is a standing regression guard.
- **No Aug 25 runoff row in this HO.** HO 600 flagged the absence; it is a separate scoped change.
- **No falsification leg writes a known-wrong value to the production database** (SKILL, HO 585).
- Explicit pathspec staging, ancestry eyeball before push, `npm run typecheck` first, code and docs commits unmixed.

---

## §6 — out of scope, all filed by HO 600

Tim Scott's chip rendering an 08-11-26 countdown for a contest he is not in (the statewide proxy resolves any D/R member of a state; a real loop, not this HO). The 2026-08-05 12:00 primaries cron timeout. The Aug 25 runoff seed. `getPrimaryForRace`'s proxy semantics generally.

---

## §7 — close

Adopt HO 600 §4's replacement criterion into the backlog verbatim, retiring the unmeetable `{D,R}` one: **C1 roster of 10 by 2026-08-10** (reads FAIL today, which is the point), **C2 results with `vote_pct` and the HO 207 two-★ rule by 2026-08-13**, **C3 the D row does not exist, standing.**

Ship report: the three legs, the branch `isSettled` actually took, and the P1/P2 readings. Show the diff before pushing.
