# HO 592 — the clock-independent structural mismatch: a static parser diff, no reproduction required

**Numbering.** Take the next number from `docs/roadmap.md`'s latest pointer, which should now read *"Also notes now run through HO 590"* with *"Docs: HO 591."* That makes this **592**. HO 588 remains the parked absence-watch probe with its block owed. Confirm against the roadmap and `git log`, not this filename.

**This handoff builds nothing.** STEP 0 only: four measurements, then a hard HALT and a report. No fix code, no component edits, no config flips, no `e2e-prod.yml` change.

---

## §0 — Why the remaining lead is not a clock

HO 590 C5 measured prod `/` as served fresh per request (`X-Vercel-Cache: MISS`, `Age: 0`, `no-store`, `Date` advancing), so the render→hydration gap is sub-second, and the harness confirms `control(+0)` — that same gap — never fires. A `Date.now()` straddle cannot happen there. The tape and `lob-age` were real latent bugs and are fixed; neither was prod's mechanism. All ~42 prod `args[]=HTML` fires across `/`, the six `?stage=` variants, `/president` and `/members` remain unattributed, and the cause count is unknown.

So the surviving hypothesis has to be a structural mismatch with **no time dependence at all**. The strongest such mechanism, and the one this probe targets:

**H5 — data-dependent invalid HTML nesting.** The browser's HTML parser applies the spec's tree-construction algorithm to the server's markup *before React ever hydrates*: a `<div>` inside a `<p>` closes the paragraph and reparents; a block element inside a `<button>` or an `<a>` inside an `<a>` gets restructured; a `<tr>` without a `<tbody>` gets one synthesised; an SVG `<title>` with multiple children is normalised. React's client render then produces the **authored** tree, which no longer matches the **parsed** DOM → `args[]=HTML`.

Why it fits every constraint the clock hypothesis failed:

- **No clock** — survives a sub-second gap, so C5 doesn't kill it.
- **Intermittent** — fires only when the data produces the offending shape (a field that's empty on most rows, a chip that wraps, a title with two children instead of one), which is why it doesn't reproduce on demand.
- **Both hits** — nothing to do with cache serialisation, so it isn't the HO 533 class.
- **Growing route set** — any surface rendering the pattern with the right data joins the set.
- **Byte-identical message** — every structural mismatch is, in prod (589 M1).
- **Precedent in this repo.** React's own cause list names invalid nesting, and CBT has already been hit by this family once: the HO 473 multi-child SVG `<title>`. HO 574 re-checked that mechanism at `290e239` — but only at **the four sites then known**, and the component surface has grown substantially since.

**The instrument is the point: you do not need to catch it firing.** Invalid nesting is detectable *statically* from the server HTML. Fetch it, parse it with a spec-compliant parser, and any node the parser moves, drops, or synthesises is a latent mismatch — visible without an intermittent ever cooperating.

---

## STEP 0 — four measurements, read-only, then HALT

Script: `scripts/diagnostic/nesting-parser-diff-592.ts`, same idiom as the 589/590 diagnostics (`dotenv/config`, `npx tsx`, no writes). Commit it, then HALT.

### M1 — the parser diff, against prod, across all of `ROUTES`

For every route in `smoke.spec.ts`'s `ROUTES` — **not** the observed firing set; HO 574's scoping guard still stands and 590 showed the set is explained by mechanism, not by having stopped growing:

1. `fetch` the raw document from prod. **Send `ct_seen=1`** or `/` 307s to `/welcome` (`app/page.tsx:74`) and you'll diff the landing page instead of the dashboard — confirmed as a false lead in HO 591, don't re-create it.
2. Parse with `parse5` (it implements the HTML tree-construction algorithm; a lenient parser will silently agree with the source and report nothing).
3. Re-serialise and diff the parsed tree against the authored markup **structurally, not textually**.

Report per route: every node whose parent, position, or existence changed, with the enclosing element path and enough surrounding markup to identify the component.

Three things that will otherwise produce noise, so handle them explicitly and say you did:

- React SSR emits comment markers and `<!--$-->` / `<!--/$-->` Suspense boundaries. Normalise them out of the comparison rather than reporting each one.
- Attribute order, quoting, and self-closing forms are parser normalisations, not mismatches. Compare **tree shape and node identity**, nothing else.
- A route serving zero rows can hide the pattern entirely. Record row counts alongside each result so an empty pass is distinguishable from a clean one.

### M2 — the SVG `<title>` re-audit, repo-wide

HO 473's mechanism was re-confirmed at four sites at `290e239`. Re-derive the site list at HEAD and check **every** one, not the historical four. A `<title>` inside an SVG with more than one child node — including a text node adjacent to an interpolation, which is easy to introduce accidentally — is the known-live instance of this class in this codebase.

### M3 — the remaining non-clock nondeterminism inventory

590's inventory targeted render-time clocks. Widen it to sources that are structural and time-independent, in **client components at render**: `Math.random()`, iteration over a `Set`/`Map`/`Object.keys()` where insertion order isn't pinned, `Array.prototype.sort` without a total-order comparator, and any conditional whose branch depends on a value not present in the RSC payload.

Same table shape as 590 M3: file:line · source · render-time or effect-time · **gates a node, or only text/class** · which routes render it. Only node-gating rows matter. Report the full table anyway; a row marked safe is a result.

### M4 — does prod's route set match H5's prediction?

H5 predicts the offending pattern is present in the SSR HTML of the firing routes and **absent** from routes that have never fired. Cross the M1 findings against the known prod firing set (`/`, six `?stage=` variants, `/president`, `/members`) and the rest of `ROUTES`.

- Findings on firing routes only → strong support, and the fix HO scopes off the specific nodes.
- Findings everywhere including never-firing routes → weak; the pattern is present but something else gates whether it mismatches. Say so.
- **No findings anywhere → H5 is falsified**, cleanly, in one pass. Record it as a result and hand the loop back with one fewer hypothesis. That is a good outcome, not a failed probe.

---

## HALT

Commit as `diag(e2e): HO 592 STEP 0 — static nesting parser diff`, then stop. Report M1–M4 with the per-route table and H5's verdict.

## Scope guards

1. **No fix code.** The diagnostic commit is the only commit.
2. **All of `ROUTES`**, not the observed firing set.
3. **No `suppressHydrationWarning`**, no new `e2e/console-noise.ts` entry.
4. **No `e2e-prod.yml` change**, and nothing added to the unattended runner — this is a manual probe like the 590 harness.
5. **Do not close or narrow the `pageErr` OPEN LOOP.** It closes on a named cause for the **prod** fires plus green runs, and a probe that falsifies a hypothesis has named nothing.
6. **No unrequested edits to SKILL.md.** If the probe turns up something SKILL gets wrong, report it and let it be scoped — the review ref exists for exactly that.
