# 379 — Playwright smoke crawler (build + first run, no CI yet)

**Self-claim:** if `docs/handoffs/379-*.md` exists, bump to the next free number (`ls docs/handoffs/ | sort -V | tail`) and rename before starting.

**Scope:** stand up one Playwright smoke crawler, run it once against the live deploy, report what it catches. Do not commit, do not wire it to CI. We decide both after seeing the first run. Per repo rule, show the added files / diff and hold for approval before any commit.

## Goal

A single crawl spec that visits every route and, per page, asserts HTTP 200, zero failed network requests, zero console errors, then captures a screenshot. Plus a handful of targeted interactions on the surfaces that actually regress. This targets the bug family that keeps recurring here: cold-start 500s, stylesheet 404s rendering pages unstyled, redirects dropping params, popovers clipping, clicks hitting nothing. None of which a unit test catches.

## Resolved premises — do not re-derive

- **Run against the live Vercel URL, not localhost.** The worst bugs are egress- and cold-start-specific: FRED is blocked from Vercel egress, Turso serves cold query plans on first hit. Localhost reproduces none of it. Default `BASE_URL` to the prod deploy (`https://congressional-terminal-chi-silk.vercel.app`), env-overridable for previews.
- **200 is not enough. Assert zero failed requests.** A stale `.next` serves a stale CSS hash, giving a 404 on `layout.css`, so the page returns 200 but renders unstyled. The tell is the stylesheet 404, so the network assertion (no request resolves 4xx/5xx) is what catches the unstyled-page class, not the status of the document itself.
- **The /welcome gate blocks the crawl.** A fresh Playwright context has no cookie, so every route redirects to /welcome, exactly the param-drop seen on `?stage=president`. Grep the actual gate mechanism (cookie name, or what "Enter terminal" sets) and clear it in a setup step before the route assertions, or every test just re-tests /welcome. Confirm the mechanism from live code; I don't know it.
- **Loose content assertions only.** The corpus syncs daily, markets tick, "43 moved/7d" moves. Assert structure and presence (the movers list exists, the tape renders, the bill panel has a sponsor line), never specific counts or values. Volatile-number assertions flap.
- **Enumerate routes from the live `app/` tree, don't trust this list.** Known surfaces to seed: `/`, the stage-filtered home variants (`?stage=committee|floor|other|president|enacted`), `/bill/[id]` (pick a real ID from the feed), `/members`, `/races`, `/hearings`, `/reports`. Grep `app/` for the real set and anything missed.

## Build

- `@playwright/test`, TypeScript, chromium headless (one browser is enough for smoke). `npx playwright install chromium` as setup.
- `playwright.config.ts` with `baseURL` from `process.env.BASE_URL`, prod deploy as default.
- One spec. Grep for an existing test dir first and follow convention; assume greenfield if none. Keep it isolated from the build.
- Per route: `goto`, assert 200; collect `page.on('requestfailed')` plus any `response.status() >= 400` and assert empty; collect `page.on('console', m => m.type() === 'error')` and assert empty; then `page.screenshot()` into `test-results/`.
- **No visual-diff baselines this pass.** Capture screenshots for eyeballing; don't set up `toHaveScreenshot` golden files yet. They need curated baselines and flap on a first run. Visual regression is a later step.

## Targeted interactions (the surfaces that break)

- Expand a bill row, assert the unified expand panel opens.
- Open a race drawer, assert it opens and stays confined (not clipped past the viewport/container, a known recurring issue).
- Trigger a B2 markets hover, assert the hover card appears and isn't clipped.
- Click each Stage Distribution row, assert it filters or shows a clean empty state. PRESIDENT is currently empty (that's what 378 is probing); flag if clicking it errors rather than empty-states.

## Report back

- The route list crawled (and anything in `app/` I didn't seed).
- Per route: 200 / failed-requests / console-errors. Flag every failure with the route and the offending request or message.
- Interaction results.
- Whether it reproduced the /welcome gate dropping `?stage=` params (confirms the deep-link bug).
- Screenshots location.
- Your read: what it caught, and whether it's worth wiring to a post-deploy GH Action.

Single pass, not a load test. Hold the commit for approval.
