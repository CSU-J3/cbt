# HO 450 — Member-hub sponsored-amendments section on `/members/[bioguideId]`

The second amendments surface, off the same HO 447 layer. HO 448 put amendments on the bill hub keyed by `amended_bill_id`; this puts them on the **member** hub keyed by `sponsor_bioguide_id` — the amendments a member authored. It's the inverse projection of the bill-hub section and the cheapest of the three banked forks (the pattern is proven live).

**No probe, no precompute — same reasoning as HO 448.** Amendments is bills-scale (~6,800 rows total); a per-member seek behind `idx_amendments_sponsor` hydrates instantly even for the heaviest amender (a senator's vote-a-rama pile is still ≤ a few hundred rows). Plain live `unstable_cache` query, tag `amendments`, no `dashboard_state` blob.

**The inversion that matters:** on the bill hub the sponsor varied and the bill was fixed, so rows led with the sponsor. Here the sponsor is fixed (it's their page), so rows lead with the **amended bill** (linked to `/bill/[id]`). Different projection → a new `getMemberAmendments` query and a new `MemberAmendmentRow` component; the disposition dot + purpose-clamp grammar is shared, `deriveDisposition` is already module-level in `lib/queries.ts` (reuse it, don't redefine).

---

## The query — `getMemberAmendments(bioguideId)` in `lib/queries.ts`

Mirror `getBillAmendments` (same file, ~2893): live, `unstable_cache`, `tags: ["amendments"]`, `revalidate: 3600`, try/catch → null. Seek on `sponsor_bioguide_id`, LEFT JOIN `bills` for the amended-bill label/title (replacing the members join — sponsor is the page's member), keep the self-join for the sub-amendment parent label. Return null when empty (member authored no amendments → section hides, the bill-hub convention).

```ts
export interface MemberAmendment {
  id: string;
  label: string;                       // "SAMDT 2137" — `${amendment_type} ${amendment_number}`
  amendmentType: string;               // SAMDT | HAMDT | SUAMDT
  amendedBillId: string | null;        // link target: /bill/{amendedBillId}
  amendedBillLabel: string | null;     // "HR 1" — via the codebase's existing bill-label convention (BillRow), or from bill_type/bill_number
  amendedBillTitle: string | null;     // bills.title, nullable
  purpose: string | null;
  description: string | null;
  latestActionText: string | null;
  latestActionDate: string | null;
  submittedDate: string;
  amendsLabel: string | null;          // resolved parent label for sub-amendments, e.g. "SAMDT 8"
  disposition: "agreed" | "failed" | "other";  // reuse the module-level deriveDisposition()
}
```

```sql
SELECT a.id, a.amendment_type, a.amendment_number, a.amended_bill_id,
       a.purpose, a.description, a.latest_action_text, a.latest_action_date,
       a.submitted_date, a.amends_amendment_id,
       b.bill_type   AS amended_bill_type,
       b.bill_number AS amended_bill_number,
       b.title       AS amended_bill_title,
       pa.amendment_type   AS parent_type,
       pa.amendment_number AS parent_number
FROM amendments a
LEFT JOIN bills      b  ON b.id = a.amended_bill_id
LEFT JOIN amendments pa ON pa.id = a.amends_amendment_id
WHERE a.sponsor_bioguide_id = ?
ORDER BY COALESCE(a.latest_action_date, a.submitted_date) DESC, a.amendment_number DESC
```

`rs.rows.length === 0 → return null`. Same `COALESCE(...)` recency as the bill hub. Return **all** rows unLIMITed (bills-scale, so cheap, and the section header needs the true count) — the component caps the render. `amendedBillId` is the `/bill/[id]` link target directly (it's already the `119-hr-1` id). Derive `amendedBillLabel` the way `BillRow`/the bills list already formats a bill label from `bill_type`/`bill_number` (match the existing convention; don't invent a new format).

---

## The component — `components/MemberAmendmentRow.tsx`

A single row, mapped by the page (the member-page idiom — like `MemberVoteRow` / `CommitteeAssignmentRow`, the page owns the `<section>` shell). **Not** self-boxing like `BillAmendments` (that was the bill page's Divider grammar). Fed one `amendment: MemberAmendment`.

- **Disposition dot** (leading, ~8px): green `--vote-yea` = agreed, red `--vote-nay` = failed, `--text-muted` = other. Same palette as HO 448's bill-hub dot — reuse it, don't fork a new one.
- **Line 1** (the anchor): `{label}` (mono, `tabular-nums`) then the **amended bill** — `{amendedBillLabel}` linked to `/bill/{amendedBillId}` (party-neutral link style), followed by `{amendedBillTitle}` clamped to 1 line in `--text-muted`. When `amendedBillId` is null (rare untracked ref), render the label plain, no link.
- **Line 2:** `purpose ?? description`, `text-[13px]` `--text-secondary`, clamp 2 lines; omit the line when both are null.
- **Line 3:** `latestActionText` + ` · ` + `latestActionDate`, `text-[11px]` `--text-muted`; when absent → `Submitted {submittedDate} · no floor action yet`.
- **Sub-amendment note:** when `amendsLabel` present, a small `↳ amends {amendsLabel}` in `--text-muted` (flatten, ~2.5%).

Match the member page's row padding/dividers (`px-4`, `0.5px solid var(--border-soft)` between rows) so it sits flush with the Committees/Voting-record rows above and below.

---

## The section insert — `app/members/[bioguideId]/page.tsx`

- Add `getMemberAmendments(bioguideId)` to the existing `Promise.all` (beside `getMemberBills`/`getMemberVotes`); destructure `sponsoredAmendments`.
- Place the section **immediately after the Sponsored bills `</section>` and before Committees** — the authoring pair (bills a member sponsored + amendments a member sponsored, the two forms of member-authored legislative text, read together before committees/votes).
- Conditional render (hide when empty, the `{scorecard ? … : null}` idiom already on this page). Mirror the Sponsored-bills section shell exactly — the `mt-6 border` box, the `bg-panel` header bar with the `text-[12px] uppercase tracking-[0.5px]` `<h2>`:

```tsx
{sponsoredAmendments ? (
  <section className="mt-6 border" style={{ borderColor: "var(--border-strong)" }}>
    <div
      className="flex items-baseline justify-between px-4 py-3"
      style={{ backgroundColor: "var(--bg-panel)", borderBottom: "0.5px solid var(--border-strong)" }}
    >
      <h2 className="text-[12px] uppercase tracking-[0.5px]" style={{ color: "var(--text-secondary)" }}>
        Amendments sponsored ({sponsoredAmendments.length})
      </h2>
    </div>
    <div>
      {sponsoredAmendments.slice(0, MEMBER_AMENDMENT_LIMIT).map((a) => (
        <MemberAmendmentRow key={a.id} amendment={a} />
      ))}
    </div>
    {sponsoredAmendments.length > MEMBER_AMENDMENT_LIMIT ? (
      <div className="px-4 py-3 text-[11px] uppercase tracking-[0.5px]" style={{ color: "var(--text-muted)" }}>
        {sponsoredAmendments.length - MEMBER_AMENDMENT_LIMIT} more
      </div>
    ) : null}
  </section>
) : null}
```

`MEMBER_AMENDMENT_LIMIT = 60` (mirrors the bill-hub cap; store == the true count in the header). No "view all" link — there's no member-amendments route yet (the standalone `/amendments` surface is the banked fork); add one when it ships. Header count is `.length` = the true unLIMITed count, so it stays honest against the capped render.

---

## Explicitly NOT in 450 (scope guard)

- **No standalone `/amendments` surface, no status model** — both stay banked (QUEUED). The display-only disposition dot here is the same best-effort scan as HO 448, not the persisted model.
- **No new query cost** — live seek on `idx_amendments_sponsor`, no blob, no cron touch, no migration.
- **No member-stats amendment count** — the header count comes from the query array, not a new `getMemberStats` field (don't touch the stats query).

---

## Git discipline

- Plan → diff → **wait for approval.** No auto-commit.
- **Explicit pathspec:** `lib/queries.ts` + `components/MemberAmendmentRow.tsx` + `app/members/[bioguideId]/page.tsx`. All additive; nothing pre-existing depends on the new query.
- Eyeball ancestry before push: one commit riding, clean fast-forward, nothing behind, nothing unrelated staged, the concurrent session's files (`RaceCard.tsx` / `CompetitiveRacesBlock.tsx` / `CompetitiveRacesStrip.tsx` / `globals.css`) untouched and history preserved.
- Commit message: `feat(amendments): sponsored-amendments section on /members/[id] (HO 450)`
- Prod-verify before we call it done: a heavy amender (a senator with a vote-a-rama pile — e.g. pick the top `sponsor_bioguide_id` by count) renders the capped section with dispositions and bill links; a member with a handful renders the full short list; a member with zero (most House members) 200s with the section absent. Report the remote SHA.

---

read docs/handoffs/450-member-amendments-surface.md and follow it
