# HO 435 — LDA lobbying data layer

## Why
The HO 434 probe cleared the source: lda.gov API live, `lobbying_activities` embedded in the
filings list response, bill-number join ~97% where a number is present. This builds the ingest
substrate. Surface-agnostic on purpose: it stores what both planned surfaces (bill-keyed
lobbying + issue-code "what's being lobbied") need, so the surface HO (436) can go either
direction without a re-ingest. No user-facing surface in this HO.

## Blocking prereq (Corey)
Register an API key at https://lda.gov/api/register/ (then POST `/api/auth/login/` for the
`key`). Put it in `.env` as `LDA_API_KEY`. The anonymous throttle (429 after ~15 requests, one
ECONNRESET under fast pulls) makes any backfill impossible. Do not attempt the backfill
anonymous.

## Scope bound
Current Congress only (119th → filing years 2025 and 2026). The LDA filings that matter are the
ones lobbying bills we track. Don't backfill all-time.

## Source facts (from HO 434, don't re-derive)
- Base: `https://lda.gov/api/v1/`. Auth header: `Authorization: Token <LDA_API_KEY>`.
- Filings list: `filings/?filing_year={y}&filing_type={Q1..Q4}`, DRF paging
  `{count, next, previous, results}`, `page_size` capped at 25 server-side, order by `dt_posted`.
- `lobbying_activities` is embedded in each list item. No per-filing fetch needed for the join.
- Each activity: `general_issue_code`, `general_issue_code_display`, `description` (the
  specific-issues free text where bills appear), `government_entities`, `lobbyists`.
- Filing carries: `filing_uuid`, `filing_type`, `filing_year`, `filing_period`, `registrant`
  (name + id), `client` (name + id), `income`, `expenses`, `dt_posted`.
- Volume is large (Q2-2025 ≈ 20,920 filings). Two years of quarters is high tens of thousands
  of filings; paginate with a cursor, don't hold it all in memory.

## Tables (propose exact DDL in plan mode)
Three additive tables, no touch to existing schema:
1. `lda_filings` — `filing_uuid` PK, `filing_type`, `filing_year`, `filing_period`,
   `registrant_name`, `registrant_id`, `client_name`, `client_id`, `income`, `expenses`,
   `dt_posted`. Idempotent upsert on `filing_uuid`.
2. `lda_activities` — synthetic key `(filing_uuid, activity_ordinal)` (the API activities are
   an unkeyed array; assign the ordinal on ingest), `general_issue_code`,
   `general_issue_code_display`, `description` (store the FULL free text: it's the raw signal
   and phase-2 title-matching needs it), `bill_ids` (JSON array, derived at ingest, see below).
3. `lda_activity_bills` — `(filing_uuid, activity_ordinal)` FK + `bill_id` (the normalized
   `{congress}-{type}-{number}` key). One row per (activity, bill) for the joinable IDs.
   Activity-granularity so a bill link carries its issue code + description.

## Ingest logic
- Reuse `lib/bill-id-extract.ts` (`extractBillIds`) unchanged. It produced the `119-s-657`
  format that joined at ~97%. Run it over each activity's `description` at ingest, store the
  result in `lda_activities.bill_ids`, and write the subset that resolves to a real `bills`
  row into `lda_activity_bills`. Store the issue-code bucket always, the bill link only when
  present, so the issue-code surface works even where no bill parses.
- Spam-filer skew: the probe found one registrant ("STATE OF LOC NATION") citing HR 40 across
  ~9 activities of a single filing. Don't dedup at ingest (store the truth), but the surface
  will need to weight by distinct filer rather than raw activity count. Flag it, don't solve it
  here.

## Sync + cron
- `sync:lda` script (matches `sync:fec` / `sync:crosswalk` / `sync:ideology`): paginate the
  current-Congress quarters, upsert, pace requests and honor `Retry-After` (the probe saw 429s
  even before saturation, so pace even authenticated). Resumable cursor on `dt_posted` so a
  re-run only fetches filings posted since the last run.
- Run it manually once to do the FULL backfill and verify, before any cron. The full backfill
  is thousands of paged requests and will not fit a 60s function; that's why it's a manual/local
  run, not a cron. Report row counts + the live join rate against the real `bills` corpus.
- Then wire `/api/cron/lda` weekly, calling the same `sync:lda`. After the manual backfill the
  cursor makes each weekly run incremental (only new/amended filings), which fits inside
  `maxDuration: 60`. LD-2s post quarterly with an amendment tail; weekly is plenty, no sub-daily.
  If even an incremental run risks the 60s wall, page in bounded batches across runs off the
  cursor rather than raising the limit.

## Diagnostic
A read-only coverage diagnostic (the standing data-layer pattern): filings ingested per quarter,
total activities, % of activities with a parsed bill_id, join rate to `bills`, distinct
registrants/clients, and the top issue codes by activity count. This confirms the backfill and
re-checks the probe's rates at full scale.

## Out of scope (banked)
- The surface itself (bill-keyed vs issue-code-first, placement) → HO 436, Corey's call.
- Title / short-title matching to recover the acronym-named bills (NDAA, appropriations, etc.)
  → its own phase-2 HO. In your plan, say whether `bills` already stores short titles, since
  that decides whether an exact short-title match is cheap phase-2 or needs a title-enrichment
  step first.
- LD-203 contributions (`contributions/`) for a future money/donor surface.

Diagnose first: propose the DDL + the sync structure + the cron wiring, show it, wait for
review. No commits until I approve the diff. Two-commit separation (schema/sync as one, cron
wiring as another if it helps).
