# HO 587 — doc sweep for HO 586 (docs only, no code)

Delivery note: this file supersedes the carry-list version of the same name. The full spec was issued in chat and didn't survive the relay (the HO 508/537 swallow, opposite direction), so it ships as a file. The four captured additions are folded in below, attributions preserved.

## Procedure

Docs-only; code and docs never mixed; SKILL its own commit. Push to `587-review` and halt — the append-only roadmap block and the SKILL edit get read out of the repo (CRLF churn check included) before main fast-forwards and the ref is deleted. `docs/roadmap.md` is authoritative for the HO number; if it disagrees with this filename, the roadmap wins.

## Roadmap — one append-only "Also (HO 586)" block

Frozen pointer: this block ends **"Also notes now run through HO 586." Docs: HO 587.** The prior (584) block is untouched — the sweep's grep gate expects it to still read 584.

- Entered as "the LA chip shows May 16" — the consequence HO 584 created read-side — and ended as the general district-first resolution. Record the promotion AND what licensed it: M3 across all 534 members came back c=0 (no non-null → null), senate=0 (proxy path byte-identical), every (b) date-change exactly the LA six, and the 160 (a) fills being precisely the HO 576 top-two / no-Senate-seat carry-forward, closed here as a side effect.
- The three-touch shape: query (district-first branch with the tie-break scoped WITHIN a temporal class), caller (`page.tsx` passes `member.district` instead of hardcoded null — the M1 finding that the fix couldn't live in `queries.ts` alone), render (the label over a three-value `party` column: D→Dem, R→Rep, anything else no party word).
- At-large: `members.district` is NULL for the six at-large states while `primaries.district` stores "00"; mapped at the query boundary (null-means-at-large for a House member; a stray null in a multi-district state finds no "00" row and degrades safely to the proxy). Six members sat invisible in M3's "unchanged" bucket until M6 instrumented which branch fired.
- The ORDER BY correction, attributed correctly: the review spec said "exact party wins" without scoping it to a temporal class, and it shipped as the first sort key — a stale past row could outrank a live future one. The mandated re-run caught it; the spec was wrong, not the implementation.
- The countdown note: `primaryDays` (the 30-day amber countdown) now runs for ~430 more members than before this HO. LA countdowns appearing in early October, and CA/WA/AK ones on their own schedules, are expected behavior — the answer is written down here so it never gets filed as a bug.
- Verification COMPLETE on prod at a1a97a8: four eyeballs — Carter LA-2 / Fields LA-6 → "Primary: 11-03-26" (no party word), Moran TX-1 → "Primary Rep: 03-03-26", McBride DE (NULL→"00") → "Primary Dem: 09-15-26", Cornyn TX senate proxy byte-identical. No review-ref prod lag (~52s promotion).

## Oddities — four entries (newest-first per file convention)

1. **An outcome gate cannot see an unfired branch.** M3 diffed 534 chip outcomes and bucketed five silent at-large fallbacks as "unchanged" — the branch never fired, so the output never moved. M6 caught them only by instrumenting WHICH branch ran. Same family as the untriggered-guard rule (a detector that works and one that structurally can't fire emit identical green): instrument the branch, not the output.
2. **A reviewer-injected defect, caught by the mandated re-run.** "Exact party match wins, 'open' second" arrived from review unscoped to a temporal class and was implemented faithfully as the first sort key, which would let a stale PAST exact-party row outrank a live FUTURE 'open' row — defeating the chip's "next primary" semantic. The re-run-after-change discipline caught it. Record that the spec was wrong, not the implementation, and that faithful implementation of an under-specified spec is a defect path the re-run exists to catch.
3. **A two-branch render over a three-value column — second instance of the HO 420 class.** `party === "D" ? "Dem" : "Rep"` sent 'open' (and 'I') to "Rep", exactly as `members.party='I'` once read as a bug. Binary code over non-binary data keeps re-emerging; the fix is the branch, never the case — special-casing 'open' would have left 'I' still rendering "Rep".
4. **"Populated → empty" was "wrong-roster → honest-empty."** The 19 same-date roster-vanish cases read as a loss only under the assumption that the statewide Senate field was ever the correct answer for a House member. It wasn't; the empty district row is the honest state. (Moot for the chip — the consumer renders date only — but the framing matters for `/primaries` and `/electoral`, where the 77-row debt lives.)

## Backlog

- **CLOSE** the P2 LA chip item — criterion met on prod (the chip shows Nov 3 for LA House members).
- **CLOSE** the HO 576 carry-forward ("senate-proxy can't serve top-two / no-Senate-seat states") — the 160 (a) fills are its close; cite the M3 table as the evidence.
- **FILE P3:** 77 of 560 past-dated house rows carry 0 candidates (~14%). Composition ran down in HO 586 M5: 11 are the incumbent's-party primary being uncontested (honestly no votebox — the district page parsed fine), 8 are both-party-empty district holes (AR-01, SC-07, AL-02, ME-01, ME-02, NC-02, AL-07, AR-03) — pre-existing HO 563-class residue or dual-uncontested, undetermined which. Lives on `/primaries` + `/electoral`, independent of 586. *Instrument:* the count of past-dated house rows with zero candidates. *Close:* each of the 8 either explained as genuinely uncontested or traced to a parse gap.
- **FILE low:** independents get no chip — the caller gates `party ∈ {D,R}` before calling. Kiley (`party='I'`) is the live instance; the data is correct per HO 420/422, and 586 makes the gap more conspicuous by giving nearly everyone else a working chip. *Close:* a decision — either an intentional-and-documented gate, or an all-party chip for I members.

## SKILL.md (own commit, never mixed)

- **The `getPrimaryForRace` two-branch convention:** district-first for House members (at-large NULL→"00"), statewide senate proxy ONLY on no-row-found — never on found-but-empty (falling back on empty would silently paper over the 77-row gap and make it unmeasurable). Include the invariant that keeps the null→"00" degrade safe: **no "00" row exists outside the six at-large states** — if one ever appears in a multi-district state, the mapping stops degrading and starts matching wrongly. State the ordering rule: future-first is the primary key; party preference is a tie-break within a temporal class, never across one.
- **The chip-label rule:** `primaries.party` is a three-value column (D / R / 'open'); the render shows a party word only for exact D or R. Do not special-case 'open'.

## AK accounting note (fold into the roadmap block or oddities, writer's choice)

The at-large fix's M3 delta split +2 fills / +4 same-date moves rather than the expected +3/+3 because Begich (AK) already carried a `senate-AK-2026-R` proxy — so AK is a same-date row-move, not a fill. Benign; recorded so the arithmetic is explained.
