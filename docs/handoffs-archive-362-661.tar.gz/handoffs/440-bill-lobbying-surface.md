# HO 440 — bill-keyed lobbying on `/bill/[id]` (hybrid precompute + live)

## What this is

The bill-keyed lobbying surface — the other fork of the LDA arc. HO 439's cost probe returned the verdict: the worst-case bill query is **44.5s cold** (4.5× the 10s `getDb` cap), all of it in the random `lda_filings` row-fetch (seek 461ms, aggregate 30ms — the predicted shape). The fan-out is a **fat tail with an extreme outlier**: 9,179 bills have ≥1 link, p50 = 6, p90 = 27, p99 = 159, max = 8,048 (119-hr-1). ~1% of bills (~92) run 159→8,048 filings; 99% are ≤159.

So: **precompute the fat tail, serve the long tail live.** Branch 3 (precompute, near-free on the existing rollup pass) for bills above a filing threshold; branch 1 (live through `getDb`) for everything below. Not the recent-N cap (branch 2) — capping 119-hr-1 to recent-200 would rank firms over 2.5% of its filings, corrupting exactly the high-traffic bills.

**Correction to carry:** HO 435's "~1,506 distinct" for 119-hr-1 was distinct *registrants*, not distinct *filings*. Real distinct filings = **8,048** (~5× heavier). Size the blob against 8,048. (This goes in the HO 441 oddities entry — not this handoff.)

---

## Phase 1 — data + cron

### Share the table read

`computeLdaRollup` (`lib/lda-rollup.ts`) does its three sequential reads inline and holds `filings` / `billsByUuid` / `linkedUuids` / `uuidsByCode` / `codesByUuid` in memory. The bill drill needs the **same reads** — it must NOT do a second ~96s scan (that would blow the 220s `ROLLUP_RESERVE_MS` gate). Extract the read so both the issue rollup and the bill drill consume one pass. Shape (Code's call on exact factoring):

- `readLdaTables(db)` → the shared intermediate maps.
- `computeIssueRollup(tables)` → the existing `LobbyingRollup` (issue stats + bars + per-code drill), **output byte-identical to current prod**.
- `computeBillDrill(tables, threshold)` → new (below).

**Verify the issue-rollup blob is unchanged** — regenerate (`npm run lda:rollup` / the cron path) and diff the new `lda_lobbying_rollup` blob against the current prod blob. This is the HO 428-A byte-identical-refactor discipline; a diff means the extraction changed behaviour.

### `computeBillDrill(tables, threshold)`

From the already-held maps, group by `bill_id` (from `billsByUuid` / the bill-link read), deduped to **distinct `filing_uuid` per bill**. Keep only bills with **≥ threshold** distinct filings. Per qualifying bill, produce the same shape the per-code drill produces (`IssueDrill` minus the code fields):

- `distinctFilings`, `distinctClients`
- `topFirms` / `topClients` — ranked by **distinct filings** (the HO 435 rule), `DRILL_TOP_N`
- `recent` — `DRILL_RECENT_N`, `FilingSummary[]` (reuse `rowToFilingSummary` / the existing hydration already in the maps)

Add a `BillDrill` type mirroring `IssueDrill`. `writeLdaBillDrill(db, drill)` → a **second** `dashboard_state` blob, key `lda_bill_drill` (a `Record<billId, BillDrill>` + `generatedAt`). Keep it separate from `lda_lobbying_rollup` so `/lobbying`'s 286KB read stays lean.

### Threshold: ≥150 distinct filings (my call — confirm by measurement)

The p99 knee is 159, so ≥150 precomputes ~the top 1% (~92 bills) — exactly the ones a live query can't serve — and everything ≤149 goes live at ≤1 hydrate chunk (~1–4s cold per the probe's per-chunk math). Before locking it:

- Report the **qualifying-bill count** and the **`lda_bill_drill` blob size (KB)** at ≥150.
- **Time a ~149-filing boundary bill live cold** (one below the threshold). The probe found warm ran 2× cold (high round-trip variance), so confirm the boundary bill is *comfortably* under the 10s cap, not just under the median. If it isn't, **nudge the threshold down** (e.g. ≥100) until the boundary is safe. Don't assume 150 — verify it.

### Cron wiring

In `app/api/cron/lda/route.ts`, after `writeLdaRollup`, inside the **same budget gate** (`msLeft >= ROLLUP_RESERVE_MS`): call `computeBillDrill` on the maps already in memory + `writeLdaBillDrill`. It piggybacks the read, so added cost is one JS grouping pass + one atomic upsert — negligible. Keep the single `revalidateTag("lda")`. Fold the bill-drill outcome into the existing `rollup` payload / chronic-err logging (non-fatal; never fails the sync). Log the qualifying-bill count like the existing `${Object.keys(blob.drill).length} drills` line.

---

## Phase 2 — query + surface

### `getBillLobbying(billId)` (`lib/queries.ts`)

Mirror `getLobbyingRollup`'s idiom (`unstable_cache`, `revalidate: 3600`, tag `"lda"`, keyed by `billId`), with a live fallback:

1. Read the `lda_bill_drill` blob; if `billId` is present (above threshold) → return it. O(1).
2. **Miss → live drill through `getDb`** (the bill is below-threshold-with-links or zero-link): seek `SELECT filing_uuid, activity_ordinal FROM lda_activity_bills WHERE bill_id = ?` → distinct uuids. If 0 → return `null`. Else fetch filing rows + `hydrateFilings` (the exact bounded-IN pattern `getRecentFilings` uses) and aggregate to the same `BillDrill` shape. Below-threshold → fast (≤1 chunk); zero-link → the seek returns nothing → `null`.

Below-threshold bills never need a blob entry — they fall through to the live path. Zero-link bills return `null` and the section hides.

### `/bill/[id]` section

Add `getBillLobbying(bill.id)` to the existing `Promise.all` (line 129). Render a **LOBBYING** section using the page's own section template — `<Divider />` + `<div className="mb-2 text-[12px] uppercase tracking-[0.5px]" style={labelStyle}>Lobbying ({n} filings)</div>` + content — placed **after Hearings, before Summary** (my call: it belongs in the activity cluster, above the descriptive block; move it if you'd rather). Content mirrors the `/lobbying` drill:

- A stat line (distinct filings · distinct clients).
- Top firms + top clients — reuse `components/IssueDrill.tsx` if its props fit the `BillDrill` shape; otherwise mirror its top-firms/top-clients rendering. Firms/clients are **plain text** (no registrant/client hub exists to link to — same as `/lobbying`).
- Recent filings via `components/FilingRow.tsx` (the existing reusable row).
- A `see all lobbying →` out to `/lobbying`.
- `null` → render nothing (no empty state; a bill with zero lobbying just omits the section, like Committees/Hearings do at count 0).

---

## Constraints / discipline

- No auto-commit — propose the plan, show diffs, wait for approval.
- Explicit-pathspec staging (a concurrent session may be touching other files — stage only what this HO changes).
- **Commit seams** (propose the split; two-commit discipline): (1) the `lda-rollup.ts` read-extraction refactor, issue-rollup byte-identical verified; (2) `computeBillDrill` + `writeLdaBillDrill` + cron wiring; (3) `getBillLobbying` + the `/bill/[id]` section. Refactor separate from feature, data separate from surface.
- **SKILL.md untouched** — behind the self-mod guard; the blob-contract + threshold updates land in the HO 441 doc sweep, not here.
- Threshold **confirmed by measurement**, not assumed (§ Phase 1).

## Banked for HO 441 (doc sweep — not this handoff)

Roadmap "Also (HO 439–440)" block; oddities entry (the 1,506-was-registrants-not-8,048-filings correction + the hybrid-threshold rationale + the fat-tail distribution); SKILL blob-contract update (second blob `lda_bill_drill`, the threshold, the live-fallback); backlog reconcile (439 was the cost probe, surface is 440 — the banked "HO 439 = bill-keyed lobbying" note slides to 440, HO 418 stale-bank precedent).
