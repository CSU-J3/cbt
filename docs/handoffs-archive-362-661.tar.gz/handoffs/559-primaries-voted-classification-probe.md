# HO 559 — primaries VOTED classification + re-poll: STEP 0 (read-only)

The BANKED pair "AWAITING RESULTS / date-driven VOTED classification (card + map bands)" plus "Forward-sync re-poll of voted-but-NULL contests (~6-week window)". Both entries were written before HO 333 consolidated Races+Primaries onto `/electoral`, and **both of their stated mechanisms look wrong at HEAD.** This HO measures that. It builds nothing.

This is the HO 512 / 529 / 546 rule again: a backlog line's stated mechanism is a claim, and here two claims are load-bearing for a build that would otherwise edit unreachable code.

## §0 — Preconditions

1. `git fetch && git status` clean, `main` even with `origin/main`, `git rev-parse HEAD` = `754569f`.
2. `npm run typecheck` clean before you touch anything.
3. Read, in this order: `lib/cartogram-data.ts` (the PRIMARIES block, ~L160–258), `components/CartogramShell.tsx` (the `variant` fork, `primariesFill`, `PrimariesLegend`), `components/PrimaryTimeline.tsx`, `components/PrimaryRow.tsx`, `components/PrimaryMapCard.tsx`, `components/PrimaryDistrictCard.tsx`, `components/ElectoralBoard.tsx`, `lib/primaries-sync.ts` (`buildScrapeUnits` / `runPrimariesCronTick`, ~L1257–1456), and `getUpcomingPrimaries` / `getPastPrimaries` in `lib/queries.ts` (~L1493–1528).

## §1 — The two suspect premises, stated so the probe can kill or confirm them

**Premise A — "the card + map bands classify VOTED by results-presence, so they misrender past-but-uningested contests."** True as written in June. What I read at HEAD: `buildPrimariesCartogram` has **zero call sites**; `CartogramShell` is instantiated once (`ElectoralBoard.tsx:103`) with `variant="races"`, so `primariesFill` / `PrimariesLegend` / the `PrimaryMapCard` pinned card sit behind a variant nothing passes; and `PrimaryRow` + `PrimaryDistrictCard` appear only inside a **comment** in `ShareBar.tsx`. Meanwhile the surface that IS live on `/electoral`, `PrimaryTimeline`, already classifies with `c.date <= todayISO` (`PrimaryTimeline.tsx:122`) — the exact date-driven model the backlog item asks for. If that reading holds, the item's build target is dead code and the item's model already ships where it matters.

**Premise B — "a slow/mid-count state is never re-polled."** What I read at HEAD: `runPrimariesCronTick` walks a cursor over `buildScrapeUnits()` (calendar + 35 Senate states + every House district) and **wraps to 0 forever**, and each unit's sync does `DELETE FROM primary_candidates WHERE primary_id = ?` then re-inserts. That is a re-poll, unconditionally, on a rolling basis. So the real question is not "does it re-poll" but **how long the cycle takes** against the item's own ~6-week ask, and whether budget stops stretch it.

Do not take either reading as settled. §2 measures both.

## §2 — Measurements

Write `scripts/diagnostic/primaries-voted-classification-559.ts`, **read-only** (no INSERT/UPDATE/DELETE, no schema, no cron touch). Print a labelled block per measurement.

**M1 — reachability (static, no DB).** For each symbol — `buildPrimariesCartogram`, `PrimaryMapCard`, `PrimaryDistrictCard`, `PrimaryRow`, `primariesFill`, `PrimariesLegend`, and the `"primaries"` member of `CartogramVariant` — enumerate every importer and every JSX/call site under `app/` + `components/` + `lib/`, **excluding the symbol's own defining file and excluding comment lines**. Then list every `<CartogramShell` call site with its literal `variant` prop. Emit per symbol: `LIVE (n call sites)` or `ORPHAN`. This is a grep-and-read measurement, so do it in the script's output (or a committed sibling note) rather than by hand, so the numbers are reproducible next session.

**M2 — the population, re-measured.** Over `primaries` where `election_round = 'primary'`: count rows with `primary_date < date('now')` (past-by-date), and of those, how many have at least one `primary_candidates` row with `vote_pct IS NOT NULL` (voted-by-results). Report the gap. Split it three ways: by chamber; by days-since-`primary_date` buckets (0–14 / 15–42 / 43–90 / 90+); and separate the **zero-candidate** rows (roster never populated) from the **has-roster-no-shares** rows — those are different failures and the item conflates them. The June-12 reading was 482 past / 407 voted / 75 gap; state today's numbers next to it.

**M3 — where the gap renders now.** Take the 10 largest-`days-since` rows from M2's has-roster-no-shares set. For each, resolve the surfaces that would display it: the derived seatId (`S-{ST}-2026` / `{ST}-{DD}-2026`) → `/race/[id]` (via `getPrimaryForRace` → `RaceRunoffs`), and its presence in `getPrimaryCalendar(2026)` → `PrimaryTimeline`. Print the seatId, the date, the candidate count, and what `RaceRunoffs`' `resultLabel(status, votePct)` would emit given the stored `status` + null `vote_pct`. **This is the measurement that decides whether any user-visible wrongness survived HO 333** — if M1 says the cards are orphaned and M3 says the live surfaces read correctly, the display half of the item is closeable without a build.

**M4 — cursor cycle time, measured not estimated.** Print `buildScrapeUnits().length` and its calendar/senate/house split. Then read the last 45 `cron_runs` rows for `/api/cron/primaries` and report, per tick: `cursorStart` → `cursorEnd` delta, `unit` kind, `budgetStopped`, `fetchFailures.length`, elapsed. Aggregate: mean + p50 units advanced per tick, budget-stop rate, and **observed days per full cycle** at the daily `0 12 * * *` cadence. Flag any cursor regression or reset. Arithmetic says roughly 40 ticks; report what the table says, because a 12-district slice against a 50s deadline and an 8s per-fetch abort has room to under-deliver.

**M5 — refresh proof + the SC special.** (a) Prove the delete-rebuild actually lands fresh shares post-election: for contests that DO have results, report the distribution of `MAX(primary_candidates.updated_at)` minus `primary_date` (how long after election day the row was last rewritten), and whether any resulted contest has been rewritten more than once since its date. If shares never refresh after first landing, Premise B is wrong in a way M4 can't see. (b) For SC 2026 senate: dump every `primaries` row (id, date, runoff_date, election_round, party) plus candidate counts, and state whether the **Aug 11 special primary** is represented at all or whether the stored rows are still the superseded June 9 regular (HO 520 parked this).

## §3 — HALT

Commit the diagnostic, report all five blocks verbatim, and **stop.** No build code in this HO. The build split depends on the readings:

- M1 all-ORPHAN + M3 clean → the display half closes as **moot, not built** (the HO 499 orphan-sweep shape), and the owed work is an orphan deletion commit, its own HO.
- M1 shows anything LIVE → that surface gets the date-driven fix, scoped to it alone.
- M4 cycle comfortably inside ~6 weeks and M5(a) shows post-date rewrites → the re-poll half closes as **already-satisfied**, with the measured cycle recorded.
- M4 well past 6 weeks, or budget-stop-dominated → the fix is a **priority pass** (scrape recently-voted-but-incomplete contests ahead of the cursor slice), not a new re-poll mechanism. That is its own HO with its own cost gate.

## §4 — Scope guards

1. **Read-only.** No writes of any kind, including no "harmless" backfill of a single obviously-stale contest.
2. **No component deletions in this HO**, however dead M1 proves them. A sweep is a separate commit under a separate HO (HO 499 precedent), and deleting on the same commit as the evidence makes the evidence unreviewable.
3. **Do not touch `PrimaryTimeline`.** Its `c.date <= todayISO` model is the thing the item wants; it is not a bug to be unified.
4. **No `vercel.json`, cron, slice-constant, or `DEADLINE_MS` change.** M4 measures the cadence; it does not tune it.
5. **No schema change, no index.** If M2 or M4 is slow, report the timing rather than adding an index inside a probe.
6. **`getUpcomingPrimaries` / `getPastPrimaries` untouched** (note in passing if M2's past count exceeds `getPastPrimaries`' `limit = 200`, since that is a separate truncation question, but do not change it here).

## §5 — Commit + gates

1. `git add scripts/diagnostic/primaries-voted-classification-559.ts`
2. `diag: HO 559 STEP 0 — primaries voted-classification reachability + re-poll cycle (read-only)`
3. `npm run typecheck` clean, ancestry eyeball (`git log --oneline @{u}..HEAD` = exactly one commit, clean fast-forward), push to `main`.
4. Report the five blocks and halt. No docs commit in this HO; the sweep follows the build split.

**Gates:** diff = 1 file, 1 commit · zero writes in the script (grep it for `INSERT|UPDATE|DELETE|CREATE|ALTER` before pushing) · no `vercel.json` / `lib/primaries-sync.ts` / component diff.
