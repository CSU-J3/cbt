# HO 520 — SC Senate seat change: roster + races reconcile (Graham)

**Production data remediation. Diagnose-first, then run existing syncs.** Follows the HO 408 / 411 / 412 senator-integrity precedent + the standing `sync:members`-staleness loop (HO 402, the Gallagher CA-01 case). This is the same class: a mid-Congress seat change the manual `sync:members` hasn't picked up — surfaced by the HO 519 audit as an `S-SC-2026` wrong-incumbent on the live `/electoral` surface.

## Verified ground truth (carry this — do not re-derive; you can't confirm post-cutoff events, so it's supplied)

A real-world event **after the training cutoff**, verified 2026-07-25 against primary/authoritative sources:

- **Sen. Lindsey Graham (bioguide `G000359`, R-SC, class 2) has died.** He served in the Senate 2003–2026. *Sources:* congress.gov member page now reads **1955–2026**; GovTrack lists him as **"[R-SC, 2003-2026], former Senator"** (record ends Jun 2026).
- **Gov. Henry McMaster appointed `Darline Graham` (bioguide `G000608` per congress-legislators) to fill the vacancy** (~mid-July 2026). She is a **caretaker appointee, serving until January 3, 2027** (when the 120th convenes after the Nov 2026 general). *Source:* the SC Governor's official press release (governor.sc.gov). (Surname coincidence — a different Graham; not a relative reference.)
- **SC 2026 is now an open special contest:** filing was open Jul 21–28; **special primary Aug 11**, runoff (if needed) Aug 25, **general Nov 3, 2026**. *Source:* same SC Gov release.

**What this does and doesn't change:** SC is class 2, so 2026 was already its regular election year — the HO 411 class-derived `next_election_year = 2026` is **unaffected**, no `data/senate-special-elections.json` entry needed (that file is for *off-cycle* specials like OH/FL; SC's contest is on the normal class-2 cycle, just now open). What changed is (a) the **sitting senator** (Lindsey → the appointed Darline Graham), and (b) the **primary** (the June 9 regular primary is superseded by the Aug 11 special — see §4, parked).

---

## §1 — Diagnose (READ-ONLY, report before touching anything)

Confirm the stale state and the upstream truth before any write:

1. **CBT `members` for SC:** dump `bioguide_id, name, party, chamber, senate_class, is_current, next_election_year` for `state='SC'` (or the equivalent). Expect the stale picture the audit found: `G000359` present with `is_current=1`; `G000608` **absent**.
2. **CBT `races`:** dump the `S-SC-2026` row (`incumbent_bioguide_id`, rating, any candidate/challenger fields). Expect `incumbent_bioguide_id = G000359`.
3. **CBT `primaries`/`primary_candidates` for SC 2026:** what's stored — a June 9 primary (Graham on it)? Nothing? Record it; it informs §4 but you're **not** touching it this HO.
4. **Upstream truth:** confirm `legislators-current.yaml` (the `sync:members` source) now (a) **carries `G000608`** as the sitting SC class-2 senator, and (b) **no longer lists `G000359`**. This is the precondition for §2 to work — if the upstream file hasn't updated yet, STOP and report (the fix can't run until upstream reflects it).

**Report §1 before proceeding.** If the upstream yaml already reflects the change (expected), continue.

---

## §2 — Roster fix (run the stale manual syncs)

The mechanism is routine — `sync:members` marks members absent from `legislators-current.yaml` as `is_current=0` (the HO 412 Mullin precedent: he resigned, dropped from yaml, audit read `is_current` clean 0/0) and ingests new sitting members; `sync:crosswalk` is members-gated so it can't invent anyone.

1. `npm run sync:members` — expect: **`G000608` (Darline Graham) added** (R, SC, class 2, `is_current=1`), **`G000359` flipped to `is_current=0`**. Confirm both from a re-dump.
2. `npm run sync:crosswalk` — run right after (the established order), to bridge `G000608`'s external IDs.
3. **Regression guard — re-run the HO 410 audit:** `tsx scripts/diagnostic/senator-year-audit-410.ts`. Confirm it stays **fully green** (§1 impossible-years = 0, §2 = 0, §3 = 0, §4 = 0/0) — i.e. pulling `G000608` and dropping `G000359` didn't disturb any other senator's class-derived year-pair. This is the same guard that caught the 18-senator drift; it must read clean after the roster change.

**Report the before/after roster diff + the audit result.**

---

## §3 — Races reconcile

`S-SC-2026` still points its incumbent at the deceased Graham. Reconcile via the HO 412 mechanism (the `is_current=1`-filtered upsert — so a departed senator's row can't recreate an ambiguity):

1. `npm run backfill:races` — expect `S-SC-2026.incumbent_bioguide_id` to move to **`G000608`** (whoever is `is_current=1` in the SC class-2 seat after §2). Confirm from a re-dump.
2. **Verify the live surface:** the `/electoral` SC card (and `/race/S-SC-2026` if it renders) must no longer show Lindsey Graham as the sitting incumbent. Note: the rating (Safe R) is unaffected; only the incumbent identity changes. Prod-verify per the BotID workaround if headless is blocked (SHA + the rendered incumbent, or local CDP).

**Report the race-row before/after + the live verification.**

---

## §4 — PARK (gated follow-on — do NOT build this HO)

The **Aug 11 special-primary tracking** is deliberately out of scope: the field is still forming (filing closed Jul 28; the primary hasn't happened), so there are no results to ingest yet, and the roster is unsettled. This is the same **"re-poll as the field settles"** pattern already banked for slow-count primaries. Flag it as a **new open loop** for the HO 521 doc sweep to record:

- SC 2026 is now a special: the stored June 9 regular primary (if present, §1.3) is superseded by the Aug 11 special primary; re-ingest the SC 2026 primary once the Aug 11 (→ Aug 25 runoff) results exist and the candidate roster settles.
- The race card's *incumbent* is the appointed caretaker (fixed in §3); the *candidate roster* for November is TBD until the special primary resolves.

Do not touch `primaries`/`primary_candidates` or add a special-elections config entry.

---

## Deliverable + guardrails

- **Diff before any commit.** This is almost certainly **zero code commits** — pure data remediation via existing syncs (the HO 402 Gallagher shape). If anything requires a code change (it shouldn't — no `senate-special-elections.json` entry, SC is on-cycle), show the diff hunk and wait for approval first (live-production rigor).
- **No doc edits.** The finding + fix get recorded in the **HO 521 doc sweep** (a backlog tombstone for the SC seat change + an oddities entry: the `sync:members`-staleness class recurred, verified via governor.sc.gov, resolved by the routine roster re-sync + `backfill:races`; and the parked Aug 11 special-primary follow-on). Don't write any of that here.
- **Report back:** §1 diagnosis, §2 roster before/after + 410-audit result, §3 race before/after + live verification, and confirm §4 is parked (not built).

read docs/handoffs/520-sc-senate-incumbent-fix.md and follow it
