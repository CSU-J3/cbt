# HO 494 — doc sweep: `/lobbying` compaction arc (492–493)

Docs only. **No code, no CSS, no config.** Two commits: docs, then SKILL.md separately under the self-mod guard.

Both changes are shipped and prod-verified — `7564423` (compaction) and `2fcb2a8` (page size), CI green, `verify:deploy` confirmed on each. Nothing to re-verify.

## Step 0 — confirm a prior line actually landed

The CI action-runtime deprecation note was handed over inline, not as a numbered HO, and inline instructions are the easiest thing to lose. Confirm it's actually in `docs/backlog.md` (expected at `e7e7727`) and reads roughly: bump `actions/checkout` and `actions/setup-node` to v5 when the Node 20 deprecation bites; symptom will look like unexplained CI failure on an unchanged codebase; check action versions before debugging. **If it isn't there, add it in this sweep.** Report which.

---

## Step 1 — `docs/roadmap.md`

Append-only, one new block covering both HOs, pointer bumped. Never retro-edit a prior block.

- **HO 492 — `/lobbying` height compaction.** Three chrome changes: issue rail bounded (`.lob-rail-scroll`, 520px + 31px header) with internal scroll; crosswalk + firms side-by-side (`.lob-secs`, single-column ≤900px); both sections bounded (`.lob-sec-scroll`, 340px). Page 4,897 → 1,777px unscoped / 1,369px scoped. All CSS scoped to `.lob-*`; `/members` and `/bill/[id]` byte-identical. Record the **regression the bound introduced and its fix**: bounding a list broke selection visibility (scoping a deep issue re-rendered with the rail scrolled to top), fixed with `scrollIntoView({ block: "nearest" })` in `IssueRailRow`.
- **HO 493 — feed page size tuned to the rail floor.** `PAGE_SIZE` 25 → 13 (file-local to `app/lobbying/page.tsx`; `/bills` uses `FEED_PAGE_SIZE`, amendments/nominations have their own). Unscoped now 1,369px, section headers start ~887px (was ~1,250). **13 not 14** — see oddity 1. `MAX_FEED_PAGES` left at 40 deliberately: reachable depth drops 1,000 → 520 filings while page 40's OFFSET falls to ~507 from ~975, so the deep-OFFSET clamp gets cheaper; holding depth would mean ~77 pages.

---

## Step 2 — `docs/oddities.md`

Three entries.

1. **Height-tuned constants on a variable-height feed are approximate, and measured slack is a property of that day's data.** `/lobbying` filing rows wrap when a filing carries several bill chips (~33px per wrapped row), so the feed's rendered height depends on which filings happen to be recent. A uniform-row measurement said `PAGE_SIZE=14` was the largest fit with 17px of slack — enough to absorb zero wrapped rows. 13 leaves ~50px, enough for one. Both floor the page at the rail when they fit, so 14 bought one row in exchange for the section headers dropping below the fold on any day page 1 carried a wrapped filing, on a feed whose contents change daily. **Generalizes: measuring a data-dependent layout gives you one sample, not the distribution. Don't re-tune such a constant upward on a day that happens to measure favorably.**

2. **Adding `overflow` to a list that carries a selected state breaks selection visibility.** Unbounded, the selected rail row was always on screen. Bounded, scoping an issue low in a 79-item list re-rendered with that row selected and the rail scrolled back to the top. **Rule: any list with a bound and a selected item needs the selected item to scroll itself into view** — `scrollIntoView({ block: "nearest" })`, and verify the window doesn't jump along with the container.

3. **The `.mc-*` two-pane system has no height bounds, by omission not design.** `/lobbying` now bounds its rail via `.lob-*`-scoped rules. `/members` deliberately doesn't: its roster is far taller than its committee rail, so a rail bound there is a no-op. Anyone extending the two-pane to a third surface should decide this per-surface rather than assuming either way.

---

## Step 3 — `docs/backlog.md`

- **Strike the `/lobbying` height compaction item** — shipped at 492/493.
- **Add the residual, parked with its reason:** unscoped section headers start ~887px, marginal on a sub-900px viewport. The remaining lever is the ~400px of chrome above the pane (masthead, two-row nav, readout, blurb, fbar) and the nav is shared across every page. Deliberately not pursued: it means tuning against one viewport size and touching shared chrome for one page's benefit.

---

## Step 4 — `.claude/skills/cbt/SKILL.md` (SEPARATE COMMIT — self-mod guard)

The `/lobbying` entry was refreshed at HO 491 (`c001984`) and is **already stale again** — it describes the two-pane as shipped at 486 but not the bounded rail, the side-by-side sections, or `PAGE_SIZE=13`.

Update it to the current layout, and while you're there, add the coupling that makes the entry self-defending: the rail bound, `PAGE_SIZE`, and the section bounds are tuned against each other, so changing one requires re-measuring the others. Cross-reference oddity 1 so nobody re-tunes `PAGE_SIZE` upward off a single favorable measurement.

**Worth noting in the sweep itself:** this entry has now gone stale twice in three arcs, both times because a shipped layout change didn't carry its doc update. That's the cost of the code/docs split convention, which is otherwise correct. Flag it in the roadmap block as an observation, not a process change — if it happens a third time, the convention needs revisiting.

**Self-mod guard: show the diff, wait for explicit approval, separate commit.**

---

## Git discipline

- Clone / hard-reset to `origin/main` first — HEAD should be **`2fcb2a8`**.
- Explicit pathspec staging; never `git add .`.
- Two commits: `docs: sweep /lobbying compaction arc (HO 494)`, then `docs(skill): refresh /lobbying layout + tuning coupling (HO 494)`.
- `npm run typecheck` before push. Ancestry eyeball, fast-forward only.
- **CI will not run on either commit** — both are docs-only and the `paths-ignore` filter added at `e1abfc5` covers `docs/**`, `.claude/**`, and `**/*.md`. This is the first real test of signal (b) from that change. **Confirm no CI run fires and report it** — that's the outstanding verification from the paths-ignore work, and it verifies itself here without anyone manufacturing a commit.
- Skip `verify:deploy` — docs-only, no runtime surface.

## Report back

The Step 0 finding on the Node 20 line, the roadmap block diff, confirmation that no CI run fired, then the SKILL.md diff separately for approval.

---

read docs/handoffs/494-doc-sweep-lobbying-compaction.md and follow it
