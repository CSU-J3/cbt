# HO 623 — dashboard fit-finish: the feed column widens, the NEXT state tightens, and 621–623 close together.

HEAD `12b3e57`. Pointer still "run through HO 620" — **622's sweep never landed**, so this HO's close covers **621–623** on one ref. **Next free is 623.** The absence band is prod-verified by the owner's screenshots (Wilson 34, McConnell 51 — the true streaks past the probe's window cap, dates matching the oracle to the day; carry those live figures into the block).

## 1. Commit 1 — the feed column: `minmax(480px, 31%)`

`globals.css:749`: `minmax(400px, 27%)` → **`minmax(480px, 31%)`**. Owner ruling, and a recorded mock deviation (the masthead precedent — the committed mock said 400/27%): at 2560 the column reads 794px, at 2400 ≈ 744, both under the C8 ceiling (~850, past which a row of text buys nothing); at 1440 the floor gives 480.

**The container-query boundary moves with it, deliberately.** `@container bxp (max-width: 440px)` (`globals.css:4469`) was tuned against the 400px column; at a 480px floor the panel's inner width lands ~456–464, just above the threshold — wide-mode at 1440, marginally cramped and flappy at the boundary. Raise to **`(max-width: 520px)`** so the 1440 column stays stacked and wide-mode arrives only where it's genuinely wide (column > 520 needs viewport ≳ 1680). `/bills` is unaffected by construction (its container is far past 520) — prove it with one expanded-row eyeball there, and re-run the 609-style expand reproduction on `/` at 1440.

`fix(dashboard): HO 623 — feed column to minmax(480px,31%); bxp collapse follows to 520 (owner ruling, mock deviation recorded)`

## 2. Commit 2 — the hearings NEXT state: collapse the jump, dim the past

Two defects in one state, both visible in the recess screenshot:

- **The spacing jump.** In NEXT mode (single future day), a large vertical gap sits between the hbar/ribbon and the lone schedule row. Diagnose to source before touching — candidates: `.hcal-agenda-day`'s stacked-mode top margin orphaned when only one day renders, an agenda-head suppressed in NEXT mode leaving its space behind, or the ≥1700px two-column schedule grid seating one row beside an empty column with its row-gap. Collapse whichever it is so hbar → ribbon → row reads tight; C6's floor still governs (the row itself stays ≥22px — the fix is the dead band above it, not the row).
- **The ribbon argues with the hbar.** `TUE 7 · WED 9 · THU 4` beside `NEXT · THU SEP 17` reads contradictory until you know those days are past. Past-day ribbon cells take the **`.past` treatment** the schedule rows already have (0.42 opacity), so the ribbon reads *done this week* and the NEXT jump stops looking like a bug. The trailing `20 THIS WEEK ▲10` stat stays — it's wstrip-consistent.

Verify the other states didn't move: a TODAY-mode day (Senate may still have one), and the empty-week rendering (weekhead + dashes + one dim line) — fire it with a scratch date if the live corpus can't show it, per the falsification rule, commit nothing from the scratch.

`fix(hearings): HO 623 — NEXT-state spacing collapses to source; past ribbon days dim (the hbar/ribbon coherence read)`

## 3. Verification

1. Typecheck + build per commit; fixture legs before any zero is trusted.
2. `--route home` at 2560 before/after: **M1 holds 0** with the wider column and the populated absence band; wrap/gap metric movement from the width change is expected and labeled. M4-true holds 0.
3. Eyeball at 1440 / 1680 / 2560: mover titles visibly gaining line length, the bxp stacked at 1440 and wide at 2560, the hearings panel tight in NEXT mode, past ribbon days dim, absence band unmoved.
4. Narrow spot at 1024/900/720: below the 1400 collapse the grid is single-column and the floor change is inert — confirm rather than assume; bucket (b) unchanged.
5. Prod-verify to the SHA, converged (the width change is CSS — SWR stale-HTML-new-CSS can garble one cycle; hold until it converges).

## 4. The combined close — `refs/heads/623-review`

One docs commit (+ no SKILL; nothing rule-shaped emerged — say so):

- **Backlog:** the Absence Watch entry → **SHIPPED at 622** exactly per the 622 §4 spec (the ruling in three sentences: streak-led because cumulative triggers make false present-tense claims — 6 sticky vs 1 blind in the 621 corpus; dated copy because "since {date}" survives recess where "now" lies; acute/chronic division of labor with the participation surfaces), the **S = 30 WATCH**, and today's live figures. Plus two mock-deviation lines from 623 (the 480/31% column, the bxp 520 boundary) so the mock's numbers stop being the record where the app has moved past them.
- **Roadmap block, 621–623, pointer → 623:** the probe redux and what the reconcile found (mechanism moved at HO 595, semantics held, M1.0 drift 0); the four reads and the ruling; the build with the probe-as-oracle check and the two-phase query; the live debut numbers (2 rows, 51/34, both audit legs green); 623's two fit-finish items with the coherence find named (a ribbon of counts beside a NEXT jump is data-coherent and display-contradictory until the past dims).
- HALT on the ref with the block; land on approval; gates: "HO 620" ×1, "HO 623" ×1, backlog SHIPPED present, oddities untouched (nothing qualified).

## 5. Guards

1. Two code commits, then the close — never mixed. Explicit pathspecs, ancestry counts stated.
2. `queries.ts` untouched. The absence band's component untouched (both fixes are CSS-side; if the spacing fix genuinely needs a JSX branch, say so in the HALT rather than silently widening scope).
3. `--fs` tokens 9–14px. The fixture untouched. No `data-viz-row`.
