# HO 451 — Doc sweep: reconcile the member-hub amendments section (closes 450)

Docs-only, one commit. Prod is verified live (`ea686a8` == HEAD), so this records confirmed-live state. Single-surface sweep — smaller than the HO 449 arc sweep. Three files: `docs/roadmap.md`, `docs/backlog.md`, `.claude/skills/cbt/SKILL.md`. **SKILL.md rides behind the self-mod guard** (diff + explicit approval before staging); show the other two diffs before the commit as well.

**No oddities entry** — HO 450 was a clean inverse projection of the HO 448 bill-hub section, nothing non-obvious broke. The heaviest-amender magnet (Bennet, 271) is the member-side echo of the `119-sconres-7` bill-side magnet already recorded at HO 448; not a new gotcha.

---

## 1. `docs/roadmap.md` — append-only block + pointer bump

Insert **immediately after the HO 446–448 block** (the `**Also (HO 446–448), the amendments pillar…**` paragraph, ~line 304) and **before the `**Banked / unbuilt:**` line**. Verbatim:

---

**Also (HO 450), the member-hub sponsored-amendments section — the second amendments fork, no theme-% change.** One of the three forks banked in the HO 446–448 block (bill-hub → 448; this ships the member-hub; the standalone `/amendments` aggregate + the persisted status model stay QUEUED). Shipped + prod-verified; live SHA `ea686a8`. **The inverse projection of the HO 448 bill-hub section:** `getMemberAmendments(bioguideId)` seeks `idx_amendments_sponsor` (where 448 seeks `idx_amendments_bill`) and keys each row on the **amended bill** — linked to `/bill/[id]` via `formatBillId`, with the bill title — rather than the sponsor, since the sponsor is fixed (it's their page). A new `MemberAmendmentRow` (a bare row the page maps — the member-page idiom, not self-boxing like the bill page's `BillAmendments`); the disposition dot + module-level `deriveDisposition` are reused, no new palette. **No probe, no blob, no cron/migration** — same bills-scale reasoning as 448: a per-member seek hydrates instantly, and the heaviest amender (Bennet `B001267` at **271** amendments) served live, capped at 60 + "N more". Placed as the **authoring pair** — immediately after Sponsored bills, before Committees (bills + amendments = the two forms of member-authored legislative text) — and hidden when empty (most House members sponsor none), the `{scorecard ? …}` conditional-section idiom. Prod-verified across heavy/capped (Bennet, 271 → 60 + 211 more), small/full (Moreno `M001242`, 6), zero/absent (Aderholt `A000055`, section omitted), and dots + sub-amendment lineage (Paul `P000603`, 1 yea / 7 nay / 35 muted, `↳ amends`). **No theme-% change** — the second v1 surface on the amendments pillar; the outcome-classification (status model) + the cross-bill aggregate lens (`/amendments`) that a bump would ride both stay deferred, matching 448 and the LDA-arc precedent. Docs: HO 451. **Also notes now run through HO 450.**

---

No other roadmap edit; do not touch the `**Banked / unbuilt:**` standing line (the two remaining amendment forks live in backlog QUEUED).

---

## 2. `docs/backlog.md` — QUEUED → DONE for the member-hub fork

The **Member-hub sponsored-amendments section** item (QUEUED, ~line 80) shipped. Remove it from QUEUED and add a DONE tombstone (match the DONE section's existing tombstone format). Tombstone text:

- **Member-hub sponsored-amendments section** — **DONE HO 450** (`ea686a8`, prod-verified). The inverse of the HO 448 bill-hub section on the member spine: `getMemberAmendments(bioguideId)` seeks `idx_amendments_sponsor`, rows keyed on the amended bill (`formatBillId` + title) instead of the sponsor; `MemberAmendmentRow` is a bare row the page maps (member-page idiom). Placed after Sponsored bills as the authoring pair, hidden when empty. Bills-scale live query, no probe/blob (Bennet `B001267` at 271 served live, capped 60 + "N more"). Second of the three amendments forks — the standalone `/amendments` aggregate + the status/disposition model stay QUEUED.

Leave the other two QUEUED amendment items (the `/amendments` aggregate surface and the status/disposition model) exactly as they are.

---

## 3. `.claude/skills/cbt/SKILL.md` — one-clause sibling on the amendments query-helper entry (SELF-MOD GUARD)

The HO 449 sweep added the `getBillAmendments` bullet to the Query-helpers section as the amendments-read pattern of record. HO 450 added its inverse; name it on the same bullet rather than adding a near-duplicate. Append to the end of the existing `getBillAmendments(billId)` bullet:

> Its inverse `getMemberAmendments(bioguideId)` (HO 450) backs the `/members/[id]` **Amendments sponsored** section — same live pattern, seek on `idx_amendments_sponsor`, rows keyed on the amended bill (`formatBillId` + title) instead of the sponsor; `MemberAmendmentRow` is a bare row the page maps (the member-page idiom, vs the bill page's self-boxing `BillAmendments`).

No other SKILL.md change (schema, sync, and the pattern itself are already documented from HO 449).

---

## Git discipline

- Show all three diffs. **SKILL.md waits for explicit approval before staging** (self-mod guard); the roadmap append + backlog tombstone follow their file conventions (append-only roadmap block, DONE tombstone) but still show before commit.
- One commit, **explicit pathspec**: `docs/roadmap.md` + `docs/backlog.md` + `.claude/skills/cbt/SKILL.md`. Docs-only — no code, no `scripts/`.
- Commit message: `docs(sweep): reconcile the member-hub amendments section (HO 451, closes 450)`
- Ancestry eyeball before push: one commit riding, clean fast-forward, nothing behind, nothing unrelated staged, the concurrent session's files (`RaceCard.tsx` / `CompetitiveRacesBlock.tsx` / `CompetitiveRacesStrip.tsx` / `globals.css`) untouched and their history preserved. Push, report the remote SHA. No verify:deploy — docs-only, nothing runtime to promote.

---

read docs/handoffs/451-doc-sweep-450.md and follow it
