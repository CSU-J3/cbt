# HO 661 — the bounded re-check: `isSettled` learns the difference between scored and decided

**Parent:** backlog QUEUED "build the bounded re-check that stops NEW freezes (recommended HO 656, parent above)" + the `isSettled` freeze parent entry. **Baseline:** `4aee4ad`. **The shape was recommended at HO 656 and is ruled a go**: re-check-eligible for N days past `primary_date`, then settle regardless, N = 30 chosen generously (recovery timings give upper bounds only; the live residuals sat unmarked at 9 days WA / 65 days ME at measurement).

## Why, and one reframe the recon forced

The current predicate (`lib/primaries-sync.ts:551`) settles on `primary_date < today AND EXISTS(vote_pct NOT NULL)` — **scored**, with no winner term. A contest scraped in the window after Ballotpedia posts results but before it marks a winner takes shares and freezes in that same instant; every later tick refuses the write that would have landed the call. HO 656 watched two rows join this class mid-run; it is live and ongoing.

**The reframe: `isSettled` is a WRITE-freeze, not a fetch-skip.** All three call sites (`:646` special pass, `:905` Senate, `:1311` House) evaluate AFTER the page is fetched and parsed — settled skips the delete-then-insert, never the fetch. Two consequences the entry's framing didn't have: the "N wasted fetches per uncontested seat" cost does not exist in this architecture (the cursor fetches the unit regardless), and the window's real price is N days of **rewrite-eligibility** on decided-but-uncalled rows — which is precisely the healing being bought. The router (HO 601, first line) still keeps substitution off these ids; the HO 564 non-empty gate still refuses erasure. What the window re-opens is same-page re-parses landing corrections and calls, self-correcting because the source is unchanged.

## The predicate

```
settled ⇔ primary_date < today
          AND ( EXISTS (SELECT 1 FROM primary_candidates pc
                         WHERE pc.primary_id = p.id AND pc.status = 'winner')
                OR primary_date < windowFloor )        -- today − N: expired, settle regardless
```

The `vote_pct` term is **gone**. "Settled" aligns with "decided or expired" for the first time — the current predicate froze rows that were not decided (scored, uncalled) and retried forever rows that were (called, shareless). `windowFloor` is computed beside `today` at `:1080` (`new Date(Date.parse(now) - SETTLE_WINDOW_DAYS * 864e5).toISOString().slice(0, 10)`) and threaded as a fourth `isSettled` argument; `const SETTLE_WINDOW_DAYS = 30` lives beside the function with its derivation comment (generous not fitted; bounds 9d/65d; the cost restated as rewrite-eligibility, not fetches).

**The five classes, enumerated so the falsification has names:**

1. **Scored, uncalled, age < N → UNFREEZES.** The defect class. Expected members at `4aee4ad`: WA-05, WA-08 (Aug 4), `house-AZ-03-2026-R`, `house-VA-10-2026-R`; WI-06 if it took shares. The deploy is the experiment — these re-enter write-eligibility immediately, and a since-arrived Ballotpedia call lands on the next tick that reaches them.
2. **Scored, uncalled, age ≥ N → stays settled** (via expiry, was via scoring). ME-D, ME-R (Jun 9): no churn, no re-hammer of the uncontested Collins page.
3. **Called, shareless → newly settles.** `senate-MI-2026-R` (uncontested, winner marked, no share) stops being retried forever. A later share-add reaches it only via the backfill — accepted, named.
4. **Shareless, uncalled, age ≥ N → newly settles.** The forever-retry class (the empty-roster ME-02/NY-02/NY-22 territory among them) stops taking writes at N. `backfill:primary-results` and `reingest:primary-slate` remain the recovery for anything past the window — that is already today's reality for this class; the sync's eternal retries have not healed them.
5. **Age < N shareless, and all future rows → open, unchanged.**

## STEP 0 — verify + size (no halt; the enumeration is claims from the chat-side clone)

- **S1 — the predicate and its consumers.** `isSettled` at `:551` matches the quoted current form; module-private; exactly three call sites; `today` at `:1080`. **Plus the fourth touch point: `scripts/verify-house-settled-guard-577.ts:43` carries the predicate INLINE** — an instrument selecting exemplars by the old definition after the change is the lied-twice family. It rides the code commit.
- **S2 — size the reclassification, exact reads, ids for the small sets:**
  - U (class 1): `primary_date < today AND primary_date >= floor AND EXISTS(vote_pct NOT NULL) AND NOT EXISTS(status='winner')` — ids.
  - C (class 3): `primary_date < today AND EXISTS(status='winner') AND NOT EXISTS(vote_pct NOT NULL)` — ids (MI-R expected, count any others).
  - E (class 4): `primary_date < floor AND NOT EXISTS(vote_pct NOT NULL) AND NOT EXISTS(status='winner')` — count only, with a completed-vs-never-had-a-page split if cheap.
  - Predicted settled-count delta = +|C| +|E| −|U|; record predicted vs observed post-deploy.
- **S3 — confirm the write-freeze reading.** The cursor's unit selection contains no settled term (grep the unit/cursor queries); settling affects writes only. If this reading is wrong anywhere, stop and say so — the cost model of this HO depends on it.
- **S4 — comment sites the edit must reconcile:** the function docstring (`:535-550`, preserve the HO 601 structural-unreachability record verbatim — it stays true), the `:898-905` "narrow on purpose / only truly-decided results freeze" block, the `:1304-1310` House parity block. Each rewritten to the new semantics; the 601 history is RECORD, not casualty.

## STEP 1 — code, one commit

`SETTLE_WINDOW_DAYS` + `windowFloor` + the new predicate + the fourth argument at all three call sites + the S4 comment reconciliation + the 577 verifier's inline predicate updated (its exemplar selection must pick a **called** row now — a genuinely-settled-under-the-new-rule row — so it still proves the House guard fires). No other behavior. `npm run typecheck` → explicit pathspecs (two files) → ancestry eyeball → fast-forward push.

## STEP 2 — diagnostic, its own commit

`scripts/diagnostic/settle-predicate-661.ts`: prints old-settled count, new-settled count, and the U/C/E membership from S2's reads in one pass — run pre-deploy (the prediction) and post-tick (the confirmation), so both sides come from one instrument. Committed in the diag lane, separate from the build.

## STEP 3 — ops: deploy + fire the branches

- **3.1** Push commit 1+2 → confirm the SHA via `/api/version`.
- **3.2** Manual fire `/api/cron/primaries` (Bearer, established route). Then read, branch by branch:
  - **Unfreeze (class 1):** for each U id the tick reached — `settledSkipped` no longer contains it; if Ballotpedia has called it since, `status='winner'` rows now exist and shares updated. A U id the cursor didn't reach this tick is verified at the predicate level via the diagnostic, not claimed as exercised.
  - **Expiry (class 2):** ME-D/ME-R read settled under the new predicate (diagnostic), and `settledSkipped` carries them whenever their unit comes up.
  - **Called (class 3):** MI-R flips settled in the diagnostic's before/after.
  - **Clobber protection regression:** re-run the updated 577 verifier — the House guard fires on a called row. Green under the new definition or the change doesn't ship as "guarded."
- **3.3** Predicted-vs-observed table for the settled-count delta and each class membership. Drift from S2's prediction is named to the id, not absorbed — the frozen population is a moving set and a new member arriving mid-arc is expected, not an error.
- **3.4** Tick duration comparable to recent `cron_runs` for the route (the write-freeze reading predicts no meaningful move — that prediction is stated so a null confirms it).
- **3.5** Downstream, observed not gated: a class-1 winner landing flows to `race_candidates` at the next 12:30 harvest, stamped. One line in the report if it happens.

## STEP 4 — docs commit (roadmap + backlog; never with code)

- **Roadmap:** append the HO 661 block — the reframe (write-freeze; the fetch-cost framing corrected against the architecture), the predicate with the five classes and their measured counts, the branch firings, the 577 verifier reconciliation, and the accepted trades stated plainly (class-3 shares via backfill only; class-4 recovery unchanged from today's reality). Pointer: "Also notes now run through HO 661." `git diff --numstat` — deletions column 0 on `docs/roadmap.md`.
- **Backlog:**
  - Strike the bounded-re-check QUEUED entry with the figures.
  - The freeze parent entry: disposition (1) is now BUILT — restate/strike accordingly, with the surviving line that `backfill:primary-results` remains maintenance for anything past N and that the population was always a moving set.
  - The 11-contests symptom entry: one line — the class self-heals within N going forward; figures remain dated snapshots.
- **Oddities:** the fetch-cost framing correction may deserve an entry (a cost stated in units the architecture doesn't spend); Code's judgment.

## STEP 5 — SKILL, alone, behind the self-mod guard

One commit, review ref `refs/heads/661-review`, diff approved before main moves. The settled-guard passages rewritten to the new predicate with the old semantics preserved as dated RECORD: the HO 560/601 clobber-guard paragraph's predicate description ("past-dated AND already carrying at least one recorded share" → the new form; the 601 structural-unreachability history stays verbatim), the HO 577 House-parity sentence, and the "narrow on purpose / only truly-decided results freeze" claims — which under the new predicate become true rather than aspirational, and the edit can say so. Enumerate every passage the S4 grep finds; nothing else moves.

## Commit table

| # | kind | contents |
|---|------|----------|
| 1 | code | predicate + constant + windowFloor + three call sites + S4 comments + 577 verifier (two files) |
| 2 | diag | `settle-predicate-661.ts` |
| — | ops (no commit) | deploy verify → manual primaries fire → branch firings → predicted-vs-observed |
| 3 | docs | roadmap block + backlog (strike · parent restate · symptom line) + oddities if any |
| 4 | docs | SKILL alone, via `refs/heads/661-review` |

## Git discipline

Explicit-pathspec staging · ancestry eyeball before every push (`git log --oneline @{u}..HEAD`) · fast-forward only on main · `npm run typecheck` before pushing · no force-push (force-with-lease on the review ref only) · delete `661-review` after the fast-forward.
