# HO 632 — MIA, feed groups, stage color in the meta line, and the cards go quiet

Main is `bd8fe92`. This is **632**. Owner ruling off `mock-632-quiet-cards-and-groups.html` (three live knobs, revised twice in review: group headers punched up to amber-bright with the tape's 2px left edge, band renamed): **all three knobs YES — groups, stage color, quiet cards — plus the MIA rename.** The mock lands in `docs/design/` before you start; halt if absent (the 631 rule). Its feed data and ages are illustrative — no numeric expectation in this handoff derives from them, and none should in your commits (the policy from 631).

Provenance worth one comment: `V2FeedList.tsx:36–37` refused feed groups at the 609 rebuild because *the committed mock has no feed groups*. The owner's uploaded reference is the earlier 591 revision where they exist; the ruling reverses the refusal with a mock of its own. Replace that comment with one citing this HO and the committed mock-632 — don't leave a comment asserting the opposite of the shipped state.

## Commit 1 — MIA

`AbsenceWatchBand.tsx:85`: `▲ ABSENCE WATCH` → `▲ MIA`. That grep shows one user-facing site; confirm with your own grep including aria attributes before calling it one. Feature name in docs/roadmap stays "Absence Watch" — this is display copy, not a rename of the record.

## Commit 2 — feed groups

TODAY / YESTERDAY / EARLIER THIS WEEK headers in the feed, the mock's revised treatment: amber-bright, `--fs-10`, weight 600, `.18em` tracking, `8px 12px 5px` padding, `border-top: 1px solid var(--border-strong)`, `border-left: 2px solid var(--accent-amber)`, background `#080b11`.

- **Scope: MOVERS and NEW only.** TOP STALLS is sorted by stall age; a TODAY header there is a category error. Ungrouped, stated in the commit.
- **The bucket derives from the same timestamp the row's age string derives from** — a row must never sit under TODAY reading `1d`. Find the field the age display uses and bucket on it; if the two ever use different fields, that's a finding to surface, not to paper over.
- **The day boundary is ET (America/New_York), server-derived, and the comment says why**: Congress runs on ET, the House stores `-04:00` offsets, and the product's "today" should be the chamber's, not the server's UTC or the viewer's locale. No client `Date` anywhere in this — the hydration constraint (574/589) holds, and the grep-gate from 630 extends to the bucketing path. The HO 622 slice-don't-parse trap applies to any date handling here: a `Date` round-trip can shift a late-evening House action across the boundary this commit exists to draw.
- **Buckets:** TODAY (since ET midnight), YESTERDAY (prior ET day), EARLIER THIS WEEK (rest of the current ET ISO week), and an OLDER group for anything before the week — expected empty at current depths (verify on live data, state the observed distribution), rendering only if real rows need it; a header claiming THIS WEEK over a 9-day-old row is false copy. Empty groups render nothing — a header over no rows is the reserved-box defect by another name (the 622 `.abw2` argument).
- **Seam mechanics, verify not assume:** headers as siblings inside `.v2f` naturally break the `.v2f-group + .v2f-group` chain, so the 628 hairline vanishes exactly where a header's strong border replaces it — no override rule should be needed. Confirm no doubled line at the tab-strip seam and none under a header at both widths. The open-group amber frame's `-1px` overpaint now also meets header borders; eyeball an open group adjacent to a header.
- **The click gate re-runs, 36/36.** Headers are inert — no glyph, no cursor, no handler — and the harness's scroller/row discovery must not trip on non-row children. If it does, fix the harness's discovery, not the DOM.

## Commit 3 — stage color

`.v2f-stage` gains stage-keyed classes. The mock draws FLOOR (`--stage-floor`) and ENACTED (`--stage-enacted`); the shipped rule generalizes to the one sentence the mock's note implies — **a stage token colors its stage** — so OTHER and PRESIDENT take `--stage-other-chamber` and `--stage-president` as the same rule rather than two hand-picked cases. INTRO and CMTE stay dim deliberately: they are the noise floor, and coloring the 90% case repaints the column — the mock's whole point is that FLOOR and ENACTED speak *against* dim CMTE. This is C3-compliant by construction (color carrying meaning: stage), which is the convention's own carve. Flag the OTHER/PRES extension in the commit as the generalization it is; if the owner dislikes it at HALT, the revert is two lines.

## Commit 4 — quiet cards

Two components, two scopes, one idiom:

- **`BillExpandPanel` metabox, global**: drop the box (`border`, `border-radius`, `background`, side padding) in favor of hairline-separated rows — check what `.bxp-mrow` already carries before adding separators — and the `CONGRESS.GOV ↗` boxed button becomes a plain amber `→ CONGRESS.GOV ↗` link. This panel is shared with `/bills`; the change rides there deliberately — one panel, one treatment; a dashboard-scoped fork of the same panel across two feeds of the same rows is the pre-316 chip smell in reverse. `/bills` gets its own HALT screenshot as the second surface's eyes, and the block names it as riding the ruling.
- **`SponsorExpandedPanel`, compact density only**: the boxed `VIEW DETAIL` / `OPEN IN FEED` buttons become plain amber `→` links **under `density="compact"`** — `/members`' full density keeps its boxes (no ruling happened there), and the byte-identical render-diff from 631 re-runs to prove it.
- **Topic chips change nothing.** They are links; the HO 619 rule keeps their borders in every variant. Stated so nobody "finishes" the quieting later.

## Gates

1. Harness 36/36 across all four commits (commit 2 is the one that can break discovery).
2. Audit `--route home`, closed state: cite the legs, read expected figures from main's current baselines, never from this handoff. The M3 movement from commit 3's colored spans is expected and C3-scoped — state it if the crawl reports it, don't tune it away.
3. Hydration grep (no client clock, now including the bucket path); typecheck + build per commit; explicit pathspecs; code and docs never mixed.

## HALT 1 — owner's eyes

Screenshots at 1440 and 2560: the grouped, stage-colored feed with one open quiet bxp; the MIA band with its open compact card showing the quiet buttons; `/bills` with an open panel. Plus the observed bucket distribution (does OLDER render on live data?).

## Close — `refs/heads/632-review`

Docs commit: roadmap block for HO 632, pointer → 632 — the four rulings off the revised mock, the reversed 609 refusal with its provenance, the ET boundary decision, the stage-rule generalization, the bxp global-vs-compact scoping and why, `/bills` named as riding. `docs/design/mock-632-quiet-cards-and-groups.html` rides the commit as the ruling's record. Grep gates: "HO 632" ×1, previous pointer reads 1. Delete the ref after landing.
