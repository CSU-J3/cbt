# HO 438 — doc sweep (LDA lobbying surface, HO 437)

Docs-only. Records the LDA lobbying **surface** now that HO 437 has shipped and is
prod-verified across three commits — `2b34058` (query layer + rollup precompute),
`d6c7d2c` (`/lobbying` surface), `3851b85` (feed deep-OFFSET fix). Live SHA
`3851b85`. No code. One commit, docs-only, staged by pathspec so the concurrent
session's `globals.css` / `components/*` / `docs/design/*` work stays out.

**Numbering note (for Corey):** this sweep is HO **438** — the next handoff number
after 437 (the surface), matching the doc-sweep-gets-its-own-number precedent
(429/431/436). The bill-keyed fork the surface handoff called "HO 438" is therefore
listed below as **HO 439**. Redirect if you'd rather the sweep share 437 and keep
bill-keyed at 438.

## roadmap.md (append-only: add a block, bump the pointer; HO 418/431 precedent)
Add an "Also (HO 437)" block. Do NOT retro-edit any prior dated block. Bump the
running "Also notes now run through HO X" pointer to **437** (the feature number,
per the 431/436 precedent — the sweep's own number goes in "Docs: HO 438", not the
pointer).

Block content:
- **LDA lobbying surface shipped** — `/lobbying`, **issue-code-first** (the HO 435
  data layer's surface, Corey's call). A new top-level nav item and a **standalone
  analytical surface** (the `/patterns` class — an aggregate lens, not an entity
  hub). Sections: a stat readout + issue-area **ranked bars** + a **per-issue
  drill** (top clients / top firms / recent filings) + a corpus-wide
  **recent-filings feed**.
- **The query-layer story is the load-bearing part.** Request-time aggregation is
  **non-viable** on this Turso tier for these table sizes. Stats + issue-bars + the
  full per-code drill are **PRECOMPUTED** in the daily LDA cron into a
  `dashboard_state` blob (`lda_lobbying_rollup`) via full-table **sequential** reads
  + in-memory JS aggregation (~186s, under the 220s cron budget gate), served O(1).
  Only the corpus recent-filings feed is **live** (a clean `idx_lda_filings_dt_posted`
  walk, clamped to the 1,000 most-recent — `MAX_FEED_PAGES=40` — so a tail-of-table
  OFFSET can't 500). A **live-per-code drill was tried and abandoned** (>25s cold for
  the top codes). A **covering-index detour was tried and fully reverted**
  (`migrate.ts` net-zero, no prod schema change).
- **No theme-% change** — an enabling surface on a new pillar, no existing theme
  bar to move. **Banked:** HO 439 (bill-keyed lobbying on `/bill/[id]`) + the
  CBT-topic crosswalk (LDA ~79 codes → 24 topics) + a corpus-wide top-firms
  leaderboard + named-not-numbered bill recovery (needs the Congress.gov
  title-enrichment sync). Docs: HO 438. **Also notes now run through HO 437.**

## oddities.md (append — this is the reusable lesson; make it prominent)
The finding is **not** "LDA is slow." It's that on this Turso tier, random
**row-fetch** cost and **sequential-scan** cost DIVERGE HARD on the oversized side
tables (`lda_*` are 7–14× `bills`). One entry, prominent, cross-referencing the
HO 340 non-covering-index note:

- Whole-table aggregates that row-fetch through a non-covering path: **30–90s+
  cold** (`COUNT(DISTINCT registrant_name/client_name)` 34–45s; issue-bars GROUP BY
  over 233k >90s).
- Per-code drill queries that join back to `lda_filings` + hydrate: **>25s cold even
  at `LIMIT 10`** (the auto-selected top code would 500) — same non-covering
  row-fetch trap, HO 340 lineage.
- Three full **sequential** table reads (filings 40.8s + activities index-only 16.6s
  + activity_bills 39.1s ≈ 96s) + JS aggregation: fine, under budget.
- Covering indexes **do** flip stats/bars to `USING COVERING INDEX`, but they do
  **not** rescue the join-with-row-fetch drill shape (it crosses
  `lda_activities → lda_filings`).
- **Deep OFFSET on a live feed is unsafe regardless of index:** `OFFSET (page-1)*n`
  walks everything before the window; a 108k-row tail measured **12.3s > the 10s
  cap**. Clamp live feeds to a recency window.

**The durable rule for the next oversized side table:** full-read-plus-JS-precompute
into a blob beats clever request-time SQL — start there, don't relearn it.
Cross-ref the HO 340 `USING INDEX ≠ USING COVERING INDEX` entry.

## SKILL.md (self-mod guard — show the diff, get explicit sign-off)
- **Schema section** already carries the 3 `lda_*` tables (added HO 436). Add the
  **`lda_lobbying_rollup` `dashboard_state` blob contract**: its shape (`stats` +
  `issues` bar list + a per-code `drill` map of top clients/firms/recent) + a
  `generatedAt`, and state explicitly **what's precomputed** (stats / bars / drill)
  **vs live** (the recent-filings feed only).
- **Query helpers:** `getLobbyingRollup()` (blob parse, tag `"lda"`),
  `getRecentFilings({page, pageSize})` (live, `dt_posted` walk, `MAX_FEED_PAGES=40`
  clamp — note WHY: the deep-OFFSET 500), `sanitizeIssueCode()`.
- **Cron topology:** the LDA cron's **rollup precompute step** (an **uncapped**
  libSQL client for the full reads — the 10s `boundedFetch` is the whole reason this
  can't be request-time) + the **budget gate** (skip on a heavy-sync / quarterly-burst
  day → blob a day stale) + `revalidateTag("lda")`. The **`npm run lda:rollup`** CLI
  (same compute, for the post-backfill populate). Note the **`/api/cron/lda-rollup`
  standalone slot** as the banked fallback if the in-cron gate starts skipping on
  non-burst days as 2026 filings accumulate.
- **Pages:** add the **`/lobbying`** entry (issue-code-first; the three sections;
  blob-served bars/drill + the one live feed) + the nav item + `pathToNavKey` +
  breadcrumb crumb.
- **Revalidate allowlist:** `"lda"` added.

## backlog.md
- **HO 439 — bill-keyed lobbying on `/bill/[id]`** — QUEUED, reuses
  `lda_activity_bills` (the other fork the surface handoff named "HO 438").
- **CBT-topic crosswalk** (LDA ~79 codes → 24 topics) — BANKED, optional overlay.
- **Corpus-wide top-firms leaderboard** — BANKED (the per-issue drill's top-firms is
  the sharper cut).
- **`/api/cron/lda-rollup` standalone slot** — BANKED, the fallback if the in-cron
  budget gate starts skipping on non-burst days.

---

Diagnose first: read the four target files' current state, then propose the roadmap
block + the SKILL diff + the oddities entry + the backlog items, show them, and wait
for approval. SKILL edits need explicit sign-off per the self-mod guard. Stage
docs-only by pathspec (`docs/roadmap.md`, `docs/oddities.md`, `.claude/skills/cbt/SKILL.md`,
`docs/backlog.md`), keep the concurrent session's docs/design / globals / components
out. One commit. Nothing committed until I approve.

read docs/handoffs/438-doc-sweep-437.md and follow it
