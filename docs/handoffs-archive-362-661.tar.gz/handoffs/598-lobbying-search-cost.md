# HO 598 — `/lobbying?q=` returns "No filings match" for terms that match

**Numbering.** Next from `docs/roadmap.md`'s pointer — 596 was the last sweep, 597 shipped the `activity_count` column and the cache-scope fix. HO 588's block is still owed. Confirm against the roadmap and `git log`.

**STEP 0 first, then HALT.** The solution space is genuinely open and one prior decision needs re-verifying before anything is scoped.

---

## §0 — What 597 found

`/lobbying?q=boeing` renders **"No filings match" with a 200** while the database holds **78 matching filings**. Every request, both `lib/db.ts` attempts lost.

- The pager `COUNT(*)`: **92.8s**.
- The page query: **15.6s**.
- They share a `Promise.all`, so the COUNT is the lever.
- HO 547 priced that COUNT at **≤67ms** and shipped honestly on it. The corpus is now **129,401 filings**.

This is worse than the VOLUME defect 597 just fixed. VOLUME is a sort you have to select; search is reachable from page 1. And since 597 moved the guard outside `unstable_cache`, the failure is no longer cached — which is correct, and means it now fails **live on every request** rather than being served a stored empty for an hour.

### The record correction this HO must carry

**Every `20.00Xs` figure in this arc is the abort ceiling, not a measurement.** `DB_REQUEST_TIMEOUT_MS` is 10s and `lib/db.ts` retries once, so anything past the bound reports ~20.00s whether it takes 21 seconds or five minutes. 593's 20.005s, 597 STEP 0's three starred rows, and the backlog's promoted "20.005s" all mean **≥20s**. 597's falsification then measured the true cost at **>55s**.

Correct the backlog's HO 544 entry to read `>20s (abort ceiling); subsequently >55s co-located`, and **use an unbounded client for every timing in this HO** — 594 M1's 120s client is the precedent, and it exists specifically so the instrument doesn't cap the finding.

---

## STEP 0 — four measurements, read-only, then HALT

Script: `scripts/diagnostic/lobbying-search-cost-598.ts`. Commit, then HALT.

### M1 — find and re-verify the FTS no-go

597 carried a "do-not-re-propose-FTS" note. **Locate the original reasoning** — HO 336 (`search-fts`) and HO 338 (`bills-q-fts`) shipped FTS for bills, so FTS exists and works in this codebase, and something specific must have excluded it here.

Then re-verify it. **A logged decision is a claim, not a fact** — HO 420's Kiley party flag is the standing precedent for scoping work on an unverified logged item. Report:

- What the recorded reason actually says, quoted.
- Whether it still holds at 129,401 filings and at today's schema.
- Whether the bills FTS implementation is reusable here or structurally different.

If the reason has expired, say so. If it holds, say so and the solution space narrows to the rest of this list. **Do not re-propose FTS without engaging the recorded reason either way.**

### M2 — decompose the cost, with an unbounded client

Time each component independently, co-located, worst case:

- The `COUNT(*)` with the search predicate alone.
- The page query alone.
- The leading-`%` `LIKE` scan, isolated from the count.
- The `linked` `EXISTS` predicate, isolated — because it's shared with the filed page-40 residual.

`oddities.md:432` already records that `EXPLAIN` is blind to leading-`%` `LIKE`, so this is a timed check, not a plan read. Report which component actually dominates. The 92.8s / 15.6s split says the COUNT, but "the COUNT" and "the LIKE scan inside the COUNT" are different findings with different fixes.

### M3 — does a bounded count help, and for which terms?

The feed is already clamped at `MAX_FEED_PAGES=40`, so the pager can never render a page number beyond that. Counting only to `pageSize × 40 + 1` and reporting "40+" bounds the work for **common** terms.

It does not obviously help **rare** ones: finding that only 78 rows match still requires scanning all 129,401. Measure both — a common term and a rare one — and report whether a bounded count is a full fix, a partial one, or no fix at all. This is the cheapest candidate on the list and it deserves to be priced before anything heavier.

### M4 — what does the pager actually need?

Before optimising the total, establish whether the total is needed. Read the pager and report what breaks if the count is approximate, capped, or absent. If "40+" or "showing 1–25 of many" is acceptable UI, the cheapest fix may be to stop computing an exact total on the search path at all.

Answer from the code, not from taste — name the components and the props that consume `total`.

### M5 — do the search fix and the filed `linked` residual converge?

597 filed `?sort=volume&linked=1&page=40` at worst 15.62s, 2/5 cold breaches, mechanism per-row `EXISTS` probing cold pages. If `linked=1` becomes a materialized column on `lda_filings`, that is a near-copy of the `activity_count` work that just shipped — same table, same writer, same shape.

Report whether one materialization serves both, or whether they're independent. **Do not build either here.** If they converge, the next HO does one migration instead of two.

---

## HALT

Commit as `diag(db): HO 598 STEP 0 — /lobbying search cost`, then stop. Report M1's FTS verdict with the original reasoning quoted, M2's component breakdown, M3's common-vs-rare result, M4's pager requirements, and M5's convergence verdict.

---

## The build (phase 2, after approval)

Falsification, four-sided, per the shape this arc has settled into:

- **RED** — `?q=boeing` at HEAD, co-located, unbounded client, worst case. The user-visible symptom ("No filings match" against 78 real matches) is part of the RED, not just the timing.
- **GREEN** — same query, margin stated as a number, and the 78 filings actually rendering.
- **CONTROL** — search results identical to what the query returns without the guard, across a common term, a rare term, and a zero-match term. A zero-match term must still render "No filings match", and that string must not be reachable by any other path.
- **NEW — the ambiguity itself.** The whole defect is that a timeout and a genuine zero-result render identically. Whatever ships must make those two distinguishable, and firing the timeout path is how you prove it.

## Scope guards

1. **Do not strip the HO 440/448 guard**, and do not move it back inside `unstable_cache`.
2. **Do not re-propose FTS without engaging M1's recorded reason.**
3. **Unbounded client for all timings.** Any ~20s or ~55s figure from a bounded client is a ceiling; treat it as `≥` and re-measure.
4. **The filed `linked` page-40 residual is out of scope** except as M5's convergence question.
5. **Do not touch the `pageErr` #418 OPEN LOOP.**
6. **Migration · writer · rewire · docs are separate commits**, docs last.
7. **No unrequested SKILL.md edits.**

## Owed to the sweep HO

- **A SKILL query-authoring rule**, not an oddity: *a number in a comment that justifies a design decision carries the corpus size and the date it was measured at.* Three instances in one arc, each true when written, each later false, each having justified a design choice — `"Small grouped aggregate (~537 rows)"` (sized by rows returned; the scan was 366k), `"~295 filings with zero lda_activities"` (drifted to 429), and `"COUNT(*) … ≤67ms — HO 547"` (now 92.8s).
- **The abort-ceiling correction**, applied to the backlog's HO 544 entry and recorded as an oddity: a bounded client with one retry caps every over-bound measurement at ~2× the bound, so `20.00Xs` is a ceiling and never a cost. This makes the *seventh* instance of the "reads the same whether or not the work happened" family — here the instrument reports a number that looks like a measurement.
- 597's shipped work: the cache-scope split, the `activity_count` column, the `~295` → `429` comment fix, and the `~421k` typo corrected at `4051f9b`.
- The filed `linked` page-40 residual as a WATCH with its numbers.
- The Turso burn prediction, still unchecked — `turso org usage` needs a platform token that isn't in `.env`, the same wall HO 582's M4b hit. Record it as owed and unscored, not as unfalsifiable.
