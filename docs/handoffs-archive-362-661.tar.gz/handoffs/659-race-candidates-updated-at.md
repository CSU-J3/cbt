# HO 659 — `race_candidates.updated_at`: the reach stamp

**Parent:** backlog QUEUED "`race_candidates` has no `updated_at`, so a harvest's effect can only be bracketed, never dated (scoped HO 656, migration deferred)." **Baseline:** `31edeba`. **Mechanics precedent:** `activity_count` (HO 597) — added by `ensureColumn` in `main()`, never in the CREATE array; `scripts/migrate.ts:840` / `:918` record why, and they govern here too.

## Why this exists

HO 642 had to bracket the harvest's last run behaviourally (newest date reached vs newest reachable) because the table records nothing temporal, and HO 656 had to hand-capture a before-state for the same reason. One TEXT column ends that: a staleness check becomes one query instead of a run-diff, and the sentinel rows carry their own provenance going forward.

## Semantics — pinned before any code, because a "helpful" deviation here is the defect

- `updated_at` = **last write (reach)**, not last content change. An idempotent rewrite stamps. That is deliberate: the instrument measures what a run touched, which is the quantity the bracket was approximating.
- **NULL = pre-instrumentation.** Existing rows are never backfilled with a fabricated time. The behavioural bracket remains the record for pre-column history.
- Stamp value: one `const runStamp = new Date().toISOString()` per script invocation, bound into every write in that run — all rows of one run share a stamp, so "which run touched this" is a GROUP BY, not a range guess.
- The migration itself stamps **nothing**. Post-migration, non-NULL count must read 0 before any writer runs.

## STEP 0 — verify the claims (no halt — this HO is additive; the enumerate-and-halt protocol is for deletions and is NOT inherited from 658)

The enumeration below comes from the chat-side clone at `31edeba`; re-derive it on your tree before editing.

- **0.1 Writers believed to be exactly two:** `scripts/backfill-race-challengers.ts:69` (`INSERT OR IGNORE INTO race_candidates`, after its sentinel-clearing DELETE) and `scripts/seed-races.ts:122` (`INSERT INTO race_candidates`). Re-grep for write verbs, including multiline template strings — `grep -rn "race_candidates" scripts lib --include="*.ts"` and read every hit for INSERT / UPDATE / DELETE / REPLACE rather than trusting a verb-adjacency pattern. `scripts/backfill-races.ts` references the table but is believed read-only against it — confirm. Any third writer found joins the stamp edit and is named in the report; do not stamp two of three.
- **0.2** `PRAGMA table_info(race_candidates)` — confirm no temporal column exists today (expected columns: `race_id, name, party, bioguide_id, status, source_url`).
- **0.3 Before-state for the falsification, captured to numbers:** total rows · sentinel rows (`source_url='harvest:primary_winner'`) with row count AND distinct-seat count · non-sentinel rows with count and their `(race_id, name)` list · an ordered dump or checksum of sentinel rows' non-timestamp columns for the byte-identity leg. HO 656's post-run reading was 206 rows / 147 seats — treat that as a prior, not an assertion; record what you measure.

## STEP 1 — code, one commit

- `scripts/migrate.ts`: `await ensureColumn(db, "race_candidates", "updated_at", "TEXT");` in `main()` beside the HO 597-era calls. **Do not touch the CREATE array** — the `:840`/`:918` comments are the rule, not a suggestion.
- `scripts/backfill-race-challengers.ts`: `runStamp` computed once at run start; `updated_at` added to the INSERT column list and bound with it.
- `scripts/seed-races.ts`: same shape on its INSERT.
- **No reads added anywhere.** `lib/queries.ts` is untouched; the first read consumer is HO 660's staleness check, deliberately not this HO.
- `npm run typecheck` → commit the three files with explicit pathspecs → ancestry eyeball → fast-forward push.

## STEP 2 — run + falsify, both legs, figures in the report

- **2.1** `npm run migrate` → log shows `added column race_candidates.updated_at`. Then read: non-NULL `updated_at` count = **0**. The migration stamped nothing, proven not assumed.
- **2.2 Positive leg — the harvest IS the test.** `npm run backfill:race-challengers`. It clears sentinel rows and re-derives, so every sentinel row it writes carries the run's stamp. Verify: non-NULL count == sentinel row count · all non-NULL values identical (one stamp per run) · sentinel content on non-timestamp columns byte-identical to the 0.3 capture, with row-count deltas either zero or explained by real drift (a winner landed since 656's run — if so, name the seat, don't absorb it).
- **2.3 Negative leg — curation untouched.** Every non-sentinel row still NULL, count unchanged from 0.3. This proves two things at once: the migration didn't stamp, and the harvest's skip-curated guard still holds with the new column in the statement.
- **2.4** `POST /api/revalidate?tag=races` (Bearer `CRON_SECRET`) — the roster feeds live surfaces and `getRaceCandidatesForCycle` persists across restarts (SKILL's `unstable_cache` gotcha). No further prod verification is owed: nothing reads the column yet and no app surface changed.
- If either leg cannot be demonstrated, record it UNPROVEN in a WATCH rather than shipping the assertion — the untriggered-guard rule applies to instruments too.

## STEP 3 — docs commit (roadmap + backlog; never with code)

- **Roadmap:** append the HO 659 block — the writer enumeration result, the two-leg falsification figures, the semantic line (reach; NULL-honest; per-run shared stamp), and **the cadence ruling onto the record: the challenger-harvest schedule is ruled slot (b), its own daily cron slot; the wiring is HO 660.** Pointer line: "Also notes now run through HO 659." Verify append-only with `git diff --numstat` — deletions column 0 on `docs/roadmap.md`.
- **Backlog, three edits:**
  1. Strike the `updated_at` QUEUED entry with the shipped figures.
  2. The harvest-schedule QUEUED entry gains the ruling line — slot (b) chosen on the record at HO 659, wired under HO 660 — and the entry itself stays open until the wiring lands (its close criterion is "chosen AND wired").
  3. The M3 re-measure entry is **restated** with the following, adapted only where the surrounding entry text requires:

  > **Restated (HO 659).** The harvest-currency parent closed at HO 656 and the harvest has run since (2026-08-13), so the 642-era figures this entry carried — 88/186 exhibits; 129 zero-roster, 62 derivable, 67 not — are **superseded**: post-run zero-roster is 36, bucketed and summing (28 future primary · 2 incumbent-only · 2 `isSettled` freeze · 3 empty-roster · 1 too-recent). **Trigger:** after HO 660's first *scheduled* fire, re-measure M3 — against a cron-maintained harvest, not a decaying one-off. **Read the number through the buckets first:** the 656 classes are expected residue, not defect; split the exhibits by bucket before calling the shape. **Build the detector only if the remainder beyond the buckets holds the ME shape (a handful).** If it stays large past that discount, the finding is the data, not a missing detector. Calibrating against a stale harvest bakes staleness into the baseline (642 R3) — which is why the trigger waits for the maintained regime.

- **Oddities:** append at END only if something genuinely odd emerged.

## STEP 4 — SKILL, alone, behind the self-mod guard

One commit, review ref `refs/heads/659-review`, diff approved before main moves. Two touches only:

- The `race_candidates` schema block (~:303) gains `updated_at TEXT` with a one-line note: ensureColumn-added at HO 659; reach semantic — stamps on every write including idempotent rewrites; NULL = pre-instrumentation, never backfilled.
- The `backfill:race-challengers` entry (~:1137) gains one sentence: every run stamps its sentinel rows with a shared per-run ISO timestamp, so run identification is a GROUP BY on `updated_at`.

The dated "First run: 82 rows across 53 races" figure **stays** — HO 656 already ruled it a record.

## Commit table

| # | kind | contents |
|---|------|----------|
| 1 | code | migrate `ensureColumn` + both writer stamps (three files, explicit pathspecs) |
| — | ops (no commit) | `npm run migrate` → harvest run → falsification reads → revalidate POST |
| 2 | docs | roadmap block + backlog (strike · ruling line · M3 restatement) + oddities if any |
| 3 | docs | SKILL alone, via `refs/heads/659-review` |

## Git discipline

Explicit-pathspec staging · ancestry eyeball before every push (`git log --oneline @{u}..HEAD`) · fast-forward only on main · `npm run typecheck` before pushing · no force-push (force-with-lease on the review ref only) · delete `659-review` after the fast-forward.
