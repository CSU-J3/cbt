# HO 572 — The `#lobby-drill` anchor + the `e2e-prod` schedule-trigger check

Confirm the number before saving: `docs/roadmap.md`'s pointer runs through **HO 570**; HO 571 was its doc sweep (`c8c48d1` + `4387bdd`). So this is **572**. Take the number from the roadmap.

Small arc: one read-only check that owes no commit, and one commit that clears a standing red. The doc sweep is **HO 573** — no doc edits here.

## Why these two together

`fit-finish.spec.ts` currently carries a failing test (`#lobby-drill`, filed P3 at HO 571). The open decision beside it is whether to wire that suite into `e2e-prod.yml`, promote its stable subset into `smoke.spec.ts`, or keep it manual. **That decision can't be taken while the suite is red** — you can't put a failing suite behind an unattended runner. So the anchor gets fixed first, and the schedule check runs in the same pass because it's free and it feeds the same question: whether the unattended runner that exists is actually firing.

---

## STEP 0 — read-only, no commit

### (a) Did `e2e-prod.yml`'s `schedule` trigger ever fire?

The last open thread of the Phase-2 CI loop, opened **Jul 23**. `deployment_status` and `workflow_dispatch` are both PROVEN; the daily `0 15 * * *` has never been observed. It's had roughly a week of chances.

```
gh run list --workflow=e2e-prod.yml --limit 30 \
  --json event,status,conclusion,createdAt,displayTitle
```

If `gh` isn't authenticated locally, say so and stop on this half — it becomes a look at the Actions tab, which is Corey's, not a blocker for (b).

Report the **event breakdown**, not just a pass/fail. Three outcomes, three different meanings:

- **`schedule` runs present and green** → the loop is closed. HO 573 tombstones it. This is the expected case.
- **`schedule` runs present and red/cancelled** → a real finding. Check the cancelled case first: the workflow's `concurrency.group` is global (`e2e-prod`) with `cancel-in-progress: true`, and a cancelled run reports as neither green nor red. That's an existing WATCH with a recorded recognition symptom ("if the daily crawl appears to stop reporting, check for cancelled runs before debugging the schedule"). Don't re-diagnose it from scratch.
- **No `schedule` runs at all** → report it as an observation, don't fix it here. Rule out the cheap causes before speculating: GitHub runs `schedule` only from the **default branch's** copy of the workflow file (it's on main, so this should be fine — verify rather than assume), scheduled runs are **best-effort and can be delayed or dropped under load**, and GitHub disables schedules on repos dormant 60+ days (not applicable, but confirm rather than assert). Whatever you find, it's a finding for HO 573, not a build.

### (b) Confirm the anchor diagnosis before changing anything

Two things to verify at HEAD, because the fix depends on both:

1. **No `id="lobby-drill"` exists anywhere.** The planning-side grep found the href at `components/TopicCrosswalk.tsx:153` and the spec references at `e2e/fit-finish.spec.ts:460-470`, and zero id definitions. Re-run it.
2. **The current failure is a thrown locator error, not a soft red.** `fit-finish.spec.ts:465-469` calls `drill.evaluate(...)` on a locator matching **zero elements** — that rejects before `expect.soft` is ever reached, which is why the run reports a hard failure rather than a soft one. Confirm this. It matters because it tells you the `if (await codeChip.count())` guard above it is passing (the chip exists) and only the target is missing.

Report both, then proceed. No HALT.

---

## C1 — the fix

### The call: re-add the id. Don't drop the fragment.

Both options were named at HO 571; take **option 1**, and the reasoning is not "so the test passes."

The crosswalk renders in `.lob-secs`, **below** the right pane (`app/lobbying/page.tsx:493` vs `:409` — HO 492 put crosswalk + firms side-by-side under the pane). So a reader is at the bottom of the page when they click a code chip, and without a working fragment the scoped re-render drops them at page top with no indication of where their answer landed. There's ~400px of chrome above the pane (masthead + two-row nav + readout + blurb + fbar — the parked "above-the-pane chrome height" item measures it), so on a short viewport the scoped context header they asked for is below the fold on arrival.

That's the same failure this codebase has already fixed twice under different names: HO 492's `scrollIntoView({block:"nearest"})` when a bounded rail re-rendered with the selection scrolled out of sight, and HO 517's rail pin when a deep-linked member landed on a rail with nothing lit. **A selection the reader made must be visibly located, or the surface reads as broken.** Dropping the fragment would make the test green by removing the behavior instead of restoring it.

### Where the id goes: the stable pane container, deliberately

Put `id="lobby-drill"` on the **`.mc-content lob-content` div** (`app/lobbying/page.tsx:409`), not on the scoped context block at `:411`.

The reason is the fallback path: `:114-117` resolves a well-formed-but-unknown code to `selectedDrill = null` and falls back to **unscoped**, so the scoped block doesn't render. An id living inside it would dangle again on exactly that path — re-creating the bug in a narrower door. The pane container always renders.

The name is then slightly off (`lobby-drill` on a container that's the pane, not the drill). **Leave the name** — it's referenced by the href, the `TopicCrosswalk.tsx:13` comment, and the spec — and add a short comment at the id saying it sits on the stable container on purpose, so nobody "corrects" it onto the scoped block later.

### Promote the assertion

With the target present, `expect.soft` at `:470` becomes meaningful — so promote it to a hard `expect`. That's the HO 473 precedent exactly: soft-assert while a finding is open, hard once it's fixed, which is what makes the suite's green mean something. Keep the surrounding `if (await codeChip.count())` guard as-is; it's guarding chip presence, which is legitimate variability.

Two files: `app/lobbying/page.tsx`, `e2e/fit-finish.spec.ts`.

Commit: `fix(lobbying): HO 572 — restore the #lobby-drill anchor, harden its assertion`

---

## Scope guards

1. Explicit pathspec staging. Never `git add .`.
2. **Two files only.** No CSS, no query changes, no `TopicCrosswalk` edits (its href is already correct — it's the target that went missing).
3. Don't touch the HO 492/493 tuned numbers (rail bound, `.lob-sec-scroll`, `PAGE_SIZE = 13`). An id is not a layout change; if the page height moves, you've done something else.
4. Don't act on the STEP 0 (a) result in this HO. If the schedule never fired, that's a finding, not a build.
5. No `docs/` edits, no `SKILL.md`. HO 573 sweeps.
6. Don't wire `fit-finish.spec.ts` into any workflow. That's the open decision this HO only unblocks.

## Verification

- `npm run typecheck` clean; `npm run build` clean on a fresh `.next`.
- **The landing instrument:** `npx playwright test e2e/fit-finish.spec.ts` goes from **1 failed → 0 failed**, and the `/lobbying` test passes with the now-hard assertion. That reads differently if the work never happened (it stays red), so it's a real instrument, not a regression gate.
- **Exercise the actual behavior, not just the test:** on a local prod build, load `/lobbying`, scroll to BY-CBT-TOPIC, expand a topic, click a constituent code chip, and confirm the scoped pane is in view on arrival. Then repeat at a **short viewport** (~800px tall), which is the case that motivated the fix.
- **The fallback path:** hit `/lobbying?issue=ZZZZ#lobby-drill` (well-formed, unknown) and confirm it renders unscoped with no dangling-anchor behavior and no console error.
- Regression: `/lobbying` unscoped renders unchanged, and page height is unmoved from the HO 492/493 figures.
- Ship: `git push` (fast-forward only, ancestry eyeball first), then `npm run verify:deploy` until served SHA === HEAD.

## Ship report

- STEP 0 (a): the event breakdown, and which of the three outcomes it is. If no `schedule` runs, list which cheap causes you ruled out and how.
- STEP 0 (b): confirmation of the missing id and that the current failure is a thrown evaluate, not a soft red.
- C1: SHA, the two files, and the comment text you left at the id.
- fit-finish before/after counts, with the `/lobbying` test named.
- The short-viewport eyeball and the unknown-code fallback result.
- Anything else you found — file it, don't fix it.
