# HO 395 — Adopt observations: commit + verify deployed tick

Confirm 395 is the next free number before saving (`ls docs/handoffs/ | sort -V | tail`); body assumes 395.

## Decision

The news-as-observations pilot is adopted. `observations` + `observation_entities` become CBT's entity-resolved news layer. The dual-write stays; future member→news / race→news surfaces build on `observation_entities`. This commits the pilot code (already tsc-clean, diffs already reviewed) and closes the one gate the local run couldn't: the deployed cron writing observations inside its budget.

What's NOT being claimed: the envelope's grading and lineage fields (reliability, credibility, cluster_id, supersedes, schema_version) are inert constants right now (all sources B/2, cluster = content_hash). They stay reserved until a second collector or a real consumer needs them. Adopting the spine (obs row + entity join) is the decision; the ornaments ride along dormant. That distinction is recorded in the doc sweep, not here.

## State going in

- The 2 tables already exist on shared prod (the pilot's local `migrate` ran against it). Deploy is code-only. The first deployed tick writes into existing tables. Do NOT re-run migrate as part of this.
- Code changes are working-tree only, uncommitted. Prod DB is currently ahead of committed code; this commit closes that gap.
- Files in the write (already shown, tsc clean): new `lib/observation.ts`, `lib/news-to-observation.ts`, `scripts/diagnostic/news-observations-coverage.ts`; edited `scripts/migrate.ts`, `lib/news-matcher.ts`, `lib/news-ingest.ts`, `lib/rss-parse.ts`, `lib/news-sources.ts`.

## Pre-commit checks (fast; fix in place if either fails)

1. **Index guards.** Confirm all 6 indexes in `scripts/migrate.ts` use `CREATE INDEX IF NOT EXISTS`, not bare `CREATE INDEX`. migrate already ran once, so an unguarded index throws on the next run against shared prod. One grep.
2. **observed_at normalization is explicit.** The 55 obs validated and stored, so RFC-822 → UTC-ISO conversion is working. Confirm it's an explicit normalization step in the mapper, not incidental, so it survives a refactor. If implicit, make it explicit.

## Commit (spec-driven, two separate concerns)

Explicit pathspecs on every `git add` and `git commit`. Never `git add -A`. Recheck ancestry before push (a second Code session touching these files between check and push is the hazard).

- Commit — code only, the 8 files above:
  `feat: adopt observation model as entity-resolved news layer (HO 394)`
- Do NOT touch `SKILL.md` / `roadmap.md` / `oddities.md` / `backlog.md` in this commit. Docs are the next handoff's sweep.

## Deploy + verify (the Gate C close)

1. Push (after ancestry recheck).
2. `npm run verify:deploy` — poll `/api/version` until served SHA matches HEAD. Do NOT proceed until it matches.
3. Force ONE deployed tick (don't wait for the 14:00 UTC schedule): curl the deployed `/api/cron/news` with `Authorization: Bearer $CRON_SECRET`. If the secret isn't reachable from where you're running, say so and fall back to reporting at the next scheduled tick rather than guessing.
4. Verify the deployed tick:
   - `SELECT COUNT(*) FROM observations` before and after — obs rows increased (deployed code wrote them, not just the earlier local run).
   - Tick completed within the route deadline (~45s per HO 117). Report the duration.
   - `cron_runs` row for the tick: no error, dual-write not swallowed by the guarded try/catch. If the catch fired, report the error verbatim. A silent dual-write failure under the deployed budget is the one thing that fails this gate.
   - If the tick fails on the candidate-bills query path rather than the dual-write, flag it as that: it's HO 369 cron-health territory (pre-existing), not a Gate C failure. Report which layer failed.

## Report back

- Served SHA (matches HEAD).
- Deployed-tick duration and the `observations` row delta from that tick.
- Any `cron_runs` error for the tick.
- Confirmation the two pre-commit checks passed, or what you fixed.

No further schema changes. No doc edits (separate sweep). Rollback unchanged if the deployed tick surfaces a problem: DROP the 2 tables + `git revert` the commit.
