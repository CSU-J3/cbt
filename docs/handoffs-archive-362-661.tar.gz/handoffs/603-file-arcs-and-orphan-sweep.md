# HO 603 — file the three untracked arcs, then the primaries display-orphan sweep

**Numbering.** Next after HO 602 (`1f82b55`, landed). Confirm against `docs/roadmap.md`'s pointer and `git log`.

**Two parts, and the order is load-bearing.** Part A is docs and lands first; Part B is code. If Part B stalls, the arcs are still filed, which is the entire point.

**No roadmap block is owed.** Part A files work that has not shipped, and Part B is a deletion sweep on the HO 499/570 precedent. Backlog and oddities only.

---

## §0 — why this exists

The backlog's own header says *nothing is tracked only in chat*. Three arcs are.

An artifact audit against `origin/main`, run before writing this, found each in a different state, and the filing requirement differs accordingly:

| arc | artifact | status |
|---|---|---|
| Absence Watch (HO 588) | `scripts/diagnostic/absence-watch-588.ts` | **tracked** (`7ce1f0e`) |
| Dashboard redesign (HO 590) | `mock-590-dashboard-declutter.html` | **untracked**, `git ls-files` empty |
| Layout audit (HO 591) | `scripts/diagnostic/layout-audit-591.ts` | **never built**, no file matching `591` |

Their only trace in the repo is two roadmap parentheticals saying HO 588's block is owed when the arc ships. **A QUEUED entry pointing at an untracked local file is the same failure as tracking it in chat**, so A2 and A3 must carry their content in prose rather than by reference.

Before writing, check whether `docs/handoffs/591-layout-audit.md` still exists on disk (that directory is gitignored, so it may survive locally). If it does, build A3 from it and treat §A3 below as a checklist rather than the source.

---

# PART A — file the three arcs (one docs commit)

## A1 — Absence Watch → QUEUED

**State:** STEP 0 probe committed and read-only (`7ce1f0e`). Nothing built.

**Surface:** a conditional front-page strip naming current members who have missed a vote threshold.

**The fork is UNRESOLVED and must be recorded as unresolved.** R2 (cumulative missed *rate*) versus R3 (a recent window). R2 was preferred as sticky and near-free because it reused `getParticipationStrip` at a marginal read of about zero. R3 addresses what cumulative is blind to: a member who stopped showing up last month is invisible inside a long denominator.

**The cost half of that argument has expired, and this is the reason not to resume from the design conversation.** HO 594/595 rewrote the participation path onto the materialized `member_participation` table, and HO 602 measured that the pre-materialization `getParticipationStrip` had been **22% of the account's entire read budget**. "Reuses `getParticipationStrip`, marginal read ≈ 0" was a true statement about a function that no longer exists in that form. **Re-derive the cost of both arms against the current materialized path before choosing.**

**Population and delegate carve, copied from `getParticipationStrip` so the strip and the dotplot cannot disagree:** `is_current = 1`; `HAVING COUNT(*) >= PARTICIPATION_FLOOR` (50); delegates carved by the territorial predicate `chamber = 'house' AND state IN ('DC','AS','GU','MP','PR','VI')`, which is population-correctness and not outlier-trimming (HO 527).

**Close/scope instruction, verbatim into the entry:** re-read `scripts/diagnostic/absence-watch-588.ts` **and its output** before scoping. Do not resume from the design conversation that produced the fork; it predates the materialization.

## A2 — Dashboard redesign → QUEUED

**State:** mockup iterated through revision J. **The mock file is untracked**, so this entry carries the decisions and the mock is at most a convenience pointer.

Record these, because each was corrected during the mock arc and will be re-litigated otherwise:

- **Two regions.** A full-height bills/movers column on the **right**, spanning **from the very top, level with the masthead** — not starting below the nav. Everything else stacks in the left region: masthead, market/odds tapes, nav, absence watch, hearings, week strip, breaking news, distributions.
- **The tapes stay horizontal.** They are not converted to a vertical rail.
- **Iteration on the existing dashboard. No parallel v3 route.** Sequenced handoffs against the live page.
- **Row-level packing:** elements pack left via flex, because far-right-anchored elements were stretching rows and opening horizontal voids.
- **Bills column readability:** no boxed bill IDs, no chip borders, no sponsor underlines; a quiet two-line format; colour reserved **exclusively** for stage status (ENACTED green, FLOOR amber, CMTE dim); date-grouped sections TODAY / YESTERDAY / EARLIER THIS WEEK.
- **Cut in the arc, so nobody re-adds them:** the Polarization band (slow-moving data not worth its space); the five-column week grid for hearings, collapsed to a single-day schedule plus a week ribbon; masthead counts that duplicated the stage-distribution chart.

## A3 — Layout audit → QUEUED

**State: nothing was built.** The specified `scripts/diagnostic/layout-audit-591.ts` does not exist.

- **Eight conventions, C1–C8.** **Three have no audit instrument by design** and that is a decision, not a gap: C5 and C6 are review rules, and C8 is C1 seen from the other end.
- **Deliverable as specified:** a read-only Playwright diagnostic with seven measurements, M1–M7.
- **Scoping findings that must survive, because they cost a session to establish:** test against `next start` (a local production build), **not** `next dev`; `/` is gated behind a `ct_seen` cookie that has to be set programmatically; **M6 (dead routes) needs no browser** and is answerable by static analysis; **900px is a bad test width** because it is the CSS breakpoint where the dashboard grid collapses; and **C2's type-scale change has a blast radius of roughly 450 font-size declarations**, with `rem` correct over `em` because `em` compounds under nesting and Tailwind v4's spacing scale is rem-based (~518 utility usages).
- **Verdict condition (HO 549 discipline):** the detector must be proven to fire on a known defect before any zero result is trusted.

---

# PART B — the primaries display-orphan sweep (code)

The HO 559-owed sweep, grep-confirmed at the HO 561 review.

**Targets:** `buildPrimariesCartogram` and `PrimaryBand` (`lib/cartogram-data.ts`), `PrimaryDistrictCard`, `PrimaryRow`, `getPastPrimaries`, `getUpcomingPrimaries`.

**It is not a plain delete.** `PrimaryMapCard`, `primariesFill`, `PrimariesLegend` and the `variant === "primaries"` branches thread through `CartogramShell` — **a live file the races path depends on** — at lines 15 / 23 / 27–28 / 55 / 97 / 352 / 370 / 383 / 456 / 549. Removing the fork may leave `variant` vestigial; decide that explicitly rather than leaving a one-valued parameter behind by accident.

## STEP 0 — verify the target list before deleting anything

**Required, because this exact list-shape has been wrong twice.** HO 570 was sent to delete `.v2f-sponsor*` (live, rendering the sponsor hover card HO 472 had verified) and `weekdayOfKey` (live via `mondayOfKey` **inside its own module**, missed because the planning grep excluded that file from its own consumer search).

For each of the six targets, confirm zero consumers **including within the defining module**, and report the grep per target. Any target with a live consumer comes off the list and is reported, not deleted.

## Gate

**A byte-identical `/electoral` render**, the HO 499 orphan-sweep shape. Capture before and after and diff them. The build compiling every route is the secondary net, since a dangling import fails the build, but it is not the gate.

## Do not

Do **not** "fix" `getPastPrimaries`' `limit = 200` against 612 past rows on the way through. It is moot the moment the function is deleted, and fixing it first is work spent on a corpse.

---

# PART C — the `isSettled` comment (own commit)

The comment-only item opened at HO 601 rides this, because the sweep **is** a primaries code touch and the only other named carrier (the Aug 25 runoff seed) is conditional on nobody clearing 50% on Aug 11 and may never happen.

`isSettled`'s block comment in `lib/primaries-sync.ts` still reads as though the freeze is what stands between a later contest's field and a settled row. Since `efa858f` the **router** is that thing, and the freeze has never observed a substitution. The comment should say so, in the terms HO 602's SKILL entry already uses. Strike the backlog item when it lands.

---

## §5 — guards and commit order

1. **Part A docs commit lands first, alone.** Backlog only (plus oddities if the artifact-status finding earns an entry — a QUEUED entry pointing at an untracked file is the same failure as tracking in chat, which is a shape worth recording).
2. **Part B code commit(s)**, gated on STEP 0's report.
3. **Part C comment commit**, own commit.

- Code and docs commits never mixed.
- Explicit pathspec staging only, never `git add .`.
- `npm run typecheck` before pushing; ancestry eyeball (`git log --oneline @{u}..HEAD`) immediately before.
- **Do not touch the races path.** The whole point of the `/electoral` gate is that races is a live dependent.
- No SKILL edit is anticipated. If one turns out to be needed, it routes through a review ref as its own commit.

## Close

Ship report: the six per-target greps, the `/electoral` before/after diff, whether `variant` was left vestigial or removed, and the three backlog entries as landed. Show the diff before pushing.
