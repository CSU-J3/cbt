# HO 517 — `/news` member rail group, "IN THE NEWS" (Axis B)

Build. **No probe step** — HO 514 (`f7a3de4`) measured this axis and the numbers are in the backlog; don't re-measure what's on record. HEAD going in is `5853f19`.

This reopens the seam HO 515 left deliberately: `?member=` currently renders no rail. After this, the rail carries two groups and member mode is a first-class rail selection rather than a deep-link-only view.

## What HO 514 already settled — inputs, not questions

- **Cardinality GO:** 126 bioguides with ≥1 observation, 39 with ≥3, 10 with ≥10. Head is genuinely newsy (Graham 49 · Thune 29 · Collins 21 · McConnell 20), not matcher boilerplate.
- **Cost:** rollup + name hydration **34ms** off `idx_obs_entities_type_value`. No index work.
- **Coverage:** 495 `person` entity rows → 460 resolved (92.9%); the 35 unresolved carry no bioguide and are honestly unjoinable. **100%** of resolved bioguides hit a live `members` row.
- **The constraint:** the member group needs **its own window**. At 24h the head is 6 members with zero at ≥3, so rebasing on the page's `?window=` empties it.

## Design calls — made, don't re-open

**1. Fixed 30d window, disclosed in the header.** The member group does **not** rebase on `source` / `window` / `signal`. Header reads `IN THE NEWS · 30d` so a user changing the window chip and seeing the member counts hold isn't looking at a bug. Use 30d, not "all-time": they're equivalent today (the observation layer is ~30d old, HO 394 pilot) but the label stays correct as the corpus accrues, where "all-time" would silently become wrong. This is the HO 456 disclose-the-exclusion posture.

**2. Units match; only windows differ.** HO 394 writes one observation per fetched article, so the member group's counts are article counts — same unit as the topic group's distinct-article counts. Say this in a comment. It's the reason two count columns can sit in one rail without the HO 442 incoherence problem, and the next reader will otherwise wonder.

**3. One selection across both groups.** The two groups drive different panes (topic → mention feed, member → observation feed), so they can't both be active. Selecting a topic clears `member`; selecting a member clears `topic`. The rail has exactly one lit row at a time, spanning both groups.

**4. Top 15, header discloses the total.** `IN THE NEWS · 30d · 15 of 126`. The topic group is 24 rows; an uncapped member group at 39+ would push it out of the bounded 520px permanently. 15 is enough for a "who's hot" read.

**5. Pin the active member when they fall outside the top 15.** This is the one thing the probe didn't surface and it *will* fire: the member-hub Press tab out-link (HO 512) can send any of ~535 members here, and only 15 are listed. When `?member=` names someone outside the shown set, **inject their row at the top of the group**, lit, visually marked as pinned (a subtle leading glyph or a hairline separator — your call, keep it quiet). Without this, arriving from a low-coverage member's Press tab renders a rail where nothing is selected — the HO 492 selection-invisibility failure reached through a different door. If the pinned member has zero observations in 30d but some all-time, still render the row with its 30d count (which may be 0) rather than omitting it; the pane below is showing their coverage, so the rail must agree that they're the active scope.

## The query

`getNewsMemberRailCounts(limit = 15)` in `lib/queries.ts`, plus a way to resolve one specific bioguide for the pin (either a second small helper or an optional arg — your call, whichever keeps the cache keys clean; note that an unbounded `activeBioguide` arg makes every visited member its own cache entry, so a separate point-lookup is probably cleaner).

- Drives `observation_entities` (`entity_type='person'`) → `observations`, 30d window, `INNER JOIN members` for name + party, GROUP BY bioguide, ORDER BY count DESC, name-tiebroken.
- Confirm the plan drives `idx_obs_entities_type_value` — the probe says it does; a one-line EXPLAIN check at build time, not a diagnostic script.
- `unstable_cache`, tag **`member-news`** — the semantically correct tag, already flushed by the news cron and already allowlisted on `/api/revalidate` (HO 414). No new cache wiring.
- `try/catch → null`, and null hides **only this group** — the topic group and the feed still render. Same graceful-degrade shape you wired for `hideTopics` at HO 515.

## The chrome

- Second group inside the existing `.nw-rail`, below TOPICS, its own header row. The rail is already bounded and scrolling (`.nw-rail-scroll`, 520px) — both groups live inside that one scroll container; don't give the second group its own nested scroll.
- Rows carry a party dot (the `PartyTag` / `lib/race-colors` colors, not a local map — HO 468 consolidated this), surname-forward name, count.
- `scrollIntoView({ block: "nearest" })` must cover the member group too — with two groups the active row is more likely to be below the fold on arrival, so this matters more here than it did at 515.
- CSS stays additive under `.nw-*`. Re-verify no shared `.mc-*` rule is edited; the containment rule has held through 486 / 492 / 496 / 507 / 515 and this is the fifth test of it.

**Mode contract, updated — restate it in the code comment that HO 515 left:**

- default → rail renders, topic group selectable, member group selectable
- `?topic=` → topic row lit, mention feed
- `?member=` → **rail now renders** (the 515 seam, closed), member row lit (pinned if outside top 15), observation feed
- `?bill=` → still no rail

## Verify

- `npm run typecheck` + build; CI green.
- Prod:
  - Bare `/news` — both groups render, member counts sane against the probe's head (Graham/Thune/Collins/McConnell at the top).
  - Click a member → pane swaps to the observation feed, that row lit, `topic` cleared from the URL.
  - Click a topic while a member is active → member cleared, mention feed returns.
  - **Change `?window=` with a member active — member counts must not move** (the whole point of call 1).
  - **The pin path:** find a member outside the top 15 with ≥1 observation, hit their hub's Press tab out-link, confirm the rail renders with their row pinned and lit. Then a member with zero recent observations — row still pinned and lit, count may read 0.
  - `?bill=` still renders no rail, byte-identical.
  - `/members` / `/lobbying` / `/bills` unchanged.

## Non-goals

- No change to `getMemberNews` or the HO 512 member-mode pane. The rail is additive above it.
- No new nav, no migration, no cron, no index.
- The 35 unjoinable person rows stay excluded — no placeholder rows for entities with no bioguide (the HO 398 challenger edge, same call).
- No source group. SOURCES is dead on cardinality (HO 514) and the backlog now says so.

## Process

Diff before commit, explicit pathspec staging, ancestry eyeball, FF push. Two commits if query and chrome split cleanly (the 515 `a2c825d` / `8bb9618` precedent). Docs are HO 518 — roadmap block, the backlog Axis B item tombstoned, and the SKILL `/news` entry's three-mode contract updated to say the rail renders in member mode now.
