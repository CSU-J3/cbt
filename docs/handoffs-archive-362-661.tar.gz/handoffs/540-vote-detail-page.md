# HO 540 — `/vote/[id]`, the roll-call detail page

**Next HO after this: 541 (the doc sweep).** Take numbering from `docs/roadmap.md`, never from an on-disk filename.

---

## Why this shape, and not the narrow one

The banked item was "the full per-member roll-call drill" — who voted how on an amendment, the v2 expand under the partisan shape HO 530/532 ship. Built narrowly, that's an expand-in-place list on `/bill/[id]`.

Built as a page, the same work serves every roll call the app already stores. Corey's call was the page.

The argument is the HO 501 one. A roll call is an entity CBT tracks (`votes`, 1,513 rows, each with full member positions in `member_votes`) and has no home. Its data currently surfaces only as a fragment of somebody else's page: a tally on the member hub, a party split under an amendment. "Who voted how" is a question about the roll call, and there is nowhere to ask it.

A verifying detail from the code search: **`getVotesByBill` exists, is cached, and has zero consumers.** So `/bill/[id]` renders its amendments' votes but not the bill's own passage votes, and the query for that was written and never wired. That's the shape of a missing entity page, not a missing section.

---

## Scope boundary — read this before building

Fork B's risk is turning into a votes pillar. It does not.

In scope: one detail route, two queries, the inbound links from surfaces that already render a vote, breadcrumb and nav wiring.

Explicitly out, all banked, none to be built here:

- No `/votes` index, aggregate, or feed. There is no votes browse surface and this HO does not create one.
- No bill-hub votes section. `getVotesByBill` stays orphaned. Wiring it is a natural follow-on and gets its own HO.
- No sync changes. `votes` and `member_votes` ingestion is untouched.
- No changes to the member hub's voting-record section beyond making its rows link out.
- No weekly-report changes. The HO 358 floor-votes section is generated markdown; linkifying it is a separate concern.

If the build starts touching a fifth file outside this list, stop and report.

---

## STEP 0 — bounded, but measure the worst case

Read-only, committed as `scripts/diagnostic/vote-detail-cost-540.ts`. Short. The seek is bounded by construction (the `member_votes` PK is `(vote_id, bioguide_id)`, so `WHERE vote_id = ?` is a leading-column seek, and a chamber caps the row count), which is the HO 448/450 no-probe-needed shape. Two things still want numbers before committing to a live query.

1. **The worst-case position list, cold.** A House roll call is roughly 435 rows plus a `members` join for name, party, state. Time it cold on the largest House vote and the largest Senate vote. EXPLAIN both; confirm the PK seek and the members join plan.

2. **The `member_votes` lag population.** Count `votes` rows that carry a tally but have zero `member_votes`. HO 533 found this class on the newest roll calls, where the vote list syncs ahead of member detail. Report how many, and how old the newest such vote is. This sets the empty-state copy, and it must not read as "nobody voted."

Also report the distribution of `bill_id` presence across `votes` (how many roll calls carry no bill), since that decides how often the page renders without a bill link.

Bring numbers back before build code.

---

## Commit 1 — the query layer

Two new cached queries in `lib/queries.ts`. Both are **new siblings**, not widenings — the HO 496/512/537 discipline.

**`getVoteById(voteId)`** — a point lookup returning the vote's own record. Reuse the existing `VOTE_SELECT` constant and `rowToVote` mapper rather than writing a fourth SELECT shape over `votes`; they already carry the `LEFT JOIN bills` and the null-bill fallback. Returns `null` for an unknown id.

**`getVoteMemberPositions(voteId)`** — the drill. `member_votes` seek joined to `members` for display name, party, state. Return a flat array of plain objects; group in the component, not the query. Normalize party through the existing `normalizePartyVariant` so the party colors match every other surface.

Both carry `try/catch`, both return JSON-serializable values only. **No Map, Set, Date, or class in a cached return** — HO 533's rule, which cost three deploys.

**Derive the cache tags from the tables each query reads**, not from the pillar. These read `votes`, `member_votes`, `members`, and `bills`. That's the HO 537 oddity, and it was a live near-miss in that arc. Check which tag names actually exist before assigning them; don't invent one.

---

## Commit 2 — the page

`app/vote/[id]/page.tsx`, plus a component for the position list.

The id is the TEXT composite (`senate-119-1-3`, `house-119-2-269`), already URL-safe, so it's the route param directly. An unknown id calls `notFound()`.

**The head** carries what identifies the roll call: chamber, congress, session, roll-call number, date, the question text, the result, and the tally with its D/R/I party split. The party split is the same aggregate `getBillAmendmentVotes` computes, so the numbers must agree with the vote line that linked here. When `bill_id` is present, link the bill. When the vote is on an amendment, link the amendment's bill — the `amendment_votes` link table resolves that in both directions now.

**The position list** is the reason the page exists. Group by position (Yea, Nay, Present, Not Voting), and within each group sort by party then surname, so cross-party defectors cluster at the party boundary rather than scattering alphabetically. That ordering is the whole analytical value; don't sort by state or by name alone.

Names are party-colored through the shared `partyColor` from `lib/race-colors` (HO 468 — one canonical helper, no local map) and link to `/members/[bioguideId]`. Position colors come from the existing tokens: `--vote-yea`, `--vote-nay`, `--vote-present`. **There is no not-voting token** — use `--text-dim` rather than minting one.

**The lag empty state matters.** A vote whose `member_votes` haven't synced has a real tally and no positions. It must say the positions aren't available yet, never render as an empty roll. Same principle as HO 533's zero-split guard: wrong is worse than absent. Step 0 measurement 2 tells you how common this is.

Use `RecordTabs` only if the content genuinely wants tabs. A single position list does not; a flat sectioned page is right. Don't reach for the shell out of habit.

---

## Commit 3 — inbound links

This is what makes it a page rather than an orphan.

**`components/AmendmentVoteLine.tsx`** — the tally becomes a link to `/vote/[voteId]`. Because HO 537 C2 extracted this component, one edit lights the drill on both `/bill/[id]` and the `/amendments` corpus feed. That extraction paying off here is the reason it was done as its own commit.

**`components/MemberVoteRow.tsx`** — each row on the member hub's voting record links to the roll call.

Keep the link styling consistent with the app's existing out-link idiom; the tally is the anchor, not a separate "details" affordance.

**Wiring.** Add `/vote/[id]` to `lib/breadcrumb.ts`. Section segments are `["Legislation", "Votes"]`, with the roll-call label appended via `opts.detail` from data the page already fetched. Nomination and treaty votes sitting under Legislation is a known imperfection, accepted because floor roll calls are overwhelmingly legislative and a conditional crumb buys little. Also give it a `pathToNavKey` line so the nav lights correctly — find where that function lives and follow the HO 501 precedent.

---

## Verification

Cache-hit path throughout: hit each URL two or three times, or wait out the revalidate window. The HO 533 regression shipped three times because every check landed in the post-deploy miss window.

- A Senate amendment vote reached from `/bill/119-hr-1` — head numbers match the vote line that linked there, positions sum to the tally.
- A House amendment vote reached from `/bill/119-hr-8800`, same checks.
- The largest House roll call renders its full list without layout break.
- A vote with no `bill_id` renders cleanly with no dead bill link.
- An unknown id returns 404, not a 500.
- A lagging vote (if Step 0 found one) shows the tally with the positions-pending state.
- The member hub's voting record links out and the rows are otherwise unchanged.
- Regression: `/bill/119-hr-1` still shows 13 vote lines, `/bill/119-hr-8800` 19 tallies and 18 splits. The `AmendmentVoteLine` edit is the only thing that could disturb those.
- `npm run typecheck` and `npm run build` clean; `verify:deploy` serves HEAD.

---

## Constraints

Explicit pathspec staging, never `git add .`. Diff shown and approved before every commit. Three commits, separate, in order — query layer, page, links — each a clean revert boundary.

Nothing here touches `SKILL.md`; the doc sweep is HO 541 and routes its SKILL edit through a review ref. If any diff in this HO needs reading rather than summarizing, push it to `refs/heads/540-review` rather than pasting it twice.

Report Step 0 numbers first, then per-commit diffs.
