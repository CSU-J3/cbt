# HO 614 — P4: `/lobbying`, the shared rail, and one more orphan claim.

HEAD `5e272d8`. Pointer "run through HO 610." **Next free is 614.** After this: the phase close (615) — leg-C fixture, instrument v3 (multi-rect + M5 banding + M5 ellipsis class), `.mc-pane` rail scope-check, `HearingsList` removal, and the P4 sweep. None of that is here.

**Leg C runs on the fallback list** (`/stale` 51, `/bills` 1). §2 must verify `/stale` shares nothing with the work **by dependency, not by route name** — the 613 lesson: grep the components this HO touches (`FilingRow`, `.mc-crow` consumers, anything in §1–§3) against `/stale`'s render tree before the first commit, and print the result. If any overlap exists, HALT and say so before proceeding; the fallback list has no depth left to absorb another expiry.

## 0. Re-baseline before believing anything

Two shared-class inheritances may have already moved `/lobbying` silently: 613's commit 1 packed `.mc-fbar` (lobbying's bar is literally that class), and 612's cap landed on `.mc-row` (which `FilingRow` rides under a `.lob-filing-row` override whose extent needs reading, `globals.css:6001` + the comment at `:5661`). Run `--route lobbying` and `--route news` at HEAD, decompose the worst-10, and paste it as step 0. The pre-613 67 is not the baseline; whatever this prints is.

## 1. Commit 1 — `FilingRow` packs

From the step-0 decomposition, expected shape: the registrant/client `1fr` track gapping to the issues/bills cells. The kit applies:

- If the rc-ink spread exceeds the threshold, it's knee time again — print the curve, take the elbow, `title` the clipped, report like 612/613 did. If the spread is under, skip the cap and say so; the curve decides.
- **The issues `micro-tag` chips become plain dim text** — they're labels, and the C3 rule (chips survive only as interactive affordances) has governed since 609. The bills cell's chips are links with hover behavior: **interactive, they stay.** That one row demonstrating both halves of the chip rule is worth a line in the HALT.
- Any pin found at any depth goes (613 found three at three levels; assume nothing).

`FilingRow` renders on `/bill/[id]` (`BillLobbying`) too — spot `--route bill-detail` and label its drift as shared-component, expected.

`fix(lobbying): HO 614 — FilingRow packs; issue chips to plain text, bill chips stay interactive (C1/C3)`

## 2. Commit 2 — the shared `.mc-crow` rail rows

The 15 deferred `/news` M1a plus lobbying's share sit on `.mc-crow` (`16px 30px 1fr 56px 28px`, `globals.css:5479`). **Decompose before designing**: a 312px rail structurally can't hold a 120px interior gap, so the hits are coming from a wider rendering context — find which (`nw-rail` width, the lobbying issue rail, or a third consumer), print where and at what px, then pack accordingly (the fixed trailing cells follow the ink; same move as everywhere). Score the shared win: `/news` M1a 15 → 0 and lobbying's rail hits → 0, in the same commit.

Consumers to verify before touching: `NewsMemberRailRow`, `NewsTopicRailRow`, `IssueRailRow`, `CommitteeRailRow` — the class is a family, and the fix must hold on every renderer or be scoped to a variant, stated either way.

`fix(rail): HO 614 — mc-crow rail rows pack; the deferred /news 15 and lobbying's share clear together (C1)`

## 3. Commit 3 — the IssueDrill claim (conditional on the grep)

`FilingRow.tsx:5`'s comment calls `IssueDrill` orphaned. This arc has falsified enough comments that the comment is the hypothesis, not the finding: `git grep -n "IssueDrill" -- app/ components/`. Zero consumers → `git rm` it plus its CSS (per-selector grep with a positive control, per the backlog's `.pdc` warning — never prefix-sweep). Consumers exist → correct the comment instead, cite the grep, and file nothing. Either way the commit message states which branch fired.

`chore(lobbying): HO 614 — IssueDrill: the comment's orphan claim, resolved by grep` (adjust to the outcome)

## 4. Verification and guards

1. Commits in order, typecheck + build each, explicit pathspecs.
2. Leg C (`/stale`) before any zero is trusted, **after** the §-preamble dependency grep proves it can't expire mid-HO.
3. Scores per stage, v2-labeled: `/lobbying` → residual decomposed (marginal / axis / multi-rect-artifact — the artifact class is now legitimate vocabulary, but only with the px evidence attached, never as an unexamined bucket); `/news` → its 15 cleared; `/bill-detail` drift labeled; `/`, `/members`, `/bills` spot-unmoved.
4. Narrow buckets at 1024/900/720 for `/lobbying`: (a)/(b) split, doc-width noted — if the 883-class rail failure appears here, it joins the phase-close `.mc-pane` item with its number, not this HO.
5. Eyeball 1440/2560: filing rows packed, expand panel opens, issue text reads, bill chips click, the drill flow (`?issue=`) works scoped and unscoped, rail rows packed in both consumers.
6. Prod-verify, converged. **HALT** with step 0, the curve (or its waiver), the rail decomposition, the grep verdict, and the dependency-check print. No fixture, no instrument work, no `.mc-pane`, no sweep — all 615.
7. Absence Watch untouched. `data-viz-row` unused. `--fs` tokens 9–14px.
