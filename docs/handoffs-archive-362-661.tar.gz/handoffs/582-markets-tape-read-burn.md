# HO 582 — Markets tape read burn: STEP 0 probe, HALT, then the fix

## 0. Context

Turso rows-read is a live budget (the July account-wide block; CBT attributed at ~85–90M rows/day since ~Jul 25). The backlog OPEN LOOP "Markets tape read burn (HO 577)" pinned the mechanism by code read; this HO measures it, halts, then fixes it. Two confident read-cost claims were falsified on inspection this month (the read-budget WATCH), so nothing below ships on arithmetic — STEP 0 measures first.

The mechanism, as read at `1cf6cbc`:

- `getLatestMarketTicks` (`lib/queries.ts`, `export const getLatestMarketTicks = unstable_cache(...)`) has cache options `{ tags: ["markets"], revalidate: 60 }`. `MarketsTapeClient` polls `/api/markets/latest` at `POLL_MS = 60_000`. TTL equals the poll interval, so any open tab drives roughly one SWR regeneration per minute, around the clock (~1,440/day). Runtime logs previously showed ~4 req/min sustained (~4 tabs); under SWR that still collapses to ~1 regen/min, the requests beyond the first in each window are hits.
- Each regeneration runs two statements: **Q1**, latest-per-symbol via `INNER JOIN (SELECT symbol, MAX(ticked_at) FROM market_ticks GROUP BY symbol)`; **Q2**, the HO 374 spark window with `julianday(ticked_at) >= julianday('now','-9 day')`. The `julianday()` wrap on the column defeats `idx_market_ticks_symbol_time`, so within each of the sparkKeys symbols (19 minus polymarket) SQLite reads every row that symbol owns, not the 9-day slice.
- **One writer, tag-covered:** `market_ticks` is inserted by exactly one route, `/api/cron/markets` (the `0 */4` full pass and the weekday `0,30 13-21` `?source=fmp` pass are the same route), and that route already calls `revalidateTag("markets")`. The kalshi cron does not write `market_ticks` (it revalidates `"races"`). This single-writer tag coverage is what makes decoupling the TTL (C1) safe — but it's a claim, so M0 verifies it rather than inheriting it.
- `app/api/markets/latest/route.ts`'s header comment asserts "no per-request DB hit between writes," which is false today (revalidate 60 expires between cron writes every minute). The backlog assigns that comment fix to this HO, not a doc sweep.

## STEP 0 — `scripts/diagnostic/markets-read-burn-582.ts` (read-only)

No writes anywhere. Commit the diagnostic alone, run it, report M0–M4, and **HALT — no build code before the halt clears.**

**M0 — writer census (static, printed in the report).** Grep every `INSERT INTO market_ticks` site and every `revalidateTag("markets")` site across `app/` + `lib/` + `scripts/`. Expected: exactly one of each, both in `app/api/cron/markets/route.ts`. Any second writer, or a writer without the tag flush, changes C1 — flag it and stop there.

**M1 — table shape.** `COUNT(*)`; per-symbol counts (all symbols present, flag any not in `MARKET_SYMBOLS`); `MIN`/`MAX(ticked_at)`; rows/day over the trailing 14 days; one verbatim `ticked_at` sample. Expect `new Date().toISOString()` format (`YYYY-MM-DDTHH:MM:SS.sssZ`) — C2's comparison bound depends on the stored representation, so confirm it, don't assume it.

**M2 — per-regeneration cost as shipped.** `EXPLAIN QUERY PLAN` for Q1 and Q2 verbatim; classify SCAN vs SEARCH per loop; compute the analytic rows-read per regeneration (Q2 ≈ the sum of rows across sparkKeys symbols under the non-sargable predicate; Q1 per its plan — SQLite's minmax-per-group optimization may already seek on `idx_market_ticks_symbol_time`, the plan decides). Then instrument cold-ish timing for both, 3 runs each — a clean EXPLAIN says nothing about latency, and rows-read is the currency here, so report both.

**M3 — the rewrite candidates, equivalence-gated.**
- (a) Q2 with the predicate replaced by `AND ticked_at >= ?`, arg = a JS ISO bound. EXPLAIN must show a per-symbol range SEARCH on `idx_market_ticks_symbol_time`. Before timing it, assert row-for-row equivalence against shipped Q2 (same rows, same order) at the same instant. Any divergence → report, don't rationalize.
- (b) Only if M2 shows Q1 scanning: per-symbol `ORDER BY ticked_at DESC LIMIT 1` over `MARKET_SYMBOLS` (symbols absent from the table return nothing, same as today). Equivalence-gate the same way. If Q1 already seeks, record that and C3 is a no-op.

**M4 — burn model + attribution.** Rows/regen (M2) × regen rate under two regimes: poll-driven as shipped (~1,440/day while ≥1 tab is open) vs write-driven post-fix (~24/weekday: 6 full-pass + 18 fmp ticks; 6/weekend day). State the daily figure and its fraction of the 85–90M/day plateau. If the fraction is small, say so plainly — the fix still ships (it's nearly free), but the read-budget backlog item then stays open pointing at summarize / LDA / traffic, and the report should say that in those words.

**M4b (optional).** Per-DB rows-read from the Turso dashboard or `turso org usage` before/after a 10-regeneration burst (call the Q1+Q2 pair directly 10×). Only if the number is visible without querying the DB — do **not** use `turso db inspect` (it queries the DB in some versions). If usage doesn't update within the session, record `M4b: SKIPPED (usage latency)` and rely on M2×model.

## Build (after HALT clears)

**C1 — decouple the TTL from the poll (unconditional).** `revalidate: 60` → `revalidate: 86400` on `getLatestMarketTicks`. The tag flush is the freshness mechanism; the day-long TTL is a bounded-staleness backstop if a flush is ever missed, not a refresh path — comment it exactly that way so nobody "tightens" it back to the poll interval. Add one regeneration marker inside the cached fn (`console.log("[markets] regenerating market-ticks-latest")`) — the fix's own instrument: post-fix, runtime logs should show it at cron cadence, not per-minute. Correct the false header comment in `app/api/markets/latest/route.ts` in this commit (it becomes true under C1: fresh on `revalidateTag`, cached between writes).

**C2 — sargable spark window (gated on M3a equivalence PASS, expected).** Replace the `julianday(...)` predicate with `AND ticked_at >= ?`, arg = `new Date(Date.now() - 9 * 86_400_000).toISOString()`. Do **not** use SQLite `datetime('now','-9 day')` — it emits `YYYY-MM-DD HH:MM:SS` (space, no `T`/`Z`), and lexicographic comparison of that against ISO-T text is subtly wrong at the day boundary; the JS bound matches the stored representation exactly (M1 confirms). Window semantics unchanged: still 9 days, the sparkline still slices ≤7d in JS, the delta anchor logic untouched.

**C3 — Q1 shape (gated on M2 showing a scan; skip if minmax already seeks).** The M3b rewrite, only if it pays.

**C4 — visibility-gate the poll (unconditional).** In the `MarketsTapeClient` poll effect (the `fetch("/api/markets/latest")` one — not the `setNow` interval above it), skip the fetch when `document.visibilityState === "hidden"`, and add a `visibilitychange` listener that polls immediately on return to visible. `POLL_MS` unchanged. C1 already makes hidden-tab polls cheap server-side; this kills the abandoned-tab multiplier at the source and is defense in depth.

Commit order: C1 alone → C2 (+C3 if live) → C4. Code and docs never mixed.

## Verification (the HO 555 convergence rule)

1. `/api/version` shows the new SHA before anything else is read.
2. Functional freshness: after the next markets cron tick, `/api/markets/latest` returns the new tick with no redeploy — that's the tag flush doing the work under the long TTL. Hit 3×; the value holds.
3. Regen rate: with a tab left open ≥15 min, the C1 marker appears in runtime logs at cron cadence only.
4. The real close (the backlog's own instrument): Turso per-DB rows-read slope over the following ~24h, against tab count. Put the before/after in the ship report — the OPEN LOOP closes on that number, not on the deploy.

## Scope guards

- STEP 0 writes nothing, anywhere. Diagnostic commit strictly separate from build commits.
- No `vercel.json` change, no cron cadence change, no kalshi route change.
- No schema, no migration — `idx_market_ticks_symbol_time` already exists. If M2/M3 appear to want a new index, HALT and report instead of adding one.
- No tape render / shuffle / hover changes beyond the C4 poll-effect guard. HO 376 shuffle and the HO 374 hover payload untouched; the `MarketTick` shape unchanged; the return stays plain arrays/objects (HO 533).
- Explicit pathspec staging; `npm run typecheck` before every push; ancestry eyeball (`git log --oneline @{u}..HEAD`, exactly one commit, clean fast-forward); fast-forward only on main.
- `docs/roadmap.md` is authoritative for the HO number; if it disagrees with this filename, the roadmap wins.
