# HO 611 — P4 opens: `/hearings` to an agenda, plus the ActiveFilterStrip rider.

HEAD `2fdee12`. Roadmap pointer: "run through HO 610." **Next free is 611.** P4 order is ruled in the backlog audit entry: hearings → members → bills/news/trades → lobbying. Sweeps defer to P4's close unless a claim on main goes false mid-phase.

**Start from the handover's own two notes:** every P3 number is v1 and the P4 baseline is v2 — no mixed tables, ever, and any table in a HALT labels its instrument. And the hearings interior transplants *primitives*, not the pattern: `HearingsDaySchedule` and `HearingDetailCard` are factored and reusable; the one-day-plus-ribbon **layout** is a glance pattern and this route is a browse surface. Transplanting it whole would delete what `→ ALL` exists to reach.

Baseline (v2, `audit-e6bbc08-2560.json`): `/hearings` M1 **3** · **M2 9, the site's largest** · M4 carried by "No meetings" columns. M5: clean at every narrow width — the one route that was, and it must stay that way.

## 1. Commit 1 — the rider: pack `ActiveFilterStrip` left

Site-wide chrome, independent of hearings, lands first. The strip (`components/ActiveFilterStrip.tsx:25–52`) renders `.active-filter-summary` then `.active-filter-actions`; the 1,347px interior gap says the actions are pinned right (find the `margin-left:auto` or equivalent in the `.active-filter-*` CSS and delete it). Target state: summary, `·`, actions, packed left; trailing gap collects right. No behavior change, no prop change.

Score: `--route home-stage-committee` before and after — the strip's over-threshold row **1 → 0**, everything else on that route flat.

`fix(chrome): HO 611 — ActiveFilterStrip packs left (C1; the conditional-chrome row every unfiltered pass missed)`

## 2. Commit 2 — the agenda

Replace `HearingsCalendar`'s per-week five-column `hcal-grid` with, per week:

- **The weekhead stays** — `WEEK OF {mon} {dom}` · `WeekStat` with its existing hover popover and delta. Untouched.
- **A ribbon row** under it: five cells MON–FRI, bold count for days with meetings, `—` for empty, `is-today` marked. The dashboard's `.rib` is the visual reference; at route scale the ribbon is **per week** (two of them at `weeks={2}`). Cells for days with meetings act as in-page anchors to their day section below (plain `<a href="#hday-...">`; no state machinery).
- **Stacked day sections, days with meetings only.** Each: a day heading (`WED JUL 29 · 5`) and the meetings via the factored primitives — `HearingsDaySchedule`'s row shape or `HearingRow`, whichever the current route rows already are, with `HearingDetailCard` behavior preserved (click/expand exactly as today). **Uncapped** — no per-day cap here; caps were the embedded tab's constraint, not the route's.
- **An empty day renders nothing below the ribbon.** Its entire footprint is the dash in its cell — C4 at route scale. An entirely empty week renders its weekhead, its ribbon of dashes, and one dim line (`Nothing scheduled this week.`), which recess makes the common case, not the edge case.

**Stays untouched, verified not assumed:** the TYPE/CHAMBER filter controls, `showCorpus` readout, the two-week span, the `weeks` prop, and whatever renders `HearingsList` (HO 267's secondary cuts) — grep its consumers before believing it's separate. The kill list is exactly: `hcal-grid`, `hcal-day`, `hcal-day-empty`, `hcal-day-list` and their CSS, plus the equal-height mechanics that put M2 at 9.

This inverts nothing from 610 — same C4 logic, different scale: the glance surface shows *one* day fully; the browse surface shows *every* day that has content and charges empty days a dash.

`feat(hearings): HO 611 — per-week ribbon + agenda replaces the five-column grid (C4; M2 9→0)`

## 3. Commit 3 — the orphaned embedded mode

`HearingsCalendar.tsx:5–6` says the dashboard tab used an `embedded` single-week, per-day-capped mode and now doesn't. Grep for the prop's consumers; if the route is the component's only renderer and nothing passes `embedded`, strip the mode and its branches (and any `embedded`-only CSS). If something still consumes it, report the consumer and leave it — this commit is conditional on the grep, not on the comment.

`chore(hearings): HO 611 — strip the orphaned embedded mode (dashboard tab moved off it at 610)`

## 4. Scoring and verification

1. Typecheck + build per commit; explicit pathspecs; ancestry eyeball reads two or three depending on §3's grep.
2. **v2 falsification before trusting any zero, with its own leg C**: the known-BAD control (`--route members`, must hold ~548) runs alongside — legs that only assert *less* are satisfied by silence, per the arc doc's standing rule.
3. `--route hearings` at 2560, before commit 2 and after commit 3: **M2 9 → 0**, **M4 → near-0** (name any residue), **M1 ≤ 3 and decomposed if it moved**, M1x expected 0 (no viz rows here — if the ribbon trips M1, decompose before reaching for `data-viz-row`; a ribbon is navigation, not a chart, and the exemption must not become a pressure valve).
4. **Narrow ladder guard:** `/hearings` at 1024/900/720 before and after — it was the clean route; overflow/extra-wrap must not appear. The ribbon takes a wrap rule if it needs one; nothing gets pinned right to save a wrap (the M5-debt entry's guard, applied here).
5. Eyeball at 1440 and 2560: agenda reads top-to-bottom, ribbon anchors jump correctly, detail cards expand, filters filter, corpus readout intact, recess week (there should be one in range in August) renders as specced.
6. Push, prod-verify to the SHA with a converged read, **HALT** with both score tables (labeled v2) and the §3 grep result. No members work, no sweep.

## 5. Guards

1. Absence Watch untouched. `/members` untouched (next HO).
2. The dashboard's `HearingsTab` and its day schedule: consumed, not modified — if commit 2 wants to change a shared primitive, that's a stop-and-report, not a refactor.
3. `--fs` tokens for any size 9–14px; ribbon cells reuse the dashboard's ribbon tokens/classes where they genuinely share, house-named otherwise.
4. Code only; the backlog's ActiveFilterStrip line gets its DONE strike at the P4 sweep, not here.
