# HO 599 — doc sweep for HO 598 (the `/lobbying?q=` arc)

**Numbering.** `docs/roadmap.md`'s pointer tail reads 586 → 590 → 595 → 597, so **598 is unrecorded** and this sweep is **599**. HO 597 is fully swept already (`f3d8987`, `5525189`, `2542462`, `665a356`, `0235bb2`), and two pieces of 598 landed inline — the FTS rejection and the `getBillLobbying` WATCH at `3ba7f4d`, and the backlog narrowing at `163bbe2`. Everything else from 598 is undocumented. HO 588's block remains owed when that arc ships.

**Docs only.** Four lanes, four commits: `docs(skill)` · `docs` (roadmap) · `docs` (oddities) · `docs` (backlog). **Roadmap through a review ref**, deleted after the fast-forward.

This arc reversed itself three times and shipped over a failed gate. The reversals and the gate reasoning are the valuable part; get those right before the numbers.

---

## Lane 1 — `docs/roadmap.md`, one new append-only block

Pointer: **"Also notes now run through HO 598."** Tail becomes 586 → 590 → 595 → 597 → 598, each N once, monotonic. Close with **"Docs: HO 599."** Do not retro-edit any prior block, and note that the HO 597 correction block deliberately carries no pointer.

Narrate 598 as the sequence it actually was, because the shape is the lesson:

- **The reframe.** The LIKE was never the cost — the walk is. `COUNT(*) WHERE registrant_name IS NOT NULL`, a name-column read with no predicate to evaluate, measured **86.3s co-located**. Cost tracks bytes dragged off the table, not the predicate and not the match count.
- **FTS re-verified and rejected again**, on a *new* reason. HO 546's premises still hold (columns 25.1/27.6 chars, 5,326 registrants + 22,422 clients = 27,748 names across 129,401 filings); its number expired (~700ms → 91.3s). But the deciding argument is neither: FTS5 can't do infix, so `%oeing%` stops matching "Boeing" — and FTS fixes the **sparse** half while still needing routing for dense, exactly as the name table does. Both solve the same half; the name table wins on every remaining axis. **Record my earlier framing ("FTS solves a half that isn't broken") as wrong** — sparse *is* the broken half.
- **The `~700ms → 91.3s` delta is UNATTRIBUTED**, not a platform regression. `oddities.md:235` records no measurement conditions for the 700ms while the entry beside it records `7.8s cold` — the same arc distinguished cold for one number and not the other. Unexplained between growth (1.15×), conditions, and platform.
- **Two gate failures, rewire withheld both times**, then a third round that cleared everything except sparse.
- **Two retractions**, each recorded as a retraction: the STEP 0 assertion that "the corpus is NOT the cause" (nothing measured supported it), and the 12.6s routing price (leg 2 was charged for the name scan leg 1 had already done — with ids passed through, leg 2 is 0–1.5s).
- **Shipped:** the bounded COUNT (`1afdd02`, 58.1s → 2.25s on common terms), the honest timeout render (`79d1276`), `lda_names` + indexes + writer (`4fd9b48`, `e7fdf30`, `85a173f`), the routed rewire (`e4f09ba`), the completeness instrument (`a4e2c1c`), and the arg-binding fix (`06d03dd`).
- **Final measurements:** 24 runs, 0 breaches, median 3,291ms, worst 7,735ms. Prod verified across all regimes — boeing 13/78, insur 13/520+, hospital 13/520+, zzqx… 0 with "No filings match" in ~400ms (was 91.3s).
- **Shipped over a failed gate, deliberately**, with the three conditions stated (see Lane 3). The loop is **narrowed, not closed**.
- **A bug shipped and was caught in prod in minutes** by an instrument this arc added: `e4f09ba` left the bounded COUNT binding 2 args against a 17-arg routed predicate; the guard degraded instead of 500ing. Both safety nets were built in the preceding four HOs.

State theme impact (correctness and reliability; the only user-facing change is search returning right answers and honest failures) and the prod verification line.

---

## Lane 2 — `docs/oddities.md`, **appended at the end**

Six entries, findings with measurements attached.

1. **A lookup table doesn't beat a walk — it rotates the failure.** The shipped path's cost is *inversely* proportional to match density: a dense term fills the page and short-circuits the `dt_posted` walk immediately; a sparse one walks everything. A name-lookup table is *proportional* to it: sparse seeks a few ids, dense resolves ~3,928 ids and seeks ~50k rows then TEMP B-TREEs them. Measured: `boeing` 19.8s → 8.83s, `llc` **58.1s → 182.5s**. Each path is fast exactly where the other is slow, so substitution fails and **routing** is the fix.
2. **`m* = √(k·N)` is the derived crossover for a fill-a-page-then-stop feed.** Expected rows walked ≈ `N × (k ÷ matches)`, so the two paths cross where matches ≈ `√(k·N)` — `√(13 × 129,401) ≈ 1,297`, about 1% density. **Derived, not tuned** — the distinction that separates it from `PAGE_SIZE=13`. Straddle-verified at 0.86× (`insur`, 1,119) and 1.16× (`hospital`, 1,500), routing correctly on both sides. The hint rides in the same scan that resolves the names at no distinguishable cost, and **over-counts** (84 vs 78; 55,834 vs 50,197), which routes toward the walk — the conservative direction.
3. **The empty short-circuit is a correctness dependency, not an optimisation.** Because `lda_names` is complete, an empty id set *proves* an empty answer without touching `lda_filings` (zero-match 91.3s → ~400ms). The inverse is the danger: any gap in `lda_names` renders as a confident "No filings match" — a silent wrong answer, the exact defect this HO existed to kill. Hence `namesUnreachable` in the sync payload, `chronicErr`, and a greppable `[lda] names-unreachable:` prefix, with the **maintenance** path proven (a synthetic new name searchable immediately), not just the backfill.
4. **Verifying one branch of a `Promise.all` is not coverage of the pair.** The e2e harness compares the page query's rows and never executes the COUNT, so it reported green while the bounded COUNT bound 2 args against a 17-arg predicate. The failure modes are independent; verification must execute every branch. **Eighth instance** of the family in oddities entry 4 — a check whose pass doesn't depend on the thing it claims to cover.
5. **Use the upper tail, not the range, when gating on variance.** `max − min` penalises a *fast* outlier, which is evidence of safety, not risk: a 380ms best case widened sparse's "spread" to 7.36s. The quantity that predicts a breach is `worst − median`. Corrected: sparse 4.23s, dense 3.11s, zero 3.34s (from 7.36 / 3.79 / 4.90).
6. **The bytes model holds across a 23× size change; the variance does not shrink with it.** 22.9 MB → 86s against ~1 MB → 6.6s is roughly linear, so removing data buys the median as predicted. But the 2–15× run-to-run spread on identical work rides at every size — a ~1 MB scan still ranges 0.3–6.6s. **Shrinking data buys the median, not the variance.**

---

## Lane 3 — `.claude/skills/cbt/SKILL.md`, its own commit

Two additions, both in the authoring/decision path rather than a post-mortem section.

**(a) The ship-over-a-failed-gate precedent, with its boundaries.** This will be leaned on, so write the fence before the rule:

> A measured improvement MAY ship over a failed margin gate only when **all three** hold:
> 1. **Strict dominance** — better than the incumbent in *every* measured regime, not on average. (Here: the replaced sparse path breached on both retry attempts at its *best* observed 19.8s; the candidate went 0-for-24 with worst 7.7s.)
> 2. **Honest failure** — when it does fail, it says so rather than returning a wrong answer.
> 3. **The loop stays open** — the entry is narrowed with the residual named and owned, never closed.
>
> This is **not** a licence to ship anything merely better. HO 594's retraction was for **closing** on a thin margin, not for improving on one. Withholding a dominant improvement to avoid a rare failure preserves a certain one.

Add the upper-tail statistic (`worst − median`) as the gate's measure, with the reason.

**(b) Derive crossovers, don't tune them.** For a feed that fills a page and stops, the routing threshold follows from the short-circuit arithmetic (`m* = √(k·N)`) and needs no fitting. Cross-reference `PAGE_SIZE=13` as the counter-example — a threshold tuned on one day's data. Add the `Promise.all` coverage rule beside the existing verification bullets.

---

## Lane 4 — `docs/backlog.md`

- **`/lobbying?q=`** — already narrowed at `163bbe2`; verify it reads correctly and add the `06d03dd` arg-binding bug plus the `Promise.all` coverage gap that let it through.
- **Promote the variance to its own OPEN LOOP.** Three HOs — 594, 597, 598 — have each been decided by the same 2–15× run-to-run spread on identical work rather than by the query they were scoped around, and it is the entire residual here (leg 1's ~1 MB scan, 0.3–6.6s). The standing explanation is sub-60s page residency on a remote store, **never probed on its own terms**. Record it as **blocked on the platform read**: `turso org usage`, plan tier, primary region against the Vercel function region, and whether the DB has replicas.
- **The burn prediction** from HO 594/595 — three full 366k-row scans removed from the request path — is still **logged and unscored**, blocked on the same platform read. Record as owed and unscored, not unfalsifiable.
- `getBillLobbying` WATCH already filed at `3ba7f4d`; leave it.

---

## Scope guards

1. **Docs only.** No code, no queries, no migrations.
2. **Four commits**, SKILL in its own lane.
3. **Roadmap through a review ref.**
4. **Never retro-edit a prior block.** The HO 546 FTS oddity is superseded by the new reason, not rewritten — its premises still hold and only its number and conclusion expired, and that distinction is the point.
5. **Oddities append at the end.**
6. **Do not close the `/lobbying?q=` entry** and **do not touch the `pageErr` #418 OPEN LOOP.**
