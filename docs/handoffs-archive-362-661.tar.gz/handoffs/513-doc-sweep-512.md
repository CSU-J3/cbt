# HO 513 — doc sweep for HO 512 (`?member=` on `/news` + Press out-link)

Docs-only. No code files in this commit; it must not ride with anything else. HEAD going in is `af3ab90`.

## 1. `docs/roadmap.md`

Append a new dated **"Also (HO 512)"** block at the end of the Also run and bump the running pointer to `**Also notes now run through HO 512.**` Append-only — do not retro-edit the HO 509–510 block or any earlier one.

Content the block owes:

- **What shipped** (`af3ab90`, three files, one commit): `/news` gains a `?member=` mode; the member-hub Press tab gains `View press coverage →`.
- **The mechanism correction, which is the block's load-bearing content.** The backlog's close-path said `getNewsFeed` already joins `observation_entities` — it doesn't. `getNewsFeed` drives `news_mentions m INNER JOIN bills b`; a person-filter bolted on there would have returned only articles that both name the member *and* matched a bill, a strict subset of what the Press tab previews. So member mode is a **branch to the observation layer** (`getMemberNews`, the exact query the tab already renders), not a filter on the mention feed — **zero `lib/queries.ts` changes**, the HO 501 route-split precedent where the honest fix was structural rather than another param on the existing query.
- **Precedence:** when `member` parses it owns the view — `bill`/`source`/`topic`/`window`/`signal`/`page` are ignored and not carried; the pill's ✕ returns to bare `/news`. `getMember` null renders member mode with the raw id + empty state (never a 404); parse-fail falls through to the unscoped feed.
- **The filter-bar asymmetry, stated as a rule so it isn't "fixed" later:** member mode early-branches to render *only* the member pill, because observation rows carry no source/topic/window/signal dims — dead chips would imply filtering that isn't happening. Bill mode keeps its chips because bill-scoped rows are still `news_mentions`. Both are correct.
- **The cap asymmetry, disclosed:** the tab previews `getMemberNews(…, 8)`, the out-link serves `NEWS_MEMBER_CAP = 50` (file-local, the HO 493 precedent), so the out-link deliberately lands on *more* rows than the tab it came from — the opposite direction from Bills/Trades, whose out-links exist because their counts exceed the shown rows. Hence **no count in the label**: `count: news.length` is a cap, not a total, and "View all N" would be a lie.
- **Also record what wasn't done:** no `getObservationNews` fold — the HO 414 debt triggers on a 3rd *projection*, and this is a 3rd *caller* of the existing helper at a raised limit (the HO 470 "adds callers, not a third projection" line applies); no pagination, no total-count query, no `getNewsFeed` change of any kind.
- **No theme-% change** — a cross-link on existing surfaces, matching the HO 509–510 precedent. It **discharges** the backlog's Press-out-link item in full.
- Close with `Docs: HO 513.` then the pointer line.

## 2. `docs/backlog.md`

Tombstone **line ~67** (`**Member-hub Press tab has no out-link (HO 509–510)**`) — strike it through, mark SHIPPED `af3ab90`, and **correct its own mechanism claim inside the tombstone**. The line's *close* path was wrong, not just imprecise: don't paraphrase it away, say plainly that `getNewsFeed` does not touch `observation_entities` and that the fix branched to `getMemberNews` instead, so a future reader who finds the old wording elsewhere knows which is right. Carry the precedence rule, the pill-only filter branch, and the cap asymmetry.

Nothing else in the backlog changes. In particular the `/news` source-spine two-pane follow-on stays QUEUED and untouched — this HO added a mode, not the rail.

## 3. `.claude/skills/cbt/SKILL.md`

Two entries, and the second is the one that's easy to miss.

**(a) The `/news` entry (~line 1424).** It currently reads "Five news params only." That's now wrong. Rewrite to six, with `member` described as a **mode, not a dim**: it branches off `getNewsFeed` entirely to `getMemberNews(bioguideId, 50)`, renders `RaceNewsRow` rows (not `NewsRow`) in the same bordered container, drops the `news-header-row` chrome (its Bill column misaligns the `--no-bill` grid) and the pager, ignores every other param, and takes the member-pill-only `NewsFilters` branch. Note the page-local `parseMember` copied from `app/trades/page.tsx` (two consumers, deliberately not extracted). Note the `member-news` cache tag already covers it (HO 414) — no new cache wiring.

**(b) The `/members/[bioguideId]` entry (~line 1420).** Its Press-tab clause literally says **"no out-link — `/news` carries no `?member=` param, backlog QUEUED"**. Replace it: out-link `View press coverage → /news?member=` when `news.length > 0`, no count in the label (the count is the cap-8 preview), no out-link at zero. Leave the rest of the tab list alone.

The SKILL `/news` entry has now gone stale the same way the `/lobbying` entry did across HO 491/492/493 — that was flagged as a process observation at HO 494 with a "third time and the convention needs revisiting" trigger. This is a different entry, so the trigger doesn't fire; don't act on it, but if a *third* surface entry goes stale between a ship and its sweep, raise it.

## 4. `docs/oddities.md`

One new entry, worth having because the trap is generic rather than about this feature:

> **A helper that "already joins X" may not — check the FROM clause, not the neighborhood (HO 512).** The backlog line proposing this feature asserted `getNewsFeed` joins `observation_entities` because the news *pillar* has an observation layer (HO 394) and two sibling helpers (`getRaceNews`, `getMemberNews`) do join it. `getNewsFeed` drives `news_mentions INNER JOIN bills` and never touches the observation tables. Had the filter been built where the backlog pointed, it would have shipped green — a person-filter over bill-matched mentions returns rows, just the wrong subset (~the fraction of a member's coverage that also matched a bill), so **the failure would have been a quietly short list on the out-link, not an error**. A backlog line's *mechanism* is a claim like any other; the probe-before-fix rule covers it.

Cross-reference it from the roadmap block.

## Verify

`npm run typecheck` (docs-only, but the repo convention runs it), then read the three edited docs back for the append-only rule — confirm no prior dated roadmap block's text moved, and that the pointer bumped exactly once.

## Process

Diff shown before commit. **`SKILL.md` is in this diff, so the self-mod guard applies** — commit locally, push to a review ref (`git push origin HEAD:refs/heads/513-review`), let me read the diff out of the repo and approve, then push main fast-forward and delete the ref. That's the default route for any SKILL commit, not a fallback after a failed paste. If the SKILL edits and the roadmap/backlog/oddities edits are easier to reason about apart, split them into two commits (SKILL alone in the second) — but they can ride together as a single docs commit if you prefer, since the whole commit goes through the review ref either way.
