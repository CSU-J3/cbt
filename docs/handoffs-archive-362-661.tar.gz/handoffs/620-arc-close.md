# HO 620 — the arc close: instrument v4, the terminal baseline, and the sweep that tells the whole story.

HEAD `d56608e`. Pointer "run through HO 615." **Next free is 620.** This is the last HO of the arc. Two HALTs: after the terminal crawl, and on the review ref. Code commits first, docs last, never mixed.

**Why v4 ships now instead of filing:** the terminal crawl is the maintenance baseline every future HO reads, and v3 hands it two known lies — M4 96.7% furniture, M3 blind to every 2-child row (the 796-chip convergence was invisible to the instrument built to score it). The scroll-by-design entry already ruled the venue: *an instrument commit with its own falsification leg, and the fixture is where its positive and negative go.* This is that commit.

## 1. Commit 1 — instrument v4 + the fixture grows

Four measurement changes, no thresholds, falsified on the fixture before any route:

1. **M4 splits: M4-true vs M4f (furniture).** An M4 candidate inside a repeated-sibling row context with non-empty short text is **furniture**, counted on its own `M4f` line (the M1x pattern). M4-true keeps the vocabulary + genuinely-empty cases. The 617 hand-split becomes the instrument's own output.
2. **M4w — width-reserved slots.** An empty element with an explicit width ≥40px inside a repeated row (the `/stale` `.row-hslot` shape, height-invisible to M4 by construction). Counted separately; the live instance is fixed, so the fixture carries the only positive.
3. **M5 scroll-by-design**, exactly per its backlog shape: own computed `overflow-x` auto/scroll/hidden with an animated or explicitly-scrollable child, **outermost of a nesting chain counted once** (six levels of one marquee was the whole distortion). New `M5s` column; (b) becomes real-only.
4. **M3 samples all repeated-sibling groups with ≥2 element children** (was: ≥3 children via M1a). The 2-child chip rows enter; the per-route means will move and **that movement is instrument, not product** — the era wall applies to M3 now too.

**Fixture additions**, each labeled with its expected reading: a furniture row (stars + short IDs in tall cells → M4f, never M4-true), a width-reserved empty slot (→ M4w exactly 1), a mock marquee two levels deep (→ M5s exactly 1, not 2), a 2-child chip row with three own-styled chips (→ enters M3, mean ~3). Existing positives/negatives/calibration unchanged and must still read exactly.

Falsification: all fixture readings, then the worked examples on routes — `/members` M4 84px → mostly M4f, `/` narrow (b) 86–88 → M5s 1 + (b) ~+85px-doc-item, `/changes` M3 3.00 → moves and is labeled. Leg C floor holds.

`diag(layout): HO 620 — instrument v4: M4 furniture/width split, M5s, M3 full-row sampling (fixture-falsified; era wall v3/v4)`

## 2. Commit 2 — the closeout pair

- **`/bill/[id]`'s three metabox chips**: grep the hrefs; function decides the border, same rule, no special case. One-line change or a stated no-op.
- **`/welcome`'s `landing_readout`** (331/290 at 900, real (b), predates P6b): wrap-don't-pin, `minmax` not fixed, per the kit. The maintenance baseline should not ship with a known real narrow defect on the front door.

`fix(closeout): HO 620 — metabox chips by function; the landing readout wraps (the last real (b) item)`

## 3. The terminal crawl — bridge + baseline

Run **v3 once and v4 once on the same DOM**, the 615 bridge pattern: the v3 column closes the arc's chain attributed (any v3→v4 delta is instrument, stated per route), the **v4 table is the maintenance baseline** — full routes, narrow subset, M1/M1x/M2/M3/M4-true/M4f/M4w/M5x/M5s/(b), burn ledger.

Then the two identities that define "done", checked as arithmetic, not prose:

- **site M1 == the residue register's sum** (17 as of `d56608e`; whatever commit 2 makes it), entry by entry.
- **site M1x == the registry's sum** (332 pending PatternBars' entry), marking by marking.

Any mismatch is a stop: either the register is missing a line or the instrument moved something unstated. **First HALT here** with both tables, both identities, and the fixture's full reading.

## 4. The arc sweep — `refs/heads/620-review`, docs commit + SKILL commit

**Roadmap block, 616–620, pointer → 620.** The close's spine: the P4-residual's three-answers demonstration and the Firms correction (applied-not-modelled, the false claim quoted in place); P5's opposite-verdict axis pair (magnitude marked, sequence capped) and the plateau curve; P6a's C4-in-C1-clothes with the uniform-gap tell, the heat ruling split by meaning, `/changes` closing by inheritance in its own words, **site M1a → 0**; P6b's rails (negative-dead left alone), the 796-chip convergence M3 couldn't see, the register printed; 620's v4 with its rationale and the era chain **v1 2,152 → v2 1,634 → 312 → v3 180 → 27 → v4 <terminal>**, every arrow attributed instrument or product, the do-not-launder clause carried to the end. Close on the arc's one-line identity: *site M1 equals named residue; site M1x equals the registry; nothing unexplained.*

**Backlog:** P5/P6a/P6b/close struck DONE with pointers; the **PatternBars registry entry** written from the draft (applied curve, 18/6, the TopicCrosswalk-shape note); the registry gains the **kind annotation** (positional encodings qualify — the ideology axis is the worked example — and the metabox outcome recorded); the **permanent-residue register** becomes a standing entry (close: never, the register/registry pair *is* the definition of done); M5 scroll-by-design and the M4 furniture items **struck as taken at v4**; a short **maintenance note**: future layout work runs fixture legs first, labels its era, and re-checks both identities after any change.

**Oddities (append at end):** the uniform-gap signature (fixed reservation vs content stretch — C4 in C1's clothes); width-blind M4 (height-keyed instrument, width-shaped defect); M3's 2-child blindness (with the reframe: several cited means measured nav, not feed); the cascade pair (tied specificity losing to source order silently; `border-color: transparent` still boxes); the 27→4 commit-message laundering near-miss, caught pre-push.

**SKILL (own commit, two rules):** (1) **Accepted residue is cited, never subtracted** — a defect count nets nothing for the register; "27 → 17 with the register named" is the form, "27 → 4" is the laundering (HO 619, caught at the message). (2) **A convention change to a shared component is verified in every variant branch** — desktop, responsive, embedded; the 609 `variant="v2"` miss and the 619 `TopicChips` mobile branch are the two citations that made it a rule.

**Arc-md:** the era table extends to v4; the phase table closes every row; a final §: the register/registry identity as the arc's definition of done and the maintenance loop for whoever touches layout next.

**Second HALT on the ref** with the block and both diffs. Gates at land: pointer greps ("HO 615" ×1, "HO 620" ×1), oddities at end, registry sums restated, both SKILL rules present, era chain attributed in the block.

## 5. Guards

1. Commit order §1 → §2 → crawl → sweep; typecheck + build each; explicit pathspecs; the crawl commits nothing.
2. v4 ships only on a fully-green fixture — every old reading exact, every new reading exact. A near-miss is a stop, and *check whether the control is clean before touching the assertion* still governs.
3. No new `data-viz-row` beyond writing PatternBars' drafted entry; no route work beyond §2's pair.
4. Era labels on every table; the bridge run is mandatory, not optional.
5. Absence Watch untouched — seventeen HOs, first to last, and its backlog entry survives the arc it outlasted.
