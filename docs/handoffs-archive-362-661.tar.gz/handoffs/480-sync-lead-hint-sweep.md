# HO 480 — `/api/sync` lead-query hint sweep

**Type:** fix, hint-only, no migration, no schedule change. Closes the `/api/sync trailing-step timeout` OPEN LOOP (HO 477). Two commits: the query sweep (code), then the doc reconciliation. This is the HO 405–406 / 407 pattern, applied to the sibling function 407 missed.

---

## What HO 479 established

`/api/sync` timed out on 32 of its last 40 ticks (~80%), all pinned at the 55s soft cap — a standing condition, not a wobble. The overrun is **not** Gemini-latency-dominated (that was HO 479's stated hypothesis, and it was wrong). It's the HO 405/407 **cold-DB-stall** class.

Anatomy from the 7 success rows: `reportCatchup` negligible (≤35ms, 0 gap days), `sync` budget-pins its 30s floor (`budgetStopped=true`) every real-delta tick, `trades` 2.4–7.5s, and **`lead` swings 3.6–20s — the variable that tips the wall.** `sync(30) + lead(14–20) + trades(2.4–7.5)` sits right on the 55s line; the survivors are the ticks where lead came in low.

Part B pinned the lead swing: `gatherLeadData`'s **transitions query cold-stalls to 12,483ms** with the `[db] timeout, retrying` signature (10s `boundedFetch` + 10s retry) and then **fails** — warm re-run of all four lead queries + the Gemini call was 1,168ms total, Gemini itself sub-second. EXPLAIN pinned the cause: the `(is_ceremonial=0 OR is_ceremonial IS NULL)` OR-predicate lures the planner into `MULTI-INDEX OR` over the low-selectivity `idx_bills_is_ceremonial` (~most of ~16.8k rows) + `USE TEMP B-TREE FOR ORDER BY`, **ignoring the perfect `idx_bills_stage_changed_at`**. `INDEXED BY idx_bills_stage_changed_at` collapses it to a single sorted range (warm 357ms) — the identical hint-only 407 remedy, no migration.

**The finding worse than the symptom:** the mis-plan wasn't merely timing the route out — it was *failing* the lead-transitions query (10s+10s → throw, caught non-fatal), so the dashboard lead has been silently going stale on every real-delta tick, not just on the ticks that tripped the 55s cap.

---

## Why this is a sweep, not a one-liner

HO 407 fixed this exact class by hinting `gatherReportData`'s six `bills` queries — but it never touched `gatherLeadData`, the identical class in a **sibling function**. `transRs` is the query Part B happened to stall on; the other lead reads carry the same shape and will mis-plan under the same cold conditions:

- `topicRs` — `FROM bills, json_each(bills.topics)` with the same `stage_changed_at` window + the same OR predicate.
- `introRs` — the same OR predicate + an `introduced_date` range.

Hint `transRs` alone and we risk shipping, then finding `topicRs` cold-stalls on the next heavy tick — the exact fix-one-miss-the-sibling trap that created this loop. Sweep the function.

---

## Commit 1 — the hint sweep (`lib/dashboard-lead.ts`, `gatherLeadData`)

Cold-EXPLAIN each of the four lead reads from idle; apply `INDEXED BY` to **every one that shows the OR-lured `MULTI-INDEX OR` / `TEMP B-TREE` plan**, and leave the clean ones alone (don't force-pessimize a query that already plans well).

- **`transRs`** (transitions) — **PROVEN.** `FROM bills INDEXED BY idx_bills_stage_changed_at`. Matches `report-generation.ts:676` (the 407 fix) exactly; the ORDER BY is `stage_changed_at DESC` and the index is `(stage_changed_at DESC)` — a clean single sorted range.
- **`topicRs`** (topic breakdown, `bills × json_each`) — same window + OR predicate. Expect `INDEXED BY idx_bills_stage_changed_at`. 407's Q6 (`json_each + GROUP BY`) held its hint cold; **verify** the `json_each` cross-join still takes the range hint here rather than re-planning.
- **`introRs`** (intro COUNT) — OR predicate + `introduced_date` range. Expect `INDEXED BY idx_bills_introduced_date` (matches 407's intro-count hint). Verify.
- **`queryEnactedThisWeek`** (the shared HO 232 helper `gatherLeadData` calls) — expect **already clean** (rides `idx_bills_enacted`, HO 335). EXPLAIN to confirm. **If it mis-plans, stop and flag it before touching** — it's a shared helper (the ENACTED THIS WEEK banner also renders it), so a hint there has blast radius beyond lead and wants its own scoping, not a drive-by edit in this commit.

**Per-query verification (the 407 bar):** cold EXPLAIN must read `SEARCH bills USING INDEX <hinted>` as a single range — **not** `MULTI-INDEX OR` and **not** `USE TEMP B-TREE FOR ORDER BY`. Then cold-time the full `generateDashboardLead()` end-to-end from idle: it should drop from the ~14–20s stall band to ~1s (Part B warm was 1,168ms incl. Gemini), with **no `[db] timeout, retrying` line**.

**The wall after the fix:** `sync (~30 budget-pinned) + lead (~1) + trades (2.4–7.5) ≈ 33–38s` — comfortably under the 55s cap. Route finalizes `success`; the dashboard lead stops silently failing. Close criterion met.

---

## Commit 2 — doc reconciliation (docs-only, separate commit)

- **backlog:** strike the `/api/sync trailing-step timeout` OPEN LOOP → DONE tombstone (fix shipped, close-criterion met). Reference the HO 479 probe + this fix.
- **roadmap:** an `Also (HO 480)` block — a **correctness fix, no theme-% change** (the HO 405–413 bucket: hint-only, closes an operational cron loop, not new surface). Bump the running "Also notes now run through" pointer to 480.
- **oddities:** one entry — the **6th appearance** of the stateless-planner OR-lured `MULTI-INDEX OR` mis-plan, and specifically that **`gatherLeadData` was the sibling `gatherReportData`'s HO 407 sweep never touched**, so the class wasn't fully closed at 407. Record the second-order finding: the mis-plan was *failing* the lead-transitions query (10s+10s → throw, non-fatal), so the dashboard lead had been silently stale on every real-delta tick — a worse condition than the visible 55s timeout implied.

---

## Out of scope (explicit — do not do these here)

- **The `wrapCronRoute` instrumentation gap.** Timeout rows carry no per-step timings: the finalize catch-branch writes `{ok, elapsedMs, error, status}`, not the handler's `timings` (which live in a closure the wrapper can't reach on the `Promise.race` reject). Real and worth fixing, but it's a **fleet-wide `wrapCronRoute` contract change** (a mutable accumulator the handler mutates + the wrapper serializes on the timeout branch) touching all 14 crons, and it does **not** close this loop — once the hint lands, `/api/sync` stops timing out and its success-row timings record as normal, so this fix is verifiable without it. → its own follow-up HO.
- **FMP `AbortController` / split trades to `/api/cron/trades`.** Latent, not today's cause: FMP `-latest` free tier `402`s past page 0, so `maxPagesPerChamber:3` is a no-op past page 0; the GETs are 50–250ms and never hung (the probe guard never tripped); trades' 2.4–7.5s is ~200 sequential `INSERT OR IGNORE` round-trips, not network. Banked; revisit only if those inserts stay material after commit 1 (they won't tip the wall on their own).
- **No migration** — `idx_bills_stage_changed_at` and `idx_bills_introduced_date` both already exist (`migrate.ts:944` and the introduced-date index). **No `vercel.json` / schedule change. No model or prompt change.**

---

## Guardrails

- Commit 1 touches `lib/dashboard-lead.ts` only. Commit 2 touches `docs/` only. Stage each by **explicit pathspec** — a concurrent session holds untracked files that must not be staged.
- **No auto-commit.** Show me each diff, the per-query cold EXPLAIN (before → after), and the `generateDashboardLead()` cold-time; wait for approval per commit.
- **Ancestry check immediately before any push** (commits riding clean, fast-forward, concurrent session's files untouched). No force-push. Keep the two commits separate (code, then docs).

---

read docs/handoffs/480-sync-lead-hint-sweep.md and follow it
