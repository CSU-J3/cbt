# HO 510 — `/bill/[id]` onto `RecordTabs`

## Why

HO 509 built the record box and proved it in prod on the member hub. `/bill/[id]` is its second consumer, and the reason the component was built shared rather than page-local.

The bill page today stacks four full-width sections under the hero — Committees | Hearings (paired), Amendments, Lobbying — and on `119-s-4784` (NDAA FY2027) that's ~2,600px of page for a surface whose hero already answers the framing question. Same problem the member hub had, same fix.

Approved mock: `mock-510-bill-detail-record-box.html`.

**The hero does not change.** Not one `.bxp-*` rule, not one line of the title row, stage bar, summary, related-news block or metabox. HO 507's containment rule stands and the feed expand panel must stay byte-identical. This handoff touches only what's *below* the hero.

## Ground truth

Clone / hard-reset to `origin/main`; HEAD should be **`8538660`** (HO 509). Re-grep line references at write time.

## Scope

`app/bill/[id]/page.tsx` (sections → box), `components/RecordTabs.tsx` (one additive prop), `app/globals.css` (deletions + nothing new). No query changes — every tab's content comes from the existing `Promise.all`. Rows unchanged: `BillCommitteeItem`, `HearingMeetingsEmbed`, `BillAmendments`, `BillLobbying`.

---

## 1. `RecordTabs` — one additive prop

```ts
initialKey?: string;   // which tab opens; falls back to tabs[0] when unset or unmatched
```

Resolve it once for the initial `useState` value (`tabs.findIndex(t => t.key === initialKey)`, `-1` → `0`). Nothing else changes; the member hub doesn't pass it and must stay behaviorally identical.

**Why a prop and not sorting the array:** tab ORDER stays the page's contract (509's design), but order and default-open are now separable concerns. The bill page wants a stable strip *and* a smart opening panel — sorting the array would give it a strip that reshuffles per bill, which is the thing worth avoiding.

## 2. The page

### Tab set

**A tab exists only when its section renders today.** This is the deliberate opposite of the member hub, and the reason is different data shape: a member always *is* something (0 disclosed trades is a fact about them), while most of the 15k-bill corpus has no committees, no hearings, no amendments and no lobbying — a wall of four dimmed tabs would be noise on the majority of bills.

Follows for free: when nothing qualifies, `tabs` is empty, `RecordTabs` returns `null` (its existing contract), and no box renders — exactly today's section-omission behavior. Verify that path explicitly.

### Order — fixed, legislative-process order

`Committees · Hearings · Amendments · Lobbying`. Referral → hearings → floor amendments → outside money. Same top-to-bottom order the page has now, so this is a compaction, not an IA change.

### `initialKey` — highest count among present tabs

Ties break toward the earlier tab in the fixed order. So `119-s-4784` opens on Amendments (872) and a typical bill with one committee referral opens on Committees, without the strip ever reordering.

| Tab | Count | `.rec-note` sticky line | Out-link | Content |
|---|---|---|---|---|
| Committees | `committees.length` | — | none | the existing `<ul className="px-4 py-2">` of `BillCommitteeItem` |
| Hearings | `meetings.length` | — | `/hearings →` | `HearingMeetingsEmbed` (`hideBills`), and the existing `meetingOverflow` foot stays **inside the panel** |
| Amendments | `amendments.length` | `{n} agreed · {n} failed` — only the clauses that are non-zero, i.e. `amStat` minus its leading `(count)` element | `/amendments →` → `/amendments?bill=${bill.id}` | `<BillAmendments rows={amendments} />` |
| Lobbying | `lobbying.distinctFilings` | `{filings} filings · {clients} clients` | none | `<BillLobbying drill={lobbying} />` |

The two `.rec-note` lines are where HO 507's fold-into-header stats land now that the strip only carries label + count. Same information, one level down.

### Deletions

- **`SectionShell`** — page-local (defined at ~L118, and `grep -rn "SectionShell" app/ components/` returns only this file). Delete it with the last caller.
- The `hasCommittees` / `hasHearings` / `pair` / `committeesBlk` / `hearingsBlk` scaffolding collapses into the tab array.
- **`.bdp .bdp-pair`**, its `> section` rule and its ≤900px media query — the box supersedes side-by-side pairing.
- **`.bdp .bdp-amend-scroll`** — `.rec-body`'s bound supersedes the 340px one.
- **`.bdp-out`** — `SectionShell` was its consumer and `.rec-out` replaces it. **Grep before deleting**; if anything else uses it, leave it and report.

Retire the `.mhp-hb3` comment's reference to `.bdp-pair`'s lone-survivor branch (`globals.css` ~L9377) since the rule it cites is going away — reword to describe the behavior, don't leave a pointer to a deleted selector.

### Unchanged below the hero

The footer `<details className="bdp-foot">` raw-JSON row stays exactly as-is, as do `.bdp-foot*`, `.bdp-latext`, `.bdp-sponsorlnk`, `.bdp-ptag`, `.bdp-relfoot`, `.bdp-mlink`, `.bdp-rawpre`. The `.bdp` wrapper on `<main>` stays.

---

## Verification

- **`119-s-4784`** (the mock's subject): four tabs, opens on Amendments (872), agreed/failed note line, lobbying note reads `85 filings · 83 clients`, out-links swap correctly.
- **A bill with committees only** — one tab, opens on it, no strip weirdness with a single tab.
- **A bill with none of the four** — **no box at all**, hero flows straight into the footer. This is the important one.
- **`119-sconres-7`** — the HO 507 amendment magnet: renders inside the bounded body, doesn't set page height.
- **A bill with hearings overflow** — the `N more · see all on /hearings →` foot renders inside the panel.
- **The feed expand panel is byte-identical** — the HO 507 check, re-run. Diff `globals.css` and confirm every `.bxp-*` rule is untouched and the only changes are the three `.bdp` deletions.
- **`/members/[bioguideId]` unchanged** — the `initialKey` addition is additive; the member hub passes nothing and must render identically. Spot-check that its Bills tab still opens by default.
- **Tab mechanics** — internal out-links are `next/link` (the HO 509 follow-up fix), external stays `<a target="_blank">`.
- **≤900px** — strip wraps, out-link drops below.
- `npm run typecheck` green.

## Git discipline

- Hard-reset to `origin/main` (`8538660`) first.
- Explicit pathspec: `app/bill/[id]/page.tsx`, `components/RecordTabs.tsx`, `app/globals.css`. Nothing else.
- **Live UI → show the diff hunks and wait for approval before committing.** Given HO 508's relay swallow, default to the review-ref route: commit locally, `git push origin HEAD:refs/heads/ho-510-review`, I read the diff out of the repo, then main FF and delete the ref.
- One commit: `feat(bill): /bill/[id] onto the shared RecordTabs box (HO 510)`.
- Ancestry eyeball before push; fast-forward only.
- **No docs.** The roadmap + backlog + SKILL sweep covering 509 and 510 together is the next HO.

## Report back

The page diff, the `RecordTabs` hunk, the three CSS deletions, the `.bdp-out` grep, and the verification list — flagging the no-box case and the expand-panel byte-identity explicitly.

---

read docs/handoffs/510-bill-detail-record-box.md and follow it
