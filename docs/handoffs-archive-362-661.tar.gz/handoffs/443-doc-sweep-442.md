# HO 443 — doc sweep: top-firms leaderboard (HO 442)

Pure doc reconciliation for HO 442 (shipped `b64e1c7` data+cron/CLI · `69644fd` surface, deployed
`69644fd`). No code. Three docs. **Append-only discipline throughout:** do NOT retro-edit the HO 437
or HO 439–440 "Also" blocks or their banked clauses — close the arc by ADDING, and strike (never
delete) superseded entries.

Ground-truth note: `SKILL.md` is **untracked/local** (like the handoffs — `git ls-files` confirms
it's not in the repo), and the uploaded snapshot predates the entire LDA arc, so neither I nor the
clone can pin its LDA section. Grep your **live local** `SKILL.md` for the anchors below.

There is **no `docs/oddities.md` edit** — HO 442 surfaced no trap or premise correction. The
"Cornerstone tops filing-volume, not revenue" result is the feature working as intended, not an
oddity. Confirm and skip oddities.

---

## 1. `docs/roadmap.md` — append the HO 442 block, bump the pointer

Insert as a new paragraph **immediately after** the HO 439–440 block (the paragraph ending
`Docs: HO 441. **Also notes now run through HO 440.**`) and **immediately before** the
`**Banked / unbuilt:**` line. Verbatim:

> **Also (HO 442), the corpus-wide top-firms leaderboard — the LDA arc's last banked surface, no theme-% change.** The third and final item banked in the HO 437 block (bill-keyed → HO 439–440; the CBT-topic crosswalk stays banked; this closes top-firms). Shipped + prod-verified across `b64e1c7` (data + cron/CLI) · `69644fd` (surface); live SHA `69644fd`. **No cost probe** — unlike every prior `lda_*` surface (434→435, 439→440), this introduced no new cold query: `computeTopFirms` is a **third consumer of the shared `readLdaTables` pass** (beside `computeIssueRollup` + `computeBillDrill`), one in-memory grouping over the already-loaded `filings` map, so the build/probe split didn't apply — it rode the ~96s pass already running. Written to a **third `dashboard_state` blob** (`lda_top_firms`) in the same budget-gated cron step under the single `revalidateTag("lda")`; the CLI (`npm run lda:rollup`) mirrors it, so local regen writes all three blobs. **Definition:** ranks **registrants** (the lobbying shops — consistent with `topFirms` everywhere else) by **distinct filings** (the HO 435 house rule), name-tiebroken; per firm carries distinct clients, bill-linked filing count, and their single most-cited `general_issue_code`. **Top 25** (one constant `TOP_FIRMS_N`, store == render). **Surface:** a **TOP FIRMS section on `/lobbying`** (new Section 3, between the issue-drill two-column and the recent-filings feed) served O(1) from `getTopFirms()` (null before the first rollup → section cleanly omitted); the separate blob key keeps the 286KB `/lobbying` rollup read lean (the HO 440 rationale). Mobile: the Top-issue + Bill-linked columns collapse below ~640px (Tailwind, no `globals.css` coupling). **Two deliberate omissions, recorded so they aren't re-litigated:** (a) **no dollar ranking** — LD-2 income/expenses are partial + income-vs-expense asymmetric across registrant types, so a summed-dollar leaderboard would mislead; dollars are the banked **LD-203** money surface; (b) **native issue-code labels, NOT crosswalked to the 24 CBT topics** — that crosswalk is the other still-banked item. **The finding:** rank-1 is **Cornerstone Government Affairs**, #2 Brownstein Hyatt — a filing-**volume** ranking is deliberately distinct from a revenue ranking (Cornerstone runs a huge book of small clients → files a mountain of LD-2s without top-grossing), which is exactly the signal this cut adds over the dollar rankings. Invariants at rollup: **25 firms of 5,175 registrants**, 0 `billLinked > filings`, 0 null `topIssueCode`; the Section-1 readout `stats.registrants` and the leaderboard `totalRegistrants` both render **5,175** (structurally guaranteed — same `readLdaTables` filings map — so no masthead incoherence). **No migration, no new cron slot, no new nav item.** **No theme-% change** — an enabling/aggregate surface on the LDA pillar (the `/patterns` class), matching HO 437/439–440. Docs: HO 443. **Also notes now run through HO 442.**

**Do not touch the `**Banked / unbuilt:**` line** — top-firms was never on it (it was banked inside
the HO 437 / 439–440 dated blocks only, which stay as-is). No prune here.

---

## 2. `docs/backlog.md` — strike L83, add a DONE tombstone, extend L84

### 2a. Strike the BANKED entry in place (currently ~L83)

`old_str` (the current bullet):

> - **Corpus-wide top-firms leaderboard — HO 437.** A static "biggest lobbying shops" cut. *Gate:* the per-issue drill's top-firms is the sharper view (firms in context of what they lobby), so a standalone all-firms leaderboard is banked unless a "who's the biggest shop overall" surface is wanted.

`new_str` (strike + pointer, matching the QUEUED tombstone idiom):

> - ~~**Corpus-wide top-firms leaderboard — HO 437.** A static "biggest lobbying shops" cut.~~ — **SHIPPED HO 442** (`b64e1c7` data+cron/CLI · `69644fd` surface), see DONE.

### 2b. Extend the standalone-slot clause (currently ~L84)

In the `**`/api/cron/lda-rollup` standalone slot — HO 437.**` bullet, the trailing sentence reads
`**Now guards both blobs (HO 440):** `lda_bill_drill` writes inside the same `ROLLUP_RESERVE_MS`
gate as `lda_lobbying_rollup`, so on a burst-day skip **both** go a day stale together; the
standalone-slot fallback, if built, carries both.` Update it for the third blob:

`old_str`: `**Now guards both blobs (HO 440):**` … `carries both.` (the whole sentence)

`new_str`:

> **Now guards three blobs (HO 440/442):** `lda_bill_drill` (440) and `lda_top_firms` (442) both write inside the same `ROLLUP_RESERVE_MS` gate as `lda_lobbying_rollup`, so on a burst-day skip **all three** go a day stale together; the standalone-slot fallback, if built, carries all three.

### 2c. Add the DONE tombstone (top of the `## DONE` section, ~L175)

Match the HO 419/440 tombstone format:

> - ~~**Corpus-wide top-firms leaderboard (HO 442)**~~ — SHIPPED (`b64e1c7` data+cron/CLI · `69644fd` surface, deployed `69644fd`, prod-verified). `computeTopFirms` is a **third consumer of the shared `readLdaTables` pass** (beside `computeIssueRollup`/`computeBillDrill` — pure in-memory grouping, no new scan, so **no cost probe** was needed), writing a **third `dashboard_state` blob** `lda_top_firms` in the same budget-gated cron step + `revalidateTag("lda")`; the CLI (`npm run lda:rollup`) mirrors it. Ranks **registrants** by **distinct filings** (HO 435 rule), name-tiebroken; per firm: distinct clients + bill-linked count + single most-cited `general_issue_code`. **Top 25** (`TOP_FIRMS_N`, store == render). Surface: a **TOP FIRMS section on `/lobbying`** between the drill and the recent feed (`getTopFirms()`; null → section omitted); separate blob key keeps the /lobbying rollup read lean; mobile drops Top-issue + Bill-linked <640px. **Deliberate omissions:** no dollar ranking (LD-2 income/expenses partial + income-vs-expense asymmetric → the banked **LD-203** money surface) and native issue-codes **not** CBT-topic-crosswalked (the other still-banked item). Finding: rank-1 **Cornerstone Government Affairs** / #2 Brownstein Hyatt — filing-**volume** ≠ revenue, by design. Invariants: 25 firms of **5,175** registrants, 0 `billLinked>filings`, 0 null issue codes; readout `stats.registrants` == leaderboard `totalRegistrants` = 5,175 (same read, structurally guaranteed). No migration / cron slot / nav item. **No theme-% change** — aggregate surface on the LDA pillar. Docs reconciled here (HO 443): roadmap "Also (HO 442)" (pointer → 442), backlog (this tombstone + the L83 strike + the standalone-slot clause now three blobs), SKILL (`lda_top_firms` blob contract + `getTopFirms` + the `/lobbying` TOP FIRMS section). **No oddities entry.** Doc sweep: HO 443.

Leave the CBT-topic crosswalk (L82) BANKED, and don't touch the unrelated "Cron topology header
stale" debt item or anything else in the ledger.

---

## 3. `SKILL.md` (untracked/local) — extend the LDA section (self-mod guard)

Grep your live `SKILL.md` for the anchors and extend in place:

- **Blob contracts** — find where `lda_lobbying_rollup` and `lda_bill_drill` are documented (the
  HO 437/440 blob-contract prose, likely near the `dashboard_state` schema / the `/lobbying` query
  story). Add a `lda_top_firms` contract beside them: a **third** `dashboard_state` blob, computed
  by `computeTopFirms` as a **third consumer of the shared `readLdaTables` pass** (beside
  `computeIssueRollup`/`computeBillDrill` — near-free in-memory grouping, no new scan, no probe),
  written in the same budget-gated cron step under the one `revalidateTag("lda")`, CLI-mirrored;
  ranks **registrants** by **distinct filings** (HO 435 rule), **top 25** (`TOP_FIRMS_N`), fields
  = distinct clients / bill-linked count / single top `general_issue_code`; served by `getTopFirms()`
  (`unstable_cache`, tag `lda`); separate key keeps the `/lobbying` rollup read lean; **no dollar
  ranking** (LD-203 deferred).
- **`/lobbying` route/surface entry** — HO 441 placed this around L1305; **re-grep**, don't trust the
  line. Add the **TOP FIRMS section** to that entry: a registrant leaderboard by distinct filings,
  rendered between the per-issue drill and the recent-filings feed, served from `getTopFirms()`
  (null → omitted); **native issue-code labels, not CBT-topic-crosswalked**; mobile drops the
  Top-issue + Bill-linked columns below ~640px.

**Self-mod guard:** show the SKILL diff and wait for explicit approval before saving. Because
`SKILL.md` is gitignored, this edit is a **local file change only — it is NOT part of the commit
and is not pushed.**

---

## Commit + push

- **One docs commit, explicit pathspec, tracked files only:** `git add docs/roadmap.md docs/backlog.md`
  — nothing else. The `SKILL.md` change is local/gitignored (approval-gated, uncommitted). The
  concurrent session's `Race*` / `CompetitiveRaces*` / `globals.css` stay untouched — do not
  `git add -A`.
- Before pushing: re-check HEAD/ancestry. If the concurrent session pushed, rebase these commits on
  top (`git pull --rebase` / `git rebase origin/main`, no merge commit).
- `git push`. A Vercel deploy will fire on the docs commit but nothing functional changes, so **no
  `verify:deploy` gate is needed** — just confirm the push landed clean and report HEAD.

read docs/handoffs/443-doc-sweep-442.md and follow it
