# 380 — President stage fix (deterministic stage + summarization priority)

**Self-claim:** if `docs/handoffs/380-*.md` exists, bump to the next free number (`ls docs/handoffs/ | sort -V | tail`) and rename before starting.

**Sequencing:** 380 and 381 may both edit `lib/queries.ts`. Do not run them concurrently. Run 381 (the filtered-view 500 outage) first, then 380.

**Scope:** the home Stage Distribution bar shows PRESIDENT = 0 even though one bill (119-s-2393) is genuinely at presentment. HO 378 proved the cause: stage is stale and the bill is gated out. Fix the staleness and the queue priority so it surfaces. Show the diff, hold for approval. No commit, no deploy until approved.

## What HO 378 established — resolved premises, do not re-derive

- **Not a classifier gap, not a correct empty.** The stage rules exist and are correctly ordered. One bill is mis-staged and invisible.
- **The classifier today is the LLM prompt in `lib/summarize.ts:23-31`**, emitted as part of the summary JSON. Rules, in order: (1) "Became Public Law" or "Signed by President" → enacted; (2) "Presented to President" or "to the President" → president; (3) "Passed Senate" AND "Passed House" → other_chamber; etc. These are pure string matches on `latest_action_text`; the LLM adds no judgment.
- **stage is written only by the summarize-runner** (`lib/summarize-runner.ts:274`), alongside the summary, from the LLM output.
- **The sync upsert** (`lib/sync.ts:177-180`) nulls `summary` / `summary_model` / `summary_updated_at` / `topics` on an `update_date` change but **leaves `stage` untouched.** So on an action advance, action text updates and summary nulls, but stage goes stale until re-summarization.
- **The home bar is summary-gated:** `getStageDistribution(..., summaryGated=true)` (`app/page.tsx:92-93`, gate at `lib/queries.ts:464`), i.e. `summary IS NOT NULL`. A null-summary bill is excluded entirely.
- **119-s-2393:** advanced to "Presented to President." on 2026-06-02; summary nulled; stage left `floor`; `summarize_attempts=0`, not failed, just unprocessed in a **1,396-bill backlog** (`summary IS NULL`; only 7 of them failed, the rest unprocessed).
- **Columns:** stage = `stage`; action text = `latest_action_text`; action date = `latest_action_date` (indexed `idx_bills_latest_action`); id = `id`; gate = `summary`.
- **HO 239 monotonicity guard** exists: stage must not regress.

## The fix

Two coupled changes sharing one helper.

**A. Deterministic `computeStage(latest_action_text)` helper.** Port the rules from the LLM prompt into a pure TS function (new `lib/stage.ts`, or co-locate, grep for the right home). Same ordering: enacted → president → other_chamber → … . Single source of truth.

**B. Use it in both write paths, and reorder the queue.**
- **summarize-runner** (`:274`): stop using the LLM's `stage` field; call `computeStage(latest_action_text)` for the stage write. (Leave the LLM prompt as-is for now and just ignore its stage output. Stripping the stage rules from the prompt is banked cleanup.)
- **sync upsert** (`lib/sync.ts:177-180`): on the same update path that nulls the summary, also write `computeStage(latest_action_text)`, **subject to the monotonicity guard: recompute and write, but never regress to an earlier stage.** This keeps stored stage fresh between an action advance and re-summarization, so non-gated views (the funnel, `/bills?stage=president`) are correct in the gap window.
- **Summarization queue priority:** order the unsummarized set so presentment/enacted-stage bills are summarized first, so a presented bill never sits behind 1,396 introduced bills.

## Traps — pin these or the fix silently fails

1. **Order the queue by stage computed from `latest_action_text`, NOT by the stored `stage` column.** Queued bills have stale stored stage by definition (that is this bug): 119-s-2393's stored stage is `floor`, so a stored-stage sort would never prioritize it. The action text is fresh, so compute stage on the fly. Select the unsummarized rows with their `latest_action_text` and **sort app-side** by `computeStage`; do not `ORDER BY CASE …` in SQL, CASE-based ORDER BY defeats the index short-circuit (the 73s cold query). It runs in the runner/cron with no 10s request cap, and ~1,396 rows of string-matching is trivial.
2. **Both writes must apply `computeStage`.** If only sync is fixed and the runner still takes the LLM stage, summarizing 119-s-2393 gives it a summary (passes the gate) while writing a wrong/stale stage, so it surfaces at the wrong stage. Single helper, both sites.
3. **The gate keys on `summary`, not `stage`.** Correcting stage alone will not surface the bill in the home bar; it must get summarized to pass the gate. That is why the queue reorder (trap 1) is load-bearing, not optional.

## Verify locally

- `computeStage("Presented to President.")` → president; `computeStage("Became Public Law No: 119-…")` → enacted; a "Passed House" + "Passed Senate" sample → other_chamber.
- Run one summarization pass (or a dry-run of the queue order) and confirm 119-s-2393 is at/near the front and gets summarized.
- After it's summarized: its `stage` = president, `summary` non-null, and `getStageDistribution(summaryGated=true)` returns PRESIDENT = 1.

## Rejected / banked

- **Rejected: ungate the bar into a full census.** Counting all bills regardless of summary would surface 119-s-2393, but it drags in the feed's pending-bill rendering and the hero stat for marginal gain over priority-queueing. Not doing it. (Say so if you want it reconsidered.)
- **Banked (OPEN LOOPS):** why the backlog is 1,396 deep, that's summarization *capacity*, not ordering, and a separate investigation. Optional one-time stage backfill recomputing stored stage across the corpus from `latest_action_text` (corrects stale stored stages now for non-gated views; bulk write, so your call, not in this handoff). Stripping the now-dead stage rules from the LLM prompt.

## Report back

The helper plus the two write-site diffs plus the queue-order change, local verification that PRESIDENT = 1 after a summarization pass, and the diff. Hold for approval.
