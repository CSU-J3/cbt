# HO 518 — doc sweep for HO 517 (`/news` "IN THE NEWS" member rail group)

Docs-only, **one commit**. HEAD going in is `f1b1167`. No code changes — this is roadmap + backlog + SKILL only. It touches `SKILL.md`, so land it through the **review-ref workflow** (§5).

Three edits: (1) roadmap append + pointer bump, (2) backlog Axis B tombstone, (3) SKILL `/news` three-mode-contract update. No oddities entry is owed — HO 517 surfaced no new gotcha; the load-bearing rules (own-window, units-match, single-select, pin) were already recorded in the 514–515 block and the backlog, and are restated in the new roadmap block below.

---

## 1. `docs/roadmap.md` — append the block, bump the pointer

**The append-only trap is live here and it's the specific reason this instruction is explicit.** The `Also (HO 514–515)` block contains the clause *"The hidden rail in member mode is a **deliberate seam Axis B reopens**, not an oversight."* That seam is now closed. **Do not go back and flip, soften, or edit that clause.** It was true when written; the dated `Also (…)` blocks are an append-only changelog, not a state doc. The closure gets recorded by the **new** block, not by mutating the old one. This is the HO 418 precedent and the exact failure mode that nearly landed at HO 429.

### 1a. Append this block immediately after the `Also (HO 514–515)` block (the last block in the file)

> **Also (HO 517, `a71a1d4` query · `f1b1167` chrome), the `/news` "IN THE NEWS" member rail group — the Axis B seam closed, no theme-% change.** The forward item the HO 514–515 block banked (a second rail group off the observation layer), built with **no probe step** — HO 514's cardinality/cost numbers stood up unmodified, the payoff of measuring both axes in one probe. The `?member=` seam HO 515 left deliberately open (member mode rendered no rail) is now closed: the `.nw-rail` carries **two groups** (TOPICS + IN THE NEWS) inside its one bounded `.nw-rail-scroll`, and member mode is a first-class rail selection rather than a deep-link-only view. **The query (`a71a1d4`):** `getNewsMemberRailCounts()` off `observation_entities` (`entity_type='person'`) → `observations`, `INNER JOIN members` for name+party, ranked desc + name-tiebroken, returns `{ rows, total }`; EXPLAIN-confirmed it drives `idx_obs_entities_type_value`, `unstable_cache` tag `member-news` (already flushed by the news cron + allowlisted on `/api/revalidate`, HO 414 — no new wiring), `try/catch → null` hiding **only this group** (TOPICS + feed still render). Plus `getNewsMemberRailPin(bioguide)`, an **uncached point-lookup** for the pin — a bounded `activeBioguide` arg on the counts query would make every visited member its own cache key, so the separate lookup keeps the counts cache clean. `NEWS_MEMBER_RAIL_WINDOW_DAYS = 30` is exported so the header label and the query can't drift. **Four design calls, all verified live:** (1) **fixed 30d window, disclosed** — the member group does NOT rebase on `source`/`window`/`signal` (header `IN THE NEWS · 30d`); 30d not "all-time" because the observation layer is ~30d old (HO 394 pilot) so they're equal today but the label stays correct as the corpus accrues (the HO 456 disclose-the-exclusion posture) — verified Graham holds 49 at `?window=24`. (2) **units match** — HO 394 writes one observation per fetched article, so both groups count **articles** (the HO 442 coherence that lets two count columns share one rail; recorded in a comment). (3) **one selection across both groups** — the two groups drive different panes (topic → mention feed, member → observation feed) so they can't co-activate; `NewsTopicRailRow.scope()` now also clears `member` and selecting a member clears `topic` (topic↔member mutually clear, exactly one lit row spanning both groups). (4) **top 15, total disclosed** (`… · 15 of 126`), with the active member **pinned** at the group top when outside the shown set — the one path the rail can't reach from itself (the HO 512 Press-tab out-link can send any of ~535 members here), so without it a low-coverage arrival renders a rail with nothing lit: the HO 492 selection-invisibility failure through a different door. **The zero-count pin holds:** a pinned member with 0 recent observations still renders, lit, count 0 (the pane below is showing their coverage, so the rail must agree they're the active scope). **Chrome (`f1b1167`):** a new single-select `NewsMemberRailRow` (party dot via `lib/race-colors`, not a local map — HO 468; surname-forward + count, no bar), both groups sharing the one `.nw-rail-scroll` (no nested scroll), `scrollIntoView({block:"nearest"})` covering the member group too; CSS **additive under `.nw-*`** (a `.nw-rail .mc-crow.nw-mrow` grid override + dot + pin hairline + group-header border) — diff-confirmed no shared `.mc-`/`.lob-`/`.bl-`/`.bxp-`/`.bdp-` rule touched, the **sixth** consecutive test of the containment rule (486 / 492 / 496 / 507 / 515 / 517). **Mode contract now:** default → both groups selectable; `?topic=` → topic lit, mention feed; **`?member=` → rail renders** (the 515 seam closed — TOPICS shows bare counts, IN THE NEWS shows the member lit/pinned), the HO 512 observation-feed pane below unchanged; `?bill=` → still no rail, byte-identical. Prod-verified across bare (15 rows, Graham head), `member=Lawler` (rank ~30, injected+lit, `nw-mrow-pin`×1, observation feed), `member=Aderholt` (0 recent obs, pinned+lit, count 0 — the call-4 zero case), the window-independence check, and `?bill=` unchanged; `tsc` clean, `verify:deploy` served `f1b1167` === HEAD. **No new nav, migration, cron, or index; the 35 unjoinable person rows (no bioguide) stay excluded (the HO 398 challenger edge); SOURCES stays dead on cardinality (HO 514).** **No theme-% change** — a browse-surface add on an existing pillar (the 486 / 492–493 / 495–496 / 507 / 514–515 precedent). With this, the `.mc-*` two-pane arc that opened at HO 328 is complete across every browse surface **and** the `/news` rail now carries the member axis the observation layer was built to enable. Docs: HO 518. **Also notes now run through HO 517.**

### 1b. Bump the live pointer

Find the tail of the `Also (HO 514–515)` block reading exactly:

`Docs: HO 516. **Also notes now run through HO 515.**`

Change **only** the pointer clause:

`**Also notes now run through HO 515.**` → `**Also notes now run through HO 517.**`

Leave every earlier `Also notes now run through HO N` untouched — those are historical, per the changelog convention. (`run through HO 515` is unique to this block, so it's an unambiguous anchor.) Do **not** touch the roadmap's `Banked / unbuilt:` line — Axis B was never on it (it lived in the 514–515 block prose + the backlog), so there's nothing to prune there.

---

## 2. `docs/backlog.md` — tombstone the Axis B item

Replace the current live item (the `**`/news` member rail — Axis B ("IN THE NEWS")…` bullet, the one whose `*Close:*` says "a member group renders as a 2nd rail section with its own window") with:

> - ~~**`/news` member rail — Axis B ("IN THE NEWS") as a 2nd group in the topic rail (HO 514–515)**~~ — **SHIPPED HO 517** (`a71a1d4` query · `f1b1167` chrome). Built with **no probe step** — HO 514's cardinality/cost (126 ≥1 · 39 ≥3 · 10 ≥10, 34ms off `idx_obs_entities_type_value`) held unmodified. The IN THE NEWS group is a 2nd rail group (top-15, `getNewsMemberRailCounts` + the uncached `getNewsMemberRailPin` for the pin) with its **own fixed 30d window** disclosed in the header — the load-bearing constraint this line banked, since the 24h page window collapses the head to 6 and empties it. One selection spans both groups (topic↔member mutually clear); the active member is **pinned** at the group top when outside the top-15 (incl. the zero-count case) so a Press-tab (HO 512) arrival never lands on a rail with nothing lit. *Close criterion met.* See roadmap "Also (HO 517)".

Keep the strikethrough-title-plus-SHIPPED-note shape of the sibling DONE lines. No change to the standing "a backlog line's stated mechanism/premise is a claim" note — HO 517 adds no new wrong-premise case (HO 514's numbers held), so it stays a two-example note (512, 514).

---

## 3. `.claude/skills/cbt/SKILL.md` — update the `/news` three-mode contract

In the `/news` entry, the contract currently says the rail renders **only** in default mode and describes member mode's hidden rail as the deferred Axis B seam. That's now stale. Replace the sentence-span that begins **"Three-mode contract — the rail renders ONLY in default mode:"** and runs through the end of the "…banked in backlog WITH its own-window constraint (24h head collapses to 6 members), NOT built here." sentence, with:

> **Three-mode contract — the rail renders in default, topic, AND member modes (HO 517 closed the 515 seam):** the `.nw-rail` carries **two groups** in its one bounded `.nw-rail-scroll` — **TOPICS** (24 rows, the HO 515 topic spine) and **IN THE NEWS** (`getNewsMemberRailCounts`, top-15 members off `observation_entities` `entity_type='person'` → `observations`). `default` → both groups selectable, topic scopes the mention feed; `?topic=` → topic row lit, mention feed; **`?member=` → rail renders** — TOPICS shows bare unscoped counts, IN THE NEWS shows the active member lit, **pinned at the group top when outside the top-15** (via the uncached `getNewsMemberRailPin`); the pane below is the **unchanged HO 512 observation feed**; `?bill=` → **NO rail** (one bill is a single-topic slice; full-width feed, byte-identical). **One selection spans both groups** — topic↔member mutually clear (`NewsTopicRailRow.scope()` also clears `member`), exactly one lit row. **The IN THE NEWS group has its OWN fixed 30d window** (`NEWS_MEMBER_RAIL_WINDOW_DAYS = 30`, exported so header label + query can't drift), disclosed in the header (`IN THE NEWS · 30d · 15 of 126`) and **NOT** rebased on `source`/`window`/`signal` — at 24h the head collapses to 6 members (HO 514), and 30d ≈ all-time today but the label stays correct as the ~30d-old observation layer accrues (the HO 456 posture). **Units match:** both groups count **distinct articles** (HO 394 writes one observation per fetched article — the HO 442 coherence that lets two count columns share one rail). **The pin covers the zero case:** a member with 0 recent observations still renders pinned+lit with count 0 (the pane is showing their coverage, so the rail must agree they're the active scope). `getNewsMemberRailCounts` is `unstable_cache` tag `member-news` (already flushed by the news cron + allowlisted on `/api/revalidate`, HO 414 — no new wiring), `try/catch → null` hiding only this group. `NewsMemberRailRow` is the single-select `.mc-crow.is-sel` idiom (party dot via `lib/race-colors` — HO 468; surname + count, no bar), **NOT** a lift of `/bills`' multi-select `TopicRailRow`. CSS additive under `.nw-*` (`.nw-rail .mc-crow.nw-mrow` grid override + pin hairline + group-header border) — `/members`/`/lobbying`/`/bills` byte-identical (containment rule's 6th test). The 35 unjoinable person rows (no bioguide) stay excluded (the HO 398 challenger edge). SOURCES stays **dead on cardinality** (3 entries — HO 514), not a deferred rail.

**Leave the rest of the `/news` entry intact.** In particular the HO 512 member-mode pane description elsewhere in the entry (member-pill-only `NewsFilters` early-branch, `RaceNewsRow` rows, dropped `news-header-row` + pager, `getMemberNews(bioguide, NEWS_MEMBER_CAP = 50)`, `getMember` null → raw-id pill, parse-fail → unscoped feed) is **unchanged by HO 517** — the rail is additive above that pane, not a rewrite of it. Before editing, eyeball `app/news/page.tsx` to confirm that pane description still matches the shipped code; if HO 517's restructure moved anything in the pane, note it rather than silently rewriting. Do **not** touch the `hideTopics` sentence — it still governs the topic-group chip/null behavior.

---

## 4. Verify before pushing

- `git diff --stat` shows **exactly three files**: `docs/roadmap.md`, `docs/backlog.md`, `.claude/skills/cbt/SKILL.md`. **Zero code files.** If any `.ts`/`.tsx`/`app/*` shows up, stop — this is docs-only.
- The `Also (HO 514–515)` block's `deliberate seam Axis B reopens` clause is **byte-unchanged** (`git diff docs/roadmap.md` should show the new block appended + the one-clause pointer bump, and nothing inside the 514–515 block body).
- `grep -c "Also notes now run through HO 515" docs/roadmap.md` → `0`; `grep -c "Also notes now run through HO 517" docs/roadmap.md` → `1`.
- The backlog Axis B bullet now reads strikethrough + `SHIPPED HO 517`; no live (un-struck) Axis B item remains.
- SKILL `/news` entry: `grep -c "rail renders ONLY in default mode" .claude/skills/cbt/SKILL.md` → `0` (the stale contract is gone).

---

## 5. Process — review-ref workflow (SKILL self-mod guard)

This commit touches `SKILL.md`, so route it through the review ref rather than pasting the diff (the paste relay has swallowed SKILL diffs before):

1. Stage **explicit pathspecs only** — `git add docs/roadmap.md docs/backlog.md .claude/skills/cbt/SKILL.md` — never `git add .`.
2. Commit locally (one docs commit; message e.g. `docs: roadmap/backlog/skill for the /news member rail group (HO 518)`). Do **not** push to main yet.
3. Push to a throwaway ref: `git push origin HEAD:refs/heads/518-review`.
4. Report back that it's on the ref. I'll fetch, read the full diff out of the repo (the SKILL span especially), and approve or send corrections.
5. On approval: ancestry eyeball (`git log --oneline @{u}..HEAD` — exactly one commit riding, clean fast-forward, concurrent-session files untouched), then FF-push main (`git push origin HEAD:main`) and delete the ref (`git push origin :refs/heads/518-review`).

Fast-forward only, no force-push. This satisfies the SKILL guard rather than bypassing it — the gate is SKILL landing on main without an approved diff, and a review ref is inert (no main history, deletable).

read docs/handoffs/518-doc-sweep-517.md and follow it
