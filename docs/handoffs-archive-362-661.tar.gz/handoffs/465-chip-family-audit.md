# HO 465 — chip-family audit (B6 arc, Step 0)

Read-only. **No code, no commit.** The existing-chip migration deferred from HO 287 (the ID / stage / party legs; topic already shipped HO 316) is app-wide and divergent, and it carries a real design fork — so this is the audit-first Step 0 HO 287 itself mandated ("Audit-first… if used in many divergent ways, flag it and split into its own handoff"). Produce the definitive catalog, then report it + the framed decisions in chat. Build handoffs follow once Corey decides.

`chip-family.html` was never committed — the source spec is HO 287's handoff body, reproduced per leg below.

## What to do

Re-grep every ID / stage / party chip rendering **and every consumer** (CSS class defs *and* the `.tsx` call sites), at write time — don't trust a prior snapshot. Starting points found in the current tree (re-confirm, don't assume they're complete):

- **ID:** `components/BillIdRail.tsx` (`.bill-rail`, vertical); `.bill-chip` (globals.css ~L1579, horizontal chamber-tinted, TOP STALLS); `.v2f-id` (~L3878); `.weekly-band-id` (~L2911); `.hearing-bill-line .bill-id` (~L7966); `.hcal-card-billid` (~L8730). Grep `bill-id`, `bill-rail`, `bill-chip`, `formatBillId` for the full consumer set.
- **Stage:** `StagePillStrip` / `StagePill` (`.stage-pill` ~L1869; consumer `BillRow.tsx`); `StageIndicator` (`components/StageIndicator.tsx`; consumers `HearingRow.tsx`, `app/bill/[id]/page.tsx`). Exclude `StageFunnel` / `StageLegend` / `StageFilter` (those are chart/legend/filter, not chips).
- **Party:** `components/PartyTag.tsx` (consumer `SearchResultsMembers.tsx`); `party-badge` (members list ~L2342); `partyChip` (`PrimaryRow.tsx`); the `[party-state]` bracket baked into `sponsor_name` (feed rows ~L3837 — note it's a *string*, not a component). Exclude party-*colored* dots/markers (`IdeologyStrip`, `RaceDistrictCard`, `MemberIdeology`) — those are data-viz fills, not tags.

Output a table per leg: **rendering · file:line · consumers · current values · spec target · delta · in-family or exempt?**

## The spec targets (HO 287)

One size ladder: **11 / 10 / 9px**.

- **ID chip (tier 1):** bordered, 2px radius, weight 600, solid `--accent-amber` border, **11px**. *(`.v2f-id` already matches this exactly — it is the canonical target, not something to rebuild.)*
- **Stage pill (tier 2):** bordered, **10px**, format `LABEL · age`. Inactive = `--text-dim` / `--border-strong`. Current/active stage = its stage color at **50% alpha** border.
- **Party tag (tier 3):** no border, `--text-dim`, tint optional (**off by default**).

## The three decisions to surface (with my read)

Frame each cleanly so Corey can decide from your catalog. These are genuine forks — do **not** resolve them in this pass.

1. **ID — the load-bearing one. Amber-unify vs. keep chamber-tint.** Two deliberate systems coexist: the **amber chip** (`.v2f-id`, spec-compliant) and a **chamber-tinted** family (`.bill-rail` vertical + `.bill-chip` horizontal, `--rail-house` cyan / `--rail-senate` purple) that encodes chamber-of-origin, used in the core `BillRow` + TOP STALLS on an explicit HO 125 rationale ("chamber is structural, not partisan; matching a palette would mislead"). The spec's "ID chip = amber, the row anchor" implies one amber chip everywhere — which retires chamber-tint. *My read: chamber-tint is a real, documented signal; most likely the amber chip should own the non-chamber id surfaces (`.weekly-band-id` green text, the hearings ids) and `BillIdRail`/`.bill-chip` stay chamber-tinted — but that reinterprets the spec's "row anchor," so it's Corey's call.* Enumerate exactly which surfaces each choice touches so the tradeoff is concrete.

2. **Stage — converge two idioms or keep both.** `StagePillStrip` (the feed's intro→current pill strip, `.stage-pill` 11px, `1px solid currentColor` border, history-dimmed via opacity) vs. `StageIndicator` (14px, borderless, arrow-prefix `▸ / ▸▸ / ▸▸▸▸`, on hearings + `/bill/[id]`). The spec's one 10px-bordered-`LABEL·age`-active@50% pill would fold `StageIndicator` in and drop its progression-encoding arrow-prefix. *My read: the strip is close to spec (needs 11→10px + the active@50%/inactive-dim border split, replacing full-`currentColor`); `StageIndicator` is a different idiom whose arrow-prefix carries stage-progression at a glance — surface whether that folds in or stays exempt.*

3. **Party — tint off-by-default is a visible change.** `PartyTag` renders `[D-CT]` in party *color*; the spec's tier-3 is `--text-dim` with tint *off* by default, i.e. party brackets go gray. And the feed's `[party-state]` is concatenated into `sponsor_name` server-side, so "tint off" wouldn't even reach the feed without a render/data change. *My read: confirm Corey wants party brackets dim-by-default in the feed at all — it desaturates a lot of at-a-glance partisan color — and note the `sponsor_name`-baked-bracket blocker separately (it may stay as-is regardless).*

## End with a proposed per-leg build plan

Given the catalog, propose the migration as **separate build handoffs, one per leg** (ID / stage / party), each its own commit (the two-commit rule — feature-per-leg, no cross-leg mixing, no refactor folded in). For each leg: the shared component/CSS to converge on, the consumer list to repoint, and which choice from §Decisions it's blocked on. This turns Corey's answers directly into scoped builds.

## No commit

Read-only audit. Report the catalog + the three framed decisions + the per-leg plan in chat. Nothing staged, nothing pushed. The concurrent session's uncommitted files stay untouched — don't `git add` anything.
