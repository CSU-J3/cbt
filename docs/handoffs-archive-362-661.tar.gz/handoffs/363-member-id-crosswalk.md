# HO 363 — Member ID crosswalk (unitedstates/congress-legislators)

> Renumber to your next free HO if HEAD has moved past 362. (Diagnostics already reference `-373`, so double-check `ls docs/handoffs/` before committing the filename.)

Wire the `unitedstates/congress-legislators` ID crosswalk into CBT so the bioguide-keyed `members` roster gains authoritative bridges to the IDs every future cross-source join needs: FEC committee IDs (money), ICPSR (Voteview ideology), Wikipedia/Ballotpedia page titles (attention), plus GovTrack, LIS, C-SPAN, Wikidata. This is plumbing. It is the cheapest thing on the source backlog and it unblocks the most downstream work, which is why it goes first.

Additive and reversible: three new tables that FK to `members`, one sync script, one diagnostic. Nothing in `members` changes. No new dependency — `js-yaml@^4.1.1` is already in `package.json`.

## How to work this handoff

Standard spec-driven flow:

1. Read this file. Re-verify the source is still live (the checks below are from 2026-07-02).
2. Propose a plan: the exact DDL you'll add, the sync shape, the match strategy, and every decision this handoff leaves to you (listed at the bottom). Don't write code yet.
3. Wait for my review.
4. Implement. Show diffs. Never auto-commit — no commits, pushes, or destructive git ops until I've approved the diff.
5. Run the diagnostic and paste the numbers back verbatim so we can see the fill rates.

## Source (verified 2026-07-02)

- Repo: `github.com/unitedstates/congress-legislators`, branch `main`. Live, actively maintained (last push 2026-06-15).
- Files needed: `legislators-current.yaml` (537 records) and `legislators-social-media.yaml`.
- **YAML only.** Both `.json` equivalents 404 — there is no JSON build. Parse with the existing `js-yaml`. Do not add a YAML dep, do not scrape.
- Fetch raw, single GET each, no pagination:
  `https://raw.githubusercontent.com/unitedstates/congress-legislators/main/<file>`
- Per-record `id` block (all fields optional except `bioguide`):
  `bioguide, thomas, lis, govtrack, opensecrets, votesmart, fec (ARRAY), cspan, wikipedia (page title), house_history, ballotpedia (page title), maplight, icpsr, wikidata, google_entity_id, pictorial`
- Social file keys actually present in the wild: `twitter` (506), `facebook` (490), `instagram` (406), `youtube` (254), `mastodon` (13), plus `*_id` numeric variants. **No `bluesky` field exists upstream** — the Bluesky backlog item cannot be fed handles from here.

## Why now, why first

`members` is `bioguide_id PRIMARY KEY` with zero external IDs (confirmed in `scripts/migrate.ts`). Every future join — member→FEC filings, member→DW-NOMINATE score, member→Wikipedia pageviews — is a `bioguide → X` lookup that today resolves to nothing. `scripts/sync-fec.ts` and `scripts/backfill-bioguide-ids.ts` already exist, so the FEC bridge has an immediate consumer waiting. This handoff is the ID layer those consumers assume.

## What to build

### 1. Schema — extend `scripts/migrate.ts`

Idempotent `CREATE TABLE IF NOT EXISTS`, following the `members` + join-table idiom (`affiliations`, `committee_members`).

```sql
-- HO 363: ID crosswalk from unitedstates/congress-legislators.
-- Enrichment of the existing bioguide-keyed roster; NEVER a source of new
-- members. All three tables FK to members(bioguide_id).

CREATE TABLE IF NOT EXISTS member_ids (
  bioguide_id       TEXT PRIMARY KEY REFERENCES members(bioguide_id),
  icpsr             INTEGER,
  govtrack          INTEGER,
  lis               TEXT,
  thomas            TEXT,
  cspan             INTEGER,
  votesmart         INTEGER,
  wikidata          TEXT,
  wikipedia_title   TEXT,
  ballotpedia_title TEXT,
  google_entity_id  TEXT,
  opensecrets       TEXT,
  maplight          TEXT,
  house_history     INTEGER,
  pictorial         INTEGER,
  raw_json          TEXT NOT NULL,
  fetched_at        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_member_ids_icpsr ON member_ids(icpsr);

-- `fec` is an ARRAY upstream (a member maps to several committee IDs).
-- Flatten it so FEC-committee -> member reverse lookup is indexed, same reason
-- HO 394 flattened entities into a child table instead of json_extract-ing.
CREATE TABLE IF NOT EXISTS member_fec_ids (
  bioguide_id TEXT NOT NULL REFERENCES members(bioguide_id),
  fec_id      TEXT NOT NULL,
  PRIMARY KEY (bioguide_id, fec_id)
);
CREATE INDEX IF NOT EXISTS idx_member_fec_ids_fec ON member_fec_ids(fec_id);
```

Optional third table, severable (see decisions):

```sql
-- OPTIONAL. Source: legislators-social-media.yaml (a separate file + fetch).
-- Near-term consumers are cold (X/Twitter API is paid/restricted; the Bluesky
-- item needs a different handle source since bluesky isn't tracked upstream).
-- Drop this table and its fetch for a tighter diff if you'd rather.
CREATE TABLE IF NOT EXISTS member_social (
  bioguide_id TEXT PRIMARY KEY REFERENCES members(bioguide_id),
  twitter     TEXT,
  twitter_id  TEXT,
  facebook    TEXT,
  facebook_id TEXT,
  instagram   TEXT,
  youtube     TEXT,
  youtube_id  TEXT,
  mastodon    TEXT,
  raw_json    TEXT NOT NULL,
  fetched_at  TEXT NOT NULL
);
```

### 2. Sync — new `scripts/sync-crosswalk.ts`, npm script `sync:crosswalk`

Mirror `scripts/sync-members.ts` conventions exactly: `import "dotenv/config"` first, `getDb()` from `lib/db` (the bounded-fetch client), batched writes.

```ts
// scripts/sync-crosswalk.ts
import "dotenv/config";
import { getDb } from "../lib/db";
import yaml from "js-yaml";

const RAW =
  "https://raw.githubusercontent.com/unitedstates/congress-legislators/main";

// 1. GET legislators-current.yaml + legislators-social-media.yaml, yaml.load() each.
// 2. Load the set of known bioguide_ids from `members` — this is the gate.
// 3. For each current-legislators record whose id.bioguide IS in members:
//      - upsert member_ids   (INSERT ... ON CONFLICT(bioguide_id) DO UPDATE SET ...)
//      - replace member_fec_ids for that bioguide: DELETE, then INSERT the array
//      - raw_json = the entire id block (fidelity copy)
//    Skip and COUNT records whose bioguide is not in members (delegates,
//    resident commissioner, historical) so we never FK-violate.
// 4. For each social record whose id.bioguide IS in members: upsert member_social.
// 5. Log: matched, skipped_no_member, fec_rows, social_rows.
// No LLM, no per-record network. Runtime is two file GETs + local parse (seconds).
```

Match reality to expect: `members` is the 119th roster (551 total / 536 current per HO 94); congress-legislators `current` is 537 and includes non-voting delegates. A handful will be unmatched in each direction. That is the diagnostic's job to surface, not an error to throw on.

Cadence: this is a manual pair with `sync:members`, like `sync:members` itself (HO 94: manual, quarterly-plus). Run `sync:crosswalk` immediately after any `sync:members`. The source barely churns, so it does not need a daily cron; wire it into a low-frequency cron later only if you want, not in v1.

### 3. Diagnostic — `scripts/diagnostic/crosswalk-coverage-363.ts`

Read-only, follows the `scripts/diagnostic/<slug>-NNN.ts` pattern. Print:

```
members total ............................. N
member_ids populated ...................... M   (M/N = match rate)
  with icpsr .............................. …   <- gates the Voteview handoff
  with >=1 fec_id ......................... …   <- gates the FEC money join
  with wikipedia_title .................... …   <- gates the pageviews handoff
  with any social handle .................. …
distinct fec_id in member_fec_ids ......... …   (size of the money bridge)
members with NO crosswalk row ............. …   (list the bioguides)
current legislators not in members ........ …   (bioguide drift, list them)
```

## Decision gates (report from the diagnostic)

- **Match rate.** What % of current members got a crosswalk row. Expect high-90s. Materially lower means the bioguide sets are drifting and `sync:members` should be re-run first.
- **FEC bridge size.** Distinct `fec_id` count. This is the authoritative member↔committee mapping `sync-fec.ts` can switch to.
- **ICPSR + wikipedia_title fill.** If these are well-populated, the Voteview and Wikipedia-pageviews handoffs are now cheap. If sparse, they need a fallback ID source and that changes their cost.

## Decisions left to you (call these in the plan)

- Scalar columns + `raw_json` (as specced) vs a single JSON blob with `json_extract`. I've gone scalar because `icpsr` and the `fec` bridge are hot join keys that want real columns and an indexed child table. Argue JSON-only if you disagree, but the child table for `fec` stays regardless.
- `member_fec_ids` re-ingest: delete-then-insert per bioguide (specced) vs upsert-and-prune. Pick one, keep it idempotent.
- Include `member_social` or defer it. Same source repo, different file; its consumers are all currently cold. I've marked it severable — your call for a tighter diff.

## Non-goals

- No edits to `members`. The crosswalk is a parallel enrichment; `members` stays Congress.gov-sourced.
- No consumer rewiring. Populating the bridge is this handoff; pointing `sync-fec.ts` at `member_fec_ids`, and the Voteview / Wikipedia handoffs, are separate and gated on the fill numbers above.
- No Bluesky handles — upstream doesn't carry them.
- No historical roster (`legislators-historical.yaml`). Current members only for v1.
- No new dependency.

## Files touched

- New: `scripts/sync-crosswalk.ts`, `scripts/diagnostic/crosswalk-coverage-363.ts`.
- Edited: `scripts/migrate.ts` (two tables, three if you keep social), `package.json` (`sync:crosswalk` script).
- Read-through: `lib/db.ts` (`getDb`), `scripts/sync-members.ts` (idiom to mirror).

## Rollback

Drop `member_ids`, `member_fec_ids`, and `member_social`; delete `scripts/sync-crosswalk.ts`, the diagnostic, and the `sync:crosswalk` script line. `members` and every other table are untouched throughout.
