# HO 400 — the_hill budget-soak check (read-only)

Confirm 400 is the next free number before saving (`ls docs/handoffs/ | sort -V | tail`); body assumes 400. (399 is claimed for the ID crosswalk.)

## What this is

Open WATCH item from the doc sweep. One deployed news tick showed politico eating 32.4s of the ~45s route budget with `budgetStopped:true` on the_hill. Question: is the_hill *systematically* starved (cut off before it contributes on most ticks), or was that a one-off slow tick? Read the natural cron history and call it. No fix in this handoff unless the data says one's warranted.

Read-only. No schema, no writes, no commit. Do NOT force extra ticks to pad the sample — natural cadence is the signal, and a forced back-to-back tick manufactures nothing useful while writing real mentions to prod.

## The data

`cron_runs` carries per-tick detail for `/api/cron/news` in its payload JSON: total `elapsed_ms`, per-feed entries (name, timing, item counts, `budgetStopped`), and `totals`. Pull the last ~14 news ticks, or all available if fewer. A read-only pass — script in `scripts/diagnostic/` or a couple of `json_extract` queries, your call; don't commit either way.

If the per-feed timing or intake isn't actually in payload (only aggregate totals + budgetStopped flags), say what's missing rather than inferring it. If cron_runs is too coarse to settle the intake question, flag that the real answer needs a one-line per-feed counter added to the news tick (separate handoff), and give the verdict on what the flags + durations alone show.

## Tabulate

- **N** — ticks in the sample and the date span. If N < ~5, flag the verdict as provisional; the soak needs more days.
- **Feed order** — fixed (politico always first)? If payload preserves order, confirm it. Fixed order with politico first is the structural setup for starving later feeds.
- **the_hill budgetStopped rate** — X of N ticks.
- **politico budget share** — politico's per-tick duration as a share of tick elapsed (median + range). Consistent hog, or was 32.4s an outlier?
- **Effective intake per feed, summed over the sample** — articles fetched and mentions/obs contributed, per feed. This is the one that matters: the_hill's cumulative contribution near-zero while politico takes ~everything = starvation. the_hill getting its turn across ticks = fine.

## Verdict

State it plainly from the numbers:
- **Occasional** (the_hill contributes across ticks, 32.4s was a slow-tick outlier) → close the backlog WATCH loop, no fix.
- **Systematic** (the_hill cut off on most ticks, cumulative intake near-zero) → the fix is feed-order rotation (rotate first position across ticks so no feed is permanently last) or a per-feed sub-budget carve. NOT a timeout raise — the route budget stays, feeds fit inside it. Convert the backlog WATCH into a QUEUED fix with the approach the data points to.

## Report back

- The tabulation (N, span, order, budgetStopped rate, politico share, per-feed intake).
- The verdict, and which backlog action follows (close vs queue-fix).

No commit; the read is a throwaway.
