# HO 553 — prove the defer path fires, then sweep HO 550–552

Number from the roadmap pointer (currently "run through HO 548") plus the 549–552 sequence. **STEP 0 commits nothing.** Then the sweep: one docs commit, plus SKILL through the review ref.

## STEP 0 — fire the defer branch, and price the stuck case

HO 552's defer branch is the protection against a decisive link being dropped permanently — but it has never executed. `deferred` was 0 through both verification runs because every roll call was already synced. Recording it in SKILL as a safety while it sits untriggered is the thing HO 549 exists to prevent, and the falsification took ten minutes there and found the answer worth having.

Same shape as 549: scratch edits on HEAD, **nothing committed**, tree verified clean afterwards.

**Part A — does it defer?** Force a constructed `voteId` to miss the `votes` table (simplest is a scratch edit that perturbs the constructed id, or a scratch row removal — your call, whichever is cleanly reversible). Re-queue one HAMDT and run the walk. Expected: `deferred=1`, the amendment is **not** stamped, `remaining` stays 1. Then restore, run again, and confirm it links and stamps on the retry. That second half is the part that matters — deferring is only useful if the retry actually completes.

**Part B — what happens when the row never arrives?** Leave the absence in place and run the walk two or three times. Confirm the HAMDT stays queued and re-fetches `/actions` each run. Report the per-run cost (one GET per stuck amendment) and whether `remaining` is stable or climbing.

Then make the call and state it plainly: is permanent retry acceptable, or does it need a bound? My read is that it's acceptable — ~228 HAMDTs, one GET per stuck row per run, and the alternative (stamping after N attempts) reintroduces the exact permanent-drop this fix removed. But it should be a decision on measured cost, not an unexamined default. If you disagree after seeing the numbers, say so and we'll scope a bound rather than paper over it.

The useful distinction to record either way: a **transient** lag shows `deferred` non-zero on one run and back to 0 on the next; a **permanent** gap shows `deferred` pinned across consecutive runs. That asymmetry is what makes the counter a real instrument instead of a number in a payload.

## The sweep

**`docs/roadmap.md`** — one new `**Also (HO 550–552)**` block with its own frozen `Also notes now run through HO 552` pointer. Don't touch the 548 block's pointer or any prior clause.

The block carries: the HO 550 probe and its six measurements; **the P1 it found** (the House walk linking every `recordedVote` unfiltered, two amendments rendering "On Ordering the Previous Question" tallies as their own outcome with a green agreed dot); the 551 fix with the predicate **derived from the full 92-row enumeration, not the two offenders** — 89 "On Agreeing to the Amendment" + 1 ", as Modified" + 2 procedural, vocabulary closed; the one-time delete of exactly 2 rows; and the 552 correction, including that 551's own comment asserted a self-heal the queue predicate can't deliver.

Record the probe's GO evidence for the motion-aware surface too — closed 4-class vocabulary, 100% number resolution with the waiver's `Amdt. No. N` confirmed as the same Senate namespace, ~55 fate-bearing lines after setting aside the 4 already-anchored and 5 orthogonal, polarity validated 54/56 against **full** coverage (procedural floor votes always generate an action, unlike the corpus-wide 8.6%), 351ms cold. Note the 64 − 5 − 2 = 57-vs-56 discrepancy in the M4 exclusion arithmetic as unreconciled — it doesn't move the verdict, but a build handoff shouldn't inherit an off-by-one silently.

No theme-% change: a correctness fix plus a probe on an existing pillar.

**`docs/backlog.md`** — DONE tombstone for the P1. Promote the motion-aware surface **BANKED → QUEUED** with the GO evidence and the constraint that it needs its own scoped build (invert table/waiver polarity, render cloture/chair as orthogonal rather than a fate, suppress the 4 already-anchored). Two WATCH entries: the `deferred` counter with the transient-vs-pinned instrument above, and — if Part A fired — nothing more; if it **didn't** fire, the WATCH says so and the branch is recorded as unproven rather than as protection.

**`docs/oddities.md`** — extend the existing HO 542 chamber-asymmetry entry with M5 rather than adding a second entry on the same subject; grep first.

Then one genuinely new entry, because it generalizes past this bug: **a queue that stamps on exit converts a transient failure into a permanent one, unless the failure is explicitly non-stamping.** The walk had the pattern right for `fetchErrors` and wrong for a missing votes row, and the 551 gate turned that latent asymmetry into a live drop. The rule: when adding any new failure mode to a stamp-on-exit queue, classify it as settled or pending *before* deciding whether it stamps — and note that HO 459's "stamp every row" rule is about walked-no-result, not walked-can't-tell-yet. That distinction is the whole bug.

**`SKILL.md`** — the walk's decisive-form gate, `HOUSE_AMDT_QUESTION_LIKE` living in the shared leaf module alongside the Senate parser (and why: the asymmetry survived because the House had no counterpart there), the `deferred` field, and the non-stamp discipline. **Separate commit through `refs/heads/553-review`** per the self-mod guard — I read the diff out of the repo, approve, then main fast-forwards and the ref is deleted.

## Constraints

- Docs only after STEP 0. No app code.
- Code and docs never ride together; SKILL separate from the roadmap/backlog/oddities commit.
- Explicit pathspec. Diff before each commit — the roadmap block is append-only and permanent.
- Fast-forward only, ancestry eyeballed immediately before push.

## Report back

- STEP 0 Part A: whether the defer fired, and whether the retry completed. Part B: the stuck-case behaviour, per-run cost, and your call on bounding it.
- Confirmation the tree is clean with nothing committed from STEP 0.
- The oddities grep showing the 542 entry was extended, not duplicated.
- Pointer gate: `run through HO 552` appears exactly once, `run through HO 548` still exactly once.
