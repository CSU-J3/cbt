# HO 640 — characterize the 11 shares-without-a-winner contests, and measure the WA non-measurement

Read-only probe. **BUILDS NOTHING.** No writes, no seed runs, no ingester changes, no backlog reclassification until the numbers are in. One script under `scripts/diagnostic/`, committed on its own per the standing rule that probes commit separately from builds.

## Why

HO 638's ride-along A found **718 completed primaries: 506 with a `status='winner'` row, 212 without**, and split the 212 into 11 with recorded shares, 123 with no shares, 78 with no roster at all. The **11** are the interesting ones — a contest that has voted and recorded `vote_pct` but names no winner is invisible to `backfill:race-challengers`, which derives general-election challengers from primary winners. That was the third independent bar on the S-ME defect.

HO 639 filed the 11 as a backlog QUEUED line and split them into two classes with **opposite fixes**:

- **Top-two / jungle (8 of 11, CA/WA `-open`)** — two candidates advance by design, so a single `status='winner'` row is a *category error*. The harvest's model is wrong, not the data. Writing one winner would be writing a false claim to make a query happy.
- **Ranked choice (ME)** — a winner *is* well-defined, it arrives through elimination rounds. A genuine ingestion gap.

**8 + 1 = 9. The line says the remaining 2 were not characterized and must be before either fix is sized.** That is what this HO measures.

The same line carries a stated non-measurement: WA's contests are dated 2026-08-04, one week old at HO 638, so some may be **un-swept rather than structurally missing**. Nobody looked. It's the same query surface and the same tables, so it rides here rather than waiting for its own HO.

**What turns on the answer.** If the 2 are top-two, the 11 collapse to two clean classes (10 model-error + 1 ingestion-gap) and the backlog line simplifies. If they are a third shape — a runoff round, an uncontested seat, a withdrawn-field contest, a sync that half-completed — then the class analysis in the backlog is incomplete and the line needs amending rather than closing. **Either outcome is a result.** Do not reach for the tidier one.

## Schema, so the query is written against real columns

Verified against `.claude/skills/cbt/SKILL.md` at `6bc251b`:

```
primaries(id, state, district, chamber, party, primary_date, runoff_date,
          primary_type, race_id, election_round, updated_at)
  -- party:        'D' | 'R' | 'open'
  -- primary_type: 'closed' | 'open' | 'top_two' | 'top_four' | ...
  -- election_round: 'primary' | 'runoff'   (HO 107)
  -- district:     zero-padded ('07'); NULL for Senate

primary_candidates(id, primary_id, name, party, incumbent, bioguide_id,
                   status, vote_pct, updated_at)
  -- status:   'running' | 'winner'
  -- vote_pct: NULL until that contest has voted (HO 206)
```

Two traps in that schema worth naming before you write the query:

1. **`primaries.party` and `primary_candidates.party` are different things.** The contest-level `'open'` is the top-two/jungle marker; the candidate-level letter is the candidate's own party and is meaningful even inside an `'open'` contest. HO 577's defect class is adjacent — `primary_type` is a TYPE column, not a status column — so read both and don't collapse them.
2. **`election_round` exists.** A runoff row is a separate `primaries` row with its own date. If any of the 11 are runoff rows, that is a distinct shape from a round-1 contest missing a winner, and it must be reported as such rather than folded in.

## Phase 1 — Reproduce the 718/506/212 partition before characterizing anything

Do not start from the 11. Start from the whole, because a reproduction that doesn't match HO 638's numbers means the definition of "completed" drifted and every number below it is measuring something else.

Report, with the exact predicate you used for "completed":

- total contests matching the completed definition
- with ≥1 `status='winner'` candidate
- without
- of the without: (a) ≥1 non-null `vote_pct`, (b) roster present but all `vote_pct` NULL, (c) no roster at all

**Expected: 718 / 506 / 212, splitting 11 / 123 / 78.** If any figure differs, **halt and report the delta before proceeding** — say which predicate you used and what HO 638 is likely to have used instead. A drifting denominator is a finding in its own right and is worth more than the characterization.

**HALT here if the partition doesn't reproduce.**

## Phase 2 — Characterize all 11, one row each

Not just the 2. Print every one of the 11, so the 8-1-2 split is re-derived from the data rather than inherited from HO 638's report. Per contest:

| field | why |
|---|---|
| `id` | the `house-LA-01-2026-open` shape encodes state/district/party |
| `state`, `chamber`, `district` | placement |
| `party` (contest-level) | `'open'` is the top-two marker |
| `primary_type` | the authoritative type; `'top_two'`/`'top_four'` vs `'closed'`/`'open'` |
| `election_round` | round-1 vs runoff — a distinct shape |
| `primary_date`, `runoff_date` | recency, and whether a round-1 row points forward at a runoff |
| `race_id` | whether it even links to a rated seat (the harvest only reaches rated seats) |
| candidate count | a 1-candidate contest is uncontested, a different shape again |
| count with non-null `vote_pct` | partial vs full result ingestion |
| `status` distribution | all-`running`, or something unexpected |
| `MAX(vote_pct)` and the top candidate's name | whether a winner is *derivable* even though none is *recorded* |
| `MAX(updated_at)` across the roster | the WA question, below |

Then state explicitly, in your own words: **which of the 11 fall into top-two/jungle, which into ranked-choice, and what the residue is.** If the residue is 2 and they share a shape, name it. If they don't share a shape, say so — two singletons is a legitimate answer and better than a manufactured category.

## Phase 3 — The WA non-measurement

For the WA contests specifically: are they **un-swept** or **structurally missing**?

The discriminator is whether anything has touched those rows since the 2026-08-04 election. Compare `primary_candidates.updated_at` (and `primaries.updated_at`) against `primary_date`, and against the most recent run of whatever writes winner status.

**Read, don't assume, which script that is.** `backfill:primary-results` (HO 206) is the shares-population path; confirm from the script itself whether it also sets `status='winner'`, or whether that is `sync-primaries.ts`, or neither. If **no script in the repo sets `status='winner'` at all**, that is a much larger finding than this HO went looking for, and it retires the "un-swept" hypothesis for every one of the 11 at once — report it in that form rather than as a footnote.

Report one of three verdicts, in these words:

- **un-swept** — the writer exists, runs on a cadence, and simply hasn't reached these rows yet. Names when it next would.
- **structurally missing** — the writer exists and has run over these rows, and still recorded no winner. Points at the model.
- **no writer** — nothing in the repo sets `status='winner'` for this shape at all.

## Cost

`primaries` and `primary_candidates` are small relative to `bills` / `member_votes`, but the ledger discipline applies regardless and this project has been wrong about read cost twice in confident directions (HO 624). Report `rows_read` for the probe as a whole. If a bare `COUNT(*)` is used anywhere, remember it is answered from B-tree interior pages and **under-reports by 227–416×** (HO 624 M0) — use a predicated form for anything you intend to quote as a cost.

## Deliverable

`scripts/diagnostic/winner-status-gap-640.ts`, read-only, committed alone. Print a table, not prose. No `.md` writeup; the numbers come back here and I'll rule on whether they amend the two existing backlog lines or open a third.

## Verification

- The Phase 1 partition matches 718 / 506 / 212 → 11 / 123 / 78, or the delta is reported and the run halted.
- All 11 printed, not just the residue.
- The 8-1-2 split is **re-derived**, not restated from HO 638.
- One of the three WA verdicts given in the words above.
- `git status` clean apart from the one new untracked-then-committed script. No writes to any table. If the script contains an `INSERT`, `UPDATE`, `DELETE` or `seed` call, it's the wrong script.

## Out of scope

- No fix. Not to the harvest's model, not to the ingester, not to `race_candidates`.
- No backlog edits. The line stands as written until the numbers are in.
- No `seed:races`, no tag flushes, no prod reads.
- The `deriveMatchup` local `won` nit stays parked; it is not in this file's scope and rides with whatever next opens that function.
