# HO 405 — Summarize cron stall: diagnostic probe

> Renumber if HEAD has moved past 404. HEAD is `05d8c61` (HO 404 audit).
>
> **Read-only probe. HALT before any fix.** This finds the failure mode; it changes no code, no schema, no prompt. The fix is a separate handoff scoped off what this returns — same as HO 369, where the news cron's real cause (a `MULTI-INDEX OR` mis-plan, not the LLM) only became fixable after the probe named it.

## What HO 404 saw

The summarize cron failed 3 of the last 4 daily ticks (07-02 timeout, 06-30 error, 06-29 timeout) and the unsummarized backlog is climbing: `summary IS NULL` went **1,011 (Jun 12) → 1,374 (Jul 2)**, ~363 bills in three weeks. That's active decay — every failed tick, the corpus gets less answerable, which is the one thing the product can't afford. Foundation is held at 96 with this as its fuse (HO 404): unfixed by the next pass, it docks.

## The three candidate failure modes

HO 284 established that "cron timeout" on this project is usually mislabeled. For the **weekly-report** cron the real cause was `boundedFetch`'s 10s+10s Turso double-timeout (a DB cold-stall in data-gathering), **not** the LLM. The summarize cron is a different path but the same three modes are in play, and the probe's job is to say which:

1. **Turso cold-stall / mis-plan** — the presentment-queue read (which bills to summarize) cold-aborts or mis-plans against the fat `bills` table, so the run dies before or between Gemini calls. This is the HO 238 10s `DB_REQUEST_TIMEOUT_MS` class that has bitten nearly every corpus-query on this project.
2. **Gemini latency / 503** — the model calls themselves are slow or rate-limited/erroring, and the run runs out the function ceiling mid-batch.
3. **Batch outgrowing the window** — nothing is broken per-call; there are just too many bills per run to finish inside the Vercel function ceiling, so it always times out with a non-empty queue and the backlog can only grow.

These have different fixes (index/hint a query · retry-and-backoff or a fallback model · bound the batch size + drain incrementally), so guessing wrong wastes a handoff. Don't pre-judge — the modes can also co-occur (a slow queue read leaves less time for Gemini, so a batch that would fit becomes one that doesn't).

## What to gather (read-only)

Work from live prod (`.env` → the single hosted Turso) and the deployed cron's own telemetry. Paste every number verbatim.

### 1. What the cron records about itself
- `cron_runs` for the summarize job, last ~14 ticks: `status`, `elapsed`, `started_at`, and whatever per-run detail the payload carries (batch size attempted, count summarized, errors array). The elapsed **signature** is the first tell — HO 369's abort sat at ~20.2s (the 10s bound + one retry); a run pinned at the Vercel function ceiling instead points at mode 2/3, a sub-ceiling error points at mode 1 or a thrown Gemini error. Report the actual elapsed of each failed tick against both the 10s DB bound and the function ceiling.
- Confirm the ceiling this cron runs under (Hobby function limit) and the route's configured `maxDuration` if set — mode 3 is only diagnosable against the real wall.

### 2. The queue read (mode 1 test)
- Find the query that selects which bills to summarize (the presentment-queue / `summary IS NULL` selection the summarize runner uses — grep the runner, likely in `scripts/summarize.ts` / its lib helper). `EXPLAIN QUERY PLAN` it against live. Report whether it goes index-only or drops onto a full `bills` scan / `MULTI-INDEX OR` (the recurring mis-plan class). Time it cold.
- If it mis-plans, that's mode 1 and the probe can stop hunting — but still capture 3 and 4 so the fix is scoped whole.

### 3. Per-call Gemini timing (mode 2 test)
- From the telemetry (or a single instrumented dry-run of the runner against a **handful** of already-null bills — no writes needed, or write to a throwaway and roll back), get the per-bill Gemini latency distribution and any non-200s. Is a typical call ~1–3s or is it 10s+? Any 503/429? Does the summarize call even carry an `abortSignal`, or can one slow call hang the whole run (the HO 284 finding — the report's Gemini call had none)?
- Note the model: SKILL says Gemini 2.5 Flash. Confirm the runner isn't silently on a slower/thinking variant.

### 4. Batch math (mode 3 test)
- How many bills does one tick attempt (the batch cap, if any), and at the per-call latency from §3, does that batch fit inside the ceiling? Compute it: `batch × p50_latency` vs ceiling. If the attempted batch can't finish in the window even with a healthy queue read and healthy Gemini, mode 3 is present regardless of 1 and 2.
- Given the backlog is 1,374 and growing, also report: at the current successful-tick throughput (bills actually summarized per good run), is once-daily even net-positive against new-bill inflow, or is the daily cron structurally underwater?

## Report back

- The elapsed signature of the failed ticks against the two walls (10s DB / function ceiling).
- The queue-read EXPLAIN + cold time.
- Gemini per-call latency + error rate + whether the call has an abort.
- The batch-vs-window math, and the throughput-vs-inflow read.
- **Your verdict: which mode(s), with the evidence line for each.** That verdict is the input to the fix handoff — I'll scope the fix off it, not off a guess.

## Non-goals

- No fix. No index added, no hint applied, no prompt/model change, no batch re-cap, no retry logic. This pass only names the mode.
- No touching the weekly-report cron (separate surfaced finding, its own handoff).
- No schema, no migration.

## Rollback

Nothing to roll back — read-only. If §3 uses a throwaway write to measure Gemini timing, delete it after.
