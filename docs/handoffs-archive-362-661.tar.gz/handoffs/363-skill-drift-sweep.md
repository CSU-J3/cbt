# HO 363 — SKILL.md drift sweep (full read, not range-scoped)

> Claim the next free HO number: `ls docs/handoffs/ | sort -V | tail`. Body assumes
> 363. SKILL.md only — this is **not** the four-doc sweep (362 did that).

Different job from 362. 362 reconciled the sections the 352–361 arcs touched (auth,
watchlist, reports anatomy, sub-nav, landing) and they're current. This is a
**full top-to-bottom read of the live `SKILL.md`** for accumulated drift in the
**structural sections a range-scoped sweep never opens** — schema, route/IA names,
the BillRow grid. Those predate ~40 handoffs and are where this doc rots.

**Read-first.** Read the whole live file against current code. **Fix the clear-cut
stale facts in place. FLAG, don't silently change, anything that's a tracked open
loop or a judgment call** (called out below). Don't re-do 362's sections.

## Method

Read live `SKILL.md` end to end. For each section, check it against live code /
schema / routes. Produce a drift list. Fix the unambiguous staleness; flag the rest
with a recommendation. Verify against the live tree — don't trust the section's own
claims.

## Suspect sections — check each against live (verify, don't assume broken)

**1. Frontmatter `description` + "What this is".** 362 fixed the "What not to do" /
intro auth lines (Code confirmed already-current). Confirm the **frontmatter
`description`** and any remaining prose don't still frame this as a single-user /
private feed. Real state: multi-user terminal, **GitHub OAuth** (NextAuth v5),
logged-out is the demo, auth gates only the watchlist. (Note: provider is **GitHub**,
not Google — 362's own handoff had that backwards; the live code keys on `github_id`.
Don't reintroduce "Google" anywhere.)

**2. Stack.** Confirm it names **Gemini 2.5 Flash via `@google/genai`** for
summarization — flag any stale "Anthropic SDK" reference. If the stack list
enumerates auth/hosting, confirm NextAuth v5 / GitHub is reflected.

**3. Build order.** Confirm no stale "single-user / don't add auth" framing survives
here (same contradiction class as the intro, easy to miss in this section).

**4. Schema block — likely the biggest gap.** Does the documented schema match the
**live tables**? The DB has grown well past `bills` + `watchlist`: votes /
`member_votes` / `members` (HO 77/79/80), committees + `meeting_bills` / hearings,
`news_mentions`, `rating_history`, `stage_transitions`, races / primaries, `users`
(355), the composite-PK `watchlist` (356). Check coverage.
- If the block is **materially incomplete**, **FLAG with a recommendation** — full
  re-document vs. a "canonical schema lives in `scripts/migrate.ts`; key tables
  summarized here" pointer. **Do not blindly transcribe ~40 tables** into the doc.
- Confirm the `bills` table columns + indexes are current: the **FTS5** full-text
  index (HO 338) and the covering indexes from the cold-start arc (331–342). Flag if
  the documented indexes lag what `migrate.ts` creates.

**5. Routes / IA "working theses".** The IA *rule* (snapshot → hub → sub-page) is
durable — leave it. The **route names** likely lag:
- Member hub: confirm whether it's `/members` (post HO 89 rename) or still the stale
  `/sponsors/[bioguideId]`. Fix to live.
- The bills surface is now nav-labeled **LEGISLATION** (route stays `/bills`, HO 362).
- Confirm the documented route map reflects what exists: `/reports`, `/hearings`,
  `/electoral`, `/patterns`, `/changes`, `/president`, `/watchlist`, `/welcome`. Add
  the missing, correct the renamed.

**6. Design system — grid + typography (known drift zone).**
- **BillRow grid:** the column template changed at **HO 125** — the doc has quoted a
  pre-125 grid before (the 215/130 trap). Confirm the documented grid matches the live
  `.feed-row` template; fix if stale.
- **Typography:** the type-scale section may be stale, **but the HO 157 → 281 ≥701px
  desktop lifts are a TRACKED OPEN BACKLOG LOOP.** If the doc is stale here, **FLAG
  that it points at the open loop — do NOT silently rewrite the type scale** (that
  pre-empts the loop). Note the discrepancy and move on.

**7. Things to watch.** The `revalidate`-is-inert-in-Next-15 note is durable — keep.
Check the rest for staleness. If Turso planner-discipline notes (INDEXED BY, covering
indexes, stateless cold plan) live here AND in oddities, don't duplicate — leave them
where they're canonical and cross-reference at most.

## Constraints

- **SKILL.md only.** Not the four-doc sweep.
- Reconcile **in place** — find the section, fix or flag; don't append a changelog.
- **Brand strings stay** ("CBT" / "Congress Bill Terminal"). The CBT → Congressional
  Terminal rename is a deferred sweep (backlog loop); confirm 362's one-line
  in-transition note is present, change nothing else brand-side.
- **Don't pre-empt tracked open loops** (type-scale lifts) — flag, don't fix.
- **Don't balloon the schema block** — flag big gaps for a decision rather than
  transcribing every table.

## Commit / report

- Shared tree is live (co-agents commit here): named `git add SKILL.md`, **commit by
  explicit pathspec** (`git commit -m "..." -- SKILL.md`), re-check HEAD
  (`git log --oneline -1`) before push. Docs-only, no `verify:deploy` needed.
- **Report:** the drift list (every section, stale-or-current); what you fixed in
  place; what you flagged for a decision (schema gap + recommendation, the type-scale
  loop, anything else); and the final SHA.
