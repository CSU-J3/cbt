# HO 487 — doc sweep: lobbying redesign arc (485–486) + owed trades verification (482–483)

Docs only. **No code, no schema, no component changes.** This sweep clears two arcs: the `/lobbying` members-style redesign shipped this session, and the trades batch-fix verification still owed from 482/483.

Prod is already verified live at `0765aaf` — rail (`ISSUES · 79`, VOL-sorted), the `AGE / REGISTRANT → CLIENT / ISSUES / BILLS` header, carets on rows, pager clamped at `Page 1 of 40`, crosswalk + firms leaderboard below, no standalone drill section. **Don't re-verify the surface.**

## Numbering note (read first)

The roadmap's running pointer stops at **HO 481** while git labelled through **483**. HO 484 was drafted as the trades doc sweep but never issued — its content is folded into this sweep instead. **484 is deliberately skipped.** Say so explicitly in the roadmap block so a future session doesn't hunt for a missing file. This sweep is **487**.

---

## Step 1 — `cron_runs` pull (do this first; the numbers gate Step 2)

The 482/483 trades claim on record is "warm trades wall dropped 5–11.5s → 320ms," measured at fix time. It has never been verified against multiple days of prod cron rows. Pull it now:

```sql
SELECT route, started_at, duration_ms, status
FROM cron_runs
WHERE route LIKE '%sync%'
  AND started_at >= datetime('now', '-14 days')
ORDER BY started_at DESC;
```

Report: **p50 / p90 / max `duration_ms`** for the sync route over the window, the **count of runs**, and any **non-ok `status`** rows. Also flag whether the **00:00-UTC residual contention oddity** (banked at 483) shows in the data — group by hour-of-day and say whether the midnight slot runs measurably slower than the others.

**Cite the verified figures in the roadmap block, not the fix-time claim.** If the pulled numbers contradict the 320ms figure, write down what prod actually shows and flag it — a logged number is a claim, not a fact. Do not "fix" anything either way; this sweep is documentation only.

Re-probe triggers stay as banked: **52s breach, or trades p90 > ~13s.** State in the roadmap whether the pulled data is near either.

---

## Step 2 — `docs/roadmap.md`

Append-only. **Add a new dated block; never retro-edit a prior block's clause.** HO 418 is the standing precedent. Bump the running pointer to 487.

Cover, in order:

- **HO 482/483 — trades batch fix.** ~200 sequential `db.execute` round-trips in `lib/trades-ingest.ts`'s `ingestChamber` collapsed into one `db.batch(statements, "write")`. Cite the **Step 1 verified prod figures**. Note the banked re-probe triggers and the 00:00-UTC oddity with whatever Step 1 found.
- **HO 485 — LDA filing-expand cost + shape probe.** Verdict GO. Worst-case single-filing read **75ms cold** (31 activities), typical **29–85ms**. Plan confirmed `SEARCH lda_activities USING INDEX sqlite_autoindex_lda_activities_1 (filing_uuid=?)` — a PK-prefix seek, the inverse of the HO 439 random-fetch trap that measured 44.5s. Committed as `scripts/diagnostic/lda-filing-expand-cost-485.ts`. Note the follow-on `0614a66` typecheck guard (see oddities).
- **HO 486 — `/lobbying` members-style redesign.** Two commits: `2bc1a26` (chrome: issue rail + filings content, scope via `?issue=`) and `0765aaf` (expandable rows + per-activity panel, carrying the A-regression fix and the `IssueDrill` removal). New query: `getFilingActivities` only. Record the **deliberate divergence from `/members`**: scoping an issue serves the precomputed `drill.recent` sample, not a complete per-issue browse, because a live per-code feed is the **HO 437 abandoned query (>25s cold)**. Pager stays on the unscoped corpus feed only.
- **Numbering**: state that 484 was never issued and its content lives here.

---

## Step 3 — `docs/oddities.md`

Five entries. These are the durable ones.

1. **Component layout belongs to the component, not its container.** Commit A gave `FilingRow` the `.mc-row` class and put its grid in `.lob-content .mc-row`. `BillLobbying` renders `FilingRow` on `/bill/[id]` outside any `.lob-content` ancestor, so those rows silently inherited the base `.mc-row` grid (`1fr 320px 56px 64px 52px`, the members layout) and broke. Fix was a row-owned `.lob-filing-row`. **Rule: when a shared component needs a grid, the class goes on the component. Ancestor-scoped overrides break every consumer that isn't the one you were looking at.**

2. **Dead files poison consumer audits.** `IssueDrill.tsx` was orphaned by commit A but still imported `FilingRow`, so a "who consumes this?" grep returned it as a live consumer. That noise is part of why the `/bill/[id]` consumer was missed. **Rule: delete orphans in the commit that orphans them.** Removed in `0765aaf`.

3. **Typecheck is not covered by the pre-push checklist.** The HO 485 probe pushed at `3ed533c` with a broken `npm run typecheck`, undetected until the next session (fixed at `0614a66`). The ancestry eyeball verifies git hygiene, not build health. **Rule: `npm run typecheck` clean is a pre-push gate on every commit, diagnostics included.** (Mirror into SKILL.md — Step 5.)

4. **URL-param interactions must not render where nothing reads them.** Pre-fix, the expand toggle would have shipped on `/bill/[id]`, where clicking a row sets `?expanded=` with no panel wired to it: caret flips, nothing happens. Resolved with an opt-in `expandable` prop — the empty 16px caret cell stays so the grid is identical across surfaces. **Rule: if a component writes a URL param, the surfaces that don't read it get the inert variant.**

5. **Rollup-blob stats lag the raw tables.** Prod `/lobbying` header reads 110,055 filings / 236,118 activities; the HO 485 probe read 112,068 filings / 240,887 activities off the raw tables the same day. The header comes from the precomputed `lda_lobbying_rollup` blob, which is cron-computed, so it trails by up to one cycle. **Expected, not a bug — don't log it as one.** Reconcile blob-sourced against blob-sourced when comparing lobbying figures.

Also append to the existing LDA shape reference (durable, from the 485 probe, n=112,068 filings / 240,887 activities):
- activities per filing — **p50 2 · p90 4 · p99 10 · max 31**
- description length — **p50 95 · p90 410 · p99 1,838 · max 24,447 chars · 0.0% empty**
- resolved bills per filing — **p50 3 · p90 12 · p99 65 · max 449**
- `lda_activities.bill_ids` is the **raw extracted JSON** and is a superset of the resolved rows in `lda_activity_bills` (44 vs the resolved subset on the worst row). **Always chip from the resolved table; the raw JSON produces dead links.**

---

## Step 4 — `docs/backlog.md`

Add, each with a one-line reason so a future session knows why it wasn't built:

- **`/lobbying` fbar features** — sort seg (RECENT/VOLUME), bill-linked-only toggle, registrant/client search. Each needs a new query or capability; deliberately cut from 486 to keep it a chrome restructure.
- **Description line-clamp + "show more"** — v1 ships a `max-height:140px` scroll box. A clamp with explicit expand is the fast-follow, warranted by the p99 1,838 / max 24,447 tail.
- **Rail ISSUES ⇄ TOPICS toggle** — parked at design (fork 3). `/members` has one rail, not a mode switch; the crosswalk section below already does the job. Revisit only if the crosswalk stops earning its space.
- **Live per-issue filings feed** — blocked on the HO 437 >25s query. Would need a per-code cost probe before any spec. This is what the scoped-view divergence is working around.
- **Headless prod verification is blocked by BotID** — verify via SHA + CSS class presence + the `?expanded=` API, or eyeball through local CDP. Note so nobody re-discovers it.

---

## Step 5 — `.claude/skills/cbt/SKILL.md` (SEPARATE COMMIT — self-mod guard)

Two conventions earned this session:

- **Shared-component layout rule** (oddity 1): grid/layout classes live on the component, never on an ancestor-scoped selector. Before changing a shared component's markup, enumerate **every** consumer (`grep -rn "<ComponentName"` across `app/` and `components/`) and check each surface.
- **Pre-push gate** (oddity 3): `npm run typecheck` clean is required before every push, diagnostics included. Add it alongside the existing ancestry eyeball.

**Self-mod guard applies: show the SKILL.md diff and wait for explicit re-approval. Separate commit from all other changes. Do not bundle it with the docs commit.**

---

## Git discipline

- Clone / hard-reset to `origin/main` first — HEAD should be **`0765aaf`**.
- Explicit pathspec staging. Never `git add .`.
- **Two commits, never riding together** (code/docs separation applies to SKILL.md too):
  1. `docs: sweep lobbying redesign arc + trades verification (HO 487)` — roadmap, oddities, backlog.
  2. `docs(skill): shared-component layout rule + typecheck pre-push gate (HO 487)` — SKILL.md only, after diff approval.
- Ancestry eyeball before each push: `git log --oneline @{u}..HEAD` = expected commits only, clean fast-forward, no concurrent-session files touched. Fast-forward only, no force-push.
- **Run `npm run typecheck` before pushing** — the gate this sweep is documenting.

## Report back

The Step 1 `cron_runs` figures (p50/p90/max, run count, non-ok statuses, midnight-slot finding), then the roadmap block diff, then the SKILL.md diff separately for its own approval.

---

read docs/handoffs/487-doc-sweep-lobbying-arc.md and follow it
