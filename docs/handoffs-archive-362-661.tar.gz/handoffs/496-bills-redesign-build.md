# HO 496 — `/bills` two-pane redesign (build)

Restructure `/bills` into the `.mc-*` two-pane, topic rail on the left, bill rows unchanged. Fork settled (multi-select preserved), probe (HO 495) verdict PARTIAL. **One HO, two commits** (A = data, B = chrome), each diff-reviewed. Bills mode only — news is untouched this HO. No migration, no index, no cron.

Reference mockup: `bills-redesign-mockup.html`.

## Frame

Third application of the pattern: committees on `/members`, issue codes on `/lobbying`, CBT topics here. The 24-chip topic filter row becomes the rail; the stage legend and party key fold into the keystrip; bill rows and `BillExpandPanel` are reproduced **unchanged** (rows-out-of-scope). Topics stay **multi-select** (`?topics=HLTH,TAX`, OR semantics) — that's the divergence from the two single-scope rails, and it's deliberate: dropping a filter capability to match a visual convention is the wrong trade.

---

## Commit A — the rail count query (data layer)

### New function, not an extension of `getTopicDistribution`

**Do not change `getTopicDistribution`'s signature or behavior.** It has two live consumers — `app/page.tsx:97` and `app/dashboard-classic/page.tsx:80`, both `(filters, true)` — that rebase on **stage only** today. Adding chamber/ceremonial rebasing there would silently change the dashboard treemap. That's a behavior change riding in a `/bills` commit, the exact shape of the HO 486 `/bill/[id]` regression.

Add a sibling: `getBillTopicRailCounts(filters)` in `lib/queries.ts`, next to `getTopicDistribution`.

**Rebase on the bounded dimensions only — stage, chamber, ceremonial. Do NOT rebase on `q`** (HO 495: `q` gives zero scan-narrowing because the query GROUP BYs all 24 topics regardless, so broad and narrow terms cost the same full-corpus walk; and every distinct search string becomes its own unbounded cache key). The rail is a browse spine; search is a needle-finder. When `q` is active, rail counts reflect the non-`q` filters — the selected topics still filter the feed, the rail just doesn't shrink to the search.

**Self-exclusion**: the rail count must NOT apply the topic selection itself (HO 495 confirmed no coupling to decouple — `getTopicDistribution` never touches `filters.topic`). With OR semantics, a count has to predict what *clicking* does: clicking TAX while HLTH is active *adds* bills, so TAX's count is "how many TAX bills under the current stage/chamber/ceremonial," never "HLTH-and-TAX."

### The query — carry the HO 382 hint logic exactly

Model it on `getTopicDistribution`'s SQL, extended for chamber. The **mandatory** requirement from HO 495 Step 5: keep the `INDEXED BY` hint on the stage-absent path or it regresses to `MULTI-INDEX OR` on `idx_bills_is_ceremonial` — the HO 382/335 misplanner.

- `json_each(bills.topics)` fanout, `GROUP BY je.value`, `ORDER BY count DESC`.
- Ceremonial: default excludes (`is_ceremonial = 0 OR is_ceremonial IS NULL`); when the ceremonial toggle is on, drop that clause.
- Stage present → `INDEXED BY idx_bills_summary_stage_topics`. Stage absent → `INDEXED BY idx_bills_summary_topics`. This mirrors the existing helper — reuse its exact hint branching.
- Chamber → `bill_type` predicate as a post-index row filter (HO 495: fine, the query walks the whole topic index anyway).
- Match the summary-gating the live `/` path uses (it calls gated; the probe measured gated as the real baseline).

**No new index.** HO 495 verified the two existing partial covering indexes suffice. If the build seems to want one, stop and report — that's a migration HO.

### Cache

Key on the **bounded tuple only** — `["billTopicRail", stage ?? "", chamber ?? "", ceremonial ? "1" : "0"]`. ~36 combinations, trivial at `revalidate: 3600`. **`q` must not enter the key** (that's the unbounded-blowup the PARTIAL verdict rules out). Tag `["bills"]`, same as the sibling.

### Zero-count topics

Return all 24 topics including zeros, so the rail is stable — a topic that drops to 0 under the current filter renders greyed, it does not vanish and reflow the rail. If the `GROUP BY` naturally omits zero-count topics (it will — no matching rows means no group), the caller pads the missing topics to 0 against the known 24-topic vocabulary.

### Commit A verification

- `getBillTopicRailCounts` returns 24 rows (padded) for: no filter; `stage=floor`; `chamber=house`; `stage+chamber`; ceremonial-on. Spot-check a stage-narrowed count against a direct query.
- Timing sanity in dev: stage-present combos ~tens of ms; worst bounded (chamber-alone) in the same band as the existing `/` treemap, not worse.
- `getTopicDistribution` **untouched** — `git diff` shows no change to it or its two callers; the dashboard treemap is unaffected.
- `npm run typecheck` clean.

---

## Commit B — the two-pane chrome

### Page (`app/bills/page.tsx`)
- **Keep above the pane** (page-level nav, not filters): the LEGISLATION/NEWS mode toggle and the CHANGES/PRESIDENT/REPORTS group tabs. These aren't rail concerns.
- **`mc-fbar`** — keeps the real filters (unlike `/lobbying`'s count-only bar): scope-count (left) + stage select + chamber segment + ceremonial toggle + search + sort. The **24-chip topic row is removed** — it's the rail now.
  - Scope count reflects the active filter set: `{feedCount} BILLS` unscoped, `{feedCount} BILLS · HLTH + TAX` when topics selected. Reuse the existing feed count.
- **`mc-pane`** (`grid`, ~264px rail):
  - **rail** (`.bl-rail`): header `TOPICS · 24` + `CLEAR` (clears `?topics=`). Rows from `getBillTopicRailCounts` → new `TopicRailRow`. **Multi-select** — several rows lit at once.
  - **content** (`.mc-content`):
    - **keystrip**: absorbs the old **stage legend + party key** row (STAGE swatches · separator · R/D/I). This is where the removed legend row goes.
    - **`mc-ctx`** (only when `?topics=` non-empty): the selected topics as removable chips (`HLTH ×`, `TAX ×`, each clears just that topic) + `· {count} bills · {pages} pages` + `× all topics`.
    - **column-less bill rows** — the existing feed rows, **unchanged**, expandable via the existing `?expanded=` + `BillExpandPanel`.
    - **pager** top + bottom (existing, `MAX_FEED_PAGES` clamp preserved).

### `TopicRailRow` (new, `components/TopicRailRow.tsx`, `"use client"`)
- **Multi-select toggle**, not single-scope — this is the key difference from `CommitteeRailRow`/`IssueRailRow`. Clicking adds/removes the topic from the `?topics=` CSV (mirror the existing `TopicFilter` toggle logic at `components/TopicFilter.tsx:20` — it already does `next.join(",")`), preserving all other params. Re-clicking a lit row removes it.
- Reuse the `.mc-crow`-family shell but with a **checkbox-style marker** (a topic-colored filled square when selected), not the single-select amber left-border — the marker has to read as "one of several," per the mockup's `.bl-mark`.
- Cells: marker · topic name · topic-colored count bar (`backgroundColor` inline from the topic color map) · count. Zero-count topics render greyed and are still clickable (or inert — your call, but greyed-clickable is friendlier).
- Bar width = `count / maxCount` across the current (filtered) distribution, so the bars rescale as filters narrow.

### CSS (`app/globals.css`)
- Scope everything under `.bl-rail` / lobbying-style wrapper classes so the shared `.mc-crow`/`.mc-row` grids (members, lobbying) are **untouched** — the HO 486 lesson. New: the rail grid (`44px`-ish count column), the checkbox marker, the keystrip separator, the `mc-ctx` removable-chip styling. Pull exact rules from the mockup.
- `/members`, `/lobbying`, `/bill/[id]` must render byte-identical — verify no shared `.mc-*` rule changed.

### Commit B verification
- Unscoped `/bills`: rail lists 24 topics (VOL-desc, topic-colored bars), fbar filters present, feed + pager, no `mc-ctx`, keystrip shows stage + party legend.
- Select HLTH: row marker fills, `mc-ctx` appears with an `HLTH ×` chip, feed narrows, rail counts **rebase** (other topics' counts drop to their HLTH-co-occurrence numbers... no — to their counts under the *non-topic* filters; HLTH selection doesn't rebase the rail, per self-exclusion). Confirm the rail does **not** collapse to HLTH-only.
- Select HLTH + TAX: both markers lit, two chips, feed = HLTH OR TAX (more bills than either alone — confirm the count *grows*, proving OR).
- Set `stage=floor` with HLTH selected: rail counts drop to floor-stage numbers (rebase on bounded dim), feed reflects both.
- Type in search: feed narrows, rail counts do **not** change (q excluded from rebase) — this is the intended PARTIAL behavior; confirm it's not a bug on sight.
- Expand a bill (`?expanded=`): `BillExpandPanel` renders unchanged, carries `?topics=` and `?page=`.
- `× all topics` and per-chip `×` clear correctly.
- `/members`, `/lobbying`, `/bill/[id]` unchanged.

---

## Out of scope

- **News mode.** Renders its current single-column layout untouched; the mode toggle swaps layouts. A news spine (sources, not topics — `source` is already a news param) is a separate future HO. Do not build a news rail.
- **`q` rebasing the rail** — excluded by the PARTIAL verdict.
- **Splitting `/news` to its own route** — noted as the real long-term fix for the 10-param page, not this HO.
- No changes to `getTopicDistribution`, the dashboard treemap, or bill row internals.
- The `queries.ts:708` comment says "`/` calls it ungated" — it's gated (`app/page.tsx:100` passes `true`). Doc-only error; fix it in **this HO's commit A** while you're in the file (one-line comment correction, rides with the query work).

## Git discipline

- Clone / hard-reset to `origin/main` first — HEAD should be **`0d21148`** (HO 495 probe).
- Explicit pathspec; never `git add .`. Files: `lib/queries.ts` (A), `components/TopicRailRow.tsx` + `app/bills/page.tsx` + `app/globals.css` (B).
- **Live surface → show the actual diff and wait for approval before each commit.**
- Two commits: A `feat(bills): topic-rail count query, bounded-dim rebasing (HO 496)`, B `feat(bills): two-pane browser with multi-select topic rail (HO 496)`. Working state after A (query exists, unused).
- `npm run typecheck` before each push. Ancestry eyeball, fast-forward only. CI runs (touches `app/`, `lib/`).

## Report back

After A: the `getBillTopicRailCounts` diff, the spot-check count vs direct query, confirmation `getTopicDistribution` is untouched. After B: the page/component diff, the OR-grows-the-count check, the `q`-doesn't-rebase confirmation, and that the three other pages are unchanged. Then live-verify + the doc sweep.

---

read docs/handoffs/496-bills-redesign-build.md and follow it
