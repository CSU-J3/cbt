# HO 492 — `/lobbying` height compaction

Chrome only. The page is ~3,000px tall; the target is ~1,200px, so the crosswalk and firms leaderboard are reachable without scrolling past a wall of issue codes.

Three changes, all layout. **No data-layer changes, no new queries, no row-rendering changes** (the rows-out-of-scope convention). Reference mockup: `lobbying-compaction-mockup.html`.

## Why the page is tall

The `.mc-*` system has **no height bound anywhere** — `.mc-pane`, `.mc-rail`, `.mc-content` are all unbounded. The rail renders all 79 issue codes at ~1,400px while the content column is ~500px, so the pane is set by the rail with roughly 900px of dead whitespace beside it. Then the crosswalk and firms stack full-width below, each using well under half their horizontal space.

---

## Change 1 — bound the issue rail

Scope to `.lob-rail`, **not** shared `.mc-rail`. That class already sits on the rail element (added in HO 486 commit A), so it's element-owned. `/members` gains nothing from a bound (its roster is far taller than its committee rail) and shared-class edits for one consumer's benefit are what broke `/bill/[id]`.

Structure: rail becomes a flex column, header `flex: none`, rows in a scrolling region.

```css
.lob-rail { display: flex; flex-direction: column; min-height: 0; }
.lob-rail-scroll { overflow-y: auto; min-height: 0; /* max-height: see below */ }
```

**Pick the max-height by measuring, don't take a number from the mockup.** Measure the content column's rendered height in *both* states — unscoped (column header + 15 filing rows + pager) and scoped (`?issue=BUD`: ctx header + who's-who strip + column header + `drill.recent` rows, no pager). Set the bound so the rail bottom lands near the content bottom in both, minimizing dead space either way. Expect somewhere near 460–520px for the scroll region. **Report the two measured content heights and the value you chose.**

Style the scrollbar to match the terminal aesthetic (`scrollbar-width: thin`, dark thumb) — see the mockup's `.lob-rail-scroll` rules.

### The regression this introduces, and the fix

Unbounded, the selected rail row is always visible. Bounded, scoping an issue low in the list (say `MON`, last of 79) re-renders with that row selected **and the rail scrolled back to the top**, so the user can't see what's selected.

Fix inside `IssueRailRow` (already `"use client"`): when the row is the selected one, scroll itself into view on mount via a ref and `scrollIntoView({ block: "nearest" })`.

**Verify the page itself doesn't jump.** `block: "nearest"` should scroll only the rail's overflow container, but confirm it on a deep selection — if the window scrolls, set `scrollTop` on the container directly instead.

---

## Change 2 — crosswalk and firms side-by-side

Wrap both existing sections in a 2-col grid below the pane:

```css
.lob-secs { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
@media (max-width: 900px) { .lob-secs { grid-template-columns: 1fr; } }
```

Both compress comfortably — the crosswalk bars currently occupy roughly 40% of a 1,180px column, and the firms table's real content is similarly narrow. If the firms table genuinely can't hold its columns at half width, **report which column is the problem rather than dropping one on your own**; that's a content decision.

The single-column fallback below 900px matters — two 590px panes on a phone would be unusable.

---

## Change 3 — bound both sections

Same flex-column pattern: section header `flex: none`, column-header row `flex: none`, body scrolls.

```css
.lob-sec-scroll { overflow-y: auto; max-height: 340px; min-height: 0; }
```

The crosswalk is interactive (HO 444/463 — tapping a topic reveals its issue codes). **Verify expansion still works inside the bounded scroll region** and that an expanded topic doesn't get clipped. If expansion pushes content past the bound it should scroll, not overflow-hidden.

---

## Out of scope

- No changes to crosswalk or firms **row internals** — wrapping and layout only.
- No changes to `getLobbyingRollup` / `getTopFirms` / `getTopicCrosswalk` or any query.
- Don't touch shared `.mc-pane` / `.mc-rail` / `.mc-content`. If something seems to require it, stop and report.
- Not fixing the deferred fbar items (sort seg, bill-linked toggle, search) — still backlogged.

## Verification

- **Total page height before and after**, measured, both unscoped and scoped. Report both numbers.
- Rail scrolls internally; all 79 issues reachable; header stays put.
- Deep selection (`?issue=MON`) scrolls the selected row into view without the window jumping.
- Scoped state (`?issue=BUD`) still renders ctx + who's-who + no pager, and the rail bound still looks right against the shorter content.
- Filing row expand (`?expanded=`) still works inside the bounded pane and isn't clipped.
- Crosswalk topic expansion works inside its bound.
- Below 900px, sections stack single-column.
- `/members` and `/bill/[id]` unchanged — no shared `.mc-*` rule touched.

## Git discipline

- Clone / hard-reset to `origin/main` first — HEAD should be **`e1abfc5`**.
- Explicit pathspec staging; never `git add .`.
- **Live surface change — show the actual diff and wait for approval before committing.**
- One commit: `feat(lobbying): compact page height — bounded rail, side-by-side sections (HO 492)`.
- `npm run typecheck` before push. Ancestry eyeball, fast-forward only. CI will run (this touches `app/`, so the `paths-ignore` filter won't suppress it).

## Report back

The two measured content-column heights and your chosen rail bound, total page height before/after in both states, the diff, and confirmation on the deep-selection scroll and crosswalk expansion.

---

read docs/handoffs/492-lobbying-compaction.md and follow it
