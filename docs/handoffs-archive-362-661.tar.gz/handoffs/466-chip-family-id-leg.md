# HO 466 — chip-family ID leg (B6 arc)

Unify the **non-chamber** bill-id surfaces onto the amber tier-1 chip. **Decision 1 (Corey): keep chamber-tint** — `BillIdRail` (vertical) + `.bill-chip` (horizontal) stay chamber-colored per HO 125 (chamber-of-origin is a structural signal); the amber chip absorbs only the plain-text amber/green id surfaces. `.v2f-id` already matches the HO 287 tier-1 spec exactly, so it's the source of the shared primitive, not a rebuild. Closes the ID leg from the HO 465 audit.

One commit. Re-grep every consumer and CSS rule at write time (line numbers below are from a clean clone at b2b5dc2 — the concurrent session has uncommitted globals.css edits, so resolve lines yourself).

## Build

### 1. The shared primitive

`.v2f-id`'s current rules (globals.css): `flex: none; font-size: 11px; font-weight: 600; color: var(--accent-amber); border: 1px solid var(--accent-amber); border-radius: 2px; padding: 2px 7px; white-space: nowrap;`. Lift into a neutral shared class:

```css
.bill-id-chip {
  flex: none;
  display: inline-flex;
  align-items: center;
  font-size: 11px;
  font-weight: 600;
  color: var(--accent-amber);
  border: 1px solid var(--accent-amber);
  border-radius: 2px;
  padding: 2px 7px;
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
  text-decoration: none;
  transition: background-color 0.12s;
}
.bill-id-chip:hover {
  background-color: var(--bg-row-hover);
}
```

New component (unifies id formatting via `formatBillId`, which returns `"HR 123"` — identical to WeeklyBand's current hand-format):

```tsx
import Link from "next/link";
import { formatBillId } from "@/lib/format";
import { BILL_TYPE_LABELS } from "@/lib/enums";

// HO 466 — the shared amber tier-1 bill-id chip (chip-family). The canonical
// treatment lifted from HO 287's .v2f-id: bordered --accent-amber, 11px/600, 2px
// radius. Used on every NON-chamber id surface (dashboard feed, weekly band,
// hearings, sponsor card). The chamber-tinted BillIdRail/.bill-chip are a
// deliberate separate system (HO 125 — chamber-of-origin) and do NOT use this.
export function BillIdChip({
  billType,
  billNumber,
  href,
  title,
  className,
}: {
  billType: string;
  billNumber: number;
  href: string;
  title?: string;
  className?: string;
}) {
  return (
    <Link
      href={href}
      className={`bill-id-chip${className ? ` ${className}` : ""}`}
      title={title ?? BILL_TYPE_LABELS[billType]}
    >
      {formatBillId(billType, billNumber)}
    </Link>
  );
}
```

### 2. Repoint — the clear set (all four carry only color, no layout, so the swap is safe)

- **`V2FeedList.tsx`** (`.v2f-id`, ~L196) → `<BillIdChip billType={…} billNumber={…} href={`/bill/${bill.id}`} />`. Remove the `.v2f-id` CSS once its only consumer is gone.
- **`WeeklyBand.tsx`** (`.weekly-band-id` links, ~L211) → `BillIdChip`. **Keep the `.weekly-band-id--more` `+N` link as-is** (it's a muted "more" affordance, not a bill id — leave `.weekly-band-id` + `--more` CSS for it). The id links sit in `.weekly-band-ids` (an inline-flex wrap) — the chip's `flex: none` fits.
- **`HearingRow.tsx`** (`.hearing-bill-line .bill-id`, ~L106) → `BillIdChip`. Remove that CSS rule after.
- **`HearingsCalendar.tsx`** (`.hcal-card-billid`, ~L216) → `BillIdChip`. Remove that CSS rule after (it had `flex: none`, now in the shared class).

### 3. Assess-and-fold (borderline contexts — use judgment, document what you leave)

- **`SponsorExpandedPanel.tsx`** (~L291): the amber bill link is **14px** today. Folding it to the 11px chip is the intended unification, but the sponsor card has its own type scale — **eyeball this one hardest in live-verify.** If the 11px chip clashes with the card, leave it as amber text and record it as a documented exception in the commit message, not a scope reopen.
- **`.hearing-chip`** (`HearingRow.tsx` ~L234, the compact "shown bills" strip): re-grep it. It's a non-link `formatBillId` chip in the row header. If it reads as a bill-id anchor, fold it onto `.bill-id-chip` (component won't fit — it's not a link; apply the class to the span). If it's deliberately a different compact idiom, leave it and note why.

### 4. Guardrails

- **Do not touch `BillIdRail`, `.bill-rail`, `.bill-chip`, or the `--rail-house`/`--rail-senate` tokens.** Chamber-tint stays (Decision 1).
- Preserve any layout-only classes on repointed elements (none of the four clear ones carry layout — verify at write time; if a surface's Link had positioning utilities, pass them via the `className` prop).
- The residual is accepted by design: dashboard `/` (amber chip) and `/bills` (chamber rail) render the same row type differently — that's the v2-vs-classic surface split, not a bug.

## Commit & verify

One commit, explicit pathspec (`git add` the touched files only — leave the concurrent session's files). Show the diff, wait for approval, ancestry eyeball before push.

```
feat(chips): unify non-chamber bill-id surfaces onto the amber tier-1 chip (HO 466)
```

Prod-verify after deploy: dashboard feed / weekly band / hearings list + calendar / bill-hub hearings render the bordered amber chip (11px, amber border); `/bills` + `/stale` + TOP STALLS still show the chamber-tinted rail/`.bill-chip` (cyan/purple) unchanged; `+N` weekly-band link still muted text; no layout breaks; zero new console errors.
