# HO 537 — the `/amendments` "voted" cut

**Next HO after this: 538 (the doc sweep).** Roadmap pointer currently runs through HO 535; HO 536 was the 535 doc sweep (`7495da4`). Take numbering from `docs/roadmap.md`, never from an on-disk filename.

---

## Why

HO 532/533 closed the `recordedVotes` gap on the bill hub: both chambers now render a tally + party split under each acted amendment on `/bill/[id]`. The corpus surface can't do the same. `/amendments` still describes the whole pillar through `latest_action_text` — 6,788 filed, ~8.6% acted — and has no way to say how many amendments actually drew a recorded floor vote.

That number is the sharper version of the page's own headline. "Acted" includes withdrawn, ruled out of order, and pending. "Voted" is the floor actually deciding something, and it's the last banked payoff of the linkage work you already paid for.

---

## The blocker, stated precisely

`amendment_votes` holds **House links only**. `scripts/sync-amendment-votes.ts` says so in its header: *"Senate needs no walk (votes.question carries the number, HO 530)."*

The Senate link is a **request-time regex parse** inside `getBillAmendmentVotes` — `SENATE_AMDT_Q` against `votes.question`, scoped `congress IN (...)` to the bill's amendments. That's correct and cheap for one bill. It's unusable corpus-wide, because the predicate lives in JavaScript:

- you can't `COUNT` it,
- you can't `EXISTS`-filter a feed on it,
- you can't paginate against it.

So there is no way to build this cut without first resolving the asymmetry.

---

## The call: materialize the Senate links

Make `amendment_votes` the single source of truth for "this amendment drew this roll call," symmetric across chambers.

Three properties make this safe rather than speculative:

1. The Senate parse is **deterministic and already proven** — HO 529 measured 114 SAMDT, 100% resolving to tracked bills. Materializing moves a known-good computation from request-time to sync-time; it invents nothing.
2. It needs **no API calls at all**. Both inputs (`votes`, `amendments`) are already synced, so the link is derivable entirely in-DB. Contrast the House walk, which pays `/actions` GETs and therefore needs the `amendment_vote_walked_at` sentinel.
3. Because it's pure recompute, it can be **rebuilt from scratch idempotently** on every tick. No sentinel, no cursor, no frontier.

Two specific instructions on the recompute:

- Do a **full delete-then-insert scoped to Senate rows**, atomic in one `db.batch(statements, "write")` (the HO 483 precedent). That makes it self-healing against a stale link, and the batch closes the window where a reader would see fewer links.
- Identify Senate rows by **joining `votes.chamber = 'senate'`**, not by `vote_id LIKE 'senate-%'`. The id prefix happens to work, but don't build on an id-format convention when the column exists.

---

## Anti-drift: extract the parse first

After this lands, two mechanisms compute the same Senate link — the new materializer and the live parse still running inside `getBillAmendmentVotes`. If they drift, the bill hub and the aggregate disagree about which amendments were voted, which is exactly the structural incoherence the `NEWS_ARTICLE_KEY_SQL` extraction (HO 515) and the `MISSED_CARVE_EXPR` sharing (HO 535) exist to prevent.

So the regex and its extraction logic move to a **leaf module** that both import. It has to be a leaf (the `lib/median.ts` shape, HO 430) because a `scripts/` entry point can't import `lib/queries.ts` without dragging `next/cache` into it.

---

## Out of scope, deliberately

**Do not rewire `getBillAmendmentVotes` to read the table for the Senate path.** It's a working production surface with a fresh scar — HO 533 shipped a latent 500 there that survived three deploys because every verification landed in the cache-miss window. Leave the live parse in place; the extraction above is what keeps the two honest. Bank the simplification for a later HO.

Also not in scope: the per-member roll-call drill (the who-voted-how expand), and any change to `scripts/verify-deploy.ts`.

---

## STEP 0 — measure before you build

Read-only, committed as `scripts/diagnostic/amendments-voted-cost-537.ts`. This is the HO 461 inline cost gate, not a separate probe HO: the pillar is bills-scale so a blob is unlikely, but three of these queries have never been run corpus-wide and one of them is a correctness gate, not a cost gate.

Report actual numbers for each. **Do not hardcode any figure from this section into the spec or the copy** — every number the page prints must be interpolated live.

1. **Sizing.** `SELECT COUNT(*) FROM votes`, and the size of the subset `chamber='senate' AND question LIKE 'On the Amendment S.Amdt.%'`. This sets the materializer's cost and tells us whether recompute-whole-every-tick stays sane.

2. **The equivalence gate — the one that can fail.** For a sample of at least five bills including `119-hr-1` (Senate vote-a-rama, 13 vote lines today), `119-sconres-7` (the 1,131-amendment magnet), `119-s-2`, `119-hr-8800` (House, 19 tallies), and one zero-vote bill: compute the Senate link set the *materializer* would produce and compare it to the set the *live parse* produces today. They must match exactly, amendment-for-amendment.
   *If the work went wrong, this reads as a non-empty symmetric difference.* A pass is both sets identical and non-empty on the Senate bills. An empty-vs-empty match on every bill is a failed instrument, not a pass — say so if that's what you get.

3. **Corpus voted count, cold.** Distinct amendments with at least one link resolving to an existing `votes` row. Note that the House walk inserts links unconditionally, so a link may point at a not-yet-synced roll call — the count must **INNER JOIN `votes`**, matching the hub's "surface only resolved ones" behavior.

4. **Feed filter, cold, deep page.** `EXISTS (SELECT 1 FROM amendment_votes av WHERE av.amendment_id = a.id)` added to `getAmendments`' WHERE. The composite PK `(amendment_id, vote_id)` should give a leading-column seek with no new index. **EXPLAIN it.** If the planner wanders — this codebase has hit the misplanner class five times (HO 405, 407, 479, 480, 481) — report the plan; don't silently add a hint without saying so.

5. **Containment.** Is voted a strict subset of acted? Count amendments with a resolved vote but `latest_action_text IS NULL`. If that's zero, the three filter chips read as a clean nested drill. If it isn't, the page has to disclose it rather than imply nesting.

6. **Chamber split of the voted set**, and the agreed/failed/other split computed through the existing `deriveDisposition` over `votes.result`.

7. **Tiebreak check.** Any amendment carrying two votes on the *same* `vote_date`? The hub sorts `list[0]` by date alone (`localeCompare`), so a same-date pair makes "the amendment's outcome" nondeterministic between hub and aggregate. If the count is zero, note it as inert and change nothing. If it isn't, align both to the same `(vote_date DESC, id DESC)` ordering.

Bring the numbers back before writing build code.

---

## Commit 1 — data (additive, no read-path change)

New leaf module `lib/amendment-vote-key.ts`: the `SENATE_AMDT_Q` regex plus a small `parseSenateAmendmentNumber(question: string): number | null`. Delete the local const in `lib/queries.ts` and import from here — `getBillAmendmentVotes` behavior must be unchanged.

New `lib/amendment-votes-senate.ts` exporting `materializeSenateAmendmentVotes()`:

- read the SAMDT set (`id`, `congress`, `amendment_number`) and the Senate amendment-question votes,
- match through the shared parser (first number in the question is the voted amendment, even when it amends another amendment),
- one `db.batch` containing the scoped delete (via the `votes.chamber` join) followed by the inserts,
- return a result object in the `WalkResult` idiom: `{ scanned, matched, linksWritten, unmatchedQuestions }`.

`unmatchedQuestions` matters — a Senate amendment question that parses but resolves to no tracked amendment is the signal that the corpus has drifted. Log it, don't throw.

CLI: add a `--senate` mode to `scripts/sync-amendment-votes.ts` (which currently has one mode). Keep `--walk` doing exactly what it does now.

Cron: in `app/api/cron/amendments/route.ts`, run the materializer **before** the House walk, after the existing `revalidateTag("amendments")`. Ordering matters — the materializer is cheap, deterministic, and DB-only, while the walk is network-bound and can hit its sub-deadline; a starved materializer would be a silent staleness bug. Wrap it in the same non-fatal try/catch and fold failures into `chronicErr` exactly as the walk does. Call `revalidateTag("votes")` when `linksWritten > 0`.

Gate on measurement 2 before committing.

---

## Commit 2 — refactor, no visible change

`VoteLine`, `voteVerb`, and `dispositionColor` currently live inside `components/BillAmendments.tsx`, and `components/AmendmentRow.tsx` re-declares `dispositionColor` with a comment explaining the duplication was left alone to avoid touching two working components. The corpus feed is now the third consumer, which is the trigger the backlog banked this on.

Extract to `components/AmendmentVoteLine.tsx`. Both existing components import; no markup or token changes. This is the HO 468 shape — a pure consolidation whose acceptance test is that the rendered output is byte-identical. Verify that on `/bill/119-hr-1` and `/bill/119-hr-8800` before committing, and keep it off the feature commit.

---

## Commit 3 — surface

**`getAmendmentsSummary`** gains a voted block: the distinct voted count, its agreed/failed/other split, and its chamber split. Resolve **one canonical vote per amendment** — the most recent — with a `ROW_NUMBER() OVER (PARTITION BY av.amendment_id ORDER BY v.vote_date DESC, v.id DESC)` subquery, then map the results through the shared `deriveDisposition` in JS. The rule has to be the same "latest vote is the outcome" rule the hub renders via `list[0]`, or the aggregate will print a number the rows contradict on click.

**`getAmendments`** gains `voted` as a third value of the existing `disposition` param (`acted | filed | voted`), applied as the EXISTS predicate. Then hydrate votes for the page's rows only: a bounded join over the ≤25 returned amendment ids, plus the party split over those vote ids — the same two queries `getBillAmendmentVotes` runs at steps 2b and 3, scoped to a page.

Fetch the party split rather than skipping it. `VoteLine` suppresses an all-zero split because that means "member positions haven't synced yet" (HO 533); if we simply didn't fetch it, the component would render the not-fetched case identically to the not-yet-synced case and quietly lie.

Attach as `votes: AmendmentVote[]` on `AmendmentListRow`, empty for the ~99%. `AmendmentVote` is plain objects, numbers and strings, so it round-trips through `unstable_cache` cleanly — **no Map, Set, Date, or class anywhere in a cached return**, per the HO 533 rule.

**The page.** Leave the existing four-segment status bar alone; it sums to total and is coherent. Add a separate recorded-votes readout beneath it carrying the voted count, its agreed/failed split from `votes.result` (authoritative, not the keyword scan), and the chamber split. Add a `Voted` chip beside `Acted` and `Filed-only`. Let measurement 6 set the blurb copy — if the Senate/House asymmetry is as lopsided as HO 461 found for filings, that contrast is the finding and it should be stated plainly, interpolated live.

**`AmendmentRow`** renders the shared `VoteLine` when the row carries a vote, absent otherwise. Same omit-don't-disclose treatment as the hub.

---

## Verification

Verify on the **cache-hit path, not the post-deploy miss** — hit each surface two or three times, or wait out the revalidate window. This is the single most expensive lesson in the repo's history: HO 533's 500 shipped three times because every check landed in the miss window right after a deploy.

Then confirm:

- `/amendments` unfiltered renders the voted readout, numbers matching the Step 0 figures,
- `?disposition=voted` returns the measured count and every row shows a vote line,
- `?disposition=acted` and `?disposition=filed` return exactly what they returned before,
- `?disposition=voted&type=HAMDT` and `&type=SAMDT` split to the measured chamber numbers,
- a deep `?page=` inside the voted filter returns 200 (bounded feed, no tail 500),
- `/bill/119-hr-1` and `/bill/119-hr-8800` are unchanged — same tally and split counts as before this HO,
- `npm run typecheck` clean, `verify:deploy` serves HEAD.

---

## Constraints

Explicit pathspec staging only, never `git add .`. Show the diff and wait for approval before each commit. The three commits stay separate — refactor and feature must not ride together. Nothing touches `SKILL.md` in this HO; if that changes, use the review-ref route (push to `refs/heads/537-review`, wait for the diff to be read and approved, then fast-forward main and delete the ref).

Report back with the Step 0 numbers first, then per-commit diffs.
