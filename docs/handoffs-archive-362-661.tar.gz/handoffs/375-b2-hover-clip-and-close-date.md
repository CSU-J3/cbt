# HO 375 — B2 hover: clip fix + odds close date

Two hover fixes. Clipping is a live positioning bug — universal, ships first as its own commit. Close date is the deferred odds enrichment from HO 374, now wanted, gated on the date already being in the fetch.

## Part 1 — Clipping (ship first, independent commit)

**Symptom.** The hover card runs off the viewport at the tape ends (left edge for leading items, right edge for trailing) and tucks under the sticky masthead.

**Cause.** The card renders inside the marquee's transformed, overflow-hidden track, so it's both clipped by the container and dragged by the `translateX`.

**Fix.** Portal the card to `body`, position it from the anchored item's bounding rect (fixed), clamp all four edges to the viewport with a small margin, and keep it clear of the sticky masthead (offset below the tape row). This is the HO 309 / 310 popover-overflow pattern — reuse it, don't reinvent.

**Verify.** Hover the first item (near left edge), the last item (near right edge), and an item mid-scroll: card fully on-screen each time, not clipped, not under the masthead. Both markets and odds cards.

**Ship.** Commit (named `git add`), push, `verify:deploy` SHA === HEAD, stylesheet loads. Then start Part 2.

## Part 2 — Close date on odds hover (gated)

Show when the bet closes on each odds card.

**Source check first.** In `lib/markets.ts`, is Kalshi `close_time` (the event/market object from discovery) and Polymarket `endDate` already on the fetched object for each odds symbol? Print the field name + a sample value per symbol: FEDCUT, FEDCUT-SEP, SHUTDOWN, RECESSION, and the POLY-* halves. FEDCUT's soonest-open discovery already holds the event, so `close_time` is likely in hand — confirm it's actually populated.

**If populated:**
- The render reads `market_ticks` (DB), not live Kalshi, so the date must be persisted for the render query to see it. Write `close_time` / `endDate` per symbol from the cron into a per-symbol store: `market_meta(symbol TEXT PRIMARY KEY, close_at TEXT)` upsert, or an existing config table if one already exists. Per-symbol, **not** a per-tick column — the value's constant until the event rolls, and the cron refreshes it each run so rolls self-correct.
- Expose `closeAt` through the latest-markets query alongside the series.
- Render: **replace** the redundant "prediction market" text in the odds freshness line with `closes <MON DD>`. The sector tag at the top already says PREDICTION MARKET, so this kills a duplication and adds the date in one move. Existing dim token, short date format matching the tape, no new CSS var.
- Graceful: any odds symbol missing a close date shows `Live` with no "closes" clause. Don't block the feature on one gap.

**If not populated / not derivable without a new fetch:** stop, ship Part 1 only, and report what the payload does and doesn't carry so we scope the source separately. Don't add a fetch or hardcode a guessed date.

**Verify.** Each odds card shows the close date Kalshi/Polymarket returns for that event — FED CUT JUL its July FOMC close, FED CUT SEP its September close, SHUTDOWN the funding deadline, RECESSION whatever `close_time` it returns (even if far off). Markets hovers unchanged. Clipping still fixed from Part 1.

**Ship.** Named `git add`, push, `verify:deploy` SHA === HEAD, stylesheet loads.

## Prod verification note (both parts)

Vercel BotID withholds the interactive tape from headless Chrome, so prod headless hover returns 0 symbols — not a regression. Verify prod via served-SHA + stylesheet-class check + `/api/markets/latest` payload + local CDP hover on the matching SHA/DB. Then eyeball the live site manually: hover at both viewport edges (clip fix) and one odds card (close date), since headless can't.
