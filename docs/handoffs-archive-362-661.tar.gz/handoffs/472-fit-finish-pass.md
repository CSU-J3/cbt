# HO 472 — Fit & finish browser pass (audit, findings-only)

The CDP-interaction half the HO 240/379 audits never reached: console errors + clicks/hovers/modals/Esc/expanders/dead-affordances across every live surface, plus the four aggregate surfaces (`/amendments`, `/nominations`, `/lobbying`, `/trades`) that shipped after the HO 379 crawler was written and have never been in the automated console/failed-request sweep. This is the pull the FIT & FINISH ledger's closing paragraph names.

**This is an audit. It produces a findings catalog. It ships zero fixes.** Fixes are follow-on handoffs scoped from what this pass finds — the standard probe-then-build split (434→435, 439→440, 452, 461). Do not fix anything you find. Log it, tag it, move on.

---

## 0. Read first (ground truth before touching anything)

- `e2e/smoke.spec.ts` + `playwright.config.ts` — the HO 379 crawler. You are **extending** this, not rewriting it. It already asserts per-route 200 / zero failed subrequests / zero console errors / zero page errors + screenshots, and carries four targeted interactions (bill expand `.bxp`, race drawer `.rdm-panel` confinement, tape hover, PRESIDENT stage-click). Reuse its `attachCollectors` / `isIgnorableBad` / gate-cookie machinery verbatim.
- `docs/backlog.md` → **FIT & FINISH** section — the severity convention (P1 wrong data · P2 inconsistent/misleading · P3 cosmetic) and the already-logged findings you must **not** re-file (§4 below).
- `SKILL.md` → the design-system + IA rule, so a "dead affordance" is judged against intended behavior, not guessed.
- Re-grep selectors at write time. The ones quoted below are from the committed HO 379 spec and current components, but confirm them live before asserting on them — components move.

---

## 1. Scope — the surfaces and what each one actually does

Deep-audit every route below. For each: capture console + pageerrors in a real browser, drive its interactions, and confirm no dead/broken affordance. The interaction column is what makes each surface non-trivial — a plain 200 is already covered by Part A.

**Home `/`** (live v2 — the swapped-in redesign)
- Bill-row click-to-expand — `useSingleOpenPanel`: only **one** row open at a time, a second click closes the first. Verify the single-open invariant, and that re-click / Esc closes.
- Distributions click-to-filter (HO 320): a STAGE bar / TOPIC tile click rebases to `?stage=` / `?topics=` with an `ActiveFilterStrip`; clicking again or CLEAR resets. Confirm the rebase and the reset.
- Feed-id link (HO 466): the id chip is now a `<Link>` to `/bill/[id]` with `stopPropagation`, so **id-click navigates** but **body-click expands** — verify both paths independently.
- HEARINGS|RACES tabbed box (HO 270/271/470): tab switch works; opening RACES stamps `cbt:racesLastView` and clears the NEW + MOVED badges; per-card NEW/MOVED pips render.
- Hovers (local-only, §3): feed sponsor hover card (`SponsorHoverName`), markets tape 4-part hover box + 7d sparkline + `closes <MON DD>` (HO 294/303/374/375), WeeklyBand per-metric hover cards (`WeeklyBandMetricCard`, HO 365), topic-chip tooltip (HO 316/466).

**`/bills`** — row expand (same shared `BillExpandPanel`, click trigger), filter bar (stage/topic/chamber/sort/q), pagination, NEWS view window toggle (24/72/168/720h), topic chips, sponsor hovers.

**`/bill/[id]`** — sections render and link: Amendments (HO 448), Lobbying (HO 440), Hearings, Summary; sponsor hover; the borderless `TopicTags` holdout.

**`/members`** — two-pane browser (HO 328): the chamber filter drives **both** panes; clicking a committee in the rail scopes the roster. IdeologyStrip dotplot (HO 425) hover (name + dim1 + hub) + click-through; PolarizationOverTime (HO 428) expand toggle (collapsed by default); `MemberTopicBar`.

**`/members/[bioguideId]`** — sections render + link: ideology axis (421), fundraising + by_size split (390/415), trades, votes, committees, News (414), sponsored amendments (450).

**`/electoral`** — the modal-heavy one, explicitly owed:
- Competitive map STATE click → `RaceDistrictModal` (`.rdm-panel`) — the HO 225 drill + HO 236/237 metro panels. **Esc closes it**; confinement (panel box within viewport — the recurring clip bug, already asserted in HO 379 but against the `/races` redirect stub; move it onto `/electoral`).
- Primary timeline band: date-click paints that date's states amber; selections accumulate / drop-on-reclick / CLEAR ALL; hover previews an outline.

**`/race/[id]`** (owed) — NEWS (398), PAC SPENDING FEC deep-links (392/393), rating, roster render + link.

**`/committee/[systemCode]`** (owed) — Hearings embeds, Nominations-referred (459), bill-hub embeds render.

**`/reports/[slug]`** (owed) — report markdown, outcome-verb coloring (360), floor-votes (358), stage ladder (352); linkified bill IDs navigate.

**`/amendments`** (461, never crawled) — status hero, most-amended-bills, top-amenders, filtered feed; deep links `?bill=` / `?disposition=` / `?type=` / `?page=` (bounded feed — deep `?page=20` must not tail-500).

**`/nominations`** (456, never crawled) — disposition strip, agency facet, chips + pagination, `?committee=` filter (bidirectional with committee detail).

**`/lobbying`** (437/442/444/463, never crawled) — issue bars + per-issue `?issue=` drill, TOP FIRMS, BY-CBT-TOPIC crosswalk **click-through** (463: topic bar expands to constituent codes → chip `<Link>` scrolls `#lobby-drill` into view), recent-filings feed. **Expect the `FilingRow` dup-key warning here — it's already logged, see §4.**

**`/trades`** (389, never crawled) — recency feed, most-traded rollup, `?member=` scoping.

**Lighter surfaces** (console + any interaction): `/hearings` (list + Mon–Fri calendar + hearing popovers HO 286; the ● LIVE badge is unexercisable if nothing is live — note, don't force), `/patterns` (PatternBars, Filler Watch toggle), `/stale` (INCLUDE PROCEDURAL toggle), `/search` (tabs + query), `/president` + `/changes` (feed sub-nav), `/news`, `/watchlist` (anonymous = empty/sign-in, not a 500).

**Esc handling** is a standing check on every modal / drawer / popover above.

**Dead-affordance sweep**: per surface, enumerate `<button>`, `<a>`, `[role="button"]`, `<select>` and confirm each does *something* (URL change / DOM mutation / panel open). Flag the inert ones — excluding the known-inert dashboard PAC glance line (HO 393(d), whole-card `<Link>`, deliberately non-linked; do not flag).

---

## 2. Method — two runners, because of two hard constraints

**Part A — extend the prod crawler.** Add the four missing routes to the `ROUTES` array in `e2e/smoke.spec.ts` (`/amendments`, `/nominations`, `/lobbying`, `/trades`) and confirm the redirect stubs still resolve to a 200 target (`/races` + `/primaries` → `/electoral`; `/committees` → `/members`; `/dashboard-v2` → `/`). Runs against prod (the config default) — the crawler's console/failed-request/200 machinery already handles it. `/changes` + `/patterns` are fine on prod (0.25–0.82s at HO 404); leave them.

**Part B/C — a new local interaction suite** (`e2e/fit-finish.spec.ts`), run against a **local server**. Two reasons it can't run headless-on-prod:
- **BotID withholds the markets tape from headless prod** (documented in the HO 379 spec + memory) — every tape-hover and any tape-dependent check finds an empty tape and skips. Run local and the tape renders.
- Hover cards, tooltips, and portaled popovers need a real interactive browser; the headless-prod pass captures none of them.

Run it: `npm run build && npm start`, then `BASE_URL=http://localhost:3000 npx playwright test e2e/fit-finish.spec.ts`. (Local dev `npm run dev` also works; a prod build renders closer to live.)

**Local-server caveat — do NOT file these as findings:** the local server reads the hosted Turso (us-west-2), so `/changes` and `/patterns` may **500 from localhost** purely on DB round-trip latency vs the 10s bound (FIT & FINISH P3 — both 200 on prod from co-located pdx1). So keep `/changes` and `/patterns` **out of the local suite** and rely on the Part A prod crawler for their console/render coverage. Their *interactions* are light (PatternBars, toggles) and low-value to force locally.

**Part C — the May 30 dropdown hunt** lives in the local suite: enumerate every `<select>` / `[role="combobox"]` / `[role="listbox"]` trigger on `/` and exercise each at **desktop (1280×800)** and **mobile (390×844)** viewports. The offending control was never identified and the dashboard's been rebuilt since — so the honest outcome is "confirmed moot" or a caught repro. Report which.

---

## 3. Hover coverage (local suite, the BotID-blocked half)

The hovers that only exist in a real browser and never in the headless-prod pass — assert each renders and (where portaled) sits on-screen:
- Feed sponsor hover card (`SponsorHoverName` → card).
- Markets tape hover: the 4-part box + 7d sparkline + `closes <MON DD>` odds line; confirm it clears the masthead and both viewport edges (the HO 375 clip fix).
- WeeklyBand per-metric hover cards.
- Topic-chip tooltip (the shared Tooltip primitive).
- IdeologyStrip dot hover (name + dim1 + hub).

---

## 4. Known-dormant / already-logged — do NOT re-file as new findings

Re-reporting these as fresh bugs makes the catalog noise. Recognize each; skip it:

1. **`FilingRow` dup-`key` React warning on `/lobbying`** — already logged (FIT & FINISH, HO 463). `FilingRow.tsx` `key={id}` collides when a filing names a bill twice. Expected on `/lobbying`; not new.
2. **Local `/changes` + `/patterns` 500** — Turso latency from localhost, not a prod bug (§2). Never a finding.
3. **`/dashboard-classic` ungated ~16,449 count** — deliberate; dies with the sunset route.
4. **NextAuth `MissingSecret`** — env OPEN LOOP (no `AUTH_SECRET` in env). Server-side log; if it surfaces in console, it's the logged env issue, not a UI bug.
5. **POLY-SHUTDOWN ODDS slot dim `N/A`** — graceful degradation (HO 375), not a bug.
6. **Orphaned CSS / dead queries** (P3 `.hearings-*`, `.mc-fbar-title`, `getMembersRankedCount`, the `getSponsorStates` probe copy) — invisible in a browser; the CSS-cleanup batch owns them.
7. **favicon / manifest / apple-touch 404s** — cosmetic; the crawler already ignores them.
8. **Redirect stubs** resolving to 200 targets — expected, not failures.
9. **Stranded `PrimariesMap` / `RacesMap` / `PrimaryDistrictModal` / `PrimaryScrubber`** — zero live importers, don't render, won't appear in a browser pass. Cleanup is a separate arc.
10. **Empty tape on any headless-prod run** — BotID artifact; it's why Part B/C runs local.

A genuinely *new* console error, a broken interaction, a clipped modal, a missing Esc handler, or an inert affordance **not** on this list is a real finding — log it.

---

## 5. Deliverable

**Findings catalog**, severity-tagged (P1/P2/P3, the FIT & FINISH convention), grouped by surface. For each: what you did, what you saw, the selector/route, and the severity. Propose it as an **append to `docs/backlog.md` FIT & FINISH** (append-only, the ledger's own discipline) and give me the same as a concise summary in chat so we can scope fixes immediately.

**Test artifacts:** the extended `e2e/smoke.spec.ts` (Part A) + the new `e2e/fit-finish.spec.ts` (Part B/C) — reusable substrate (and the future home of the CI-wiring loop's three hardenings, though that's **not** this pass). Screenshots into `test-results/`.

If the audit comes back clean on a surface, say so explicitly — a "checked, no finding" line keeps the catalog legible (the HO 404 "audited and correct" pattern).

---

## 6. Commit boundary

- **No fixes.** Nothing you find gets patched in this pass.
- Show diffs; **do not commit** until I approve them.
- Two commits, both diff-first, kept separate by class: **(1)** the `e2e/` test-infra (crawler routes + interaction spec), **(2)** the `docs/backlog.md` findings append. Test infra and docs don't ride together.
- Explicit pathspec staging only; no globs; ancestry eyeball before any push.
- No SKILL.md or roadmap edits this pass — findings land in the backlog ledger; the roadmap/SKILL sweep, if any, follows once fixes ship.

---

read docs/handoffs/472-fit-finish-pass.md and follow it
