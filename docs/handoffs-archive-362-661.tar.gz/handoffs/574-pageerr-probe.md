# HO 574 — The `pageErr` intermittent: read the artifact before theorising

Confirm the number: the roadmap's pointer runs through **HO 572**; HO 573 was its sweep (`ef0192e` + `259afac`). So this is **574**.

Probe first, one instrumentation commit, then **HALT**. No fix ships in this HO.

## The thing that makes this urgent

`e2e-prod.yml` uploads its report artifact with **`retention-days: 14`**. The failing runs are 2026-07-29 (`schedule`) and the two `deployment_status` reds, so those artifacts expire around **Aug 12**. The collector already recorded what we want — `e2e/smoke.spec.ts:129` does `c.pageErr.push(err.message)` — so **the actual error text was captured at the time and is sitting in an artifact on a clock.**

The reason it isn't already in hand: the log line at `:200` prints only the **count** (`pageErr=${pageErr1.length}`), never the strings. So the run's console output shows `pageErr=1` and nothing else, while the message survives only through the assertion failure output in the HTML report.

**Pull the artifact first.** If it carries the message, there is nothing to reproduce and this probe is over in ten minutes. Trying to trigger a once-a-day intermittent locally when the answer may already be on disk is the expensive path taken for no reason.

---

## STEP 0(a) — pull the artifacts, read the error

```
gh run list --workflow=e2e-prod.yml --limit 30 \
  --json databaseId,event,conclusion,createdAt \
  --jq '.[] | select(.conclusion=="failure")'

gh run download <run-id> -n playwright-report -D /tmp/ho574-<run-id>
```

Do this for **all three** failed runs (the 07-29 `schedule` and both `deployment_status` reds), not just the newest. Three samples of an intermittent is the difference between "an error" and "the error" — if the message is identical across all three, that's a single cause; if they differ, the finding is bigger than one bug.

Report, verbatim: the error **message**, the **stack** if the report carries one, which **route** and which **hit** (1 or 2 — the HO 548 cache-miss vs cache-hit distinction may itself be the tell), and whether it reproduced across retries within the same run.

If the artifacts have expired or don't carry the strings, say so plainly and fall through to (b). Do not guess at the message.

## STEP 0(b) — only if the artifacts don't answer it

### The structural observation to start from

The two observed failing URLs are `/` and `/?stage=other_chamber`. Check this rather than trusting it: `ROUTES` (`smoke.spec.ts:56-58`) crawls `/` plus six `...STAGES.map` variants, and **those seven are exactly the tape-bearing routes** — `DashboardV2Header:147-148` mounts `<MarketsTape>` and it's the `/` header; `HomeHeader`'s tape belongs to `/dashboard-classic`, which isn't crawled; HO 323/326 stripped the tape from every inner page.

So **every observed failure falls inside the tape-bearing set, and nothing outside it has been seen to fail.** That's a real signal of the same kind the HO 563 contiguous-districts and HO 566 deficit-shape findings were.

**State the confound in the report rather than letting it hide:** `/` and its variants are also the heaviest pages with the most client islands, so "tape-bearing" and "most client islands" are perfectly confounded on the current evidence. The observation narrows the search; it does not identify the component.

### Two named hypotheses, ranked, both testable

**H1 — a client island throwing on an empty tape payload under BotID.** SKILL records that prod withholds the tape from headless Chrome (0 items) — a condition that exists *only* where this crawl runs, which is exactly why manual browsing never shows it, and which would be intermittent if BotID challenges some runs and not others. If `MarketsTapeClient` (or something downstream of it) assumes a non-empty payload, this is the whole story. **Test:** force an empty/withheld payload locally against a prod build and see whether an uncaught error fires. Cheap and decisive in one direction.

**H2 — a hydration mismatch from time-derived render inputs.** The dashboard computes from `Date.now()` in several places (the HO 183 cycling stamp, relative ages, the hearings 3h `watchState` window), and an SSR-vs-client mismatch fires only when a render straddles a boundary — which is the shape of "sometimes recovers on retry #1." **Note what's already ruled out:** the HO 473 multi-child SVG `<title>` class is falsified (all four sites carry a single template-literal child at `290e239`), so if it is hydration, it's a **new** cause, not that one. Don't let "hydration" slide back into "#418 as previously fixed."

If H1 lands, stop. If it doesn't, report and HALT — don't start on H2's fix.

### If it can't be reproduced at all

**Say so, and stop.** A probe that can't trigger the failure will otherwise produce a confident story from a clean run, which is worse than no story because it gets believed. An unreproduced intermittent with C1 shipped is a perfectly good outcome for this HO — the next occurrence self-diagnoses.

---

## C1 — print the messages, not just the count (unconditional)

Ships regardless of what STEP 0 finds, because it's the instrument that makes the next occurrence readable without an artifact download inside a 14-day window.

`e2e/smoke.spec.ts:200` (and its hit-2 counterpart) logs counts only. Make the line carry the **messages** when the arrays are non-empty, keeping the counts. Same for `consoleErr` and `bad` if it falls out naturally, but `pageErr` is the one that matters.

Two things to respect:

- `attachCollectors` / `logClean` / `assertClean` / `settle` are **shared with `e2e/fit-finish.spec.ts`** (it imports them). One edit, two consumers — confirm both still pass rather than assuming.
- Keep it bounded. An uncaught error can carry a long stack; truncate per message so a noisy run doesn't produce an unreadable log. The point is a readable first line, not a full dump.

Commit: `test(e2e): HO 574 — log pageErr/console messages, not just counts`

## HALT

After C1 and the STEP 0 report, **stop**. Whatever the cause turns out to be, the fix is scoped separately:

- It's in **shared dashboard chrome**, the highest-blast-radius surface in the app.
- If it's H1, the fix is an empty-payload guard, and the question of *which* component owns that guard is a design call, not a patch.
- If it's H2, a hydration fix touching time-derived rendering has a real chance of changing what every dashboard surface displays.

Neither is improvised at the end of a probe. Report and wait.

## Scope guards

1. **No fix.** Not a one-liner, not "while I was in there." The instrumentation commit is the only code that lands.
2. `e2e/smoke.spec.ts` only. No `app/`, no `components/`, no `.yml`.
3. No `docs/` edits, no `SKILL.md` — HO 575 sweeps.
4. Don't wire `fit-finish.spec.ts` into any workflow. Still a separate open decision, and this finding is the argument for not doing it yet.
5. Don't re-run the crawl repeatedly against prod to farm a reproduction. The existing WATCH already notes the doubled crawl halved the politeness headroom; hammering prod to catch an intermittent is the wrong instrument.

## Verification

- `npx playwright test e2e/smoke.spec.ts` and `e2e/fit-finish.spec.ts` both still pass locally (fit-finish was 41/0 at HO 572).
- The new log line renders readably on a **forced** non-empty case — inject a throw in a scratch page to confirm the message actually prints, then revert. **This is the HO 549/553 falsification rule:** don't record a logging change as working because the arrays happened to be empty. Scratch only, revert, `git status` clean, commit nothing from it.
- Ship: `git push` (fast-forward, ancestry eyeball first). No `verify:deploy` owed — the spec isn't part of the deployed app.

## Ship report

- **STEP 0(a):** the verbatim message(s) from each of the three failed runs, whether they match, and which route/hit each fired on. Or a clear statement that the artifacts were gone or didn't carry them.
- **STEP 0(b)** if reached: whether the tape-bearing observation holds against `ROUTES`, and the H1 result. Reproduced or not — say which, and don't narrate a cause you didn't trigger.
- **C1:** SHA, and the falsification transcript for the log line.
- Your read on which hypothesis the evidence supports, stated as a read with its confidence, not as a conclusion.
- Anything else found — file it, don't fix it.
