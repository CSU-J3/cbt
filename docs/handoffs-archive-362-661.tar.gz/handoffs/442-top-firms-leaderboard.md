# HO 442 — Corpus-wide top-firms leaderboard (`/lobbying`)

Ships the banked "corpus-wide top-firms leaderboard" (banked in the HO 437 block, re-banked
in the HO 439–440 block). Ranks the lobbying shops (LDA **registrants**) by distinct-filing
volume, served O(1) from a new precomputed blob, rendered as a section on `/lobbying`.

## Why there's no probe step

This is a **build HO, not a probe HO.** Every other new `lda_*` surface got a cost probe first
(HO 434→435, HO 439→440) because it introduced a new cold query over the 108k/233k-row tables.
This one doesn't. The leaderboard is a **third consumer of the existing `readLdaTables` pass** —
the same ~96s sequential read the cron already runs to feed `computeIssueRollup` +
`computeBillDrill`. `computeTopFirms` adds one in-memory grouping pass over the already-loaded
`filings` map; there is no new query to time and no live path. This is the exact "piggyback the
pass, near-free" case HO 440 established. The read on `/lobbying` is an O(1) blob parse like the
other two.

## Ground truth first (do this before writing anything)

Per SKILL discipline: clone the live repo, don't trust these line numbers — they drift. HEAD at
handoff authoring was `1bfc749` (the HO 441 doc sweep closing the bill-keyed lobbying arc). The
architecture you're extending:

- `lib/lda-rollup.ts` — `readLdaTables(db)` returns `LdaTables` (one sequential read of all three
  tables). It already carries everything this feature needs: `filings: Map<uuid, FilingRec>` where
  `FilingRec` has `registrantName` + `clientName`, plus `codesByUuid`, `linkedUuids`,
  `displayByCode`. Two consumers exist today: `computeIssueRollup` and `computeBillDrill`, each
  writing its own `dashboard_state` blob (`LDA_ROLLUP_KEY`, `LDA_BILL_DRILL_KEY`).
- `app/api/cron/lda/route.ts` — inside the budget-gated `if (msLeft >= ROLLUP_RESERVE_MS)` block,
  the cron does `readLdaTables` **once** and feeds both computes, both under a single
  `revalidateTag("lda")`. This is where the third write slots in.
- `scripts/rollup-lda.ts` — the `npm run lda:rollup` local-regen path. It writes the same blobs
  the cron does. Re-grep it; add the firms write in the same sequence so local regen stays
  complete.
- `lib/queries.ts` — `getLobbyingRollup` / `getBillDrillBlob` are the O(1) blob getters
  (`unstable_cache`, `revalidate: 3600`, `tags: ["lda"]`). The new getter mirrors them exactly. It
  also re-exports the lda-rollup types (that's how `IssueDrill`/`FilingSummary`/`BillDrill` reach
  components via `@/lib/queries`).
- `app/lobbying/page.tsx` — the surface. Sections today: (1) readout, (2) two-column issue bars +
  drill, (3) recent-filings feed. The leaderboard becomes the new **Section 3**, pushing the feed
  to Section 4.
- `components/LobbyingMiniBars.tsx` — the amber-bar ranked-list idiom to match (amber at 0.55
  opacity over `--bg-row-hover`, `tabular-nums` counts, 0.5px borders).

## Decisions locked (do not reintroduce these in plan mode)

- **"Firm" = registrant** (`registrant_name`, the lobbying shop) — consistent with `topFirms`
  everywhere else on the surface.
- **Rank by distinct filings**, name-tiebroken (the HO 435 house rule). One filing = one distinct
  filing, same as the issue drill / bill drill.
- **No dollar column.** LD-2 income/expenses are partial and income-vs-expense asymmetric across
  registrant types; a summed-dollar ranking would mislead. Dollars are the banked **LD-203 money
  surface**, out of scope here. (Per-filing income on `FilingRow` is unrelated and stays.)
- **Native `general_issue_code` labels**, NOT crosswalked to the 24 CBT topics. The CBT-topic
  crosswalk is the *other* banked HO 442 item — do not touch it.
- **Top 25.** One constant `TOP_FIRMS_N`. Store 25, render 25 (no stored-vs-shown split).
- **Separate blob** (`lda_top_firms`) — keeps the 286KB `/lobbying` rollup read lean (the HO 440
  rationale). Rides the existing `revalidateTag("lda")`, no new tag.
- **No migration** (new `dashboard_state` key, table exists). **No new cron slot** (rides the LDA
  cron). **No new nav item** (a cut of Lobbying, not a peer pillar).

---

## Commit 1 — data layer + cron/CLI wiring

### 1a. `lib/lda-rollup.ts` — add the blob key, constant, interfaces, compute, write

Add near the other `LDA_*_KEY` exports:

```ts
export const LDA_TOP_FIRMS_KEY = "lda_top_firms";
// Top N lobbying shops (registrants) by distinct filings. Store == render (no
// stored-vs-shown split); bump here to widen the leaderboard.
export const TOP_FIRMS_N = 25;

export interface TopFirm {
  name: string;                    // registrant_name (the lobbying shop)
  filings: number;                 // distinct filings (rank metric — HO 435 rule)
  clients: number;                 // distinct clients represented
  billLinked: number;              // distinct filings citing >=1 resolved tracked bill
  topIssueCode: string | null;     // their single most-cited general_issue_code
  topIssueDisplay: string | null;  // its display label
}
export interface TopFirmsBlob {
  generatedAt: string;
  totalRegistrants: number;        // for the honest "top N of M registrants" label
  firms: TopFirm[];
}
```

Add the compute + write (piggybacks the shared `LdaTables`, same as `computeBillDrill`):

```ts
// HO 442 — the corpus-wide top-firms leaderboard, computed from the SAME LdaTables
// the issue rollup + bill drill read (third consumer of the ~96s pass; pure
// in-memory grouping, no new scan/query). Ranks REGISTRANTS (the lobbying shops)
// by DISTINCT filings (the HO 435 rule), name-tiebroken. Per firm: distinct
// clients, bill-linked filing count, and their single most-cited issue code.
// Dollars are deliberately NOT ranked here (LD-2 income/expenses are partial +
// income-vs-expense asymmetric across registrant types; the money surface is the
// banked LD-203 work).
export function computeTopFirms(
  tables: LdaTables,
  generatedAt: string,
  n: number = TOP_FIRMS_N,
): TopFirmsBlob {
  const { filings, codesByUuid, linkedUuids, displayByCode } = tables;

  type Acc = {
    filings: number;
    clients: Set<string>;
    billLinked: number;
    codeTally: Map<string, number>;
  };
  const byFirm = new Map<string, Acc>();

  for (const [uuid, f] of filings) {
    if (!f.registrantName) continue;
    let acc = byFirm.get(f.registrantName);
    if (!acc) {
      acc = { filings: 0, clients: new Set(), billLinked: 0, codeTally: new Map() };
      byFirm.set(f.registrantName, acc);
    }
    acc.filings++;
    if (f.clientName) acc.clients.add(f.clientName);
    if (linkedUuids.has(uuid)) acc.billLinked++;
    for (const code of codesByUuid.get(uuid) ?? []) {
      acc.codeTally.set(code, (acc.codeTally.get(code) ?? 0) + 1);
    }
  }

  const firms: TopFirm[] = [...byFirm.entries()]
    .sort((a, b) => b[1].filings - a[1].filings || a[0].localeCompare(b[0]))
    .slice(0, n)
    .map(([name, acc]) => {
      // single most-cited issue code, count-desc then code-asc (deterministic)
      let topIssueCode: string | null = null;
      let best = -1;
      for (const [code, c] of acc.codeTally) {
        if (c > best || (c === best && (topIssueCode === null || code < topIssueCode))) {
          best = c;
          topIssueCode = code;
        }
      }
      return {
        name,
        filings: acc.filings,
        clients: acc.clients.size,
        billLinked: acc.billLinked,
        topIssueCode,
        topIssueDisplay: topIssueCode
          ? (displayByCode.get(topIssueCode) ?? topIssueCode)
          : null,
      };
    });

  return { generatedAt, totalRegistrants: byFirm.size, firms };
}

export async function writeLdaTopFirms(
  db: Client,
  blob: TopFirmsBlob,
): Promise<void> {
  await db.execute({
    sql: `INSERT INTO dashboard_state (key, value, updated_at)
          VALUES (?, ?, ?)
          ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`,
    args: [LDA_TOP_FIRMS_KEY, JSON.stringify(blob), blob.generatedAt],
  });
}
```

### 1b. `lib/queries.ts` — the getter + type re-exports

Add `LDA_TOP_FIRMS_KEY` and `TopFirmsBlob` (and `TopFirm` if the surface imports it from
`@/lib/queries` — follow the existing lda-rollup re-export pattern) to the import block from
`@/lib/lda-rollup`. Add the getter, byte-mirroring `getLobbyingRollup`:

```ts
// PRECOMPUTED into dashboard_state by the LDA cron / `npm run lda:rollup` — an
// O(1) blob parse, NOT a request-time aggregate. Separate key from the /lobbying
// rollup so this small blob is the only thing the leaderboard section reads.
// null before the first rollup lands (section omitted). Tag "lda" flushed by the
// cron; 1h TTL fallback.
export const getTopFirms = unstable_cache(
  async (): Promise<TopFirmsBlob | null> => {
    const db = getDb();
    const rs = await db.execute({
      sql: "SELECT value FROM dashboard_state WHERE key = ? LIMIT 1",
      args: [LDA_TOP_FIRMS_KEY],
    });
    const raw = rs.rows[0]?.value as string | undefined;
    if (!raw) return null;
    try {
      return JSON.parse(raw) as TopFirmsBlob;
    } catch {
      return null;
    }
  },
  ["getTopFirms"],
  { revalidate: 3600, tags: ["lda"] },
);
```

### 1c. `app/api/cron/lda/route.ts` — third write in the shared block

Add `computeTopFirms, writeLdaTopFirms` to the `@/lib/lda-rollup` import. Inside the existing
`if (msLeft >= ROLLUP_RESERVE_MS)` try block, right after `await writeLdaBillDrill(client, billBlob);`:

```ts
const firmsBlob = computeTopFirms(tables, generatedAt);
await writeLdaTopFirms(client, firmsBlob);
```

Extend the log line and the `rollup` summary object with `topFirms: firmsBlob.firms.length` so the
count surfaces in `cron_runs` (match the existing `billDrills` field's treatment). No new tag — the
firms blob rides the single `revalidateTag("lda")` already there.

### 1d. `scripts/rollup-lda.ts` — mirror it locally

Re-grep this script for where it writes the rollup + bill-drill blobs (mirrors the cron). Add the
`computeTopFirms(tables, generatedAt)` + `writeLdaTopFirms(client, firmsBlob)` call in the same
sequence, so `npm run lda:rollup` regenerates all three blobs. Print the firm count in its summary
log.

**Commit 1 verification before staging:** `npx tsc --noEmit` clean; `npm run lda:rollup` locally
writes the blob and prints ~25 firms / totalRegistrants ≈ 5,165. Spot-check the JSON: rank-1 firm
is a recognizable big shop (Akin Gump / Brownstein Hyatt / etc.), `billLinked <= filings` for every
row, `topIssueCode` populated.

---

## Commit 2 — the surface

### 2a. `components/FirmsLeaderboard.tsx` (new)

A dense ranked table. Grid template / exact classes below are a **starting point** — reconcile with
the live design system and check the mobile viewport (CBT has mobile foundations, HO 156/157/161):
under ~640px the six-column grid will overflow, so either collapse the lower-priority columns
(Top issue, Bill-linked) or let the block scroll, matching how the nearest existing table degrades.

```tsx
import type { TopFirm } from "@/lib/queries";

// HO 442 — the corpus-wide TOP FIRMS leaderboard section on /lobbying. Ranks the
// lobbying shops (registrants) by distinct filings, served O(1) from the
// lda_top_firms blob. Amber filings bar (same treatment as LobbyingMiniBars),
// distinct clients, their top issue area, and how many of their filings cite a
// tracked bill. Server component, inline-styled.
const COLS = "24px minmax(0,1fr) 150px 64px minmax(0,120px) 64px";

export function FirmsLeaderboard({
  firms,
  totalRegistrants,
}: {
  firms: TopFirm[];
  totalRegistrants: number;
}) {
  if (firms.length === 0) return null;
  const max = Math.max(1, ...firms.map((f) => f.filings));
  return (
    <section className="mt-6">
      <div className="mb-2 flex flex-wrap items-baseline gap-2">
        <h2
          className="text-[12px] uppercase tracking-[0.5px]"
          style={{ color: "var(--text-secondary)" }}
        >
          Top firms · by filing volume
        </h2>
        <span
          className="text-[11px] uppercase tracking-[0.5px] tabular-nums"
          style={{ color: "var(--text-dim)" }}
        >
          top {firms.length} of {totalRegistrants.toLocaleString()} registrants
        </span>
      </div>
      <div className="border" style={{ borderColor: "var(--border-strong)" }}>
        <div
          className="grid items-center gap-2 px-[14px] py-2 text-[10px] uppercase tracking-[0.5px]"
          style={{
            gridTemplateColumns: COLS,
            color: "var(--text-dim)",
            borderBottom: "0.5px solid var(--border-strong)",
          }}
        >
          <span className="text-right">#</span>
          <span>Firm</span>
          <span>Filings</span>
          <span className="text-right">Clients</span>
          <span>Top issue</span>
          <span className="text-right">Bill-linked</span>
        </div>
        {firms.map((f, i) => (
          <div
            key={f.name}
            className="grid items-center gap-2 px-[14px] py-[7px]"
            style={{
              gridTemplateColumns: COLS,
              borderTop: i === 0 ? undefined : "0.5px solid var(--border-soft)",
            }}
          >
            <span
              className="text-right text-[12px] tabular-nums"
              style={{ color: "var(--text-dim)" }}
            >
              {i + 1}
            </span>
            <span
              className="truncate text-[12px]"
              style={{ color: "var(--text-secondary)" }}
              title={f.name}
            >
              {f.name}
            </span>
            <span
              className="grid items-center gap-2"
              style={{ gridTemplateColumns: "minmax(0,1fr) 40px" }}
            >
              <span
                className="block h-[8px] overflow-hidden rounded-[2px]"
                style={{ backgroundColor: "var(--bg-row-hover)" }}
                aria-hidden
              >
                <span
                  className="block h-full rounded-[2px]"
                  style={{
                    width: `${(f.filings / max) * 100}%`,
                    backgroundColor: "var(--accent-amber)",
                    opacity: 0.55,
                  }}
                />
              </span>
              <span
                className="text-right text-[12px] tabular-nums"
                style={{ color: "var(--text-muted)" }}
              >
                {f.filings.toLocaleString()}
              </span>
            </span>
            <span
              className="text-right text-[12px] tabular-nums"
              style={{ color: "var(--text-muted)" }}
            >
              {f.clients.toLocaleString()}
            </span>
            <span
              className="truncate text-[12px]"
              style={{ color: "var(--text-muted)" }}
              title={f.topIssueDisplay ?? ""}
            >
              {f.topIssueCode ? (
                <>
                  <span style={{ color: "var(--accent-amber)" }}>{f.topIssueCode}</span>{" "}
                  <span style={{ color: "var(--text-dim)" }}>{f.topIssueDisplay}</span>
                </>
              ) : (
                <span style={{ color: "var(--text-dim)" }}>—</span>
              )}
            </span>
            <span
              className="text-right text-[12px] tabular-nums"
              style={{ color: "var(--text-muted)" }}
            >
              {f.billLinked.toLocaleString()}
            </span>
          </div>
        ))}
      </div>
    </section>
  );
}
```

### 2b. `app/lobbying/page.tsx` — fetch + place the section

- Import `FirmsLeaderboard` and `getTopFirms`.
- Fetch alongside the rollup at the top: `const [rollup, topFirms] = await Promise.all([getLobbyingRollup(), getTopFirms()]);`
  (the `getRecentFilings` feed call stays where it is — it depends on `rollup.stats` to clamp the
  pager). The existing null-guard on `rollup` already covers the pre-first-cron case (both blobs are
  null together).
- Insert the section **between the two-column drill (Section 2) and the recent-filings feed**, guarded:

```tsx
{topFirms?.firms.length ? (
  <FirmsLeaderboard
    firms={topFirms.firms}
    totalRegistrants={topFirms.totalRegistrants}
  />
) : null}
```

- Update the recent-filings section's `{/* Section 3 — ... */}` comment to Section 4.

**Commit 2 verification:** `npx tsc --noEmit` clean; `/lobbying` renders the TOP FIRMS section
between the drill and the feed; rank-1 bar is full; clients/bill-linked columns populated;
`billLinked <= filings` visually holds. Before the first rollup (or if the blob is missing) the
section is cleanly omitted.

---

## Discipline (SKILL)

- **Plan mode first, then diffs, then wait for approval. No auto-commit / no push** until Corey
  approves the diff. (Global rule.)
- **Two commits**, in order: (1) data layer + cron/CLI wiring, (2) the surface — mirroring HO 440's
  `ab1505a` (data+cron) / `9a540b2` (surface) split.
- **Do NOT touch `docs/roadmap.md` or `SKILL.md`.** The roadmap append (a new "Also (HO 442)" block
  + Banked-line prune) and any SKILL note are a **follow-up doc-sweep HO**, not this one.
- Immediately-before-push ancestry eyeball (one commit riding, clean fast-forward, concurrent
  session's files untouched). Stage by explicit pathspec.
- No migration, no new cron slot, no new nav item.

## Prod check (after deploy)

Trigger the LDA cron (or wait for the 08:00 UTC tick): `curl -H "Authorization: Bearer $CRON_SECRET"
https://cbt-chi-silk.vercel.app/api/cron/lda`. Confirm the log shows the `topFirms` count, then load
`/lobbying` and confirm the section populated with real data.

read docs/handoffs/442-top-firms-leaderboard.md and follow it
