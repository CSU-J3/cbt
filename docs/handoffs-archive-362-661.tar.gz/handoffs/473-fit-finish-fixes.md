# HO 473 — Fit & finish fixes (the three HO 472 findings)

Lands on `929e34d`. Fixes the two P2s + the P3 Esc gap from the HO 472 audit; flips the harness from 3-red to green. #4 stays banked. Three commits, one per fix, each flipping its own red assertion — that per-commit test flip is the verification.

Re-grep every line/number below at write time. They're from a fresh clone at HEAD, but confirm before editing.

---

## Fix 1 — SVG `<title>` hydration (#418), as a class (P2)

Adjacent JSX children inside an SVG `<title>` emit SSR segment markers the SVG-namespace text parse drops, so React regenerates the subtree client-side → uncaught #418. Four sites carry the idiom. Collapse each to a **single template-literal child**. The already-correct form is `components/PrimaryTimeline.tsx:145` — match it.

- `components/CommitteeActivityChart.tsx:145` — `{formatMonthLabel(month)} · {bucket} · {value}` → one `{`…`}` child. **This is the confirmed thrower** (fired on every `/committee/[systemCode]`).
- `components/BillsTimeSeries.tsx:123` — `{formatMonthLabel(month)} · {topicLabel(topic)} · {value}` → one child. Latent on `/trends`, same idiom.
- `components/PrimaryDistrictModal.tsx:163` — `{d.cd}{has ? … : ""}` → one child.
- `components/RaceDistrictModal.tsx:140` — `{d.cd}{comp ? ` · ${contest.rating}` : ""}` → one child.

The two modals render client-only, so they don't throw #418 today — they're latent, fixed for class-consistency, and their tooltip text is **byte-identical** after the collapse (no behavior change, no test moves from them). If a nested template literal reads poorly in the two conditional cases, hoist the label to a `const` above the element — single-child is the only requirement.

**Do NOT allowlist #418** in the spec's console filter (`e2e/fit-finish.spec.ts:40–44` allows favicon / MissingSecret / FilingRow-dup-key / DevTools / Fast-Refresh — leave that set alone). The source fix is the fix; masking it defeats the audit.

**Verify:** re-run the committee route (crawler + local) and `/trends` — zero un-allowlisted console errors, no #418.

**Confirm the class is closed:** `grep -rn "<title>" components app` and eyeball that every remaining `<title>` is a single child (only `PrimaryTimeline` and the four you just fixed should exist).

---

## Fix 2 — `/lobbying` pagination drops `?issue=` (P2)

`app/lobbying/page.tsx:203` passes `carry={new URLSearchParams()}` — empty — so NEXT on `/lobbying?issue=HCR` builds `/lobbying?page=2` and the drill resets to the top issue. `/amendments:313` and `/nominations:234` pass a populated `carry`; match that.

Build a carry that preserves the explicit selection and hand it to `<Pagination>`:

```ts
const carry = new URLSearchParams();
if (params.issue) carry.set("issue", params.issue);
```

Carry `params.issue` (the raw URL param), not `selected` — `selected` defaults to `issues[0].code` when the param is absent, and you don't want pagination to *inject* `?issue=` on the unfiltered feed, only to preserve one the user chose. `Pagination.buildHref` already deletes `page` on page 1 and drops `expanded`, so `issue` + `page` compose cleanly.

**Verify:** `e2e/fit-finish.spec.ts:470` (`/lobbying: pagination preserves the selected ?issue=`) — the `:484` soft-assert goes green.

---

## Fix 3 — Esc doesn't close an expanded feed row (P3)

`components/useSingleOpenPanel.ts` has no keydown handler, so single-open + re-click work but Esc doesn't — while the electoral district modal *does* close on Esc (`fit-finish.spec.ts:304/329` passes). Close the inconsistency at the hook, so all four consumers (`BillRowList`, `TopStallsList`, `V2FeedList`, `CompetitiveRacesStrip`) inherit it:

```ts
useEffect(() => {
  if (expandedId === null) return;
  const onKey = (e: KeyboardEvent) => {
    if (e.key === "Escape") setExpandedId(null);
  };
  window.addEventListener("keydown", onKey);
  return () => window.removeEventListener("keydown", onKey);
}, [expandedId]);
```

Add `useEffect` to the `react` import. Guard on `expandedId === null` so no listener is attached when nothing's open. The setter is already in scope.

**Verify:** `fit-finish.spec.ts:96` (`feed row expand: single-open invariant + re-click + Esc close`) — the `:122` soft-assert goes green. Confirm the district-modal Esc test (`:329`) still passes (independent handler, untouched).

---

## #4 — banked, do NOT build

The amendments status hero being a non-interactive readout while nominations' strip filters is a documented P3 consistency nit. The chips already cover amendments' filtering; making the hero interactive touches a working component for cosmetics. Leave it as the FIT & FINISH P3.

---

## Commits — three, diff-first, on `929e34d`

One fix per commit, each independently flipping its finding's assertion (the point of the split — clean per-fix revertability + a visible red→green per commit):

1. `fix(charts): collapse multi-child SVG <title> to single child (HO 473)` — the four component files. Committee + trends #418 clears.
2. `fix(lobbying): preserve ?issue= across pagination (HO 473)` — `app/lobbying/page.tsx`. `:484` flips.
3. `fix(feed): Esc closes an expanded row via useSingleOpenPanel (HO 473)` — `components/useSingleOpenPanel.ts`. `:122` flips.

Promote the two `expect.soft` FINDING-CHECK assertions (`:122`, `:484`) to hard `expect(...)` and drop their "if it fails → finding" comments **in the same respective commit** — a now-guaranteed behavior should hard-assert, and the change belongs with the fix it guards. (If you'd rather keep `e2e/` edits out of the source commits, a single trailing test-infra commit is acceptable — state which you did.)

**Commit 4 (docs, recommended, separable):** reconcile `docs/backlog.md` FIT & FINISH — strike findings #1/#2/#3 as resolved (tombstone, don't delete), keep #4 as the banked P3, and update the "28 pass / 3 fail by design" note to reflect green. Leaving three fixed bugs shown as open + a stale by-design note is exactly the ledger drift the project guards against. Kept separate from the fixes per the docs-vs-source boundary; defer to a later sweep only if you'd rather.

**Boundary:** show every diff, commit nothing until I approve. Explicit pathspec staging, no globs. Ancestry eyeball before push — HEAD still `929e34d`, commits riding as a linear fast-forward, concurrent-session files untouched; branch/rebase only if that check surfaces a concurrent commit. No roadmap/SKILL edits — the roadmap "Also (HO 473)" note follows in a later doc sweep once this is on prod.

**Done =** the full harness green (the 3 findings' assertions pass, nothing else regresses), committee + `/trends` console-clean, and `grep "<title>"` showing only single-child titles.

---

read docs/handoffs/473-fit-finish-fixes.md and follow it
