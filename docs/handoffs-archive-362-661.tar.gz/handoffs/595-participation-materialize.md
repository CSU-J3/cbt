# HO 595 — take (b): get `member_votes` off the request path entirely

**Numbering.** Next from `docs/roadmap.md`'s pointer. 594 shipped the covering index (`eab2fd2` migration, `8159554` query change) on top of its STEP 0 (`f21b18b`). 588 remains the parked absence-watch probe with its block owed. Confirm against the roadmap and `git log`.

**STEP 0 first, then HALT.** The shape is a real fork and the index's continued existence is a live question.

---

## §0 — What 594 settled, including what it retracted

The covering index is a large real improvement and it does not close the defect:

| | co-located, pdx1 |
|---|---|
| steady state, all three queries | 140ms – 1.5s (was 20–24s+) |
| cold first touch of `member_votes` | 8.2s – 14.1s |
| worst | 20.003s → TimeoutError, twice in one 4-call sample |

**Worst-case margin against the 10s bound: −4.1s.**

The mechanism was pinned with two controls rather than assumed. `?order=` moved the spike to whichever query touched `member_votes` first (the CTE took 13.5s/8.2s in first position while the strip ran at 462–1024ms), so it isn't one bad query. `?warm=1` showed a trivial `SELECT 1` costs 1.4–1.9s and does not absorb the spike, so it isn't connection setup. It is the **first touch of the `member_votes` index pages, with residency under 60s** — every 45–60s gap went cold again.

Two consequences follow, and both are why (a) can't be finished:

- **Indexing cannot close it.** A covering index still has to read pages that aren't resident.
- **Cron warming cannot close it either.** Sub-60s residency needs a warm more frequent than Vercel cron can schedule, and warming the `unstable_cache` entry doesn't keep *index pages* resident, which is what actually decays.

594's STEP 0 recommended (a) off a 208ms median. That recommendation is **retracted on evidence** — cold, reading a 366k-row covering index is irreducible at request time, which puts it on the (b) side of the discriminator.

### Three findings from 594 that this HO has to carry

1. **The GREEN was not clean.** Post-fix: 0/13 route failures, but *one 10.23s first hit* — a bound breach that survived because the retry caught it. State post-fix results as **route failures AND query breaches**, never route failures alone.
2. **Retry masking.** `lib/db.ts` retries once, so a route 500 requires *both* attempts to breach. Route-level failure rate is roughly the **square** of the query-level breach rate. This is why 593's M2 counts were tiny and unrankable, and it means **every measurement in this HO instruments at the query level**, not the route level.
3. **The residency finding is not about `member_votes`.** Any request-time aggregation over a large table breaches the bound intermittently regardless of indexing, because the traffic gap exceeds page residency. That is a measured, sharper version of the LDA lesson — and it lowers the threshold, since the LDA rule was written about tables 7–14× `bills` and 366k rows is now over the same line.

---

## STEP 0 — four measurements, read-only, then HALT

Script: `scripts/diagnostic/participation-materialize-595.ts`. Commit, then HALT.

### M1 — the shape fork: 536-row table vs `dashboard_state` blob

Not a preference. The discriminator is the consumers.

`getParticipationStrip` and `getChamberParticipationContext` are straightforward reads and either shape serves them. **`participationAggCte` is the problem**: it feeds `getMembersRanked` (`lib/queries.ts:5857`) and `getCommitteeRoster` (`:6001`), both of which `ORDER BY missed_pct` **inside SQL**, with the HO 535 delegate carve-out applied in both the SELECT and the ORDER BY — deliberately, per the comment at `:5828` explaining that ordering by the alias alone would rank a delegate by its raw rate.

- **A blob** forces that ranking into JS and puts the carve-out's subtlety into hand-written code.
- **A 536-row materialized table** (`bioguide_id` PK, `missed_pct`, `total`) keeps it a join. The ranking SQL, the carve-out, and the tiebreaks are untouched; only the CTE's source changes. 536 rows is always resident.

Price both. **Recommendation is the table** — the LDA blob was right there because the consumer was a dashboard read, and that isn't the consumer shape here — but measure rather than inherit that.

### M2 — freshness, stated as a trade

Today the values are up to an hour stale (`revalidate: 3600`). A materialized value is as fresh as its refresh. Report: which job carries the refresh and at what cadence, what staleness that implies, and whether it's acceptable for a **cumulative** metric that moves by fractions of a percent per roll call. Write the trade down with the number; don't gloss it as "fine."

### M3 — does the covering index still earn its keep?

If the request path never touches `member_votes`, the index's only consumer is the refresh job. Against that, 594 C5 measured its cost on a **delete-and-rebuild-per-vote** write path: median 2.49s → 5.12s, worst 4.99s → 17.10s (~2× / ~3.4×).

Price the refresh job with and without the index and recommend **keep or drop**. Carrying a 2×-write-cost index whose only beneficiary is one nightly aggregate may not pay. A drop is its own migration in its own commit — do not fold it into the rewire.

### M4 — the residency finding's blast radius (inventory only)

594's mechanism generalises. Inventory request-path queries that read a large table cold, timed **co-located**, not from a laptop. `lda_filings` at 59% of bound (the HO 544 watch) is the same class and is the obvious first entry.

Ranked list by measured cold worst-case against 10s. **Fix nothing.** The output tells the next HO whether this is a family.

---

## HALT

Commit as `diag(db): HO 595 STEP 0 — participation materialization shape`, then stop. Report M1's two priced options plus a recommendation, M2's freshness trade, M3's keep-or-drop with numbers, and M4's ranked inventory.

---

## The build (phase 2, after approval)

Scope from M1/M3. Falsification, with the 594 lessons applied:

- **RED at HEAD, measured at the query level.** Route-level red is stochastic by construction because of the retry (594 got 1/13 route failures while the surviving 200s took 18–21s — abort plus successful retry). Instrument the query, force the cold key, and report the breach rate and the cold worst-case.
- **GREEN.** Cold first touch on the new path, worst case stated as a number with margin against 10s. Report **both** route failures and query breaches; a 0/N route count with a 10s query in the sample is not a green.
- **CONTROL.** 594 already produced value fingerprints — strip `1eedaa8d`, cte `21611d72`, chamberContext `349972d`. Reuse them. Post-rewire values must match, across `/members` (both sorts), `/committee/[code]`, and `/members/[bioguideId]`.

## Scope guards

1. **Do not touch the `pageErr` #418 OPEN LOOP.** 593 proved these are separate faults.
2. **Do not raise `DB_REQUEST_TIMEOUT_MS`**, and do not remove or extend the `lib/db.ts` retry — it's masking, but it's also the thing keeping the current state mostly-serving. Change it in neither direction here.
3. **Migration, rewire, and any index drop are three separate commits.**
4. **M4 is inventory.** No widening into `lda_filings` or anything else it surfaces.
5. **No unrequested SKILL.md edits.** The placement problem is real and stays owed to the sweep.
6. **No read-budget optimisation.** The predicted rows-read drop stays a logged prediction.

## Downstream note

**HO 588 (parked) is scoped against the current substrate.** Its R2 rule was costed as "reuses `getParticipationStrip`'s population so marginal read ≈ 0." If the strip becomes a materialized read, that assumption changes shape — it gets *cheaper*, not worse, but the probe's costing text will be stale. Flag it in the 588 handoff rather than letting the next person re-derive it. Do not resume 588 here.

## Owed to the sweep HO (592–595)

Everything already listed in 594's "owed" section, plus:

- The **residency finding** as a first-class oddity: page residency under 60s means request-time aggregation over a large table breaches the bound regardless of indexing — with the two controls (`?order=`, `?warm=1`) that pinned it, and the note that it lowers the LDA rule's size threshold to at least 366k rows.
- **Retry masking**: route-500 rate ≈ the square of the query-breach rate, so route-level counts systematically understate this class. Cross-reference 593's unrankable M2 table as the worked example.
- **`migrate.ts`'s 10s client can't build this index** — the build took 14.3s and needed a long-timeout apply. That's a trap for the next migration on a large table.
- **`npm run sync:votes` cannot measure its own write cost** — it skips vote ids it already has, so a second run writes nothing. 594 timed the atomic unit instead. Same class as the two instrument-integrity instances already owed: a command whose output looks like a measurement but isn't.
- 594's **retraction** recorded as a retraction, in a new roadmap block — the STEP 0 recommendation was made on a laptop median and reversed by a co-located worst case, which is the reusable lesson.
