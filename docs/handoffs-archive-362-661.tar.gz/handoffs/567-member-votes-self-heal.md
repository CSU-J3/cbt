# HO 567 — member_votes self-heal: closing the zero-roster inflow race (fix + repair, one mechanism)

HO 566 M2/M3 established the shape: 4 votes carry a positive tally and ZERO `member_votes` rows (`house-119-2-253` OTPQ 431 · `house-119-2-254` On Agreeing to the Resolution 431 · `house-119-2-269` On Agreeing to the Amendment 437 · `senate-119-2-146` Motion to Waive Budgetary Discipline 100), every deficit is all-or-nothing (no partials, no surpluses), and both syncs are WINDOWED. The reading: these votes were first-synced in the gap between the tally publishing and the member positions publishing, the per-vote wipe+rewrite wrote tallies plus an empty roster, and the watermark then froze them permanently. That is an inflow race, not four one-offs; it mints permanent zero-roster rolls at a base rate, and each one silently inflates every member's MISSED denominator and suppresses any 557 motion-line split it feeds.

**The design fork was decided in review: the bounded self-heal pass, not holding the vote row.** Holding the row until members arrive makes a fresh tally vanish from live surfaces for the gap. The heal pass keeps tallies live, converts permanent loss into bounded lag, reuses the 552/553 `deferred` precedent (non-stamp on pending, retry until complete, prove both branches), and its first run drains the existing 4 — so repair and fix are one mechanism, no separate backfill script.

## §0 — Preconditions

1. `git fetch && git status` clean, `main` even with `origin/main` at `0c62a81` or later, `npm run typecheck` clean.
2. Read before writing anything: the per-vote write path AND the watermark/selection logic in both `lib/votes-sync.ts` (M3 cited L354 / L388 / L322) and `lib/senate-votes-sync.ts` (L361 / L373 / L291); the M2 queries in `scripts/diagnostic/delete-rebuild-erosion-566.ts` (reused verbatim in verification); the 552/553 `deferred` convention (SKILL + oddities) — this HO is its sibling; the HO 533 all-zero split suppression (it explains the current `senate-119-2-146` render and the V3 expectation).

## §1 — STEP 0: confirm the cause upstream (read-only, diag commit, conditional HALT)

`scripts/diagnostic/member-votes-upstream-567.ts`: for each of the four ids, fetch the SAME upstream detail the sync fetches (House: the members payload `votes-sync` reads; Senate: the detail XML `senate-votes-sync` reads — take the URL construction from the sync files, don't invent one) and report: member count found, two sample names, and the tally the payload itself carries. No DB writes.

Commit the diagnostic alone (`diag:` prefix, explicit pathspec), report the four results, then gate:

- **All four now return a populated member list** → the transient-publication cause is confirmed; proceed to §3.
- **Any of the four still returns an empty roster upstream** → HALT after the diag commit and report. That is a different bug (a permanently memberless roll), and this design would retry it forever; the fix needs rescoping before any build code runs.

## §2 — The design

A **heal pass** inside each chamber's run function, executed after the watermark-driven new-vote loop on every run (cron tick and CLI alike), sharing the run's existing client and any existing time budget:

- **Predicate: zero-roster only.** `SELECT id FROM votes WHERE chamber = ? AND (yea + nay + present + not_voting) > 0 AND NOT EXISTS (SELECT 1 FROM member_votes mv WHERE mv.vote_id = votes.id) ORDER BY vote_date DESC LIMIT <cap>`. Small-table judgment (1,516 rows): no index, no hint. Newest-first so a fresh race heals fastest.
- **NOT deficit-based, deliberately.** Partial deficits measured 0 at HO 566, and a partial can be structural (a Senate resolver miss re-fetches into the same miss) — healing on deficit would spin forever on it. The zero-roster predicate is also **self-limiting by construction**: a vote that heals even partially gains rows and exits the set, so a structural partial can never trap the pass. If partials ever appear in the wild, that is a different HO.
- **Cap: 10 per chamber per run** (`HEAL_CAP` const, comment carrying today's backlog of 4). One upstream GET per healed vote, worst case 10 GETs inside the existing budget.
- **The heal re-runs the existing per-vote write function unchanged.** On a populated response the wipe+rewrite inserts the roster (the DELETE is a no-op on a zero-roster row); on a still-empty response it inserts nothing and the vote simply remains in the set for the next run. Permanent retry is the accepted posture, exactly as adjudicated at HO 553 for `deferred` (~one GET per stuck row per run, versus re-opening a permanent drop).
- **Visibility:** each chamber's sync summary gains `memberVotesHealed: string[]` and `memberVotesHealPending: string[]` (the ids attempted this run that stayed empty), surfaced into `cron_runs.payload` — the `rosterDeletesRefused` / `deferred` precedent. Pending PINNED across runs on the same ids is the promote signal (recorded at the HO 569 sweep as a WATCH, not here).

## §3 — Build

**C1 — House.** The heal pass in `lib/votes-sync.ts` + the two summary fields. `npm run typecheck`.
**C2 — Senate.** The same pass in `lib/senate-votes-sync.ts` + fields. `npm run typecheck`.
Watermark and selection logic byte-untouched in both (the four M3 line sites). Explicit pathspec per commit, ancestry eyeball before each push.

## §4 — Falsification (before anything is recorded as protection)

- **Pending branch (must be forced — HO 549/553):** scratch-perturb locally so ONE of the four's upstream fetch yields an empty roster (stub the fetch or force the parse to `[]` for that id — scratch edit only, never committed, never a checkout of pre-fix files). Run the pass: the row stays zero-roster, the id lands in `memberVotesHealPending`, NOT in `memberVotesHealed`, and nothing else changed. Revert the scratch, `git status` clean, run again: it heals. Record the transcript summary in the report.
- **Success branch:** the live drain in §5 is the proof — no simulation needed.

If the local environment can't force the pending branch, record it UNPROVEN in the report and say so; do not describe it as protection.

## §5 — Drain + verification

1. **Drain:** run each chamber's sync locally (CLI) against prod. Expect `memberVotesHealed` = the 3 House ids and the 1 Senate id respectively; report any residual per-vote deficit on the healed four (a small partial means upstream genuinely lists fewer names — record it, it exits the heal set by design).
2. **V1 — regression by the probe that found it:** re-run `scripts/diagnostic/delete-rebuild-erosion-566.ts`. M2(a) must read 0 / 0; distributions collapse to the 0-deficit bucket (645 / 871) modulo any residual recorded in step 1.
3. **V2 — payload wiring:** the next run's summary carries both fields (empty arrays at steady state); confirm they appear in `cron_runs.payload` after the next deployed tick, presence-of-field, not just absence-of-error.
4. **V3 — the 557 bonus:** `senate-119-2-146` is a budget-waiver roll; locate its amendment via the motion query and confirm the motion line now renders its D/R split (it was all-zero → suppressed under HO 533 before the heal). Eyeball, screenshot or CDP note.
5. **V4:** one `/vote/[id]` eyeball on `house-119-2-269` showing the member breakdown.

Push, `verify:deploy` SHA, and let the next scheduled tick confirm V2 in prod.

## §6 — Report, then halt

Paste back: STEP 0's four upstream results, the falsification transcript, drain output, V1 numbers, V3/V4 confirmations, and a payload sample. Docs are NOT touched here — roadmap/backlog/oddities/SKILL all land at the HO 569 sweep (which also covers 568). Halt after the report.

## Hard scope guards

1. Watermark and selection logic untouched — L354/L388 (`votes-sync`) and L361/L373 (`senate-votes-sync`) byte-identical.
2. The per-vote write function untouched; the heal calls it, never forks it.
3. Predicate stays zero-roster (`NOT EXISTS`); no deficit-based healing, no tally reconciliation.
4. No schema, no migration, no index, no `vercel.json` touch.
5. `amendment_votes`, the 537 recompute, the Senate resolver, and `committees-sync` untouched (committees is HO 568).
6. No docs commits; SKILL.md untouched (569).
7. Nothing noticed in passing gets fixed.
