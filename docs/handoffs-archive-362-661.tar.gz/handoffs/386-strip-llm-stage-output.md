# 386 — Strip dead LLM stage output (gated on 385)

**Self-claim:** if `docs/handoffs/386-*.md` exists, bump to the next free number (`ls docs/handoffs/ | sort -V | tail`) and rename before starting.

**Precondition, do not start until both hold:** 385 is live, and its residual-uncatchable count has been reviewed and accepted. This handoff removes the LLM's stage output, so after it lands there is no residual LLM value behind the cases computeStage can't catch from latest-action text. Running it is the decision to accept that those cases under-stage (by a rung, on obscure bills) in exchange for single-authority stage and a leaner prompt. If 385's residual is large or includes bills that matter, hold and reconsider; the escape hatch is feeding computeStage the full action list, a bigger change, not this one.

**Scope:** remove the now-dead stage field from the summarize prompt and its handling. Behavior is unchanged (the runner already stages via computeStage since 383); this only deletes the dead emit and parse. Show the diff, hold for approval.

## Why (resolved premises)

- 383 made computeStage the stage authority and the runner ignores `result.stage`, but the prompt still asks the LLM to emit stage and the response still carries it. It's dead weight: a field generated, parsed, and discarded.
- 385 closed the catchable coverage gap, so computeStage now recognizes the patterns the LLM stage was implicitly covering, leaving only the documented residual.

## Steps

1. **Confirm it's truly dead.** Grep every reader of the LLM stage field across the repo, not just the runner. Confirm nothing consumes `result.stage` anywhere. If anything still does, stop and surface it.
2. Remove the stage instruction from the prompt (`lib/summarize.ts`) and the stage field from the requested JSON shape.
3. Remove the parse/handling of `result.stage` in `lib/summarize-runner.ts` and any now-dead type field on the response.
4. Confirm the runner still writes stage via computeStage (unchanged) and summary/topics are unaffected.
5. **Verify:** run summarization on a sample bill; confirm stage is still set correctly (via computeStage), summary and topics still produced, the JSON contract parses with the field gone, tsc clean.
6. Update `SKILL.md` to state the prompt no longer emits stage and computeStage is the sole stage authority (flips the doc-sweep "pending removal" note to done), or hand that line to the pending doc sweep, your call.
7. Show the diff, hold for approval. No deploy until approved.

## Report back

Confirmation the field was dead everywhere (the grep result), the diff, and the sample-run verification that stage / summary / topics are intact with the field removed.
