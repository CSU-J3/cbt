# HO 660 — the harvest gets its clock: slot (b) wired

**Parent:** backlog QUEUED "the challenger harvest has no schedule; it runs when a human remembers" — **ruled slot (b) at HO 659**, close criterion *chosen AND wired*, first half done. **Baseline:** `d6b7407`.

## The slot, with its reasons

**`/api/cron/race-challengers` daily at `30 12 * * *` (12:30 UTC).** The harvest's entire input is what `/api/cron/primaries` writes, and that fires `0 0,12 * * *` — so 12:30 rides the tick most likely to carry fresh next-day winner calls (US primary results post in the 00:00–06:00 UTC band; the 12:00 tick is the one that reads them settled). Winners marked by the 00:00 tick wait at most 12.5h, which is the price of keeping the ruling at one daily fire rather than quietly over-provisioning it to two. 12:30 is clear of the weekday fmp half-hourlies (`0,30 13-21` starts at 13:00) and collides with nothing else in `vercel.json`.

**Deliberately no cron-lock.** The primaries tick is deadline-bounded at 50s inside a 60s ceiling, so it is finished by ~12:01; nothing else writes `race_candidates` on a schedule (the seed is manual). Stating the omission so it reads as a decision, not a gap.

## Shape: one implementation, two callers

The harvest logic moves from `scripts/backfill-race-challengers.ts` into **`lib/harvest-challengers.ts`**, and both the npm script and the new route call it. The script survives as the manual path — the backlog ruling wired a clock, it did not retire the hand-run.

- `export async function harvestChallengers(db): Promise<{ runStamp, cleared, inserted, rows, races, ratedIndex }>` — contains, verbatim from the script: the `runStamp` computation (moves INSIDE the function; one stamp per invocation regardless of caller), the sentinel DELETE, the `INSERT OR IGNORE … SELECT DISTINCT` with `HARVEST_FROM_WHERE`, and the fill census. **The SQL moves byte-identical — zero query changes in the refactor.**
- No `dotenv/config` in the lib file (server runtime has env; the script wrapper keeps its import). `db` is an argument, the `logRatingHistory(getDb())` pattern.
- The script keeps its before-census, sample eyeball block, and done-message as wrapper flavor around the lib call.

## STEP 0 — verify the claims (no halt; additive)

Chat-side clone readings at `d6b7407`; re-derive on your tree:

- **0.1** `vercel.json`: primaries at `0 0,12 * * *`; no existing entry at or adjacent to 12:30; fmp half-hourlies start 13:00 weekdays. Confirm 16 cron entries today so the diff is +1.
- **0.2** `app/api/cron/rating-history/route.ts` is the template: `authorize()` on Bearer `CRON_SECRET`, `wrapCronRoute` from `@/lib/cron-log` (the `cron_runs` row), `dynamic = "force-dynamic"`, `maxDuration = 60`, GET+POST both handled.
- **0.3** `lib/cron-health.ts` `CRON_ROUTES`: read the existing **daily** entries' `maxStaleMs` and mirror it for the new route — match the pattern, do not invent a window.
- **0.4** The script's current shape matches the extraction plan above (runStamp → before → DELETE → INSERT → fill → sample). Any drift from that reading is named before the refactor, not absorbed by it.

## STEP 1 — refactor commit: extraction, behavior-identical

- Create `lib/harvest-challengers.ts`; rewire `scripts/backfill-race-challengers.ts` to call it. Constants (`CYCLE`, `HARVEST_SOURCE`, `HARVEST_FROM_WHERE`) move with the function.
- **Gate — the HO 659 instrument is the refactor's equivalence check.** Run the refactored `npm run backfill:race-challengers`, then `scripts/diagnostic/race-candidates-stamp-659.ts`: sentinel content checksum byte-identical to the pre-refactor reading (or drift named to the seat — a winner may genuinely have landed), exactly one fresh distinct stamp across all sentinel rows, the 11 curated rows still NULL. A refactor that passes this touched behavior not at all.
- `npm run typecheck` → commit (explicit pathspecs: the two files) → ancestry eyeball → fast-forward push. Refactor and feature never ride together.

## STEP 2 — feature commit: the route, the schedule, the watchdog

- **`app/api/cron/race-challengers/route.ts`** mirroring rating-history exactly: authorize → `wrapCronRoute("/api/cron/race-challengers", …)` → `harvestChallengers(getDb())` → `revalidateTag("races")` **unconditionally** (every run clears and re-derives, so every run is a write; the tag flush is not conditional on `inserted > 0`) → payload = the figures. One log line with the figures, the house pattern.
- **`vercel.json`**: the functions entry (`maxDuration: 60`) and the cron entry (`30 12 * * *`). +1 each.
- **`lib/cron-health.ts`**: the `CRON_ROUTES` entry with the 0.3-mirrored window.
- `npm run typecheck` → commit (explicit pathspecs) → push. **Direct to main** — new route + schedule ship in one deploy so Vercel never fires a schedule at a 404.

## STEP 3 — ops: deploy verify + manual fire (this does NOT arm M3)

- **3.1** Confirm the SHA live via `/api/version` before interpreting anything.
- **3.2** Manual fire: `curl -X POST -H "Authorization: Bearer $CRON_SECRET" https://<prod>/api/cron/race-challengers` → 200 with the figures; a failing-auth control (no header → 401) so the guard is fired, not assumed.
- **3.3** Read back: `cron_runs` carries a row for the path; the 659 instrument shows one fresh stamp across all sentinel rows and curated still NULL; `GET /api/health` lists the route (its manual row satisfies the window).
- **3.4** **The scheduled first fire cannot be forced and is not claimed.** The HO 504 schedule precedent governs: manual and deploy-adjacent invocations prove the route, the `schedule` trigger stays UNPROVEN until its first real fire. WATCH: confirm the ~12:30 UTC `cron_runs` row the next day. **That row — not today's curl — arms the M3 re-measure**, exactly as the restated backlog entry says: the trigger is the first *scheduled* fire, because the detector calibrates against the maintained regime, and a hand-fired route is still a harvest that runs when a human remembers.

## STEP 4 — docs commit (roadmap + backlog; never with code)

- **Roadmap:** append the HO 660 block — the slot and its reasons (12:30 after the 12:00 primaries tick; the ≤12.5h price of one daily fire; no-lock as a decision), the extraction with its instrument-gated equivalence reading, the manual-fire verification figures, and the two open tails stated plainly: the schedule trigger UNPROVEN until first fire (HO 504 precedent), and M3 armed by that fire, not by the curl. Pointer: "Also notes now run through HO 660." Verify append-only with `git diff --numstat` — deletions column 0 on `docs/roadmap.md`.
- **Backlog:**
  - Strike the schedule QUEUED entry — *chosen AND wired* are both now true — with the slot, the route path, and the figures. Inside the strike text, one WATCH line: first scheduled fire pending, confirm the ~12:30 UTC `cron_runs` row, and note that this fire is what arms the M3 restatement's trigger.
  - The M3 restated entry gains nothing — its trigger text already names HO 660's first scheduled fire. Touch it only if 0.x found its wording no longer true.
- **Oddities:** append at END only if something genuinely odd emerged.

## STEP 5 — SKILL, alone, behind the self-mod guard

One commit, review ref `refs/heads/660-review`, diff approved before main moves. Touches:

- The cron topology section gains the slot: `/api/cron/race-challengers`, daily `30 12 * * *`, after the 12:00 primaries tick, pure DB-to-DB, `revalidateTag("races")` every run.
- The `backfill:race-challengers` entry gains one sentence: wired to a daily cron at HO 660; the npm run remains the manual path; both callers share `lib/harvest-challengers.ts`.
- If SKILL documents the `CRON_ROUTES` watchdog set, the new entry joins that list; if it doesn't, don't create the list for this.

The dated "First run: 82 rows across 53 races" figure stays, as ever.

## Commit table

| # | kind | contents |
|---|------|----------|
| 1 | refactor | `lib/harvest-challengers.ts` + script rewire, instrument-gated equivalence |
| 2 | feat | route + `vercel.json` (+1 function, +1 cron) + `CRON_ROUTES` entry |
| — | ops (no commit) | `/api/version` → manual fire + 401 control → `cron_runs` / instrument / health reads |
| 3 | docs | roadmap block + backlog strike-with-WATCH + oddities if any |
| 4 | docs | SKILL alone, via `refs/heads/660-review` |

## Git discipline

Explicit-pathspec staging · ancestry eyeball before every push (`git log --oneline @{u}..HEAD`) · fast-forward only on main · `npm run typecheck` before pushing · no force-push (force-with-lease on the review ref only) · delete `660-review` after the fast-forward.
