# HO 467 — chip-family stage leg (B6 arc)

Bring the stage pill strip onto the HO 287 tier-2 spec: **10px**, active (current) stage = its color at **50% alpha** border, inactive (history) = `--text-dim` text + `--border-strong` border. **Decision 2 (Corey): `StageIndicator` stays exempt** — its `▸ / ▸▸ / ▸▸▸▸` arrow-prefix encodes stage progression at a glance on hearings + `/bill/[id]`, and flattening it into a plain pill is lossy. Closes the stage leg from the HO 465 audit.

One commit. Touches `StagePillStrip.tsx` + two `.stage-pill` CSS rules; the change flows to every BillRow surface through the one shared component. Re-grep at write time (globals.css line numbers drift from the concurrent session).

## Current vs target

`.stage-pill` today: `font-size: 11px; border: 1px solid currentColor;` (full stage color), and `StagePill` sets `style={{ color: stageColor(stage) }}`. `.stage-pill--history` dims the whole pill via `opacity: 0.6` (stage color still shows through). The spec wants the history pill explicitly gray (`--text-dim` / `--border-strong`), not a dimmed stage color.

## Build

### 1. `.stage-pill` CSS

- `font-size: 11px` → `10px`.
- `border: 1px solid currentColor;` → `border: 1px solid color-mix(in srgb, currentColor 50%, transparent);` — the active pill's border becomes its stage color at 50%. (`color-mix` is already used in this stylesheet — `.bill-rail` — so it's supported.)

### 2. `.stage-pill--history` CSS

- Remove `opacity: 0.6`.
- Add `color: var(--text-dim); border-color: var(--border-strong);` — history pill goes explicitly gray, overriding both the inline stage color and the 50%-stage border.

### 3. `StagePill` component (`StagePillStrip.tsx`)

The inline `color` currently drives both text and (via `currentColor`) the border. For the history pill to render dim text, set the color conditionally:

```tsx
style={{ color: history ? "var(--text-dim)" : stageColor(stage) }}
```

So: current pill → text = stage color, border = stage color @50% (from `currentColor`); history pill → text = `--text-dim`, border = `--border-strong` (from the `--history` override). The middot separator's inline `opacity: 0.5` stays (it now dims off `--text-dim` on history pills, off the stage color on the current pill — both fine).

### 4. Leave exempt

`StageIndicator.tsx` (hearings + `/bill/[id]`), `StageFunnel`, `StageLegend`, `StageFilter` — untouched.

## Commit & verify

One commit, explicit pathspec, show diff, wait for approval, ancestry eyeball before push.

```
feat(chips): stage pill strip → tier-2 spec (10px, active @50% / inactive dim) (HO 467)
```

Prod-verify after deploy on any two-pill bill (e.g. a floor-stage bill on `/bills`): the **current** pill reads at its stage color with a 50%-alpha border at 10px; the **history** (INTRODUCED) pill reads gray (`--text-dim` text, `--border-strong` border), no longer a dimmed stage color; the `→` arrow between them is unchanged; `LABEL · age` format intact. `StageIndicator` on `/bill/[id]` + hearings still shows the arrow-prefix idiom. Zero new console errors.
