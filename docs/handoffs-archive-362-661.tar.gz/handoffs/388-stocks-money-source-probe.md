# Handoff 388 — Stocks & money source probe (read-only)

Revive the two parked member-depth threads (stock trades, donor breakdown) on the free path. This is a **diagnostic only** — grep the live repo for what survives, then probe candidate free sources live and HALT with findings. No schema, no ingestion, no UI. The build handoff scopes against what this probe finds, not against memory.

## Resolved premises — do not re-derive

Take these as given. They cost real reverts to learn:

- **OpenSecrets API is dead** (discontinued April 2025). HO 65 was reverted because of it. It was the easy industry-classified donor source. Gone.
- **FMP `/api/v4/` congressional-trading is dead** (deprecated August 2025). HO 70 was built on it and the pipeline died. The `stock_trades` schema HO 70 left behind may still exist and is reusable.
- **Quiver Quantitative is out of scope.** $300/yr Hobbyist, costed in May, killed — no revenue story. Do not probe it, do not propose it.
- **FEC fundraising totals are already live.** HO 83 surfaces total raised + cash-on-hand per member on the member hub, via `api.open.fec.gov` on `FEC_API_KEY`. That pipeline works. The *donor breakdown* (top contributors / industry / PAC-vs-individual) was explicitly cut from HO 83 and is the unbuilt money piece.

## Step 0 — Live repo state

The `/mnt/project` copy lags HEAD. Grep live and report exact state, because the build scopes against this:

```
# Stocks (HO 70 residue)
grep -rl "stock_trades\|fmp\|sync-trades\|TradeRow" lib/ scripts/ app/ components/ --include="*.ts" --include="*.tsx"
sqlite/turso: SELECT name FROM sqlite_master WHERE type='table' AND name LIKE '%trade%';
turso: PRAGMA table_info(stock_trades);   -- if it exists
turso: SELECT COUNT(*) FROM stock_trades;  -- if it exists, is there stale data in it?

# Money (HO 83 + reverted HO 65 scaffolding)
grep -rl "fec_totals\|fec-resolve\|sync-fec\|donor\|fundrais" lib/ scripts/ app/ --include="*.ts" --include="*.tsx"
turso: PRAGMA table_info(fec_totals);
turso: SELECT COUNT(*) FROM fec_totals;
turso: SELECT name FROM sqlite_master WHERE type='table' AND (name LIKE '%donor%' OR name LIKE '%fec%');
```

Report: which files exist, whether `stock_trades` is present and whether it holds dead rows, current `fec_totals` row count, and any reverted-HO-65 donor tables still sitting in the schema.

## Step 1 — Stocks: free source probe

In priority order. The goal is a structured trade feed (member, ticker, txn type, amount band, txn date, disclosure date) without writing a PDF parser if we can avoid it.

**1. Capitol Trades BFF (lead candidate).** Undocumented JSON API behind capitoltrades.com, no auth, returns parsed trades. This is the closest free thing to what Quiver sells. Confirm the live endpoint, params, and shape — don't trust this URL from memory, verify it:

```
curl -fsSL "https://bff.capitoltrades.com/trades?page=1&pageSize=12" | head -c 4000
```

Report the response envelope and per-trade fields (politician identity, asset/ticker, txType, value range, txDate, pubDate). Flag: no official API → ToS-fragile, can break or block without notice. Does it expose a stable politician ID we could match to `bioguide_id`, or only a name string?

**2. Finnhub congressional-trading.** Was HO 70's named fallback. Symbol-keyed, not member-keyed (you query by ticker), which is awkward for a per-member surface. Free tier may have moved this to premium — confirm:

```
curl -fsSL "https://finnhub.io/api/v1/stock/congressional-trading?symbol=AAPL&token=${FINNHUB_TOKEN}" | head -c 2000
```

No token on hand → report that signup is required to probe and stop there; don't sink time into account creation. If it's premium-only now, mark dead-for-us.

**3. House Clerk bulk FD/PTR (source of truth, ugly).** The House Clerk publishes annual ZIPs: an XML index of every filing (DocID, name, filing type, date) plus the PDFs. PTRs are filing type `P`. The index gives you *who filed and when*; the trade *contents* live inside the PDFs (recent ones e-filed, older ones scanned/handwritten). Confirm the current-year URL pattern is reachable and what the index contains:

```
curl -fsSL -o /tmp/fd.zip "https://disclosures-clerk.house.gov/public_disc/financial-pdfs/2026FD.ZIP"
unzip -l /tmp/fd.zip   # confirm the {YEAR}FD.xml index is inside
```

Report whether the ZIP + XML index is reachable, and confirm the PTR contents require PDF parsing (the multi-handoff cost). Half of House depth lives behind a PDF parser — say so plainly.

**4. Senate eFD (efdsearch.senate.gov).** Behind an "accept agreement" gate that sets a session cookie, then search is a CSRF-protected POST. Headless-hostile. E-filed PTRs render as structured HTML tables (parseable); paper filings are PDFs. The real question is whether the agreement-cookie + CSRF flow works server-side at all. Probe whether the agreement endpoint and a follow-up search request can be driven from a cookie-jar flow, or report it as blocked-from-egress if the gate defeats a server-side request.

**Egress caveat (the FRED lesson).** Local curl succeeding does not prove Vercel can reach it — `fredgraph.csv` is cloud-IP-blocked from Vercel egress while working fine locally. For whichever candidate emerges viable, confirm reachability **from a deployed function**, not just your laptop, before it's reported as buildable. Flag any source that 403s or hits a JS/Cloudflare challenge from egress.

Skip Unusual Whales — congressional data is paid-tier only.

## Step 2 — Money: donor breakdown probe

FEC totals (raised + CoH) are live. This probes whether the *breakdown* is buildable free on the existing `FEC_API_KEY`. Reachability is not the question (HO 83 proved the key works) — shape and the classification gap are.

Resolve one member already in `fec_totals` to their principal campaign `committee_id`, then probe the Schedule A aggregate endpoints:

```
# top contributors by employer — closest free analog to OpenSecrets "top orgs"
curl -fsSL "https://api.open.fec.gov/v1/schedules/schedule_a/by_employer/?committee_id=${CID}&cycle=2026&per_page=10&sort=-total&api_key=${FEC_API_KEY}" | head -c 3000

# small-dollar vs large-dollar split
curl -fsSL "https://api.open.fec.gov/v1/schedules/schedule_a/by_size/?committee_id=${CID}&cycle=2026&api_key=${FEC_API_KEY}" | head -c 2000

# by occupation
curl -fsSL "https://api.open.fec.gov/v1/schedules/schedule_a/by_occupation/?committee_id=${CID}&cycle=2026&per_page=10&sort=-total&api_key=${FEC_API_KEY}" | head -c 2000
```

Report the shape and a sample top-10. Then the limitation that decides whether this is worth building:

**FEC gives employer, not industry.** The aggregates return contributor *employer strings* (`"Google"`, `"Kirkland & Ellis"`, `"Retired"`, `"Self-employed"`) — not classified sectors. OpenSecrets' value was the hand-built employer→industry rollup ("Securities $X, Tech $Y"). Reproducing that on FEC data means building our own employer→industry mapping, which is a real classification project, not a sync. State explicitly whether employer-level breakdown is the ceiling of what's free, and roughly how noisy the employer strings are (how much "Retired"/"None"/blank dominates the top rows).

Quick confirm there's no free industry-classified replacement that's appeared post-OpenSecrets (expect none — a 2-minute check, not a research project).

## HALT — report format

End with a table, one row per source:

| Source | Thread | Status | Match key | Cost to build |
|---|---|---|---|---|

Status ∈ `ALIVE·FREE·structured` / `ALIVE·FREE·needs-PDF-parse` / `ALIVE·but-egress-blocked` / `PAID-for-us` / `DEAD`. Cost ∈ one-handoff / multi-handoff parser / blocked.

Then:
- Repo-state summary from Step 0 (what survives, what's salvageable, any dead rows to clear).
- For each thread, your SHIP / PARK read with one line of why.

**Hard stop here.** No schema, no ingestion, no UI, no clearing of stale `stock_trades` rows. The viable threads each get a scoped build handoff after sign-off in chat; anything that comes back blocked-or-paid stays parked with the finding recorded.
