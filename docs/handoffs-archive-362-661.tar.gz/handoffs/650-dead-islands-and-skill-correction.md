# HO 650 — SKILL names a dead component as live and omits the one that replaced it

**Ground truth:** `main` at `abcee25` (`docs(HO 649): file what the coverage probe priced`), `ls-remote` reads main only.

**On the number.** First application of the rule banked at HO 649 M3: the roadmap's pointer still reads **646**, commit subjects run to **649**, so the next HO is `max(646, 649) + 1` = **650**. Taking it from the roadmap alone would have collided for the third time.

This closes the HO 649 orphans entry. It does **not** touch the 12-component classification or the 18 class-3 figures — both are separate questions and §6 explains why one of them gets harder if this is done carelessly.

**Three commits:**

| # | Kind | Contents |
|---|------|----------|
| 1 | `chore` | rehome `TopicDatum`, delete four dead component files |
| 2 | `docs` | SKILL — the client-islands enumeration, four sites |
| 3 | `docs` | backlog — the orphans entry closes |

Commits 2 and 3 ride a **review ref**: commit 2 edits SKILL and sits behind the self-mod guard, and commit 3's strike is permanent in shape.

---

## §1 — Measured state, not inherited state

Verified independently of the HO 649 probe (direct import grep on `abcee25`, because the probe's own graph is the thing that found this):

| file | value importers | `"use client"` | SKILL says |
|---|---|---|---|
| `StateFlag.tsx` | **0** | yes | live row affordance (L1711, L2044) |
| `DashboardTopicTreemap.tsx` | **0** (two `import type` only) | yes | live island on `/` (L1711, L2043, L2044) |
| `IssueBars.tsx` | **0** | no | correctly superseded (L1732) |
| `TerminalPrompt.tsx` | **0** | no | *"unused no-ops left in place for a later sweep"* (L1916) |
| `TopicDistributionList.tsx` | 1 — `app/page.tsx:216` | yes | **nothing. Zero hits.** |

Two things fall out that change the shape of the work.

**`IssueDrill.tsx` is already gone**, so L1732's clause naming both is accurate as written and needs **no edit** — `IssueBars` is a deletion only. Do not touch that line.

**L1916 is currently TRUE and this handoff makes it false.** It says `TerminalPrompt`, `.page-masthead` and `.home-cursor-title` are left in place *for a later sweep*. This is that sweep, for one of the three. The clause must narrow to name what still remains rather than be deleted — the two CSS selectors are **not** in scope here, and a clause that stops mentioning them loses the only record that they exist.

---

## §2 — Commit 1: the code

**Rehome `TopicDatum` first.** It is defined at `DashboardTopicTreemap.tsx:22` and consumed type-only by `app/page.tsx:11` and `TopicDistributionList.tsx:5`. Move it into **`TopicDistributionList.tsx`** — the live renderer, and the component whose own header already documents the HO 627 swap ("the mock wins over the shipped treemap"). Update both importers. **Two consumers, not one**; the logged chore names the constraint but not the count.

Then delete `components/DashboardTopicTreemap.tsx`, `components/StateFlag.tsx`, `components/IssueBars.tsx`, `components/TerminalPrompt.tsx`.

The ordering is load-bearing and the type edge is the reason: `import type` is erased at compile time, which is exactly why the probe's first reachability graph called the treemap live and why the file survived a chore that was already logged against it. Delete before rehoming and `tsc` fails on two files.

---

## §3 — Commit 2: SKILL, four sites

**L2043 — the `/` islands list.** Replace the `DashboardTopicTreemap` entry with `TopicDistributionList`, and say what happened: HO 627 replaced the treemap with a ranked bar list per the committed mock, and the treemap file is deleted at HO 650. **Do not write a passage for `TopicDistributionList` — one clause naming it in the islands list, no more.** §6.

**L2044 — the canonical `### Server / client split` set.** Drop `DashboardTopicTreemap` from the interactive-charts group and `StateFlag` from the row-affordances group.

**L1711 — the design-section prose.** The same two names appear in the same two groupings. Same removal.

**L1916 — the `TerminalPrompt` clause.** Narrow it: the component is deleted at HO 650; `.page-masthead` and `.home-cursor-title` remain as unused CSS.

**One contradiction to fix while you are in both lines, and it is bounded to this.** L1711 puts the client set at **~67** (69 grep matches); L2044 puts it at **~53**. Same set, two numbers, both lines carrying their own *grep to refresh* instruction. Run the grep on the post-deletion tree and make both agree with the measured count. **Do not go looking for other count disagreements** — that is HO 649's M2 class-3 list and it is a different HO.

---

## §4 — Commit 3: backlog

Strike the **orphans entry** (*"Two more display orphans, extending the HO 627 chore"*) as SHIPPED with a tombstone. It closes completely: the covered-but-not-reachable set goes from 4 to **0**, since all four files are deleted here rather than two.

Add one clause to the **M1 entry** — do not restate its numbers, they are correctly SHA-stamped at `b634f7e`. The clause: this HO changes what a re-run reports, and the direction is not obvious. See §6.

The **HO 627 `DashboardTopicTreemap` chore** is subsumed. Strike it too if it is a separate line; note it here if it is a clause inside a larger entry.

---

## §5 — Verification

**5.1 — the discriminating check is a render diff, and it needs a positive control.** Capture `/`'s served HTML before, apply, capture after. **Byte-identical is the pass** — the four files are dead, so nothing should move.

The trap: **byte-identical is also exactly what doing nothing produces.** So the render diff alone is not evidence. Two things make it one:

- The `--numstat` must show four file deletions and the `TopicDatum` move. Report it alongside the diff, not separately.
- **Fire the harness first.** Perturb a visible string inside `TopicDistributionList`, capture, confirm the diff is **non-empty**, revert, confirm `git status` clean. An empty diff from a capture that cannot see changes reads identically to an empty diff from a correct one, and this is the third arc in a row where that shape has come up.

**5.2** — `npm run typecheck`. This is what catches a missed `TopicDatum` importer, and there are two.

**5.3** — `npm run build`. A deleted client component that something reaches at runtime survives `tsc` and fails here.

**5.4** — Re-run `scripts/diagnostic/skill-coverage-649.ts` and report the new counts. This is the probe proving its own finding closed, and it is the first time it has been run against a change it caused.

---

## §6 — What this does to the HO 649 numbers, stated before anyone reads them

Naming `TopicDistributionList` in the islands list gives it a SKILL hit. So a re-run reports **11** zero-hit reachable components, not 12.

**11 does not mean one was classified.** Nothing here decides what owes a passage — the criteria for that still have to be written before the list is read, and the list has now been read three times. `TopicDistributionList` leaves the set because a *false claim about a different component* was corrected and it happened to be the correction's subject. **Whoever scopes the 12 must re-run the probe rather than work from the filed list**, and should know that one name left it for a reason that does not generalise.

The covered-but-not-reachable set goes 4 → **0**, and that one is a real close.

---

## §7 — Delivery

Commit 1 direct is fine. Commits 2 and 3 push to `refs/heads/650-review` — report the ref SHA and per-file numstat, and state the expected numstat for commit 3 before running it. Main stays at `abcee25` until the SKILL text is read.

Explicit pathspec staging (`git rm` for the deletions), no `git add .`, ancestry eyeball, fast-forward only.
