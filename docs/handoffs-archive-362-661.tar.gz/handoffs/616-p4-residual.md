# HO 616 — P4-residual: four routes, three different answers to the axis question, and P4 actually closes.

HEAD `3825bd3`. Pointer "run through HO 615." **Next free is 616.** Baseline is v3 (`9244cb9` crawl): `/trades` 32 · `/amendments` 20 · `/members` 16 · `/nominations` 15. Sweeps defer to the arc close unless a main claim goes false; this HO's HALT carries the numbers.

**§0 — a rule this HO establishes by needing it: curves are instrument-relative.** The 613 trades curve (`240→(17,5)`, `200→(29,1)`) was measured under v2 banding and is **void** — v3's ink-span changed what a "row over" is (magnitude 1,137→248 on the same rows). Any curve consulted in this HO is re-derived under v3 or it isn't a curve. That sentence goes in the sweep.

**§0.5 — the three answers, ruled up front so the HO demonstrates the registry rather than litigating it:**

- **`/trades` — the attribute is BARRED.** No bars, no encoding: a right-aligned money column is clause 1's named non-qualifier ("never a plain text table"). The fix is structural: **the reorder** — the variable-width column moves last (`date · txn · ticker · amount · amount · asset-name`), so per-row slack becomes trailing gap, which is the target state and unthresholded. The amounts keep a *tighter* axis (adjacent to ticker), the cap likely becomes deletable, and no exemption is spent. This is a new kit move; the sweep names it.
- **The `RankRow`s — the attribute MAY qualify, curve first.** Both `/amendments` and `/nominations` render an identical inline `RankRow` (`minmax(0,1.6fr) minmax(0,2fr) 56px`, the 2fr holding a real `widthPct` bar on a shared track origin). Real bars, shared origin: clause 1 is satisfiable — but clause 2 is not waivable. Measure where the void falls (label→track-origin in the 1.6fr, and bar-end→count) and what a cap costs, then mark or cap by the curve's verdict, registry entry with `M1x <candidates> / <rows>` either way.
- **`/members` — decompose before anything.** The 16 under v3 is expected to be the 612 marginals (121–131px), headers, and strips; work only what decomposes as real. The `MemberTopicBar` question, if the decomposition raises it, goes through the same clause-2 gate — but don't go looking for it.

## 1. Commit 1 — `/trades`: the reorder

Reorder the template and the cell order in `TradeRow` (and its header) to `60px 40px 80px 110px 110px minmax(0,1fr)`. The asset name takes natural width with its existing `title`; test whether the 280 cap is still needed (expected: no — a trailing variable column can't open an interior gap) and delete it if the v3 measurement agrees, keeping the ellipsis for narrow widths. Buy/sell coloring, txn glyphs, amount alignment: untouched.

Score: `--route trades` → 32 → ~0, residual decomposed. Eyeball: the row reads `date txn ticker $range $range Asset Name…` and the amounts scan as a column.

`fix(trades): HO 616 — the reorder: variable-width column last; the axis tightens, the cap retires (C1, no exemption spent)`

## 2. Commit 2 — the `RankRow`s: extract, curve, then mark or cap

First: **extract the duplicated inline `RankRow` to `components/RankRow.tsx`** — two identical page-local copies is the collector-helpers drift class, and this HO touches both. Then the curve under v3, per void: if it shows the leaderboard shape (void is the track, cap can't reach it), mark the **list container** (`data-viz-row` on the `ul`/`ol`, headers included per the table-not-rows clause), file `M1x <candidates>/<rows>` per route, add both to the registry at the sweep. If a cap or the reorder reaches it cheaply, do that instead and spend nothing. The commit body carries the curve either way.

Whatever `AmendmentRow`/`NominationRow` feed rows contribute beyond the RankRows: standard kit (decompose, pack, wrap-don't-pin).

Score: `--route amendments` 20 → ~0+M1x?, `--route nominations` 15 → ~0+M1x?, both decomposed with the curve pasted.

`fix(rank): HO 616 — RankRow extracted; amendments/nominations resolved by curve (marked or capped, evidence attached)`

## 3. Commit 3 — `/members`' 16, worked by its decomposition

Decompose under v3 first. Expected buckets: the 11 threshold-marginal rows (121–131px — if v3 still reads them, they're the knee's accepted cost and stay, stated), the header rows, `.mc-fbar` if any residue, the three strips (still off-limits per the 612 guard). Work only what falls outside those buckets; if nothing does, the commit is a no-op and the HALT says "decomposed to accepted residue, nothing to ship" — which is a legitimate close for a route whose knee was priced deliberately.

`fix(members): HO 616 — residual worked to its decomposition` (or no commit, stated)

## 4. P4 closes by its scope list — the SKILL rule's first enforcement

The HALT prints the eight-route scope table: `bills · news · amendments · nominations · hearings · members · lobbying · trades`, each with its v3 number and disposition (worked-to-zero / accepted-residue-decomposed / exempted-with-curve). **This table is what "P4 closed" means now**, and it's the artifact the sweep cites. If any route's disposition can't be stated in one of those three forms, P4 isn't closed and the HALT says so.

## 5. Verification and guards

1. Commits in order (§1–§3), typecheck + build each, explicit pathspecs; §3 may be a stated no-op.
2. Fixture legs run before any zero is trusted — all positives fire, all negatives silent, calibration exact. The fixture is the anchor now; no product-route dependency check needed, which is the first HO in the arc that can say that.
3. Per-route v3 tables at each stage; `/`, `/bills`, `/lobbying` spot-unmoved; narrow buckets (M5x/(b)) for the four routes, with the scroll-by-design entry's vocabulary available if a (b) item is a designed scroller — cite it, don't widen M5x here.
4. Any new `data-viz-row` marking: curve in the commit body, both units filed, registry addition queued for the sweep with the site M1x arithmetic updated. **No marking without a curve; no curve under v2.**
5. Eyeball 1440/2560 all four routes; prod-verify converged; **HALT** with the scope table, the curves, the decompositions. No P5 work, no sweep.
6. Absence Watch untouched. `/stale` untouched (P6a's, and its numbers are its own now that leg C is fixture-anchored). `--fs` tokens 9–14px.
