# HO 411 — senator election-year fix (derive from `terms[].class`) + create missing 2026 races

> Self-claim the next free number: `ls docs/handoffs/ | sort -V | tail`. If HEAD has moved past 410, renumber.
>
> This is the durable root fix for the drift HO 410 quantified. Scope is **the members year-pair derivation + creating the 6 missing race rows**. It is NOT the destructive race-table cleanup (correcting the CO card, deleting the CA/NY phantoms) — that is **HO 412, gated on this handoff verifying**. Code discipline: propose the derivation change, show diffs, no commit or push until approved.

## Verdict from HO 410 (resolved — don't re-derive)

18 of 100 current senators carry a `next_election_year` that disagrees with their Senate class, bidirectional, ±2/±4 years, hitting long-serving elected members (Cornyn, Markey, Booker, Wyden, Murkowski, Scott, Kelly, Schiff), not just appointees. Every flagged row except Armstrong still satisfies `next_election_year = current_term_end_year − 1` — internally consistent, wrong absolute anchor. That's a systemic sync-derivation bug (wrong `terms[]` entry / bad start-year+6), so the fix derives the pair from class deterministically, not per-senator overrides. `is_current` is clean (0/0). Mullin `M001190` `is_current=0` is **correct** (absent from `legislators-current.yaml`, resigned) — HO 404 mis-flagged it; do not treat it as an error.

The 18 target rows (+ the two OH/FL specials, handled separately below) are in the 410 audit output. Success is defined by re-running that audit, not by matching a list by hand.

## What canonical looks like

Senate class fixes the election cycle. Residues mod 6: **class 1 ≡ 2, class 2 ≡ 4, class 3 ≡ 0**. The next election for a class, from any date, is the smallest year `≥ currentYear` whose value mod 6 equals the class residue — computed from `new Date()`, **not hardcoded to 2026**, so it doesn't re-rot after November.

```
residue = { 1: 2, 2: 4, 3: 0 }[senateClass]
y = smallest year >= currentYear with (y % 6 === residue)
// November boundary: if y === currentYear and today is past election day
// (Tue after the first Mon of Nov), y += 6
next_election_year = y
current_term_end_year = next_election_year + 1        // regular seats only
```

Class comes from the **last** entry of each senator's `terms[]` array in `legislators-current.yaml` (`class: 1|2|3`). It is not currently in `members` (HO 404) — this handoff ingests it.

**Special-election exceptions (2026).** Ohio and Florida are Class-3 seats up in 2026 via special, filling remainder terms that end Jan 2029. They break the `ney = ctey − 1` invariant legitimately. Keep them in a small cycle-scoped, data-driven list checked **before** the class default:

```
data/senate-special-elections.json
[
  { "state": "OH", "bioguide": "<Husted — read from members/yaml>",  "cycle": 2026, "next_election_year": 2026, "current_term_end_year": 2029 },
  { "state": "FL", "bioguide": "<Moody — read from members/yaml>",   "cycle": 2026, "next_election_year": 2026, "current_term_end_year": 2029 }
]
```

Don't type the bioguides from memory — read them from the members table / yaml. These entries expire after the 2026 cycle (the seats revert to class-3 regular in 2028); note that in the file.

## Steps

**1. Ingest class.** `ALTER TABLE members ADD COLUMN senate_class INTEGER;` (safe, non-destructive; House rows stay NULL, which is correct). In the members sync (`sync:members` / whatever reads `legislators-current.yaml`), read `terms[last].class` into `senate_class` for every senator.

**2. Replace the derivation.** Locate the current `next_election_year` / `current_term_end_year` computation in the members sync (the wrong start-year+6 / term-selection logic) and replace it with: consult `senate-special-elections.json` first (match on state + current cycle); if matched, use its explicit pair; otherwise derive from `senate_class` via the residue formula above, with `ctey = ney + 1`. Delete the old derivation — we're not diagnosing the old bug, we're replacing it. Show the diff.

**3. Run the sync against prod Turso.** Expect: `senate_class` populated for all 100 current senators; year-pair corrected for the ~18 flagged rows; OH/FL carrying the special values (`ney=2026, ctey=2029`). Snapshot every senator's `(bioguide, senate_class, next_election_year, current_term_end_year)` before → after and confirm only the expected rows moved.

**4. Re-audit to zero.** Re-run `scripts/diagnostic/senator-year-audit-410.ts`. Success = **0 class-mismatches** in §2, OH/FL showing correct special values (not flagged), §1 impossible-values = 0 (Armstrong's odd 2031 resolved), §4 still clean. Paste the re-audit headline.

**5. Create the 6 missing races.** With member years now correct, run `backfill:races` (it's `INSERT OR IGNORE` — pure creation, touches no existing row). This files the 6 seats that were missing because their holders had drifted off 2026: **NJ (Booker), MN (Smith), MS (Hyde-Smith), NE (Ricketts), OH (Husted, special), FL (Moody, special)**. After the fix every state is unambiguous (exactly one senator per state at `ney=2026`), so the derivation is deterministic — confirm each of the 6 new rows got the right incumbent. Report which race rows were created.

**6. Promote the audit to a standing guard.** Commit `scripts/diagnostic/senator-year-audit-410.ts` as the permanent regression probe (it's currently uncommitted). An internal-only `ney=ctey−1`/even check catches just 1 of 18 — the guard needs the class cross-check, which now works because class is stored. Note in the script header that OH/FL-style specials are expected exceptions.

## Sequencing + discipline

- **Members before backfill, hard order.** Step 5 must not run until steps 3–4 verify. Running backfill against unfixed member years would null MA/TX (currently zero senators at `ney=2026`, displaying correctly only from pre-drift rows). Verify the member fix first.
- Show diffs for the sync change, the migration, and the special-list file before committing. Explicit pathspec on add + commit. Ancestry re-checked before push. Nothing pushed until approved.
- The migration + sync run write to prod, but they're the sync doing its normal job (idempotent upsert of member rows), not an ad-hoc mass update. No destructive ops in this handoff — all deletes live in 412.

## After this verifies — HO 412 preview (do not do here)

The root fix leaves three stale artifacts in `races` that `INSERT OR IGNORE` can't touch, which 412 handles as destructive/surgical cleanup behind print-before-delete:

- **Correct 1 wrong card:** `S-CO-2026` still shows Bennet (B001267, class 3). After the fix only Hickenlooper (H000273, class 2) sits at `ney=2026`, but the existing row won't auto-update. 412 either changes `backfill:races` to `ON CONFLICT(id) DO UPDATE SET incumbent_bioguide_id = excluded.incumbent_bioguide_id` (self-healing, scoped to that one column so it never clobbers rating/margin/incumbent_running/roster; seed:races still runs last for genuine overrides) or does a targeted UPDATE. Recommend the upsert for defense-in-depth.
- **Delete 2 phantoms:** `S-CA-2026` (Padilla, class 3, up 2028) and `S-NY-2026` (Gillibrand, class 1, up 2030) — neither state is up in 2026; the cards exist only because those rows wrongly said `ney=2026`. After the fix backfill won't recreate them, but the stale rows persist until explicitly deleted. Check dependents (race_ratings, race_candidates keyed by race_id) and print before deleting.

Also note for 412's scope, not a blocker: whether the 6 newly-created races appear on the `/races` LIST depends on `race_ratings` existing for them (getRacesIndex is the INNER JOIN); rating coverage for the new seats is a separate question, not part of the year fix.

## Doc sweep

Hold until 411 + 412 both land, then one docs-only commit: close the integrity OPEN LOOP in `backlog.md` (record it was systemic — 18 rows, derive-from-class, not the churn HO 404 implied); `oddities.md` note that `members` now carries `senate_class` and year-pairs derive from class + a cycle-scoped special-election list (specials legitimately violate `ney=ctey−1`); `SKILL.md` line on the derivation + the standing guard (trips the self-mod guard — re-approve). Correct the HO 404 Mullin mis-flag in whichever doc carried it.
