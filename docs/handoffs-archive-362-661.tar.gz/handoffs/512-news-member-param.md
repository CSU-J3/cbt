# HO 512 — `?member=` on `/news` + the Press-tab out-link

## Context

The record box (HO 509) gives the Bills and Trades tabs out-links (`View all N bills →` `/bills?sponsor=`, `View all N trades →` `/trades?member=`) but Press has nowhere to go: `/news` (HO 501) carries `source`/`topic`/`window`/`bill`/`signal` only. This HO adds a member-scoped view to `/news` and lights the Press tab's out-link. Backlog line ~67 is the source item.

**Premise correction — read before building.** The backlog's close-path says "`getNewsFeed` already joins `observation_entities`, so a `person`-bioguide filter mirrors `getMemberNews`." That is wrong on the mechanism. `getNewsFeed` drives `news_mentions m INNER JOIN bills b` (lib/queries.ts ~4240) and never touches the observation tables. A person-filter bolted onto the mention feed would show only articles that mention the member AND matched a bill — a strict subset of what the Press tab previews (most of a member's press has no bill match), so the out-link would land on fewer rows than the tab it came from. Do not build that. Member mode is a **branch to the observation layer** — the way `?bill=` is a semantic branch, not just a WHERE clause — served by the existing `getMemberNews`. Zero `lib/queries.ts` changes.

## Scope

Three files, one feature commit:

1. `app/news/page.tsx` — parse `member`, branch fetch + render
2. `components/NewsFilters.tsx` — a member pill mirroring the bill pill (single-consumer since HO 501, confirmed by the HO 500 probe)
3. `app/members/[bioguideId]/page.tsx` — Press tab gains `outLabel`/`outHref`

## 1. `/news` member mode

**Parse.** Copy the trades page's page-local `parseMember` (`app/trades/page.tsx:24`) — same bioguide shape-check, kept page-local, don't extract a shared helper for a two-consumer 5-liner.

**Precedence.** When `member` parses, it owns the view: `bill`/`source`/`topic`/`window`/`signal`/`page` are ignored (not errored — just not applied, and not carried). The pill's ✕ returns to bare `/news`. Bare and `?bill=` behavior stays byte-identical.

**Fetch.** `Promise.all([getMemberNews(bioguideId, NEWS_MEMBER_CAP), getMember(bioguideId)])`.
- `const NEWS_MEMBER_CAP = 50` — file-local to `app/news/page.tsx` (the HO 493 file-local-constant precedent; `PAGE_SIZE` on `/lobbying` is the sibling).
- `getMemberNews` already carries the `member-news` cache tag (HO 414), flushed by the news cron and allowlisted on `/api/revalidate` — **no cache wiring in this HO**.
- `getMember` null (valid-shape but unknown bioguide): don't 404 — render member mode with the raw id as the pill label and the empty state. Parse-fail: drop the param, unscoped feed.

**Render.** HeaderBar / GroupTabs / the LEGISLATION|NEWS toggle unchanged (`buildModeHref` already carries all params on the idempotent NEWS click and drops to bare `/bills` on LEGISLATION — correct as-is). In member mode:
- `NewsFilters` gets `memberId` + `memberLabel` (below); `Pagination` is not rendered (no pages in this mode).
- Rows: `<RaceNewsRow item={n} nowMs={nowMs} />` — the member-hub idiom — inside the same bordered list container the mention rows use. Pass the page's existing `nowMs` (line ~50); never `Date.now()` in a row (the HO 490 class).
- Empty state: `No recent news linked to this member.` — the exact HO 414 string.

## 2. NewsFilters member pill

Add optional props `memberId?: string; memberLabel?: string`. When `memberId` is set, **early-branch: render only the member pill row** — skip the source/topic/window/signal chip rows and the bill pill entirely. Those dims don't exist on observation rows; dead chips would imply filtering that isn't happening. (Bill mode keeps its chips because bill-scoped rows are still `news_mentions` — that asymmetry is correct, note it in a comment.)

Pill mirrors the bill pill block exactly: label is a `<Link>` to `/members/<bioguideId>`, ✕ is a `<Link>` to bare `basePath` with `aria-label="Clear member filter"`.

## 3. Press tab out-link

In the member page's tab array (`key: "press"` block, ~line 480):

```
outLabel: news.length > 0 ? "View press coverage →" : undefined,
outHref:  news.length > 0
  ? `/news?member=${encodeURIComponent(member.bioguideId)}`
  : undefined,
```

**No count in the label.** `count: news.length` is the `getMemberNews(…, 8)` cap, not a total — Bills/Trades have real totals to print, Press doesn't, and a count query is out of scope. Don't fabricate "View all N".

## Non-goals (recorded so they aren't re-litigated)

- **No `getObservationNews` fold.** The HO 414 debt triggers on a 3rd *projection* over the observation layer; this is a 3rd *caller* of the existing `getMemberNews` at a raised limit — the HO 470 precedent line ("adds callers, not a third projection") applies. Leave the code debt note where it is.
- No pagination, no total-count query, no window/signal semantics on observation rows.
- No challenger / non-bioguide handling (the known HO 398 coverage edge).
- No `getNewsFeed` changes of any kind.

## Verify

- `npm run typecheck` + build green locally; CI green on push (HO 488 runs both).
- Prod after deploy:
  - `/news?member=J000299` (the HO 414 heavy member) — pill + rows render, sources/dates sane.
  - `/news?member=A000055` — empty state.
  - Pill ✕ → bare `/news`; pill name → the member hub.
  - `/news` and `/news?bill=<known id>` byte-identical to pre-change (containment).
  - Member hub Press tab shows the out-link, lands scoped; a zero-news member shows no out-link and the tab dims at (0) as before.
- Console clean on the scoped view.

## Process

Diff shown before commit, explicit pathspec staging, fast-forward push, ancestry eyeball. Code and docs never ride together — the sweep is HO 513 and **must** correct backlog line ~67's false "`getNewsFeed` already joins `observation_entities`" mechanism claim in its tombstone, add the roadmap "Also (HO 512)" block, and give the SKILL `/news` entry the member-mode line.
