# HO 495 — filtered topic-distribution cost probe

Read-only diagnostic. **No schema, no index creation, no surface, no build.** Commit the script as a sibling to the other `scripts/diagnostic/` probes and report the numbers.

## Why

The `/bills` two-pane redesign puts a 24-topic rail on the left, with counts that **rebase on the other active filters** — select `stage=floor` and Healthcare shows floor-stage healthcare bills, not all 2,140. That's a per-render aggregate over `bills` with `stage` / `chamber` / `q` / `ceremonial` predicates.

This is the query shape that has hurt most in this codebase. **HO 382**: the `EXISTS (SELECT 1 FROM json_each(bills.topics) …)` clause had no usable column on `idx_bills_summary_stage`, so topics got row-fetched across the whole ~15k corpus — defense hit 28s and the `/?topics=` filtered view 500'd. Only fixed by pinning `INDEXED BY idx_bills_summary_stage_topics`. Stack the recurring OR-predicate cold-stall class (HOs 405, 407, 479–481) on top and this needs measuring before anything is spec'd.

## Step 0 — read the existing helper first; don't assume

`getTopicDistribution` already exists at `lib/queries.ts:704` and takes `(filters, boolean)`. `app/page.tsx:97` calls it as `getTopicDistribution(filters, true) // treemap — rebases on STAGE`, so **some** filtered rebasing may already work. The prior plan for this redesign logged "existing `getTopicDistribution()` — no new query needed," and that's a claim, not a fact.

Report verbatim, before running anything:
- Full signature and what the second boolean argument does.
- **Which filter dimensions it actually applies today** — stage only, or more?
- The SQL, including any `INDEXED BY` hint already present.
- The `unstable_cache` key and tags.

If it already covers every dimension, this probe is mostly a timing exercise. If it only handles stage, say so plainly — that changes the build.

## Step 1 — plans

`EXPLAIN QUERY PLAN` for the current query and each filtered variant below. Report each plan **verbatim** and name the index chosen. Flag any `SCAN`, `USE TEMP B-TREE`, or `MULTI-INDEX OR`.

**A clean plan is not a pass** — the standing rule is that `EXPLAIN` says nothing about cold latency. Time everything regardless.

## Step 2 — cold timings

Run the **worst realistic combination first**, before any other query warms the connection. That first number is the verdict; everything after is diagnostic.

Time each, reporting ms and row count:

| # | Filters |
|---|---|
| 1 | none (today's dashboard baseline) |
| 2 | `stage` only |
| 3 | `chamber` only |
| 4 | `stage` + `chamber` |
| 5 | `ceremonial` included |
| 6 | `q` (free-text search) alone |
| 7 | `q` + `stage` + `chamber` |

For `q`, use a term that matches broadly (`"act"`) and one that matches narrowly — the `LIKE` fans across id, title, sponsor_name, and summary, so selectivity will swing the cost hard.

## Step 3 — self-exclusion

Rail counts must rebase on everything **except** the topic selection, because topics filter with OR (`topicClauses.join(" OR ")`, `lib/queries.ts:247`) and a count has to predict what clicking does. Confirm this is simply "run without the topic clause" and that nothing in the existing helper couples the two. If it does couple them, that's a finding.

## Step 4 — cache-key blowup

Today the key is fixed (`["getTopicDistribution"]`). Filter-dependent counts mean the key carries the filter tuple.

Report the realistic key cardinality. The bounded dimensions are small — stage × chamber × ceremonial is a few dozen. **`q` is unbounded**: every distinct search string becomes its own cached aggregate.

Then give a recommendation: **should the rail rebase on `q` at all?** If free-text pushes the aggregate into a bad place, the defensible product answer is that the rail rebases on the bounded dimensions only and ignores search — search is a needle-finder, the rail is a browse spine. I'd rather take that trade than ship a rail that stalls on typing. Report the numbers and say what you'd choose.

## Step 5 — the index question

For each variant, report which index the planner picks and whether it needs an explicit `INDEXED BY` hint to behave — specifically whether `idx_bills_summary_stage_topics` (the HO 382 fix) covers the chamber and `q` dimensions or only stage.

**If the finding is that a new index is required, report it and stop.** Do not create it. Index creation is a migration and gets its own HO.

## Verdict

- **GO** — worst realistic combo under ~500ms cold. This sits on the render path of every `/bills` load, so the bar is tighter than a one-off drill.
- **PARTIAL** — bounded dimensions are fine but `q` isn't. That's a perfectly good outcome; it just means the rail doesn't rebase on search.
- **NO-GO** — even bounded rebasing is slow. Then the rail shows unfiltered corpus counts and says so, and we revisit.

Report the per-variant numbers either way. They decide which dimensions rebase, which is the actual output of this probe.

## Constraints

- Read-only. No `INSERT`/`UPDATE`/`CREATE INDEX`/migration.
- No changes to `app/`, `lib/`, `components/`.
- No build, no surface — that's the follow-up HO once this verdicts.

## Git discipline

- Clone / hard-reset to `origin/main` first — HEAD should be **`e5e2177`** (HO 494 skill commit).
- Commit only `scripts/diagnostic/topic-distribution-filtered-495.ts`, explicit pathspec, never `git add .`.
- Inert diagnostic → approve on summary, but show the ancestry eyeball before push (`git log --oneline @{u}..HEAD`, one commit riding, clean fast-forward, no concurrent-session files touched).
- `npm run typecheck` clean before push — this is what broke at `3ed533c` on a probe commit, and CI will now catch it, but catch it first.
- Message: `chore(diag): probe filtered topic-distribution cost (HO 495)`.

## Report back

Step 0 verbatim (signature, dimensions actually supported today, SQL, existing hint, cache key), then the plans, the seven cold timings, your `q`-rebasing recommendation, and the index verdict.

---

read docs/handoffs/495-topic-distribution-probe.md and follow it
