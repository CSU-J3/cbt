# HO 486 — /lobbying members-style redesign (build)

Restructure `/lobbying` into the `/members` two-pane browser, and make filing rows expand inline. Forks settled, probe (HO 485) GO. **One HO, two commits** (A = chrome, B = expand) — each diff-reviewed. Code only, no docs, no migration, no cron.

## Frame

Current `/lobbying` = 5 stacked sections (readout → `IssueBars`|`IssueDrill` two-column → `TopicCrosswalk` → `FirmsLeaderboard` → paginated feed). Target = the `.mc-*` two-pane: LDA issue codes are the rail spine (like committees), the right pane is a filings browser with expandable rows. Data comes from the existing `getLobbyingRollup()` blob (`{stats, issues, drill}`) + `getRecentFilings()`; the **only** new query is the expand read (HO 485-cleared).

## Out of scope — do NOT build these

- **A live paginated per-issue feed.** Scoping an issue keeps serving the precomputed `drill[code]` (who's-who + `drill[code].recent` sample), NOT a complete per-issue browse. A live per-code feed is the HO 437 abandoned query (>25s cold). The pager stays on the **unscoped corpus feed only**. This is the deliberate divergence from members (committee scope = full roster; issue scope = drill sample), forced by the query-cost reality — state it in a code comment, don't try to "fix" it.
- **fbar filters/search/sort.** The mockup showed a sort seg + bill-linked toggle + search; each needs a new query or capability outside this redesign. The v1 fbar is the scope-reflecting **count only**. Deferred as follow-ups.
- **Rail ISSUES/TOPICS toggle** (fork 3 dropped) — single issue rail. `TopicCrosswalk` stays a section below the pane (it doubles as the topic-color legend).
- **Keystrip** — dropped. Rail bars are single-topic-colored; the crosswalk below is the legend. No `mc-keystrip` on this page.
- **Lobbyist names / government entities** — not ingested (no table). Panel is `lda_activities` + `lda_activity_bills` only.

## Kept below the pane (unchanged)

`FirmsLeaderboard` (Section 4) and `TopicCrosswalk` (Section 3, HO 444/463 interactive) render **below** the two-pane, as-is. Don't touch their internals.

---

## Commit A — chrome restructure (two-pane, rows flat)

### Page (`app/lobbying/page.tsx`)
Replace Sections 1–2 + 5 with:
- **Corpus readout** (keep Section 1: `Lobbying` + the stats line; trim the blurb to one sentence).
- **`mc-fbar`** — scope-reflecting count only:
  - unscoped → `{stats.filings} FILINGS · {stats.clients} CLIENTS`
  - scoped (`?issue=`) → `{drill.filings} FILINGS · {drill.distinctClients} CLIENTS · {drill.display}`
  - Use `.mc-fbar` + `.mc-fbar-count` + `.mc-fbar-n` (existing). Left-aligned, spacer after. Nothing else in the bar.
- **`mc-pane`** (`grid 312px 1fr`, existing):
  - **rail** (`.mc-rail`): header `.mc-rail-h` → `ISSUES · {issues.length}`; then map `rollup.issues` → `<IssueRailRow>` (new, below).
  - **content** (`.mc-content`, wrapped so grid overrides scope — see CSS):
    - **scoped only** (`?issue=` set): `.mc-ctx` (code + display + `· {filings} filings · {distinctClients} clients · {billLinked} bill-linked` + spacer + `× all filings` → clears `?issue=`), then the **who's-who** 2-col strip (below).
    - **column header** `.mc-row-hdr` (grid matches the filing row): empty · `AGE` · `REGISTRANT → CLIENT` · `ISSUES` · `BILLS`.
    - **rows**: the filing list. Unscoped → `getRecentFilings({page})`. Scoped → `drill[code].recent`. Both are `FilingSummary[]` → `<FilingRow>` (grid-aligned; flat in commit A).
    - **pager**: `<Pagination>` **only when unscoped** (corpus feed, `MAX_FEED_PAGES` clamp preserved). No pager in the scoped view.
- Pre-first-cron null guard (`!rollup`) stays — the honest empty state is unchanged.

### `IssueRailRow` (new, `components/IssueRailRow.tsx`, `"use client"`)
Mirror `CommitteeRailRow`'s scope idiom on `?issue=`:
- Reuse the `.mc-crow` shell (padding/border/hover/`is-sel`) — grid overridden in CSS under the rail wrapper.
- Cells: `.mc-crow-tag` = issue `code` · `.mc-crow-name` = `display` · `.mc-crow-act > .mc-crow-act-f` (bar) · `.mc-crow-mem` = `filings.toLocaleString()`.
- **Bar fill inline-colored by CBT topic**: `style={{ width: pct%, backgroundColor: topicColor(topicForCode(code)) }}` — overrides the fixed `--stage-committee`. `pct` = `filings / maxFilings * 100` (max over `issues`). Drop the `.mc-crow-mark` dot (no on-marker for issues).
- Click sets/clears `?issue=code` (re-click clears), drops `?expanded=` (an open filing may not be in the new scope) — the `CommitteeRailRow.scope()` pattern exactly. `router.push(..., { scroll: false })`.
- Name is NOT a link (no entity route for issues) — plain span.

### Who's-who strip (scoped only)
Reuse the existing `LobbyingMiniBars` — no new component. A 2-col wrapper (`.lob-ww`) holding `<LobbyingMiniBars label="Top clients" rows={drill.topClients} />` and `<LobbyingMiniBars label="Top firms" rows={drill.topFirms} />`, rendered right under `.mc-ctx`.

### `FilingRow` (modify — grid only in commit A)
Convert the flex-wrap layout to a grid that aligns with the column header: caret-slot · age · `registrant → client` · issue chips · bill chips. In commit A the caret slot is empty (rows flat). Keep the existing chip rendering (`micro-tag` issue codes, amber `bill-chip` links, `+N` overflow) and the income/expenses `title` tooltip. Grid set in CSS under the content wrapper.

### CSS (`app/globals.css`)
**Scope every grid override under lobbying wrapper classes so the shared `.mc-*` (used by `/members`) is untouched.** Add a wrapper class on the lobbying `.mc-rail` and `.mc-content` (e.g. `lob-rail` / `lob-content`), then:
```css
.lob-rail .mc-crow { grid-template-columns: 44px 1fr 56px 48px; }      /* code | name | bar | 5-digit count */
.lob-content .mc-row { grid-template-columns: 16px 52px 1fr auto auto; } /* caret | age | reg→client | issues | bills */
```
Plus the who's-who 2-col + cell classes (`.lob-ww`, columns split by a `--border-soft` rule) and any filing-row cell classes (age = `--text-dim` tabular, `reg` = `--text-primary`, arrow = `--text-dim`). Pull the exact rules from the mockup (`lobbying-redesign-mockup.html`, the `.ww*` / `.mc-party` / `.mc-age` blocks). Verify `/members` renders byte-identical after (the shared `.mc-crow`/`.mc-row` grids must be unchanged — the overrides only fire under `.lob-*`).

### Commit A verification
- Unscoped `/lobbying`: rail lists issues (topic-colored bars, VOL-desc), content = corpus feed + pager, fbar shows corpus count. No `mc-ctx`, no who's-who.
- Scoped `/lobbying?issue=BUD`: `is-sel` on the BUD rail row (amber border), `mc-ctx` + who's-who render, content = `drill.recent`, **no pager**, fbar shows BUD count + display.
- `× all filings` clears the scope. Rail re-click clears.
- `/members` unaffected (diff the shared `.mc-*` rules = none changed).

---

## Commit B — expandable filing rows

### `getFilingActivities` (new, `lib/queries.ts`)
Two PK-prefix reads (both HO 485-timed fast), parallel; chip from the **resolved** set, not the raw `bill_ids` JSON (probe finding #5 — dead-link avoidance):
```ts
export async function getFilingActivities(filingUuid: string) {
  return unstable_cache(
    async () => {
      try {
        const db = getDb();
        const [acts, bills] = await Promise.all([
          db.execute({
            sql: `SELECT activity_ordinal, general_issue_code, general_issue_code_display, description
                  FROM lda_activities WHERE filing_uuid = ? ORDER BY activity_ordinal`,
            args: [filingUuid],
          }),
          db.execute({
            sql: `SELECT activity_ordinal, bill_id FROM lda_activity_bills WHERE filing_uuid = ?`,
            args: [filingUuid],
          }),
        ]);
        const byOrdinal = new Map<number, string[]>();
        for (const r of bills.rows) {
          const o = Number(r.activity_ordinal);
          (byOrdinal.get(o) ?? byOrdinal.set(o, []).get(o)!).push(String(r.bill_id));
        }
        return acts.rows.map((r) => ({
          ordinal: Number(r.activity_ordinal),
          code: (r.general_issue_code as string) ?? null,
          display: (r.general_issue_code_display as string) ?? null,
          description: (r.description as string) ?? null,
          bills: byOrdinal.get(Number(r.activity_ordinal)) ?? [],
        }));
      } catch {
        return null; // a bad read hides the panel, never 500s the page
      }
    },
    ["filing-activities", filingUuid],
    { tags: ["lda"] },
  )();
}
```
Do NOT select `lda_activities.bill_ids` (raw extracted JSON, 44 ids on the worst row — superset of the resolved subset).

### `FilingRow` (add expand)
- Caret in the first cell (`.mc-caret`): `▸` dim / `▾` amber when expanded.
- The row becomes a `<Link>` toggling `?expanded=<filingUuid>`, **carrying** the current `?issue=` and `?page=` (mirror the members `rowHref`; `replace scroll={false} prefetch={false}`). Bill chips keep their own `stopPropagation` so they still deep-link without toggling the row (the HO 466 idiom).
- `is-expanded` → `.mc-row.is-expanded` background (existing).

### `FilingExpandPanel` (new, `components/FilingExpandPanel.tsx`, server)
Receives the pre-fetched `activities` + the row's `FilingSummary`. Renders under the expanded row. Sized to the HO 485 shape:
- **Header** (filing-level, from `FilingSummary`): `registrant → client` · `filing_period` (if present on `FilingSummary`; if not, add it to the `getRecentFilings` + drill SELECTs — it's a stored `lda_filings` column) · amount (`income $…` / `expenses $…` — promote from the tooltip).
- **Per-activity list** (`activities`, ordered by `ordinal`): each row = `[{code} · {display}]` label + the **description** + resolved **bill chips**.
  - **Description** in a `max-height: ~140px; overflow-y: auto` box (p99=1,838, max=24,447 chars — never render raw; the scroll box is v1, a line-clamp + "show more" is a fast-follow). Sans font like the other expand-panel bodies.
  - **No empty-state branch** — description is 0.0% empty (probe); assume present.
  - **Bill chips** = the activity's resolved `bills`, capped ~8 + `+N more` (a filing carries up to 449 total; per-activity modest — the cap keeps a heavy activity's row sane). Amber `bill-chip` → `/bill/[id]`.
- No sub-pagination on the activity list (max 31 rows — probe).

### Page wiring
```ts
const expandedUuid = sanitizeFilingUuid(params.expanded); // add sanitizer, mirror sanitizeIssueCode
const activities = expandedUuid ? await getFilingActivities(expandedUuid) : null;
```
Render `<FilingExpandPanel activities={activities} filing={f} />` under the row whose `filingUuid === expandedUuid` (works identically for unscoped feed rows and scoped `drill.recent` rows — both `FilingSummary`). If `expandedUuid` isn't in the current set, nothing attaches (the members constraint — fine).

### CSS
Expand-panel classes (pull from the mockup `.mc-exp*` block) under `.lob-content`. Reuse the `.sponsor-expanded-panel` `--bg-row-hover` background idiom.

### Commit B verification
- Expand a corpus-feed filing: caret flips, panel renders per-activity code/display + description + resolved bill chips; a long description scrolls inside its box; a many-bill activity shows `+N more`.
- Expand carries scope: `?issue=BUD&expanded=<uuid>` keeps BUD scoped with the panel open; `?page=3&expanded=<uuid>` keeps page 3.
- Expand a scoped `drill.recent` filing — same panel.
- A filing with a resolved bill chips only the resolved set (cross-check: raw `bill_ids` count > chip count on the ENV-heavy type of row).
- Bad/absent `?expanded=` → no panel, no error. Pre-first-cron null guard intact.

---

## Git discipline

- Clone / hard-reset to `origin/main` first — HEAD should be **`3ed533c`** (HO 485). Establish ground truth.
- Explicit pathspec staging per commit; never `git add .`. Files touched: `app/lobbying/page.tsx`, `components/IssueRailRow.tsx`, `components/FilingRow.tsx`, `components/FilingExpandPanel.tsx`, `lib/queries.ts`, `app/globals.css`.
- **Surface build → show the actual diff hunk and wait for approval before each commit** (not approve-on-summary — this is live UI).
- Two commits: A `feat(lobbying): members-style two-pane browser (HO 486)`, B `feat(lobbying): expandable filing rows + per-activity detail (HO 486)`. Working state after A.
- Ancestry eyeball before each push: `git log --oneline @{u}..HEAD` = the expected commit(s) riding, clean fast-forward, no concurrent-session files touched. Fast-forward only, no force-push.
- No docs in these commits — the roadmap sweep is a separate HO.

## Report back

After A: the page diff + a note that `/members` renders unchanged. After B: the `getFilingActivities` diff + panel behavior on a heavy filing (long description scroll, bill-chip cap). Then it's live-verify + the doc sweep.

---

read docs/handoffs/486-lobbying-redesign-build.md and follow it
