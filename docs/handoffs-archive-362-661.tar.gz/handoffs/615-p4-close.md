# HO 615 — the P4 close: instrument v3 + the fixture, the exemption extension, the rail, the v3 crawl, and the sweep.

HEAD `cc1b32f`. Pointer "run through HO 610." **Next free is 615.** This HO retires every deferral P4 accumulated. Order matters: **the instrument lands first** so everything after it is scored on the final ruler, and the sweep lands last because its claims cite the crawl.

Two HALTs: after the crawl with the full table, and on the review ref with the diffs.

---

## 1. Commit 1 — instrument v3 and the fixture

`diag(layout): HO 615 — instrument v3: ink-span banding, M5 declipped, leg C moves to a fixture with negative controls`

**v3's measurement changes** — definitions, not thresholds, same discipline as v2:

- **Multi-rect / wrap handling (M1):** an element's band membership is its **ink span** — the union bbox of its client rects. An element occupying bands 100–105 is *present in every band it overlaps*, so a gap can never be measured across it (the four worked examples: 610's breaking row, 613's `/bills` bar and `/trades` rows, 614's wrapped rc cell). Gap = nearest ink-edge between horizontally adjacent ink spans that share band overlap.
- **M5 extra-wrap:** same overlap clustering v2 gave M1; the `round(centreY/4)` bucketing dies here too (the 611 `.hcal-agenda-head` false positive is the worked example).
- **M5 overflow:** elements whose own computed style declares `text-overflow: ellipsis` or a `line-clamp` split into a separate counted column (call it **M5x, design-clip**) rather than polluting (b)-real. Raw totals stay printed for continuity with the bucket tables.

**Leg C becomes the fixture.** `scripts/diagnostic/fixtures/layout-legc.html`, committed, loaded via `file://` by the audit, versioned with the instrument, structurally immune to remediation:

- **Positives (must fire):** a ≥600px row with a ≥300px far-right interior gap; a bordered panel with >40px trailing slack; a ≥40px reserved empty box.
- **Negatives (must stay silent), marked `data-legc-clean`:** a single-line row mixing `--fs-9`/`--fs-14` children on one baseline (v2's banding false positive); a row with one wrapped two-line cell between single-line neighbours (v2's phantom-gap artifact); an ellipsized cell in a packed row (must land in M5x, not M5-real) beside a genuinely overflowing cell (must land in M5-real) — the M5 pair calibrates here permanently too.
- **Calibration (must count exactly):** a three-row `label · bar · value` block marked `data-viz-row` — reads as M1x = 3, never as M1 hits, never absent. Leg B then owns an off-product anchor for the day the live funnel changes shape.
- Leg C passes only when **every positive fires and every negative doesn't** — silencing and over-firing are now both caught, permanently, by the same leg. `/stale` retires as anchor with thanks.

**Falsify v3 before anything else runs on it**, A/B/C:

- **A (known-good clears):** `/lobbying`'s 11 artifact rows and `/trades`' ~52 must drop to ~0 under ink-span banding, with the real 47px gaps still reported as under-threshold.
- **B (exemptions stable):** the fixture's calibration block reads M1x = 3 exactly, and the live funnel holds 13 pre-commit-2 — neither grows, shrinks, nor leaks into M1.
- **C (the fixture):** as above, both directions.

Print all three legs. A near-zero site-wide M1 after v3 is *expected* in the artifact classes and **C is what distinguishes correction from silencing** — the arc-md sentence applies verbatim.

## 2. Commit 2 — the exemption extension, with its numbers in the message

`data-viz-row` on `FirmsLeaderboard` and `TopicCrosswalk` row containers. The commit body carries the 614 evidence (611px / ~600px label spreads; cap-260 → 8 clipped and 44 still over) and the standing creep guard verbatim: *the attribute marks rows containing a bar or shared-axis encoding, never plain text tables, and every new marking ships with its curve.* Score: `/lobbying` M1 drops ~48 into M1x; M1x site total ≈ 13 + the new count, printed.

`feat(lobbying): HO 615 — FirmsLeaderboard + TopicCrosswalk are axis encodings; exempted, counted, curves attached`

## 3. Commit 3 — the `.mc-pane` rail, scoped by measurement first

The 612 filing says the 312px rail never collapses and `/members` has a hard 883px minimum; the shared-with list (`/lobbying /bills /news`) is a **class-presence claim, not a failure claim** — 613/614 showed those three clear doc-width at 720. So: measure which routes actually fail doc-width at 720 post-`cc1b32f` (expected: `/members` alone, possibly `/committee/[id]` — check its roster embed), then fix where it fails: below ~900px the rail stacks under the content as a full-width section (C8's inverse, the BillExpandPanel precedent), no disclosure widget unless stacking proves unusable in the eyeball. Acceptance: every failing route clears doc-width at 720; bucket (b) → 0 there; wide layouts byte-identical at 1024+.

`fix(members): HO 615 — the rail stacks below ~900px; the 883px floor dies (C8 inverse)`

## 4. Commit 4 — `HearingsList` leaves

Zero consumers (611's grep). `git rm components/HearingsList.tsx`; its CSS goes **per-selector with a positive control** (grep one live selector first to prove the grep works, then the dead ones — the `.pdc` discipline). If any selector turns out shared, it stays and the HALT says which.

`chore(hearings): HO 615 — HearingsList removed (zero consumers since the HO 611 agenda)`

## 5. The v3 crawl — the P5/P6 baseline

Full pass: 26 routes at 2560, the 6-route subset at 1024/900/720, fixture leg C throughout. **Every number is v3 and comparable only to v3** — the table header says so, era-labeled (v1 / v2 / v3 are three rulers; the roadmap block restates it). Print: per-route M1/M1x/M2/M3/M4 + the narrow buckets with the new M5x column, the burn ledger, and the delta-vs-v2 for the routes P4 touched *with the artifact share annotated* (a route dropping because v3 stopped lying about it is an instrument note, not a remediation claim — the block must not launder artifact removal as layout work).

**First HALT here.** Include the proposed P5/P6 plan sized from the table: expected shape is `/stale` (the momentum-overlay 50, P6), `/member-detail` and `/committee-detail` (P5), `/patterns`/`/reports`/the rest as one or two batch HOs if their residuals are small, `/changes` closing near-done. Propose, don't start.

## 6. The sweep — `refs/heads/615-review`, docs commit + SKILL commit

**Roadmap block, 611–615, pointer → 615.** The P4 story: per-route before/after (era-labeled), the anchor-expiry trilogy (612 planned → 613 by shared component with the fallback save → 614 exhaustion → the fixture with negative controls), the kit as it actually accreted (decompose-first · derive-don't-tune · the knee · the two-ended derivation · the wrap-cap · wrap-don't-pin · dependency-grep for anchors · re-anchor rides the expiring commit), the chip rule's reference row (`FilingRow`: 31 labels to plain text, 181 interactive chips keep the border), the three step-0 premise corrections, the orphan-comment base rate (IssueDrill true-but-stale; HO 300 false; the hearings header stale — comments are hypotheses), and the multi-rect saga ending with remediation *producing* the artifact wrap fix by wrap fix until v3 measured ink instead of rects.

**Backlog:** P4 SHIPPED entry; DONE strikes — ActiveFilterStrip, the `.mc-pane` item (with the measured scope), HearingsList, the M5-debt entry (instrument side resolved by v3; any product-side residue re-filed with numbers); the **exemption registry** gets its own small entry (funnel + FirmsLeaderboard + TopicCrosswalk, each with its curve, plus the creep guard); the P5/P6 plan from §5's table replaces the stale ordering.

**Oddities (append at end):** (1) the external pin — `.control-sort { margin-left:auto }` pinned a bar from outside the component; trace computed styles to their source rule, containers don't confess. (2) the two-ended cap — derived against one end's ink, off by the other end's ~27px; both ends or wrong. (3) wrap-caused multi-rect — C1 remediation manufactures the exact geometry that breaks centre-band gap measurement; v3's ink-span is the fix and the fixture's negative control is the regression trap.

**Arc-md:** three new sections — *The remediation kit* (the list above, as method), *Instrument v3* (definitions + the era table: v1/v2/v3, what each can and cannot read, comparability rule), *The fixture* (why leg C left the product, both-direction contract). The §3 audit spec gets an era pointer instead of edits.

**SKILL (own commit, tight):** two additions only. The exemption rule (`data-viz-row`: axis encodings only, counted, curve attached, never plain tables). The anchor rule (falsification anchors are stated in dependency terms and live in fixtures, not product routes; product anchors expire by remediation — the trilogy is the citation).

**Second HALT on the ref** with the block and both diffs. Gates at land: pointer greps ("HO 610" ×1, "HO 615" ×1), oddities in the final section, DONE strikes present, era labels present in the block.

## 7. Guards

1. Commits §1→§4 in order; crawl before sweep; typecheck + build each; explicit pathspecs; code and docs never mixed.
2. P5/P6 routes untouched except via instrument or shared-class effects, labeled as such in the table.
3. Absence Watch untouched, phase after phase, still.
4. `--fs` tokens 9–14px. No new exemptions beyond §2's two. The fixture is the only new HTML.
5. Anything that resists its commit's acceptance gets reported decomposed, not forced — the phase closes on honest numbers or it doesn't close.
