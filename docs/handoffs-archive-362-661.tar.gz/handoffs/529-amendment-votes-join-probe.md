# HO 529 — amendment → roll-call-vote join probe (is it already free?)

The banked `recordedVotes` item (HO 452 QUEUED) assumes a member-level "how did each member vote on this amendment" surface needs an **`/actions` walk** (~2× the amendments backfill) to recover each voted amendment's roll-call number. **That premise is very likely wrong, and this probe tests it before any build.** The `votes` table already stores `amendment_designation`, and both vote syncs already populate it — so amendment roll-call votes with per-member positions may already be in the DB, joinable to `amendments` with a plain string match and **zero backfill**. This is the backlog's own "a line's stated mechanism is a claim — probe it, don't trust it" rule (the HO 512/514 corrections); the diagnostic settles which path is real.

**Read-only probe.** One committed diagnostic (`scripts/diagnostic/amendment-votes-join-529.ts`, sibling of `lda-bill-cost-439.ts` / `amendments-aggregate-cost-461.ts`), no build follows in this HO — report the numbers + a verdict and I'll scope the build (HO 530) from them. No schema, no sync, no surface.

## Baked from the code (facts — do not re-derive)

- **`votes`** (`migrate.ts:355`): `id` PK, `chamber`, `congress`, `session`, `roll_call INTEGER`, `vote_date`, `question`, `description`, `result`, `bill_id` (FK bills), **`amendment_designation TEXT`**, yea/nay/present/not_voting counts, `raw_json`. **`member_votes`** (`:380`): `(vote_id, bioguide_id)` PK, `position` — per-member yea/nay/present/not_voting, FK `votes.id`.
- **Both syncs already write `amendment_designation`** — `lib/votes-sync.ts:196` sets it to `` `${vote.legislationType}${num}` `` (House), `lib/senate-votes-sync.ts:172` the same (Senate), whenever the vote's legislation is an amendment. So **amendment roll-call votes are already ingested**, with `member_votes` populated, for whatever roll calls Congress.gov's vote feeds return. That's the crux: the votes may already be here.
- **`amendments`** (`migrate.ts:864`): keyed `amendment_type TEXT` (SAMDT / HAMDT / SUAMDT — the house-style pair, HO 447) + `amendment_number INTEGER`, plus `chamber`, `congress`, `amended_bill_id`, `latest_action_text` (present on only ~8.6% — HO 448). SUAMDT ≈ 0 in the 119th (HO 446).
- **The candidate free join:** `amendments.amendment_type || CAST(amendments.amendment_number AS TEXT) = votes.amendment_designation`, scoped by `chamber` + `congress`. If this resolves cleanly, `member_votes` on the matched `votes.id` gives the whole "who voted how" surface with **no `/actions` walk, no backfill** — just a query. **The format match is the unknown** (`votes.amendment_designation` is `legislationType||num` — does `num` zero-pad? is `legislationType` exactly `SAMDT`/`HAMDT`? does it match `amendment_number` stringified?), which §B measures empirically rather than assuming.
- `getMemberVotes` / `getMemberVoteStats` already read `votes` + `member_votes` and already carry `amendment_designation` through (`lib/queries.ts:6683+`, `:6820+`) — so the read plumbing exists; this probe is about whether the amendment-side join is complete enough to build on.

## What to measure

**§A — Is the join populated? (the GO-CHEAP test)**
1. `COUNT(*)` of `votes` rows with `amendment_designation IS NOT NULL`, split by `chamber` — the amendment roll-call votes already synced.
2. Of those, how many join to an `amendments` row on the candidate join above (chamber + congress + designation match)? Report the **match rate** both directions: (a) amendment-votes → amendments, (b) the ~586 acted amendments (`latest_action_text IS NOT NULL`, HO 448) → do they have ≥1 matching vote row, and (c) **all** amendments → how many carry ≥1 vote (the true surface coverage — this is the number that decides whether the feature is worth building).
3. For a handful of matched pairs, confirm `member_votes` rows exist on the matched `votes.id` (the per-member yea/nay is the payoff — should be true, confirm it).

**§B — Format reality (why a match might fail)**
Dump ~15 distinct `votes.amendment_designation` samples alongside the corresponding `amendments.amendment_type || amendment_number` for the same amendment — show whether they're byte-equal or need normalization (zero-padding, `SAMDT` vs `S.AMDT`, casing). If the raw join undercounts purely on format, report the normalization that closes it (e.g. strip leading zeros, `UPPER()`), and re-run §A.2 with it applied — a format gap is a fixable join, not a NO-GO.

**§C — Coverage vs the `/actions` fallback (only if §A is thin)**
If the direct join covers only a fraction of voted amendments, the question becomes *why*: are amendment votes simply absent from the vote feeds the syncs consume (so the roll calls were never ingested), or is it a format miss (§B)? Sample ~20 amendments that have a top-level `latest_action_text` mentioning a vote (agreed to / rejected / roll call) but **no** matching `votes` row, pull each one's `/amendment/{congress}/{type}/{number}/actions` (the HO 452 endpoint), and check: does its `recordedVotes.rollNumber` resolve to an **existing** `votes` row (`chamber` + `congress` + `session` + `roll_call`)? 
- If **yes** → the `/actions` walk would recover the link for the format-missed / designation-null rows (a middle path: walk only to get the rollNumber, then join to votes-already-present).
- If **no** (the roll call isn't in `votes` at all) → the real dependency is a **votes-sync gap**, not the `/actions` walk — recovering it needs extending the vote sync to ingest those roll calls, which the `/actions` walk alone can't do (no `member_votes` to join). Flag this as the scope-determining finding.

**§D — Numbers for the build call**
Report: total amendments, amendments with ≥1 joined vote (the buildable set), of those how many are on tracked bills (the `/bill/[id]` surface reach), the SAMDT/HAMDT split, and whether any amendment maps to **multiple** vote rows (a re-vote / motion-to-reconsider — the surface must handle a list, not a scalar). Commit the script.

## Verdict to return (I scope HO 530 from this)

- **GO-CHEAP** — the designation join (raw or §B-normalized) covers the voted-amendment set with member positions present → the surface is **query-only, no backfill** (retire the backlog's `/actions`-walk premise). This is the likely outcome and the big finding.
- **GO-WALK** — designation is unreliable but `/actions.recordedVotes.rollNumber` resolves to existing `votes` rows → a bounded `/actions` walk stores the rollNumber link, then joins to votes-already-present (still no member-vote backfill, just a linkage backfill).
- **NO-GO / BLOCKED-ON-SYNC** — the amendment roll calls aren't in `votes` at all → the dependency is a votes-sync extension (bigger scope), flagged for its own decision, and this feature waits on it.

State which, with the §A/§C coverage numbers behind it, and the §B format finding. Then stop.

## Guardrails + deliverable

- Read-only — `SELECT` + the ~20 `/actions` GETs in §C only; **no writes, no schema, no sync.** Commit as `scripts/diagnostic/amendment-votes-join-529.ts` (explicit pathspec, diff shown, one commit, FF). Match the read-only-diagnostic convention (`typecheck` clean before push — the HO 485 `3ed533c` broken-typecheck lesson).
- The `/actions` sample is small and bounded (§C, ~20) — don't walk the whole corpus; this probe measures feasibility, it doesn't do the backfill.

read docs/handoffs/529-amendment-votes-join-probe.md and follow it
