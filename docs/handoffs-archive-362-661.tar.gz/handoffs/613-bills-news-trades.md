# HO 613 — P4: `/bills`, `/news`, `/trades`, and the filter-bar pattern.

HEAD `8a23ff9`. Pointer "run through HO 610." **Next free is 613.** After this, P4 holds only `/lobbying` (last, per the ruling) and the phase close.

Baselines (v2, post-612 rider): `/bills` **76** (25 M1a) · `/news` **60** (16 M1a) · `/trades` **53** (0 M1a / 53 M1b). Leg C is `/changes` (469) and nothing here touches it. The shared `.mc-pane` 312px rail and its 883px min-doc-width are **phase-close scope; @720 doc-width failures on these routes are expected and not this HO's debt** — bucket them, don't chase them.

**Method is now standing:** decompose-first from the audit artifact's worst-10 per route, derive don't tune, wrap don't pin, re-anchor anything you expire, and every residual ships decomposed (marginal / axis / deferred) rather than forced.

## 1. Commit 1 — the filter-bar pattern (five routes, one shape)

The `.mc-fbar-spacer { flex: 1 }` is members' pin; `/hearings`' `.hcal-filterbar` (1,588px), `/bills`', `/news`', and `/trades`' bars each have their own (find each bar's actual pin — spacer, `margin-left:auto`, or `justify-content` — at build time; the class names differ per route). Pack every bar left: controls in their existing order, search box last-in-content rather than pinned, trailing gap right. Wrap stays allowed (they already `flex-wrap`).

This is the strip/titlebar rider at pattern scale. Score each route's bar row → 0 over-threshold; controls all reachable at 1024/900/720 (the §4-style control check, per route).

`fix(chrome): HO 613 — filter bars pack left across hearings/members/bills/news/trades (C1, one pattern)`

## 2. Commit 2 — `/bills`: star leads, media merges, the row packs

Decompose the 25 M1a from the artifact first and confirm the shape (expected: short-content rows gapping to the fixed `40px 28px` media+star right columns). Then the ruling, decided here so it isn't relitigated per-route:

- **The watch star moves to a leading rail**: `grid-template-columns: 28px 1fr` (star · content). A leading star is a stable click target on every row, satisfies C1 without an exemption, and follows the 609 caret precedent (far-right affordances reposition, they don't get carved out). Compact `/`'s v2 rows have no star and are untouched.
- **The media-attention column dies as a column** and its datum joins `.row-meta` as plain text (`▮ 12` or the existing glyph, dim) — it's data, and `row-meta` is where the row's data lives.
- The content column keeps its natural fill; with both fixed right columns gone the row has no far-right anchor left. `SponsorHoverName` behavior on these rows re-verified (it lives here, per 610's correction).

Score: `--route bills` — the 25 M1a → 0; decompose whatever M1b remains (rail rows and strips are candidates; name them). `/stale` shares `BillRow` — spot `--route stale` and eyeball one row there; its numbers may move with the shared component and that's expected, label it.

`fix(bills): HO 613 — watch star leads, media joins row-meta, the feed row packs (C1; the 609 caret precedent)`

## 3. Commit 3 — `/news`: the grid becomes a packed flex row

`.news-row`'s `124px 1fr 120px 64px` is the canonical content-then-pinned shape. Convert to the mock's `brk-row` idiom at route scale: id · headline · source · age, flex, packed left, trailing right. The **3px SIGNAL rail** (`border-left`, HO 241) survives untouched — it's a left rail and it's state, exactly what C3 reserves color for. Headlines wrap at narrow widths rather than ellipsize (the 611 lesson; a browse list has no box to protect). `.news-header-row` takes the same treatment so header and rows can't disagree. `RaceNewsRow` shares the idiom minus the id cell — same conversion, verified not assumed.

Score: `--route news` — 16 M1a → 0, residual decomposed.

`fix(news): HO 613 — news rows pack left, SIGNAL rail intact (C1)`

## 4. Commit 4 — `/trades`: the knee, again

`.trade-row`'s `60px 40px 80px 1fr 110px 110px` has the members problem in the 1fr asset-name track. Same method, same reporting: measure the asset-name ink distribution at 2560 across the rendered page, print the cap→(truncated, rows-over) curve, take the knee, keep full names in `title`, `justify-content:start` so the amount columns' shared axis sits inside the packed span. If the distribution's spread is under the threshold (possible — tickers and short names dominate), say so and skip the cap; the curve decides, not the pattern.

The txn buy/sell coloring is state and stays. Score: `--route trades` — 53 → decomposed handful.

`fix(trades): HO 613 — asset-name track capped at the measured knee; amounts keep their axis (C1)`

## 5. Verification and guards

1. Four commits in order, typecheck + build each, explicit pathspecs, ancestry reads four.
2. Falsification with leg C on `/changes` before trusting any zero — it must hold ~469 throughout, and nothing in this HO may touch `/changes`.
3. Per-route score tables (v2-labeled) at each stage; `/` and `/members` spot-checked unmoved at the end (M1 0 and ~22 respectively).
4. Narrow buckets per route at 1024/900/720: (a) design-ellipsis vs (b) real, doc-width noted with the 883-rail exclusion applied. Bucket (b) not worse than baseline anywhere.
5. Eyeball at 1440/2560: bills rows with leading stars (click a star, watch it stick), news wrap at 900, trades axis alignment, all five filter bars packed and usable.
6. Prod-verify to the SHA, converged. **HALT** with the tables, the trades curve, the bills M1a decomposition, and anything the pattern commit surprised. No lobbying work, no `.mc-pane` rail work, no M5 instrument work, no sweep.
7. Absence Watch untouched. `data-viz-row` unused. `--fs` tokens for anything 9–14px.
