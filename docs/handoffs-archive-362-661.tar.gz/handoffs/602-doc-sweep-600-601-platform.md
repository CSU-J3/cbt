# HO 602 — doc sweep: the SC special-primary arc (600–601) + the platform read and read-budget attribution

**Numbering.** Next after HO 601 (`c4a3c06` — the arc ran to five commits; see A0). Confirm against `docs/roadmap.md`'s pointer and `git log`.

**Docs only. No code.** Two unrelated subjects in one sweep (the HO 487 precedent), each owed its own append-only roadmap block. Two commits: roadmap + backlog + oddities first, SKILL alone second, gated on an approved diff through the review ref.

**Read this first.** Part B's findings have **no committed artifact and cannot be regenerated from the repo**. They came off the Turso dashboard on 2026-08-05 and exist nowhere but a chat transcript. This sweep is their only record, which puts them in the HO 584 statutory-facts class rather than the normal doc-pass class: write the numbers, their source, and the date, because nothing downstream can rederive them.

---

# PART A — the SC special-primary arc (HO 600–601)

**A0 — the HO 601 arc is FIVE commits, not three; two landed after the ship report.** `5bf1176` pre-flight · `efa858f` code · `0473dc6` docs · **`07dd555`** the pre-flight baseline relabel (`TODAY` → `PRE_601`; the mirror describes the gate at `36b7731`, which stopped existing at `efa858f`, so a re-run would silently compare against a dead baseline) · **`c4a3c06`** the freeze-status residual (backlog WATCH + queued comment-only item + a fourth oddity). **Several items this draft lists as "new" are therefore ALREADY FILED** — check `docs/backlog.md` and `docs/oddities.md` before writing any of them, and tombstone rather than re-file. Marked inline below.

---

## A1 — roadmap block

One block covering both HOs. Land the following, in the house voice.

**What shipped.** HO 600 (`36b7731`) deleted the phantom `senate-SC-2026-special-D` and rewrote the seed note around the statute. HO 601 (`5bf1176` pre-flight · `efa858f` code · `0473dc6` docs · `07dd555` baseline relabel · `c4a3c06` freeze-status residual) replaced the page-type gate with an `<h5>` router resolved against the seeded set, added the regular-page fallback to the priority pass, and made the pass's result reportable. Live-verified: 10 rows on `senate-SC-2026-special-R`, exact name match, 0 missing / 0 extra.

**The external facts, with their source and date, because the repo cannot rederive them.** South Carolina's August 11 contest is a special *primary* under S.C. Code §7-11-55, held after the death of the Republican nominee, and open to Republican candidates only because that nominee had general-election opposition. Filing closed 2026-07-28; the winner goes onto the November 3 general ballot. Verified 2026-08-05 against the SC Election Commission notice and corroborated by Ballotpedia's own linking. It is **not** a special election, which is why it is absent from Ballotpedia's two-item 2026 Senate specials list (FL, OH).

**The defect, stated as its class.** `isSpecialElectionPage()` read the page `<title>` and used it to gate whether a votebox was parsed at all. A container's self-reported type cannot gate its contents. SC's parenthetical page title carries no "special election" string while the box `<h5>` reads "Special…", so the predicate inverted against itself and dropped the only box on the page. Fixing the URL alone would not have worked.

**The correction to HO 601's own §1, and why the handoff's rule was wrong.** The `<h5>` says a box is a special contest. It does **not** say whether that contest is *additional* to a regular one for the same seat, and that is the fact that decides the destination. SC has both; FL and OH have only the special, so their base ids are the correct home. The seed registry already encodes exactly that distinction, so the shipped rule is: **a special-classified box routes to `senate-{ST}-2026-special-{party}` iff that id is seeded, otherwise to the base id.** Measured: §1's rule produced 4 unseeded targets and moved FL, OH and SC; the seeded rule produces 0 and moves SC alone.

**The premise that fell with it.** HO 601 §5 guarded `senateSpecialPageUrl` as "correct for FL/OH." **FL and OH never used it.** Ballotpedia serves their special-election articles under the plain `United_States_Senate_election_in_{State},_2026` URL (200, `redirected=false`) with a title that self-reports "special election," which is why the old gate worked there and failed on SC. Combined with HO 561 S2's 0-of-35 missing standard pages, **nothing currently reaches Ballotpedia through that URL shape at all.**

**Falsification, three legs, and what leg 2 does and does not prove.** Leg 1 wrote the 10 rows, with `sources[].url` confirming the C2 fallback fired and `candidates: 19` against 10 written confirming the pass parsed a document full of regular voteboxes and wrote only its invoked special id. Leg 3 held FL/OH byte-identical and exercised both branches (FL future-dated so the write path ran and reproduced itself; OH past-dated so `settledSkipped` fired). Leg 2 recorded `isSettled` **consulted and refused** on `senate-SC-2026-R`, byte-identical, `updated_at` untouched. **State the limit in the same breath:** `isSettled` short-circuits before the roster is built, so it refuses every settled row unconditionally and does not discriminate a substituting roster from any other — and the payload it refused was the **correct June roster**, not a substituting one. So the HO 560 freeze is **exercised on its general case** (any rewrite of a settled row) and is now **structurally unreachable for substitution**: the router removes that hazard upstream, so no substituting roster can arrive at a settled row for the freeze to observe. **Do not write that it is "now exercised against a page carrying a substituting contest"** — HO 600 reported it untested, and the honest successor state is narrower than "exercised," not broader. The router is the first line; the freeze is the second, and it stays live and useful for its general case (leg 3's OH `settledSkipped` is that case firing). Idempotency proven on a second pass (10 → 10 identical).

**Scope held:** `senateSpecialPageUrl` unmodified, no `-special-` row auto-created, `senate-SC-2026-special-D` absent throughout, no Aug 25 runoff row.

**No theme-% change** — a correctness fix and an ingestion path on the existing electoral pillar; Races holds at 99.

## A2 — backlog

- **Retire** the unmeetable `{D,R}` criterion; **adopt** HO 600 §4's replacement verbatim. C1 (roster of 10 by Aug 10) **now passes**, and record that it read FAIL on the day it was written, which was its design. C2 (results with `vote_pct`, HO 207 two-★ rule) is **due Aug 13** and open. C3 (the D row does not exist) is a standing guard.
- **Tombstone** HO 600 and HO 601 with their SHAs and the three legs.
- ~~**New loop**~~ **ALREADY FILED (`0473dc6`)** — the Aug 25 runoff row is absent, and it is dated and conditional. `runoff_date` sits on the special row but no `election_round='runoff'` row exists, and HO 600 established `/race/S-SC-2026` reads `getRunoffsForRace`, which filters on exactly that column. Ten candidates makes an outright majority unlikely, so if Aug 11 goes to a runoff the race hub renders nothing. *Close:* either seed the runoff row or record why the special row's `runoff_date` is sufficient. **Decide after the Aug 11 result, not before.**
- ~~**New loop**~~ **ALREADY FILED (`0473dc6`)** — `senateSpecialPageUrl` appears to serve no state. File with the evidence above and an explicit **do not delete on this evidence**: the measurement shows it is currently unreached, not that the case it defends against cannot occur. *Close:* show that a standard page can never be missing, or delete it with that reasoning stated.
- **New loop — Tim Scott's chip renders a contest he is not in** (HO 600 M1). Class 3, next election 2028, hub shows `Next election 2028 · Primary Rep: 08-11-26 (6d)`, contradicting the cell beside it. The statewide proxy resolves any D/R member of a state, and `NOT_SPECIAL_UNLESS_SENATE` distinguishes "is a senator" from "is the senator whose seat this special fills." Pre-existing, unaffected by either HO.
- **ALREADY FILED (`c4a3c06`), do not re-file — the HO 560 freeze's real status.** A WATCH (structurally unreachable for substitution; live for its general case; second line behind the router) **and** a QUEUED comment-only item for a comment at `isSettled`. **The queued item is a CODE file and the HO 581 scope guard keeps it out of this sweep** — it rides the next primaries code touch, likely the Aug 25 runoff work. Verify both read correctly; add nothing.
- **New item — the 2026-08-05 12:00 primaries cron timeout** (`The operation was aborted due to timeout`, 46.7s).
- **Correct** the HO 600 handoff's own premises where the backlog repeats them: `/race/S-SC-2026` was never in scope (`getRunoffsForRace` returns 0 rows for it), the phantom was a **count inflation** (Aug 11 tick 48 → 47 contests) and not a rendered label, and `getDashboardPrimaries` runs unconditionally in `CompetitiveRacesBlock` so the PRIMARIES tab renders on both `/` and `/dashboard-classic`.

## A3 — oddities

The three HO 601 already drafted, landed as written: a container's self-reported type cannot gate its contents (with the dedup corollary — **Mark Lynch runs in both SC contests**, June R at 28.9% and the August field, so a name-keyed dedup collides two real contests); a seed file that looks additive can **move** data, the transferable part being that the failure mode was designed out of the code and into the config where no typecheck, test, or review diff catches it; and the skip-on-empty inversion recorded **as a shape** with its recognition rule.

**A fourth already landed with the residual (`c4a3c06`):** a fix upstream of a guard can make it structurally unreachable, and the fix's own success report reads as the guard being exercised — distinct from HO 549/553 (there the guard never fired; here it fired on a different input than the one it exists for, which no "did it fire?" check can distinguish). Recognition rule: **when a fix removes a hazard's delivery mechanism, the guard downstream needs its status RE-STATED, not RE-CONFIRMED.** Verify it reads correctly; do not duplicate it.

The remaining oddities action is therefore **not a new entry but a strengthening of the existing skip-on-empty one**, because the shape now has three instances in three consecutive HOs on one subsystem and the ledger's own header says a third makes it a convention problem rather than coincidence: HO 600's `fetchFailures: []` against three real 404s, HO 601 §2's unreachable states counting as unchanged and flipping a gate green, and the `emptyRosterSkipped` case caught pre-emptively while fixing the second. Add the third instance to the entry that already exists rather than opening a duplicate. **Coverage is a precondition of a verdict, not a footnote.**

## A4 — SKILL

The router contract and its seeded-set resolution; the specialness-aware dedup key; the priority pass writing only its invoked special ids (and why: the base rows are reached by the standard pass, where `isSettled` guards them, and a second writer on a different schedule is a new substitution surface); the C2 fallback's **cursor-driven rationale** (HO 600 M2 measured three consecutive ticks on `unit="house"` at cursor 439–462 of 471, so the senate slice may not reach SC before Aug 11 — say so, or someone deletes the fallback as redundant now that SC's content is also on the regular page).

---

# PART B — the platform read and read-budget attribution

Source: Turso dashboard for org `csu-j3`, read 2026-08-05. **No script, not reproducible from the repo.** Every number below is to be written with that provenance.

## B1 — roadmap block

**The platform facts the variance loop was blocked on, now on the record.** Plan **Developer** ($5.99/mo, 2.5B rows read/mo, +$1/B overage). DB primary **`aws-us-west-2`** (`libsql://cbt-csu-j3.aws-us-west-2.turso.io`), single group `default`, **no replicas, no branches**. Vercel functions are pinned **`pdx1`** (`vercel.json:2`), which is us-west-2. **Store and compute are in the same AWS region.**

**Two variance hypotheses die on that.** Cross-region latency and replica routing are both out. What remains is that <cite>Turso's own Developer-plan launch post describes the tier as running on a massive multi-tenant server</cite>, which is the shape that leaves a median alone while fanning an upper tail. **There is no purchasable lever**: the plan comparison table carries quota, retention and governance rows and **no performance row at any tier**, so a Scaler upgrade is an unfalsifiable experiment and was rejected rather than run. The loop therefore closes by **bounding** (a co-located worst case with the margin as a number), not by explaining, which was always the second half of its criterion.

**Read-budget attribution, answered by measurement after being reasoned about across four HOs.** Turso's per-query `rows_read` over 30 days: the `bills_agg` sponsor aggregate **110.0M / 317 calls / 347k per call (26%)**; `getParticipationStrip` **91.3M / 106 / 861k (22%)**; `getChamberParticipationContext` **85.4M / 96 / 890k (20%)**; the pre-582 markets spark window **40.7M / 8,660 (10%)**; the pre-582 markets MAX-GROUP-BY join **35.5M / 8,470 (8%)**. **Top five = 363M of 418M, 87%.** The whole LDA family is ~11M, under 3%.

**None of the four standing suspects was the answer.** The loop carried the e2e crawl, summarize, the LDA precompute, and real traffic. It was three aggregates.

**The `/members` 500 loop and the read-budget loop were one fault, and nothing said so.** HO 593 named those two participation queries as the 500's cause, 594 indexed them, **595 materialized them into `member_participation` and removed `member_votes` from the request path**, closing **42% of the read budget as a side effect**. HO 582 had taken the markets 18% two days earlier. HO 595's tombstone says "Not claimed: this does not touch the `pageErr` #418 OPEN LOOP" and is silent on the loop it did close. **Record this as a new statement here, not a retro-edit** of 595's block, which was correct on its evidence.

**Append-only correction to the HO 577 burn figure.** The record says CBT "stepped ~10× around Jul 25 and plateaued near 85–90M/day." The daily series shows a baseline of **3–5M/day** through ~Jul 22, a ramp from **Jul 23–24** steepening **Jul 27–30**, and a peak near **38M**. The timing survives; the magnitude is roughly **2.4× overstated**. Three HOs reasoned against the higher number.

**The ramp has a named cause and it is not the one first proposed.** A 24-hour Top Queries read showed LDA on top and was mis-read here as the ramp; the 24-hour window shows what is *left* after the fixes, not what caused the rise. The 30-day window names the participation aggregates, which shipped **into** the ramp: `getChamberParticipationContext` HO 523 (`2b8d62b`, Jul 25), `getParticipationStrip` HO 527 (`7fa729c`, Jul 26), `participationAggCte` into the roster HO 535 (`b565c13`, Jul 27).

**The HO 597 prediction is OWED AND UNSCORABLE, not failed.** HO 594/595/597/598 all landed Aug 3–5, the same 48 hours as the `activity_count` backfill (129,000 UPDATEs) and the `lda_names` back-catalogue sweep, so fixes and their one-time cost are confounded and the required day-matched quiet day does not exist yet. Direction is not in doubt: ~60% of the burn was removed across Aug 1–4 against a logged estimate of "roughly a fifth, a level shift not a resolution." **Re-read Aug 8–9 on a quiet day** and score it against the stated constraints.

**Cap risk is low.** 418M against 2.5B over 30 days; even sustained at the 38M peak that is ~1.1B/month.

## B2 — backlog

- **Read-budget attribution: CLOSED on measurement**, with the decomposition above and the note that none of the four suspects was the cause. Tombstone it.
- **Query-cost VARIANCE loop:** record the platform facts, strike cross-region and replicas as dead hypotheses, record multi-tenancy as the standing candidate with no purchasable lever, and state that the loop now closes by bounding. Its instrument is unchanged (`lobbying-search-gate-598.ts`, worst − median per regime).
- **The HO 597 prediction:** status **owed and unscorable until ~Aug 8–9**, with the confound named. Do not let it age out.
- **New QUEUED — the `bills_agg` sponsor aggregate, 110M rows / 26%, the largest single consumer and untouched.** Its own comment records the HO 277 hint making it index-only at 96ms, and it reads 347k rows per call at ~10 calls/day, so it is the fastest expensive query on the database and invisible to every latency instrument. This is the HO 582 currencies lesson in pure form. **Probe first** (the 594/595 shape); the levers are narrowing what it reads or materializing it.
- **New WATCH — the two Top Queries windows disagree.** The 24-hour view's top row (`lda_filings` completeness COUNT, 5.95M / 46 calls) does not appear in the 30-day list where its magnitude says it belongs. Treat them as two instruments, not one, and do not build a number on their difference without resolving this.
- **Overages toggle:** check it and record the state. Low urgency at current burn; the point is that with overages off the ceiling is an account-wide read block, which is what took prod down twice.

## B3 — oddities

Rows read and milliseconds remain different currencies, now with the strongest instance yet: a covering-index scan documented in-code as "index-only, 96ms" is the single largest read-budget consumer on the database. A latency instrument cannot see it, and only per-query `rows_read` can.

And: a 24-hour attribution window shows what survived, not what caused a rise. Attributing a ramp requires a window that contains the ramp.

## B4 — SKILL

The platform facts as a stated environment section (region pinning on both sides, single instance, tier and quota), and the per-query `rows_read` view named as the read-attribution instrument of record, since four HOs reasoned about this without one.

---

## Close

Two commits, review ref, gate counts verified independently. An invalidation pass over prior claims first, per the sweep rule: Part A retires two of my own handoff premises and Part B retires one of my own attributions and corrects a logged figure, and each should read as a retraction with its reusable shape rather than a quiet edit.
