# HO 463 — `/lobbying` topic crosswalk: click-through to constituent codes

Make the **BY-CBT-TOPIC** bars on `/lobbying` (HO 444, Section 3) interactive. Clicking a topic bar reveals the LDA issue codes that roll into it, each linking to that code's **existing per-code drill** (the Section 2 right-column `IssueDrill`). No new data layer, no new query, no blob change — this is a pure UI pass over data already in the page.

Closes the QUEUED "topic crosswalk click-through (HO 444 v2)" item. This is HO 463 (roadmap HEAD is HO 462 — check `docs/roadmap.md`, not the on-disk filename).

## What already exists (the mechanism you're reusing)

`app/lobbying/page.tsx` reads three O(1) blobs. Two facts make this cheap:

1. **`rollup.issues`** carries every corpus issue code as `{ code, display, filings, activities }`, sorted by filings desc. **`rollup.drill`** (`Record<string, IssueDrill>`) has an entry for **every** code in `issues` (built uncapped in `computeIssueRollup` — loop over all of `uuidsByCode`). So every constituent code of every topic has a working drill; a chip link can never land on a blank.
2. Section 2 already drills by URL: `IssueBars` rows are `<Link href="/lobbying?issue=CODE" scroll={false}>`; the page reads `params.issue`, sets `selected`, renders `drill[selected]` in the `patterns-right` aside via `IssueDrill`. **You reuse this exact `?issue=` path** — the topic-code chips just point into it.

`TopicCrosswalkRow` does **not** carry its constituent codes, so you derive them page-side by grouping `rollup.issues` under `topicForCode` (`lib/lda-issue-topic-map.ts`). Critically: `computeTopicCrosswalk` groups by the *same* `topicForCode`, so your grouping aligns exactly with the bar totals — no drift, no double-counting seam.

## The build — two files, one commit

### 1. `app/lobbying/page.tsx`

**a.** Import the mapper (top, with the other `@/lib` imports):

```ts
import { topicForCode } from "@/lib/lda-issue-topic-map";
```

**b.** After the existing `const { stats, issues, drill } = rollup;` and the `selected` line, group the corpus codes under their CBT topic:

```ts
// HO 463 — group every corpus issue code under its CBT topic so the crosswalk
// bars can drill into their constituent codes' existing per-code drills.
// issues[] covers every corpus code and drill[code] exists for each, and
// computeTopicCrosswalk keys on the same topicForCode — so this aligns with the
// bar totals and no chip lands on a blank drill.
const topicCodes: Record<
  string,
  { code: string; display: string; filings: number }[]
> = {};
for (const i of issues) {
  const t = topicForCode(i.code);
  (topicCodes[t] ??= []).push({
    code: i.code,
    display: i.display,
    filings: i.filings,
  });
}
// issues is already filings-desc, so each group is too — sort is defensive.
for (const t of Object.keys(topicCodes)) {
  topicCodes[t].sort((a, b) => b.filings - a.filings);
}
```

**c.** Give the Section 2 drill aside an id anchor so the chips can scroll it into view (`HeaderBar` is `position: relative`, so no sticky offset is needed — if you find any sticky chrome above it, add a matching `scroll-mt-[Npx]`):

```diff
-          <aside className="patterns-right">
+          <aside id="lobby-drill" className="patterns-right">
```

**d.** Pass the new props to `TopicCrosswalk` (Section 3):

```diff
         {topicCrosswalk?.topics.length ? (
-          <TopicCrosswalk topics={topicCrosswalk.topics} />
+          <TopicCrosswalk
+            topics={topicCrosswalk.topics}
+            topicCodes={topicCodes}
+            selected={selected}
+          />
         ) : null}
```

### 2. `components/TopicCrosswalk.tsx` — becomes a client island

It's currently a server component. Convert to `"use client"` for the instant expand toggle (a static reveal of codes — no fetch). Client state persists across the `?issue=` soft-nav (the component stays mounted under the stable `topicCrosswalk?.topics.length` guard), so the expanded topic does **not** collapse when a chip is clicked. Import the row type from `@/lib/lda-rollup` (its definition) rather than `@/lib/queries` to keep the client bundle off the query module.

Full replacement:

```tsx
"use client";

import Link from "next/link";
import { useState } from "react";
import type { TopicCrosswalkRow } from "@/lib/lda-rollup";
import { topicColor, topicFullLabel, topicLabel } from "@/lib/topic-colors";

// HO 444 → v2 (HO 463) — the /lobbying CBT-topic crosswalk section, now a
// click-through: the same corpus the native issue bars show, re-expressed in
// CBT's 24-topic vocabulary, with each topic bar expanding to its constituent
// LDA issue codes. Each code chip links into the EXISTING Section 2 ?issue=
// drill (drill[code] is precomputed for every corpus code) and scrolls it into
// view (#lobby-drill). A PARALLEL lens beside the native general_issue_code bars;
// the mapping's lossiness is disclosed by showing both. Served O(1) from the
// lda_topic_crosswalk blob; the per-topic code lists are derived page-side by
// grouping rollup.issues under the SAME topicForCode the blob keys on.
//
// Multi-code property: a filing naming codes in two topics counts under each, so
// the bars DON'T sum to the corpus — the header says "by issue focus", never
// "share". Bar scales to the max topic (linear), same as IssueBars.
//
// Responsive: the Clients column drops below Tailwind's `sm` (~640px) — Tailwind
// arbitrary grid tracks (no globals.css coupling, the HO 442 rule).
const GRID =
  "grid items-center gap-x-[14px] grid-cols-[minmax(0,1.3fr)_minmax(0,2fr)_64px] " +
  "sm:grid-cols-[minmax(0,1.3fr)_minmax(0,2fr)_64px_64px]";

export function TopicCrosswalk({
  topics,
  topicCodes,
  selected,
}: {
  topics: TopicCrosswalkRow[];
  topicCodes: Record<string, { code: string; display: string; filings: number }[]>;
  selected: string | null;
}) {
  const [open, setOpen] = useState<string | null>(null);
  if (topics.length === 0) return null;
  const maxFilings = Math.max(1, ...topics.map((t) => t.filings));

  return (
    <section className="mt-6">
      <div className="mb-2 flex flex-wrap items-baseline gap-2">
        <h2
          className="text-[12px] uppercase tracking-[0.5px]"
          style={{ color: "var(--text-secondary)" }}
        >
          Lobbying by topic · CBT taxonomy
        </h2>
        <span
          className="text-[11px] leading-snug"
          style={{ color: "var(--text-dim)", fontFamily: "var(--sans)" }}
        >
          The same filings mapped to CBT&rsquo;s 24 topics. Tap a topic to see the
          issue codes it covers &mdash; each drills to who&rsquo;s lobbying it. A
          filing can name several issue areas, so it counts under each; the bars
          don&rsquo;t sum to a share.
        </span>
      </div>
      <div className="border" style={{ borderColor: "var(--border-strong)" }}>
        <div
          className={`${GRID} px-[14px] py-[9px] text-[11px] uppercase tracking-[0.5px]`}
          style={{
            backgroundColor: "var(--bg-panel)",
            borderBottom: "0.5px solid var(--border-strong)",
            color: "var(--text-dim)",
          }}
        >
          <span>Topic</span>
          <span aria-hidden />
          <span className="text-right">Filings</span>
          <span className="hidden text-right sm:block">Clients</span>
        </div>
        <ul>
          {topics.map((t) => {
            const color = topicColor(t.topic);
            const widthPct = (t.filings / maxFilings) * 100;
            const codes = topicCodes[t.topic] ?? [];
            const isOpen = open === t.topic;
            return (
              <li key={t.topic}>
                <button
                  type="button"
                  onClick={() => setOpen(isOpen ? null : t.topic)}
                  aria-expanded={isOpen}
                  disabled={codes.length === 0}
                  className={`${GRID} w-full cursor-pointer px-[14px] py-[10px] text-left transition hover:bg-[var(--bg-row-hover)] disabled:cursor-default`}
                  style={{
                    borderBottom: "0.5px solid var(--border-soft)",
                    borderLeft: `3px solid ${isOpen ? "var(--accent-amber)" : "transparent"}`,
                    backgroundColor: isOpen ? "var(--bg-row-hover)" : undefined,
                  }}
                >
                  <span className="flex min-w-0 flex-col leading-[1.2]">
                    <span className="flex items-center gap-[6px]">
                      <span
                        className="text-[10px] leading-none"
                        style={{ color: "var(--text-dim)" }}
                        aria-hidden
                      >
                        {isOpen ? "\u25be" : "\u25b8"}
                      </span>
                      <span className="truncate text-[12px]" style={{ color }}>
                        {topicFullLabel(t.topic)}
                      </span>
                    </span>
                    <span
                      className="pl-[16px] text-[10px] uppercase tracking-[0.5px]"
                      style={{ color: "var(--text-dim)" }}
                    >
                      {topicLabel(t.topic)} · {codes.length} code
                      {codes.length === 1 ? "" : "s"}
                    </span>
                  </span>
                  <span
                    className="block h-[10px] overflow-hidden rounded-[2px]"
                    style={{ backgroundColor: "var(--bg-row-hover)" }}
                    aria-hidden
                  >
                    <span
                      className="block h-full rounded-[2px]"
                      style={{ width: `${widthPct}%`, backgroundColor: color, opacity: 0.6 }}
                    />
                  </span>
                  <span
                    className="text-right text-[12px] tabular-nums"
                    style={{ color: "var(--text-muted)" }}
                  >
                    {t.filings.toLocaleString()}
                  </span>
                  <span
                    className="hidden text-right text-[12px] tabular-nums sm:block"
                    style={{ color: "var(--text-muted)" }}
                  >
                    {t.distinctClients.toLocaleString()}
                  </span>
                </button>
                {isOpen && codes.length > 0 ? (
                  <div
                    className="flex flex-wrap gap-[6px] px-[14px] pb-[11px] pt-[3px]"
                    style={{
                      backgroundColor: "var(--bg-panel)",
                      borderBottom: "0.5px solid var(--border-soft)",
                    }}
                  >
                    {codes.map((c) => {
                      const active = c.code === selected;
                      return (
                        <Link
                          key={c.code}
                          href={`/lobbying?issue=${encodeURIComponent(c.code)}#lobby-drill`}
                          title={c.display}
                          aria-current={active ? "true" : undefined}
                          className="inline-flex items-center gap-[6px] rounded-[2px] border px-[7px] py-[3px] text-[11px] no-underline transition hover:bg-[var(--bg-row-hover)]"
                          style={{
                            borderColor: active
                              ? "var(--accent-amber)"
                              : "var(--border-strong)",
                            color: active
                              ? "var(--accent-amber)"
                              : "var(--text-secondary)",
                          }}
                        >
                          <span className="font-[600] tracking-[0.3px]">{c.code}</span>
                          <span
                            className="max-w-[18ch] truncate"
                            style={{ color: "var(--text-dim)", fontFamily: "var(--sans)" }}
                          >
                            {c.display}
                          </span>
                          <span
                            className="tabular-nums"
                            style={{ color: "var(--text-dim)" }}
                          >
                            {c.filings.toLocaleString()}
                          </span>
                        </Link>
                      );
                    })}
                  </div>
                ) : null}
              </li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
```

## Interaction

- Topic bar → `<button>` toggles an inline chip row of its constituent codes (filings-desc). One topic open at a time (`open` is a single slug; click the open one to collapse).
- Code chip → `<Link href="/lobbying?issue=CODE#lobby-drill">` drives the **existing** Section 2 `IssueDrill` and scrolls it into view. It does **not** use `scroll={false}` (unlike `IssueBars`, which sits right beside the drill) precisely because Section 3 is far from it — the hash pulls the drill up so the user sees what they asked for.
- The chip for the currently-`selected` code renders amber (`aria-current`), giving visual continuity with the Section 2 selection.
- The expanded topic persists across the chip's soft-nav (client state, component stays mounted), so a user can pick a second code from the same topic without re-expanding.

## Correctness / non-goals

- **Coverage:** every code in `issues` has a `drill[code]` entry (uncapped build), so no chip lands on the "Select an issue" empty state. `sanitizeIssueCode` accepts every 2–8-char uppercase code, so all LDA codes pass.
- **Alignment:** page-side grouping uses `topicForCode` — the exact function `computeTopicCrosswalk` keys on — so the chips under a topic are exactly the codes that fed its bar. A future unmapped code falls to `other` in both places (the blob already `console.warn`s it), so they never diverge.
- **`other` is the fat one** (~21 codes) — its chip row wraps to a few lines. Fine.
- **`elections`** maps from no code, so it isn't in the blob and shows no bar. No special-casing needed (the `codes.length === 0` guard disables the button defensively regardless).
- **No blob/query/cron/migration change.** No `IssueDrill`/`IssueBars` change. No new nav. This is Section 3 UI + a page-side grouping only.
- **Out of scope:** rendering a drill inline within Section 3 (deliberately reuse the single Section 2 drill surface); a topic-keyed precomputed drill (unnecessary — the per-code drills already exist); the `deriveDisposition`/`dispositionColor` shared-module extraction (a separate QUEUED item, don't fold it in).

## Commit boundary

One commit, both files. Explicit pathspec staging (`git add app/lobbying/page.tsx components/TopicCrosswalk.tsx`), no glob. Propose the plan, show the diff, wait for approval before committing — no auto-commit. Before any push: ancestry eyeball (one commit riding, nothing behind, clean fast-forward, a concurrent session's files untouched).

Suggested message:
```
feat(lobbying): topic-crosswalk click-through — bars drill to constituent issue codes (HO 463)
```

## Verify on prod after deploy

- `/lobbying` renders the BY-CBT-TOPIC section; each bar shows a caret + "N codes".
- Click **Healthcare** → chips appear (HCR / MMM / PHA / MED / ALC / FAM), filings-desc. Click **HCR** → page scrolls to the Section 2 drill showing HCR's clients/firms/recent; the HCR chip is amber; the topic stays expanded.
- Pick a second code from the same open topic (e.g. **PHA**) without re-expanding → drill updates, chip highlight moves.
- Click **Other** → the ~21-code row wraps cleanly; a low-volume code (e.g. **APP**) drills to a real (small) drill, not the empty state.
- Collapse works (click the open topic again). Below `sm` the Clients column is gone and chips still wrap. No console errors.

---

read docs/handoffs/463-lobbying-topic-crosswalk-drill.md and follow it
