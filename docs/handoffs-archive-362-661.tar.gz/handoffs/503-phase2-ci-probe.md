# HO 503 — Phase 2 CI (Playwright in CI): feasibility probe

Confirm 503 is the next free number before saving (`ls docs/handoffs/ | sort -V | tail`); body assumes 503. Roadmap "Also" notes run through HO 502, HEAD `4762d08`.

Read-only survey. **No `ci.yml` edits, no `playwright.config.ts` edits, no spec edits, no fixture built, no `lib/db.ts` touch.** Produce a report; the build HO (or the decision to scope it down) follows from it. Nothing to commit unless a durable diagnostic falls out.

## Why a probe, when the path is already "decided"

The backlog says the preferred path is **a seeded local libSQL file in CI, not prod credentials in Actions** — libSQL is SQLite, so a fixture removes the secrets question rather than managing it. That reasoning is sound and I'm not reopening it.

What's unmeasured is everything downstream of it. The loop has been carried since Jun 30 across five HOs and has only ever been described in terms of its **three blockers** (no `webServer` block, `TURSO_*` unprovisioned, markets-hover timeout). Those are the cheap part. The expensive part nobody has costed: **the two committed specs were written against the live prod corpus**, and a fixture is by definition not that corpus. Every assertion that reaches for a real race district, a real lobbying drill, a real trades rollup, a real ticker symbol fails against an empty or synthetic DB — and it fails as a *red CI*, which is precisely the red-blindness the #418 fix was celebrated for removing.

So the question this probe answers is not "can we run Playwright in Actions." It's **what fraction of the existing suite can survive a fixture, and is the answer high enough that a fixture is the right shape at all** — versus splitting the suite into a CI-runnable subset plus a prod-only interaction suite that keeps running manually.

Probe first, per the standing rule. A clean plan says nothing about what the specs actually assert.

## Step 1 — does `file:` even work through `getDb()`

`lib/db.ts:67-70` is `createClient({ url, authToken, fetch: boundedFetch })`. The HO 238 `boundedFetch` is injected unconditionally.

Determine, by running it, not by reading docs:

- Does `@libsql/client` (check the installed version) accept a `file:./x.db` URL **with a `fetch` key present in the config**? Throw, ignore, or silently misbehave?
- Same question with `authToken` present-but-undefined.
- If it throws or degrades: **what is the minimum change to `lib/db.ts`** — a scheme sniff that omits `fetch`/`authToken` for `file:`? Report the exact shape, don't apply it.

This is the one question that can move the build's blast radius from "config + fixture" to "config + fixture + an edit to the single most load-bearing module in the repo." `lib/db.ts` serves every page, route, cron and script from one place. If the answer is "needs a code change," say so loudly — that changes the sequencing (it'd want its own commit ahead of everything, with the HO 238 timeout/retry semantics proven unaffected on the HTTP path).

Also confirm: does `scripts/migrate.ts` run clean against a `file:` target? It's 1,284 lines / ~132 DDL statements and is the only schema source. If migrate is Turso-flavored anywhere (remote-only pragmas, `ALTER` ordering that assumes an existing prod table), the fixture can't be built from it.

## Step 2 — the data-dependence audit (the real deliverable)

Go through **every** `test(...)` in `e2e/smoke.spec.ts` and `e2e/fit-finish.spec.ts` and classify each into exactly one bucket:

- **(A) Shape-only** — asserts status, no-console-error, an element/class exists, a param round-trips. Survives any non-empty DB, possibly an empty one.
- **(B) Needs corpus rows** — asserts a bill row expands, a member link navigates, a committee-scoped roster renders, chips rebase a count. Survives a fixture *if the fixture carries the right rows*. **Say what rows.**
- **(C) Needs a precomputed `dashboard_state` blob** — `/lobbying` (`lda_lobbying_rollup`, `lda_top_firms`, `lda_topic_crosswalk`), `/bill/[id]` LOBBYING (`lda_bill_drill`), the dashboard lead (`weekly_lead`). No cron runs in CI, so these keys are absent and the surfaces take their omit-when-null path. **A spec asserting the section exists fails, and it fails silently-plausibly** — the page 200s, the section just isn't there.
- **(D) Needs live external state** — markets tape (`market_ticks` freshness), Kalshi/Polymarket odds, anything the `.hover()` case touches. Not fixture-solvable at all.
- **(E) Needs prod egress specifically** — the BotID-blocked paths, the `ct_seen` gate / `/welcome` redirect, cold-start behavior. The HO 379 config comment is explicit that localhost reproduces none of the egress/cold-start class the crawler exists to catch.

Give me the count per bucket and the per-test table. **This number is the decision.** If A+B is most of the suite, build the fixture. If C+D+E is most of it, the fixture is expensive theater and the honest answer is a split suite — which is a much smaller build.

While you're in there, note any test that is **already** effectively asserting nothing (the HO 502(a) `/hearings` case was one — retitled because the calendar exercise its title implied was never written). If there are more of those, they're free to fix and they inflate the apparent suite size.

## Step 3 — fixture provenance and rot

If Step 2 says a fixture is worth it, cost the fixture itself:

- **Where do the rows come from?** Three candidates, pick one and defend it: (a) a committed binary `.db` (fast, opaque, rots silently against `migrate.ts`), (b) a seed script writing synthetic rows (transparent, maintained, and **it becomes a second schema consumer that drifts**), (c) a sanitized export from prod (realistic, and a standing obligation to re-export + a data-in-repo question).
- **How big?** The specs touch bills, members, committees, races, primaries, amendments, nominations, `lda_*`, `stock_trades`, `observations`. Estimate the minimum row count per table for the (B) bucket to pass. If that estimate is "hundreds of rows across ~15 tables hand-maintained," say it plainly.
- **What detects rot?** When `migrate.ts` gains a table, what fails, and does it fail loudly? A fixture that quietly stops representing the schema is worse than no fixture.

## Step 4 — the three known blockers, verified live

Don't take these from the backlog — it's a claim, not a fact. Confirm each against the current tree:

1. `playwright.config.ts` has no `webServer` block (read it — I believe this is still true). What would it need: `npm run build && npm run start` on 3000, or `next dev`? Note the port pin (`-p 3000`) landed at `361d8df`.
2. `TURSO_*` unprovisioned as repo secrets — moot if the fixture path holds; confirm it's moot rather than assuming.
3. The markets-hover `.hover()` timeout. Is it bucket (D)? If so it doesn't get "fixed," it gets **excluded from the CI project and kept in the prod suite**. Say which.

## Step 5 — shape the split

Whatever Step 2 returns, report the concrete shape you'd build:

- One Playwright **project** per target (`ci` against localhost+fixture, `prod` against the live deploy), or two spec files, or a tag/grep filter? Recommend one.
- Does the CI e2e job run on `pull_request`/`push:main` beside `checks`, or as a separate workflow? Note that `ci.yml`'s `paths-ignore` filter and the **branch-protection landmine** (ignored-path PRs never report a required check) apply to any job added there.
- Runtime estimate: install + browsers + build + run. If it's several minutes on every push, say so — that's a real tax on the current one-commit-at-a-time rhythm.

## Step 6 — the honest alternative

Argue the case for **not doing this**, so the decision is made against something.

Phase 1 CI already catches the failure class that actually bit us (`3ed533c` shipped with a broken typecheck). The e2e suite's value is concentrated in exactly the buckets a fixture can't serve — egress, cold start, BotID, real markets data — and it runs fine manually against prod today. A plausible verdict is: **wire nothing, keep the suite prod-manual, and close the loop as "deliberately not automated,"** or wire only the (A) bucket as a thin post-deploy smoke against prod using the existing `BASE_URL` override and no fixture at all.

I don't have a prior here. Step 2's numbers should pick it. If the report comes back arguing for the no-build option with evidence, that's a successful probe, not a failed one.

## Constraints

- **Read-only.** No edits to `.github/`, `e2e/`, `playwright.config.ts`, `lib/db.ts`, `scripts/migrate.ts`.
- Step 1 may create a scratch `file:` DB **outside the repo** (or gitignored) to answer the question. Delete it. Nothing enters the tree.
- Don't build a partial fixture "to see if it works." The report is the deliverable.
- If something resists classification — a test you can't bucket, a blob dependency you can't trace — **report it as an open question**. Unresolved questions in the report are useful; guesses in the build are not.

## Report back

Step 1 verdict (`file:` works / needs a `lib/db.ts` change, with the exact shape) · the Step 2 per-test bucket table plus counts · Step 3 fixture cost if applicable · Step 4 blocker confirmations · Step 5 recommended shape · Step 6 your call between fixture / split / don't-build, with the reasoning. I'll write the build — or the tombstone — from it.

No commit unless a durable diagnostic script falls out, and if one does, show me the diff first.
