# HO 630 — Absence Watch expands the member card in place; navigation becomes opt-in

Main is `83a29fa` (628 + 629 code landed; both docs closes still owed — see Close). This is **630**. Owner ruling, same product logic as HO 627's: the drill moves one level in, not away.

## Today's behavior and the target

`AbsenceWatchBand.tsx:81` wraps the whole row in `<Link href="/members/{bioguideId}">` — any click leaves the dashboard. Target: a plain click expands the member's card inline under the row; the member page stays reachable via modifier-click on the name and via the card's own drill.

The card is not new: `SponsorExpandedPanel` (HO 198's three-column member card, reused by the merged `/members` browser at `app/members/page.tsx:400`). Reuse it verbatim — no absence-specific card variant.

## Why the /members data path doesn't transfer, and what does

`/members` expands by URL state: `isExpanded && expansion` is server-rendered per selected member. Borrowing that means navigation — the defect. Instead: **prefetch, then toggle.**

**Commit 1 — data.** Extend the band's data path so each absent member carries the card's `expansion` shape (`stats, topics, recentBills, committees, affiliations` — see the page.tsx:400 prop list for the full set of scalars riding alongside). Find the helper `/members` uses to assemble `expansion`; if it's inlined in the page, extract it to `lib/queries` as a shared helper — this HO makes it two-consumer, which is the promotion bar.

- Assembly rides inside the existing cached `getAbsenceWatch` (votes tag, one regen/day). The degradation guard outside the cache boundary stays exactly as is.
- **Per-member try/catch, and the failure mode is specified:** a card-assembly failure degrades that member to identity-only (the row still renders from the base query) and must never empty the band. "Card data missing" collapsing into "nobody is absent" is the HO 622 silent-wrong-answer, one level up.
- HO 533 serialization check on the extended return: plain arrays/objects only, no Map/Set/Date across the `unstable_cache` boundary.
- Cost measured, ledger discipline: state the rows_read delta in the commit. It scales with band membership, which the streak≥30 filter bounds to a handful; today it is 2 members.

**Commit 2 — the band expands.** Rows stay server-rendered text (the HO 574/589 constraint holds: no client time derivation anywhere — grep-gate the island for `Date`/`now`). A client wrapper owns single-open `expandedId` (the feed's idiom) and:

- Row: `<Link>` → `div role="button" tabIndex={0} aria-expanded` with Enter/Space handlers — the v2f-row pattern verbatim.
- The member **name** becomes the anchor to `/members/{bioguideId}` with modifier-aware onClick: plain click expands the row; ctrl/cmd/shift/middle navigates and must **not** also expand — the HO 627 mirrored-defect (the event bubbles even when you let the default happen; the gate below checks both directions).
- Leading disclosure glyph, the v2f-disc idiom: `▸`, dim, rotates 90° amber on open, leading not trailing.
- On open, `SponsorExpandedPanel` renders as the row's sibling inside the `<li>` — conditional render from prefetched props, no fetch, no loading state.
- Drill one level in: verify the card's existing buttons put the member-page link visibly near the top at band widths; if the stacked layout (commit 3) pushes them below the summary run, add the packed-left `→ FULL PAGE` head-drill, the HO 627 bxp precedent.
- Identity-only members (commit 1's degraded case) render the row without the glyph and without expand — a row that advertises an affordance it can't honor is the 627 defect again.

**Commit 3 — the scoped narrow collapse.** The card has no container handling (only a mobile media tweak at globals.css ~6737); its three columns were tuned against the `/members` pane. Post-629 the band's region reads ~1350px at 2560 and **~760px at the 1440 floor**. Per HO 623's rule the threshold must be derived for this container, and per the HO 507 shared-component rule the fix is scoped to the band's mount, not the card:

```css
.abw-card-wrap { container: abwcard / inline-size; }
@container abwcard (max-width: <measured>px) {
  .abw-card-wrap .sponsor-expanded-panel { /* stacked columns */ }
}
```

`<measured>`: render the card at descending wrapper widths and state where three-column legibility actually dies (columns under ~200px, committee names wrapping unreadably) — a few width/readability pairs in the commit, the applied-curve habit, not a guessed number. `.sponsor-expanded-panel`'s global rules are untouched; `/members` must render byte-identical (verify, don't assert).

## Gates

1. **Click gate extends.** Absence rows join the harness alongside the bill rows' 16/16 (which must still pass untouched): plain click at row center expands and does not navigate; ctrl-click on the name opens `/members/{id}` in a background tab and does not expand (`tabs 1→2 · open=false`); Enter and Space toggle; both widths. Band sits at top of page — no scroll leg needed, say so rather than silently dropping it.
2. Audit `--route home` at 2560, default state: **M1 0 · M1x 30 · M4-true 1 / 42px** — the band's two rows still fall between M1a's and M1b's gates (the HO 622 note), and the crawl does not open panels, so the card's interior is inherited from `/members`' P4-worked hygiene, not re-scored here. State that scoping honestly in the commit.
3. Typecheck + build per commit; explicit pathspecs; code and docs never mixed.

## Verification

Prod-verify converged (the band regenerates on the votes tag — confirm the deployed SHA first via `/api/version`, then read until the card markup holds across sequential reads). Screenshots at 1440 and 2560: band closed, one card open at each width, the 1440 shot showing the collapsed layout if the threshold binds there.

## Close — the owed blocks land in order

Docs commits, one review-ref carrying all three blocks in sequence (or sequential refs if cleaner): **HO 628's block** (hairline, the dropped mock declaration, source-order mechanism, commit 2 not taken — ruling recorded), **HO 629's block** (owner ruling at 45% off the live-knob mock, the C8 rows-scope argument, measured widths, bxp check outcome, `docs/design/mock-629-bills-boundary.html` committed alongside), then **HO 630's block** (this HO: the redirect→expand ruling, the prefetch-then-toggle shape, the per-member degradation rule, the scoped collapse threshold with its measurements). Pointers → 628, 629, 630, each block frozen-per-block, monotonic. Grep gates per block. Delete the stale `refs/heads/620-review` on origin if it still exists.
