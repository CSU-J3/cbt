# HO 550 — STEP 0: procedural amendment outcomes (read-only probe)

Take the number from the roadmap pointer (currently "run through HO 548"), not from a filename. **This handoff builds nothing.** One read-only diagnostic script, six measurements, then HALT for a GO/NO-GO call in chat. Do not write a query layer, a component, or a migration off the back of it.

## Why a probe first

The banked item (HO 537 M8) is the 64 Senate roll calls that touch an amendment without being its up-or-down vote — Motion to Table, Cloture Motion, Decision of the Chair, and the `Motion to Waive … Budgetary Discipline Re: … Amdt. No. N` waivers. The oddities entry already establishes *why* they can't ride the amendment-framed `VoteLine`: their yea/nay is on the motion, so the polarity is inverted or orthogonal, and `deriveDisposition` gets the word but not the meaning.

What's never been measured is whether the surface is worth building, and whether the premise it rests on is even true on both chambers. Two things to establish before anything gets specced.

**The chamber asymmetry is the priority measurement.** `lib/amendment-votes-senate.ts` matches Senate votes through the anchored `SENATE_AMDT_Q` regex — up-or-down only, procedural deliberately excluded. But `lib/amendment-votes-walk.ts` (House, HO 532) does no such filtering: it takes **every** `recordedVotes` entry off the amendment's `/actions` and links it, whatever the motion. If Congress.gov attaches a procedural roll call to a HAMDT's actions — a motion to table, ordering the previous question — it lands in `amendment_votes` and `BillAmendments` renders its tally as the amendment's own outcome. That would be **wrong data on prod today**, the precise failure the Senate matcher exists to prevent, and it would outrank the feature.

So M5 below is not a nice-to-have. If it comes back non-zero, stop and report — the fix takes priority over the surface.

## The script

`scripts/diagnostic/procedural-amendment-votes-550.ts`, read-only (SELECTs only, no writes, no schema). Follow the existing diagnostic conventions in that directory — header comment stating what it measures and why, printed sections per measurement, honest counts.

**M1 — class coverage.** Enumerate every Senate vote whose `question` mentions an amendment but does **not** match `SENATE_AMDT_Q` (the M8 residual, expected ~64). Print each question verbatim, grouped by normalized leading form. The question to answer: does a small deterministic class set — table / cloture / chair / waiver — cover **100%**, or is there a tail? Print the tail explicitly if one exists; a motion-aware model is only viable if the vocabulary is closed. Report the group counts against M8's 14 + 50 split and flag any drift (`votes` is append-only, so the count can only have grown).

**M2 — number-token resolution.** The waiver form carries `Amdt. No. N`, a different token from `S.Amdt. N`. Per class, extract the amendment number, and report what fraction resolves to a real `amendments` row. State the namespace question plainly: is the waiver form's `N` the same Senate amendment number, or a different numbering? Don't assume it is because the regex matches — check that the resolved row's type/congress is coherent. An unresolvable token means that vote can't attach to anything and drops out of scope.

**M3 — the payoff number, and the one most likely to kill this.** Of the amendments the residual resolves to, how many do **not** already carry an anchored decisive vote? That's the count of amendment rows that would gain a line they don't have today. M8 already found 3 of the 14 resolving votes attach to an amendment with an anchored vote (the double-line risk — and `list[0]` date-sort could even promote the procedural one over the real one). Run that across all 64. If most of the residual attaches to amendments that already display their real outcome, the surface adds almost nothing and the honest verdict is NO-GO — say so.

**M4 — does the polarity rule actually hold?** For each (class, `votes.result`) pair, state the implied amendment fate under the inversion model — tabling agreed = killed, tabling failed = survived, cloture rejected ≠ amendment rejected, chair sustained is orthogonal — and cross-check against the amendment's `amendments.latest_action_text` where one exists. Report the agreement rate **and the N it's computed over**. Coverage will be thin (only ~8.6% of amendments carry a top-level action text), so a high agreement rate on N=4 is not validation and must not be reported as if it were. If N is too small to conclude anything, that is itself the finding: the model would ship unvalidated.

**M5 — the House asymmetry (run this first, report it first).** Count rows in `amendment_votes` whose `vote_id` points at a `votes` row whose `question` is **not** an up-or-down form. Print every one found: amendment id, vote id, question, result, tally. These are rendering through the amendment-framed `VoteLine` right now.

Zero is a clean result and worth stating as one — it would mean Congress.gov only attaches decisive roll calls to a HAMDT's actions, and the unfiltered walk is safe by luck of the upstream data rather than by construction (which is still worth writing down, because it's a dependency on someone else's behaviour). Non-zero is a P1: report it and stop there.

**M6 — cost.** Cold-time whatever join the surface would need, from idle. 64 rows is trivial and this will almost certainly be fast, but the convention is to measure rather than assert — a clean `EXPLAIN` says nothing about cold latency (HO 340/437), and the HO 543 lesson is that pricing the cheapest component isn't pricing the query you'd ship.

## Constraints

- Read-only. SELECTs only. No writes, no schema, no app code, no component.
- One commit, diagnostic-only: `diag: HO 550 STEP 0 — procedural amendment-vote residual (read-only)`. Explicit pathspec on the single script.
- **HALT after the report.** No build, no follow-on commit, no spec written off your own findings.

## Report back

- **M5 first** — the House asymmetry, with every offending row printed, or a stated zero.
- M1 class table with the tail called out; M2 resolve rates per class + the namespace answer; M3 the payoff count; M4 the agreement rate **with its N**; M6 the cold number.
- Your read on GO / NO-GO, with the reason — and if the answer is that the surface earns too few lines to justify a motion-aware model, say that. A NO-GO here is a good outcome; it retires a banked item on measurement instead of leaving it to be re-proposed, the way HO 546 retired FTS.
