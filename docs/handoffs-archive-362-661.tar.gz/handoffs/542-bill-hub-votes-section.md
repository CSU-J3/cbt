# HO 542 — Bill-hub passage/procedural VOTES tab (`/bill/[id]`)

**One-liner.** `getVotesByBill` is written, cached (`["votes"]`), indexed, and **unconsumed** — so `/bill/[id]` renders its *amendments'* votes (HO 530/532/533) but not the bill's *own* passage/procedural roll calls. Wire the orphan into the HO 510 `RecordTabs` box as a VOTES tab, each row → `/vote/[id]` (the entity page HO 540 just built to link into).

This is a QUEUED top-of-ledger pick. Bills-scale, no new query, no migration, no cron, no index. The one real unknown is **overlap with the Amendments tab** — handled by an inline STEP 0 measurement below, then a small filtered build.

Take the HO number from `docs/roadmap.md`'s pointer, not this filename. Roadmap runs through HO 540; HEAD is the HO 541 `/vote/[id]` doc sweep — so this is **HO 542**.

---

## Ground truth (already verified from the clone — don't re-probe these)

- `getVotesByBill(billId): Promise<Vote[]>` — `lib/queries.ts` ~L7153, `WHERE v.bill_id = ? ORDER BY v.vote_date DESC, v.id DESC`, `revalidate: 3600`, tags `["votes"]`. Zero consumers repo-wide (grep-confirmed).
- `votes.bill_id` rides `idx_votes_bill_id ON votes(bill_id) WHERE bill_id IS NOT NULL` — the read is a bounded partial-index seek. **No cost gate** (HO 448/450 bills-scale precedent).
- `Vote` fields available: `id · chamber · congress · session · rollCall · voteDate · question · description · result · billId · billTitle · amendmentDesignation · yeaCount · nayCount · presentCount · notVotingCount`.
- The record-box tabs are built in `app/bill/[id]/page.tsx` (~L166–270): fixed order committees → hearings → amendments → lobbying, each **omitted at zero** (a tab exists only when its section renders today), `initialKey` = highest `count` among present tabs.
- Vote-link shape is `/vote/${vote.id}` (voteId is a TEXT composite, e.g. `senate-119-1-3` / `house-119-1-32`). `AmendmentVoteLine.tsx` L59 and `MemberVoteRow.tsx` L91 both use it.
- `getBillAmendmentVotes(bill.id)` is already fetched on the page (L142) and its `AmendmentVote` values carry `voteId` — so the amendment-vote id set is buildable **from data already in scope**, no extra query.

---

## STEP 0 — measure the overlap + own-vote population (read-only, report back before building)

`getVotesByBill` returns *every* vote carrying this bill's `bill_id`. Per HO 532, House amendment votes carry `bill_id` (Senate amendment votes are matched by question-parse and mostly don't) — so some of what `getVotesByBill` returns is **already shown in the Amendments tab**. The VOTES tab must show the bill's **own** votes (passage, motion to recommit/table, cloture, procedural on the bill itself), not re-list amendment votes.

Write `scripts/diagnostic/bill-votes-overlap-542.ts` (read-only, committed sibling of `vote-detail-cost-540.ts`). For three bills — a vote-a-rama magnet (`119-hr-1`), a normal passage bill, and a House-amendment-bearing bill — print:

1. `getVotesByBill` row count, and of those how many `vote.id` appear in that bill's `amendment_votes` links (the House-amendment overlap) **plus** how many match the Senate amendment question pattern via `lib/amendment-vote-key.ts` (belt-and-suspenders — the exclusion set should be the union).
2. The **remaining count after exclusion** = the bill's own votes. This is the number that justifies the tab.
3. Corpus-wide: of the 890 `bill_id`-carrying votes (HO 540 STEP 0), how many survive the amendment-vote exclusion — i.e. how many bills would actually get a VOTES tab, and the per-bill distribution (p50/p90/max).

**Report the numbers back before building.** Expected GO shape: a real own-vote population (passage/procedural votes across many bills), overlap concentrated on amendment-heavy bills. **NO-GO / replan** if the exclusion empties the tab on nearly all bills (then the feature is thin and we rethink), or if own-votes turn out to already be covered elsewhere. Given HO 540 established 890/1513 carry `bill_id` and only ~97 null-bill_id ones resolve to amendments, a healthy own-vote set is likely — but confirm, don't assume (a backlog line's mechanism is a claim).

---

## The build (after STEP 0 GO)

### 1. Consume the orphan (`app/bill/[id]/page.tsx`)

Add `getVotesByBill(bill.id)` to the existing `Promise.all`. Build the exclusion set from data already in scope:

```ts
const ownVotes = billVotes.filter((v) => !amendmentVoteIds.has(v.id));
```

where `amendmentVoteIds` is a `Set<string>` collected from the already-fetched `amendmentVotes` map values (their `voteId`). If STEP 0 shows Senate amendment votes also leak into `getVotesByBill` on any sampled bill, extend the set with the `lib/amendment-vote-key.ts` question match; otherwise the House-link set is sufficient.

### 2. New row component (`components/BillVoteRow.tsx`, server)

The bill hub has **no per-member position**, so `MemberVoteRow` (member-scoped `[YEA]` chip) is the wrong component and `VotePositionList` (the per-member breakdown) is the heavy `/vote/[id]` view — neither fits. Write a small new summary row (the "new sibling, don't widen" discipline):

- Label: `question ?? description ?? "—"`, then `· {result}` when `result` present (the `MemberVoteRow` questionLine idiom).
- Tally: `{yeaCount}–{nayCount}`, yea/nay colored via `--vote-yea` / `--vote-nay`. **Suppress the tally entirely** when `yeaCount + nayCount + (presentCount ?? 0) + (notVotingCount ?? 0) === 0` (the HO 540 by-name/procedural case — a Speaker-election-style "0–0" is meaningless; show label + result only).
- Date: `formatDateShort(vote.voteDate)`.
- The whole row (or the roll-call `#{rollCall}` anchor) → `/vote/${vote.id}`. Follow the `MemberVoteRow` pattern: if you make the row a link, don't nest another; the `#{rollCall}` anchor is the clean choice.
- Additive CSS under a new `.bvote-*` scope, reusing tokens — **do not touch** `.vote-row` (it backs `MemberVoteRow`) or any shared `.rec-*` / `.mc-*` / `.bxp-*` / `.bdp-*` rule.

### 3. Push the VOTES tab

Insert **between amendments and lobbying** — a bill's own passage/procedural votes are the culminating floor action on the whole bill (amendments act on parts; passage acts on the whole), and lobbying (outside money) stays orthogonal-last. Fixed order becomes: committees → hearings → amendments → **votes** → lobbying.

```ts
if (ownVotes.length > 0) {
  tabs.push({
    key: "votes",
    label: "Votes",
    count: ownVotes.length,
    content: ( /* map ownVotes → <BillVoteRow> */ ),
  });
}
```

- **Omit at zero** — no VOTES tab when the bill has no own votes (most bills, introduced-never-voted). Matches the HO 510 bill-page section-omission exactly.
- `initialKey` is count-based and unchanged: own-vote counts are small, so Votes won't steal the initial tab from Amendments/Lobbying on heavy bills; a passage-only bill opens on Votes. Correct either way — no `initialKey` edit.
- No `outLabel`/`outHref` — there's no aggregate votes-by-bill surface to link out to (unlike `/amendments`).

---

## Decisions already made (don't re-litigate)

- **Placement** committees → hearings → amendments → **votes** → lobbying (legislative sequence; votes = culminating floor action).
- **Exclusion of amendment votes** — the VOTES tab is the bill's *own* roll calls; amendment votes stay in the Amendments tab. Filter by the amendment-vote id set built from already-fetched data.
- **Omit-at-zero**, same as every other bill-page tab.
- **New `BillVoteRow`**, not a reuse of `MemberVoteRow`/`VotePositionList` (no member context on the bill hub).
- **Tally suppression** on all-zero (procedural/by-name votes).

## Out of scope / banked

- No aggregate votes-by-bill surface, no `/votes` route, no new query, no migration/cron/index.
- No per-member drill on the bill hub — that's `/vote/[id]` (HO 540), which each row links to.
- Don't fold the two party-split mechanisms (that's the HO 540 BANKED item, gated on a third consumer — not triggered here; this row shows a tally, not a split).

## Verify + git discipline

- STEP 0 diagnostic committed **separately** from the build (diagnostic ≠ feature commit boundary). Report its numbers before writing the build.
- `tsc` clean + `next build` green (CI runs both, HO 488).
- Prod-verify on the **cache-hit path** (hit each URL 2–3×, not just the post-deploy miss — the HO 533 lesson): a passage-only bill (VOTES tab opens, rows link to `/vote/[id]`), a vote-a-rama bill (`119-hr-1` — confirm amendment votes are NOT double-listed in VOTES, and Amendments tab is byte-identical), an introduced-never-voted bill (no VOTES tab), and confirm the feed expand panel + the other four tabs are byte-identical (containment held).
- Explicit-pathspec staging only; diff shown and approved before every commit; fast-forward only; code and diagnostic commits ride separately. No auto-commit.
- Roadmap block + this HO's doc sweep are a **separate** docs commit after the build lands (never ride with code).

read docs/handoffs/542-bill-hub-votes-section.md and follow it
