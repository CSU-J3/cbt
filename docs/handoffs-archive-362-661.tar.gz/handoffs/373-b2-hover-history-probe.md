# HO 373 — B2 hover history probe

Read-only diagnostic to scope the hover enrichment (sparkline + trailing delta). Determine what `market_ticks` actually holds per symbol so the build picks the right window, gap handling, and delta tolerance. Diagnosis only, no deploy change, nothing to build.

Run every query against the **live hosted Turso** (the instance the app uses, via the existing db client/env), not the `/mnt/project` snapshot. `market_ticks` is small and the `(symbol, ticked_at DESC)` index covers these reads, so no EXPLAIN / INDEXED BY needed.

## Two premises Code would otherwise get wrong

**Timestamp format trap.** `ticked_at` is stored ISO-UTC with a `T` and likely a `Z`/fractional seconds (HO 142). `datetime('now', ...)` returns `YYYY-MM-DD HH:MM:SS` with a space and no `Z`. Naive string comparison (`ticked_at >= datetime('now','-1 day')`) is silently wrong because `T` > ` ` lexically. **Compare with `julianday()` on both sides** in every offset query, as written below. `MAX(ticked_at)` for "latest row" is fine as a string compare (one consistent writer), the trap is only the cross-comparison against `now`.

**Rolling-symbol fragmentation.** Fed-cut and shutdown are dynamic Kalshi events that roll (HO 251: `KXFEDDECISION-26JUN` → `-26JUL` after the meeting closes; shutdown `KXGOVTSHUTDOWN-26OCT01`). If the symbol string written to `market_ticks` is the rolling event ticker, then the history for one displayed item ("FED CUT") is split across multiple symbol strings with non-overlapping date ranges, and a trailing-window sparkline silently breaks at every roll. The single most load-bearing output here is: **what symbol string does each odds item store, and is it stable across a roll.** The build keys the sparkline on whatever's stable.

## What to determine, per symbol

1. **Roster reconcile.** Distinct symbols in the table, mapped to the displayed tape items (SPX, NDQ, 10Y, WTI, NVDA, AAPL, MSFT, GOOGL, LMT, CPI, UNEMP, SHUTDOWN, FED CUT JUL, FED CUT SEP, RECESSION). Flag stored-but-not-displayed rows (dead history, e.g. the old DXY/VIX from the HO 142 roster) and displayed-but-not-stored items (can't sparkline). Record the exact symbol string for each odds item.
2. **Density + retained window.** Total count, first/last tick, and counts in trailing 24h / 7d / 30d. Reveals points-per-window and whether HO 172's prune is capping the retained span.
3. **Gap structure.** Avg and max inter-tick gap over the trailing 7d. Equities go dark on weekends/holidays (expected holes), FRED dailies ~daily, odds continuous. Cron failures (HO 313/314) show as outsized gaps. Decides time-based-with-gap-handling vs index-based even-spacing for the x-axis.
4. **Delta feasibility.** Per symbol: price now, nearest price ≤ 24h ago, nearest price ≤ 7d ago, with each anchor's actual timestamp. Shows how stale the "24h"/"7d" anchor really is (a Friday-close equity has no Saturday −24h row) and which symbols have no 7d anchor at all (odds added <7d ago). Sets the nearest-match tolerance.

## Queries

**A — roster + density (one pass):**
```sql
SELECT
  symbol,
  COUNT(*)        AS n_total,
  MIN(ticked_at)  AS first_tick,
  MAX(ticked_at)  AS last_tick,
  SUM(CASE WHEN julianday(ticked_at) >= julianday('now','-1 day')  THEN 1 ELSE 0 END) AS n_24h,
  SUM(CASE WHEN julianday(ticked_at) >= julianday('now','-7 day')  THEN 1 ELSE 0 END) AS n_7d,
  SUM(CASE WHEN julianday(ticked_at) >= julianday('now','-30 day') THEN 1 ELSE 0 END) AS n_30d
FROM market_ticks
GROUP BY symbol
ORDER BY symbol;
```

**B — gap structure, trailing 7d:**
```sql
WITH w AS (
  SELECT symbol, ticked_at,
         (julianday(ticked_at)
          - julianday(LAG(ticked_at) OVER (PARTITION BY symbol ORDER BY ticked_at))) * 24 AS gap_h
  FROM market_ticks
  WHERE julianday(ticked_at) >= julianday('now','-7 day')
)
SELECT symbol,
       COUNT(*)            AS pts_7d,
       ROUND(AVG(gap_h),2) AS avg_gap_h,
       ROUND(MAX(gap_h),2) AS max_gap_h
FROM w
WHERE gap_h IS NOT NULL
GROUP BY symbol
ORDER BY symbol;
```

**C — delta anchors (run the three, join on symbol in the report):**
```sql
-- now
SELECT symbol, price AS price_now, ticked_at AS at_now
FROM market_ticks m
WHERE ticked_at = (SELECT MAX(ticked_at) FROM market_ticks WHERE symbol = m.symbol);

-- nearest <= 24h ago
SELECT symbol, price AS price_24h, ticked_at AS at_24h
FROM market_ticks m
WHERE ticked_at = (
  SELECT MAX(ticked_at) FROM market_ticks
  WHERE symbol = m.symbol AND julianday(ticked_at) <= julianday('now','-1 day'));

-- nearest <= 7d ago
SELECT symbol, price AS price_7d, ticked_at AS at_7d
FROM market_ticks m
WHERE ticked_at = (
  SELECT MAX(ticked_at) FROM market_ticks
  WHERE symbol = m.symbol AND julianday(ticked_at) <= julianday('now','-7 day'));
```

**D — odds roll-stability:**
```sql
SELECT symbol, COUNT(*) AS n, MIN(ticked_at) AS first_tick, MAX(ticked_at) AS last_tick
FROM market_ticks
WHERE symbol LIKE '%FED%'  OR symbol LIKE '%CUT%'    OR symbol LIKE '%KXFED%'
   OR symbol LIKE '%SHUT%' OR symbol LIKE '%KXGOV%'
   OR symbol LIKE '%RECES%' OR symbol LIKE '%RECSSN%'
GROUP BY symbol
ORDER BY symbol;
```
If multiple symbol strings map to one displayed odds item with non-overlapping date ranges, that's the fragmentation. Report it plainly.

**Code cross-check.** Grep the markets fetch/write layer for the `INSERT INTO market_ticks` site and read what `symbol` it writes for the Kalshi/Polymarket items — a stable internal key, or the raw rolling ticker. The code is ground truth; query D confirms it in the data. Do both.

## Output

A short table for A–C, the query-D + code verdict on roll stability, and the roster reconcile (stored-not-displayed / displayed-not-stored). Close with a one-line read on each decision this probe exists to settle:

- sparkline window: 7d / 30d / last-N ticks (from density + retained window)
- x-axis: time-based with gap handling / index-based even spacing (from gap structure)
- odds: sparkline now, or delta-only until history accumulates (from odds density + roll stability)
- delta nearest-match tolerance (from anchor staleness)

That unblocks the build handoff.

## Ship

Read-only. If you add a script, `scripts/diagnostic/b2-hover-history-probe-373.ts`, mirror the `tape-source-probe-288.ts` pattern and commit it with a named `git add`. Nothing to deploy, no `verify:deploy`. Paste the output back.
