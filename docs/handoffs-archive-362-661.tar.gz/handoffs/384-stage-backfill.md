# 384 — One-time stage backfill (computeStage, advance-only)

**Self-claim:** if `docs/handoffs/384-*.md` exists, bump to the next free number (`ls docs/handoffs/ | sort -V | tail`) and rename before starting.

**Scope:** correct corpus-wide stale stored `stage` by recomputing it from `latest_action_text`, advance-only (never regress). The dry-run is read-only and runs freely. The apply step is a bulk write on the shared prod Turso, so HALT after the dry-run and surface the bucket counts before writing. No commit until the script/diff is approved.

## Why (resolved premises)

- 383 made `computeStage(latestActionText)` the deterministic stage authority, in `lib/enums.ts` beside `stageRank`/`ALLOWED_STAGES`, carrying two guards beyond the raw prompt (Senate-officer false positives like "President pro tempore" → not president; post-passage procedural motions → floor). The monotonicity guard is the existing `decideStage` helper the runner and sync use.
- 383 fixed the forward path: sync and the runner now write computed stage. But sync only re-touches a bill on a real `update_date` advance, so the already-stale backlog is not retroactively corrected. Only each bill's next advance fixes it, and for terminal stages (enacted) there is no next advance, so those rows stay wrong indefinitely.
- 383's queue preview confirmed this is corpus-wide, not one bill: 6 enacted bills stored as `other_chamber`/`committee`, floor stored as `committee`, and more.
- The visible effect is on **ungated** stage readers, notably the `/bills?stage=` filtered lists (just unblocked by 382), where a bill stored as `committee` but truly `enacted` wrongly appears under committee and is missing from enacted. The home funnel is summary-gated (`getStageDistribution(summaryGated=true)`), so corrected stage on an *unsummarized* bill won't move gated counts until it's summarized. The backfill is the right data-integrity fix regardless, and makes the stage correct for whenever the bill is summarized.

## Backfill semantics

- For every bill: `computed = computeStage(latest_action_text)`, then `new = decideStage(stored, computed)` (the existing monotonicity guard). Reuse 383's functions exactly. Do not reimplement either, or the backfill drifts from the live path.
- **Advance-only.** The guard means a bill whose latest action maps *lower* than its stored stage (re-referral, post-passage procedural) keeps its stored high-water, never regressed. Only bills whose stored stage fell *behind* their progress get corrected.
- **`stage` column only.** Do not write `stage_transitions` rows, and do not set `stage_changed_at` (especially not to now, which would flood `/changes` and the Monday report with ~1.4k fake recent advances). The backfill corrects the snapshot, not the history; accurate transition timing can't be reconstructed from `latest_action_text` alone, and the live forward path owns the log going forward. Leaving `previous_stage`/`stage_changed_at` stale on corrected rows is an accepted cosmetic cost.
- **Idempotent.** After a successful apply, `computed == stored` for corrected bills, so a second run is a no-op. Good re-run safety.

## Steps

1. **Dry-run (read-only, run freely).** `SELECT id, stage, latest_action_text, latest_action_date` for all bills; compute `new = decideStage(stored, computeStage(latest_action_text))` in TS. Bucket and report:
   - **Advances** (`new > stored`): count, the stage-transition tally (e.g. `committee→enacted: 6`), and a sample. These are what the apply will write. Confirm the known cases appear (the 6 enacted-stored-as-committee, the floor-stored-as-committee).
   - **No change** (`new == stored`): count.
   - **Would-regress** (`computeStage(text) < stored`, the guard holds them): count + the **full list**. The apply does nothing to these; we want eyes on whether any are genuine over-staging (a separate problem) versus legitimate high-water / re-referral cases (correct to keep).
   - **Within `/changes` window:** of the advances, how many have `latest_action_date` inside the recent `/changes` window. A sanity check that we're not surfacing a flood (we aren't, since `stage_changed_at` is untouched); report it for awareness.
   - **HALT here** with these numbers. No write until go.
2. **Apply (bulk write, only on explicit go).** For the advances bucket only, batched `UPDATE bills SET stage = ? WHERE id = ?` in chunks (libSQL batch, ~few hundred per chunk), `stage` only. Report rows written.
3. **Verify.**
   - Re-run the dry-run comparison: advances bucket now 0 (idempotency confirmed).
   - Spot-check the known cases: the 6 formerly-committee bills now read `enacted`.
   - Confirm ungated counts shifted: `/bills?stage=committee` count drops by the corrected amount, `enacted`/`floor`/etc. rise correspondingly.
   - Confirm `/changes` was not flooded (`stage_changed_at` untouched).
   - tsc clean.
   - Show the script + the before/after bucket numbers. Hold for commit approval. Keep the script tracked as a one-off provenance record, header-commented do-not-blind-re-run (though it's idempotent).

## Out of scope / banked

The dead LLM stage output in the prompt (383 banked its removal), the B-sync watch item (waits for a live advance), the doc sweep, the gated home-bar logic (correct as-is), CCBT.

## Report back

The three bucket counts + the stage-transition tally, the would-regress full list, rows written on apply, and the verify results.
