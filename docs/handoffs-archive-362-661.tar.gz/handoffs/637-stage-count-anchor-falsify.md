# HO 637 — falsify disposition (4) before it moves eight readers

HEAD `89eb8cb`. Pointer runs through HO 636. **Next free is 637.**

Takes up the QUEUED entry opened at HO 636: eight class-(C) readers still window counts on the observation clock, with disposition (4) recorded as **priced and proven viable**. Read-only through the HALT. Nothing commits before the ruling.

---

## The premise is not established, and the record says it is

**85.0% measures binning accuracy for rows already in the set. It does not measure set membership.** The sample was 40 rows already known to be recent movers, and the question asked of each was "does `latest_action_date` put this row in the right week." Moving the window changes *which rows are in the set at all*, and that direction was never measured.

The current predicate (`buildChangesWhere`, `lib/queries.ts:6747`) is:

```sql
stage_observed_at IS NOT NULL
stage_observed_at > datetime('now', '-N days')
```

Under (4) the second clause moves to `latest_action_date`, and the first has to stay, because it is what makes the row a transition at all. So the predicate becomes **"the stage has moved at some point, AND the latest action of any kind was recent."** Those are not the same bills.

A bill referred to committee in May that picked up a cosponsor yesterday satisfies both clauses and **enters this week's STAGE TRANSITIONS count without having transitioned this week.** The observation clock does not have this failure; whatever else is wrong with it, it only counts advances it actually saw. (4) trades a dating error for a membership error, and only one of the two has been measured.

**This reaches a landed number.** The `163 / 114 / 288 / 180` occurrence column in HO 635's M4 was itself computed by windowing on `latest_action_date`, so it carries whatever false positives exist. The roadmap block states `243` against `163` as "49% high" and describes the four-week shape as inverting. If the false-positive rate is material, **163 is not the true count either**, the true number is unmeasured, and both claims need an appended correction. The roadmap is append-only, so that would be a new block, not an edit.

**ENACTED is unaffected and stays shipped.** For an enacted bill the latest action is the enactment, which is terminal, so the false-positive class does not arise there. HO 635's reasoning holds for the one reader that moved.

---

## Step 0 — verify, don't inherit

Two claims from the record to re-check at `89eb8cb` before measuring, because both are load-bearing and both are inherited rather than observed here.

- The predicate shapes above, read from the code rather than from this handoff.
- **The clock/date mismatch.** `stage_observed_at` is a full ISO timestamp and the window uses `datetime('now', ...)`; `latest_action_date` is date-only. Confirm what `latest_action_date` actually stores, and state which of `date()` / `datetime()` the moved window needs. Mixing them silently shifts a boundary by up to a day, which on a 7-day window is a 14% error nobody would see.

---

## M1 — the falsification, and it gates everything

For the current week and the three prior, over the same window `getStageChangesCount` uses:

1. The set under the shipped predicate (observation clock).
2. The set under (4)'s predicate (`stage_observed_at IS NOT NULL` + `latest_action_date` in window).
3. **The intersection, and both differences.** The rows in (2) but not (1) are the candidate false positives; the rows in (1) but not (2) are transitions (4) drops.

Then classify the (2)-not-(1) rows, which is the measurement that matters: for each, how long before the window did `stage_observed_at` fall? A row whose observation is a few days before the window is (4) working correctly, catching a move we noticed late. A row whose observation is **months** earlier is a false positive: the stage moved long ago and a minor action pulled it into this week.

Report the split with a distribution, not a single rate. **The number that decides (4) is the share of (2) whose `stage_observed_at` predates the window by more than the observation lag itself** (median 3.76d, p90 16.01d from HO 635, n=40). Beyond p90 lag, a row is very unlikely to be a late-observed move.

Bound the sample and state its size. This is four windowed reads plus a classification pass, not a corpus walk.

---

## M2 — only if M1 says (4) is compromised

Three candidates. Measure, don't pick.

- **(4a) Bounded conjunction.** Keep `latest_action_date` as the window and add `stage_observed_at > datetime('now', '-K days')` as a membership guard, K chosen from M1's lag distribution. Kills the months-stale case while keeping the better dating. Its error is bounded and measurable, which is more than either clock has today. Report what K and what it costs in dropped true positives.
- **(4b) `stage_transitions` for the set, `latest_action_date` for the date.** The table has one row per transition, so it identifies the set correctly even though `observed_at` is the same clock. History begins 2026-06-12 and it holds 1,165 rows against 1,115 bills, so state the coverage before recommending it.
- **(4c) Decline for the counting readers.** If no anchor gets the set and the date right, the honest disposition may be that these counts cannot be corrected with what the database holds, and the fix is disclosure rather than re-sourcing. That is a legitimate outcome, not a failure of the probe.

---

## The eight are not one move

Whatever M1 returns, do not treat them as a block. Report which of these the evidence supports moving, and say so per reader:

- **`getStageChangesCount` + `getWeeklyBandTransitionLadder` are coupled.** The ladder sums to the headline, so they move together or the card stops summing. Verify that coupling in the code rather than taking it from here.
- **`getWeeklyBandPriorWeek`** is the other half of a delta. Both halves move together or the delta compares two clocks, which is the ENACTED lesson.
- **`getStageChanges`** is a feed whose window doubles as its ordering, and it is a (C)+(A) hybrid. "What we noticed move recently" is a defensible thing for `/changes` and the MOVERS tab to show. Moving its window while leaving its `ORDER BY` is a design choice, not a mechanical edit.
- **`gatherLeadData`'s two reads** select a lead story. Recency-of-notice is arguably the right selector for a terminal.
- **`gatherReportData`'s two reads** are inside a weekly report about a named week. That is the strongest case for moving after the count itself.

---

## If a build follows

Only after the ruling. Two risks worth stating now so they are not discovered.

- **The index hints.** `getStageChanges`/`getStageChangesCount` force `INDEXED BY idx_bills_stage_observed_at` and `getWeeklyBandTransitionLadder` forces the same. If the window moves to `latest_action_date`, the hint has to move to `idx_bills_latest_action` **in the same edit** — a hint on a column the query no longer constrains is the HO 405/480/481 misplan family, and that family cold-500s rather than failing loudly. Run `cold-start-audit-332.ts` before and after, and reconcile its pinned copies first; HO 635 found one already stale.
- **The comment at `queries.ts:6793`** states that `buildChangesWhere` always constrains `stage_observed_at`, which is the justification for the forced hint. If the constraint moves, that comment becomes false in the place a later reader forms the belief. **This is the schema-comment shape from HO 636's own sweep**, and a rename-style grep gate goes green while carrying it across.

---

## Guards

1. Read-only through the HALT. No writes, no schema, no display change.
2. Commit the probe to `scripts/diagnostic/` with a header naming what it measures and its date.
3. Turso reads are a live budget. Bound the sample, state its size, and do not walk the corpus to answer a question four windowed reads answer.
4. Every figure carries its corpus size and date.
5. Explicit pathspec staging. `npm run typecheck` before pushing.

## Ship report

M1's three sets with the (2)-not-(1) classification as a lag distribution, not a rate · whether (4) survives, in one sentence · **whether `163 / 114 / 288 / 180` and the "49% high" and shape-inversion claims in the landed HO 635–636 roadmap block need an appended correction** · M2's candidates priced, if reached · the per-reader recommendation across the eight · the clock/date mismatch resolved · anything found, filed not fixed.
