# HO 433 — Cron cadence pass (now on Vercel Pro)

## Why now
CBT moved from Vercel Hobby to Pro. Two constraints lift:

- **Cadence.** Hobby capped every cron at once/day; any finer expression failed at deploy. Pro allows per-minute schedules with per-minute precision.
- **Duration.** Fluid defaults are 300s with an 800s Pro max. Our routes still pin `maxDuration: 60` in both `vercel.json` and the route files.

The schedule in `vercel.json` is a Hobby artifact: ten crons hand-staggered across UTC hours (09:00–21:30) so each ran once/day without colliding. That stagger no longer buys anything. Reset each cron to the cadence it actually wants.

Biggest single win: the summarize backlog-timeout loop (HO 404 logged the queue growing 1,011 → 1,374; HO 405/406 patched the doom-loop with a partial `INDEXED BY` queue + worker pool) is structural, not a bug. Summarize runs **once a day**, so any day inflow exceeds one 60s drain, the queue grows. On Pro this is a one-line fix: drain continuously.

## Current cron state (from vercel.json at HEAD 7cbcd37)
```
/api/sync                 0 9 * * *        bills (Congress.gov)
/api/cron/weekly-report   30 9 * * 1       weekly, Mon
/api/sync-votes           0 10 * * *       votes
/api/sync-race-ratings    0 11 * * 3       weekly, Wed
/api/cron/committees      30 11 * * *
/api/cron/primaries       0 12 * * *
/api/cron/summarize       0 13 * * *       LLM summarizer   <-- the offender
/api/cron/news            0 14 * * *
/api/cron/rating-history  0 15 * * *
/api/cron/markets         30 21 * * *      tape (odds / equities / FRED)
```
`app/api/cron/kalshi/route.ts` exists and has a `maxDuration` entry but is **not** in `crons` and has no caller inside `app/` (grep for `/kalshi` returns nothing). Resolve what triggers it before deciding its cadence.

Every function pins `maxDuration: 60` in `vercel.json`. Summarize additionally hard-codes `SUMMARIZE_BUDGET_MS = 45_000` (stop starting new bills at 45s) plus a 15s per-bill AbortController, tuned so 45 + 15 = the old 60s ceiling.

## Step 1 — Diagnose before editing (report, don't change yet)
1. **Idempotency / overlap.** Every route running sub-daily must tolerate duplicate and missed runs — Vercel invokes best-effort and can fire the same schedule twice. Confirm each is reconciliation-based, not increment-based. Expected already-safe: summarize (queue + partial index, HO 406), news (dedup, HO 118), sync (bounded, HO 116). Flag any non-idempotent write.
2. **Summarize run-overlap.** At `*/10` the 45s budget can't overrun the 10-min interval, but under load Vercel may start a second invocation before the first exits. Confirm `runSummarize` tolerates two concurrent drains (the partial-index queue + per-bill claim should make this safe). If not, add a lightweight in-progress guard (a `cron_runs` lock row or equivalent). Report which.
3. **kalshi.** Determine the trigger: called by `markets` via a lib import, run by a script, invoked manually, or dead. Report before wiring a schedule.
4. **Per-source rate limits.** Higher frequency multiplies upstream calls. Note the ceilings and confirm the proposed cadences stay well under them: Congress.gov key, Gemini 2.5 Flash, FMP, FRED, Kalshi, Polymarket. Summarize at `*/10` and news at `*/30` should be fine; confirm.
5. **Early-exit cost.** Pro bills active CPU + provisioned memory, not wall-clock; I/O waits (Gemini, DB, HTTP) don't count. A `*/10` poll is near-free **only if** the route early-returns when there's no work. Confirm summarize / news / markets short-circuit on empty queue or unchanged upstream before doing paid work. If any always does a full scan, fix that before raising cadence.

## Step 2 — Proposed cadence (propose final, show the vercel.json diff, wait)
Starting schedules. Adjust per Step 1 findings.

| Route | Current | Proposed | Rationale |
|---|---|---|---|
| `/api/cron/summarize` | `0 13 * * *` | `*/10 * * * *` | Continuous drain. Retires the HO 404 backlog loop. Keep the 45/15 budget and `maxDuration: 60` untouched. |
| `/api/cron/news` | `0 14 * * *` | `*/30 * * * *` | "Breaking news" becomes actually fresh. Start at 30 min; tighten to `*/15` if cost and limits allow. |
| `/api/cron/markets` | `30 21 * * *` | `*/15 * * * *` | Terminal freshness: odds and equities tick through the day instead of one 21:30 snapshot. FRED (CPI/UNEMP) updates ≤ daily, so keep those specific reads gated once/day inside the route to save calls; Kalshi / Poly / FMP-equities are what benefit. |
| `/api/cron/kalshi` | (unscheduled) | TBD | Per Step 1.3. If it's the odds feed and currently dormant, `*/15 * * * *`; if `markets` already drives it, leave unscheduled. |
| `/api/sync` | `0 9 * * *` | `0 */6 * * *` | Catch same-day Congress actions faster. Congress.gov isn't minute-fresh, so 6h is plenty. |
| `/api/cron/committees` | `30 11 * * *` | `0 */12 * * *` | Low churn; twice a day is enough. Optional — leave daily if simpler. |
| `/api/sync-votes` | `0 10 * * *` | leave daily | Votes post in batches; daily is fine. 2×/day only if you want faster same-day roll calls. |
| `/api/cron/rating-history` | `0 15 * * *` | leave daily | It's a daily snapshot; daily granularity is the point. |
| `/api/cron/primaries` | `0 12 * * *` | leave daily | Event-driven; bump manually around known primary dates. |
| `/api/sync-race-ratings` | `0 11 * * 3` | leave weekly | Cook / Sabato refresh slowly; manual/scrape source. |
| `/api/cron/weekly-report` | `30 9 * * 1` | leave weekly | Correct by definition. |

## Step 3 — Duration
Leave `maxDuration: 60` on every route for now. None of the proposed cadences need more than 60s per run, because frequency replaces per-run volume. Do **not** touch summarize's `SUMMARIZE_BUDGET_MS` / 15s per-bill guard. If news at `*/30` still backlogs on article volume, prefer raising **news** `maxDuration` to 120–300 (Pro allows to 800) over widening its cadence.

## Out of scope (note, don't build)
The manual `sync:*` scripts (ideology, crosswalk, fec, polarization-history, pac-ie) are not cron-wired and stay manual. Scheduling them is a separate decision (GitHub Actions on the public repo runs them as-is under a 6h job ceiling), not this pass.

## Guardrails
- Diagnose (Step 1) → report findings → propose final schedules → show the `vercel.json` diff plus any overlap-guard / early-exit code diffs → wait for approval. No auto-commit.
- Two commits if code rides along: the `vercel.json` change separate from any logic change (overlap guard / early-exit).
- On close, append a dated **HO 433** block to `docs/roadmap.md` noting the once/day Hobby cron constraint is retired and which crons went sub-daily. Append-only: do not retro-edit prior blocks — add a new line that the HO 404 summarize loop is discharged rather than rewriting it.
- `SKILL.md` cron references change only under its self-mod guard, with explicit approval.
