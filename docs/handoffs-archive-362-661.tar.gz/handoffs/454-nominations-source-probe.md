# HO 454 — Probe: nominations source — volume, civilian/military split, join profile (new pillar, GO/NO-GO)

Read-only probe, no writes. Nominations is a candidate new pillar — the other half of the amendments-vs-nominations fork, chosen after amendments closed out (446→453). Unlike amendments (bill spine + member sponsor) and LDA (bill-number join), nominations have **no bill spine and no member-sponsor** — the president nominates, the Senate confirms. So the pillar is more standalone, and this probe characterizes exactly how standalone before any build. Mirror `scripts/diagnostic/amendments-probe-446.ts` (dotenv, `createClient`, inline `fetchJson` 429-backoff, read-only, tabulate). File: `scripts/diagnostic/nominations-source-probe-454.ts`. Needs `CONGRESS_API_KEY`.

**The two decision-relevant cuts, both specific to nominations:**

1. **Civilian vs military.** A single military PN bulk-nominates hundreds-to-thousands of officers (routine en-masse promotions, procedurally confirmed) — noise-by-count. The product ("WTF is going on in Congress") cares about **civilian** nominations: judges, cabinet/agency heads, ambassadors, US Attorneys, Fed governors, controversial nominees. If the corpus is dominated by military bulk with thin civilian signal, that reshapes or kills the pillar. Measure the split **two ways** — by PN count *and* by nominee count (a single military list PN can dwarf hundreds of civilian PNs on the nominee axis).

2. **The committee-referral join.** The one hook onto an existing spine (the committees pillar, `committees.system_code`). Nominations are referred to a committee (Judiciary → judges, Armed Services → DoD, Foreign Relations → ambassadors). If the referral carries a `systemCode` that resolves against tracked `committees`, nominations cross-link onto `/committees/[id]` and aren't fully standalone. If not, it's a standalone `/nominations` surface only. Report the resolution rate.

---

## Endpoint

- List: `GET {API_BASE}/nomination/{congress}?api_key=…&format=json&limit=250` → `{ nominations: [...], pagination: { count } }`. `API_BASE = https://api.congress.gov/v3`. Confirm it honors `fromDateTime` + `sort=updateDate asc` (for a future resumable frontier sync mirroring `sync:amendments`) — note whether those params work, since the sync design depends on it.
- Detail: `GET {API_BASE}/nomination/{congress}/{number}?…` → `{ nomination: {...} }` (and nominee/committee sub-resources may be separate calls — discover and report).

---

## What to measure + report

**A. Volume & list shape.** Total PN count for the 119th (`pagination.count`). Dump 2-3 raw list items + 2-3 raw details verbatim so the field inventory is on record. Report which fields live on the **list** vs require a **detail** fetch (committee, organization, nominees, latestAction) — this sizes the sync (list-only vs list→detail hydration, the amendments question).

**B. Civilian vs military split — the first crux.** Discover the distinguishing field (candidates: an `isList` boolean for bulk military lists, a `nominationType`, an `organization` naming a service branch, or a large `nominees` count) and report which one(s) actually separate them. Then:
- **PN-count split:** civilian PNs vs military PNs. If the distinguishing field is **list-level**, compute this corpus-wide from the full list (cheap — paginate the list). If it's **detail-only**, estimate from the detail sample and flag the caveat.
- **Nominee-count split:** total nominees civilian vs military (pull `nominees` length from the detail sample; project). State the magnet clearly — e.g. "N military list PNs carry ~M nominees, vs C civilian PNs."

**C. Join profile — the second crux.** Sample ~80 details, stratified civilian/military (or random + spread across organizations if the split isn't list-determinable):
- **Committee referral → `committees.system_code`:** does each nomination carry a committee referral with a `systemCode`? What % resolve against tracked `committees` (query the table)? This rate decides the `/committees/[id]` cross-link. Report civilian vs military separately (military lists may route differently).
- **Organization/agency:** the destination org (department/agency). Is it a clean structured field? Distinct-value cardinality? This is the natural facet for a standalone `/nominations` surface (nominations by agency), the analogue of LDA's issue-code lens.
- **Nominee identity:** confirm there is **no bioguide-style ID** on nominees (they aren't members → no member-spine join for the nominee). State it explicitly so the "weaker join" premise is grounded.
- **Confirmation vote (`recordedVotes`):** does a confirmed nomination's `latestAction`/actions carry a roll-call `recordedVotes` ({chamber, rollNumber, url})? Note presence — a clean nominee → Senate-vote link (the amendments `recordedVotes` analogue), a potential secondary join to `member_votes`. Secondary, not the decision.

**D. Disposition coverage — the amendments contrast.** Report the `latestAction` vocabulary (Received / Referred to Committee / Reported / Placed on Calendar / Confirmed / Returned to President / Withdrawn) **and its coverage %**. Amendments' top-level `latestAction` covered only 8.6% (the status-model NO-GO, oddities); nominations each have a clear procedural status, so coverage is likely high. If it is, note the contrast — a nomination status/disposition model would be viable where the amendments one wasn't (a real forward lever, not a promise).

---

## The decision this feeds (HO 455+, not this handoff)

- **GO, standalone + committee cross-link** — if civilian volume is meaningful (a few hundred+ civilian PNs with clean organization + high committee-referral resolution + good disposition coverage): a standalone `/nominations` surface (by agency, by disposition, by committee) plus a nominations section on `/committees/[id]`. Sync mirrors `sync:amendments` (resumable frontier, list→detail), likely **civilian-filtered or military-collapsed** so bulk lists don't drown the signal.
- **GO, reduced** — if the join is weak or the corpus is military-heavy: standalone `/nominations` only, civilian-filtered, no cross-link.
- **NO-GO** — if civilian signal is thin or the data is too sparse/bulk to be worth a pillar. (The probe made this call cheap for amendments' status model; make it cheap here too.)

The numbers decide; don't pre-commit the build or the schema.

---

## Explicitly NOT in 454

- **No writes, no table, no sync, no surface.** Read-only characterization only.
- **No schema proposal in code** — the field inventory + join rates go in the chat report; the schema lands with the build handoff (if GO), shaped by what the probe finds (the amendments 446→447 sequence).

---

## Git discipline

- Plan → diff → **wait for approval.** No auto-commit.
- **Explicit pathspec:** the one file, `scripts/diagnostic/nominations-source-probe-454.ts` (a reusable diagnostic, sibling to `amendments-probe-446.ts`). Commit on approval, then run and **report the full findings in chat** — volume, the two-axis civilian/military split, the join-profile table (committee-resolution rate, organization cardinality, nominee-ID absence, recordedVotes presence), disposition coverage %, and list-vs-detail field placement. Those numbers feed the GO/NO-GO and the schema.
- Commit message: `feat(nominations): source probe (HO 454)`
- Ancestry eyeball before push: one commit riding, clean fast-forward, nothing behind, nothing unrelated staged, the concurrent session's files (`RaceCard.tsx` / `CompetitiveRacesBlock.tsx` / `CompetitiveRacesStrip.tsx` / `globals.css`) untouched and history preserved.

---

read docs/handoffs/454-nominations-source-probe.md and follow it
