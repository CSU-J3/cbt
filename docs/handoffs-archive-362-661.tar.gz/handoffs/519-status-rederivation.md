# HO 519 — Status re-derivation audit (full sweep #2)

**READ-ONLY. No commits, no writes, no `migrate.ts`, no doc edits.** This is the deferred "next full audit," the HO 404 precedent (`404-full-audit.md`). HO 404 was dated **2026-07-02**; ~113 HOs have shipped since and the STATUS block still reads "As of HO 404." The theme bars are stale, and three whole pillars built since (LDA lobbying, amendments, nominations — each a top-level nav item) **aren't in the theme table at all**.

**Your job:** re-derive the state against live prod + repo, section by section, and hand back a findings report with a per-theme verdict. **The STATUS-block rewrite and any new theme bars are a SEPARATE follow-on (HO 520 doc sweep) — not this HO.** The rubric call ("do the three pillars get their own bars?") comes back to Corey + the architect from your evidence; you gather and *propose*, you don't decide it or write it into docs.

Deliverable is a **pasted findings report** (numbers + verdicts), structured by the sections below. No new script is required — reuse the existing diagnostics. If an ad-hoc consolidation script falls out naturally, propose it as a *separate* diff-approved commit AFTER the findings land; default is no commit.

Everything runs against **prod Turso** (the diagnostics read `TURSO_*` from `.env` via `dotenv/config`; run with `tsx scripts/diagnostic/<x>.ts`). Cold route timings are `curl` against the live deployment.

---

## §0 — Pin the live SHA

1. `npm run verify:deploy` — record the deployed SHA. (Ignore the known Windows `process.exit`→127 teardown false-failure; the confirmation line is what matters — backlog.)
2. `git rev-parse HEAD` and confirm the deployed SHA **== HEAD** (`5681322` at handoff write time). If they diverge, note it and audit against the SHA that's actually live.

**Report:** live SHA, HEAD, match y/n.

---

## §1 — Foundation structural health (plumbing re-verify)

The HO 404 Foundation verdict (held 96) rested on: sync fresh, `bills_fts` == corpus, every forced `INDEXED BY` present, cold-start audit 0 unexpected BAD, base routes 200. Re-verify all of it — **but the cold-start audit is now partially blind** (see 1c), so don't rubber-stamp it.

**a) Sync freshness + corpus counts.** Against prod:
- `MAX(update_date)` on `bills` (should be recent — flag if > ~2 days stale).
- Raw `bills` count, `bills_fts` count (must be equal — FTS fully populated).
- Canonical **tracked** count = `getCorpusStats(true)` = `(is_ceremonial=0 OR is_ceremonial IS NULL) AND summary IS NOT NULL` (was ~15,075 at 404; corpus has grown — record current).
- `summary IS NULL` count (the summarize-queue depth — was drained to single digits after HO 406; flag if it's re-grown into the hundreds+, which would mean the `*/10` drain regressed).

**b) `INDEXED BY` guard inventory.** The OR-lure cold-stall class (HO 405/407/479/480/481) is guarded by forced `INDEXED BY` hints across `lib/queries.ts` + `lib/enacted-this-week.ts`. `grep -rn "INDEXED BY" lib/` and sanity-check the count hasn't dropped vs what the closed loops imply (summarize-queue, the four `gatherLeadData` reads, the enacted helper, the news candidate-bills query, the topic-rail queries). Just confirm they're present — no EXPLAIN needed here, that's 1c.

**c) Cold-start plan audit — RUN IT, THEN MIND THE GAP.**
- Run `tsx scripts/diagnostic/cold-start-audit-332.ts`. Record BAD count (HO 404 got 0 unexpected of 50).
- **The gap:** that script's SQL inventory was frozen at HO 332 — it copies request-path SQL from `lib/queries.ts`/`lib/enacted-this-week.ts` *as of then*. It does **not** cover the queries added since: `getBillTopicRailCounts` (496), `getNewsTopicRailCounts` / `NEWS_ARTICLE_KEY_SQL` (515), `getNewsMemberRailCounts` (517), `getAmendmentsSummary` + the disposition scan (461), `getNominationsSummary` (456), `getBillLobbying` (440), `getFilingActivities` (486), the `getMemberNews`/`getRaceNews` observation reads, etc. So "0 BAD" from the script alone is **clean-on-what-it-knows, blind to the rest**.
- **Close the blind spot without rewriting the script:** grep `lib/queries.ts` for helpers added since HO 404 (roughly: the `*RailCounts` trio, `getBillLobbying`, `getFilingActivities`, `getAmendmentsSummary`/`getAmendments`, `getNominationsSummary`/`getNominations`/`getCommitteeNominations`, `getMemberAmendments`/`getBillAmendments`). For a **representative ~6–8** of the ones that read a large table (the rail counts over `bills`, the amendments disposition scan, the nominations GROUP BYs), pull the SQL and `EXPLAIN QUERY PLAN` it warm against prod. Confirm each either (i) rides its intended index / covering index, or (ii) carries the `INDEXED BY` hint it was built with (461 added `idx_amendments_acted`; 496/515 added the stage-absent hint). Flag any that show `MULTI-INDEX OR` / `USING TEMP B-TREE` / full `SCAN` on a fat table with no hint — that's a latent 500 the frozen audit would miss.

**d) Base-route cold sweep.** The public surface grew a lot since 404's "seven latency-watch routes." Cold-hit (first request after idle) each of the full nav + the redesigned pages, record HTTP status + wall time:
`/` · `/bills` · `/members` · `/members/{a real bioguide}` · `/bill/{a real id, e.g. 119-hr-1}` · `/lobbying` · `/amendments` · `/nominations` · `/news` · `/electoral` · `/hearings` · `/committee/{a real systemCode}` · `/race/{a real id}` · `/reports` · `/patterns` · `/trends` · `/stale` · `/president` · `/watchlist` · `/trades`.
Flag anything non-200 or over ~8s cold.

**Report:** the numbers above; a Foundation verdict — **hold 96 / propose move**, with the reason. Structural drift, the closed OR-lure cluster, CI (488/504), the hydration-class fix (490), and the browse-surface unification all landed since 404 and are Foundation-adjacent — say whether any of it moves the bar or is correctly "no bar move" (most was self-declared as such; your call is whether that still holds in aggregate).

---

## §2 — Cron fleet health (NEW section — the topology changed entirely post-404)

HO 404 logged two operational cron regressions (summarize backlog growing, weekly-report erroring) as backlog loops rather than docking Foundation. Both are fixed (406/407), plus the topology moved Hobby→Pro (433), markets/kalshi migrated GitHub→Vercel (475), and a watchdog + `/api/health` shipped (477). Confirm steady state; hunt any NEW regression.

**a)** `curl` the live **`/api/health`** — expect `200` / `healthy:true` / all **14** `CRON_ROUTES` fresh. If 503, record which route(s) tripped and why (no-row-in-window vs error/orphaned; note `timeout` counts as *alive* by design, HO 139/477; markets is judged on `market_ticks` freshness not the row, HO 477).

**b)** Re-run `tsx scripts/diagnostic/cron-runs-sync-verify-487.ts` (the split-at-fix-boundary read). Confirm the four fixed loops are holding in steady state:
- **summarize** (406): queue not re-grown (cross-check §1a), no doom-loop timeouts.
- **weekly-report** (407): most recent report row present + not errored; catch-up healthy (`payload.reportCatchup.ok`).
- **`/api/sync` trailing-step** (480/481): route p50 under the 55s soft cap; lead step not silently failing.
- **trades batch** (483): re-probe triggers **NOT** crossed — route breach ≥ 52s, or trades step p90 > ~13s (banked at 487). Record where the current numbers sit relative to those lines.

**c)** Reuse `tsx scripts/diagnostic/cron-health-135.ts` for the per-route freshness reads if `/api/health` flags anything ambiguous.

**Report:** `/api/health` verdict; the four-loop steady-state check; any route that's newly stale/erroring. Note the one known-open finding from HO 477 (the `/api/sync` step-overrun on ~6-of-7 ticks reads *alive*, is by-design soft-cap reaping, not a regression) — confirm it still reads that way and hasn't degraded into actual failure.

---

## §3 — Theme-by-theme re-derivation

For **each existing bar**, enumerate what shipped since HO 404 and give a verdict. HOs are listed so you're not hunting; cross-check against `docs/roadmap.md`'s "Also (…)" blocks 405→517. Every block since 404 self-declared "no theme-% change" — your job is to say whether that's still right *in aggregate* per theme, or whether an accumulation now warrants a move.

- **Foundation (96)** — covered by §1/§2. Plus: browse-surface `.mc-*` unification (486/496/515), `RecordTabs` detail shells (509/510), chip-family close (466/468), CI (488/504), hydration fix (490), the OR-lure cluster close (479–481).
- **Home (100)** — capped; confirm nothing regressed it.
- **Visualizations (97)** — shared SVG scaffold extraction (428-A, `components/svg/`); any new chart surface? Likely hold.
- **Weekly reports (98)** — believe unchanged since 404 (405–413 were cron/integrity). Confirm no reports-surface change landed.
- **News signal (CLOSED · "obs layer live; race/mbr joinable")** — this label is now badly under-selling it. The observation layer has grown from "joinable" to **multiple live consumers**: race→news hub (398), member→news hub (414), dashboard NEW badge (470), the whole `/news` route (501) + its `?member=` mode (512) + the topic rail (515) + the member rail (517). **Genuine question to surface:** does News signal now warrant a real numeric bar instead of "CLOSED"? Enumerate the consumers, propose — don't decide.
- **Member depth (99)** — member→news shipped (414), FEC by_size closed (415/416), member-hub sponsored-amendments (450), `/trades` index (389), `RecordTabs` member hub (509), Press-tab out-link (512). The one named hold to **100** is the **member-scorecard arc** (career vote participation + external scorecards), still unbuilt. Confirm 99 holds and the scorecard is still the only thing between 99 and 100.
- **Races (99)** — race→news hub (398), dashboard NEW badge lit (470), PAC-IE direction line (392/393). Confirm hold.
- **Committee activity / hearings (98)** — nominations committee cross-link (459) added a "Nominations referred" section to `/committee/[id]`. Does it move the bar or ride as within-theme? Note the standing **owed eyeball**: the ● LIVE hearings badge has never been exercised against a real live meeting — still owed.

**Report:** per-theme, **hold / propose move-to-N**, one-line reason each. Where you propose a move, say what shipped surface justifies it (the rubric bumps for shipped *theme surface*, not chrome/infra/bug-fixes — the standing "don't invent movement" line).

---

## §4 — The three uncounted pillars (the reason for this audit)

Each is a top-level nav item with live surfaces, entirely absent from the theme table. Re-run the existing coverage scripts for current numbers, enumerate the surfaces, and lay out the rubric fork.

**Coverage (re-run these):**
- `tsx scripts/diagnostic/lda-coverage-435.ts` — filings / activities / bill-links / registrants / clients; join rates.
- `tsx scripts/diagnostic/amendments-coverage-447.ts` — corpus count, SAMDT/HAMDT split, acted %.
- `tsx scripts/diagnostic/nominations-coverage-455.ts` — distinct PN count, civilian/military split, disposition mix, committee-hydration coverage.

**Surfaces shipped, per pillar** (enumerate from the roadmap blocks + a quick repo confirm):
- **LDA lobbying** — `/lobbying` nav item (issue-code bars + per-issue drill + TOP FIRMS + BY-CBT-TOPIC crosswalk + recent feed; members-style two-pane redesign 486/492/493) · `/bill/[id]` LOBBYING section (440) · data layer (435). HOs 435/437/440/442/444/463/486/492/493.
- **Amendments** — `/amendments` nav item aggregate (461) · `/bill/[id]` + `/members/[id]` sections (448/450) · data layer (447). HOs 446–452, 461.
- **Nominations** — `/nominations` nav item (456) · `/committee/[id]` cross-link (459) · data layer (455). HOs 454–459.

**The rubric fork (propose, don't decide):**
- **(a) three new bars** — Lobbying, Amendments, Nominations each get their own theme %.
- **(b) one combined bar** — e.g. "Influence & process" or "Downstream pillars" folding all three (they share the "extend downstream along the bill spine" scope decision and the `/patterns`-class aggregate-surface shape).
- **(c) fold into existing** — under Foundation (as shipped surface breadth) or split across existing themes.

State which you'd lean toward and **why**, against the framing question ("WTF is going on in Congress" — lobbying money, floor-fight amendments, and confirmation flow are all core sense-making cuts, which argues they're themes not chrome). But the mint-a-bar decision is Corey's + the architect's on your evidence.

**Report:** the coverage numbers, the surface enumeration, and your fork recommendation with reasoning.

---

## §5 — Standing loops re-confirm

- **OK-Senate P1** — HO 404 flagged `S-OK-2026`→Lankford live on prod (+ the `2031` impossible-year smell). Fixed at 411/412 (class-derivation + race-table reconcile). **Re-run `tsx scripts/diagnostic/senator-year-audit-410.ts`** and confirm it's fully green (§1=0 §2=0 §3=0 §4=0/0) — i.e. the fix held, no regression.
- **Env/config loops (Corey's, not blocking, confirm still open):** `NextAuth MissingSecret` on prod page loads; `FEC_API_KEY` not in Vercel Production (60/hr ceiling); the empty `FEC_API_KEY=` line. These are env fixes, not code — just confirm they're still open so the doc sweep records them accurately.
- **Corpus tracked count** — restate the canonical `getCorpusStats(true)` figure from §1a as the number the new STATUS block will cite.

**Report:** OK-Senate audit result (green y/n); env loops still-open y/n; the tracked count.

---

## Deliverable

Paste back a **section-by-section findings report** (§0–§5): the numbers, and for §3 a per-theme **hold/move verdict**, for §4 the **pillar-bar fork recommendation**. That report is what the architect adjudicates with Corey before writing the **HO 520 doc sweep** that rewrites the STATUS block.

**Do not touch any doc.** No `roadmap.md` / `backlog.md` / `oddities.md` / `SKILL.md` edits — those land in HO 520 after ratification. No commits unless you propose a consolidation script separately, diff shown first.

read docs/handoffs/519-status-rederivation.md and follow it
