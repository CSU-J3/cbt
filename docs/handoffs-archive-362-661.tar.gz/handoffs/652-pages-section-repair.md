# HO 652 — repair `### Pages`, the section holding a third of the phantoms

**Ground truth:** `main` at `4b3d766` (`docs(HO 651): file the phantom enumeration and the paired-drift finding`), `ls-remote` reads main only.

**Number:** roadmap pointer **646**, commit subjects run to **651**, so **652**.

**The unit is the SECTION, not the name.** Fifty name-level edits are fifty chances to write a plausible replacement clause; one section rewritten with all its phantoms in view is one decision. That choice is also why `~53` and `~67` ended up on two lines about the same set.

**Two commits, both docs, both on a review ref** — this edits SKILL and sits behind the self-mod guard:

| # | Kind | Contents |
|---|------|----------|
| 1 | `docs` | SKILL `### Pages` — the repairs |
| 2 | `docs` | backlog — a clause on what the entry's counts now mean |

---

## §1 — The section, measured

`### Pages` runs **1713–1757**, 45 lines, ~26 route bullets. Of the 20 citable phantom names, **35 mentions land here** — more than in any other section, and more than double the next.

**The route-existence axis is nearly clean, and knowing that up front stops you looking for the wrong thing.** Every route the section documents resolves to a real `app/**/page.tsx` — including `/primaries` and `/dashboard-v2`, which exist as redirect pages and which SKILL correctly describes as redirects. **One exception: `/dashboard-classic` is ABSENT.** Its bullet at L1715 describes a live preserved route and says it will be *"sunset in a later handoff (open loop)."* The sunset happened; the bullet did not notice.

So this is not a route problem. It is 26 route descriptions naming components that no longer render, and that is the whole shape of the work.

---

## §2 — Scope from the re-run, not from the filed list

**Step one is re-running `scripts/diagnostic/skill-phantoms-651.ts`** and filtering its PHANTOM mentions to lines 1713–1757. That set is the work list. The HO 651 entry's ruling stands and the reason is mechanical: 20 of the 50 names are citable, the other 30 include dictionary-word UI labels and symbols that lived inside another file, and hand-transcribing a list that long is how this class of contradiction gets made.

**Control on the re-run.** The citable names whose mentions fall in 1713–1757 must all appear in the filtered set. They were verified three ways at HO 651 — probe exclusion, git deletion record, and an independent tree check — so if the re-run's section slice is missing one of them, the filter is wrong and nothing downstream is readable. **Report that check before the work list.**

---

## §3 — The repair, and the rule that keeps it honest

For each phantom mention, the repair is one of three, and **which one is decided by reading the route's own `page.tsx`, never by inference**:

- **Delete the name.** Nothing replaced it; the description is simply carrying a corpse.
- **Name what actually renders.** Only when `app/<route>/page.tsx` shows the replacement. HO 650's treemap→`TopicDistributionList` was legitimate because the import sits at `app/page.tsx:216` and the component's own header documents the HO 627 swap — the claim was read out of the tree, not reconstructed from the names.
- **Restate as a record**, if the surrounding sentence is load-bearing history rather than a claim about the present.

**THE FAILURE MODE THIS HO IS MOST EXPOSED TO IS AN INVENTED CLAUSE.** A rewritten route paragraph that reads well and cites nothing is indistinguishable from a correct one, and SKILL is the doc that wins when implementation is in doubt — so a plausible wrong clause here propagates into future builds rather than sitting inert.

**Therefore: every clause you write or keep must carry a `file:line` you actually opened, and the report lists them per repair.** A repair whose grounding is "X was clearly replaced by Y" is not a repair. If the tree does not settle what replaced something, delete the name and say nothing about a successor — silence is correct where a guess is not.

**`/dashboard-classic`: delete the bullet.** SKILL describes what is. Its removal is history and belongs to the roadmap — so check whether the roadmap or backlog records that removal, and **if nothing does, say so in the report rather than fixing it here.** An open loop that closed with no record is the same defect in the other direction and it is not this HO's to take.

---

## §4 — Bound the edit

**Only touch bullets carrying a measured phantom.** Every other line in 1713–1757 stays byte-identical. The section is 45 lines; a diff approaching that size means the pass widened into rewriting-for-clarity, which is how unrelated claims get quietly restated.

**Do not fix the other sections.** `### Server / client split` holds the next-largest cluster and is 653 — it is a canonical list that has already drifted from itself, so it wants rebuilding from a measured set rather than name-by-name editing, and mixing it in here would put two different repair methods in one diff.

**Do not touch `app/globals.css:1563`.** It is the known vouching artifact, named in the HO 650 entry as part of that repair.

---

## §5 — Verification

**5.1** — Re-run the probe after the edit and report the `### Pages` PHANTOM count before and after. **Expected: the section's count goes to zero or to a stated residue with a named reason per survivor.** This is the probe measuring its own repair, and it is the closest thing this HO has to a real instrument.

**5.2** — `--numstat` on SKILL, stated before running. Additions and deletions both, since this is in-place editing rather than appending.

**5.3** — The grounding table from §3: one row per repair, with the `file:line` consulted and which of the three outcomes was taken.

**5.4** — No build or render check applies — this is docs-only and touches no code. **Say that explicitly rather than reporting a green typecheck as though it verified something**; a passing check that cannot fail on this change is not evidence.

---

## §6 — Commit 2: backlog

Add one clause to the HO 651 phantom entry. **Do not restate its counts** — they are correctly SHA-stamped at `0ee0570` and remain true of that commit. The clause says what a re-run now measures differently and that `### Pages` is discharged, so a later reader does not read 94 as current.

If §3 turned up phantoms the tree could not settle, they close as deletions and need no entry. If §3's `/dashboard-classic` check found no roadmap record of the removal, **that** is worth a line.

---

## §7 — Delivery

Both commits to `refs/heads/652-review`. Report the ref SHA, per-commit numstat, and the §5.3 grounding table. Main stays at `4b3d766` until the SKILL text is read.

Explicit pathspec staging, no `git add .`, ancestry eyeball, fast-forward only.
