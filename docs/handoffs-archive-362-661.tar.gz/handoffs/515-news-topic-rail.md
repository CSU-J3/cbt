# HO 515 — `/news` topic rail (Axis A)

Build. Probe verdict from HO 514 (`f7a3de4`) is GO, live-servable. HEAD going in is `f7a3de4`.

Fourth and final application of the `.mc-*` two-pane pattern: committees (`/members`, HO 328) → LDA issue codes (`/lobbying`, HO 486) → CBT topics on bills (`/bills`, HO 496) → CBT topics on news.

## What the probe settled, carried as constraints

- **Live-servable, hint mandatory.** `INDEXED BY idx_news_mentions_published` on the rail query, unconditionally — not just on the no-source path. Unhinted bare is **2231ms** cold (MULTI-INDEX OR off `idx_bills_is_ceremonial`, the HO 332/479–481 class); hinted is 29–64ms across every combination. When `source` is set the planner picks correctly on its own, but forcing the hint there costs nothing (31–33ms), so one always-hinted query beats a conditional. No new index.
- **Corpus is 726 rows / 439 distinct articles.** The SKILL's 227 figure is 3.2× stale — not order-of-magnitude, so the live call stands. That doc correction belongs in the sweep, not here.
- **`json_each` temp-btree residual is accepted** (the HO 461 Q6 precedent), immaterial at this size.

## Two calls, made — don't re-litigate in build

**1. Count distinct articles, not mentions.** The probe measured `COUNT(*)` and flagged the alternative as equal-cost. Take the alternative: `COUNT(DISTINCT COALESCE(m.article_url, m.article_title || '|' || m.source || '|' || m.published_at))` — the same `article_key` expression `getNewsFeed` already uses. Reason: the feed's own total is distinct-articles (HO 133), so a mentions-counting rail prints `HLTH 41`, you click it, and the feed says 28. That's the masthead incoherence HO 442 made structurally impossible by construction, and the same discipline applies. Extract the `article_key` expression to one module-level constant in `lib/queries.ts` so the rail and the feed can't drift.

**2. Single-select rail.** `/news` carries singular `?topic=`; `/bills` carries plural `?topics=` with OR semantics. So this rail is **not** a lift of `TopicRailRow` — that component's multi-select checkbox marker (`.bl-mark`) is the documented *divergence* from the pattern, not the pattern. This rail follows `/members` + `/lobbying`: single-scope, one active row, `.mc-crow.is-sel` amber left-border, click-again-to-clear. Write a new row component; don't widen `TopicRailRow` with a mode flag (that's the HO 486/496 riding-regression shape — it has two `/bills` consumers).

## The query

New sibling in `lib/queries.ts`, `getNewsTopicRailCounts(filters)`. **A new function, not an extension of `getNewsFeed`** — same reasoning as HO 496's `getBillTopicRailCounts` vs `getTopicDistribution`.

- Rebases on the bounded dims: `source`, `windowHours`, `signal`.
- **Self-excluding** — never applies the `topic` clause, or selecting a topic collapses the rail to one row (HO 496's rule).
- Bill-scoped (`?bill=`) is out of scope: that mode is a single bill's mention history, so a topic rail over it is one row. In bill mode the rail doesn't render (see below).
- `unstable_cache`, tag `news-breaking` (the tag the news cron already flushes — no new cache wiring, no `/api/revalidate` allowlist entry).
- `try/catch → null` so a bad read hides the rail rather than 500-ing the page.
- Returns all 24 topics zero-padded, sorted VOL-desc; zeros sink to the bottom and render dimmed (the `/lobbying` + `/bills` rail convention).

## The chrome

`app/news/page.tsx` gets the two-pane structure. CSS **additive under a `.nw-*` prefix** so shared `.mc-*` rules are untouched and `/members` / `/lobbying` / `/bills` stay byte-identical — verify that explicitly, it's the containment rule that has held through 486 / 492 / 496 / 507.

- **Left:** `.mc-rail nw-rail`, header `TOPICS · 24` + CLEAR, one row per topic (label, topic-colored bar, distinct-article count).
- **Right:** `.mc-content` — the existing `NewsFilters` chips (minus topics, below), the `news-header-row` chrome, the `NewsRow` list, the pager. Rows unchanged (the rows-out-of-scope convention).
- **Bound the rail** at ~520px with internal scroll and `scrollIntoView({ block: "nearest" })` on the selected row — HO 492 shipped exactly this and then had to fix the selection-invisibility regression it introduced. Build it with the fix already in.

**Remove the 24-topic chip row from `NewsFilters`** — it's the rail now (HO 496 precedent). Keep source / window / signal chips and the bill pill. Grep-confirm `NewsFilters` is still single-consumer before editing (HO 500 confirmed it was; re-check, don't assume).

## Mode interactions — the part that's easy to get wrong

`/news` now has three modes. State each explicitly in code comments:

- **Default (mention feed):** rail renders, topic selection scopes the feed.
- **Bill-scoped (`?bill=`):** rail does **not** render. One bill's history is a single-topic slice; a rail over it is noise.
- **Member-scoped (`?member=`, HO 512):** rail does **not** render. The pane is the observation feed, a different table — topic doesn't apply to it. **HO 512's member mode must come out byte-identical.**

That last one is a deliberate seam, not an oversight. The intended Axis B ("IN THE NEWS" member group as a *second group in this same rail*) will reopen it, because in member mode the rail becomes the selection state. Note it in the comment so the next session doesn't read the hidden rail as a bug. Axis B is **not** in this HO, and B carries its own window semantics (the probe found the 24h head collapses to 6 members, so the member group can't rebase on `?window=`) — do not build toward that here beyond keeping the rail container able to hold more than one group.

## Verify

- `npm run typecheck` + build; CI green (HO 488).
- Prod: bare `/news` rail renders VOL-desc with counts; selecting a topic scopes the feed and **the rail count matches the feed total exactly** (the whole point of call 1 — check one non-trivial topic); the rail rebases on source/window/signal but the selected topic never collapses it; CLEAR returns to bare; `?bill=` and `?member=` render byte-identical to today.
- `/members`, `/lobbying`, `/bills` visually unchanged.

## Process

Diff shown before commit, explicit pathspec staging, ancestry eyeball, FF push. Two commits if the query layer and the chrome are cleaner apart (the HO 496 `e84f7c5` / `d789c20` split is the precedent). Docs are HO 516 — and that sweep owes the `news_mentions` 227 → 726 correction in SKILL alongside the usual roadmap block, backlog line, and the `/news` entry rewrite.
