# HO 647 — the band caches a card bundle to print six strings

**Ground truth:** `main` at `2803099` (`docs(HO 646): SKILL — the absence band is cards with two tiers`). The roadmap's last pointer reads **"Also notes now run through HO 646"**, so this is **647**.

Authorised by the HO 646 backlog entry (`3684f40`) — the amended absence-band payload line, which already carries the by-id measurement this build acts on. **Two commits, in this order:**

| # | Kind | Contents |
|---|------|----------|
| 1 | `perf` | the projection at the assembly site, the narrowed type, the caps-file comment correction |
| 2 | `docs` | backlog strike + DONE tombstone |

Commit 2 is named here as its own commit rather than left as a condition of shipping commit 1 — that is HO 646's recorded instruction defect (`8852478` carried a backlog re-price alongside code because HO 645 §4 mandated it as a shipping gate). **Do not roll the roadmap into this.** A single build does not open a block; it rides the next sweep.

---

## §1 — The measurement is already in hand. Do not re-derive it.

HO 645's probe measured the cached `getAbsenceWatch` blob at **29.5 KB**, and HO 646 filed its by-key breakdown:

- `recentBills` — **23,098 B / 78.2%**
- `committees` — **5,127 B / 17.4%**
- `topics` — 224 B, `affiliations` — 182 B, **serialized for no consumer at all**

Against that, `AbsenceCardBack` reads exactly six things out of `card`:

- `committees[].name`, and `committees.length` for the `+N` closer
- the first three `recentBills`' `bill_type` and `bill_number`
- `stats.total`

`recentBills` is a `FeedBill[]`. `FeedBill` carries `title` and `summary`. Ten of them are cached and serialized so that three bill numbers can be joined with a `·`. That is the whole finding, and it was already measured — **do not open a probe.**

---

## §2 — The change

**2a. A narrow payload type**, in `lib/queries.ts` beside `AbsentMember`:

```ts
// HO 647 — what AbsenceCardBack actually reads, and nothing else. The band used
// to cache the whole MemberCardExpansion (a FeedBill[] with title+summary on every
// row) to print three bill numbers and a committee list. The shape is the contract:
// if the back ever needs another field, it is added here deliberately rather than
// found already sitting in the blob.
export type AbsenceCardPayload = {
  stats: { total: number };
  recentBills: { bill_type: string; bill_number: number }[];
  committees: { name: string }[];
};
```

Retype `AbsentMember.card` to `AbsenceCardPayload | null`.

**2b. A shared cap.** Add beside `ABSENCE_WALK_BOUND` (~L4879):

```ts
export const ABSENCE_BACK_BILLS_CAP = 3; // what the 330px back prints; the assembly slices to it
```

`AbsenceCardBack` is a server component and already imports from `@/lib/queries`, so this needs no leaf module — the constraint that produced `lib/member-card-caps.ts` was `SponsorExpandedPanel`'s `"use client"`, and it does not apply here. Import it in `AbsenceCardBack` and delete the local `BILL_CAP`. **`CMTE_CAP` stays local and is not exported** — see §3.

**2c. Project at the assembly site** (`lib/queries.ts` ~L5128), replacing the current spread-and-slice:

```ts
m.card = {
  stats: { total: expansion.stats.total },
  recentBills: expansion.recentBills
    .slice(0, ABSENCE_BACK_BILLS_CAP)
    .map((b) => ({ bill_type: b.bill_type, bill_number: b.bill_number })),
  committees: expansion.committees.map((c) => ({ name: c.name })),
};
```

Rewrite the HO 631 comment block above it rather than editing around it. The current one explains a slice to `COMPACT_BILLS_CAP` that no longer happens, and a leftover explanation of a superseded mechanism reads as a current one.

**2d. Drop the now-unused `COMPACT_BILLS_CAP` import** at `lib/queries.ts:7`. The constant itself stays — `SponsorExpandedPanel` is still its consumer for `/members`.

**2e. Correct `lib/member-card-caps.ts`.** Its comment asserts that `getAbsenceWatch` slices `recentBills` before caching and that *"the assembly-site slice and the render cap must be the SAME number."* **Both clauses become false the moment 2c lands.** Rewrite the file header so it describes only `SponsorExpandedPanel`'s use, and say the band no longer reads it. This is a comment on code being changed, so it belongs in commit 1 — and shipping a false claim in the file that exists to hold the claim is the class this repo keeps filing.

**Keep `AbsenceCardBack`'s own `.slice(0, ...)` on both lists.** It is now redundant against a fresh payload and load-bearing against a stale one — see §4.

The judgment call, stated so nobody later cites a byte figure for it: narrowing `stats` to `{ total }` saves roughly seventy bytes and is taken for **shape honesty, not bytes**. Six unread numbers in a payload re-open this same question in six months.

---

## §3 — What must not move

**Committees are not sliced.** `cmteMore = cmtes.length - CMTE_CAP` counts off the **full** array, so a slice at the assembly site makes the `+N` under-report silently. Project the rows to `{ name }`; keep every row. This asymmetry against `recentBills` is deliberate and is the reason `CMTE_CAP` stays local to the component.

`billMore` is safe under the slice because it counts off `stats.total`, and `Math.min(BILL_CAP, bills.length)` is unchanged for any member with fewer than three sponsored bills. Confirm this by reading the expression, not by assuming it.

**`getMemberCardExpansion` is untouched. `SponsorExpandedPanel` is untouched. `app/members/page.tsx` is untouched.** `/members` is the other consumer and reads the full bundle — HO 507's rule, restated at HO 631 and again at 645. The projection is consumer-side, at the band's assembly site, inside `queryAbsenceWatch`.

The `card === null` catch is not opened. It is an open WATCH from HO 646 (its *cause* is unfired) and widening scope to it here would make neither attributable.

---

## §4 — The instrument, and the trap that makes it lie

Use the committed probe, **`scripts/diagnostic/absence-payload-645.ts`** — its M4 already reads the real cached blob and prints the by-key table with `*` on consumed keys. Do not write a new one. HO 646 filed *a lesson encoded in one instrument is not inherited by the next*; re-running the same instrument is how that gets avoided rather than re-learned.

**The trap is in the probe's own header and it will fire on this change.** `getAbsenceWatch`'s cache key is the literal `["getAbsenceWatch"]` — it does not include the payload shape. So after 2c lands, `.next/cache/fetch-cache` still holds the **fat** blob and M4 will report it as if current. HO 645 hit exactly this after the S=40 falsification. Delete the entry and re-request `/` before the post-measurement, and say in the report that you did.

Two consequences worth stating rather than rediscovering:

The old cached value is a **superset** of the new type, so a stale hit during the convergence window renders correctly — the back finds `committees`, `recentBills` and `stats.total` where it expects them and ignores the rest. This is why `AbsenceCardBack` keeps its own slices: across that window it will be handed ten fat bills and must still print three.

On prod the same key-stability means the blob does not shrink at deploy. It shrinks when the entry regenerates — the hourly `revalidate` or a `votes` tag flush. **Do not report a prod byte figure until it converges and holds** (`/api/version` first to confirm the deploy is live).

---

## §5 — Ruling criteria, fixed before the numbers exist

**PASS** requires all three:

1. M4's by-key table lists **no `topics`, no `affiliations`, no `key`** — the keys are gone from the object, not merely small.
2. `recentBills` falls to **≤ 5%** of its 23,098 B pre-value.
3. The rendered back is **byte-identical** for every band member, §6.1.

**FAIL** on any rendered-back byte differing, or on either unread key still present.

**What the instrument reads if the work never happened:** the by-key table still lists five keys with `recentBills` near 78%. That is a different reading from success, which is what makes it an instrument (the standing rule, confirmed twice in the 644–646 arc).

---

## §6 — Verification

**6.1 — the discriminating check, and it is a string diff, not an eyeball.** Before the edit, capture the served HTML of every open card back on `/` — the `.abw-bk-*` subtree per member, including both `+N` closers. After, capture again and diff. Empty diff or it did not pass. A rendered back that *looks* right is exactly what a broken `cmteMore` produces.

**6.2** — M4 before and after, with the cache entry deleted between. Report the by-key table both times and the blob total both times. **By id, not by total** — a total can coincide (HO 631).

**6.3** — `npm run typecheck`. The retype at 2a is what surfaces any reader of `card` outside `AbsenceCardBack`; a clean pass is the evidence that there is none.

**6.4** — Report the live band population at the time of measurement (MIA / at-risk). The bytes are per-member, so a figure without its population is not comparable to HO 645's.

**6.5** — If the band is empty when you measure, say so and stop rather than reporting a 0-byte blob as a win. An empty band is the good-news state and measures nothing.

---

## §7 — Commit 2: backlog

Strike the absence-band payload entry in place with a SHIPPED pointer, matching the house strike form, and append a DONE tombstone carrying the before/after by-key figures and the population they were read at.

**Do not close the three HO 646 lines.** The unfired `card === null` cause, the 119TH denominator, and the `SponsorPhoto` fallback residue are all untouched by this build.

**One new line, if and only if 6.2 shows it:** the `getAbsenceWatch` cache key does not include the payload shape, so a shape change is invisible to the cache and the old value serves until it regenerates. If that is not already an oddity, it is one — and it is the second time this entry's own probe has had to warn about it.

---

Report the diff before pushing anything. Explicit pathspec staging, no `git add .`, ancestry eyeball before the push, fast-forward on `main`.
