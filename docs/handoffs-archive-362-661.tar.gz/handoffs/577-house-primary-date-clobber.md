# HO 577 — The SC House primary dates: an unguarded write path next to a guarded one

Confirm the number: the roadmap's pointer runs through **HO 574**; HO 575 was its sweep, HO 576 shipped `ce936c5` + `e3cf396`. So this is **577**. HO 578 will sweep 576 and 577 together (the multi-arc pattern from 566–568).

**Probe first, hard HALT, then a repair.** This one writes data, so nothing is written until STEP 0 is reviewed.

## There is a deadline on this

The wrong rows carry **2026-08-11**, which is 12 days out. While that date is in the future the rows are still OPEN and repairable. Once it passes they become past-dated, and if they pick up recorded shares they will read as **settled** to the very guard this HO is likely to add — at which point the guard freezes the error in place and the escape hatch becomes `scripts/reingest-primary-slate.ts`. **Repair before Aug 11.** Say so in the ship report if that looks at risk.

## The hypothesis, stated so it can be killed

`lib/primaries-sync.ts:697` carries the HO 560 settled-row clobber guard, and its comment names this exact mechanism unprompted: *"Ballotpedia rebuilds a seat's page around a LATER contest (e.g. the SC Aug special), so an unconditional delete-rebuild would overwrite a past election's stored results with a different contest's field."*

That guard sits in the **Senate candidate path only**. The House district write at `:1062-1070` does a plain `ON CONFLICT(id) DO UPDATE SET primary_date = excluded.primary_date` with **no `isSettled` call**, and its date comes from `calByState.get(d.state)` (`:1060`, built at `:913-922`).

So the reading to test is: **the same input hit both paths, and only one had a guard.** SC's Senate rows survived at June 9 because they were past-dated with recorded shares and the guard skipped them; the House rows had no such protection and took the Aug 11 write. Same cause, different outcome, explained entirely by which path calls `isSettled`.

If that's right, two consequences follow and both matter more than the SC rows themselves:

1. **A repair alone evaporates.** The primaries cron runs daily. Fix the rows without fixing the path and the next tick rewrites them.
2. **The exposure is not SC-specific.** The guard's absence is generic, so any state whose Ballotpedia page gets rebuilt around a later contest has the same hole. Measure repo-wide before assuming this is one state's problem.

---

## STEP 0 — read-only diagnostic, own commit, then HALT

Create `scripts/diagnostic/house-primary-date-clobber-577.ts`. Read-only, with the same runtime WRITE-regex guard the HO 576 diagnostic used.

- **M1 — the blast radius, repo-wide.** For every state, compare each `house-{ST}-{DD}-2026-{party}` row's `primary_date` against that state's regular statewide `senate-{ST}-2026-{D|R|open}` date. List every disagreement with state, district, party, house date, statewide date. **Do not filter to SC.** If SC is the only hit, that's a finding; if it isn't, the HO is bigger than it looks.
- **M2 — what the source holds now.** Print the `calByState` backing rows for SC (and every M1 state): what date would the next sync write? This decides whether a repair sticks or gets undone tomorrow.
- **M3 — the guard asymmetry, confirmed in code.** Show that the Senate path calls `isSettled` and the House path does not. One grep, but state it explicitly so the sweep can record it as verified rather than asserted.
- **M4 — kill or confirm the hypothesis.** Are SC's `senate-SC-2026-R/-D` rows actually settled by `isSettled`'s own predicate (past-dated **and** carrying at least one recorded share)? If they are, the survival is explained. If they aren't, the hypothesis is wrong and something else wrote them.
- **M5 — live impact.** How many rows does `/primaries` currently show as upcoming that shouldn't be? `getUpcomingPrimaries` filters `election_round = 'primary'` and date >= today, so the bad rows are rendering right now. Give the count and confirm whether the correct (past) contests have therefore disappeared from the past view as well. Also confirm what does **not** read these rows: the member hub reads statewide only after HO 576, so it should be unaffected — verify rather than assume.
- **M6 — recoverability.** What is the correct SC House primary date, and where does that come from? Is it derivable from stored data (prior rows, `primary_candidates` shares, results) or does it need a re-fetch? This determines whether the repair is an UPDATE or an ingestion.

Note: `primary_type = 'open'` on the SC House rows is **correct and not part of this bug** — South Carolina genuinely runs open primaries with no party registration. Don't repair it.

Commit: `chore(diagnostic): HO 577 STEP 0 — house primary date clobber scope + guard asymmetry`

### HALT

Report M1–M6 and stop. The repair writes data, and its shape depends on M2 and M6.

---

## After approval — the build (do not start it now)

Recorded to aim the probe, not as authorisation. Expect roughly:

- **The path fix first.** Add the settled-row guard to the House district write so the repair can't be undone. Reuse `isSettled` rather than writing a second predicate — a shared guard that only protects the paths importing it is the recurring shape here, and this is the second instance.
- **Then the repair**, scoped to exactly what M1 found, as its own commit with its own revert boundary. If M6 says the correct dates need a re-fetch, that's an ingestion, not an UPDATE, and it may want `scripts/reingest-primary-slate.ts` (the documented post-settle escape hatch) rather than new code.
- **Falsification is owed on the new guard.** The House path's guard will be untriggered the moment it lands, and an untriggered guard emits the same green as one that can't fire. Hand-apply the clobber on current HEAD, scratch only, confirm the guard blocks it, revert, `git status` clean, commit nothing from it. If it can't be demonstrated locally, it goes in the sweep as UNPROVEN in a WATCH, not as protection.

## Scope guards

1. STEP 0 is read-only and lands as its own commit. No writes of any kind.
2. No schema change, no migration.
3. Don't repair `primary_type`. It's correct.
4. Don't touch `getPrimaryForRace` — HO 576 shipped and its delta is verified. This bug doesn't reach it.
5. Don't touch the Senate path's guard. It worked.
6. No docs, no `SKILL.md` — HO 578 sweeps 576 and 577 together.
7. Explicit pathspec staging. Never `git add .`.

## Verification (STEP 0 only)

- `npm run typecheck` clean.
- Runs to completion against prod Turso and prints M1–M6.
- Provably read-only — no `INSERT`/`UPDATE`/`DELETE`/`CREATE`/`DROP`/`ALTER`/`REPLACE` in the file. State that you checked.

## Ship report

- M1 in full, as a list rather than a count. Whether SC is alone is the headline.
- M2: what the next sync tick would write, per affected state.
- M4: hypothesis confirmed or killed, with the `isSettled` predicate result for the SC senate rows.
- M5: the live wrong-row count on `/primaries`, and confirmation the member hub is unaffected.
- M6: whether the repair is an UPDATE or an ingestion.
- Your read on whether the Aug 11 deadline is at risk.
- Anything else found — file it, don't fix it.
