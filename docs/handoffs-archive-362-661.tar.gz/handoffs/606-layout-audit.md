# HO 606 — the layout audit. Build, falsify, run, HALT.

HEAD `bbe062b`. Roadmap pointer: *"Also notes now run through HO 604."* 605 is closed on main. **Next free is 606** — matching what the arc doc and backlog:130 already name, so for once the number needs no correction.

**The spec is in-repo and this handoff does not restate it.** Read, in order:

1. `docs/design/layout-conventions-arc.md` **§3** — the full audit spec: file name (`scripts/diagnostic/layout-audit-606.ts`), target (`next start`, never dev, never prod), route list (31 + the 6-route narrow subset), burn bounds, M1–M6 as corrected, output shape, GO condition. **§3 is the deliverable's contract.** §4 is the gate-writing rule you'll be held to.
2. `docs/backlog.md` — the layout-audit entry (search `layout-audit-606`): the survive-independently findings and the two instrument traps.
3. `docs/handoffs/604-artifacts/walk.mjs` + the four baseline JSONs — local-only, repo-ignored. If they're not on disk, say so and build cold; do not assume git has them.

What follows is only what §3 doesn't already say.

---

## 1. The skeleton lift — what transfers and what must not

`walk.mjs` transfers its **plumbing**: browser launch via `@playwright/test`'s `chromium`, the `ct_seen` cookie set context-wide, the seed list, the double-hit-per-route rhythm, the viewport loop, and the per-element crawl. Lift that shape.

Two things in it must **not** transfer:

- **The signature scheme.** walk.mjs keys elements on the ancestor class chain — which includes `text-[length:var(--fs-N)]` classes. Fine for a type instrument; wrong for this one, where the key is a **grouping** predicate (M1a's "same tag + class signature" for siblings), not an identity across builds. Derive the sibling signature from tag + *sorted* class list, and treat the keyed-diff oddity as the standing warning: this audit will be re-run after P3–P6 remediation, and remediation renames classes. **A cross-run comparison keyed on class names goes blind exactly where the fix landed.** So the per-route counts are the cross-run currency, and `selectorPath` is a human pointer, not a join key.
- **The measurement function.** Nothing in walk.mjs's computed-style logic survives; M1–M4 are geometry, not style.

One consequence of the lift worth stating: walk.mjs was a scratch `.mjs`; the deliverable is a typed `.ts` under `scripts/diagnostic/` run via `tsx`, house header per `absence-watch-588.ts`, README entry included.

## 2. The falsification leg — before the full run, not after

§3's GO condition says prove M1 fires on `/` before trusting any zero. Make that a **structured first leg**, printed before the crawl proper:

- Run M1 against `/` at 2560 only. It must name, by recognizable selector path, at least: the **breaking-headline rows** (timestamp far right), the **masthead** (M1b — this is the singleton mode's existence proof; if M1b returns nothing on `/`, M1b is broken, whatever M1a says), and if the miss-strip is live, its badge gap.
- Run M2 against `/`: the stage-funnel/distribution panel region is the known C7 offender. If M2 reads zero on `/`, print the panel predicate's intermediate values (border-width, backgrounds compared) for the funnel's container so the miss is diagnosable, and stop.
- **M4's seed-vocabulary check inverts by calendar.** Congress's August recess makes the hearings grid the known M4 offender *if empty columns render* — but the week may legitimately have zero scheduled days, in which case M4 finding nothing on `/` is plausible, not proof of breakage. Falsify M4 instead on whichever crawled route the candidate-emitter (≤12 chars, ≥40px) surfaces first; the emitter existing is the check.
- Print `FALSIFICATION: PASS` with the found selectors, or halt with the diagnostics. **No full crawl on a failed falsification leg** — 80 page loads of Turso reads against a broken instrument is spend with no information.

## 3. Two ambiguities §3 leaves open — resolved here so they aren't resolved ad hoc

**Gap denominator.** "Interior gap" between vertically-banded children: measure between **rendered right edge of child N and rendered left edge of child N+1**, using the union of each child's client rects (a wrapped inline has several). Flex `gap`/margins are part of the measured space — a 10px `gap` is invisible noise under the 120px threshold, which is the threshold's job. Don't subtract styled gaps; that's modeling, not measuring.

**M3's "non-default color."** Own-vs-parent computed comparison as specced, with one addition: compare **resolved rgb values**, not authored tokens — `var(--text-dim)` and `#6b7280` must not read as two colors. And exclude elements whose only difference is `color` matching one of the two link/hover conventions on `:hover` — the crawl never hovers, so computed hover styles shouldn't appear, but a `:focus-visible` default can; skip focus-only deltas.

## 4. Run mechanics

- **Two commits.** Commit 1: the script + README line, **before the full run** — the instrument's identity is fixed before its numbers exist (`diag(layout): HO 606 — cross-route layout audit (M1–M5)`). Commit 2 does not exist: **output is pasted, never committed.** Baselines the audit emits (per-route JSON, if you write any) go under `docs/handoffs/606-artifacts/` — repo-ignored, per the parity rule now in SKILL.
- Typecheck, ancestry eyeball (exactly one commit), fast-forward, then run.
- Burn: print the ledger §3 requires — route count, total page loads, and wall time. If any route 500s or hangs past a 30s cap, record it in the can't-measure list and continue; **do not retry-loop a failing route** (each retry is another Turso read).
- The absence-watch rows, if any render on `/`, are noted and skipped per the arc's standing carve.

## 5. Output and HALT

Paste full stdout, then §3's four artifacts: the per-route defect table (M1a+M1b descending), M1/M4 site totals, the M5 narrow baseline, the can't-measure list. Add one line §3 doesn't ask for: **which three routes top the table** — that trio is the proposed P4 opening, and naming it makes the table a plan instead of a report.

Then HALT. No remediation, no P3 code, no doc sweep — the sweep is its own HO after the numbers are read.
