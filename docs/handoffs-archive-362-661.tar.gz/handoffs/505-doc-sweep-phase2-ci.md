# HO 505 — doc sweep: the Phase 2 CI arc (503 probe → 504 build)

Docs only. Two commits, in this order: (1) `roadmap` + `backlog` + `oddities`, (2) `SKILL.md` **alone** under the self-mod guard, diff shown and re-approved before it commits. Nothing else rides either one.

HEAD is `482cd55`. Roadmap "Also" notes run through HO 502; this bumps them to 504.

## Frame it right, because this one closes backwards

Most sweeps record a thing that got built. This one records a **loop that closed by replacing its own close criterion**. The backlog has read, since Jun 30, "the e2e job runs green in CI with a real DB and the interaction hardenings in place." There is no real DB, there will not be one, and that is the correct outcome. If the tombstone doesn't say so in those words, a future session reads a closed loop, goes looking for the fixture, finds no fixture, and re-opens the whole question from the top.

The reason has to travel with it: **the specs guard with `test.skip`-on-empty, so an under-seeded fixture doesn't fail — it passes.** That inverts the entire premise the fixture was being built on. HO 503 was sent to cost a build and came back arguing against it, which is a probe working, and the record should read that way rather than as a build that fizzled.

## Commit 1 — roadmap + backlog + oddities

### `docs/roadmap.md`

Append-only. New **"Also (HO 503–504)"** block, bump the running pointer to 504. Do not retro-edit the HO 502 block or any prior dated block — HO 418 is the standing precedent.

Content:

- **HO 503, the probe — verdict: don't build the fixture.** Sent to cost a seeded local libSQL fixture for Playwright-in-CI (the path the backlog had preferred since HO 491, on the sound reasoning that libSQL is SQLite so a fixture removes the secrets question rather than managing it). Two results are worth recording even though the verdict made them moot: `file:` works through `getDb()` **with zero `lib/db.ts` change** (the local sqlite path ignores the injected `boundedFetch` and the undefined `authToken`, so HO 238's HTTP timeout/retry semantics are provably untouched), and `migrate.ts` runs clean against `file:` (52 tables, FTS5 populated). Bucket count across both specs, 73 tests: **A 41 · B 28 · C 2 · D 2 · E 0** — 95% nominally fixture-servable. **The verdict turned on none of that.** It turned on the guard inversion (below). No commit; the probe scripts were throwaway.
- **HO 504, the build — two commits, `fc42872` (spec hardening) + `482cd55` (workflow).** `.github/workflows/e2e-prod.yml`: `deployment_status` (gated `state=success` + `environment=Production`) + daily `0 15 * * *` + `workflow_dispatch`, running `e2e/smoke.spec.ts --grep-invert "@nonci" --retries=2`, `timeout-minutes: 20`, report artifact on failure, global concurrency with cancel-in-progress. Deliberately a **separate workflow file, not a job in `ci.yml`** — it never runs on the PR path, so it can't become a required check that fails to report under the `paths-ignore` / branch-protection landmine `ci.yml` documents. Spec hardening: `isKnownNoise` extracted to `e2e/console-noise.ts` (single-source, both specs import it), the race-drawer test retargeted to `/electoral` and its skip-guard converted to a hard assertion, the bill-row selector re-anchored on the `role=button` + `aria-expanded` toggle contract, and the markets-hover case tagged `@nonci`.
- **Step 0 finding:** Vercel emits GitHub `deployment_status(state=success, env=Production)` to this repo — verified live, not assumed — so post-deploy coverage is real rather than aspirational. The event's `target_url` is the **protected per-deploy alias**, so the crawl runs against the stable prod domain instead; the ~2min of checkout + `npm ci` + browser install is what makes that safe against the alias-swap race, and the workflow comment says so as a constraint on future edits.
- **Trigger coverage, stated honestly:** `deployment_status` PROVEN (run `30040913867`, job ran-not-skipped, green 2m39s), `workflow_dispatch` PROVEN (run `30041280979`, exercises the `if:` fall-through branch that `schedule` shares), **`schedule` UNPROVEN until its first fire** — it can't be forced. Don't write this up as full coverage.
- **Two hardenings resolved, one retired.** #3 (bill-presence selector) shipped, but the backlog's description of it was **wrong on both counts** — it claimed an `<a href>` selector broken by `<li role=button>` rows; the actual code was a `.v2f-row` class selector against a `<div role="button">`. #2 (console allowlist) shipped as the shared extraction. **#1 is retired as moot, not done:** "freeze the marquee so the hover lands on a stable item" was specified before BotID was understood — prod withholds the tape from headless Chrome entirely, so there is nothing to hover and freezing a non-rendering animation fixes nothing.
- **No theme-% change.** Test infrastructure, no user-facing surface — the HO 379 / 382–386 precedent (that block's rubric line: bumps for shipped theme surface, not bug-fixes or harnesses). Foundation holds at 96.
- **Also notes now run through HO 504.**

### `docs/backlog.md`

**The tombstone.** Strike the **Playwright smoke-crawler CI wiring** OPEN LOOP, opened Jun 30, carried through five HOs. Say plainly:

- Closed by **explicit tombstone with a replaced criterion**, not by meeting the original one. The convention allows this ("an item leaves OPEN LOOPS only by meeting its close-criterion or being explicitly tombstoned") — use the second door and name it.
- Original criterion: e2e green in CI against a real DB with the hardenings. **Replaced with:** an unattended prod crawl on `deployment_status` + schedule, no fixture, no secrets, off the per-commit path.
- Why: the HO 503 false-green mechanism, plus the observation that pre-merge protection buys minutes in a single-committer workflow that already diff-gates and prod-verifies every change, at the cost of a hundreds-of-row artifact maintained forever against a 132-statement schema.
- Record the **fallback that was considered and not taken**, so it isn't re-litigated: a few-dozen-row fixture backing only the (A) route crawl tagged `@ci`, never the guarded interaction tests. Available if pre-merge #418 protection is ever explicitly wanted.
- The probe's one open question — whether every (A) route 200s on a migrated-but-empty DB or 500s on a `rows[0]` access — is **moot under this verdict.** Record it as moot, not as a dangling measurement someone should go take.

**New items:**

- **OPEN LOOP — `schedule` trigger unproven.** Dated, *Owner:* Code. *Close:* confirm the first `0 15 * * *` run fires and the `smoke` job runs green. Job logic is identical to the proven dispatch path; the only unknown is whether the cron fires. Tombstone on the first successful daily run.
- **FIT & FINISH, P3 — PRESIDENT stage-click fixed-wait race.** The test's settle is a fixed `waitForTimeout` before asserting `page.url()` contains `stage=president`; if the client-side rebase hasn't landed inside that window the assertion fails. Observed once on the pre-push crawl, recovered on retry #1, and **`retries: 2` now masks it by design** — which is the tradeoff we chose knowingly for an unattended run, and also the reason this can't sit in WATCH (nothing behind a retry ever gets revisited). Fix named: replace the fixed wait with `await page.waitForURL(/[?&]stage=president/, { timeout: 8_000 }).catch(() => {});`, keeping the `toContain` as the real failure surface — the predicate-wait pattern both specs already use elsewhere. **Verify the line numbers and paste the current hunk before filing** — the visible grep in the 504 report showed `141-142` / `waitForTimeout(2_500)` while the write-up cited `289-290` / `1_500`. Both sites probably exist (a crawl-helper settle and the test's own), but this entry prescribes an exact replacement at an exact location, and two backlog entries have already failed on contact this arc for precisely that reason.
- **FIT & FINISH, P3 — `/races` redirect coverage is implicit.** The route crawl asserts 200 *after* `page.goto` follows the 308, so it catches `/races` breaking outright but not `/races` redirecting somewhere wrong. HO 502 set the explicit-assertion pattern three days ago for `/news` and `/president`. A one-line addition when someone next touches the crawl, not its own arc.
- **WATCH — global concurrency group.** `e2e-prod`'s concurrency group is global, not per-ref, so a deploy burst can cancel an in-flight scheduled run; a cancelled run reports as neither green nor red. Low probability at once-daily, and arguably correct behavior (newer state wins). **Recognition symptom:** if the daily crawl ever appears to stop reporting, check for cancelled runs before debugging the schedule. Did not occur on the 504 push (one deploy, one event, nothing cancelled) — this is latent, not demonstrated.
- **WATCH or a line on the existing loop — `console-noise.ts` is gate-critical.** `e2e-prod.yml` reds on any un-allowlisted console error, so adding an entry to the shared allowlist is a decision with teeth rather than housekeeping. Two of its five entries are open loops (`MissingSecret`, the FilingRow dup-key) whose fixes should delete them; the file carries per-entry provenance so they stay grep-findable when those loops close.

**Update, don't duplicate:** the existing **`actions/checkout` + `actions/setup-node` → v5** loop now spans *two* workflows, and both `e2e-prod` runs carried the same Node-20 deprecation annotation. Amend that loop's scope line; don't open a second entry for the same bump.

### `docs/oddities.md`

Newest-first. **One entry, and it's the arc's whole point:**

**Skip-on-empty guards invert a fixture's failure mode.** A spec that reads `if (await x.count()) … test.skip(...)` is honest against prod, where zero rows can be genuine data variability. Against a fixture — which is deterministic by construction, so a guard can never be needed — the same line means an **under-seeded fixture passes while exercising nothing.** Playwright reports a skip as not-a-failure, so the suite goes green. That is strictly worse than the red-blindness the fixture was being built to cure, and it is what killed the Phase-2 fixture at HO 503 after the bucket count (95% nominally servable) said build it. **The corollary that outlived the verdict:** those guards are in the specs *today*, running against *prod* — so a surface that regresses to zero rows currently skips its test and the run stays green. HO 504 converted the one instance in `smoke.spec.ts` where empty means regression rather than variability (the `/electoral` cartogram, static topojson, never DB rows); `fit-finish.spec.ts` still carries the bulk of them and stays manual.

**Judgment on scope, and read this before adding more:** the doc-duplication WATCH item (logged HO 502 as the third instance, "revisit on a fourth") proposed the fix as *deciding which file owns a fact so the other points at it.* Practice that here rather than logging a fourth instance. **Oddities owns the finding** — the mechanism, the numbers, what it killed. **SKILL owns the forward rule** and points back at this entry instead of restating it. If you catch yourself writing the same sentence into both files, that's the instance, and it's the fourth.

Do **not** add a second oddities entry for the `deployment_status` / alias-swap detail. It's already recorded where it acts — as a constraint comment in the workflow, aimed at whoever tries to cache the install step. Duplicating it into oddities is the exact behavior the WATCH item is tracking.

## Commit 2 — `SKILL.md`, alone, self-mod guard

Show the diff and wait for explicit approval. Separate commit, nothing rides it. Path is under `.claude/` so CI doesn't fire.

The testing section is now stale in a load-bearing way — it predates both workflows. It should carry:

- **Two workflows, two jobs, and what each is for.** `ci.yml` = Phase 1, typecheck + build, secretless, on `pull_request` / `push:main` with the `paths-ignore` filter. `e2e-prod.yml` = the unattended prod crawl, three triggers, `smoke.spec.ts` only, off the PR path by design. State why they're separate files — the branch-protection landmine — because that's the part someone will otherwise "tidy up."
- **`@nonci` as a tag convention**, not a one-off: a test tagged `@nonci` is excluded from the unattended run. First and only member today is the markets-hover case (bucket D, BotID). The tag exists so the next exclusion is declared in the spec where a reader sees it, rather than as a title-substring match in a YAML file.
- **`e2e/console-noise.ts` is the single allowlist**, imported by both specs, and it gates a real run. Adding an entry has teeth.
- **The forward rule, stated once:** don't guard a spec with skip-on-empty when the surface is one where empty means regression — assert the precondition, or tag the test out. Point at the oddities entry for the mechanism; don't restate it.

Check whether SKILL's testing section still describes `verify:deploy` or the e2e suite as prod-manual-only. If it does, that's now wrong in the authoritative doc — the same failure shape as the force-dynamic correction at HO 502, where SKILL kept asserting a mechanism oddities had already fixed.

## Report back

Commit 1 diff as raw fenced text in your reply body, all three files. Then commit 2's `SKILL.md` diff separately for its own approval. Explicit pathspec staging both times, ancestry eyeball immediately before push, fast-forward only.

Confirm at the end: no source files touched, `ci.yml` untouched, and the roadmap edit is purely additive (new "Also" block + pointer bump, no prior block modified).
