# HO 622 — Absence Watch builds: streak-led, dated, two rows today.

HEAD as pushed at 621 (fetch and confirm; pointer still "run through HO 620" — 621/622 sweep together at this HO's close). **Next free is 622.** The ruling from the 621 output governs:

- **Trigger: consecutive-miss streak ≥ 30**, per chamber, newest→oldest, explicit `not_voting` extends, any explicit position breaks, NO-DATA skips (the 588 rule verbatim). Population = the strip's (`member_participation` + `PARTICIPATION_FLOOR` at read time + the delegate carve).
- **Copy is dated, never "now":** the row's claim is *no vote cast since {date}*, which stays true through recess. R2's cumulative rate rides inside the row as evidence. R1 is dead.
- **Division of labor, recorded:** Absence Watch is *acute* (gone); the participation dot-plot and `/members` sorts are *chronic* (spotty). Biggs-class members (26/30, streak 0) are correctly absent from this strip and present on those.
- Expected render today: **Wilson (since Jul 16) and McConnell (since Jun 11), and nothing else.** That expectation is a verification instrument, not a hope — see §3.

## 1. Commit 1 — the data layer

`getAbsenceWatch()` in `lib/queries.ts`, shaped as:

1. **Candidate filter first, walk second.** Phase A is the probe's M3b window query per chamber (last 30 roll calls, members with 30/30 explicit `not_voting` among rows present — the ≥30-streak candidates are necessarily 30/30 in the window, so the cheap query bounds the expensive one). Phase B walks only candidates: true streak up to a **bound of 120 rolls**, plus the date of the last explicit vote (or "start of the 119th" if the walk hits the bound — display `120+` and the bound date, honestly).
2. Return type **JSON-serializable only** (the HO 533 rule): plain objects, ISO date strings, no Map/Set/Date.
3. `unstable_cache`, `revalidate: 3600`, tagged so the **sync-votes cron** busts it the way the participation refresh does — read how `participation-refresh.ts`'s consumers tag and match the house pattern rather than inventing one. The degradation guard, if any, sits **outside** the cache boundary (the HO 598 cache-scope lesson).
4. Cost stays in M3b's family: Phase A ≈ 16k rows, Phase B a few hundred per candidate, tag-preferred cadence. State the measured first-run cost in the HALT.

`feat(absence): HO 622 — getAbsenceWatch: streak-led candidate filter + bounded walk, dated, cache-tagged`

## 2. Commit 2 — the band

Into the HO 608 slot (between nav and hearings), as the committed mock's absence band drew it, under the conventions:

- **Conditional: zero qualifying members renders `null`.** No wrapper, no reserved box, no header for nothing — C4, and the strip's empty state is the good-news state.
- Row anatomy, packed left, `--fs` tokens: `ABSENCE WATCH` label on the band once, then per member — name bright, `{party}-{state}` in party color (party carries party), **`NO VOTE CAST SINCE {MON DD}`** as the claim, `· {streak}+ CONSECUTIVE ROLL CALLS` and `· {rate}% OF 119TH VOTES` dim as evidence, linking to the member hub. Trailing gap right; no far-right anchor; two-line collapse at narrow widths per the kit, wrap-don't-pin.
- **The mock's footer line ships**: `NON-VOTING DELEGATES EXCLUDED · REFRESHES AFTER SYNC-VOTES` — it was designed in, and it discloses the carve (Radewagen at 82.4% is carved by rule, and the footer is why that's legible rather than mysterious).

`feat(absence): HO 622 — the Absence Watch band: conditional, dated claims, carve disclosed (C1–C8 native)`

## 3. Verification — the probe is the oracle

1. **Probe-consistency check before anything ships:** run `getAbsenceWatch()`'s output against the 621 probe's numbers — it must name exactly Wilson and McConnell, with last-vote dates Jul 16 / Jun 11 and streaks consistent with 30+ (the walk should report the true figures past the window cap; McConnell's will be large). Any third name or a date disagreement is a stop: the query and the probe disagree about the same corpus, and one of them is wrong.
2. **Cache posture proven, not assumed:** hit the page across the miss and hit paths (HO 533), and after deploy, hit until the strip's content **converges and holds** (HO 555) — the SHA via `/api/version` first.
3. **The audit debut:** `--route home` at 2560 before and after. M1 must hold 0 with the band populated (it's packed by construction — prove it), M4-true must hold 0 (the conditional render means no reserved space; the fixture is untouched and its legs run first). Narrow ladder 1024/900/720: the band wraps, nothing pins, bucket (b) unchanged.
4. Eyeball 1440/2560: two rows, dated copy, footer line, links land on the member hubs; and **force the empty state** locally (threshold bumped in a scratch run, not committed) to see the band render nothing — the C4 branch gets fired, not narrated, per the falsification rule.
5. Prod-verify converged, then **HALT** with the probe-consistency print, the cost number, both audit tables, and screenshots.

## 4. The close — small sweep on `refs/heads/622-review`

After prod verification only. One docs commit + no SKILL (nothing rule-shaped emerged; say so):

- **Backlog:** the Absence Watch entry (open since HO 588, outlived two arcs and the loop it was blocked behind) → **SHIPPED at 622**, carrying the ruling and its rationale in three sentences: streak-led because cumulative triggers make false present-tense claims (6 sticky vs 1 blind in the 621 corpus), dated copy because "since {date}" survives recess where "now" lies, acute/chronic division of labor with the participation surfaces. Plus a **WATCH: S = 30 launch-conservative** — revisit after a live cycle; a long-empty strip is C4 working, not a broken threshold, but a strip that never fires across a full active session means S is above the corpus.
- **Roadmap block** covering 621–622, pointer → 622: the probe redux (what the reconcile found — mechanism moved, semantics held, M1.0 drift 0), the four reads, the ruling, the build, the probe-as-oracle verification, today's two names.
- HALT on the ref with the block for the diff read, land on approval, gates ("HO 620" ×1, "HO 622" ×1).

## 5. Guards

1. Probe HO and build HO stay separate — 621 is closed; this HO does not touch the probe except to *run* it if the oracle check needs a fresh print.
2. `queries.ts` gains one export; nothing existing is edited. The participation surfaces are untouched.
3. `--fs` tokens 9–14px; no `data-viz-row` (nothing here is an axis); the audit's fixture untouched.
4. Explicit pathspecs, typecheck per commit, ancestry counts stated, code and docs never mixed — the sweep waits for the live verification it cites.
