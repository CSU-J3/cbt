# HO 491 — doc sweep: CI wiring + hydration arc (488–490)

Docs only. **No code, no config, no workflow changes.** Two commits: docs, then SKILL.md separately under the self-mod guard.

Everything here is already shipped and verified — `3aa677c` (CI), `c7d75f1` (probe), `8114ffc` (fix), CI green on each. Nothing to re-verify.

---

## Step 1 — `docs/roadmap.md`

Append-only. New dated block, bump the running pointer to 491. **Never retro-edit a prior block** (HO 418 precedent).

- **HO 488 — CI wiring.** First CI in the repo; there was none after the HO 475 Vercel-cron cutover retired the GitHub Actions workflows. `.github/workflows/ci.yml`: single `checks` job, typecheck + build, on `pull_request` and `push:main`, Node 20, `concurrency` with `cancel-in-progress`. **Secretless** — `next build` succeeds with `TURSO_*` and `GEMINI_API_KEY` unset because every DB-backed route is dynamic. Lint deliberately omitted: no ESLint dependency or config exists in the repo. Verified by deliberate type error (TS2322, exit 2) and by confirming the log shows real execution, not skipped steps.
- **HO 489 — hydration probe.** Root-caused intermittent React #418 on `/bills`, `/changes`, `/`. Committed `scripts/diagnostic/hydration-probe-489.ts`.
- **HO 490 — hydration fix.** `formatRelativeAge` / `formatRelativeAgeLong` / `daysSince` take a required `nowMs`; one clock per page, prop-drilled, no context provider. 34 files, +282/−75. Required-with-no-default was the point: `tsc` now rejects any implicit-clock caller, and CI runs `tsc`, so the bug class is closed rather than the instance. Acceptance test = the 489 probe under forced straddle, 0 errors across 6 loads.

Note the closing loop explicitly: **488 built the gate, 489 found the cause, 490 used the gate to make the cause unrepeatable.**

---

## Step 2 — `docs/oddities.md`

Six entries. Several exist to stop a future session re-deriving a dead end.

1. **The force-dynamic invariant (now load-bearing).** Ages are computed once server-side and passed to the client, so server and client always agree. If an age-rendering route is ever prerendered or given a `revalidate` window, the frozen clock produces a **silently wrong age with no hydration warning** — both sides agree on the stale value, so nothing fires. This fix traded a loud failure mode for a silent one under conditions that don't currently hold. Verified at fix time: none of `/committees`, `/races`, `/primaries`, `/members/pass-rate` render a relative age, and no route sets `revalidate`.

2. **Dev cannot reproduce hydration mismatches naturally — a clean dev run proves nothing.** 9/9 loads came back clean. That's structural: dev never prerenders and its SSR→hydrate gap is ~0ms, so a bucketed relative time almost never straddles a boundary. Prod's real server→client latency widens the window, which is why the bug was prod-only and intermittent. **Technique that works:** Playwright `addInitScript` advancing *only* the client's `Date.now()` (leaving `Date.parse` intact) before hydration — the server renders at real time, the client hydrates in a later bucket, mismatch guaranteed. That's what `scripts/diagnostic/hydration-probe-489.ts` does; re-run it with `CLOCK_OFFSET_MS` to verify any future hydration work.

3. **Prod React minifies hydration errors — chase them in dev.** Production gives `#418` with no component name and no diff. Dev prints the server-vs-client text and a full component stack. But see (2): dev alone won't reproduce it, so you need dev *plus* the forced straddle.

4. **`Date.now()` read during render in a client component is a hydration bug by construction.** Generalizes past time: any non-deterministic value read at render (now, random, locale, timezone) must be computed server-side and passed as data. The enforceable form is a **required** parameter, not a defaulted one — a default compiles every existing call site untouched and lets the bug walk back in silently.

5. **Two dead ends, recorded so they aren't re-derived.** Both were plausible and both were wrong:
   - *Not* the `LAST SYNC` / HO 183 cycling timezone stamp. `CyclingTimestamp` + `lib/zone-cycle.ts` are hydration-safe by construction — SSR and first client paint both render MT, the live zone swaps only in `useEffect`, and they read a fixed `corpus.lastSync` rather than `now`.
   - *Not* static-page staleness. **`/dashboard-v2` is a `permanentRedirect("/")`, not a static page** — HO 488's build output showing it as static was the redirect stub, and the failure attributed to it is really the home page after the 308. Write this down plainly; the build output will mislead the next reader the same way it misled this one.

6. **Don't point the smoke suite at dev.** Dev emits `[auth][error] MissingSecret` because `AUTH_SECRET` lives only in `.env.production.local`. The specs assert on console errors, so dev produces false failures on `/bills`, `/changes`, `/dashboard-v2` that have nothing to do with the thing under test.

---

## Step 3 — `docs/backlog.md`

Each with its blocker stated:

- **CI Phase 2 (Playwright in CI)** — three blockers remain: no `webServer` block in `playwright.config.ts` (it only sets `baseURL`, pointing at a live URL); `TURSO_*` unprovisioned as repo secrets (only `CRON_SECRET` exists); and the markets-hover `.hover()` timeout, which fails consistently headless and is an interaction issue, not hydration. **Preferred path when this is picked up: a seeded local libSQL file in CI, not prod credentials in Actions.** libSQL is SQLite, so a fixture database removes the secrets question entirely rather than managing it.
- **ESLint absent** — no dependency, no config. Wiring it is its own arc: install, configure, then triage a likely wall of pre-existing errors across the runtime surface. Deliberately kept out of HO 488 so CI could land clean.
- **Dev `AUTH_SECRET` gap** — dev-only console noise, see oddity 6. Config fix, not a code fix.
- **`/lobbying` height compaction** — mockup delivered (bounded issue rail with internal scroll, crosswalk + firms side-by-side and internally bounded, ~3,000px → ~1,200px). Awaiting a decision on whether the rail bound is `.lob-rail`-scoped or goes on the shared `.mc-rail`. Not started.

---

## Step 4 — `.claude/skills/cbt/SKILL.md` (SEPARATE COMMIT — self-mod guard)

Three edits:

1. **New: CI exists and what it enforces.** `.github/workflows/ci.yml` runs typecheck + build on `pull_request` and `push:main`, secretless. State that a red CI blocks nothing mechanically (no branch protection) but is the standing signal.
2. **Amend the HO 487 pre-push typecheck gate entry.** It currently reads as a manual convention. It's now automated by CI as of `3aa677c` — keep the pre-push habit (it's faster than waiting for Actions) but say the enforcement is real, not honor-system.
3. **New: the clock-explicit convention.** `formatRelativeAge(iso, nowMs)`, `formatRelativeAgeLong(iso, nowMs)`, `daysSince(dateStr, nowMs)` take a required clock. Compute one `nowMs = Date.now()` per page in the owning server component and prop-drill it; no context provider. Never call `Date.now()` during render in a client component. Cross-reference the force-dynamic invariant (oddity 1).

**Self-mod guard: show the SKILL.md diff and wait for explicit approval. Separate commit, never bundled with the docs commit.**

---

## Git discipline

- Clone / hard-reset to `origin/main` first — HEAD should be **`8114ffc`**.
- Explicit pathspec staging; never `git add .` (untracked diagnostic and design files must stay out).
- Two commits: `docs: sweep CI + hydration arc (HO 491)` then `docs(skill): CI enforcement + clock-explicit convention (HO 491)`.
- `npm run typecheck` before push. Ancestry eyeball, fast-forward only, no force-push.
- Skip `verify:deploy` — docs-only, no runtime surface to promote.

## Report back

The roadmap block diff, then the SKILL.md diff separately for its own approval.

---

read docs/handoffs/491-doc-sweep-ci-hydration.md and follow it
