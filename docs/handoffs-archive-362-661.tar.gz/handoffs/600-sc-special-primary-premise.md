# HO 600 — the SC Aug-11 special primary: one seeded contest doesn't exist, and the source page probably never will

**Numbering.** Next from `docs/roadmap.md`'s pointer (latest block: "Also notes now run through HO 598", Docs: HO 599; `main` = `cb61a4f`). Confirm against the roadmap and `git log` before writing anything.

**This handoff builds almost nothing.** Four measurements, then HALT. One pre-authorized data fix is described in §3 but does not run until STEP 0 reports.

---

## §0 — Why now, and what changed

**The clock is real and it is short.** `runSpecialPriorityPass` (`lib/primaries-sync.ts:612`) selects seeded `-special-` rows where `ABS(julianday(primary_date) - julianday(today)) <= 7`. `senate-SC-2026-special-{D,R}` carry `primary_date = 2026-08-11`. Today is 2026-08-05, so the window opened **2026-08-04** and the trigger has been live for roughly three twice-daily ticks. This is the first time in the feature's life that HO 561 C1's hit branch could run at all: it has only ever demonstrated its 404 skip.

**Two external facts, verified 2026-08-05, that nothing in the repo can rederive.**

**(1) There is no Democratic contest on August 11. The seeded `senate-SC-2026-special-D` row is a contest that does not exist.** The SC Election Commission's notice (2026-07-13) states the special filing period and special primary are held under S.C. Code §7-11-55 after the death of the Republican nominee for U.S. Senate, and that because that candidate had general-election opposition, **the filing period was open to Republican candidates only**. Multiple county boards and the LWV state guide carry the same wording, and voters who cast a ballot in the June *Democratic* primary are explicitly barred from the August 11 contest. The winner goes onto the November 3 general ballot in the deceased nominee's place.

So a live prod row is asserting a Democratic special primary six days out. `election_round='primary'` puts it into `getPrimaryCalendar`, which feeds `PrimaryTimeline`, so this is a wrong claim rendering, not a dormant row.

**(2) The Republican field has been published since July 28.** Candidate filing closed 2026-07-28; the August 11 ballot is set; statewide early voting runs August 5 to 7. So "the field is not yet published", the premise written into `data/special-primary-seeds/sc-2026-senate.json`'s `note` and carried through HO 560 and HO 561, is **now false**. Whatever is blocking ingestion, it is not that the roster doesn't exist.

**The design premise that is probably wrong.** `senateSpecialPageUrl` (`lib/primary-candidates-scrape.ts:100`) builds:

```
https://ballotpedia.org/United_States_Senate_special_election_in_{Slug},_2026
```

That URL shape is Ballotpedia's convention for special **elections**: Florida (Rubio's remainder) and Ohio (Vance's remainder), both on November 3, and both listed as the *only* two 2026 Senate specials on Ballotpedia's `United_States_Senate_elections,_2026` page. **SC is not among them, and correctly so.** South Carolina's August 11 contest is a special *primary* for the regular Class-2 seat, feeding the ordinary November 3 general. The seat is not vacant-and-special; the nomination is.

Ballotpedia's convention for a per-primary page is a parenthetical suffix on the **regular** race page, and both June pages exist under exactly that shape:

```
United_States_Senate_election_in_South_Carolina,_2026_(June_9_Republican_primary)
United_States_Senate_election_in_South_Carolina,_2026_(June_9_Democratic_primary)
```

**So the 404s observed at HO 560 and HO 561 were most likely never "not published yet". They were the wrong page shape**, and waiting for that page to appear is waiting for something that isn't coming. Stated as a hypothesis, not a conclusion: the special URL has not been fetched directly in this pass, which is M3's job.

**Consequence for the WATCH.** The backlog's close criterion, *"results present in `senate-SC-2026-special-{D,R}` by roughly Aug 13"*, **cannot be met for D by statute**. It is an instrument that reads FAIL when the system is correct. It must be replaced with a Republican-only criterion, per the ledger's own header rule.

---

## STEP 0 — four measurements, then HALT

Script where a script fits: `scripts/diagnostic/sc-special-premise-600.ts`, read-only, refusing any non-SELECT. Commit it, then stop.

### M1 — the D row's live state and its blast radius

Read-only, against prod.

- Does `senate-SC-2026-special-D` exist? Its `primary_date`, `runoff_date`, `election_round`, `race_id`, `updated_at`, and its `primary_candidates` count (expected 0).
- Same readout for `senate-SC-2026-special-R`.
- **Name every surface that reads them.** At minimum check `getPrimaryCalendar` → `PrimaryTimeline` (does an Aug 11 tick render, and does it render one entry or two?), `/race/S-SC-2026`, and `/electoral`. The rows carry `race_id = 'S-SC-2026'`, so the race hub is in scope, not just the timeline.
- **Does any member chip resolve to the D row?** `getPrimaryForRace` after HO 586 takes `memberChamber` and is party-keyed with a future-first ORDER BY. An SC Democrat has no seat here, but state the result rather than reasoning it: run the shipped function for both SC senators and report the resolved row id and rendered date.

Report what a reader of the site sees today, in plain terms. That is the severity, and it decides whether §3 ships immediately or waits.

### M2 — has the priority trigger fired, and what did it return

The first-ever exercise of C1's hit branch. Read `cron_runs` for `/api/cron/primaries` from `2026-08-04T00:00:00Z` forward:

- `payload.priorityScraped` per tick: which special ids were attempted.
- `payload.fetchFailures`: the status per attempt.
- `cursorStart` across ticks: **confirm the cursor did not advance on the priority pass** (the C2 contract).
- `payload.settledSkipped`: see M3's caution below.

**No rows in that window is itself a finding.** It would mean either the cron didn't run or the window query selected zero, and those are different bugs. Say which, don't average them.

### M3 — does any page carry the August 11 field, and at what URL

Live fetch, read-only, no writes. Try in this order, reporting HTTP status and whether `parseCandidatesPage` finds its `Candidates_and_election_results` anchor:

**(a)** `United_States_Senate_special_election_in_South_Carolina,_2026` — what the code builds today.
**(b)** the parenthetical shapes on the regular race page. The two June pages prove the convention exists; find the August one if it exists. Report the exact URL string.
**(c)** `United_States_Senate_election_in_South_Carolina,_2026` — the regular page. Does it now carry an August 11 votebox **alongside** the June ones?

**Do not invent a roster.** If no Ballotpedia page carries the field, that is the answer, and the fix is a source change rather than a parse fix.

**Caution on (c), and this is the sharpest thing in the measurement.** If the regular SC senate page now carries both the June and August voteboxes, then the *standard* pass, `scrapeSenateCandidates`, may pick up the August box and write it into `senate-SC-2026-R`, the settled June row. **That is precisely the substitution hazard HO 560 was built to stop**, arriving on schedule, and this is its first live test. `senate-SC-2026-R` is past-dated and carries shares, so the HO 560 C2 freeze should refuse the rewrite. Verify it did: report `settledSkipped` and confirm the June row's shares are unchanged. If the freeze held, say so as a proven guard rather than a green run. If it did not, that outranks everything else in this handoff.

### M4 — the votebox to party mapping

The third step in the WATCH's diagnostic order, run only if M3 finds a page. On whatever page carries the August field, does the votebox class map to `R`, or does it fall through to `open`? A special primary heading may not read as a plain "Republican primary" box.

**Then HALT.** Report M1 to M4 and stop.

---

## §3 — the pre-authorized fix, gated on M1 only

The statutory fact is externally verified and unambiguous, so the D-row removal does not need a second round to authorize. It ships **only if M1 confirms the row exists with zero candidates**, and it ships as one commit with both halves.

**The mechanism matters.** `scripts/seed-special-primaries.ts` is a pure `INSERT … ON CONFLICT DO UPDATE` with no delete pass. **Removing the entry from `data/special-primary-seeds/sc-2026-senate.json` does not remove the live row.** Both are required or the next `seed:special-primaries` run recreates it.

1. A scoped one-off delete, print-before-delete, on the HO 412 phantom-deletion precedent (`S-CA-2026` / `S-NY-2026`). Print the row and its dependents first, then delete **one literal id**: `senate-SC-2026-special-D`.
2. Remove that entry from the seed JSON in the same commit.
3. **Rewrite the seed file's `note`.** Its current text asserts the field is unpublished, which is false as of July 28. Replace it with the statutory fact, its source, and the verification date, so nobody re-adds a D row from the symmetry of the R one. Record explicitly that a §7-11-55 special primary is single-party by construction when the deceased nominee had general-election opposition.

**Guards.**

- Do not touch `senate-SC-2026-D` or `senate-SC-2026-R`. Different id set, settled, frozen.
- Do not widen the delete to a `LIKE '%-special-%'` glob. One literal id, matching the HO 577 scoping discipline.
- **Do not change `senateSpecialPageUrl` in this HO.** It is also the FL/OH fallback path, and for FL and OH the current URL shape is *correct* — those are genuine special elections. Retargeting it would break two working states to fix one that needs a different source. If M3 says the URL is wrong for SC, that is its own scoped change with FL/OH regression coverage stated as a gate.
- No falsification leg may write a known-wrong value to the production database (SKILL, HO 585).

---

## §4 — what this HO does not decide

- **How the R roster gets populated.** M3 decides that, and the answer may be that Ballotpedia is the wrong source entirely. If it is, the fallback is the SC Election Commission's own results, which is a new scraper and a separate build with its own probe. Flag it, do not scope it here.
- **The replacement close criterion** for the WATCH. Propose one in the ship report, R-only, with an instrument that can read FAIL. The current one cannot.
- **Post-election results ingestion.** August 11 is the election; results follow. This HO is about the field, not the outcome.

---

## Close

Report M1 to M4, name whether the freeze held on the June row, and stop. If M1 confirms the phantom, ship §3 as one commit and show the diff before pushing.
