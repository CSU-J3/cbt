# HO 394 — News funnel probe (instrument, run once, revert)

Confirm 394 is the next free number before saving (`ls docs/handoffs/ | sort -V | tail`); body assumes 394.

## What this is

Read-only diagnostic. Temporarily instrument `lib/news-ingest.ts` to capture the ingest funnel over ONE run, print the numbers plus the dropped titles, then revert. No schema. No new tables. No commit.

Goal: see where articles fall out of the pipeline. Almost everything gets fetched; almost nothing ends up as a mention. This tells us whether the loss is the pre-filter, the matcher, or something else.

## HALT — this is a probe

- Do NOT add columns, tables, or migrations.
- Do NOT commit. Every edit gets reverted at the end.
- One real side effect, and it's expected: a live ingest writes mentions to the shared prod Turso exactly as the daily cron would. That's intended, we want the true `mentionsInserted`. Nothing else is written.

## Pre-flight

Before touching anything, confirm the file is clean so the revert can't clobber a parallel agent's work:

```
git status --short lib/news-ingest.ts
```

If that prints anything, STOP and report it. Don't start.

## Verify premises live (structure has drifted since HO 64)

Read the current code before editing. Don't trust the old handoff shape.

- `lib/news-ingest.ts` — the ingest loop and the result type it returns (`IngestResult`, or whatever it's now called).
- Confirm the four funnel landmarks in the current loop:
  1. **itemsFetched** — items pulled from RSS. Already carried per-feed in the result object.
  2. **pre-filter gate** — the in-memory keyword/heuristic filter that runs before bill matching. We want the count of articles that clear it.
  3. **billMatches** — the per-article match array and the `if (billMatches.length === 0) continue` drop.
  4. **mentionsInserted** — final inserts. Already carried in the result object.
- If any landmark's name differs from the above, use the live name and report which one you used. If there is no distinct pre-filter stage in the current code, say so and report the stages that actually exist instead of inventing one.

## Instrumentation (temporary)

Add temp logging only. Capture, aggregated across all feeds:

- `itemsFetched` — sum of items pulled.
- `prefilterPassed` — count of articles clearing the in-memory pre-filter. Reuse an existing field if the loop already counts it; otherwise add a local counter incremented at the point an article passes the pre-filter, before matching.
- `matched` — count of articles with `billMatches.length >= 1`. Reuse if already counted; otherwise add a local counter.
- `mentionsInserted` — from the result object.

Dropped set: at `if (billMatches.length === 0) continue`, push the article title (use the live title field) to a temp array. After the run, print the first ~30, one per line.

Print one delimited block at the end of the run so it's copy-pasteable:

```
=== HO 394 FUNNEL ===
itemsFetched:     <n>
prefilterPassed:  <n>
matched:          <n>
mentionsInserted: <n>
=== DROPPED (billMatches==0), first 30 ===
<title>
<title>
...
```

## Run

Run one ingest through the existing CLI entry point. Confirm the script name from `package.json` first (`sync:news` per HO 64, but check it's still named that):

```
npm run sync:news
```

This hits live RSS and prod Turso. Expected.

If the run errors out (e.g. the news pipeline is still failing on the candidate-bills query or a feed), do NOT fix it. Capture the error verbatim and report that in place of the funnel block. This is a probe, not a fix.

## Revert

Restore the committed state, this pathspec only:

```
git restore lib/news-ingest.ts
git status --short lib/news-ingest.ts   # must print nothing
```

## Report back, verbatim

1. The FUNNEL block plus the ~30 dropped titles.
2. The actual field/var names you instrumented (so I know the live shape), and whether a distinct pre-filter stage exists.
3. Confirmation the revert left the file clean.

No commit.
