# HO 481 — `queryEnactedThisWeek` cold-stall (the 5th sibling)

**Type:** probe-then-fix, **hint-first**. Closes the `queryEnactedThisWeek` OPEN LOOP (opened in the HO 480 docs commit). Same cold-DB-stall class as HO 405 / 407 / 480 — the last sibling in the enacted/lead cluster. Shared helper, so the blast radius gets verified, not a drive-by.

---

## What HO 480 surfaced

The 480 sweep cold-EXPLAINed all four `gatherLeadData` reads and hinted three (`transRs` / `topicRs` / `introRs`). The fourth — **`queryEnactedThisWeek`** (`lib/enacted-this-week.ts`, the shared HO 232 helper) — mis-plans identically (`MULTI-INDEX OR` over `idx_bills_dash_stage` + temp-btree) and was flagged-not-touched per the 480 handoff's shared-helper guard.

**The stale premise HO 480 corrected:** the HO 335 assumption that this helper rides `idx_bills_enacted` cleanly is wrong. `idx_bills_enacted` is `(congress, latest_action_date) WHERE stage='enacted'` (migrate.ts:1070) — it has **no `stage_changed_at`**, so it can't serve this query's `stage_changed_at` window filter or its `ORDER BY stage_changed_at DESC`. Different column than HO 335 assumed.

**Severity is low and bounded** (unlike `transRs`): the query carries `AND stage='enacted'`, so even mis-planned it seeks the small enacted set (few enacted rows/week) rather than scanning the full corpus — which is why it never tipped the 55s wall. This closes the class for correctness/hygiene, not because the wall needs it. But leaving a known sibling of this class unfixed is the exact `gatherReportData`→`gatherLeadData` miss that created the 480 loop, so we close it.

---

## The blast radius — both callers live in `lib/enacted-this-week.ts`

1. **`queryEnactedThisWeek`** — the row query. Consumed by the lead step (`gatherLeadData`) **and** the ENACTED THIS WEEK banner (`getEnactedThisWeek`, `lib/queries.ts:5167`). Predicate: `(is_ceremonial=0 OR IS NULL) AND stage='enacted' AND stage_changed_at IS NOT NULL AND stage_changed_at > datetime('now','-7 days') ORDER BY stage_changed_at DESC`.
2. **`queryEnactedPriorWeekCount`** — the week-over-week delta COUNT. Same predicate, bounded window `(now-14d, now-7d]`, no ORDER BY.

A hint applied in the shared helper flows to **every** caller — which is what we want; they all take the same predicate and want the same collapse. Sweep both functions.

---

## The fix — hint first, index only if it doesn't land

Try Option A before Option B. Prefer the hint onto the existing partial index over a new index (the probe-before-build / hint-over-migration discipline). This is a probe: cold-EXPLAIN + cold-time decides which option ships.

**Option A (expected to work) — `INDEXED BY idx_bills_enacted` on BOTH functions.** The partial index is `WHERE stage='enacted'`, and the query has `AND stage='enacted'`, so it qualifies. Forcing it → scan the partial enacted index (a few hundred rows, the whole enacted set for the Congress) → filter `stage_changed_at` + sort in memory, trivial at that row count. Cold-EXPLAIN and cold-time each function.

- **Acceptance:** plan reads `SEARCH`/`SCAN bills USING INDEX idx_bills_enacted` (the small partial), **no `MULTI-INDEX OR`**, and cold-time comfortably under the `boundedFetch` 10s wall. If both clear → ship Option A, no migration.

**Option B (fallback, only if A doesn't collapse under the wall) — a new partial index.** `CREATE INDEX idx_bills_enacted_changed ON bills(stage_changed_at DESC) WHERE stage='enacted'`. Serves the window filter + sort directly (`SEARCH … (stage_changed_at>?)`, pre-sorted). Tiny (enacted set is small). This is a **migration** — add to `migrate.ts`, and apply it to prod **out-of-band** per the HO 406 gotcha (building an index over the corpus can itself trip the 10s `boundedFetch`, so `npm run migrate` may abort it; build once with a long-timeout libsql client, `CREATE INDEX IF NOT EXISTS` no-ops thereafter). Only reach for this if the hint genuinely doesn't land — don't add an index the hint makes unnecessary.

---

## Verification

- Cold-EXPLAIN both functions before → after; the plan must drop `MULTI-INDEX OR` + temp-btree.
- Cold-time `getEnactedThisWeek` and the lead's enacted read from idle: out of any stall band, no `[db] timeout, retrying`.
- Confirm the ENACTED THIS WEEK banner and the week-delta still render the **same numbers** — the hint/index is plan-only, never a semantic change.

---

## Commits

1. **Code** — `lib/enacted-this-week.ts` (Option A hint) **[+ `scripts/migrate.ts` only if Option B]**. If Option B, keep the schema/index commit separate from any other change per the two-commit rule, and report the out-of-band index-build result.
2. **Docs** — backlog tombstone (close the `queryEnactedThisWeek` OPEN LOOP that the 480 docs opened); oddities note (the enacted helper closed the 480 sweep's 5th sibling; record that `idx_bills_enacted` keys `latest_action_date`, not `stage_changed_at`, correcting the stale HO 335 read); a roadmap `Also (HO 481)` line if you're tracking it as its own block, else fold the closure into the 480 block.

---

## Guardrails

- Explicit-pathspec stage; a concurrent session holds untracked files that must not be staged.
- **No auto-commit.** Show me each diff, the cold-EXPLAIN (before → after) for both functions, and the cold-time; wait for approval. If Option B, show the out-of-band index-build result before the code that depends on it goes to prod.
- Ancestry check immediately before any push; no force-push; keep code and docs commits separate.

---

read docs/handoffs/481-enacted-helper-hint.md and follow it
