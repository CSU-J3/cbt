# HO 432 — race→news: light the dark HO 272 NEW badge + race news in the dashboard popover

Two surfaces off the observation join (HO 394/398), both dashboard-side, both incumbent-keyed (matches HO 398 — a race's news is news mentioning its incumbent). **One data addition powers both:** the dashboard competitive popover starts fetching `getRaceNews(incumbent)` per card, and the RACES-tab NEW badge reads the latest date off that same fetch. No new query — so the HO 414 "fold `getRaceNews`+`getMemberNews` into `getObservationNews` on the 3rd consumer" debt **stays deferred** (this reuses the existing query, it doesn't write a third verbatim projection). See §D.

Re-grep every line number below; they drift. Diagnose before touching (§E).

## Verified state (established live at 7cbcd37, trust the plan)
- `RacesBoxTabs.tsx:78` hardcodes `const newCount = 0` with the comment "NEW = news→race linkage (absent); slot stays dark (HO 272)." The badge chrome (`.rbx-badge-new`, L113) already renders when `newCount > 0` — only the count is dead.
- The MOVES badge is the working template: `getRecentRaceMoves(raceIds)` → `moves` map (CompetitiveRacesBlock:83) → threaded `lastMoveAt={moves?.[raceId]}` into `<RaceCard>` (CompetitiveRacesStrip:117/125) → `<RaceMovedIndicator>` (RaceCard:308) renders `MOVED` when the move postdates last-view **and** registers in `RacesUpdatesContext` so the tab badge = registry size.
- The "dashboard drawer" is CompetitiveRacesStrip's **hover popover** (HO 178) rendering `RaceHubBody preview` from the pre-fetched `hubs` (CompetitiveRacesStrip:192-202). The popover `<div>` (L192) is a **sibling** of the card `<Link>` (L155-187), not nested inside it — so `RaceNewsRow`'s `<a>` headlines are valid HTML there and are clickable (cell-`:hover` keeps the popover open as the mouse enters it). This sibling structure is why news-in-the-popover is viable; it's currently absent only because `RaceHubBody` gates `news` behind `!preview`.
- `RaceHubData` (CompetitiveRacesStrip:15-19) is `{race, incumbent, candidates, runoffs}` — **no `news` field**. `CompetitiveRacesBlock` builds it (lines ~95-110) and already fetches each race's `incumbent` there.
- The news cron flushes `race-news` (`app/api/cron/news/route.ts:89`) and it's allowlisted on `/api/revalidate` (L28). So a `race-news`-tagged read lights on the daily news run with **no new tag, no cron edit, no allowlist edit**.

## A. Shared data — `getRaceNews` per card in the hub prefetch
In `CompetitiveRacesBlock`, inside the per-race hub build (the `races.map` that returns `RaceHubData`), add a `getRaceNews(race.incumbent_bioguide_id, N)` fetch, null-guarded on the incumbent exactly like the hub's existing `getMember` guard (open seat → `[]`, no join key). Add `news: RaceNewsItem[]` to the `RaceHubData` type.

- `N`: the popover shows a small cap (≤3). `getRaceNews`'s default is 8 (the hub keeps 8 at `app/race/[id]/page.tsx:72`). `unstable_cache` keys on the args, so `getRaceNews(inc, 3)` and `getRaceNews(inc, 8)` are distinct cache entries — either fetch 3 for the dashboard (a second small entry per incumbent, both `race-news`-tagged so flushed together) or fetch 8 and slice in render. Your call; note it in the diff.
- These reads ride `race-news` (getRaceNews's own tag), so they flush on the news cron independently of the hubs' `races` tag. No new tag.

## B. Light the NEW badge (mirror the MOVES path exactly)
1. **`RacesUpdatesContext.tsx`** — add a parallel news registry to the type + default: `registerNews(raceId)` / `unregisterNews(raceId)` beside the moved pair. Keep the single `lastViewMs` (one "last opened RACES" timestamp resets both badges — opening RACES marks both moves and news viewed, matching the current UX).
2. **New `components/RaceNewIndicator.tsx`** — a near-copy of `RaceMovedIndicator`: consumes `lastViewMs` + `registerNews`, computes `newsMs = lastNewsAt ? Date.parse(...) : NaN`, `isNew = lastViewMs != null && !NaN && newsMs > lastViewMs`, registers in the effect, renders nothing before hydration (`lastViewMs` null) so SSR/first-client agree (preserves the RacesBoxTabs:40 no-badge-on-first-render invariant). Visible form: a small `.rc-new` marker (e.g. `NEWS` or a `●`) mirroring `.rc-moved` — add the class to globals.css beside `.rc-moved`. Design call, tunable; note the MOVED+NEW co-render case (a card that both moved and has fresh news shows both tags — acceptable, flag if it reads cluttered).
3. **`RaceCard.tsx`** — add a `lastNewsAt?: string | null` prop beside `lastMoveAt`; render `<RaceNewIndicator raceId={row.raceId} lastNewsAt={lastNewsAt} />` next to `<RaceMovedIndicator>` (L308).
4. **`CompetitiveRacesStrip.tsx`** — pass `lastNewsAt={hubs[i]?.news?.[0]?.observedAt}` to `<RaceCard>` right beside `lastMoveAt={moves?.[race.raceId]}` (L125). This is the whole reason §A's fetch is enough for the badge — the latest news date falls out of the hub's news list, no recency query.
5. **`RacesBoxTabs.tsx`** — add `newsSet` state + `registerNews`/`unregisterNews` callbacks (copy the `movedSet` block), thread them through the `RacesUpdatesContext.Provider` value, and set `newCount = newsSet.size` (replace the hardcoded `0` at L78). `openTab("races")` already stamps `lastViewMs` — nothing to change there; the news indicators unregister on the same stamp, clearing the NEW badge on open just like MOVES.

## C. News in the popover (open the `!preview` gate, capped)
- **`CompetitiveRacesStrip.tsx:194`** — pass `news={hubs[i]?.news ?? []}` to the popover's `<RaceHubBody preview … />`.
- **`RaceHubBody.tsx`** — the news block is gated to the full hub (`!preview`). Add a **preview** news render: a compact `IN THE PRESS` section showing up to ~3 `RaceNewsRow`s when `preview && news?.length`. Keep the full 8-row block on the hub. The open-seat/empty case: preview can simply render nothing (no empty-state row in the cramped popover), while the hub keeps its empty state.
- **Hover-enterability check (real, do it):** the popover is `.competitive-race-cell:hover` with the popover a child of the cell. Confirm there's no dead gap between the card and the popover that drops `:hover` before the mouse reaches a headline — if there is, add a transparent bridge / padding so the links are actually clickable. Also note (minor, not blocking): the popover is `role="tooltip"`; tooltips aren't meant to hold interactive content, so clickable headlines there is an a11y compromise — leave the role for now, flag it for a later pass if you want.

## D. Do NOT generalize to `getObservationNews` here
The HO 414 debt note says fold on the 3rd obs-**consumer**. This handoff adds callers, not a third projection: the popover and the badge both call the **existing** `getRaceNews` (incumbent key), and there's no new recency query. So there are still exactly two `RaceNewsItem`-projection functions (`getRaceNews`, `getMemberNews`). Leave the debt note in `lib/queries.ts` in place — don't rename `RaceNewsItem`/`RaceNewsRow` or introduce `getObservationNews` in this arc.

## E. Diagnose first
- Re-grep the line numbers. Confirm `CompetitiveRacesStrip` renders `<RaceCard>` for the dashboard variant and where exactly `moves`/`lastMoveAt` threads (the file has more than one card branch — put `lastNewsAt` on the same branch as `lastMoveAt`).
- Confirm `race.incumbent_bioguide_id` is on the `Race` type used in the hub build (it's read at CompetitiveRacesBlock:104, so it is).
- Confirm the news cron flush + allowlist as quoted above before assuming no new tag is needed.

## Commit discipline
Spec-driven: propose the plan, show diffs, no auto-commit or push until approved. Suggested split (feature-separated), or collapse to one if the diff reads cleaner:
1. `feat(races): race news in the dashboard competitive popover` — §A (the shared `getRaceNews` fetch + `RaceHubData.news`) + §C (the preview render).
2. `feat(races): light the RACES-tab NEW badge off race-news recency` — §B (context + `RaceNewIndicator` + `RaceCard` threading + `RacesBoxTabs`).

No schema, no `migrate.ts`, no cron/allowlist edit, no `getObservationNews` rename. No `docs/` (a sweep folds this later).

## Report back
- The `N` you chose for the dashboard news fetch and whether you sliced or fetched-small.
- The badge: confirmation the NEW indicator mirrors MOVED (hydration-safe, registers/unregisters, clears on RACES open), and a shot/description of it lighting when a featured seat's incumbent has news newer than last-view.
- The popover: confirmation headlines are actually clickable (hover-enterability held, or the bridge you added).
- Confirmation `getObservationNews` was left un-done and the debt note is intact.
- Both diffs.
