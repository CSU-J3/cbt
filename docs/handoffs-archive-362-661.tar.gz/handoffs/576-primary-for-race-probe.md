# HO 576 — `getPrimaryForRace`: stop reconstructing the id, and decide what "next primary" means

Confirm the number: the roadmap's pointer runs through **HO 574**; HO 575 was its sweep (`fb400e3` + `a364b48`). So this is **576**.

**Diagnostic first, then a hard HALT.** No build code runs until STEP 0 is committed and reviewed. There is a design question buried in this that the backlog line doesn't name, and STEP 0 exists to surface it.

## Scope note — the orphan sweep is NOT in this HO

The backlog queues two primaries items. The other one (delete `buildPrimariesCartogram` / `PrimaryBand` / `PrimaryDistrictCard` / `PrimaryRow` / `getPastPrimaries` / `getUpcomingPrimaries`) is **deferred to its own HO**, because a planning-side check showed the backlog's flat list is misleading in a way that would burn this HO:

Every one of those symbols has references, but the referrers are largely **each other**. `PrimaryRow` imports `ShareBar`; `PrimaryDistrictCard` imports `ShareBar`; `ShareBar` is also imported by `PrimaryMapCard`; `CartogramShell` (live, backs `/electoral`) names `PrimaryBand` and carries `variant === "primaries"` branches — while `ElectoralBoard.tsx:104` is the only variant call site and passes `"races"`. **A reference count is not reachability.** That sweep needs a probe that traces mounting from page roots and deletes bottom-up, plus the byte-identical `/electoral` render gate for unpicking the `variant` fork out of a live file. Different job, different verification regime. Don't touch any of it here.

---

## STEP 0 — read-only diagnostic, own commit, then HALT

Create `scripts/diagnostic/primary-for-race-576.ts`. Read-only: no writes, no migration, no changes to `lib/queries.ts`.

### The bug, confirmed at HEAD

`lib/queries.ts:1535-1537` builds the row id by string reconstruction:

```ts
const id = district
  ? `house-${state}-${district}-2026-${party}`
  : `senate-${state}-2026-${party}`;
```

Special-primary rows are written by `lib/primaries-sync.ts:511` as `` `senate-${abbr}-2026-special-${contest}` ``. The reconstructed key structurally cannot match them, so SC's Aug 11 special is invisible and the chip still shows June 9. There is at least one more id shape the reconstruction misses: `primaries-sync.ts:344` writes `` `senate-${state}-2026-open` `` for non-partisan/top-two states, which a `party`-keyed reconstruction also can't reach.

### The design question STEP 0 must answer, not assume

Read `app/members/[bioguideId]/page.tsx:220-225` before writing any SQL. The caller passes `district = null` **for every member, House and Senate alike**, and the comment says why: *"The chip shows for House and Senate members alike: every state's primary date sits on the senate-prefixed calendar row."* That's deliberate — House members read the statewide senate row as a proxy for their own primary date, because the two share a date in most states.

So "prefer the soonest future contest" is ambiguous the moment a state has a special:

- For **SC's senators**, the Aug 11 special primary genuinely is the next primary.
- For an **SC House member**, that special is a Senate contest they aren't in. Showing them Aug 11 would be *newly wrong* in a way today's June 9 isn't.

**Do not resolve this in the diagnostic.** Measure it and put it in front of the HALT.

### Measurements

- **M1 — today's coverage.** For every current member with `party` in (D, R), call the existing `getPrimaryForRace(state, null, party)`. Bucket: row returned vs `null`.
- **M2 — why the nulls.** For each null, classify against the `primaries` table: (a) no row for that state at all; (b) only `-special-` rows; (c) only an `-open` row; (d) a row exists under some other id shape — name it.
- **M3 — the delta.** Run the proposed structured query alongside (state + party + `election_round = 'primary'`, preferring the soonest `primary_date >= today`, falling back to the most recent past) and bucket every member: unchanged · newly populated (was null) · **date changed**. For the date-changed bucket, list state, chamber, old date, new date. This bucket is the whole risk of the HO.
- **M4 — the SC case, concretely.** Confirm `senate-SC-2026-special-R` / `-D` exist, print their `primary_date` and `election_round`, print what the member hub shows today for both SC senators and for two SC House members, and print what each would show after.
- **M5 — cost.** Cold latency of the new query shape vs the current point-lookup. The current one is a primary-key hit; the replacement filters and sorts, so it will be slower. Measure how much and say whether an index is wanted (**don't add one** — that's a build decision for after the HALT).

Also report: does any other caller exist? The planning check found exactly one (`page.tsx:225`). Confirm.

Commit the diagnostic on its own: `chore(diagnostic): HO 576 STEP 0 — getPrimaryForRace coverage + soonest-future delta`

### HALT

Report M1–M5 and **stop**. Do not write the fix. The HALT exists to take the House-vs-special decision on evidence, and the shape of M3 may change what the fix should be.

---

## After approval — the build (do not start it now)

Recorded here so the diagnostic is aimed correctly, not as authorisation.

- Replace the id reconstruction with a query over the structured columns already selected by `PRIMARY_SELECT` (`p.state`, `p.district`, `p.chamber`, `p.party`, `p.primary_date`, `p.race_id`, `p.election_round`). Keep `PRIMARY_SELECT` and `rowToPrimary` — no new row shape, no new type.
- Ordering: soonest future first, most recent past as fallback, so a member whose primary has already happened keeps a chip instead of losing one. Losing the chip post-primary would be a regression the current code doesn't have.
- `election_round = 'primary'` must stay in the filter or a runoff row can win the sort (HO 107 rows live in the same table; `getRunoffsForRace` is the only thing that should see them).
- **Do not make the query chamber-aware without an explicit decision at the HALT.** Filtering `chamber = 'house'` for House members would empty most House chips, because the rows they read today are senate rows by design.
- **Do not change the caller's signature or its `district = null` argument** as part of a "cleanup." That argument is load-bearing and documented.

## Scope guards

1. STEP 0 is read-only and lands as its own commit, separate from any build commit.
2. No schema change, no migration, no index — even if M5 wants one, that's a post-HALT decision.
3. No `lib/primaries-sync.ts` edits. The id shapes are what they are; this HO reads them, it doesn't renegotiate them.
4. No touching `getRunoffsForRace`, `getUpcomingPrimaries`, `getPastPrimaries`, `/primaries`, `/electoral`, or anything in the deferred orphan-sweep list.
5. No docs, no `SKILL.md`.
6. Explicit pathspec staging. Never `git add .`.

## Verification (STEP 0 only)

- `npm run typecheck` clean.
- The diagnostic runs to completion against prod Turso and prints M1–M5.
- It must be **provably read-only**: no `INSERT`/`UPDATE`/`DELETE`/`CREATE` anywhere in the file. State that you checked.

## Ship report

- M1–M5 as specified, with the M3 date-changed list in full rather than a count.
- Your read on the House-vs-special question, with the SC numbers from M4 as the concrete case.
- Confirmation that `page.tsx:225` is the only caller.
- M5's latency figures and whether you'd want an index, stated as a recommendation for the HALT.
- Anything else found — file it, don't fix it.
