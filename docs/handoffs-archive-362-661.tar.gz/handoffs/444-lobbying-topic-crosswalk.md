# HO 444 — CBT-topic crosswalk on `/lobbying`

Closes the last banked LDA item from the HO 437 block. HO 437 banked four LDA surfaces off the HO 435 data layer: bill-keyed lobbying (→ 439–440), the top-firms leaderboard (→ 442), and the CBT-topic crosswalk. This is the crosswalk.

Ground-truth anchor: I cloned live at the start of this session. HEAD is `2c23d3e` (`docs(sweep): reconcile the top-firms leaderboard (HO 443, closes 442)`). The roadmap pointer runs through HO 442; 443 was the doc sweep. This is 444. If your on-disk filename says otherwise, the roadmap wins — label it 444.

Re-grep every line number below at write time; treat them as approximate (they're from the `2c23d3e` clone).

## The call: build, not probe

Every prior `lda_*` surface got a cold-latency probe first (434→435, 439→440) because it introduced a new cold query. This one doesn't. `computeTopicCrosswalk` is a **fourth in-memory consumer of the shared `readLdaTables` pass** — same pattern as `computeTopFirms` (HO 442), which skipped the probe for exactly this reason. `readLdaTables` already loads `uuidsByCode` (Map<issue_code, Set<filing_uuid>>), `codesByUuid`, `activityCountByCode`, and the `filings` map. The crosswalk re-buckets that already-loaded data through a static `issue_code → topic` map. No new table read, no request-time aggregate. So no probe — go straight to the build.

## The call: `/lobbying` section, not a topic hub

I checked: there's **no topic entity/hub route** (no `app/topic/`). Topics surface only as a filter/facet (bills filter, dashboard distribution, `/trends`). So "cross-link lobbying onto a topic page" has no home — it would require building a topic hub first, which isn't this banked item. The self-contained version is a **section on `/lobbying`** that expresses the corpus in CBT's 24-topic vocabulary.

This does **not** reopen the HO 437/442 "native labels, not crosswalked" decision. That decision was: don't *replace* the native `general_issue_code` issue bars with lossy crosswalked ones. A separate, clearly-labeled parallel section is additive. Its payoff is comparability — it's the first time LDA activity is expressed in the same 24-topic units as the dashboard's bill-topic distribution, so "what's lobbied" and "what's legislated" can finally be read side by side in one vocabulary. Keep the native issue bars exactly as they are; the topic view sits alongside them, and the lossiness is disclosed by having both.

## Work items

### 1. The mapping — `LDA_ISSUE_TO_TOPIC` (this is the judgment work; put it in the plan)

Author a static `Record<string, Topic>` from LDA's `general_issue_code` values to CBT's `Topic` union (`ALLOWED_TOPICS` in `lib/enums.ts` — 24 topics, `"other"` is one of them).

Method, in order:
1. Enumerate the real input domain from the data — don't map the theoretical LDA list, map what's actually in the corpus: `SELECT DISTINCT general_issue_code, general_issue_code_display FROM lda_activities WHERE general_issue_code IS NOT NULL ORDER BY general_issue_code`. (This is domain reconnaissance for authoring a lookup, not a latency probe — no GO/NO-GO gate hangs on it.)
2. Map the confident codes (TAX→`taxes`, HCR→`healthcare`, DEF→`defense`, BUD→`budget`, TRD→`trade`, ENV→`environment`, ENG→`energy`, IMM→`immigration`, EDU→`education`, LBR→`labor`, and so on).
3. Route the genuinely ambiguous ones to `"other"` rather than forcing a bad fit — mirror the "comprehension over coverage" philosophy already stated in the `TOPIC_ALIASES` comment in `enums.ts`. Every code maps to *something* (confident topic or `other`), so nothing silently drops. Document the debatable calls inline (the LDA codes with no clean CBT home — Torts, Media, Advertising, Gaming, Postal, etc. — write a one-line comment on each explaining the routing).

Location: `lib/enums.ts` alongside `ALLOWED_TOPICS`/`TOPIC_ALIASES` if it stays a hand-authored constant, or `data/lda-issue-topic-map.json` if you'd rather keep it out of code (there's precedent for `data/` override files — `fec-candidate-overrides.json`). Your call; state it in the plan.

**The full proposed map goes in your plan for Corey to review before you build the rollup on top of it.** The mapping is the one place human judgment matters here, and it fits the spec-driven rule — the map *is* the plan's substance. Don't commit it until the map is approved.

### 2. `computeTopicCrosswalk(tables, generatedAt)` — the fourth consumer

Add to `lib/lda-rollup.ts`, right after `computeTopFirms` (~L512). Signature and shape parallel to `computeTopFirms`: takes the `LdaTables` from `readLdaTables`, returns a self-contained blob with its own `generatedAt`.

Semantics — read carefully, the multi-code property matters:
- A filing carries multiple `general_issue_code`s (`codesByUuid` is a `code[]`). So a filing can land in **multiple topic buckets** (TAX+HCR → both `taxes` and `healthcare`), exactly as it already appears under multiple issue bars.
- Build each topic's filing set by **unioning the `uuidsByCode` sets** for every code that maps to that topic. Dedupe within a topic (a filing citing two codes that both map to `healthcare` counts once for `healthcare`).
- Per topic: `filings` (= |union set|), `activities` (sum `activityCountByCode` over the topic's codes), optionally `distinctClients` (union client names over the topic's uuid set — cheap, nice-to-have).
- **Filings summed across topics will exceed `stats.filings`** (multi-code filings double-count across topics) — same property the issue bars already have. This is not a partition. The section copy must not imply the buckets sum to the corpus total; label it "by issue focus" / "topics lobbied," not "share of filings."

Return `{ generatedAt, topics: { topic, label, filings, activities, distinctClients? }[] }`, sorted by `filings` desc. Include `other` in the array (it'll sort naturally by its count).

### 3. The blob + reader

Fourth `dashboard_state` blob, key `lda_topic_crosswalk` (add `LDA_TOPIC_CROSSWALK_KEY` next to `LDA_TOP_FIRMS_KEY`).

- **Cron**: `app/api/cron/lda/route.ts` — the block at ~L108–112 already computes issue/bill/firms off the one `readLdaTables` pass. Add the fourth compute + write in the same budget-gated block, under the same single `revalidateTag("lda")`. It rides the ~96s pass already running; no new cron slot, no new budget.
- **CLI mirror**: `scripts/rollup-lda.ts` ~L31–35 mirrors all three blobs so a local `npm run lda:rollup` regenerates everything. Add the fourth so local regen writes all four.
- **Reader**: `getTopicCrosswalk()` in `lib/queries.ts`, mirror `getTopFirms` (~L2691) exactly — `unstable_cache`, `SELECT value FROM dashboard_state WHERE key = ?`, null before the first rollup lands (→ section omitted), tag `["lda"]`, 3600 TTL. Separate key keeps the small blob the only thing this section reads (the HO 440/442 lean-read rationale).

### 4. The surface — `TopicCrosswalk` section on `/lobbying`

`app/lobbying/page.tsx`. Add `getTopicCrosswalk()` to the existing `Promise.all` (~L45). Place the new section **right after Section 2** (the issue bars two-column) so the two taxonomic lenses are adjacent — native `general_issue_code` bars, then the same corpus in CBT topics. That pushes top-firms to Section 4 and the feed to Section 5 (comment-label renumber only).

Render: ranked bars mirroring the issue bars, but **topic-colored and topic-labeled** via `topicColor()` / `topicLabel()` from `lib/topic-colors.ts` (this is the topic lens, so use CBT's topic color/abbrev system, not the issue-bar styling). One row per topic, sorted desc, `other` included. Null blob → omit the section cleanly (match `getTopFirms`). Non-interactive in v1 — there's no topic-keyed drill to click into (the per-code drill is issue-code-keyed). A click-through (topic → its constituent issue codes → their existing drills) is a clean v2; note it, don't build it.

Mobile: if any column would overflow below ~640px, collapse it with Tailwind — no `globals.css` coupling (the HO 442 rule; a concurrent session is holding `globals.css`, see process notes).

## Invariants / verification

- `computeTopicCrosswalk` covers every distinct code: assert 0 codes in `uuidsByCode` are absent from the map (with `other` as the catch-all, this should be structurally 0 — the assert guards against a new code appearing in a future corpus).
- Corpus consistency: the crosswalk reads the same `readLdaTables` filings map as the issue rollup, so `stats.filings` and the crosswalk's underlying corpus are the same object — no masthead incoherence (the HO 442 guarantee carries).
- Prod-verify after deploy: `/lobbying` renders the new section with topic-colored bars; the pre-first-rollup path omits it cleanly (confirm null → no section, no 500); spot-check that a known code lands in the expected topic (TAX filings show up under `taxes`).

## Process

- **Spec-driven, plan first.** Propose the plan — including the full `LDA_ISSUE_TO_TOPIC` map — and wait for Corey's review. Show diffs. No auto-commit, no push, no destructive git until the diff is approved.
- **Two commits**, matching the HO 442 split (`b64e1c7` data + `69644fd` surface): commit 1 = mapping + `computeTopicCrosswalk` + cron/CLI blob write + reader; commit 2 = the `/lobbying` section. Keeps the data layer landing independently of the surface.
- **Push discipline.** Immediately-before-push ancestry eyeball: one commit riding, clean fast-forward, nothing behind. Stage by **explicit pathspec** — a concurrent session is live and holding `components/RaceCard.tsx`, `components/CompetitiveRacesBlock.tsx`, and `app/globals.css` as modified. Do **not** `git add -A`; do not touch those three files; do not force-push (their next push expects `2c23d3e`-descended history to fast-forward).
- **No doc sweep in this handoff.** The roadmap/backlog/SKILL reconciliation is the *next* handoff (445), same as 442→443. Land the feature here; sweep after.

read docs/handoffs/444-lobbying-topic-crosswalk.md and follow it
