# HO 407 — Weekly-report cron: the fix

> Confirm the next free number before saving: `ls docs/handoffs/ | sort -V | tail`. Body assumes 407. HEAD after HO 406 (summarize fix).
>
> This is a **code fix, possibly + one index**, so it runs spec-driven: read the gate first, HALT with the verdict, propose the exact fix for the mode you find, **wait for my review, show diffs, never auto-commit.** HALT again before any migration and before any deploy.
>
> Runs independently of HO 406 (separate cron, separate path). **One collision to watch:** if the gate lands you on the cold-stall fix, the index goes into `scripts/migrate.ts` `statements[]` — the same file HO 406 edits. If 406 is in flight, re-check ancestry immediately before push; disjoint edits carry, but two sessions in that file in the same window is the hazard.

## What HO 404 saw (the input — don't re-derive the history)

The weekly-report cron has been **erroring since Mon Jun 29, reports ~2 weeks stale**. This is a regression: the surface was fixed twice already and has come back.

- **HO 141** lowered `thinkingBudget` so `generateWeeklyReport()` fits inside the 60s function (was 88s at 8192). Post-141 gen runs ~15–29s. The Monday cron *can* produce a row.
- **HO 285** added `runReportCatchup()` in `lib/report-generation.ts` — a daily safety net that inspects the last ~4 completed weeks and regenerates the most-recent missing one (idempotent, one gen/run, non-fatal). It was wired into `/api/sync`. **Code flagged a placement deviation at ship**: `/api/sync` already ran 33–55s and soft-timed-out ~1 day in 5, so a gen appended after the heavy sync work wouldn't fit under the 55s soft cap on the gap days it must run. Where it ended up is not in my notes — the gate confirms it.
- **HO 314** gave the markets cron a Vercel daily floor because GitHub-Actions-delivered ticks land only ~80% of the time.

So a report is missing *and the catch-up that exists to backfill it is not landing*. The fix is whatever restores the catch-up as a reliable backstop; the Monday cron staying flaky is tolerable if the net catches.

## The gate — which mechanism regressed (read-only, HALT before any fix)

HO 284 already mapped this cron's failure taxonomy (Turso cold-stall via `boundedFetch` 10+10 · Gemini 503 · slow-gen >55s). This is not a from-scratch diagnosis — it's confirming **which known mode came back, and why the HO 285 catch-up isn't absorbing it.** Three candidates, divergent fixes. Read all of §A–§D, then HALT with the verdict.

**§A — did the crons even fire?** Pull the last ~10 `cron_runs` rows each for `/api/cron/weekly-report` and `/api/sync` since Jun 25 — `status` + `elapsed_ms` + `error_message`, verbatim.
- If the **Monday `/api/cron/weekly-report` rows are absent** on the failing Mondays (not present-and-failed, but missing) → **delivery drop** (HO 314 class). The GitHub-Actions tick isn't landing.
- If `/api/sync` rows are present but **soft-timing-out (504 / `status='timeout'`) more often than the HO 285 1-in-5 baseline** → the catch-up is being **cut off** before it runs (or before its gen completes).

**§B — is the catch-up still wired, and where?** Grep `runReportCatchup` — confirm it's still called, from which route, and **at what point in that route** (before or after the heavy sync/lead/trades work). This resolves the HO 285 placement deviation. A catch-up sitting *after* 40s of sync work on a route that soft-times-out is a catch-up that runs on maybe half its intended days.

**§C — does gen itself stall when attempted?** The HO 285 §27 banked suspect: *one of `gatherReportData()`'s ~10 queries may be a mis-planning aggregate of the HO 238/280 family* — the **exact corpus-scaling pattern HO 406 just fixed** for the summarize read (a query that was a transient stall at a smaller corpus and is now a permanent stall at 16k+). Confirm or clear it:
- Time `gatherReportData()` cold (first call from idle) — is it the ~2–5s HO 141 assumed, or has a query blown out?
- **`EXPLAIN` every query in `gatherReportData()`.** Report each plan. Flag any `SCAN bills` / non-COVERING `USING INDEX` over the fat table — that's a misplanner that cold-aborts at the 10s `DB_REQUEST_TIMEOUT_MS` and takes the whole gen (Monday *and* catch-up) down every time, which is exactly the "catch-up regenerates daily and never lands" symptom.
- Time one full gen cold (`generateWeeklyReport` for a known-missing week). Confirm current gen time against the ~15–29s post-141 figure — if it's back near the 55s wall, `thinkingBudget` regressed or the report grew.
- Separate Gemini failures from DB failures in the `error_message` text: a ~20s LLM abort or a 503 is a *transient* mode the catch-up is designed to survive by retrying daily; a **permanent cold-stall in gatherReportData is not**, and needs the query bound.

**§D — reuse the existing harness.** `scripts/diagnostic/report-cron-probe-284.ts` is in the repo — drive it to confirm state rather than re-inventing the reads. Add temporary instrumentation only if needed, and commit it alone so it's revertible.

**HALT.** Report §A–§C verbatim + your one-line verdict on the dominant mechanism, and the matching fix from below. Wait for review before touching anything.

## The fix — forks by the gate's verdict

Pick the branch the gate lands on. If two are live (e.g. a cut-off catch-up *and* a cold-stall in gen), fix both — they compound.

**Fix D (delivery) — if §A shows the Monday cron isn't firing.** Mirror HO 314: add a **Vercel floor cron** for the weekly report so its landing doesn't depend on GitHub-Actions delivery. Keep the existing GitHub trigger as best-effort; the Vercel entry is the guarantee. Confirm Hobby's once-daily cron cap doesn't collide with the existing Vercel floor slots already in `vercel.json`.

**Fix B (catch-up cut off) — if §A/§B show `/api/sync` soft-timing-out before the catch-up runs.** The catch-up needs a budget that isn't consumed by sync first. Cleanest: **give it its own cron route** (the same move HO 115/117 made for summarize and news when they outgrew `/api/sync`), on a daily Vercel slot, so its 15–29s gen gets a fresh 60s window instead of the tail end of a 55s-soft-capped sync. Second option if a new slot isn't wanted: move the `runReportCatchup()` call **ahead of** the heavy sync/lead/trades work so it runs first while there's budget. Propose which in the plan — a dedicated slot is more robust and matches precedent.

**Fix C (gen cold-stall) — if §C flags a `gatherReportData` misplanner.** This is the HO 406 pattern. **`EXPLAIN`-drive the offending query to a covering-index plan**, adding an `INDEXED BY` hint and/or a partial/covering index into `scripts/migrate.ts` `statements[]` (`CREATE INDEX IF NOT EXISTS`). The stateless planner mis-plans fat-table queries without the hint, and a clean plan once doesn't guarantee cold stability on this project — so **EXPLAIN before/after and cold-time it** to confirm the plan holds from idle. The read must stop touching the full corpus. (If the misplanner is a `GROUP BY` + `json_each` shape, note it — that combination re-plans even on previously-hinted queries.) `ANALYZE`/`VACUUM` are blocked on hosted Turso, so an index + hint is the only lever; don't reach for stats.
- If §C instead shows a **Gemini transient** (503 / ~20s abort) as the dominant killer *and* the catch-up is confirmed running: the catch-up's daily retry is the intended defense, so the residual fix is tightening the HO 160 retry ladder (retry on 503 *and* timeout, bounded attempts, backoff that still fits the window). But confirm the catch-up is actually landing on *some* days first — if it never lands, the problem is B or C, not the retry ladder.

## Catch-up hardening (do regardless of branch)

Whatever the mechanism, the HO 285 net demonstrably has a hole. Two cheap guards, if not already present:
- **Make the catch-up's failure visible.** If `runReportCatchup()` swallows its own errors as non-fatal (it was wired non-fatal by design), confirm the failure still writes *something* to `cron_runs` or logs — a silent daily failure is why this sat undetected for two weeks. It should be diagnosable next time without a full audit.
- **Confirm the window covers the gap.** The catch-up looks back ~4 weeks and fills the *most recent* missing one per run. With ~2 weeks stale, confirm a multi-week gap actually fills over consecutive days rather than thrashing on the same week — and that the ~4-week lookback is wide enough for the current gap.

## Verification (before reporting shipped)

- The matching fix applied; if an index was added, `EXPLAIN` shows a bounded/covering plan **cold**, not the corpus scan.
- Trigger the daily route (or the new catch-up route) once and confirm it **regenerates a missing week** — its `reports` row appears, and the `/reports` index + dashboard READ FULL pick it up (HO 312 confirmed the write path revalidates `reports`). If a gen flakes on a transient, it lands on a later run since the row stays missing.
- Idempotency intact: an already-present report is not regenerated.
- The host route stays under its `maxDuration` with the gen included.
- `npm run verify:deploy` — served SHA (`/api/version` → `VERCEL_GIT_COMMIT_SHA`) === pushed HEAD. **Shipped means deployed AND live-verified**, not pushed.
- Report in the ship note: which mechanism the gate found, which fix branch shipped, and whether the stale weeks backfilled.

## Non-goals

- **No schedule change beyond a reliability floor, no Pro upgrade.** A Vercel floor cron (Fix D/B) is adding a *guarantee*, not widening the tier.
- **Don't touch the report's content** — sections, ordering, prompt vocabulary (HO 110/112) and the `thinkingBudget` value (HO 141) stay, unless §C proves gen time regressed past the wall, in which case flag it as its own finding rather than silently re-tuning.
- **Don't touch the summarize cron** (HO 406's lane) except for the shared-`migrate.ts` ancestry check noted up top.
- **Don't chase every transient.** The catch-up's job is to absorb the occasional 503/abort by retrying; the fix here is restoring the net (delivery, budget, or the permanent cold-stall), not eliminating every flake.

## Files (depends on branch — confirm in the plan)

- `lib/report-generation.ts` — `runReportCatchup()` placement (Fix B option 2); catch-up failure-visibility guard.
- `app/api/cron/weekly-report-catchup/route.ts` (or similar) — **new**, only if Fix B takes the dedicated-slot path.
- `vercel.json` — Vercel floor cron entry (Fix D, or Fix B dedicated slot).
- `scripts/migrate.ts` — index into `statements[]`, `IF NOT EXISTS` (Fix C only). **Shared with HO 406 — ancestry-check before push.**
- `app/api/sync/route.ts` — only if Fix B moves the catch-up call within it.
- `.claude/skills/cbt/SKILL.md` — cron-topology note, only if the topology actually changes (a new route/slot); it trips its self-mod guard, so re-approve rather than route around. Docs-only, separate commit.

## Rollback

Per branch: drop the added index (Fix C) / remove the new cron route + `vercel.json` entry (Fix B/D) / revert the `runReportCatchup` placement change. Each is additive and independently revertible; nothing else is touched.
