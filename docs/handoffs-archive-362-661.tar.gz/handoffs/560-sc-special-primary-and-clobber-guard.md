# HO 560 — the SC Aug 11 special primary + the settled-row clobber guard

HO 559 M5(b) found the Aug 11 SC special primary absent, with `senate-SC-2026-{D,R}` still holding the superseded June 9 regular and its results. Reading the sync path makes the problem larger than a missing row, and dated.

**The hazard, stated precisely.** `syncSenateCandidates` (`lib/primaries-sync.ts` ~L402) scrapes one Ballotpedia page per state and then **unconditionally delete-rebuilds** `senate-{ST}-2026-{D,R,open}`. It never reads what contest the page's votebox describes. Ballotpedia's SC 2026 Senate page will be rebuilt around the special election, because the special IS now the contest for that seat. The next SC unit visit therefore overwrites June's roster and shares with the August field. Meanwhile `syncCalendar` (~L304) writes only 270toWin's **state-uniform** calendar date, which is the June regular, so `primary_date` stays `2026-06-09`. The end state is a row dated June 9 carrying August candidates, with June's results gone and nothing anywhere recording that a substitution happened.

That is a silent data-loss path, it is not SC-specific in mechanism, and HO 559 M4 measured the cursor cycle at 44.6 days, so it fires on its own schedule with no further prompting.

This HO ships the seed and the guard. Both are additive; neither is a redesign of the primaries pillar.

## §0 — Preconditions

1. `git fetch && git status` clean, `main` even with `origin/main`, `git rev-parse HEAD` = `6db8fd0`.
2. `npm run typecheck` clean before you touch anything.
3. Read: `scripts/seed-runoffs.ts` **end to end** (it is the precedent this build copies), `lib/primaries-sync.ts` `syncCalendar` + `syncSenateCandidates`, `scripts/reingest-primary-slate.ts` (the manual escape hatch the guard leans on), `getPrimaryForRace` / `getPrimaryCalendar` / `getRunoffsForRace` in `lib/queries.ts` (~L1529–1612), and the `election_round` column note in `scripts/migrate.ts` ~L1230.

## §1 — STEP 0 (read-only, inline, no separate HO)

Four questions. Print them, then proceed unless one HALTs.

**S1 — what does Ballotpedia's SC Senate page render today?** Fetch the page `scrapeSenateCandidates("SC", "South_Carolina")` targets and report which contest its votebox describes: the June regular (with results), the August special (roster, probably no shares yet), or both. **This decides urgency.** If it already shows the special, the clobber is one SC unit visit away and the guard is the priority commit.

**S2 — the 270toWin entry for SC.** From `scrapeStatePrimaryCalendar()`, print SC's `primaryDate` / `runoffDate` / `primaryType`. Expected: June 9, confirming the calendar pass structurally cannot produce Aug 11 (it lists one state-uniform date). If it has moved to Aug 11, **HALT** and report, because then `syncCalendar` is about to rewrite the date on the result-bearing rows and the guard has to cover the calendar path too, which this HO does not scope.

**S3 — freeze-predicate blast radius.** Count `primaries` rows where `election_round='primary' AND primary_date < date('now')` that have at least one `primary_candidates.vote_pct IS NOT NULL`. Expect ~431 (HO 559 M2). Split senate vs house. This is the population C2 stops rewriting.

**S4 — id-keyed consumers.** Confirm by grep that `getPrimaryForRace` is the only reader that reconstructs a `senate-{ST}-2026-{party}` id literally rather than querying by state/date, and name its call sites. A seeded row with a new id is invisible to id-keyed readers, and §3 rules on that deliberately.

## §2 — Build

### C1 — seed the special (`seed:special-primaries`)

Copy the `seed-runoffs.ts` shape, do not extend that script: a runoff and a special primary are different contests and globbing both from one loader would put two unrelated seed vocabularies in one file.

- `scripts/seed-special-primaries.ts`, globbing `data/special-primary-seeds/*.json`, idempotent: `primaries` upserts on PK, `primary_candidates` delete-then-insert per `primary_id`. Wire `seed:special-primaries` into `package.json` next to `seed:runoffs`.
- `data/special-primary-seeds/sc-2026-senate.json`: `id` **`senate-SC-2026-special-{D,R}`**, `state: "SC"`, `chamber: "senate"`, `district: null`, `primary_date: "2026-08-11"`, `runoff_date: "2026-08-25"`, `race_id: "S-SC-2026"`, `primary_type: null`.
- **`election_round` is `'primary'`, not a new value.** A new round string would render nowhere: `getPrimaryCalendar` and both feed queries filter to `'primary'`, `getRunoffsForRace` to `'runoff'`, and teaching every consumer a third vocabulary to display one contest is the wrong trade. As a `'primary'` row it flows into `getPrimaryCalendar` → `PrimaryTimeline` automatically, and it appears as a new Aug 11 date tick rather than mutating the June one.
- **The June rows are not touched.** The new id is outside the `senate-SC-2026-{party}` set `syncCalendar` and `syncSenateCandidates` write, so the special rows are also immune to both passes by construction.
- **Roster: source it, do not invent it.** Pull the declared candidates from the Ballotpedia SC special page. If the field is not yet published, **seed the rows with an empty `candidates` array** and say so in the report. A dated contest with no roster is correct and renders as a scheduled tick; fabricated names are not recoverable from later.

### C2 — the settled-row clobber guard

In `syncSenateCandidates`, before the per-contest `DELETE FROM primary_candidates`, skip the rewrite when the target row is **settled**: `primary_date < today` **AND** the row already has at least one `vote_pct IS NOT NULL`. Count skips and surface them in `SenateSyncSummary` (a `settledSkipped: string[]` of primary ids) so the cron payload shows it.

The predicate is chosen so it does not undo the re-poll HO 559 confirmed:

- Past-dated rows **with no shares** stay open, which is exactly the mid-count / late-ingest population the banked re-poll item cared about (HO 559 M2: 38 rows, none older than 90 days).
- Future-dated rows stay open, so roster churn before election day keeps flowing.
- Only **settled** rows freeze, and the cost of freezing them is losing upstream corrections to results already stored. `scripts/reingest-primary-slate.ts` is the deliberate escape hatch for that, already built and already the documented workflow (HO 341 / the CA reingest).

**Senate only in this HO.** `syncHouseDistricts` carries the identical hazard on 435 units, but the House path has its own roster-matching layer and HO 559 M2 put 177 of the 181 gap there, so widening the predicate to it belongs with the zero-candidate investigation rather than riding a SC fix. Name it in the report as the follow-on.

### C3 — cadence

`vercel.json`, `/api/cron/primaries` `0 12 * * *` → `0 0,12 * * *`. HO 559 M4 measured 44.6 days per cycle against a ~6-week ask; twice-daily takes it to roughly 22 with no new code and no change to per-tick load (the slice constants and the 50s deadline are untouched, so Ballotpedia sees the same 12-district burst, just twice a day). Own commit. Do **not** touch `CRON_HOUSE_SLICE`, `CRON_SENATE_SLICE`, or `DEADLINE_MS`.

## §3 — Decisions taken, so they are not re-litigated

1. **The member-hub primary chip will keep showing June 9 for SC.** `getPrimaryForRace` reconstructs the id literally, so it cannot see `-special-`. Teaching it to prefer the soonest future contest for a state is a real improvement and a real behavior change on every state, and it is not worth coupling to a dated fix. Record it as a follow-on, do not build it here.
2. **No `results_final` column, no migration.** The date-plus-shares predicate is derivable from what is stored.
3. **No retro-repair of the June rows.** They are correct today. The guard's whole job is keeping them that way.
4. **No new nav, surface, component, or query.** The special renders through `PrimaryTimeline` via the existing calendar query.

## §4 — Scope guards

1. No edits to `syncCalendar`, `syncHouseDistricts`, `rematchHouseCandidates`, or the scrape parsers.
2. No edits to `seed-runoffs.ts` or `data/runoff-seeds/`.
3. No `election_round` vocabulary change and no `migrate.ts` change.
4. No component or page edits at all. If C1 lands and nothing renders, report it rather than adding a surface.
5. No change to the cursor, slice constants, or deadline (C3 is a schedule line only).
6. Do not delete the HO 559 orphans. That sweep is its own HO.

## §5 — Commits, ref, gates

1. `diag: HO 560 STEP 0 — SC senate page contest + freeze-predicate blast radius (read-only)` if S1–S4 warrant a committed script; a reported-only STEP 0 is acceptable here given the clock, but say which you did.
2. `feat(primaries): HO 560 C1 — seed the SC Aug 11 special primary` (script + seed JSON + `package.json`).
3. `feat(primaries): HO 560 C2 — freeze settled primary rows against scrape clobber`.
4. `chore: HO 560 C3 — primaries cron to twice daily`.
5. Push to `git push origin HEAD:refs/heads/560-review`, report SHAs + the STEP 0 blocks + the seed roster provenance, **halt**. Do not paste diffs.
6. On approval: ancestry eyeball, fast-forward, delete ref.

**Verification owed in the report:** `seed:special-primaries` run twice (idempotence, second run reports the same counts); `getPrimaryCalendar(2026)` shows a new `2026-08-11` date with its contest count; the June rows byte-identical after both the seed run and a forced single-state SC senate sync (the guard's real test, and the one number that matters is that SC's June shares are still there afterwards with `settledSkipped` naming the two ids).
