# HO 370 — Doc sweep: ledger reconcile + B2/cron doc items + STATUS re-date

If `370` is already claimed (`ls docs/handoffs/ | sort -V | tail`), self-claim the next free number and rename this file.

Docs-only sweep. No code, no tsc, no build. Reconcile living docs in place — never append a "see below," edit the actual entries. The facts below were verified live in the prior session; do not re-derive them.

## Resolved facts (verified, trust these)

1. **HO 329 member-expand cold-start 500 is FIXED.** Shipped under **HO 331, commit `46beff8`** (2026-06-23). The three sponsor helpers (`getSponsorStats`, `getSponsorTopTopics`, `getSponsorRecentBills` in `lib/queries.ts`) had the dead `OR sponsor_name = ?` branch removed (now bare `WHERE sponsor_bioguide_id = ?`), `INDEXED BY` restored (`idx_bills_sponsor_agg` for stats/recent, `idx_bills_sponsor_topics` for topics), and all three EXPLAIN to a covering/index point-lookup on live Turso. The misplan class is gone. The OPEN-LOOP entry was never reconciled and still reads "diagnosed, not applied."

2. **HO 238 prod soak closes clean.** Jun 26 re-probe (bypassing the `/welcome` redirect with `ct_seen=1` to hit the real dashboard render): 5/5 `200`, worst 2.47s, nowhere near the 10s DB abort. Consistent with the Jun 12 9/9.

3. **Markets 21:30 UTC Vercel floor is firing.** `market_ticks.ticked_at` shows a **Jun 25 21:27Z, 18-symbol full-roster tick** (SHUTDOWN, FEDCUT, recession K/P pairs, equities, WTI, TNX, CPI). The HO 314 Vercel daily floor is registered and firing post-rename (~3 min cron drift off the `30 21 * * *` schedule, normal). This also answers the chat-side "was the 21:30 cron de-registered after the domain rename" worry — no, it fired.

## Edits

### `docs/backlog.md`

OPEN LOOPS — remove these three lines, tombstone to DONE:
- Remove `Member-expand cold-start 500 — HO 329 diagnosed …`. DONE: `member-expand cold-start 500 — FIXED HO 331 (46beff8): dropped dead OR sponsor_name branch, INDEXED BY restored, covering plan on all 3 sponsor helpers.`
- Remove `Markets scheduled-fire soak — opened Jun 22 …`. DONE: `markets 21:30Z Vercel floor — CONFIRMED firing (Jun 25 21:27Z, 18-symbol full roster). Floor registered post-rename; "de-registered?" worry retired.`
- Remove `HO 238 prod soak — watch through ~Jun 16 …`. DONE: `HO 238 prod soak — CLOSED clean (Jun 26: 5/5 200s, worst 2.5s; matches Jun 12 9/9).`

OPEN LOOPS — add two:
- `HOUSE count 436 vs 435 (HO 367) — delegates + resident commissioner file under chamber='house'. Decision pending: voting-only filter on the bucket, or leave. Corey's call. Low; killable.`
- `Breaking news pipeline freshness unverified — read-only diagnostic authored in a separate session, awaiting a Code run. Close = last_ingest within ~2 days confirmed on news_mentions.`

If QUEUED or WATCH holds any placeholder for the four B2/cron doc items below ("pending doc sweep"), retire it — the content lands in the living docs in this same sweep.

### `SKILL.md` — B2 markets tape section (grep for the markets-tape / B2 block)

Reconcile to live (HO 363 + the separator reversal):
- **Separator is a pipe**, not a gap. Rendered via a trailing `::after` pseudo-element on each item (`position:absolute`, out of flow, zero effect on the `ch` width-pin or marquee geometry). Supersedes the earlier no-glyph / gap-only note. Leading `::before` was rejected because the track structure drops dividers at set boundaries.
- **Render order:** `SYM · VALUE · Δ · QUAL`. Value + delta weight 600; symbol/name step to `--accent-amber` weight 500; 2px amber left border on the pinned label cells.
- **Status cell tokens (live, these win over the HO 363 spec's named values):** STALE → `--accent-amber`, CLOSED → `--ticker-closed`.
- Gap widening scoped to `.markets-tape--scroll` only; the static dashboard-classic tape is unchanged. Label font is 9px.

### `docs/oddities.md` (grep, add two entries)

- **Strip-freshness `max()` masking.** Tape freshness reads `MAX(ticked_at)` across all symbols, so a single dead feed is invisible — one fresh symbol masks N stale ones. The real health read is per-source `MAX`. Latent trap when diagnosing "is the tape live."
- **Markets cron silent-307.** After the domain rename, `curl` in GitHub Actions stops at the 307 redirect without `-L`, so the function never runs and no tick lands. All markets curls now carry `-fsSL`. The Vercel 21:30Z daily floor is the backstop and fires independently — it was masked before because GitHub Actions had been silently carrying the load.

### `docs/roadmap.md` — STATUS block

- Re-date the header to `As of HO 370 · 2026-06-26`.
- Overall stays **~98%**.
- Reconcile the deferred-entries note: HO 364 (brand rename) and HO 366/367 (header consolidations) are within-theme polish (Home / Foundation / Member depth), minted no new bars — mark them accounted-for and drop the "deferred to a future sweep" language for those three.
- Keep the off-repo baseline re-derivation flag for Foundation and Member depth (still owed at the next full audit).

## Ship

Docs-only. Commit with an explicit pathspec naming exactly the files you actually edited (some subset of `docs/backlog.md`, `SKILL.md`, `docs/oddities.md`, `docs/roadmap.md`). Never `git add -A` — parallel sessions share the tree. Ancestry recheck before push; Corey runs the push. `npm run verify:deploy` for the SHA match after.
