# HO 402 — Member ID crosswalk (unitedstates/congress-legislators)

> Renumber if HEAD has moved past 401. Diagnostic filename tracks this number (`crosswalk-coverage-402.ts`).
>
> Supersedes the draft numbered 363, which mislabeled the `fec` array as committee IDs and claimed `members` had zero external IDs. Both corrected below (verified 2026-07-02).

Wire the `unitedstates/congress-legislators` ID crosswalk into CBT so the bioguide-keyed `members` roster gains authoritative bridges to the IDs every future cross-source join needs: FEC **candidate** IDs (money), ICPSR (Voteview ideology), Wikipedia/Ballotpedia page titles (attention), plus GovTrack, LIS, C-SPAN, Wikidata. This is plumbing, and it's the cheapest thing on the source backlog that unblocks the most downstream work, which is why it goes first.

Additive and reversible: two new tables that FK to `members`, one sync script, one diagnostic. Nothing in `members` changes. No new dependency (`js-yaml@^4.1.1` is already in `package.json`).

## Two corrections from plan review (read before implementing)

1. **The `fec` array is FEC candidate IDs, not committee IDs.** Values are `S8WA00194` / `H2WA01054` (candidate-ID format), not `C########` committee IDs. A member has several, one per office sought over a career (Cantwell's House run + Senate run). Table and index are sound; the framing "committee mapping / FEC-committee → member" was wrong and is fixed to candidate-ID throughout.
2. **`members` already carries `fec_candidate_id`** (+ `fec_resolved_at`), added via `ensureColumn` around `migrate.ts:907` and consumed by `sync-fec.ts`, which resolves that single ID by fuzzy name-match against FEC today. So the crosswalk's `fec` array is the authoritative, multi-entry version of what `members.fec_candidate_id` currently approximates. That's a real upgrade and a switch *opportunity*, not filling a void, and the switch stays a non-goal here (see non-goals).

## How to work this handoff

Standard spec-driven flow:

1. Read this file. Re-verify the source is still live (checks below are 2026-07-02) **and confirm the `members` current-flag column name — §3 assumes `is_current`; grep to be sure before writing the diagnostic query.**
2. Propose the plan: exact DDL, sync shape, match strategy, and any remaining decision. Don't write code yet.
3. Wait for my review.
4. Implement. Show diffs. Never auto-commit.
5. Run the diagnostic and paste the numbers back verbatim.

## Source (verified 2026-07-02, live)

- Repo `github.com/unitedstates/congress-legislators`, branch `main`. Live, last push 2026-06-15.
- Files: `legislators-current.yaml` (1.08 MB, 537 bioguide records) and `legislators-social-media.yaml` (105 KB).
- **YAML only** — both `.json` and `.csv` equivalents 404, there is no JSON build. Parse with the existing `js-yaml`. No new dep, no scraping.
- Fetch raw, single GET each, no pagination: `https://raw.githubusercontent.com/unitedstates/congress-legislators/main/<file>`
- Per-record `id` block (all optional except `bioguide`): `bioguide, thomas, lis, govtrack, opensecrets, votesmart, fec (ARRAY of candidate IDs), cspan, wikipedia (page title), house_history, ballotpedia (page title), maplight, icpsr, wikidata, google_entity_id, pictorial`.
- Raw fill, confirmed live 2026-07-02 (pre-gate, i.e. before matching to `members`): `fec` 536/537 and stored as an array — 65 of those members carry >1 candidate ID (career offices), which is the whole reason it's a child table; `wikipedia` 536/537 (page titles); `icpsr` 320/537 (60%, so ~six in ten members carry a Voteview key). Also well-filled if a later handoff wants them: `govtrack` and `wikidata` 100%, `ballotpedia` and `opensecrets` ~98%.

## Why now, why first

`members` is `bioguide_id PRIMARY KEY` carrying a single fuzzy-matched `fec_candidate_id` and little else. Every other cross-source join — member→DW-NOMINATE, member→Wikipedia pageviews, member→GovTrack — is a `bioguide → X` lookup that today resolves to nothing. `sync-fec.ts` and `backfill-bioguide-ids.ts` already exist, so an authoritative candidate-ID source has an immediate consumer waiting. This handoff is the ID layer those consumers assume.

## What to build

### 1. Schema — extend `scripts/migrate.ts`

Idempotent `CREATE TABLE IF NOT EXISTS`, following the `members` + join-table idiom (`affiliations`, `committee_members`).

```sql
-- HO 402: ID crosswalk from unitedstates/congress-legislators.
-- Enrichment of the existing bioguide-keyed roster; NEVER a source of new
-- members. Both tables FK to members(bioguide_id).

CREATE TABLE IF NOT EXISTS member_ids (
  bioguide_id       TEXT PRIMARY KEY REFERENCES members(bioguide_id),
  icpsr             INTEGER,
  govtrack          INTEGER,
  lis               TEXT,
  thomas            TEXT,
  cspan             INTEGER,
  votesmart         INTEGER,
  wikidata          TEXT,
  wikipedia_title   TEXT,
  ballotpedia_title TEXT,
  google_entity_id  TEXT,
  opensecrets       TEXT,
  maplight          TEXT,
  house_history     INTEGER,
  pictorial         INTEGER,
  raw_json          TEXT NOT NULL,
  fetched_at        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_member_ids_icpsr ON member_ids(icpsr);

-- `fec` is an ARRAY of FEC *candidate* IDs upstream (one member -> several IDs,
-- one per office sought over a career). Flattened into a child table so
-- candidate_id -> member reverse lookup is indexed, same reason HO 394 flattened
-- entities instead of json_extract-ing. Column is fec_candidate_id to match the
-- existing members.fec_candidate_id (single, fuzzy-resolved) it upgrades.
CREATE TABLE IF NOT EXISTS member_fec_ids (
  bioguide_id      TEXT NOT NULL REFERENCES members(bioguide_id),
  fec_candidate_id TEXT NOT NULL,
  PRIMARY KEY (bioguide_id, fec_candidate_id)
);
CREATE INDEX IF NOT EXISTS idx_member_fec_ids_cand ON member_fec_ids(fec_candidate_id);
```

**On the FK:** libSQL runs with `foreign_keys` OFF by default, so `REFERENCES members(bioguide_id)` is documentation, not an enforced constraint. The "never a source of new members" guarantee is the sync gate in §2 (load known bioguides, skip + count the rest), not the FK. Keep the gate even if the constraint looks like it has you covered — dropping it silently re-opens orphan inserts.

`member_social` is **deferred**, not built. Same source repo, different file, but every consumer is cold (X/Twitter API is paid/restricted; the Bluesky item can't use it because `bluesky` isn't tracked upstream). It's one file GET and one table away the day a consumer exists. Kept out for a tighter diff.

### 2. Sync — new `scripts/sync-crosswalk.ts`, npm script `sync:crosswalk`

Mirror `scripts/sync-members.ts` exactly: `import "dotenv/config"` first, `getDb()` from `lib/db`, per-row `INSERT ... ON CONFLICT(bioguide_id) DO UPDATE` (its idiom, no `batch()`).

```ts
// scripts/sync-crosswalk.ts
import "dotenv/config";
import { getDb } from "../lib/db";
import yaml from "js-yaml";

const RAW =
  "https://raw.githubusercontent.com/unitedstates/congress-legislators/main";

// 1. GET legislators-current.yaml, yaml.load().
// 2. Load the set of known bioguide_ids from `members` — this is the gate.
// 3. For each current-legislators record whose id.bioguide IS in members:
//      - upsert member_ids   (INSERT ... ON CONFLICT(bioguide_id) DO UPDATE SET ...)
//      - replace member_fec_ids for that bioguide: DELETE, then INSERT the whole
//        fec array (idempotent; same delete-then-insert idiom as observation_entities)
//      - raw_json = the entire id block (fidelity copy)
//    Skip and COUNT records whose bioguide is not in members (delegates,
//    resident commissioner, historical) so we never FK-violate.
// 4. Log: matched, skipped_no_member, fec_rows.
// No LLM, no per-record network. Runtime is one file GET + local parse (seconds).
```

Match reality to expect: `members` is the 119th roster (551 total / 536 current per HO 94); congress-legislators `current` is 537 and includes non-voting delegates. A handful stay unmatched in each direction. That's the diagnostic's job to surface, not an error.

Cadence: manual pair with `sync:members` (itself manual, quarterly-plus per HO 94). Run `sync:crosswalk` right after any `sync:members`. Source barely churns, so no cron in v1.

### 3. Diagnostic — `scripts/diagnostic/crosswalk-coverage-402.ts`

Read-only, follows `scripts/diagnostic/<slug>-NNN.ts`.

**Before writing the query, confirm the current-flag column on `members`.** This spec assumes `is_current`; if the live schema names it `current` / `in_office` / `active`, adjust — a wrong name throws, and match-rate-vs-current is the whole point of the diagnostic.

Print:

```
members total ............................. N
members current (is_current=1) ............ C
member_ids populated ...................... M   (M/C = match rate vs CURRENT)
  with icpsr .............................. …   <- gates the Voteview handoff
  with >=1 fec_candidate_id ............... …   <- the authoritative money bridge
  with wikipedia_title .................... …   <- gates the pageviews handoff
distinct fec_candidate_id in member_fec_ids  …   (size of the candidate bridge)
members whose members.fec_candidate_id
  appears in their crosswalk set .......... …   <- agreement: fuzzy pick is in the set
members whose members.fec_candidate_id
  is ABSENT from their crosswalk set ...... …   <- probable bad fuzzy pick; LIST these
members with NO crosswalk row ............. …   (list the bioguides)
current legislators not in members ........ …   (bioguide drift, list them)
```

Two things the split fixes:
- Match rate is computed against **current** members. The ~15 inactive members (551 vs 536) can't match by construction — congress-legislators `current` excludes them — so a flat `M/N` reads artificially low.
- The agreement/disagreement pair measures `sync-fec`'s fuzzy name-match against the authoritative set. Agreement is necessary but not sufficient for switching `sync-fec` later: the set holds every career candidate ID, and sync-fec needs the *current-office* one, so "present in the set" only confirms the fuzzy pick isn't outright wrong. Disagreement — a `members.fec_candidate_id` that isn't even in the career set — is the number to act on: those bioguides are where the current fuzzy resolution is probably wrong, so list them.

## Decision gates (report from the diagnostic)

- **Match rate vs current.** Expect high-90s. Materially lower means the bioguide sets are drifting and `sync:members` should be re-run first.
- **Candidate-bridge size + agreement.** Distinct `fec_candidate_id` count, how often the existing fuzzy `members.fec_candidate_id` agrees with the authoritative set, and — the actionable one — where it disagrees (list them). Together these size and de-risk a future `sync-fec` switch.
- **ICPSR + wikipedia_title fill.** ~60% icpsr, ~near-full wikipedia expected. Well-populated means the Voteview and Wikipedia-pageviews handoffs are cheap; 60% icpsr specifically means Voteview lands natively for six in ten members and the rest need a fallback ID or accepted partial coverage.

## Resolved in review

- Scalar columns + `raw_json` (not a JSON blob): kept, because `icpsr` and the candidate bridge are hot join keys wanting real columns and an indexed child table.
- `member_fec_ids` re-ingest: delete-then-insert per bioguide.
- `member_social`: deferred (above).
- FEC column named `fec_candidate_id` for precision and parity with `members.fec_candidate_id`.

## Non-goals

- No edits to `members`. Crosswalk is a parallel enrichment; `members` stays Congress.gov-sourced.
- **No `sync-fec` rewiring.** Switching it from the fuzzy `members.fec_candidate_id` to the authoritative array is a separate handoff — the array has all career candidate IDs and sync-fec needs the current-office one, so the switch needs office-disambiguation logic this handoff doesn't build.
- No Bluesky handles — upstream doesn't carry them.
- No historical roster (`legislators-historical.yaml`). Current members only for v1.
- No `member_social` in v1. No new dependency.

## Files touched

- New: `scripts/sync-crosswalk.ts`, `scripts/diagnostic/crosswalk-coverage-402.ts`.
- Edited: `scripts/migrate.ts` (two tables), `package.json` (`sync:crosswalk` script).
- Read-through: `lib/db.ts` (`getDb`), `scripts/sync-members.ts` (idiom to mirror).

## Rollback

Drop `member_ids` and `member_fec_ids`; delete `scripts/sync-crosswalk.ts`, the diagnostic, and the `sync:crosswalk` script line. `members` and every other table are untouched throughout.
