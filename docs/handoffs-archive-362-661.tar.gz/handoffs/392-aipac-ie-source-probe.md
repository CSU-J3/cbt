# HO 392 — Source probe: pro-Israel PAC independent expenditures via FEC (Schedule E)

Confirm the next free number before saving: `ls docs/handoffs/ | sort -V | tail`. Body assumes 392.

## What this is

Read-only feasibility probe. Go/no-go before scoping a build that surfaces pro-Israel PAC independent-expenditure spending (for and against candidates) on race cards and, secondarily, member hubs — sourced directly from FEC, not from trackaipac.com.

trackaipac is an advocacy PAC (Citizens Against AIPAC Corruption) running on Squarespace with no API; its own footer says the data is "compiled via fec.gov." We pull the same numbers from the primary source we already have wired, attribute to FEC, and use trackaipac only as a reference for the committee set and a sanity-check on totals.

No code changes, no schema, no commits. A throwaway probe script is fine — delete it after. Report findings in chat and stop; the build gets scoped separately once this returns.

## Resolved premises (don't re-derive)

- **FEC-from-Vercel is already proven.** The Schedule A donor-mix pipeline (`member_fundraising` `by_size`) runs on prod, so FEC via api.data.gov works from deployment egress. This probe runs locally against live FEC; no egress check needed for connectivity. (Unlike FRED's `fredgraph.csv`, cloud-IP-blocked from Vercel — not a concern here.)
- **Anchor spender:** United Democracy Project (UDP) is AIPAC's super PAC and the dominant IE spender in Democratic primaries. It reports independent expenditures on FEC Schedule E, tagging the target candidate and a support/oppose flag. DMFI (Democratic Majority for Israel) and the AIPAC connected PAC round out the set, but some of that money is bundled direct contributions (Schedule A/B), not IEs, and won't appear on Schedule E. Confirm roles below.
- **The linkage is the crux.** The project keys members/candidates by `bioguide_id`; Schedule E keys the money by FEC `candidate_id` (the target). Whether this money can attach to the project's entities depends entirely on the existing member↔FEC mapping. Nail that down first.

## The probe (read-only)

Use the project's existing FEC client / base URL / `FEC_API_KEY` from the Schedule A donor-mix code. Don't hardcode a new base.

**1. Existing member↔FEC mapping (internal recon).** How does the donor-mix / `member_fundraising` pipeline resolve a member to FEC? Report the exact path: is an FEC `candidate_id` and/or principal `committee_id` stored per member (which table, which column), or resolved on the fly by name/state? This is the join the IE money attaches through.

**2. Committee set (FEC).** Search FEC committees for the pro-Israel IE spenders. For each, report `committee_id`, `committee_type`, `designation`, and total IE spend for the 2026 cycle:
- United Democracy Project (anchor)
- Democratic Majority for Israel / DMFI PAC
- AIPAC PAC (flag whether it's a connected/hybrid committee doing bundled contributions vs. actual Schedule E IEs)

The goal is to see who actually spends via Schedule E versus who just bundles direct money (Schedule A/B, a different and far less race-legible surface).

**3. Schedule E shape + volume (FEC).** For UDP's `committee_id`, cycle 2026, pull Schedule E. Confirm the row carries `candidate_id`, `candidate_name`, `support_oppose_indicator` (S/O), `expenditure_amount`, `expenditure_date`, and candidate `office`/`state`/`district`. Report total row count, total $, a 5-row sample, and the count of distinct target candidates.
- Also check whether `/schedules/schedule_e/by_candidate/` (the aggregate endpoint) returns pre-summed per-candidate support/oppose totals. If it does, that's the shape we'd sync — it hands us trackaipac's two numbers directly. If not, note we aggregate raw rows ourselves (sum by candidate × support_oppose).

**4. Surface relevance (does it land where we have UI).** Pull 3–5 of the races the app already tracks (the competitive / 2026 primary set) and check whether UDP + the set have Schedule E rows targeting candidates in those races. Report which tracked races show IE activity and the for/against split. If UDP's targets and our tracked races barely overlap, that's a real finding: the feature would render empty on the surface we'd build it for.

**5. Linkage verdict.** Given (1) and (3): can a UDP Schedule E `candidate_id` be resolved to the project's member/race entities using the mapping from (1), or does the build need a new FEC-candidate-id backfill across members? One-line verdict plus what that backfill would cost if needed.

## Report

A structured go/no-go:
- Committee IDs + 2026 IE totals (who spends via Schedule E, who bundles).
- Schedule E field confirmation + volume + whether the `by_candidate` aggregate exists.
- The tracked-races cross-check (which races light up, for/against).
- Linkage verdict: reuse existing mapping vs. new backfill.
- Bottom line: clean FEC pull or a slog, and what the build's first real obstacle is.

## Constraints

Read-only. No schema, no writes, no commits. Throwaway probe script, deleted after. Mind the api.data.gov rate limit shared with the Congress.gov key: this is a handful of queries, space them, not a bulk pull.
