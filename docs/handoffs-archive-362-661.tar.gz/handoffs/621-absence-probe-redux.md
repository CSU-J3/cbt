# HO 621 — Absence Watch, step 0 redux: reconcile the probe, re-run it, HALT for the ruling.

HEAD `ba03e51`. Pointer "run through HO 620." **Next free is 621.** The standing rule governs this session: *do not resume from the old chat that scoped this — the probe and its fresh output are the only inputs.* This HO is the probe HO; the build is 622, specced after the ruling. Probe HOs and build HOs commit separately, per convention.

**What moved under the probe since HO 588 wrote it, visible from the clone:**

1. **HO 594/595 materialized participation.** `getParticipationStrip` now reads the `member_participation` table (`queries.ts:4734`), not the live aggregate the probe copied its facts from. The probe's verbatim-copied predicates cite `queries.ts:4547-4577`, `:5834`, `:7726` — **all stale line refs, and possibly stale mechanisms.** R2's cost premise got *stronger* (a materialized read is cheaper than the shared-cache reuse the probe priced), but the copies must be re-verified, not trusted.
2. **HO 608's shell built the slot.** The left stack accommodates a band between nav and hearings, reserved-box-free per C4. The build lands into a designed home, under C1–C8 as law, `--fs` tokens, and an audit that will crawl it — none of which existed at 588.
3. **Four months of votes.** The old output's distributions, divergence sets, and threshold sweeps describe a corpus that no longer exists. Q3-into-recess attendance patterns are exactly the kind of thing that moves them.

## 1. Commit — reconcile the probe to HEAD

Before running anything, re-verify every copied fact against current `queries.ts`:

- **Population predicate + delegate carve + `PARTICIPATION_FLOOR`**: find their current homes (the materialization moved them; the floor may now live in the materializer or the reader). If only line numbers moved, update the probe's comment refs. **If the predicate changed semantically** — different floor, different carve, a population now defined by the materialized table rather than a live `HAVING` — update the probe's copies to match and **say which**, because the ruling depends on the probe's population being the strip's population.
- **The zero-roster instrument** (`vote-detail-cost-540.ts:67` lag query): confirm it still exists at that shape; the streak walk's NO-DATA rule leans on it.
- **One new question the materialization raises, answered as a comment in the probe, not as code:** does `member_participation` carry anything per-roll or windowed, or is it cumulative-only? R3 needs recency; if the materialized table is cumulative-only (expected), R3's window query remains a **new** read path and M3b's cost number is the live price of it. State it either way.

`diag(absence): HO 621 — probe facts reconciled to HEAD (HO 595 moved the participation predicates); refs and copies updated`

Typecheck, explicit pathspec, ancestry reads one, push.

## 2. Run it

`npx tsx scripts/diagnostic/absence-watch-588.ts` against prod, once. It's bounded aggregate SELECTs by design — no per-member loops — and the burn context is now understood (event-shaped, cheap baseline), so one run is one run.

## 3. HALT — paste full output, plus the four reads the ruling turns on

The ruling (mine, next message) is R2 vs R3 vs a hybrid, and it needs these called out from the output rather than left inside it:

1. **The M1 threshold sweep** — candidate cuts for R1/R2 and *who trips at each*, by name. A front-page strip is an editorial claim about named members; the ruling reads the names, not just the counts.
2. **The M2 divergence sets** — is the sticky failure (returned member still tripping on cumulative) and the blind failure (recent-streak member invisible to cumulative) **real in the current corpus or hypothetical**? Names and counts for both sets. This is the entire R2-vs-R3 tension, and 588's answer is four months stale.
3. **M3b** — the window query's measured cost, which is R3's price tag now that R2's is near-zero.
4. **M1.4** — the floor-excluded members (invisible to any rule), so the ruling knows who the surface structurally cannot name.

No build, no `queries.ts` touch, no component, no slot work. The fixture and the audit are untouched. Output is pasted, never committed; if the probe writes any artifact, it goes under `docs/handoffs/621-artifacts/`.

## 4. After the HALT

I rule on the shape and threshold from the output; HO 622 gets the build spec — query, cache posture (the HO 533/555 serialization and convergence rules apply to whatever it returns), the strip component under C1–C8, its empty state rendering *nothing*, and its audit debut. None of that is this HO's business.
