# HO 638 — S-ME-2026 nominee replacement, and the `nominee` status the roster vocabulary is missing

## Why

The dashboard's ME Senate card shows **Janet Mills** and **Graham Platner** as the active Democratic field. Neither is the candidate. The real sequence:

- **2026-06-09** — Platner wins the Democratic primary, defeating Mills (who had already suspended her campaign).
- **2026-07-10** — Platner files formal withdrawal with Maine's division of elections, following a sexual-assault allegation.
- **2026-07-25** — Maine Democrats hold a replacement nominating convention in Bangor. **Troy Jackson**, former Maine Senate president, wins with 566 of 571 delegates and is certified before the July 27 statutory deadline.

So the card is two candidate-states behind on a tossup Senate seat that sits in the dashboard's four-card strip.

**This is not a sync failure — there is no sync.** Three separate mechanisms each independently guarantee the roster stays frozen, and all three need naming before anything is edited:

1. **`data/races-seed.json` is the only writer for this race, and it is frozen at HO 171.** The `S-ME-2026` entry still carries `Janet Mills` and `Graham Platner`, both `status: "running"`, `last_verified` 2026-06-01. HO 174 refreshed GA / PA / NJ after their May–June primaries and did not touch ME, whose primary fell on June 9 — after that handoff was written.

2. **`backfill:race-challengers` is structurally barred from this race, by design.** Its `NOT EXISTS` guard skips any race carrying a row whose `source_url` is not the `harvest:primary_winner` sentinel. ME's rows carry the Ballotpedia URL, so the harvest has never touched it and never will. That guard is correct — it exists to protect the hand-curated strip rosters — but it means the four strip races have **no automated refresh path at all**.

3. **Even with the guard lifted, the harvest could not produce the right answer.** It reads `primary_candidates` where `status = 'winner'`. For ME that row is Platner, who won and then withdrew. **Jackson was never in a primary** — he was nominated at a party convention under Maine's ballot-vacancy provision. A convention-replacement nominee has no ingestion path in this codebase.

And one mechanism that will bite during the fix if it isn't stated first:

4. **`seed:races` is insert/upsert only.** The candidate loop is `INSERT ... ON CONFLICT(race_id, name) DO UPDATE`. There is no delete. **Removing Platner and Mills from the JSON is a no-op** — their `race_candidates` rows persist and keep rendering. They must be transitioned by status, not by deletion from the seed.

## Sourcing note (per the SKILL rule)

Every fact below is from live search on 2026-08-11, not recalled. Sources:

- Convention result / delegate count: https://www.npr.org/2026/07/25/nx-s1-5902982/democrats-maine-senate-race and https://www.cnn.com/2026/07/25/politics/maine-democrats-troy-jackson-party-convention
- Withdrawal + July 27 deadline: https://www.pbs.org/newshour/politics/graham-platner-submits-notice-to-formally-withdraw-from-maine-senate-race
- Primary result: https://www.washingtonpost.com/elections/2026/06/09/maine-senate-primary-election-live-results-embattled-graham-platner-runs/
- Party process of record: https://mainedems.org/senate-race/

Ballotpedia's ME Senate page stays the seed's `source_url`; it is the canonical roster reference the other strip races already use.

## Phase 1 — Diagnostic (HALT after)

Read only. No JSON edits, no schema changes, no seed runs.

1. **Current DB state for the race.** Report:
   - `SELECT id, rating, rating_source, incumbent_bioguide_id, incumbent_running, last_verified FROM races WHERE id = 'S-ME-2026'`
   - `SELECT name, party, bioguide_id, status, source_url FROM race_candidates WHERE race_id = 'S-ME-2026'`
   - `SELECT source, rating, updated_at FROM race_ratings WHERE race_id = 'S-ME-2026'`

   The ratings read matters independently: if Cook / Sabato / Inside Elections re-rated ME after the Platner collapse and the weekly `race-ratings` cron picked it up, then ratings self-updated while the roster did not — which tells us the staleness is scoped to the hand-curated layer and not to the race row generally. If they did **not** move, say so; that is a second stale surface and a separate finding.

2. **The `won_primary` call-site census.** I count four sites that key on the string. Confirm exhaustively (grep the literal across `lib/`, `components/`, `app/`, `scripts/`) and report any I missed:
   - `lib/queries.ts` — `getRaceCandidates` `ORDER BY CASE`
   - `lib/queries.ts` — `getRaceCandidatesForCycle` `ORDER BY CASE`
   - `lib/race-matchup.ts` — `deriveMatchup`, the `won` filter
   - `components/RaceCandidates.tsx` — `statusLabel` switch

   Also confirm `RaceMapCard.tsx` and `RaceDistrictCard.tsx` key only on `withdrew` (my read) and so need no change.

3. **Where else does Platner still render?** He legitimately won the June 9 primary, so `primaries` / `primary_candidates` rows for ME are **historically correct and must not be edited**. But report whether any surface renders a primary winner as a present-tense general-election candidate — `/primaries`, the dashboard PRIMARIES tab (`getDashboardPrimaries`), the primaries map colouring, `RaceRunoffs`. If one does, it is a second instance of the same defect and gets its own line, not a silent fix here.

4. **Does anything read `races.last_verified`?** Grep it. My expectation is that it is written by `seed:races` and read by nothing. If that holds, the hand-curated layer has **no staleness instrument** — which is the project's own "state what the instrument reads if the work never happened" rule failing on a live surface. Report the answer; the backlog line in Phase 4 depends on it.

**HALT.** Report 1–4 and wait for a ruling on Phase 2 before writing anything.

## Phase 2 — Ruling required: add `nominee` to the status vocabulary

**My recommendation: yes, add it, as a distinct status handled identically to `won_primary` at every site.**

The expedient alternative is to seed Jackson as `status: "won_primary"` and ship in one commit. That renders correctly today and I am recommending against it, for the reason this project has already been bitten by twice:

- HO 577 established the defect class directly — `primary_type` is a TYPE column, not a status column, and reading it as one produced a real bug.
- HO 420 established the cost — a wrong claim written into the data was believed across multiple handoffs because nothing ever re-read it.

`won_primary` on Jackson is a false claim in a status column. It will be invisible the moment it ships, and the next reader will believe he won a primary. Meanwhile the case recurs: ballot-vacancy replacement, appointment, Louisiana's system, any future withdrawal-after-nomination.

**The synonym trap, stated so the falsification leg is not skipped.** A new status that must be handled identically everywhere fails *silently* at each missed site, and each failure looks plausible:

- missed in the `ORDER BY CASE` → falls to `ELSE 4`, sorts **below withdrawn candidates**
- missed in `statusLabel` → falls to `default:`, renders the raw string `nominee` in the drawer
- missed in `deriveMatchup`'s `won` filter → drops out of the `nominee` shape

Note the third one **cannot be caught by looking at ME today**: with Mills and Platner both withdrawn, `active.length === 1` resolves the nominee shape on its own, so `deriveMatchup` renders correctly whether or not the filter was updated. That site must be fired with a scratch third active candidate, not read.

**If the ruling is yes**, this ships as two commits, vocabulary first:

- **Commit 1 — vocabulary.** `nominee` added at all four sites, sorted at the same rank as `won_primary` (both `0`), labelled `Nominee`, included in `deriveMatchup`'s nominee-resolution filter. No data change. Each of the four sites fired individually on scratch data, reverted, `git status` clean, nothing committed from the perturbation.
- **Commit 2 — data.** The seed edit below.

**If the ruling is no**, say so and Jackson ships as `won_primary` in a single commit, with the inaccuracy recorded as an oddity rather than left unmarked.

## Phase 3 — The seed edit (only after the Phase 2 ruling)

`data/races-seed.json`, entry `S-ME-2026`. Keep `rating_source` and `source_url` as they are. The candidates array becomes:

| name | party | bioguide_id | status |
|---|---|---|---|
| Troy Jackson | D | null | `nominee` (or `won_primary` per the ruling) |
| Graham Platner | D | null | `withdrew` |
| Janet Mills | D | null | `withdrew` |

Notes on each:

- **Jackson** is not a sitting member — `bioguide_id` stays null, no member-hub link.
- **Platner and Mills stay as rows.** Removing them from the JSON does nothing (see Why §4) and deleting the rows by hand would erase the race's actual history from a surface that dims rather than hides withdrawn candidates. `withdrew` is accurate for both: Mills suspended pre-primary, Platner withdrew post-nomination.
- Do **not** touch `incumbent_bioguide_id` (Collins) or `incumbent_running`.

Then:

1. `npm run seed:races`. Report the summary line.
2. Flush both tags: `POST /api/revalidate?tag=races` and `?tag=race-ratings`, Bearer `CRON_SECRET`. Per the SKILL's `unstable_cache` note, a dev-server restart does **not** make the write visible — `getRaceCandidatesForCycle` persists in `.next/cache`. Verify via the revalidate POST.

## Verification

- Diff of `races-seed.json` shown and approved before commit. Diff of the four vocabulary sites shown and approved before commit. Separate commits, explicit pathspec staging.
- `SELECT name, party, status FROM race_candidates WHERE race_id = 'S-ME-2026'` returns exactly the three rows above.
- The dashboard ME card renders the `nominee` matchup shape — Collins (R) vs Jackson (D) — not a two-name Dem field, not a `nolead` shape.
- The race drawer lists Jackson first with the label `Nominee`, Platner and Mills below and dimmed.
- `/race/S-ME-2026` agrees with the card.
- **`deriveMatchup` fired, not read** — scratch a third active D candidate into the roster, confirm the nominee shape still resolves to Jackson rather than falling to `leader`/`nolead`, revert, tree clean.
- Prod: confirm the SHA is live via `/api/version` before scoring any read, then hit the dashboard twice. The first read may serve the pre-deploy cached value — the Data Cache survives deploys, so the **second** read is the real test.
- `npm run typecheck` clean before push.

## Phase 4 — Backlog lines (file, don't build)

1. **The hand-curated race layer has no staleness instrument.** Four strip rosters and 34 retirement entries are refreshed only when someone notices they are wrong on screen — which is exactly how this one surfaced. `races.last_verified` is written and (pending Phase 1 item 4) read by nothing, so the instrument currently reads the same whether the work happened or not. Candidate: surface `last_verified` age on the race hub, or a diagnostic that lists rated races whose `last_verified` predates their own primary date.
2. **Convention / ballot-vacancy nominees have no ingestion path.** `race_candidates` is fed by hand-seed or by primary-winner harvest, and a replacement nominee is neither. Not necessarily worth automating for an n of one, but it should be a known gap rather than a rediscovery next cycle.

## Out of scope

- No edits to `primaries` / `primary_candidates`. Platner won the June 9 primary; that is history and it is true.
- No changes to the harvest sentinel guard. It behaved correctly.
- No new races, no rating edits, no drawer layout changes.
- No roadmap block. Docs sweep is its own HO.
