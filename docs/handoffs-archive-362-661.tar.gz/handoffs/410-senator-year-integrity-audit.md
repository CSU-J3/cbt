# HO 410 — read-only audit: senator election-year integrity vs `terms[].class`

> Self-claim the next free number: `ls docs/handoffs/ | sort -V | tail`. If HEAD has moved past 409, renumber.
>
> **READ-ONLY. No writes of any kind** — no `UPDATE`, no seed, no write-path sync, no commit. This pass finds and quantifies the wrong `next_election_year` / `current_term_end_year` values across current senators and traces which race cards they've corrupted. The fix is a separate handoff, and its shape (derive-from-class vs curated per-senator override) gets decided from what this audit reports. If you write a script, put it under `scripts/diagnostic/` and leave it uncommitted — we decide later whether it earns a permanent slot.

## Why

HO 408 fixed `S-OK-2026` at the card layer, but the root is intact: `backfill-races.ts` derives a race's incumbent by matching `members.next_election_year = <cycle>` with no cross-check against Senate class, so every wrong member-year is a latent wrong-incumbent on some seat. S-OK was the one we noticed (Lankford's row said 2026; he's Class III / 2028). We caught two bad rows in passing — Lankford `L000575` (2026, should be 2028) and Armstrong `A000383` (2031, an impossible odd year). This audit finds the rest and shows whether it's a handful of bad rows or a systemic derivation bug, which is the input to the fix decision.

## Canonical source

`members` does **not** carry Senate class (confirmed HO 404 — `terms[].class` not ingested). Pull it from `unitedstates/congress-legislators` → `legislators-current.yaml`. Each legislator's class is on the **last** entry of their `terms[]` array (`class: 1|2|3`); the same term carries `end` (the term-end date) and `state`/`type`. The project already ingests from this repo, so use the existing fetch path.

## Reference (state these, don't re-derive — off-by-one here poisons the whole audit)

As of July 2026 (pre-November), Senate class fixes the regular cycle:

| class | next regular election | current_term_end_year |
|-------|----------------------|----------------------|
| 1     | 2030                 | 2031                 |
| 2     | **2026**             | 2027                 |
| 3     | 2028                 | 2029                 |

Internal invariant, independent of class: **`next_election_year = current_term_end_year − 1`**, and `next_election_year` is **always even** (federal elections). Any odd value is definitionally wrong.

**Special-election exceptions for 2026** — these seats are legitimately up in 2026 despite being Class 3, so their holders correctly show `next_election_year = 2026` with `class = 3`. Do **not** flag them as bugs; list them in their own bucket:

- **Ohio** — Husted (appointed, Vance's Class-3 seat; Vance → VP)
- **Florida** — Moody (appointed, Rubio's Class-3 seat; Rubio → SecState)

Oklahoma is **not** an exception: it's the regular Class-2 election (Mullin's seat), so OK's correct holder shows `next_election_year = 2026, class = 2`. If you find any senator **other than OH/FL** with stored `next_election_year = 2026` and `class ≠ 2`, surface it explicitly — it's either an additional special we should note or a real bug. Report, don't auto-verdict.

## What to report (four sections, numbers verbatim)

### 1. Impossible values (internal, no external source)
Every current senator whose `next_election_year` is **odd**, or where `next_election_year ≠ current_term_end_year − 1`. Columns: bioguide, name, state, stored `next_election_year`, stored `current_term_end_year`. Count + full list. (Armstrong 2031 and the term-end 2032 land here.)

### 2. Class cross-check (the mismatch table)
Join every current senator (`members`, `type = 'sen'`, `is_current = 1`) to their class from the yaml. Produce one table: `bioguide · name · state · class · stored next_election_year · class-expected next_election_year · yaml term end · stored current_term_end_year · class-expected term end`. Flag rows where stored ≠ class-expected on either year, **excluding the OH/FL specials** (list those separately). Report: total senators audited, count matched to the yaml, any senator missing from the yaml (or in the yaml but absent/`is_current=0` in members), and the flagged-mismatch count. Then a one-line **pattern read**: is it a few churned/appointed seats, an off-by-one-cycle class of rows, all-odd garbage, or something the sync computes wrong wholesale? That read is what picks the fix.

### 3. Race blast radius (the payload — which cards are wrong right now)
For each Senate race in `races` at cycle 2026 (`S-*-2026`): report the incumbent `backfill-races` would derive (the `members` row where `next_election_year = 2026` for that state), that incumbent's **actual class** from the yaml, and whether it's the right seat. Flag every race where the derived incumbent's class ≠ 2 and the state isn't an OH/FL special — those are live S-OK-style wrong cards. Also flag any state with a 2026 race that has **zero or multiple** senators at `next_election_year = 2026` (ambiguous derivation). Give the full list, not just a count — these become the fix's worklist.

### 4. `is_current` reconciliation (secondary, same yaml pull)
Two lists: senators `is_current = 1` in members but **absent** from `legislators-current.yaml` (departed — should be 0); and senators present in the yaml but `is_current = 0` (or missing) in members (should be current). Mullin `M001190` (`is_current=0`, resigned) is correct and shouldn't appear as an error — sanity-check that.

## Report back

The four sections above, counts verbatim, section 3 first (it's the live-impact one). No STATUS/backlog edits in this pass — once we see the shape we scope the fix handoff and the doc reconciliation together. Nothing committed, nothing pushed.

## Non-goals / discipline

- No fix. No writes. No sync that mutates. No commit. If a diagnostic script is written, it stays under `scripts/diagnostic/`, uncommitted.
- Don't "helpfully" correct a row you find wrong — log it, move on. A partial hand-fix mid-audit corrupts the count we're trying to establish.
- Scope is current **senators**. House members have no class and are out of scope here.
