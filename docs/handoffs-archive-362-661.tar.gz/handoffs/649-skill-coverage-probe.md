# HO 649 — a probe for what shipped and never reached the docs that record it

**Ground truth:** `main` at `226bd99` (`docs(HO 648): SKILL — the absence-band payload carries its SHAPE, not a size`), `ls-remote` reads main only.

**On the number.** The roadmap's last pointer reads **"Also notes now run through HO 646"**, and its highest HO reference anywhere is 646 — but 647 and 648 both shipped, neither touching `docs/roadmap.md` (647 was told not to; 648 had no reason to). So **the roadmap pointer is two behind and taking 647 from it would collide with committed work.** This is **649**, derived from the maximum HO in commit subjects. The standing rule — *never take the HO from an on-disk filename, take it from the roadmap* — still holds against filenames; what it does not survive is a roadmap that stopped tracking. That gap is itself in scope here, §4.

**This is a PROBE. It fixes nothing.** No SKILL edit, no backlog strike, no roadmap block, no component touched. It reads the filesystem only — no DB, no network, so there is no read-budget question to price. The output is a measurement and a classification; whatever it prices becomes a later HO.

**Two commits:**

| # | Kind | Contents |
|---|------|----------|
| 1 | `chore` | `scripts/diagnostic/skill-coverage-649.ts` — the instrument |
| 2 | `docs` | backlog entries for what M1/M2/M3 price, appended |

Commit 2 only if there is something to file. An empty M3 is a real result and does not need an entry.

---

## §0 — Why this exists, stated so the report can be checked against it

The absence band shipped at HO 622 and reached SKILL at HO 646 — **twenty-three HOs and two full reworks later.** The passage it finally got was falsified by HO 647 **inside one HO**, and the figures it carried (`29,520 bytes`, `14,760 per member`, `78.2%`, `topics`/`affiliations` unread) were corrected at 648.

Both were found because a handoff happened to ask. Neither was found by looking. **The point of this probe is to replace "a handoff happened to ask" with something re-runnable**, which is why the instrument is a committed script and not a session of greps.

**The failure mode to design against is a tidy answer.** The 638–641 arc produced four wrong framings, every one of them tidier than the truth and every one surviving until something measured it. A report that says *SKILL covers the significant surfaces, with a handful of minor gaps* is a characterization, not a finding. **Report counts and the list. Classification criteria are fixed in §3 and §6 before you look at any output** — they cannot be fitted to what comes back.

---

## §1 — Scale, so the output can be sanity-checked

Measured on `226bd99`: SKILL is **2,451 lines / 69 `##`-or-`###` headings**; there are **150** `components/*.tsx` and **30** `app/**/page.tsx`. A candidate list that comes back at five entries, or at a hundred and forty, should both make you re-read the query before writing the report.

Two reference points for how weak the raw signal is: `AbsenceCardBack` — which now has a real passage — appears **twice**. `SponsorExpandedPanel` appears **three times**, at least one of which is the absence-band passage saying it is *no longer reused here*. **Hit count does not discriminate a passage from a mention**, so M1 does not try to.

---

## §2 — M1: surfaces with no SKILL passage

**Mechanical half.** For every `components/*.tsx` basename and every route path under `app/`, emit `name · hit count · line numbers` against SKILL.md. Anchored `grep -F` on the exact identifier, never a regex — HO 648 already lost time to `78.2` matching `78`+any+`2`.

**The collision that would read as success.** Component names nest: a `BillRow` query matches every `BillRowGrid` line and reports `BillRow` as covered when it is not. **Before the table, emit the prefix/substring pairs among the 150 names**, and mark every hit on a colliding name as needing its line read rather than counted. A too-loose match reports everything as covered, which is indistinguishable from a clean bill of health — that is the dangerous direction, and it is the only one.

**Reachability, because an unreferenced component is a different defect.** Split the zero-hit set into *renders on a route* and *not reachable from any `app/**/page.tsx`*. The second group is display-orphan work, not coverage work, and conflating them is how the audit produces a number nobody can act on.

**Do not classify the reachable zero-hit set in this probe.** Emit it whole, with each component's route. Deciding what owes a passage is a judgment that needs its criteria written down first, and writing them against a list you have already read is how you get criteria that fit the list.

---

## §3 — M2: figures that outlived their measurement

Find every line in SKILL carrying a numeric literal alongside a date or an HO tag. Then classify each into exactly one of three, by these tests, fixed here:

**Class 1 — has a canonical home.** The same figure appears in `docs/backlog.md` or `docs/oddities.md`. Mechanical: grep for it. SKILL should point rather than carry, which is what HO 648 did to the payload line. *Priced as: replace with a pointer.*

**Class 2 — the claim fails without it.** The sentence makes an assertion the number is the evidence for. The live example is the line directly above 648's edit: *Live population: 2 members, both MIA, AT RISK 0 (measured 2026-08-11)* is what makes *the amber branch is unexercised* readable. **HO 647 re-measured that on 08-12 and got the same value**, so the figure is confirmed and the date is one day stale — which is the whole class in miniature. *Priced as: stays, carries a date, no other action.*

**Class 3 — drift-prone, no home.** Everything else. *This is the only class that is work*, and pricing it is the probe's output.

**Do not re-measure anything.** A figure being stale is not this probe's finding to make — its finding is which figures are *structurally exposed* to going stale. Re-measuring turns a bounded classification into an unbounded audit, and it is how this becomes a three-day job.

---

## §4 — M3: the roadmap gap

One command's worth: the set of HO numbers in `git log --format=%s` on main, against the set in `docs/roadmap.md`. Report the missing ones and their commit subjects.

The answer is **at least 647 and 648** — that is already known and is not the finding. The finding is whether there are others, further back, from earlier deferred sweeps.

**Bank the rule correction regardless of the count.** The next HO number is `max(roadmap pointer, highest HO in commit subjects)`, not the roadmap pointer alone. The roadmap is authoritative *when it is current*, and it is only current after a sweep — so a deferred sweep silently degrades the one instrument that was supposed to be safe against filenames. That belongs in `docs/backlog.md` and eventually in SKILL, but **not in this commit** — SKILL sits behind the self-mod guard and this is a probe.

---

## §5 — Controls

The instrument reports absence, so it needs to prove it can report presence.

1. `AbsenceCardBack` must come back **covered**. Its passage was written at 646 and rewritten at 648; if the grep misses it, the grep is broken and every zero in the table is meaningless.
2. A nonsense token must come back **zero**. Proves absence is a reading and not a default.
3. `DashboardTopicTreemap` and `V2FeedList` must land in the **not-reachable** split. Both are known display orphans from an open chore; if reachability puts them on a route, the reachability logic is wrong.

**Run all three and report them.** A table without its controls is a list of numbers whose failure mode is invisible.

---

## §6 — What the report must contain

- The three control readings, first, before any finding.
- The prefix/substring collision pairs, and which hits they contaminate.
- M1 raw counts: total components, zero-hit, zero-hit-and-reachable, zero-hit-and-orphaned. **Counts before commentary.**
- The reachable zero-hit list in full, with routes. Not a summary of it.
- M2 counts by class, and the class-3 list in full.
- M3's missing HO set with subjects.
- **What the instrument cannot see.** At minimum: a passage that exists but describes a superseded version is *covered* by this instrument and wrong in fact — HO 646's passage would have passed M1 the day before 647 falsified it. Name that limit rather than letting the report imply coverage means correctness.

**No recommendations in the probe report.** What to do about class 3, and what owes a passage, are the next HO's questions.

---

## §7 — Commits

Commit 1 is the script alone. Commit 2, if it happens, is backlog only — appended, and state the expected `--numstat` before running it.

Report the diff before pushing. Explicit pathspec staging, no `git add .`, ancestry eyeball, fast-forward on `main`. If commit 2 lands a backlog entry whose wording you want read, use a review ref rather than pasting it.
