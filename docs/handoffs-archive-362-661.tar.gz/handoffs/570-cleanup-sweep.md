# HO 570 — Cleanup sweep: dead CSS, dead exports, and the "next touch" one-liners

Confirm the number before saving: `docs/roadmap.md`'s latest pointer runs through **HO 568**; HO 569 was its doc sweep (`dae297e` + `0719678`). So this is **570**. Take the number from the roadmap, not from an on-disk filename.

## What this is

Six independent cleanups that have each been deferred to "the next touch of that file" — and nobody is touching those files. This is that touch. Every item is already logged in `docs/backlog.md` (FIT & FINISH + BANKED + OPEN LOOPS); this HO discharges them in one arc with clean per-concern commit boundaries.

**No behavior change on any rendered surface.** The one exception is C5 (the `amendments-sync` repair gate), which is a real behavior change on a sync path and is quarantined in its own commit for that reason.

Code and docs never mix — the doc sweep for this arc is **HO 571**, not part of these commits. No `SKILL.md` edits here.

---

## STEP 0 — read-only re-verification (mandatory, HALT-free but binding)

The backlog's target lists are **claims, not facts** — that's the ledger's own standing rule, and it fires here. A planning-side pre-check against HEAD already found two of them wrong:

- The backlog says `.v2f-sponsor*` is dead. **`.v2f-sponsor-last` and `.v2f-sponsor-last--plain` are LIVE** (`components/V2FeedList.tsx:123,130`). A prefix sweep would delete a live class and silently restyle the feed sponsor line.
- The in-CSS comment at `app/globals.css:~4427` lists the dead set and is itself part of the problem: the `.v2f-sc-*` card definitions it sits next to are **LIVE**, revealed by `.bxp-sponsor:hover .v2f-sc-card` (`globals.css:4628-4629`) and rendered by `components/BillExpandPanel.tsx:224-237`. Only the dead `.v2f-sponsor` *wrapper* rules go.

So: **re-grep every target below against HEAD before deleting anything.** The binding rule is one line —

> Anything the re-grep shows live is dropped from the sweep, not deleted. Report what you dropped and why. Do not "fix" a live consumer to make a deletion possible.

Two grep blind spots to check explicitly, because plain string grep misses both:

1. **Dynamic class construction.** The codebase builds class names from templates (`` className={`hearing-watch state-${state}`} ``, `` `hcal-day${isToday ? " is-today" : ""}` ``, `` `bill-rail ${chamberClass(billType)}` ``). Before deleting any class, grep for its *stem* as well as its full name.
2. **Type-producing consts.** In `lib/hearings.ts`, `HEARING_BADGES` looks unused but produces `HearingBadge` (`export type HearingBadge = (typeof HEARING_BADGES)[number]`), which **is** consumed by `components/HearingsCalendar.tsx`. Same shape for `HEARING_TYPES`/`HearingTypeFilter` and `HEARING_VIEWS`/`HearingView` — those two type aliases came back with zero consumers, so their consts are genuinely droppable, but verify rather than trust this paragraph.

Report STEP 0 findings in chat as a table (`target · claimed · verified · action`) before the first commit. No commit for STEP 0 itself.

---

## C1 — dead CSS sweep (`app/globals.css` only)

Delete the orphaned rule blocks. Pre-checked as **zero `.tsx`/`.ts` consumers** at HEAD:

**The HO 317 private-Expand orphans** (dead since the shared `.bxp` panel replaced the per-surface expand):
`.v2f-exp` · `.v2f-grid` · `.v2f-summary` · `.v2f-related` · `.v2f-rel-*` · `.v2f-side` · `.v2f-sk` · `.v2f-sv` · `.v2f-cmte-*` · `.v2f-btns` (incl. `.v2f-btns a.v2f-btn-primary`) · `.v2f-sponsor` · `.v2f-sponsor-name` · `.v2f-sponsor-name:hover` · `.v2f-sponsor-tag` · and the dead reveal pair `.v2f-sponsor:hover .v2f-sc-card, .v2f-sponsor:focus-within .v2f-sc-card` (globals.css:4366-4367).

**The HO 306 hearings-redesign orphans:** the whole `.hill-band*` family (18 hits, 0 consumers).

**The HO 366 `/hearings` chrome orphans:** `.hearings-page-masthead` · `.hearings-prompt` (+ `.hearings-prompt .prompt-accent`) · `.hearings-subhead` (+ `.hearings-subhead .num`).

**The HO 306 list-view filter-bar orphans:** `.hearings-filterbar` · `.hearings-filter-group` · `.hearings-filter-label` · `.hearings-filter-opt` (+ its `::before`/`::after`/`:hover`).

**The HO 367 members-header orphan:** `.mc-fbar-title`.

### Do NOT delete — verified live, each would be a real regression

| Class | Live consumer |
|---|---|
| `.v2f-group`, `.v2f-group.open` | `V2FeedList.tsx:190`; asserted by **both** e2e specs |
| `.v2f-sponsor-last`, `.v2f-sponsor-last--plain` | `V2FeedList.tsx:123,130` |
| `.v2f-sc-card` / `-info` / `-name` / `-party` / `-meta` / `-photo` / `-photo--fb` | `BillExpandPanel.tsx:164-237`, revealed by `.bxp-sponsor:hover` at globals.css:4628 |
| `.v2f-bar` / `-bdot` / `-bping` / `-bnode` / `-blabel` / `-bdate` / `-bdotwrap` | `BillExpandPanel.tsx` (the shared stage bar) |
| the ~12 live `.hearings-*` calendar/list classes | `HearingsCalendar.tsx` / `HearingsList.tsx` — target the **named survivors above**, never a blanket `hearings-` sweep |

The `.v2f-sponsor:hover .v2f-sc-card` deletion is only safe **because** `.bxp-sponsor:hover .v2f-sc-card` exists at 4628-4629. Confirm that line is present before removing 4366-4367; if it isn't, stop and report.

### Also in C1: fix the stale map comment

The comment block at `globals.css:~4421-4429` (the `── HO 317` banner) names the dead set and says "sweep in a follow-up." That sweep is now this commit. Rewrite it to (a) drop the now-deleted list, and (b) state the surviving relationship correctly: `.v2f-sc-*` and `.v2f-b*` are **reused by `.bxp`** and are live. Leaving the old wording behind would re-seed the exact wrong-glob error this HO caught.

Commit: `chore(css): HO 570 C1 — sweep dead expand/hearings/members-header rules`

---

## C2 — dead query + dead `lib/hearings` exports

**`lib/queries.ts`:** delete `getMembersRankedCount` (`:5842`) and reconcile the stale comment at `:5667` that references it. Its last caller went away when HO 367 replaced the `/members` readout with a live `rows`-bucketed chamber split (the reason is recorded in a comment at `app/members/page.tsx:197` — leave that comment, it explains the absence). Note `scripts/diagnostic/members-plan-277.ts:49` uses the string `"getMembersRankedCount"` as a *label* beside a locally-defined `MEMBERS_COUNT` SQL const (`:44`) — deleting the query does **not** break it, but the label is now stale; update it to name the SQL, not a function that no longer exists.

**`lib/hearings.ts`:** delete the exports STEP 0 confirms have zero consumers. Pre-check says: `HEARING_TYPES` · `HearingTypeFilter` · `sanitizeHearingType` · `typeFilterBadge` · `HEARING_VIEWS` · `HearingView` · `sanitizeHearingView` · `weekdayOfKey`. **Keep `HEARING_BADGES`** — it produces the live `HearingBadge` type.

Commit: `chore(lib): HO 570 C2 — drop dead getMembersRankedCount + unused hearings exports`

---

## C3 — `FilingRow` duplicate key + the allowlist entry it holds open

The backlog names `key={id}` at line 76. **That line number and that diagnosis are both stale.** At HEAD there are two `key=` sites in `components/FilingRow.tsx`:

- `:82` — `key={code}` over `shownIssues` (`filing.issueCodes.slice(0, MAX_ISSUE_CHIPS)`). A filing repeating an issue code produces the dup.
- `:96` — `key={id}` over `filing.billIds`.

Determine which actually collides (a quick local `/lobbying` load with the React dev warning on will name it) and fix **that** one. Prefer deduping the source array over index-suffixing the key — a filing listing the same issue code twice is a redundant render, not just a React complaint. If both can collide, fix both.

**Then delete the matching entry from `e2e/console-noise.ts`.** Line `:18` (`/Encountered two children with the same key/`) plus its provenance line in the header comment at `:10`. That file's own header states the two OPEN-LOOP entries exist to be deleted when their loops close — this is that close. **Leave the `MissingSecret` entry alone**; its loop (the `AUTH_SECRET` env gap) is still open.

Verification order matters: fix the key first, confirm the warning is gone locally, *then* remove the allowlist entry. Removing it first would red the suite on a real warning.

Commit: `fix(lobbying): HO 570 C3 — dedupe FilingRow chip keys, retire the allowlist entry`

---

## C4 — scripts hygiene (three one-liners, no behavior change)

1. **`scripts/verify-deploy.ts`** — `process.exit(0)` at `:46` and `process.exit(1)` at `:54` trip the Windows libuv `UV_HANDLE_CLOSING` teardown assertion, mangling a passing check into exit 127. Apply the same fix already used in the cron-check script: `process.exitCode = n; return`.
2. **`scripts/sync-fec.ts:4`** — the comment claims "well under FEC's 1000/hr api.data.gov limit." The key has been on the **60/hr** standard tier throughout. Correct it; note the comment at `:30` is already accurate, so make the two consistent rather than duplicating the explanation.
3. **`scripts/diagnostic/cold-start-audit-332.ts:232`** — drop the `getSponsorStates` probe entry. The function was deleted from `lib/queries.ts` at HO 356; the script still carries a hardcoded copy of its SQL and times it, which is why the HO 404 audit reported a **false SLOW: 34,656ms** for a query with zero callers.

Commit: `chore(scripts): HO 570 C4 — exit-code, stale rate comment, dead audit probe`

---

## C5 — `amendments-sync` repair gate → full enumeration (behavior change, own commit)

`repairAmendments` gates completion on `storedCount >= liveCount` (`lib/amendments-sync.ts:390`, and the same expression in the return at `:454`), where `liveCount` is `pagination.count`. This is the exact latent bug nominations already fixed at `e175fd7`. It is **harmless only while the amendments feed stays duplicate-free**; if the feed ever returns duplicate list entries, `storedCount` can never reach `liveCount` and the gate false-negatives forever — the loop runs doing nothing with `complete: false`.

Align it to the nominations shape: enumerate, compare, complete on `missing.length === 0`, and **report `duplicates`** in the result. Read `e175fd7` and match that implementation rather than inventing a second one.

**Falsification is required before any doc records this as protection** (the HO 549/553 discipline — a guard that structurally can't fire emits the same green as one that works). The `duplicates` path has never executed, because the feed is duplicate-free today. So:

- Hand-inject a duplicate list entry on current HEAD, **scratch only** — never check out pre-fix files.
- Run the repair, confirm it reports the duplicate and still reaches `complete: true` instead of spinning.
- Revert the scratch edit, `git status` clean, commit nothing from the falsification.
- If the local environment can't demonstrate it, say so plainly and it gets recorded as **UNPROVEN in a WATCH** at HO 571 — not as protection.

**This commit may be dropped from the arc.** If STEP 0 or the implementation shows it's larger than a gate swap (e.g. the enumeration needs a new fetch shape), stop, report, and let it take its own HO number. Do not let it swell C1–C4.

Commit: `fix(amendments): HO 570 C5 — repair gate on full enumeration, not pagination.count`

---

## C6 — two e2e spec fixes

**1. The PRESIDENT stage-click fixed-wait race.** The backlog's line numbers are stale (the file drifted at HO 548). At HEAD the test is at `e2e/smoke.spec.ts:328`; the fixed wait is `:338-339` (`waitForLoadState("load").catch(...)` then `waitForTimeout(1_500)`), and the assertion is `:346-347`. Replace the two wait lines with the predicate-wait pattern both specs already use elsewhere:

```ts
await page.waitForURL(/[?&]stage=president/, { timeout: 8_000 }).catch(() => {});
```

Keep the `toContain` at `:346-347` as the real failure surface. **Do not touch** the crawl-helper settle at `:162-163` (`waitForTimeout(2_500)`) — different site, different job. Also leave `:275` and `:308` alone; they're out of scope.

Why this can't sit in WATCH: `--retries=2` masks the flake by design on the unattended run, and nothing behind a retry ever gets revisited.

**2. `/races` redirect coverage is implicit.** `ROUTES` carries `{ slug: "races", path: "/races" }` at `:63`, and the crawl asserts 200 *after* `page.goto` has already followed the 308 — so it catches `/races` breaking outright but not `/races` redirecting somewhere wrong. Add the explicit assertion HO 502 established for `/news` and `/president`: assert `redirectedFrom()` or a `/electoral` page marker. One line, same pattern as the existing sites.

Commit: `test(e2e): HO 570 C6 — predicate-wait on the president rebase, explicit /races redirect assert`

---

## Scope guards

1. Explicit pathspec staging only. Never `git add .`.
2. Nothing the STEP 0 re-grep shows live gets deleted. No exceptions, no "it's obviously dead."
3. No new features, no restyling, no refactors of adjacent code because you were already in the file.
4. No `docs/` edits and no `SKILL.md` — HO 571 is the sweep.
5. No migration, no schema change, no cron change.
6. C5 is the only commit permitted to change runtime behavior. If any of C1–C4 or C6 changes what a user sees, you've gone out of scope.
7. Each commit stands alone and reverts cleanly. If two concerns want the same commit, they want two commits.

## Verification

**These are two different questions — keep them apart in the ship report.**

*Did the sweep land?* Grep counts for every deleted class/export go to **zero** repo-wide, and report the `app/globals.css` line delta (9,713 at HEAD). If the work never happened these read unchanged, so they're a real instrument.

*Did the sweep break anything?* This is a regression gate, and it would read green if the work never happened — so it proves absence of damage, not presence of work. Don't conflate them.

- `npm run typecheck` clean.
- `npm run build` clean. Fresh `.next` (`rm -rf .next`) before the render checks — a stale build is the classic way a CSS deletion looks fine locally.
- Confirm the stylesheet actually loads (no 404 on `layout.css`) before trusting any visual check.
- `npx playwright test e2e/fit-finish.spec.ts` — must stay green, and specifically the sponsor hover-card assertion at `:287` (`.v2f-sc-card`) must pass. That test is the guard against the exact wrong-glob deletion STEP 0 caught. Known local false-fails from the `AUTH_SECRET` open loop (`/bills`, `/changes`, `/dashboard-v2` console assertions) are **not** findings — don't chase them, and don't point smoke at dev.
- Eyeball, on a fresh build: `/` feed row expand (panel + stage bar + **sponsor hover card**), `/bills` row expand, `/hearings` list **and** calendar, `/members` filter bar, `/lobbying` filing rows.
- Ship: `git push` (fast-forward only, ancestry eyeball first — `git log --oneline @{u}..HEAD`), then `npm run verify:deploy` until served SHA === HEAD.

## Ship report

- STEP 0 table: every target, claimed vs verified, and **what you dropped from the sweep** with the live consumer that saved it.
- Per-commit: SHA, files, and the grep-count-to-zero line.
- `globals.css` line delta.
- C3: which `key=` site actually collided, and confirmation the allowlist entry is gone while `MissingSecret` remains.
- C5: shipped or deferred; if shipped, the falsification transcript (injected duplicate → reported → reverted → `git status` clean). If it couldn't be demonstrated locally, say **UNPROVEN** in those words.
- C6: the two edits, and confirmation `:162-163` is untouched.
- fit-finish result with the sponsor-card assertion called out by name.
- Anything you found that isn't in this handoff — file it, don't fix it.
