# Carry for the next sweep — 582 slope bar + dup-write / HO 238 (NO docs, NO build yet)

**Trigger:** the Aug-1 Turso slope bar landing (tomorrow's dashboard bar). That fires the
read-budget slope scoring (582 leg #4) and folds the items below into the record. **No docs
edits and no build until then — this file is the durable carry only.** Roadmap is
authoritative for the HO number. Handoffs are gitignored, so this is the cross-session carry.

## 1. HO 582 verification — legs #2/#3 CLOSED; leg #4 (slope) is the open one

- **Leg #2 freshness-after-cron — CLOSED.** The 00:00 UTC markets tick surfaced on
  `/api/markets/latest` (max `ticked_at` `2026-08-02T00:01:59.938Z`, 18 symbols — the deduped
  payload) and held **identical across 3 hits** at SHA `e8160ff`, **no redeploy**.
- **Leg #3 marker cadence — CLOSED.** `[markets] regenerating market-ticks-latest` fired only
  at **16:02 / 20:12 / 00:06** over 21h — cron cadence (lazily, on the first `GET /` after each
  `revalidateTag("markets")`), **zero per-minute clusters** despite real sustained tab traffic.
- **Refinement into the record:** post-C1 regens are **DEMAND-GATED** — an overnight cron tick
  with no tab open regenerates *nothing* (the `revalidateTag` invalidates, but nothing
  re-materializes until the next `GET /`). So the **~294K/day regen model was a CEILING**, not
  the actual rate; the real rate is bounded below it by demand. Tightens the 582 read-budget model.
- **Leg #4 = the slope**, scored against the **~1/5-cut prediction** when the Aug-1 bar lands.
  This is the remaining open leg; it closes the 582 "verification PARTLY OPEN" clause and the
  read-budget WATCH's markets share.

## 2. Dup-write P3 (`docs/backlog.md:33`) — instrument RESOLVED, predicted outcome

- **Reading:** ONE run wrote CPI+WTI (the bare `0 */4` markets cron, full symbol set) with
  `[db] timeout, retrying` lines present → the **boundedFetch / client-retry hypothesis
  CONFIRMED** (byte-identical `ticked_at` is the retry re-sending pre-computed args, not a second
  execution). The 20:00 **bare+fmp dual-fire is by-DESIGN disjoint writes** (the fmp pass = 7
  equities only, never touches CPI/WTI), NOT resurrected concurrency.
- **Record corrections:**
  - **(a) ids 6580–6583 are `market_ticks` ids** (CPI 6580/6582, WTI 6581/6583 — already correct
    at `backlog.md:33`). The earlier "stale ids / they're cron_runs summarize rows" was a
    **table confusion** (cross-referenced `cron_runs`), NOT handoff staleness. The handoff ids
    were right; the wrong table was read.
  - **(b) Three `[db] timeout, retrying` lines** in the 20:00 window: two attributable to the
    CPI+WTI pair via the byte-identical dup evidence; the **third is unattributable** — the warn
    at `lib/db.ts:52` carries **no statement identity**, so tying a given retry line to a specific
    INSERT is **structurally unavailable** from the log alone.

## 3. HO 238 idempotency-grep re-run item — UPGRADED with its first concrete harm instance

(Currently the scope-note spin-out inside the dup-write P3 at `backlog.md:33`: "the HO 238
idempotency argument under-covers every bare append-only INSERT reachable through `getDb()`.")

- **First harm instance:** `cron_runs` **6482/6483** — shared `started_at` **20:00:51.126**,
  mapping to ONE request (only the 20:00:46 fmp `GET` exists near then) — the SAME retry
  double-write mechanism, but at `startCronRun`'s INSERT (identical ms because the pre-computed
  `new Date().toISOString()` arg is re-sent on retry). **6482 is the orphaned phantom** (its
  response was lost; the handler finished the retry's id 6483).
- **Why it's harm, not just noise:** `cron-health.ts:93` puts `'orphaned'` in `HARD_FAIL`
  (`const HARD_FAIL = new Set(["error", "orphaned"])` — verified). A retry-phantom orphan is a
  *successful* run's ghost that the watchdog can read as a hard fail.
- **Open question INSIDE the item — CHECK, don't assume:** whether the phantom actually trips the
  watchdog depends on the **most-recent ordering key vs the reaper's stamp time**
  (`evalCronRunsRoute`'s "last run" ordering vs when `reapStaleRows` stamps `ended_at` +
  `status='orphaned'`). Resolve at sweep time; do not assume it trips.
- **Fix shapes DEFERRED into the item (do NOT build now):**
  - `market_ticks` → **`ON CONFLICT(symbol, ticked_at) DO NOTHING`**. The **trap:** a bare
    `UNIQUE(symbol, ticked_at)` *without* the conflict clause is **strictly worse** — the retry's
    second INSERT would ERROR and mark a successful run failed. The conflict clause is load-bearing.
  - `cron_runs` → an **id-safe idempotent `startCronRun`**: client-generated run key +
    `INSERT OR IGNORE` + `SELECT` to fetch the id. `DO NOTHING` alone loses the `RETURNING` id
    the handler needs.
- **Rider:** the retry warn (`lib/db.ts:52`) could carry a **SQL prefix** so the next
  investigation is direct — makes attribution possible, addressing 2(b).

## 4. Roadmap

- The new sweep block **CLOSES 582's "verification PARTLY OPEN" clause** (legs #2/#3 done; leg #4
  = the slope, scored against the ~1/5 prediction when the bar lands).

## Scope guards

- **No docs edits, no build** until the slope bar triggers the sweep.
- The fix shapes in §3 are **DECISIONS for after** — recorded, not scoped.
