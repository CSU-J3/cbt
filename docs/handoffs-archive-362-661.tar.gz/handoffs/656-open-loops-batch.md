# HO 656 — four open loops: recover the frozen 11, advance the harvest, one denominator, one rate read

**Derive the number.** At writing: roadmap pointer 654, subjects through 655, so 656. Re-derive at the clone.

**The four backlog entries are the spec; this handoff is the route between them.** Before acting, read each in full at HEAD: the `isSettled` freeze parent (opened 641), the 11-contests symptom (638/641), Harvest currency (643), the 119TH denominator (646), and the `pageErr` entry (572→591). **On any conflict between an entry and this handoff, the entry wins** — and if any of the four shows a disposition postdating this file, HALT that section and report.

Ordering: §A1 before §B, strictly. §C and §D are independent of everything, and a HALT in one section never blocks the others.

---

## §A — the isSettled freeze: recover now, probe the guard, build nothing

The entry's two dispositions are independent. Both run here; neither edits `isSettled`.

**A1 — recovery, using what already ships.** The frozen class (11 contests: shares recorded, no winner row) is unreachable by the three sync paths but not by `npm run backfill:primary-results`, which UPDATEs `vote_pct` AND `status` with no settled check.

1. **Gate first, one fetch:** pick `house-NJ-09-2026-R` (ordinary partisan, Pino 51.5%, the cleanest case) and fetch its Ballotpedia page live. Has the votebox been marked with a winner since? If yes, the recovery is live; run it. If no, check one more of the 11, then report per-contest and stop A1 with the entry updated rather than closed.
2. Run `npm run backfill:primary-results` (default past-dated mode). Pacing is built in (1100ms/seat). **Check `vercel.json` for the daily primaries slot first and run off-tick** — the backfill and the sync both write `primary_candidates`, and while the UPDATE is idempotent, overlapping a delete-rebuild is not a race to volunteer for.
3. Re-measure the 11. Report recovered vs residual, per contest. **`senate-ME-2026-R` (Collins, uncontested, 100.0%) is expected residual and that is correct behaviour** — Ballotpedia marks no votebox winner where there was no contest. Record it against the convention/hand-curation entry's territory, do not force a status.
4. Flush the relevant cache tag after writes, per the script conventions in SKILL.

The recovery itself is the falsification: a frozen prod row gaining its winner through the bypass path demonstrates the mechanism on real data. No synthetic rows in prod, ever. If the gate says nothing is markable, record disposition 2 as UNPROVEN-at-this-date in the entry and move on.

**A2 — the guard fix, probe and recommendation only.** The entry rules out the naive winner term (it un-freezes uncontested seats permanently). Two shapes are named: a bounded re-check window (eligible for N days past `primary_date`, then settle regardless) and an attempt counter (M no-winner scrapes, then settle). Evaluate both:

- Bound N from what A1 yields: the 11's `primary_date`s against today give upper bounds on Ballotpedia's call lag only. **Say plainly if N cannot be measured from our data** — an honest "pick N generously, the cost of re-fetching an uncontested seat for N days is N wasted fetches" beats a fitted number.
- The counter shape needs a column, so it is a migration and disqualified from this HO regardless of merit.
- Recommend one shape with its parameter and file the build as its own QUEUED entry. **The build happens under its own number** — the entry says so and nothing here overrides it.

## §B — the harvest, run under recovered data, then the scoping the entry demands

After A1 only.

1. Record the before-state: sentinel rows/seats (last known 82/53, exactly SKILL's first-run figure), zero-roster rated seats (last known 129 of a 186 rated set). **These are dated claims; re-derive all of them.**
2. Run `npm run backfill:race-challengers`, flush `races` per its header.
3. Re-measure, then **classify every remaining zero-roster rated seat into exactly one bucket, buckets summing to the total:** future `primary_date` (not a defect) · winner present but correctly excluded (incumbent-winner or hand-curated guard: verify the guard behaved) · uncontested or convention (the S-ME class; count separately, cross-referencing that entry) · runoff pending · frozen residue from A1 · other, enumerated seat by seat. A bucket named "other" with a count and no names is not a classification.
4. The two structural questions the entry requires scoped: **(i) schedule** — price chaining the harvest after the daily primaries sync against a weekly slot, against `vercel.json`'s current shape and the Turso read budget, recommend one, file it QUEUED, **wire nothing**; **(ii) `race_candidates.updated_at`** — file the migration as its own QUEUED entry with the HO 642 bracketing pain as its justification, do not migrate here.
5. **SKILL check:** the 82/53 figure lives in SKILL. Read the line: if it presents as a dated first-run record, leave it; if it reads as current state, it gets the drift-figure treatment (pointer to the record), its own commit behind the self-mod guard on the review ref.

This run plus the classification plus the two filings satisfies the entry's close ("a scoped handoff, not a script invocation"); strike it accordingly, carrying the numbers.

## §C — the 119TH denominator, one field, fenced

Per the HO 646 entry: `queryAbsenceWatch`'s population pass already SELECTs `p.total` and `p.not_voting` from `member_participation` and discards both after computing `missedPct`. Ride the two counts on `AbsentMember`; the card back renders `<pct>% · <missed>/<total>`.

- **Zero new SQL statements is the premise and the gate.** If carrying the fields turns out to need a new statement anywhere, the premise is false: HALT §C, report, leave the entry open with the correction.
- **Fence: the `recentBills` payload projection (HO 647) is untouched.** Not re-scoped, not "improved while in there."
- The back is space-tight (HO 631 overlay). If `370/1,262`-scale text overflows its line at the established type scale, report the character budget and stop rather than reflowing the card.
- Verify: the rendered pair equals a direct `member_participation` read for one member; typecheck; **direct to main** (UI, the preview-dedup rule); `verify:deploy` under the consecutive-match gate; record what each check reads if the work never happened.

## §D — pageErr: one cheap dimension, time

Read-only. The entry's hypothesis families are exhausted and stay exhausted; **no fixes, no new crawls, no attribution attempts.** The one thing the record lacks is whether the fire rate has moved.

1. Read `smoke.spec.ts` first to learn what a pageErr fire looks like in a run log (assertion text, retry lines, collector output).
2. Pull e2e-prod run logs via `gh run list` / `gh run view --log`, **scheduled daily runs preferred** (one per day), window from HO 590's deploy to now. Artifacts only exist on failure with 14-day retention, so logs are the record; if GitHub's log window truncates the span, report the observable span honestly rather than extrapolating.
3. One table: date · fired? · count · deploy(s) that day (from the git log). The question: did any deploy in the 604–655 train step-change the rate, in either direction?
4. Outcomes: a step to ~zero after a deploy is a bisect lead — file it in the entry, stop. An unchanged rate is a datapoint — file it, stop. **State what this check reads if nothing happened: the same intermittent rate.** The step is the only signal.

---

## Commits

Expected shape: **one code commit** (§C, direct to main) and **docs on `656-review`** — one roadmap block per the convention read from the file's own recent blocks, and the backlog pass: strike 646 (denominator) · strike Harvest currency with its numbers · update the freeze parent (disposition 2 executed or UNPROVEN-dated; disposition 1's recommended shape) · update the 11-contests symptom with the recovered count · the pageErr entry gains the §D table's conclusion · new QUEUED entries for the guard build, the harvest schedule, and `updated_at`. Plus the conditional SKILL commit from §B.5, alone, behind the self-mod guard.

Data runs commit nothing. Docs and code never ride together. Explicit pathspec staging, ancestry eyeball, append-only verified on `--numstat`'s deletion column (not `grep -c '^-[^-]'`, not normal-format diff against `git show` under autocrlf).

## Guards

1. The backlog entries win over this handoff on any conflict.
2. `isSettled` is not edited. No migrations. No cron wiring.
3. No synthetic rows in prod; the recovery's live run is the proof, or the disposition records UNPROVEN.
4. Ballotpedia pacing as shipped; runs off the sync tick.
5. §D is read-only and bounded to the log window; the moment it turns into hypothesis work, stop.
6. Every classification's buckets sum to their total, and every "other" is enumerated by name.
7. Report, per section, what its checks read if the work never happened.
