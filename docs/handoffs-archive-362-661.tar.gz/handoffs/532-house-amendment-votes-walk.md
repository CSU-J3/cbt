# HO 532 — House amendment→vote linkage walk (the banked House tail)

The other chamber of the amendment-vote surface. HO 530 shipped the Senate half query-only (the number's in `votes.question`); the **House has no cheap key** — its vote questions are generic (`On Agreeing to the Amendment`, no number, only `bill_id`), so the link must be recovered from each HAMDT's `/actions.recordedVotes.rollNumber`. HO 529 §C already confirmed this **GO-WALK**: every sampled `recordedVotes` resolved to an existing `votes` row (BLOCKED-ON-SYNC refuted — the roll calls are all ingested), so this is a **linkage** backfill (store `amendment_id ↔ vote_id`), **not** a member-vote backfill — the votes + member positions are already in the DB. **Straight build, no probe** (529 §C did the feasibility). Rare payoff by nature (the HO 461 "the floor almost never votes" — 17/20 sampled HAMDTs never voted), so the whole thing is small and bounded.

**Code build.** A migration (link table + sentinel + partial index), a walk (`--walk` CLI + a bounded cron step), a House branch on `getBillAmendmentVotes`, and **zero render change**. Diff shown before commit; **no doc edits, no SKILL** (its own doc sweep after — the House-tail close + the numbering note). Next HO after this is the sweep.

## Baked from the code (facts — do not re-derive)

- **House `votes.id` is deterministic** — `voteId(congress, session, rollCall) = \`house-${congress}-${session}-${rollCall}\`` (`lib/votes-sync.ts:172`). So the walk **constructs** the vote_id from `recordedVotes` fields (`house-{congress}-{sessionNumber}-{rollNumber}`) — no lookup to find it. The votes side already has `member_votes` for it (the House vote sync ingests amendment roll calls, HO 529).
- **`recordedVotes` shape** (from the amendment `/actions` sub-resource, HO 452's endpoint): each carries `{ chamber, congress, sessionNumber, rollNumber, url, date }`. Confirm the exact field casing off one live `/actions` payload during the build (the sync stores no actions today). Filter to `chamber` House (a HAMDT's recorded votes are House votes).
- **`/actions` is NOT fetched by the current sync** — `lib/amendments-sync.ts` does list → `detailUrl` detail only; `/actions` (`/amendment/{congress}/{type}/{number}/actions`) is a separate sub-resource the walk adds (the HO 452 probe path). The sync deliberately skips it for **dispositions** (HO 452 NO-GO); the walk uses it **only** for `recordedVotes`.
- **The sentinel is safe on `amendments` (the HO 459 pattern, verified).** `lib/amendments-sync.ts`'s `ON CONFLICT(id) DO UPDATE SET` (~line 208) names every column explicitly — a new **`amendment_vote_walked_at`** is in neither the INSERT list nor the SET, so a re-sync INSERTs it NULL on a genuinely new amendment (correctly un-walked → in the queue) and **preserves** the walk's stamp on CONFLICT (never re-nulled). Same trap the HO 459 `committee_hydrated_at` column navigated — here confirmed by reading the actual clause. **Do not add the sentinel to the sync's SET.**
- **HAMDT population is small** — ~228 in the 119th (HO 446: SAMDT 6,560 / HAMDT 228), so the one-time walk is ~228 `/actions` GETs, and the cron delta is usually 0. This is bills-scale-tiny, not a corpus backfill.
- **The read is `getBillAmendmentVotes` (HO 530)** — Step 1 pulls the bill's SAMDT amendments and keys `(congress, number)`; Step 2 parses `votes.question` (`SENATE_AMDT_Q`); Step 3 does the D/R/I party split over the matched `vote_id`s. The `AmendmentVote` type + the tally extraction + Step 3 are **chamber-agnostic** — they take a `vote_id` and a `votes` row. So the House branch only has to *produce matched House vote rows*; the split and the assembly are reused.
- **The render is chamber-agnostic** — `BillAmendments` renders a vote line for any amendment the map carries. So House votes render identically once they're in the map. **No component change.**

## §1 — Migration (`scripts/migrate.ts`)

Three additive changes (idempotent — the file's existing `IF NOT EXISTS` / add-column-if-absent pattern; follow the HO 459 `committee_hydrated_at` precedent for the column):

- **Link table** — loose links, no enforced FK (the HO 447 amendments-table convention for self/cross-referential bulk data):
  ```sql
  CREATE TABLE IF NOT EXISTS amendment_votes (
    amendment_id TEXT NOT NULL,
    vote_id      TEXT NOT NULL,
    PRIMARY KEY (amendment_id, vote_id)
  );
  ```
  (The composite PK handles the list case — an amendment can carry a table-then-substantive pair, HO 530.)
- **Sentinel column** — `ALTER TABLE amendments ADD COLUMN amendment_vote_walked_at TEXT` (nullable; walk-only, the sync never names it — verified §baked).
- **Walk-queue partial index** (the HO 406/459 partial-index pattern):
  ```sql
  CREATE INDEX IF NOT EXISTS idx_amendments_hamdt
    ON amendments(update_date) WHERE amendment_type = 'HAMDT';
  ```
  (Indexes the HAMDT subset by `update_date` so the queue predicate below seeks; the ~228-row residual is trivial regardless.)

## §2 — The walk (`lib/amendment-votes-walk.ts` + `sync:amendment-votes`)

A new module + a `package.json` script `sync:amendment-votes` (`-- --walk` for the CLI backfill), mirroring the `sync:nominations --hydrate` shape (HO 459).

**Queue** — HAMDTs not yet walked, or changed since their last walk:
```sql
SELECT id, congress, amendment_type, amendment_number, update_date
  FROM amendments
 WHERE amendment_type = 'HAMDT'
   AND (amendment_vote_walked_at IS NULL OR update_date > amendment_vote_walked_at)
 ORDER BY update_date ASC
 LIMIT ?;   -- cap for the cron step; unbounded for --walk
```
Both `amendment_vote_walked_at` and `update_date` are full ISO timestamps, so `update_date > walked_at` cleanly re-walks any HAMDT whose Congress.gov record changed since we last looked (catching a *newly-voted* HAMDT — the live-corpus edge that the nominations immutable-committee case didn't have; don't compare against `latest_action_date`, a bare date, which would misorder same-day).

**Per HAMDT:**
1. GET `/amendment/{congress}/{type}/{number}/actions` (the HO 452 endpoint; `fetchJson`, the same per-fetch timeout + pacing as the detail loop).
2. Extract `recordedVotes` across the actions (House only). For each, construct `voteId = \`house-${congress}-${sessionNumber}-${rollNumber}\`` and **upsert** `amendment_votes(amendment_id = <this HAMDT id>, vote_id)` — `INSERT … ON CONFLICT(amendment_id, vote_id) DO NOTHING`. **Insert unconditionally** — do NOT gate on the `votes` row existing: the read LEFT-JOINs `votes`, so a link to a not-yet-synced roll call is null-safe and self-heals when the House vote sync ingests it (529 §C says 100% resolve today, so dangles are unlikely). A HAMDT with no `recordedVotes` inserts nothing.
3. **Stamp** `amendment_vote_walked_at = <now ISO>` on the HAMDT **regardless** of whether a vote was found (the queue-exit — the HO 459 stamp-every-processed-row rule; a walked-no-vote HAMDT must leave the queue).

**Modes:** `--walk` (unbounded one-time backfill of the whole queue, ~228 GETs, paced ~150ms like the detail loop) vs the deadline-gated cron path (§3). Report `{ walked, linksInserted, hamdtWithVote, remaining }`.

## §3 — Cron step (`app/api/cron/amendments/route.ts`)

Add a **bounded walk step after the sync**, mirroring the nominations sync→hydrate split (HO 459). The route is `wrapCronRoute`, `maxDuration 300`, `AMENDMENTS_BUDGET_MS 280_000`. Carve it: sync gets ~240s, the walk gets the remainder (its own sub-deadline, cap ~40 HAMDTs/tick). Since the HAMDT delta is usually 0, this rarely does work; when a HAMDT is added/voted it trickle-links over a tick or two. Add `revalidateTag("votes")` after the walk writes links (so `getBillAmendmentVotes`, tagged `votes`, flushes — §4 also adds the `amendments` tag as a second flush path). Keep the existing `revalidateTag` for the sync.

## §4 — The read branch (`lib/queries.ts`, `getBillAmendmentVotes`)

Extend the existing query — do **not** fork a new one:
- **Step 1:** widen the amendment pull to `WHERE amended_bill_id = ? AND amendment_type IN ('SAMDT','HAMDT')`. Keep the SAMDT `(congress, number)` keying for the question-parse path; **also collect the HAMDT `id`s** into a list.
- **Step 2 (unchanged):** the Senate `votes.question` parse, matched to the SAMDT keys.
- **Step 2b (NEW — House):** if any HAMDT ids, `SELECT av.amendment_id, v.id, v.result, v.vote_date, v.yea_count, v.nay_count, v.present_count, v.not_voting_count FROM amendment_votes av JOIN votes v ON v.id = av.vote_id WHERE av.amendment_id IN (…)`. Push each into `matched` with the **same tally extraction** the Senate path uses (`deriveDisposition(result)`, the counts, empty party skeleton).
- **Step 3 (unchanged):** the D/R/I party split over `matched`'s `vote_id`s already covers the House rows.
- **Tags:** add `"amendments"` to the query's tag list (currently `["votes"]` → `["votes", "amendments"]`) so the amendments cron's existing `revalidateTag("amendments")` flushes it when the walk step adds links; `votes` stays for a votes re-sync.

The `AmendmentVote` type, the `Map<amendmentId, AmendmentVote[]>` return, the list handling, and the render are all unchanged — House votes flow through the exact Senate machinery.

## Guardrails + deliverable

- **Straight build, no probe** — but **confirm the `recordedVotes` field casing** off one live `/actions` payload before writing the extractor (the sync stores none today), and **run `--walk` and report** `{walked, linksInserted, hamdtWithVote}` before the read/cron land. 529 §C named concrete cases to spot-check — a HAMDT it saw resolve (e.g. HAMDT5 → House roll 32, HAMDT13/15 → roll 80/82); confirm those links land and the constructed `house-119-…` id matches an existing `votes` row with `member_votes`.
- Read `/mnt/skills/public/frontend-design/SKILL.md` only if any render turns out necessary (it shouldn't — the render is chamber-agnostic; flag if that assumption breaks).
- **Diff shown before commit.** Explicit pathspec (`scripts/migrate.ts` + `lib/amendment-votes-walk.ts` + `package.json` + `app/api/cron/amendments/route.ts` + `lib/queries.ts`); confirm the amendments-sync SET clause is **untouched** (the sentinel stays sync-invisible), `getBillAmendments` untouched, and concurrent-session files clean. Ancestry eyeball, FF only. **One code commit** (migration + walk + cron + read ship together as the feature; the untracked verify output stays untracked). `verify:deploy` + confirm live: a bill with a House amendment vote now shows the vote line + party split in its AMENDMENTS section (identical rendering to the Senate lines), and a Senate-only bill is unchanged.

## Banked (record in the doc sweep)

- **Full per-member roll-call drill** — still the heavier v2 (v1 ships the partisan *shape* for both chambers now; the who-voted-how list is the expand, `member_votes` has it).
- **`/amendments` aggregate "voted" cut** — now unblocked (both chambers' links exist), so a "reached a recorded vote" filter/column on the HO 461 aggregate is a clean follow-on.

read docs/handoffs/532-house-amendment-votes-walk.md and follow it
