# HO 452 — Probe: amendment `/actions` walk — cost + disposition recovery (gates the status model)

Read-only probe, no writes. The status/disposition model (banked QUEUED) needs the per-amendment `/actions` sub-resource — the HO 447 sync deliberately skips it, taking only the top-level `latestAction`, which is why `latest_action_text` covers just **8.6%** of the corpus. Walking actions for all ~6,788 amendments roughly **doubles the backfill** (~6,800 → ~13,600 requests, ~85 → ~170 min at the sync's 750ms pacing). That's only worth it if the walk actually **recovers classifiable dispositions** for the ~91% that lack a top-level action. This probe measures the recovery rate + the cost, then feeds a GO / NO-GO / reduced-scope call (HO 453).

**The question that isn't obvious:** "no top-level `latest_action_text`" is NOT the same as "no action." The `/actions` list is the full history — a filed amendment with no top-level `latestAction` might still carry a terminal `Motion to table agreed to` / `Amendment withdrawn` / `Amendment agreed to` the top-level field omits. Or it might carry only `Submitted` (genuinely filed-never-acted — vote-a-rama fallout). The probe settles which, and the **`119-sconres-7` vote-a-rama pile is the decisive stratum** (1,131 amendments = 17% of the corpus; if *those* stay "Submitted-only" in the walk, the model helps only the long tail, not the bulk).

---

## Endpoint + fetch

- Actions endpoint (mirrors the bill actions endpoint in SKILL.md): `GET {API_BASE}/amendment/{congress}/{type}/{number}/actions?api_key=…&format=json` → `{ actions: [...] }`. `API_BASE = https://api.congress.gov/v3`, `type` lowercased (`samdt`/`hamdt`).
- **Read-only, self-contained diagnostic** at `scripts/diagnostic/amendments-actions-probe-452.ts`. Mirror `amendments-coverage-447.ts` (dotenv, `createClient`, no writes). Needs `CONGRESS_API_KEY`. Do **not** import/export from `lib/amendments-sync.ts` — mirror a minimal inline fetch (api_key param, `format=json`, a small `sleep` between requests to be cap-polite; the sync's private `fetchJson`/pacing is the reference, not an import — same low-blast-radius posture as HO 447). Time each request for the cost projection.

---

## Sample — stratified, bounded (~155 requests, a couple of minutes)

Pick each stratum from the DB, fetch each one's `/actions`, classify the terminal action. The strata isolate the decision:

1. **`has_top_action` (n=40)** — `WHERE latest_action_text IS NOT NULL`, mixed SAMDT/HAMDT (order by `RANDOM()`). Validates the walk *agrees* with the top-level disposition and *adds* tail detail (does the terminal action match `latest_action_text`? does the walk surface withdrawn/tabled/ruled-out the top-level missed?).
2. **`no_top_action, non-magnet` (n=40)** — `WHERE latest_action_text IS NULL AND amended_bill_id != '119-sconres-7'`, `RANDOM()`. The general recovery question for the silent 91%.
3. **`no_top_action, sconres-7` (n=45)** — `WHERE amended_bill_id = '119-sconres-7' AND latest_action_text IS NULL`, `RANDOM()`. **The decisive stratum** — do the vote-a-rama amendments carry dispositions (tabled/agreed/withdrawn) in the walk, or only `Submitted`? This is the bulk-of-corpus case.
4. **`hamdt` (n=15)** — `WHERE amendment_type = 'HAMDT'`, `RANDOM()` (only 228 exist; House action vocabulary differs from Senate — confirm both classify).
5. **`sub_amendment` (n=15)** — `WHERE amends_amendment_id IS NOT NULL`, `RANDOM()`. Do sub-amendments carry their own independent action history?

---

## What to measure + report

**A. Cost.** Per-request latency (p50 / p90 / max). Project the full walk: 6,788 requests × observed latency at the sync's 750ms pacing → wall-clock estimate, and headroom against the hourly cap (report observed 429s, if any, at the sample's pacing). State it as "adds ~X requests / ~Y min on top of the existing ~6,800 / ~85 min → ~Z total."

**B. Payload structure.** Dump the raw action shape for ~3 amendments. Report which fields the amendment `/actions` objects carry — specifically: a structured `type` and/or `actionCode`, `sourceSystem`, and **`recordedVotes`** (a roll-call vote attached to an action would let a future status model link amendment → vote — flag it as a bonus if present). A structured code beats regex-on-`text` for classification; report the distinct `type`/`actionCode` values seen across the sample.

**C. Recovery rate — the crux.** Per stratum, report:
- The count/% whose action list is **`Submitted`/`Proposed`-only** (no terminal disposition → correctly "pending", nothing to recover) vs. those carrying a **terminal disposition action**.
- The distinct terminal-action `text` (and `type`/`actionCode`) observed, with a proposed disposition for each.
- For strata 2 + 3 especially: **the recovery rate** = of the no-top-level-action amendments, what % gain a classifiable terminal disposition from the walk. This number is the whole decision.

**D. Proposed classification + residual.** Apply a starter classifier (hypothesis to test — refine at build from the residual) and report the split + the unclassifiable remainder:

```
agreed            ← terminal text ~ /agreed to/ or /adopted/ (not "not agreed")
failed            ← /not agreed to/, /rejected/, /motion to table .* agreed to/  (tabling kills it)
withdrawn         ← /withdrawn/
ruled_out_of_order← /point of order/ sustained, /ruled out of order/, /fell/
pending           ← Submitted/Proposed only, no terminal disposition
(residual)        ← terminal action that maps to none of the above — report the raw text verbatim
```
Report each bucket's count and the residual text list — the residual is what tells us whether a clean deterministic map is achievable or whether the tail is messy.

---

## The decision this feeds (HO 453, not this handoff)

- **High recovery** (the walk classifies a large fraction of the silent 91%, *including* sconres-7's vote-a-rama outcomes) → **GO:** build the actions-walk sync extension + a persisted disposition column (+ optional `vote_id` if `recordedVotes` is present) + a one-time backfill; the display-only dot (HO 448/450) upgrades to the persisted enum, and disposition rates unblock the `/amendments` aggregate.
- **Low recovery** (most no-top-level amendments are `Submitted`-only — genuinely filed-never-acted — so the walk adds little beyond the current 8.6%) → **NO-GO or reduced scope:** the top-level scan is already near the ceiling of what's classifiable; a full backfill-doubling isn't justified. Possible cheaper win: walk actions only for the strata that *do* carry dispositions, or accept the display-only dot as the model.

Either way the probe's numbers make the call; don't pre-commit to the build.

---

## Explicitly NOT in 452

- **No writes, no schema, no sync change, no new column.** Read-only diagnostic only.
- **No classifier shipped into `lib/`** — the starter map lives in the probe script as a hypothesis; the real map lands with the build (if GO).

---

## Git discipline

- Plan → diff → **wait for approval.** No auto-commit.
- **Explicit pathspec:** the one file, `scripts/diagnostic/amendments-actions-probe-452.ts` (a reusable diagnostic, sibling to `amendments-coverage-447.ts` / `lda-bill-cost-439.ts`). Commit it on approval, then run it and **report the full findings in chat** — the cost projection, payload structure, the per-stratum recovery table, and the classification split + residual. Those numbers feed HO 453.
- Commit message: `feat(amendments): actions-walk disposition probe (HO 452)`
- Ancestry eyeball before push: one commit riding, clean fast-forward, nothing behind, nothing unrelated staged, the concurrent session's files (`RaceCard.tsx` / `CompetitiveRacesBlock.tsx` / `CompetitiveRacesStrip.tsx` / `globals.css`) untouched and history preserved.

---

read docs/handoffs/452-amendments-actions-probe.md and follow it
