# Handoff 390 — Donor small/large-dollar split on the member hub

Scoped from the HO 388 probe (signed off in chat). Ships the **one clean, honest** donor-breakdown cut that's free on the existing key: FEC Schedule A `by_size` (small-dollar vs large-dollar). The OpenSecrets-style **industry rollup stays PARKED** (it needs an employer→industry classifier — the project HO 65 reverted away from).

## Resolved premises — do not re-derive (from HO 388)

- **`fec_totals` does not exist.** FEC totals live in **`member_fundraising`** (524 rows, cycle 2026, raised + cash-on-hand, 0 null CoH), surfaced on the member hub via `MemberFundraisingLine` + `getMemberFundraising`. The `by_size` block slots in **right beside that line.**
- **The key works from egress** (HO 83) — `FEC_API_KEY ?? CONGRESS_API_KEY` (`lib/fec.ts::fecApiKey`). No new secret, no egress probe needed.
- **`member_donors` / `member_industries` exist but are EMPTY** (reverted-HO-65 scaffolding). `member_donors` is the natural store if you persist; or store the size split in a small new shape — builder's call.
- **Probed live (Schumer `C00346312`, cycle 2026):** `by_size` returns clean buckets — `size=0` (unitemized/small-dollar) = $393k; itemized 200/500/1000/2000. `by_employer`/`by_occupation` work too but are **employer/occupation strings, dominated by NOT EMPLOYED / SELF EMPLOYED / RETIRED / NULL** — NOT industries. **Do not build the industry rollup.**

## Scope

1. **Resolve committee_id per member.** `member_fundraising` stores a candidate-page `source_url` (candidate_id), not a committee_id. Resolve the principal committee via FEC `candidates/search` → `results[].principal_committees[0].committee_id` (the probe used this path). Cache the committee_id (extend `member_fundraising` or a small map) so the daily run isn't re-resolving 524 members each tick.
2. **Fetch `schedule_a/by_size`** per committee, cycle 2026. Collapse to a **small-dollar vs large-dollar** two-value split (e.g. `<$200` unitemized + small buckets vs `$2000` bucket — define the boundary at build; FEC's `size` bucket floors are 0/200/500/1000/2000). Persist as cents (match the existing cent convention).
3. **Render on the member hub** beside `MemberFundraisingLine` — a compact small-vs-large bar or `42% small / 58% large` line. Reuse the same-hue-bar hairline rule if it's one bar.
4. **Wire it onto an existing cron** (the FEC/fundraising sync path — `scripts/sync-fec.ts` / wherever `member_fundraising` is written), **non-fatal try/catch** per the third-party-sync house pattern. No new cron slot.

## Out of scope

- **No employer "top donors" list, no industry rollup** (the classification gap — explicitly parked).
- No new route. This is a member-hub block + a sync extension.
- FEC pagination/rate limits: reuse `lib/fec.ts::fetchJson` (already has 429/5xx backoff + the no-cache-on-transient-failure discipline).

## Acceptance

Member hubs with a resolved committee render a small/large-dollar split sourced from FEC `by_size`; members without a resolvable committee degrade cleanly (no block, no fabricated split — the honest-gap discipline). Cache tag `member-fundraising` (the existing tag); the sync `revalidateTag`s it. Ship: eyeball locally, then `git push && npm run verify:deploy`, report the live SHA.

## If the employer-level question comes back

`by_employer` is shippable **only** with NOT EMPLOYED/SELF/RETIRED/NULL filtered and labeled "top employers, not industries" — a separate, caveated handoff. The industry-classified version has **no free source** post-OpenSecrets (confirmed HO 388) and is a classifier project, not a sync. Don't let it ride in on this one.
