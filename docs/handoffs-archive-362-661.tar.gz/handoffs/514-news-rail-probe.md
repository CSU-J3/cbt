# HO 514 — `/news` rail probe: topic spine cost + member spine cardinality

Read-only. No schema change, no route change, no component. One committed diagnostic under `scripts/diagnostic/`, results pasted back. **Do not build the rail in this HO.**

HEAD going in is `a81535e`. Next HO number is 514 (roadmap pointer reads 512; the sweep itself was 513).

## Why this exists

The backlog's `/news` spine item named SOURCES as the rail. That's dead on inspection — `NEWS_SOURCES` has three entries, and the three shipped rails carry 24 / 79 / ~200 rows. Three rows is the SOURCE chip row already in `NewsFilters`, relocated. So the rail gets respec'd onto one of two axes, and this probe measures both **before** either is designed:

- **Axis A — TOPIC spine (24 rows).** Scopes the existing mention feed in place. Parity with `/bills`. `?topic=` already exists.
- **Axis B — MEMBER spine ("who's in the news").** Off the HO 394 observation layer. Selecting a member swaps the pane to the feed HO 512 shipped.

The intended sequence is A, then B as a **second group inside the same rail** (the `/lobbying` precedent — one rail, multiple sections). That only holds if B has real cardinality, so B's number has to land before A's component boundaries are drawn, not after. Hence one probe, two questions.

## Question 1 — Axis A cost

The rail needs per-topic mention counts, rebased on the other active dims (`source` / `window` / `signal`), self-excluding on `topic` (the HO 496 rule: a rail that applies its own clause collapses to one row).

Shape is `news_mentions m INNER JOIN bills b` + `json_each(b.topics)` GROUP BY. Two things make it non-obvious and both must be measured **cold**, not warm, not from `EXPLAIN` alone (HO 340's standing lesson: a clean `EXPLAIN` says nothing about cold latency):

1. **The OR-lure.** `getNewsFeed` already carries `INDEXED BY idx_news_mentions_published` on its windowed form precisely because the stateless planner otherwise drives from the 16.8k `bills` side via `idx_bills_is_ceremonial` — the HO 332/405/407/479–481 MULTI-INDEX-OR class. The ceremonial predicate is in the base WHERE here too. Report the plan **with and without** the hint, cold both ways.
2. **`json_each` on the aggregate side.** HO 461 hit residual temp-btrees on a `json_each` GROUP BY and accepted them (the Q6 precedent). Confirm whether the same residual appears and whether it matters at this corpus size.

Measure across the realistic dim combinations, not just the bare case: bare; `?source=politico`; `?window=24` and `?window=720` (the extremes — 720h is the one that stops being selective); `?signal=breaking`; and one stacked combo. Report cold ms per combination and the plan line for each.

Also report **corpus size**: `COUNT(*)` on `news_mentions`, plus the count inside the 720h window. The SKILL still quotes "the 227-row `news_mentions` side" from HO 335 — that figure is over a year stale and is exactly the kind of logged number that gets treated as fact. Re-measure it; if the table has grown an order of magnitude the live-vs-precompute call changes.

**Verdict A wants:** live-servable (like `/bills`' `getBillTopicRailCounts`) or not, and whether it needs a hint, a new index, or neither.

## Question 2 — Axis B cardinality

The number that decides whether B is worth sequencing at all. Off `observation_entities` (`entity_type='person'`) joined to `observations`:

- **How many distinct bioguides carry ≥1 observation?** Then the distribution: how many carry ≥3, ≥10, ≥25. A rail needs a populated head *and* a tail worth scrolling; if it's 40 members total, B collapses and A is terminal.
- **The head itself** — top 20 bioguides by observation count, hydrated to names via `members`. Eyeball whether it reads as a real "who's in the news" list or as an artifact of the matcher (e.g. leadership names appearing in every article boilerplate).
- **Recency shape** — the same counts restricted to the last 7d and 30d. A rail scoped to the page's window needs to still have rows in it at 24h. If the 24h head is three members, the rail needs its own window semantics, which is a design constraint worth knowing now.
- **Cold cost** of the rollup + name hydration, same discipline as Q1. `idx_obs_entities_type_value` should drive it; confirm it does.
- **Coverage sanity:** what fraction of `person` entity rows resolve to a live `members` row? HO 398's known edge is non-incumbent challengers having no bioguide; this is the members-side equivalent check.

**Verdict B wants:** a GO / COLLAPSE call on whether a member rail group has enough rows to be a spine rather than a top-5 list, plus whether it needs its own window.

## Non-goals

- No build, no rail, no CSS, no `NewsFilters` change.
- No new index. If the probe finds one is needed, that's a finding for the build HO, not a migration to ship here.
- Don't touch `getNewsFeed` or `getMemberNews`.
- Don't re-litigate the SOURCE spine — it's dead, the probe doesn't need to prove it again.

## Deliverable

`scripts/diagnostic/news-rail-probe-514.ts`, read-only, committed on its own. Paste back: corpus counts, the Q1 cold table (combination × ms × plan line, hinted and unhinted), the Q2 distribution + top-20 head + recency cuts, and a plain-language verdict on each axis. Flag anything that contradicts a premise in this handoff — the HO 479 precedent is that a probe refuting its own brief is the probe working.

## Process

Diagnostic commits are inert, so summary approval is fine for the diff. Separate commit from anything else; nothing else rides.
