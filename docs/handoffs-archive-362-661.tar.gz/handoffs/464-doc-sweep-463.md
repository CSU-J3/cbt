# HO 464 — doc sweep: record HO 463, reconcile stale QUEUED

Doc-only, no code. Its own commit (two-commit rule: docs separate from the HO 463 feature). Both `docs/roadmap.md` (append-only) and `docs/backlog.md`.

Fill in the HO 463 commit SHA from the commit you just made (shown as `<463-SHA>` below).

## 1. `docs/roadmap.md` — append the HO 463 note (append-only)

Add a new `Also` block after the current last one (the HO 461 `/amendments` aggregate block), and **bump the running pointer** from `Also notes now run through HO 461` → `HO 463`. Do **not** retro-edit the HO 461 block (append-only; HO 418 precedent).

Block to add:

> **Also (HO 463), the `/lobbying` topic-crosswalk click-through — the HO 444 crosswalk made interactive, no theme-% change.** The BY-CBT-TOPIC bars (HO 444) were non-interactive in v1; HO 463 (`<463-SHA>`) turns each into a `<button>` that expands inline to its constituent LDA issue codes, each chip a `<Link>` into the **existing** Section 2 `?issue=` drill — scrolling it into view via a plain `#lobby-drill` hash (Next 15.5 honors it on soft-nav; no `scroll={false}`/`onClick` workaround needed). **No chip can land on a blank:** `drill[code]` is built uncapped over every corpus code (`computeIssueRollup` loops all of `uuidsByCode`), so every constituent code has a real drill. Page-side grouping of `rollup.issues` keys on the **same `topicForCode`** `computeTopicCrosswalk` uses, so the chips align exactly with the bar totals — no double-count seam. `TopicCrosswalk` became a `"use client"` island (instant expand; client state persists across the `?issue=` soft-nav, so the open topic survives a chip click). **No new data layer / blob / query / cron / migration / nav** — a UI pass over data already in the page. **No theme-% change** — a v2 interaction refinement on the LDA `/lobbying` surface (the `/patterns` class), matching the LDA-arc precedent. Docs: HO 464. **Also notes now run through HO 463.**

## 2. `docs/backlog.md`

**a. Tombstone the shipped QUEUED item.** Strike through the QUEUED bullet:

> **`/lobbying` topic crosswalk — click-through to constituent codes (HO 444 v2).** …

→ mark `SHIPPED HO 463 (`<463-SHA>`)` and add a DONE tombstone (append-only) recording: topic bars now expand to their constituent LDA codes, each drilling into the existing `?issue=` per-code drill; client island, plain-hash scroll, no new data layer; verified across Healthcare/Other/collapse/sub-breakpoint.

**b. Reconcile the stale QUEUED item.** The QUEUED bullet:

> **Standalone `/amendments` aggregate surface** — the follow-on fork off the HO 447 amendments layer (HO 448 shipped the bill-hub section). …

is **stale** — it shipped at **HO 461** (`e96f0ab`, `/amendments` aggregate + nav) and the roadmap Status block already records it, but this QUEUED entry was never struck. Strike it through → `SHIPPED HO 461 (`e96f0ab`)`, point to the existing roadmap `Also (HO 461)` record + the DONE tombstone if present (add one if not). QUEUED should stop listing built work.

**c. New FIT & FINISH entry (low).**

> **`FilingRow` duplicate `key` warning (HO 463)** — opened Jul 2026; *Owner:* Code, low. `components/FilingRow.tsx:76` renders `key={id}` where `id` can collide, producing a React duplicate-key warning on `/lobbying` (surfaced during HO 463 CDP verification). Pre-existing, unrelated to HO 463, and left untouched there per the no-FilingRow-changes boundary. *Close:* dedupe the key (composite or index-suffixed) on the next `FilingRow` touch — not worth its own commit.

## Commit

One doc-only commit, explicit pathspec (`git add docs/roadmap.md docs/backlog.md`), no glob. Show the diff, wait for approval, ancestry eyeball before push.

Suggested message:
```
docs(sweep): record HO 463 + reconcile stale /amendments QUEUED (HO 464)
```

---

read docs/handoffs/464-doc-sweep-463.md and follow it
