# HO 642 — dashboard chrome batch

**Ground truth:** fresh clone at `0d27b1b`. Roadmap's latest pointer is HO 641, so this is **642**.
**Type:** build + one read-only probe. No roadmap block, no SKILL edit, no backlog line — those ride the doc sweep that closes this arc.

Five owner asks off a live dashboard read. Four are presentational and land together; one changes a fetch constant; one needs a measurement before its UI can be specified at all. Two further asks (the MIA photo strip, the primaries/competitive merge) are **explicitly deferred** — see §7 for why and what unblocks them.

---

## §0 — Commit plan

| # | Commit | Scope |
|---|---|---|
| A | `fix(HO 642): dashboard chrome — polarization cut, breaking hover, feed title, MIA name face` | §1 §2 §3 §4 — CSS + two prop removals |
| B | `fix(HO 642): three competitive races per chamber` | §5 — one constant + a measured guard |
| C | `feat(HO 642): chamber selector on the dashboard feed panel` | §6 — wiring + two query signatures |
| P | `chore(HO 642): absence at-risk threshold probe` | §8 — read-only, no product code |

Standing rules for all four: explicit pathspec staging (**never `git add .`**), `npm run typecheck` before every push, ancestry eyeball before every push (HEAD is the SHA you expect, the commit rides as a linear fast-forward on `main`), no force-push. Docs and code never ride in the same commit; the probe never rides with a build.

Do not start B until A is pushed and green. C is independent of both.

---

## §1 — Cut the polarization chip from the dashboard

**Ask, verbatim:** *"Week of and Polarization bar. remove the Polarization, that should only show in the members page."*

It is not a bar any more. HO 608 killed the full-width `PolarizationBand` and folded its numbers into `WeeklyBand.tsx` as an inline `PolarizationChip`. That fold is what's being reversed.

**`components/WeeklyBand.tsx`**
1. Delete the `PolarizationChip` function (the whole block including its HO 608 header comment — that comment documents the fold, and leaving it above nothing is a lie for the next reader).
2. Delete `<PolarizationChip band={band} />` from the returned JSX.
3. Drop the `band` parameter from `WeeklyBand`'s signature; the component now takes no props.
4. Drop `import type { PolarizationBand } from "@/lib/queries"`.

**`app/page.tsx`**
5. Remove `getPolarizationBand` from the `@/lib/queries` import list.
6. Remove `getPolarizationBand()` from the `Promise.all` array and `polarization` from the destructure. Keep every other element in place and in order.
7. `<WeeklyBand band={polarization} />` → `<WeeklyBand />`.
8. Rewrite the comment above it. It currently narrates the HO 608 fold as live. Replace with: the band was cut at HO 424→608, the chip that survived it was cut at 642 on an owner ruling that ideology belongs to `/members` only, and `/` no longer reads `getPolarizationBand` at all.

**`app/globals.css`**
9. Delete `.weekly-band-polchip`, `.weekly-band-polchip b`, `.weekly-band-polsep`, `.weekly-band-polchip a`, `.weekly-band-polchip a:hover` (contiguous block around :3301–3324). Verified: `WeeklyBand.tsx` is their only consumer, so they orphan the moment step 2 lands. Delete them here rather than filing them — this is the feature's own CSS, not a shared token, and an orphan sweep should not have to rediscover it.

**Do NOT touch `getPolarizationBand` in `lib/queries.ts`.** `app/members/page.tsx:132` reads it, and `PolarizationOverTime` documents the registration-vs-caucus seam against it. Removing the dashboard's call removes one `unstable_cache` consumer, not the query.

**Check:** `grep -rn "PolarizationBand\|polarization" app/page.tsx components/WeeklyBand.tsx` returns nothing. `/members` still renders its three ideology surfaces.

---

## §2 — The MIA names are not Comic Sans, and the fix is the same either way

**Ask, verbatim:** *"MIA is still in comic sans"*

**Read this before editing.** I cropped and upscaled the screenshot. `▲ MIA` in `.abw-title` is genuine mono and is fine. The complaint is the **member names**:

```css
.abw-name {
  color: var(--text-primary);
  font-size: var(--fs-13);
  font-weight: 600;      /* ← no font-family, so this inherits --font-mono */
  ...
}
```

`--font-mono` is `ui-monospace, "JetBrains Mono", "SF Mono", SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace`. On Windows/Chrome the first entries don't resolve and it lands on **Consolas**, which ships no 600 weight — so the browser **synthesizes** a faux-bold. Synthesized Consolas bold is chunky and rounded, and that is what reads as Comic Sans.

**State the mechanism as a hypothesis, not a finding.** It is unfalsified, not proven: it depends on which mono resolves on the owner's machine, and a DevTools rendered-font read on your box measures your box. The fix below is correct regardless of which mono wins, because it removes the synthesis on *every* machine. **The falsification is the owner's eyeball** — if it still reads wrong after this ships, the premise was wrong and the next step is a `CSS.getPlatformFontsForNode` read on the owner's browser, not another guess.

**`app/globals.css` — `.abw-name`:**
```css
.abw-name {
  font-family: var(--sans);
  font-weight: 500;
  /* HO 642 — was an unfamilied 600, so it inherited --font-mono and asked
     Consolas (the Windows resolution of that stack) for a weight it does not
     ship; the browser synthesized it. 500 is a REAL loaded Plex face (HO 633
     loads 400/500/600), so no synthesis on any platform. The family move is
     also the HO 297 rule applied where it always belonged: sans for names and
     prose, mono for chrome. .v2f-title already reads a bill title this way. */
  color: var(--text-primary);
  font-size: var(--fs-13);
  white-space: nowrap;
  text-decoration: none;
}
```

Leave `.abw-title`, `.abw-claim`, `.abw-ev` and `.abw-party` on mono — those are chrome, and HO 297's split is exactly this line.

---

## §3 — Breaking hover: cut the dim and the drop shadow

**Ask, verbatim:** *"remove the shadow over the bills when hovering over breaking"*

Two things put a shadow over the bills. Cut both.

**`app/globals.css`**
1. Delete this rule outright (around :830):
```css
.dash-page:has(.breaking-row:hover) .dash-bills {
  opacity: 0.4;
  transition: opacity 120ms ease;
}
```
This is the one the ask is about — hovering a breaking row drops the whole MOVERS column to 40% and reads as a shade thrown across it. Delete the rule and its HO 178 lineage comment together; a comment describing a cross-column overrun-dim that no longer happens is worse than no comment.

2. In `.breaking-row-full`, delete only this line:
```css
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.5);
```
**Keep `background-color: var(--bg-row-hover)` and `border: 1px solid var(--border-strong)`.** `--bg-row-hover` is `#0f1620`, fully opaque, so the overlay stays legible over undimmed content on its own — which is the property that has to hold now that step 1 removed the dim it used to rely on. Confirm that by eye at a row whose headline overruns into the distributions panel; if it doesn't read cleanly, the fix is a stronger border, not a restored shadow.

**Do NOT touch** `.home-grid:has(.breaking-row:hover) .home-col-right` (around :994). It is the pre-608 twin and `.home-grid` / `.home-col-right` have zero TSX consumers, so it is already dead — but dead-CSS removal is an orphan sweep, and orphan sweeps do not ride inside a behaviour commit. Leave it and say so in the report so it can be picked up with the `DashboardTopicTreemap` / `V2FeedList` chore.

---

## §4 — Feed title reads too heavy

**Ask, verbatim:** *"the bill name text looks to bold"*

**Measure first — this is a one-line check and it can make the rest unnecessary.** With the dashboard open, read:

```js
const t = document.querySelector('.v2f-title');
const s = getComputedStyle(t);
console.log(s.fontWeight, s.fontFamily, s.fontSize, s.color);
```

Report the four values verbatim before editing.

- **If `fontWeight` > 400**, something upstream is setting it, that is the whole defect, and the fix is to find and remove that rule. Stop and report; do not apply the block below on top of it.
- **If `fontWeight` is 400** (expected — `.v2f-title` sets no weight and nothing in the chain does), the weight is already minimal and the perceived heaviness is contrast: `--text-primary` `#e5e7eb` on `--bg-panel` `#050709` at `--fs-14`, in a sans face surrounded by dim mono. Apply:

```css
.v2f-title {
  display: block;
  font-family: var(--sans);
  font-size: var(--fs-14);
  /* HO 642 — explicit, so the next reader doesn't have to walk the chain to
     learn this was never bold. The perceived weight was contrast, not weight:
     stepping --text-primary -> --text-secondary is the lever that moves on
     Windows. Smoothing is a MacOS/Retina-only thinner and a no-op on Windows —
     it is here for the machine this project is moving to, and it is not the
     fix. */
  font-weight: 400;
  color: var(--text-secondary);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
```

**C3 still holds.** The row's line 2 is `--text-dim` `#6b7280` and the id chip is amber; at `--text-secondary` `#cbd5e1` the title remains the brightest element in the row. Amber is a colour cue, not a brightness competitor.

**Leave `.title-pop` on `--text-primary`.** It is a popover on an explicit hover, where full brightness is correct, and matching it here would be consistency for its own sake.

---

## §5 — Three competitive races per chamber (commit B)

**Ask, verbatim:** *"can we adjust the races competitive to fit better? or combined primaries tab with competitive?"*

**The mechanism, measured.** The dashboard renders `variant="v2"`, which takes `CompetitiveRacesStrip`'s early-return branch into `.race-grid` — **not** `.competitive-races-grid`. `.race-grid` is:

```css
grid-template-columns: repeat(auto-fit, minmax(min(400px, 100%), 1fr));
gap: 14px;
```

At a `.dash-left` of ~1370px that resolves to **3 columns**. `PER_CHAMBER = 2` gives **4 cards**. 4 into 3 leaves one card alone on row two with two thirds of the row empty — the hole in the screenshot.

**The fix is the card count, not the grid.** 6 divides by 1, 2 and 3 — every column count `auto-fit` resolves to at the widths this panel actually renders at. Widening to a flat 2×2 would trade the hole for four ~680px cards, which is C8's failure mode (wide screens buy columns, not wider rows). Six cards keep their designed ~450px, fill both rows, and the panel carries more seats.

**`components/CompetitiveRacesBlock.tsx`**
```ts
const PER_CHAMBER = 3;
```
Update the HO 163 comment above it: the Senate-led 2+2 mix becomes 3+3, and the reason is that the grid resolves to 2 or 3 columns and 6 is divisible by both while 4 is not.

**Two guards, both measured, both blocking.**

**G1 — the partition has to be deep enough.** `POOL = 30` is a competitiveness-ordered pool and the existing comment says top Senate seats sit ~rank 20 behind House toss-ups. That was sized for 2. After the change, assert at runtime during dev that `senate.length === 3 && house.length === 3`. If either is short, raise `POOL` until both fill and record the value you landed on and why. Do not ship a silently 5-card panel — it re-creates the orphan under a different cause.

**G2 — the column count has to be 2 or 3.** Before committing, measure at three viewport widths (1440, 1920, 2560), on the RACES tab:

```js
const g = document.querySelector('.race-grid');
console.log(window.innerWidth,
  getComputedStyle(g).gridTemplateColumns.split(' ').length,
  document.querySelector('.dash-left').getBoundingClientRect().width);
```

Report the three readings. **If any width reports 4 columns, 6 cards orphan again** (4+2) — in that case add an explicit cap:
```css
@media (min-width: <the width where it went to 4>) {
  .race-grid { grid-template-columns: repeat(3, minmax(0, 1fr)); }
}
```
and say in the commit message which reading forced it. Do not add the cap pre-emptively; a media query nothing fires is the same-as-success shape.

**G3 — eyeball the battlefield.** `Battlefield` takes `featuredIds={races.map(...)}` and renders each featured seat as a labelled dot on one lean axis. Six labels instead of four may collide. Look at it. If labels overlap, **report it and stop** — do not fix it inside this commit; it is a separate sizing decision.

**Not in this commit, and stated so it isn't inferred:** the COMPETITIVE|PRIMARIES sub-tabs stay. See §7.

---

## §6 — Chamber selector on the feed panel (commit C)

**Ask, verbatim:** *"also need a selector for hou and sen"*

Better starting position than it looks: `FeedFilters.chamber` already exists (`lib/queries.ts:193`) and `buildFeedWhere` already emits `bill_type IN (…)` off `HOUSE_BILL_TYPES` / `SENATE_BILL_TYPES` (:184–185). `buildChangesWhere` spreads its `FeedFilters` straight into `buildFeedWhere`, so MOVERS and TOP STALLS need **no query work at all** — only a populated first argument.

### 6a — URL param

**`app/page.tsx`**
- `searchParams` type gains `chamber?: string`.
- `const chamber = sanitizeChamber(sp.chamber);` — `sanitizeChamber` already exists at `lib/queries.ts:327`; add it to the import list. Copy the call shape from `app/bills/page.tsx:146`.
- `chamber` is **feed-panel scope only**. It does not enter `DashboardFilters`, does not touch `WeeklyBand` (a whole-Congress week strip), does not rebase BREAKING or the distributions. Write that as a comment where `chamber` is derived, because a URL param that reshapes only one panel is surprising and the next reader will otherwise "fix" it.

### 6b — Thread it

- `activityCount`: `getStageChangesCount({ chamber }, 7, filters)`
- `newCount`: `getNewBillsThisWeekCount(chamber)`
- `<ActivityTicker chamber={chamber} … />`, `<TopStalls chamber={chamber} … />`, `<NewThisWeek chamber={chamber} … />`

**`components/ActivityTicker.tsx`** — new `chamber?: Chamber` prop:
```ts
getStageChanges({ chamber }, 7, CAP, filters)
getStageChangesCount({ chamber }, 7)
```
**Both calls, not one.** `remaining = counts.total - bills.length` drives the `[ + N more → ]` footer; filtering the rows while the count stays corpus-wide makes that number silently wrong and clamps it at 0 once the count drops below the rendered rows. That is the HO 637 Group A coupling, and this is the same arithmetic. (Note for the report, not for fixing here: that coupling is **already** loose for `stage`/`topic` — the feed takes `filters`, the count doesn't. Pre-existing, out of scope, worth a backlog line.)

**`components/TopStalls.tsx`** — new `chamber?: Chamber` prop → `getStaleBills({ chamber }, ROW_LIMIT)`.

**`components/NewThisWeek.tsx`** — new `chamber?: Chamber` prop → `getNewBillsThisWeek(ROW_LIMIT, chamber)` and `getNewBillsThisWeekCount(chamber)`.

### 6c — Two query signatures

`getNewBillsThisWeek` and `getNewBillsThisWeekCount` take no filters. Give each a trailing `chamber?: Chamber` and append, when set:
```sql
AND bill_type IN (…HOUSE_BILL_TYPES or SENATE_BILL_TYPES…)
```

Three constraints, all load-bearing:
1. **Both move in the same edit.** `getNewBillsThisWeek`'s own comment says its predicate is exactly `getNewBillsThisWeekCount`'s so the tab label can't drift from the rows. Changing one is the drift that comment exists to prevent.
2. **Keep `INDEXED BY idx_bills_introduced_date` and the `introduced_date` constraint.** The forced hint is only safe while the WHERE constrains that column (HO 246). Adding a `bill_type` predicate doesn't disturb that — removing the date clause would.
3. `chamber` is part of the `unstable_cache` key, so `house` / `senate` / undefined are three entries per query. Priced deliberately: 6 new entries across the three feeds and their counts, warm after first toggle, and the other ~12 dashboard queries keep their existing keys because they never see `chamber`. This is a bounded add to the Turso read budget, not an unbounded one.

### 6d — The control

Server-rendered `<Link>`s, so the toggle is real navigation and the state is shareable. Build the hrefs in `app/page.tsx` — copy `chamberHref` from `app/bills/page.tsx:219–224` (it preserves the other params and deletes the key on the empty option). Pass the rendered node into `ActivityTabs` as a new `filterSlot?: ReactNode` prop and render it **inside** the existing `.search-tabs.breaking-stalls-tabs` nav, after the three tab buttons, separated by a dim `·`.

Conventions: packed left, no far-right anchor (**C1** — the toggle must sit against the last tab, not float to the panel's right edge). Three options `All | House | Senate`, active one in `--accent-amber-bright`, inactive `--text-dim`. Reuse existing token sizes; no new CSS variables.

**`components/ActiveFilterStrip.tsx`** — new `chamber?: Chamber` prop:
- `× Clear` currently hrefs bare `basePath`, which would silently drop a chamber selection while clearing a stage. Make it `chamber ? \`${basePath}?chamber=${chamber}\` : basePath`.
- `View in /bills →` should carry `chamber` into `feedParams` — `/bills` reads the same key.
- The `if (!stage && !topic) return null` early return **stays**. Chamber alone renders no strip; the selector shows its own state, and a strip for it would be C5 (the same fact twice).

`StageFunnel` and `TopicDistributionList` need **no change** — both build from `new URLSearchParams(params.toString())`, so they already carry `chamber` through a stage or topic click. Verify that by clicking a funnel bar with `?chamber=senate` set and confirming the param survives.

---

## §7 — What this HO deliberately does NOT do

Both are real asks. Both are redesigns, and this repo's precedent for reshaping a panel is a committed mock first (HO 631, 632, 633). Neither belongs inside a chrome batch.

**The MIA photo strip.** *"could we uses there photo instead of just words? might free up some room. and i would like to add the ppl who are in danger of being MIA."*

`SponsorPhoto` exists and is already a client component, so `AbsenceWatchRows` can import it directly. But a photo on a full-width row makes the row **taller**, not shorter — the version that frees room is turning the band from stacked full-width rows into horizontal member chips (small photo + name + streak) that wrap, which is a rewrite of the row anatomy HO 621 ruled and HO 630/631 built. HO 631's overlay card is anchored to the **band**, not the row, so the expand survives that rework untouched — which is why the rework is cheap once it's ruled. It needs a mock and it needs §8's numbers first.

**The primaries/competitive merge.** The sub-tab split is what reserves `.races-panel-body { min-height: 240px }` — a C4 reserved box — and merging would retire `RacesPanelTabs` entirely. But `DashboardPrimaries` currently renders a timeline plus four date-group cards in a 2×2 plus a footer link; stacking that under six race cards makes the RACES panel ~950px tall. The merge only pays if the primaries rollup compacts to roughly one row, and what survives that compaction is an owner call on a mock, not a build instruction. §5 removes the visible defect without it.

---

## §8 — Probe: absence at-risk thresholds (commit P, read-only)

The "in danger of MIA" tier cannot be specified yet, because the current query **cannot see those members at all**. `queryAbsenceWatch`'s Phase A is:

```sql
WHERE vote_id IN (<most recent ABSENCE_WINDOW = 30 rolls>)
GROUP BY bioguide_id
HAVING nv = n AND nv > 0
```

A member on a 15-roll streak fails `nv = n` over 30 rolls and never becomes a candidate. Phase B's exact streak walk never runs for them. So the tier needs Phase A widened, and widening Phase A grows the candidate set that Phase B walks against `ABSENCE_WALK_BOUND = 120` rolls — a cost that must be measured before it is committed to, not after.

**Write `scripts/diagnostic/absence-atrisk-642.ts`.** Read-only. Model it on `scripts/diagnostic/absence-watch-588.ts` — **read that probe and its output first**; do not reconstruct the population carve from memory. The carve is `is_current = 1`, `total >= PARTICIPATION_FLOOR`, and House delegates excluded (`state IN ('DC','AS','GU','MP','PR','VI')`), and it must match `getParticipationStrip` exactly.

For **WARN ∈ {10, 15, 20}**, per chamber and pooled, report:

1. Phase A candidate count at that window.
2. After the Phase B walk, the **streak distribution** of candidates: how many land in `[WARN, 30)` (the at-risk tier) and how many at `>= 30` (the existing MIA tier).
3. The names, streaks, `lastCastDate` and `missedPct` for the `[WARN, 30)` set at each threshold.
4. How many hit `atBound` (walk exhausted at 120 without observing a cast vote).
5. **Cost:** total statements and `rows_read` for the whole probe, and the Phase B row count at each WARN. Predicate every count (`WHERE … IS NOT NULL`); a bare `COUNT(*)` is answered from B-tree interior pages and under-reports by 227–416× — the HO 624 M0 trap.

**Ruling criteria, fixed here before the numbers exist so they cannot be fitted to the result:**
- A WARN threshold is **viable** if the pooled `[WARN, 30)` set is **≤ 6 members**. Above that the at-risk tier outnumbers the MIA tier and the band stops being an alarm.
- Phase B cost is **acceptable** if `rows_read` at the chosen WARN is within **2×** the current WARN-equivalent (i.e. the shipped 30-roll window's Phase B read).
- If no threshold in {10, 15, 20} satisfies both, report that, and do not extend the sweep on your own — the rule shape is the owner's call, and this is already tangled with the open S=30 threshold review that is gated on the House returning from recess.

Push P on its own commit. **No product code, no UI, no CSS.** Paste the numbers back in chat.

---

## §9 — Verification

Before pushing each commit:
- `npm run typecheck` clean.
- `git status` clean of anything you didn't intend to stage; explicit pathspecs only.
- Ancestry eyeball: HEAD is the SHA you expect and rides linear on `main`.

After A and B are deployed, check `/api/version` to confirm the deploy is live before believing any visual verification — the Vercel Data Cache survives deploys and `unstable_cache` values converge on their own schedule. §6's chamber variants are new keys, so their first read is always a miss; hit each option until the value converges and holds rather than trusting a first render.

Report back with: the four `.v2f-title` computed values from §4, the three `.race-grid` readings from §5 G2, the G1 `POOL` value if you had to raise it, the G3 battlefield eyeball, and the §8 probe numbers.
