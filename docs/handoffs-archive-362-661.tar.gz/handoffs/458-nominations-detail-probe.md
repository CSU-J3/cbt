# HO 458 — Nominations detail probe: part-specific detail shape + civilian committee-referral re-measure + hydration cost

The QUEUED nominations committee cross-link — the probe half. HO 455/456 shipped the pillar **list-only** and deferred the one detail-only join: `committee_system_code` sits in the schema NULLABLE, populated by "a later detail-hydration HO." This is that HO's probe.

Probe-first for the same reason every prior pillar was (434→435, 446→447, 454→455): the cross-link rides a cold query that's **never been measured at civilian scale on the correct record.** The 454 source probe *did* tally a civilian referral rate — but it fetched `/nomination/{congress}/{number}` (the **base** record), and HO 455 then established that for a multi-part PN the base endpoint returns a **different record** than the part-keyed row (citations are `PN{number}-{partNumber}`; the composite key is `(pn_number, part_number)`). So the 454 civilian number is confounded: it may have read referral off the parent aggregate, not the record the surface will link. This probe re-measures on whatever record actually corresponds to the part-keyed row, civilian-only, at real scale — and prices the hydration walk. Read-only. Returns **GO/NO-GO for the cross-link** plus the shape facts that scope HO 459 (the detail-hydration sync + the `/committees/[id]` section).

Sibling to `scripts/diagnostic/nominations-source-probe-454.ts` — copy its harness (inline `fetchJson` 429-backoff + 120ms pace, own `@libsql/client`, `getCurrentCongress()`, the `committees.system_code` set load). Seed from the **already-populated `nominations` table** (ground truth, no full re-paginate).

---

## The three questions (in order — each depends on the one above)

### Q1 — part-specific detail shape (settle this FIRST; everything else hangs on it)

The build must populate `committee_system_code` **per row**, and rows are `(pn_number, part_number)`. So: for a **multi-part** civilian PN, where does the part's committee referral live, and is there one record per part or one shared record?

Resolve definitively, the way 446 settled the amendments self-FK before 447 built:

- **Single-part PN** (`part_number = "00"`): confirm `/nomination/{congress}/{number}` (base) carries the referral and is the correct record for the row. (For single-part it *is* the row — expected clean, but confirm the `committees` field is present here.)
- **Multi-part PN** (several stored rows, e.g. a batched ambassador/US-Attorney list or a split resubmission): the decisive test. Each stored row's `raw_json` carries a `url` (the 454 `ListItem` had `url?: string`). **Follow each part-row's own `raw_json.url`** and compare against the base `/nomination/{congress}/{number}`:
  - Do the per-part `url`s return **distinct** records (distinct `citation`, distinct/own `committees`), or do they all collapse to the base?
  - Where does the referral actually sit — per-part, or PN-level (shared across parts, only on the base)?
  - Is `committees` **embedded** in the detail JSON, or a sub-resource `{count, url}` (the 454 probe handled both)? This sets fetches-per-PN → the hydration cost and the sync's fetch shape.

The clean outcome: each part-row's stored `raw_json.url` resolves to the record whose referral belongs to that row, so hydration is "follow the stored url." If instead referral is only PN-level (base), the hydration keys on `pn_number` and every part-row of a PN shares one code — also fine, just a different populate rule. **The probe decides which; don't assume.**

**Also report the wrinkle's blast radius:** the `part_number` distribution across civilian rows — `SELECT part_number, COUNT(*) FROM nominations WHERE is_military=0 GROUP BY part_number ORDER BY 2 DESC`, plus the count of *distinct civilian PNs that have >1 part*. If ~all civilian rows are single-part `"00"`, the multi-part path is a small tail and Q1 mostly confirms base-is-fine; if multi-part is common, it's load-bearing.

### Q2 — civilian committee-referral resolution (the GO/NO-GO)

Measured on the **correct** record from Q1, **civilian-only** (`is_military = 0`), at a real sample. Report:

- **Referral presence:** % of sampled civilian PNs (or part-rows, per Q1's keying) that carry ≥1 committee referral. (Some civilian nominations are privileged / discharged without committee — expected non-100%; quantify it.)
- **Resolution against tracked `committees`:** of those with a referral, % whose `systemCode` is in the `committees.system_code` set. These are Senate committees (`ss*` — Judiciary `ssju00`, Foreign Relations `ssfr00`, Armed Services `ssas00`, Finance `ssfi00`, HELP, Banking, Commerce, …).
- **The distinct referral committees seen**, with counts, and — **flag any `systemCode` that does NOT resolve** (a Senate committee referred-to but absent from the tracked `committees` set → a coverage gap the cross-link would silently drop). Note whether unresolved codes look like real Senate committees (a `sync:committees` gap) vs. malformed.
- **Cardinality:** is referral 1:1 (one committee per nomination — typical) or do some carry sequential/multiple referral? (Sets whether `committee_system_code` stays a single column or the cross-link needs a link row — I expect single, but confirm.)

**This is the decision.** Clean GO ≈ referral present on most civilian PNs and resolving ≥~90% against tracked committees. Reduced/NO-GO ≈ referral sparse, or codes don't resolve (untracked committees / format mismatch). Make the call cheap here like it was for the amendments status model.

### Q3 — hydration cost (mechanism-setter)

The sample IS the cost probe — time every fetch. Report:

- **Fetches per civilian PN:** 1 if `committees` is embedded in the detail; 2 if it's a sub-resource `url` (from Q1).
- **Measured per-fetch latency** (mean + p90) over the sample, on real Congress.gov egress.
- **Projected wall-clock** for the full **~830-civilian** hydration = 830 × (fetches/PN) × mean, plus the 120ms pace.
- **Verdict:** does it fit a CLI `sync:nominations --hydrate` backfill (minutes — fine), and/or a deadline-gated cron step (does the incremental delta fit the 300s route)? This scopes HO 459's mechanism (CLI-driven backfill like the LDA/amendments precedent, vs. cron-chunked).

**Rider, secondary, not the decision:** the schema's other detail-only column is `nominee_count` (military officer count). It's orthogonal to the cross-link (committees is all the `/committees/[id]` section needs), but it rides the same detail walk. While hydrating the civilian sample, note in passing whether military PN details expose a clean `nomineeCount` (the 454 probe saw the `nominees` `{count,url}` shape) — one sentence, so the 459 build can decide whether to fold military nominee-count into the same walk or leave it deferred. Do **not** walk the ~1,051 military PNs in this probe.

---

## Method

- **Seed civilian PNs from the DB:** `SELECT id, pn_number, part_number, organization, raw_json FROM nominations WHERE is_military = 0`. Parse `raw_json` for the per-row `url`.
- **Sample ~150 civilian PNs**, deterministically spread across `organization` (even step, no RANDOM — the 454 `pick()` idiom), and **force-include every multi-part civilian PN** (or a good sample if many) so Q1's multi-part test has real cases. 150 of ~830 is ~18% — enough for the resolution rate to be honest and the latency projection stable.
- **For each sampled PN:** follow the base `/nomination/{congress}/{number}` AND the row's `raw_json.url`; dump the **first 2 single-part and first 2 multi-part** raw details (truncated ~2.5k) so the record-shape question is answerable from the log, not just the tallies. Tally referral presence / resolution / distinct committees / cardinality; time each fetch.
- **Committees set:** `SELECT system_code FROM committees` → `Set` (the 454 load).
- Congress via `getCurrentCongress()`. `CONGRESS_API_KEY` absent → throw. Print a clean sectioned report (A: part-detail shape + raw dumps, B: civilian referral resolution + the unresolved-code flags, C: hydration cost + the military-nominee-count one-liner).

---

## The decision this feeds (HO 459 — NOT this handoff)

- **GO** — clean civilian referral: HO 459 hydrates `committee_system_code` on civilian rows (a `sync:nominations --hydrate` pass or a cron step, per Q3), then adds a **NOMINATIONS section on `/committees/[id]`** — that committee's referred civilian nominations, grouped/led by disposition (reusing `NominationDispositionBadge` + the disposition strip), linking each row into the `/nominations` list context. The inverse projection of the existing surface, keyed on the committee.
- **Reduced** — referral present but resolution weak / gappy: hydrate what resolves, cross-link only committees with real coverage, disclose the drop (the LDA/military-exclusion honesty posture).
- **NO-GO** — referral sparse or unresolvable: leave `committee_system_code` NULL, tombstone the cross-link, and the nominations pillar stays at its one live surface (`/nominations`). Cheap call, made on numbers.

The numbers decide. Don't pre-commit the hydration mechanism or the surface scope.

---

## Explicitly NOT in 458 (scope guard)

- **No writes, no schema, no sync, no surface.** The `committee_system_code` / `nominee_count` columns already exist NULLABLE (HO 455) — nothing to migrate. Read-only characterization only.
- **No `--hydrate` mode, no cron change.** That's HO 459, shaped by what this finds.
- **No military detail walk.** Civilian sample only; the military nominee-count observation is a one-line rider, not a corpus walk.
- **No `/nomination/[id]` detail page** — still BANKED, unrelated to this.

---

## Git discipline

- Plan → diff → **wait for approval.** No auto-commit.
- **Explicit pathspec:** the one file, `scripts/diagnostic/nominations-detail-probe-458.ts` (reusable diagnostic, sibling to `nominations-source-probe-454.ts`).
- Commit message: `feat(nominations): detail probe — part-specific detail + civilian committee-referral (HO 458)`.
- Ancestry eyeball before push: one commit riding, clean fast-forward, nothing behind, nothing unrelated staged, the concurrent session's files (`RaceCard.tsx` / `CompetitiveRacesBlock.tsx` / `CompetitiveRacesStrip.tsx` / `globals.css`) untouched and history preserved. Report the remote SHA.
- Then **run it and report the full A/B/C findings in chat** — the part-detail record shape (base-vs-per-part `url`, embedded-vs-sub-resource, multi-part blast radius), the civilian referral presence + resolution % + the distinct/unresolved committee codes, and the per-fetch latency + projected 830-PN hydration cost. Those numbers make the GO/NO-GO and scope HO 459. No doc churn on a probe — the finding gets narrated in the roadmap block at the arc's sweep, same as 446/454.

---

read docs/handoffs/458-nominations-detail-probe.md and follow it
