# HO 628 — feed row hairline: the mock declaration the 609 rebuild dropped

HEAD `97eed89`. Pointer runs through HO 627. **Next free is 628.**

Owner report: the bill rows in the right rail read cramped. The diagnosis is one missing declaration, not a spacing rework.

## Diagnosis

The HO 609 rebuild of the collapsed feed row followed the mock's `.mv` anatomy (two lines, packed left, 5px vertical padding, hover background) but dropped one declaration the mock carries:

```
.mv{padding:5px 10px;border-top:.5px solid var(--border-soft)}
```

(`docs/design/dashboard-layout-target.html:142`, identical in `dashboard-2col.html`.) Shipped `.v2f-row` (globals.css ~4194) has the padding and the hover, no border, and no comment recording the drop as a decision. At depth 5 the omission never read. HO 627's depth raise to 30 exposed it: thirty borderless two-line rows at 5px padding read as one undifferentiated block. Mock wins, the standing precedent, cited at 627 for this same page's distributions panel.

## Commit 1 — the hairline

Between groups, on the group wrapper:

```css
.v2f-group + .v2f-group {
  border-top: 0.5px solid var(--border-soft);
}
```

- Sibling combinator: the first group carries no line against the tab strip, no `:first-child` carve needed.
- `0.5px` + `--border-soft` is the house hairline. The exact declaration `border-top: 0.5px solid var(--border-soft)` already exists verbatim at globals.css:352; fractional borders run to ~279 hits in the file.
- Group-level, not row-level, so `.v2f-group.open`'s own `border: 1px solid var(--accent-amber)` overrides the grey top edge on the open group for free.
- **Open-frame interaction, verify not assume:** the open frame paints over neighbors via `margin: -1px 0` + z-index (HO 303 comment, globals.css ~4176). The group *after* an open group now has a grey border-top sitting where the amber bottom edge lands. Open a mid-feed row at 1440 and 2560 and confirm the frame still reads as one clean amber line, no grey sliver above or below. If a sliver shows, fix on the adjacent selector (`.v2f-group.open + .v2f-group { border-top-color: transparent }`), not on the frame.

Padding stays `5px 12px`. The mock's density is 5px WITH the hairline; that pairing is the approved design. Do not bump it pre-emptively.

## HALT 1 — owner's eyes

Screenshots at 1440 and 2560: closed feed scrolled mid-list, plus one open mid-feed group. Acceptance is the owner reading the rows as separated. If the verdict is still-cramped, commit 2 is `.v2f-row` padding `5px → 7px` vertical — a recorded mock deviation (the HO 623 minmax precedent: owner ruling, noted in the roadmap block). Not taken silently, not taken in advance.

## Guards

1. **The click gate re-runs, 16/16.** No JSX changes expected, but row-wide expand + modifier-aware id click is the pinned HO 627 requirement and the gate is cheap: real clicks at target centers, from a genuinely scrolled feed, both widths.
2. Audit `--route home` at 2560: **M1 holds 0** (a border-top opens no gap), M1x holds 30, M4-true 1 / 42px. Falsification leg per standing practice.
3. No `--fs` changes, no new tokens, no edits to `.bill-id-chip`, `/bills` `.feed-row`, the weekly band, or hearings rows.
4. Typecheck + build per commit. Explicit pathspecs. Code and docs never mixed.

## Verification

Prod-verify by stylesheet, not HTML (the HO 212 stale-`.next` trap, per 627's own close): confirm the served CSS on the deployed hash carries the new rule, then take the screenshots.

## Close — `refs/heads/628-review`

One docs commit: roadmap block for HO 628, pointer → 628. Short block: the dropped mock declaration, the depth raise that exposed it, commit 2 taken-or-not with the owner ruling recorded if taken. Grep gates: "HO 628" ×1, previous block's pointer still reads 1. HALT on the ref; land on approval.
