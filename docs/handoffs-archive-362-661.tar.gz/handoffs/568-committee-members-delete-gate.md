# HO 568 — the non-empty delete gate on committee_members (the 564 rule, standing-wipe edition)

Honest stakes first: HO 566 M1 classified this path STANDING with zero current victims, and the every-12h full rewrite means a wiped roster self-heals within one tick once the source recovers. What this HO buys is convention enforcement plus window closure: the SKILL convention line (a sync must never convert absence of evidence into deletion; delete-then-insert requires an authoritative non-empty payload) now explicitly forbids this write shape, `unstable_cache` on committee queries can serve a wiped roster past the tick that restores it, and the gate is a few lines plus a counter. Small on purpose; build it as such.

The site: `lib/committees-sync.ts` ~L285–330. Per-committee wipe-and-rewrite gated only on `Array.isArray(members)` — an empty array passes and deletes; entries without `bioguide` are skipped after the delete, so a non-empty array of insertless entries erases just as thoroughly. The HO 143 perf property (everything ships in ONE `db.batch`) must survive unchanged.

## §0 — Preconditions

1. `git fetch && git status` clean, `main` even with `origin/main` at `f6aab1b` or later, `npm run typecheck` clean.
2. Read: the wipe block in `lib/committees-sync.ts` (including the HO 143 one-batch comment); the HO 564 gate in `lib/primaries-sync.ts` as the pattern being ported (this time the analogy IS measured — same shape, 566 M1 sized it); the M1 queries in `scripts/diagnostic/delete-rebuild-erosion-566.ts`.

## §1 — Baseline (no new diagnostic; the 566 probe is the instrument)

Re-run `scripts/diagnostic/delete-rebuild-erosion-566.ts` and quote M1 fresh: total `committee_members` rows, committees-with-roster count, the zero-member list. One extra read while there, load-bearing for §2: do the 10 known-empty committee codes appear in the parsed source with empty arrays, or are they absent from it entirely? One line in the report either way.

## §2 — The gate

Per committee, build the INSERT statements first; push the DELETE only when the **insertable count** is > 0 — entries carrying a `bioguide`, not raw array length, so a non-empty array of insertless entries refuses exactly like an empty one. Refused system codes collect as **`rosterDeletesRefused: string[]`** on the sync summary and into the cron payload (the exact 564 field name; one greppable family).

**Refusal must stay signal-bearing at steady state.** If any of the 10 source-empty bodies appear in the parsed source with empty arrays, a naive gate reports them every tick and the counter pins at 10 forever, masking real refusals. So: one upfront grouped query (`SELECT committee_system_code, COUNT(*) ... GROUP BY`) builds the set of currently-rostered codes, and the refusal fork splits on it — insertable = 0 AND the code is rostered → **refuse and report** (a real protection event: existing rows were about to be erased by nothing); insertable = 0 AND the code is unrostered → **silent skip** (nothing to protect, nothing lost). Steady state stays `rosterDeletesRefused: []` either way, and the field only ever names a roster it actually saved. A refused committee's rows keep their old `updated_at` until the source recovers, so a pinned refusal also surfaces through M1(c)'s staleness read — the two instruments compose.

Accepted trade, stated: a committee whose roster genuinely empties (dissolution) lingers at its last membership until corrected manually — the 564 stance, absence in one payload is never authority to erase, and the manual hatch is a one-off correction if it ever happens (none exists today).

Untouched: the `unknownCommittees` skip, the `!Array.isArray` guard, `committeesSeen` semantics (a refused committee still counts as seen), the single-batch shape, and everything on the meetings side of the file family.

## §3 — Build

**C1, one commit:** the gate + the summary field in `lib/committees-sync.ts` (plus its type). `npm run typecheck`, explicit pathspec, ancestry eyeball, push.

## §4 — Falsification (both refuse variants forced before anything is recorded as protection)

Scratch edits only, never committed, HO 549/553 discipline:

- **A — empty array:** force one rostered committee's parsed `members` to `[]`, run the sync locally: its roster byte-identical (row count + a spot-checked member unchanged), its code in `rosterDeletesRefused`, every other roster rewritten normally.
- **B — insertless entries:** force the same committee's entries to drop `bioguide`, run again: identical refusal — this is the proof the gate keys on insertable count, not array length.
- Revert, `git status` clean, natural run: `rosterDeletesRefused: []`, the committee's roster rewritten, `updated_at` advanced.

If either variant can't be forced locally, record UNPROVEN and say so; don't describe it as protection.

## §5 — Verification

1. Re-run the 566 probe: M1 (a)/(b)/(c) match the §1 baseline modulo natural churn; zero-member list unchanged.
2. Push, `verify:deploy` SHA, then the next 12h committees tick: `rosterDeletesRefused` present in `cron_runs.payload` (presence-of-field, expected `[]`) — quote the run id.

## §6 — Report, then halt

Paste back: the §1 baseline + the source-presence answer for the 10, the falsification transcript (A and B), the probe re-run numbers, and the payload sample with run id. Docs untouched — roadmap/backlog/oddities/SKILL land at the HO 569 sweep, which covers 566–568. Halt after the report.

## Hard scope guards

1. One file plus its summary type; nothing else.
2. The one-`db.batch` shape preserved (the HO 143 55s lesson).
3. `unknownCommittees`, the meetings side, `votes-sync`/`senate-votes-sync` (567 is done), `amendment_votes`, primaries: all untouched.
4. The `jhje00`/`jjec00` Joint Economic dup is NOT fixed here — 569 records it.
5. No schema, no migration, no index, no `vercel.json`, no docs, no SKILL.
6. Nothing noticed in passing gets fixed.
