# HO 483 — batch the trades inserts (one round-trip, not ~200)

**Type:** code fix, single file. HEAD `7a66f43` + the HO 482 probe commit. Roadmap through HO 481; probe is 482; this is 483.
**Precedent for the win class:** Turso round-trip collapse (the per-row → batched-write pattern). Fix commit only — no doc sweep in this commit.

## Why

HO 482 proved the trades step in `/api/sync` is **~200 sequential `INSERT OR IGNORE` round-trips** — page-0 returns ~100 rows/chamber × 2 chambers, each row a separate `db.execute`, at ~35ms/round-trip → **7.0s** (matching measured trades p50 7.3s to within 4%). It's 5–11.5s on every tick, present on all four post-fix ticks, and it's the contention amplifier that turned tick #3446 into a 50.0s tick (200 slow round-trips instead of 1). Sync self-caps at 30s and trades attempts are fixed at ~200 by FMP's page-0-only free tier, so **neither grows with volume** — the lever is round-trip count, and this collapses it 200 → 1.

Projected: #3446 50.0→~43s, #3499 40.5→~34s, #3612 36.0→~29s. ~7–11s of margin fleet-wide under the 55s soft cap.

## Two premises HO 482 already settled — build on them, don't re-check

- **Matching is in-memory.** `ingestChamber` (`lib/trades-ingest.ts`) calls `matchMemberName(memberNameRaw, members, chamber, stateHint)` against a preloaded `MatchableMember[]`. **No per-row DB read** — the only per-row round-trip is the INSERT. Batching the INSERTs removes the entire per-row DB cost.
- **`db.batch()` is available and semantics-preserving.** The DB handle is `@libsql/client` `Client` (`getDb()`). `client.batch(statements, "write")` sends N statements in **one** round-trip and returns a `ResultSet[]`, one per statement, each with its own `rowsAffected` — so both `result.inserted` and the `pageInsertedAny` all-seen short-circuit are reconstructable. Batch is N separate statements (not one compound `INSERT`), so `SQLITE_MAX_VARIABLE_NUMBER` (999) does **not** apply.

## The change — `lib/trades-ingest.ts`, `ingestChamber` inner loop only

Today the inner `for (const trade of trades)` loop `await db.execute(...)`s one `INSERT OR IGNORE` per row and checks `rowsAffected` inline to drive `result.inserted` and `pageInsertedAny`. Restructure to **build, then batch**:

1. Keep every per-row step that's already in-memory: `extractName`, the `pickString`/`normalizeDate` field extraction, `matchMemberName` + the `result.matched++` / `result.unmatchedNames.add(...)` counters, and `composeId`. These stay in the build loop unchanged.
2. Instead of `await db.execute` per row, push `{ sql: <the same INSERT OR IGNORE>, args: [<the same 13 args>] }` onto a `statements: InStatement[]` array (`import type { InStatement } from "@libsql/client"`). The SQL string and arg order are **byte-identical** to the current statement — do not alter columns, `OR IGNORE`, or the `disclosureDate ?? ""` arg.
3. After the build loop, if `statements.length > 0`, run **one** `const results = await db.batch(statements, "write");`. Then walk `results`: for each `rs`, `if ((rs.rowsAffected ?? 0) > 0) { result.inserted++; pageInsertedAny = true; }`. This reproduces the exact per-row counter and short-circuit from `rowsAffected`.
4. Leave the outer page loop, the `if (trades.length === 0) break`, the fetch `try/catch → break`, the `if (!pageInsertedAny) break` all-seen short-circuit, and `const ingestedAt` (once per chamber) **unchanged**. The all-seen break still fires correctly because `pageInsertedAny` is now derived from the batch results instead of inline.

Net: the set of rows that land is **identical by construction** (same `INSERT OR IGNORE` statements, same OR-IGNORE conflict semantics, just wrapped in one batched write) — only the transport changes, ~200 round-trips → 1.

**Defensive footnote (do not implement unless needed):** ~100 rows/chamber × ~13 small args + one `raw_json` blob each is a few hundred KB per batch — comfortably within a libSQL batch request. If a batch-size ceiling is ever hit on a fat page, chunk the statements into groups of ~50 and batch each group; not required at current volumes.

## Keep it best-effort

The whole trades step is already wrapped non-fatal in `route.ts` (`try/catch → console.warn → skip`, status stays success). A `db.batch` throw surfaces there the same as an `execute` throw did — no new error handling needed. Do not make trades fatal.

## Verify (report before commit)

- `tsc` clean against `tsconfig.json`.
- Run the CLI once: `scripts/sync-trades.ts` (the same `ingestChamber` path). Confirm it completes, `inserted`/`matched`/`unmatchedNames` counts are plausible (non-zero `matched`, `inserted` = the new-row delta), and the trades wall for the run collapses toward **sub-1s** vs the 5–11.5s cron baseline.
- Correctness argument to state explicitly: because each batched statement is the same `INSERT OR IGNORE`, the inserted **set** is unchanged — verification confirms nothing was dropped (counts plausible, no new errors), not an A/B (live FMP state shifts between runs, so a strict before/after count isn't meaningful).
- Post-deploy (its own follow-up, not this commit): pull a few `/api/sync` ticks; `payload.timings.trades` should read sub-1s and `elapsed_ms` p90 should fall ~7–11s (a #3446-class 00:00-UTC tick lands ~43s, ~12s margin).

**Close criterion:** trades wall < ~1.5s on post-change runs, inserted/matched counts unchanged in behavior, no new errors, `tsc` green. The 200→1 round-trip collapse removes both the ~7s baseline and the contention multiplier that produced the 50.0s tick.

## Discipline

- One-file code fix: `lib/trades-ingest.ts`. Explicit pathspec stage of just that file. Diff shown and approved before commit. Ancestry checked immediately before push (`git log --oneline @{u}..HEAD` = one commit, clean fast-forward), no force. All concurrent-session files untouched.
- **Code commit only** — the roadmap/backlog/oddities reconciliation for the 482 probe + this fix + the banked re-probe triggers + the "00:00-UTC residual spike" oddity is a **separate doc-sweep HO** (484), after this lands.
