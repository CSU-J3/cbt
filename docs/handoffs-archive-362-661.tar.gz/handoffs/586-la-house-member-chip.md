# HO 586 — the LA House member chip: the read side of the proxy convention

## 0. What this is

HO 584 fixed the write side. The six `house-LA-{DD}-2026-open` rows now correctly carry 2026-11-03 / 2026-12-12 / `jungle`. The read side never moved: `getPrimaryForRace` (`lib/queries.ts:1554`) pins `p.district IS NULL`, so a LA House member's chip resolves to `senate-LA-2026-{party}` @ 2026-05-16. **The same member page now shows two different dates for one contest, live on prod.** That inconsistency is a consequence 584 created, and it's the reason this is P2 rather than housekeeping.

Two structural mismatches, not one. The query pins `district IS NULL`, and LA House rows carry a district. It also pins `p.party = ?` against the member's party, and LA House rows carry `party='open'` because the contest is all-party — so even with the right district, a party-keyed match misses. Both have to go for the chip to resolve.

**The adjacent item is the same defect.** The backlog carry-forward "`getPrimaryForRace` senate-proxy can't serve top-two and no-Senate-seat states (HO 576 STEP 0)" describes CA/WA (`-open` rows only, no D/R senate row) and the ~21 states with no 2026 Senate seat at all. LA is that class with a live symptom attached. Whether this HO fixes the class or just LA is a **decision gated on STEP 0 M3**, not a call to make up front.

**The trap this query has already sprung once.** HO 576 STEP 0 M3a tested exactly this widening — dropping the district restriction — and proved it wrong: it leaked per-district house rows and would have "fixed" 127 null chips with arbitrary district dates. That's why `district IS NULL` is pinned and why the `district` parameter sits in the signature unused, commented "retained per the documented call contract; query pins statewide." **Do not remove the pin without the full-corpus delta.** M3 exists because that mistake is on the record.

## STEP 0 — `scripts/diagnostic/member-chip-district-586.ts` (read-only)

Read-only by nature — this is a query-shape change, no write path is involved. The HO 584 rule still applies in spirit: prove at the query-and-args level, touch nothing.

Commit alone, run, report, **HALT.**

**M1 — what the call site actually passes.** Find every caller of `getPrimaryForRace` and print the real argument tuple `(state, district, party, memberChamber)` for a LA House member and for a control Senate member. HO 576 recorded the caller as chamber-blind and passing `district=null` for House members, and it added `memberChamber` — but it did not necessarily start passing a real district. **If `district` still arrives null for House members, the fix is not confined to `queries.ts`** and the caller has to supply it; report that rather than working around it inside the query.

**M2 — confirm the disagreement on prod.** For 2–3 current LA House members, print what the chip resolves to today (expect `senate-LA-2026-{party}`, 2026-05-14/16) alongside the `house-LA-{DD}-2026-open` row (expect 2026-11-03). This is the user-visible defect stated as data.

**M3 — the full-corpus delta, and it is the gate.** For **every current member**, compute the chip under the shipped query and under the proposed district-first query, and diff. Report: total changed, broken out by (a) null → non-null, (b) non-null → different date, (c) non-null → null. For every row in (b) and (c), name the member, both ids, and both dates. **(c) is a regression by definition — any non-zero count halts the build.** (b) needs each case justified individually as an improvement, not counted in aggregate; that's the 127-row lesson.

**M4 — coverage of the proposed source.** Per state: does a `house-{ST}-{DD}-2026-*` row exist with a non-null date, and what `party` values do those rows carry? Enumerate the states where the district-first lookup finds nothing (expect the HO 209 gap states with frozen/null dates), because those members keep the senate proxy and that's the fallback path, not a bug.

## Build (after HALT clears)

**C1 — district-first resolution for House members.** For `memberChamber === "house"` with a non-null district, prefer the member's own `house-{ST}-{DD}-2026-*` row, matching `p.party = ?` **or** `p.party = 'open'` so all-party contests resolve regardless of member party. Fall back to the existing statewide senate proxy only when no district row is found. Senate members' path is unchanged — same query, same pin, byte-identical results.

The `district IS NULL` pin doesn't get deleted; it becomes the fallback branch. Say that in the comment, along with why: dropping it outright is the HO 576 M3a failure, and the district-first branch is safe only because it keys on the member's *own* district rather than taking whatever row sorts first.

**Scope, decided by M3, stated in the ship report either way:**
- If M3 shows changes confined to LA (plus clean null→non-null fills elsewhere), ship the general query and note that it closes the carry-forward item as a side effect.
- If M3 shows (b) cases outside LA that aren't each defensible, **narrow to LA only** and leave the carry-forward item open with M3's table as its new evidence. Narrowing on evidence is the right outcome, not a failure.

**C2 — reconcile the comment.** The `district` parameter's "query pins statewide" note is wrong once C1 lands. Rewrite it around the two-branch shape and cite HO 576's M3a as the reason the fallback still exists.

## Falsification

Prove the district-first branch actually fires rather than the fallback quietly serving the same answer — an untriggered branch and a broken one emit identical green. For a LA House member, show the branch taken and the row id returned (`house-LA-{DD}-2026-open`, not `senate-LA-2026-*`). Then force the fallback by querying a state with no district row and confirm it returns the senate proxy. Read-only throughout; nothing written, nothing committed from scratch.

## Verification

The primaries helpers are deliberately uncached plain `db.execute` (`queries.ts:~1615`), so there's no data-cache convergence to wait out — confirm `/api/version` shows the new SHA, then read a LA House member hub and confirm the chip reads Nov 3 and matches the House row on the same page. Check one Senate member hub is unchanged.

## Scope guards

- STEP 0 writes nothing; diagnostic commit separate from build commits.
- No writes anywhere in this HO — it is a read-path change end to end.
- No change to `HOUSE_PRIMARY_OVERRIDES`, `calByState`, or any sync path. HO 584 is not reopened.
- No change to the Senate resolution path, `NOT_SPECIAL_UNLESS_SENATE`, or the HO 576 `memberChamber` rule (a Senate special is never a House member's proxy).
- No change to `getRunoffsForRace`, `getPrimaryCalendar`, or the primaries feed helpers.
- Do not "fix" `primary_type` while in here — that's the P3 fallback-default item and it has its own instrument.
- Explicit pathspec staging; `npm run typecheck` before pushing; ancestry eyeball; fast-forward only on main; code and docs never mixed.
- `docs/roadmap.md` is authoritative for the HO number.
