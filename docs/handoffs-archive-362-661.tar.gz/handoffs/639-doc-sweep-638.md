# HO 639 — doc sweep for HO 638 (`nominee` vocabulary + the S-ME-2026 roster)

Docs only. **No code, no schema, no seed runs, no data.** If any step here wants a code change, halt and say so rather than taking it.

## Why

HO 638 added a status value to a vocabulary that SKILL.md enumerates in three places, and shipped a data correction that two of those places describe by name. SKILL is the conventions doc — it wins on implementation questions — so a wrong enumeration there is worse than a wrong comment in a component. It currently reads:

```
status TEXT,   -- 'declared' | 'running' | 'won_primary' | 'withdrew'
```

which is now false about the live table.

## Commit split (Corey's standing rule: code, docs and SKILL never ride together)

- **Commit A** — `docs/roadmap.md`, `docs/backlog.md`, `docs/oddities.md`
- **Commit B** — `SKILL.md`

Explicit pathspec staging. Diffs shown and approved before each. Two commits, not one.

## Phase 1 — Diagnostic (HALT after)

1. **Did the five backlog lines actually land?** Your HO 638 report listed them; confirm whether they were written to `docs/backlog.md` or only reported in the transcript. If they were only reported, Commit A writes them. If they landed, quote them so Commit A amends rather than duplicates.

2. **`docs/oddities.md` insertion point.** Confirm the file-header convention (append at the END — the header wins over any memory or spec claim about ordering; corrected at HO 587) and report the current last entry so the append lands in the right place.

3. **The SKILL sites.** I have four candidates from reading `SKILL.md` at `d2c26a5`. Confirm the line numbers still hold and report anything I missed — grep `won_primary` across the whole file:
   - **~305** — the `race_candidates` schema comment. The enumeration. Wrong.
   - **~1054** — `getRaceCandidates` "orders by status precedence — `won_primary` first, then `running`, `declared`, `withdrew`, others". Incomplete.
   - **~1205** — `/race/[id]` "ordered won_primary → running → declared → withdrew → name". Incomplete.
   - **~1214** — the harvest sentinel description, including "(NJ-07/PA-10/S-GA/S-ME, with their `withdrew`/`running` nuance)". The S-ME clause is now wrong; **the rest of that passage is correct and must not be touched** — `backfill:race-challengers` still writes `status='won_primary'` and should.

   That last distinction is the one to get right. Three sites are stale enumerations. One site correctly describes a script that legitimately writes `won_primary`. Do not "fix" the fourth.

4. **The roadmap's latest pointer.** Report the last `Also notes now run through HO N` line so the new block appends after it and the HO number is taken from the roadmap rather than from any filename.

**HALT.** Report 1–4 before writing.

## Phase 2 — Commit A: roadmap, backlog, oddities

### `docs/roadmap.md` — one appended block, append-only

Never retro-edit a prior block. The new block covers HO 638 and should carry, in your own compression:

**The defect and its three independent bars.** The ME Senate card showed Mills and Platner as the active field while the seat's actual nominee was Troy Jackson, nominated at a 2026-07-25 party convention after Platner won the June 9 primary and withdrew on July 10. Three mechanisms independently guaranteed it would never self-correct: the seed entry was frozen; `backfill:race-challengers`' sentinel guard structurally skips hand-curated races; and ME's `primary_candidates` carry **no `status='winner'` row at all**, so the harvest was inert for that seat regardless of the guard. The third was found in Phase 1 and is not a variant of the second.

**Two corrections to the handoff, recorded rather than retro-fitted.** Why §1 claimed the seed was frozen at HO 171 with `last_verified` 2026-06-01. Wrong: `seed:races` **ran** on 2026-07-03 and touched ME. The JSON *entry* was frozen, not the run — the write happened, the content didn't change, and the stamp moved anyway. That is the finding, not a footnote. Second, the "NJ-07 shape precedent" cited when the seed diff was approved is **cosmetic**: JSON array order feeds nothing, display order is the SQL `CASE` ladder alone, so a correct render is not evidence that the file ordering did anything.

**The vocabulary, and why it wasn't the expedient thing.** `nominee` ships as a distinct status handled identically to `won_primary` — different HOW, not different WHAT. Seeding Jackson as `won_primary` would have rendered correctly today and written a false claim into a status column that nothing downstream re-reads: HO 577's defect class, HO 420's cost. **Five hard sites, not the four the handoff counted** — the missed one, `buildRoster`'s `wonPrimary` flag, feeds `favoredMember`'s party-market tiebreak. `RosterMember.wonPrimary` was renamed `isNominee` in the same commit, because once `nominee` sets that flag the old name is the status-column lie one layer in.

**The falsification, and the two sites ME cannot reach.** With Mills and Platner `withdrew`, `active.length === 1` and `ofParty.length === 1` short-circuit before either flag is read, so `buildRoster` and `deriveMatchup` are **unreachable from ME's own data** and are proven by the scratch third-candidate fixture alone. Measured, not asserted: without the fixture, `nominee` and an unknown status are indistinguishable. A green ME card is not a fire of those two — state it, so a later reader doesn't inherit the wrong provenance.

**Two soft sites got comments, not code.** `RaceMapCard` and `RaceDistrictCard` render the raw status generically, so `nominee` degrades correctly with no edit — luck, not design, and the opposite failure mode from `statusLabel`'s `default:`. The comments mark the generic path as load-bearing so a later tidy toward an explicit switch doesn't create a third silent-default site.

**The ordering fire, and why it couldn't run from `tsx`.** Both ladders are `unstable_cache`-wrapped; calling one outside a Next request context throws `Invariant: incrementalCache missing` (this codebase's own HO 622). So `getRaceCandidates` was fired via `GET /api/race/S-ME-2026/hub` and `getRaceCandidatesForCycle` via a rendered `/electoral` — its only consumer. Both returned **Jackson 0, Platner 1, Mills 2**; the failing signature would have been Jackson at 3+, below the withdrawn rows. Raw status read back as the literal `nominee` **first**, because `seed:races` does not validate status and a typo would have produced a byte-identical failure signature.

Two things the fire turned up that nobody asked for. `buildRacesCartogram` had to be read before the `/electoral` DOM order counted as a SQL fire — it is a pure grouping pass with no sort, so the array order is the query's; had it sorted, the reading would have been JS measured and called SQL. And the locator **failed loudly on its first run** rather than returning an empty selection: `kalshiOdds` carries a nested `"raceId":"S-ME-2026"` that tripped the boundary guard, and the rewrite selects by roster content then back-tracks to the enclosing `raceId` to verify provenance (57 challenger arrays in the payload, exactly one matched).

**One thing that looks like evidence and isn't.** The live ME card renders `Jackson  D · nominee`. That string is `RaceCard:206`, a hardcoded label for the `challenger.kind === "nominee"` **shape** (HO 305), unrelated to the status column — it would read identically if Jackson were `won_primary`. The status-column evidence is the two orderings plus `/race/S-ME-2026`'s title-case `Nominee`. This is the arc's own instance of the layer-check policy: the check has to look where the value *lands*, not where a similar-looking string is *authored*.

**The instrument that already knew, and this is the sharpest finding of the arc.** Kalshi (65%) and Polymarket (69%) both named **Troy Jackson** as favorite while the roster beside them on the same card named Platner and Mills. `favoredMember`'s name-market branch does `roster.find(m => nameKey(m.name) === nameKey(fav.favoriteLabel)) ?? null` — so it computed "this market names someone who is not on this roster" on **every render for roughly two and a half weeks** and discarded it as a null, falling back to a party label. Two independent feeds disagreed with the curated data beside them and nothing surfaced it. Meanwhile `races.last_verified` read **green on the defect**: `/race/S-ME-2026` printed "last verified 2026-07-03" beneath a roster two candidate-states behind, because the stamp records when `seed:races` last ran and stamps whether or not the entry's content changed — the same-as-success shape on a live surface, with a live exhibit.

**What the fix did NOT do, stated as a decision.** Mills and Platner stay as rows: `seed:races` is insert/upsert with no delete, so removing them from the JSON is a no-op and both would render as `running` forever; they had to be transitioned by status, and `withdrew` is accurate for both. Ride-along B left the 39-race `last_verified` re-stamp **unpatched** (2026-07-03 → 2026-08-11, one of the 39 actually verified) — a hand-restore of the other 38 is reversed by the next run with nobody watching, which is worse than a uniformly meaningless stamp.

Close with the standing `Also notes now run through HO 639.` line.

### `docs/backlog.md` — five lines, with two amendments

Per Phase 1 item 1, write or amend. **Two of the five need changing from how they were reported:**

**Line 1 gets a better instrument than `last_verified`.** As reported it prices a curator-set date field. Add the stronger one: a **name market that resolves to no active roster member** is a stale-roster detector that is already computed and thrown away in `favoredMember`. Scope it precisely — the signal is the *name*-market branch failing to match (`!favoriteIsParty && favoriteLabel` and no roster hit), **not** `favoredMember` returning null generally, because an unresolvable *party* market is a normal state and would make the detector fire constantly. State what it would have read on 2026-07-25: Kalshi and Polymarket both naming Jackson, no roster match, on a card whose `last_verified` read green.

**Line 2's sizing is right and its framing is not.** The 11 contests with recorded shares but no `winner` row are **not one class**, and the difference decides whether the fix is the ingester or the model:
- **Top-two / jungle** (8 of 11, CA/WA `-open`): two candidates advance by design, so a single `status='winner'` row is a category error. The harvest's model is wrong here, not the data.
- **Ranked choice** (ME): a winner IS well-defined; it arrives through elimination rounds. That is an ingestion gap.

Note the WA contests are 2026-08-04, a week old, so some may simply be un-swept rather than structurally missing — say which, or say it's unmeasured.

Lines 3, 4, 5 stand as reported (no ingestion path for convention nominees; the ladder transcribed twice; `seed:races` validates ratings but not status).

### `docs/oddities.md` — append at the END, two entries

1. **`RaceCard:206` renders a hardcoded `nominee` label off the matchup SHAPE, not the status column.** It reads identically whether the candidate's status is `nominee` or `won_primary`, so it cannot be used as evidence that a status-column change landed. Name the real instruments: the two `ORDER BY` fires and `RaceCandidates`' title-case label.

2. **`races.last_verified` records when `seed:races` last ran, not when a roster was last checked** — the script stamps every entry it touches whether or not the content changed. It rendered "last verified 2026-07-03" on `/race/S-ME-2026` beneath a roster two candidate-states stale.

## Phase 3 — Commit B: SKILL.md

Three sites corrected, one deliberately left alone.

1. **~305, the schema comment.** Add `nominee` to the enumeration.
2. **~1054 and ~1205, the ordering descriptions.** `won_primary` **and `nominee`** tie at rank 0, then `running`, `declared`, `withdrew`, others, then name. Note in one place (not both) that the ladder is **transcribed twice in `lib/queries.ts`** — `getRaceCandidates` and `getRaceCandidatesForCycle` — with no shared constant, so a status added to one needs adding to the other, and a miss sorts the new status *below withdrawn candidates* rather than erroring.
3. **~1214, the S-ME clause only.** `(NJ-07/PA-10/S-GA/S-ME, with their `withdrew`/`running` nuance)` → reflect that S-ME now carries `nominee`. **Leave the rest of that passage untouched** — `backfill:race-challengers` writes `status='won_primary'` and that is correct.

Add a short vocabulary note wherever the schema comment lives, covering: `nominee` is the ballot-vacancy / convention-replacement route to being a party's general-election candidate; it is handled identically to `won_primary` everywhere; the two are different HOW, not different WHAT; **do not collapse them**, because `won_primary` on a convention nominee is a false claim in a status column that nothing downstream re-reads. Mention that `seed:races` does **not** validate status, so an invalid value inserts silently and sorts to `ELSE 4`.

**Do not** restate the whole HO 638 narrative in SKILL. Roadmap carries the arc; SKILL carries the contract.

## Verification

- `docs/oddities.md` entries land at the END of the file.
- No roadmap block above HO 638's is edited. `git diff` on `roadmap.md` shows additions only — if any deletion appears, halt.
- Each distinct HO number appears exactly once in the roadmap, monotonic.
- `grep -c "won_primary" SKILL.md` before and after; every surviving occurrence is either the harvest description or a passage where `won_primary` alone is genuinely correct. Report each survivor and why it survived.
- Two commits, separate diffs, explicit pathspec.
- No `npm run typecheck` needed — nothing executable changed. If a diff touches anything outside the four doc files, halt.

## Out of scope

- No code. The `deriveMatchup` local `won` nit stays unfixed and rides with whatever next opens that function.
- No new backlog items beyond the five plus the two amendments.
- No re-run of `seed:races`, no tag flushes, no prod reads.
