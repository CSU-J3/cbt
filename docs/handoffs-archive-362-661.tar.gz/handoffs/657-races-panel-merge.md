# HO 657 — the races panel merges: one body, a dates line, no sub-tabs

**The ruling, Corey's, verbatim: "B"** — against `mock-657-races-merge.html`, variant B. The reviewer's reading of that scope: **the dates line ships AND the per-date detail opens on click**, because variant B as mocked includes the click. If a correction to that reading arrives, it arrives as one line; build to B-as-mocked unless it does.

**Derive the number.** At writing: HO 656's docs were approved on `656-review = 103798f` but the fast-forward may not have executed. §0 settles it.

The mock is direction and token-faithful reference; **this spec is authoritative** where they differ or the mock is silent. Match real spacing to the conventions arc (C1–C8), not to the mock's pixel values.

---

## §0 — Ground truth, the owed fast-forward, and halts

1. `git ls-remote --heads origin`. **If `656-review` still exists:** the approval is on record — *"Approved. Fast-forward main to `103798f`, delete `656-review`."* Execute it first (ancestry eyeball, no merge commit), then continue. If main has moved past `103798f` in a way that is not that fast-forward, HALT and report.
2. Fresh state, then derive: expected roadmap pointer 656, subjects 656, so **657**. Take the real numbers.
3. Find the merge's own backlog entry if one exists (the deferred primaries/competitive merge). Read it before building; if it carries constraints this handoff lacks, **the entry wins** — report the delta before proceeding.

---

## §1 — What the ruling settles

Dies: the COMPETITIVE|PRIMARIES sub-tab row, the 6-month tick timeline, the 2×2 date-card grid, and the `primariesCount` badge. Lives: the competitive body exactly as it is (battlefield + cards on v2; the 2×2 hover-popover cards on the default variant), plus one new element — a **NEXT PRIMARIES line** above it, with per-date click-open detail. Depth stays on the standalone electoral surfaces; the panel's ALL → link keeps pointing wherever today's expander points.

Out of scope, explicitly: the standalone `/primaries` and electoral subnav; `RaceCard` and its chips; the battlefield; the HO 656 empty-roster finding (ME-02/NY-02/NY-22); anything in `getDashboardPrimaries`'s SQL.

---

## §2 — Enumerate before editing

Read these out of the code; none are inherited from this file.

1. **Consumers.** Every render path into `RacesPanelTabs`, `CompetitiveRacesBlock`, and `DashboardPrimaries` at HEAD. The `variant` prop suggests two surfaces ("/" default popover cards vs v2 rich cards) — after the HO 311 swap, name which routes actually render which, because the merge lands on all of them through the one shared component.
2. **The chrome and the containment box.** `RacesPanelTabs` owns `.dashboard-pane .home-races-pane` — moved there at HO 233 *so the same element remains the HO 230 popover containment box* (`position:relative` + `overflow:hidden`). The island held only the toggle; with the toggle dead, the shell should become **server-rendered**, but **the chrome must land on an element with the identical containment role.** Say which element carries it after the edit and why the popover confinement is unchanged. This is the number-one regression risk in the whole HO.
3. **The height lock.** `.races-panel-body` min-height 240px exists for tab-parity; `RacesBoxTabs` CSS-hides rather than unmounts partly to preserve nested sub-tab state. With the sub-tabs gone, that rationale is half-dead — read the locked-height mechanism, keep whatever prevents the HEARINGS↔RACES box from jumping, and update the `RacesBoxTabs` comment so it stops citing a state that no longer exists (the HO 654 lesson: a comment that overstates its scope is the next defect's nursery).
4. **The ALL target.** Today's `DashboardPrimaries` has an expander link; record its href and reuse it.
5. **Spec selectors.** Grep both e2e specs for anything pinning the sub-tabs, `dash-prim-*`, or tab labels. Fixtures that pin the old structure update **in the same commit** as the code (the HO 655 lesson, not repeated twice).
6. **Pre-edit reads.** Record what the panel renders now on each consuming route — tab labels, counts, body — so §5's "unchanged" claims have a prior.

Report §2 before any edit.

---

## §3 — The build

**Shell.** `RacesPanelTabs` retires. Its replacement is a server-rendered section in (or under) `CompetitiveRacesBlock` carrying the same chrome classes on the same structural element per §2.2. The `primariesCount` computation goes with the badge.

**`NextPrimariesLine`** (new, small). Input: the existing `getDashboardPrimariesData` payload, unchanged — `cards` is already the four soonest dates with states, counts, and marquee seats, and `strip`'s `soon` flag maps amber per date. Renders:

- The label `NEXT PRIMARIES`, then one button per card date: mono date (amber when soon, secondary otherwise), states abbreviated with the existing `+N` overflow rule, dim count. `ALL →` at the far right to §2.4's href.
- Click a date → one detail row directly below the line: date, states, contest count, marquee seats — the card content, one open at a time, × closes, re-click closes. This needs a client island; keep it to the open-state `useState` and nothing else, mirroring how `RacesPanelTabs` was only a toggle.
- **Empty window renders nothing at all.** Not the current "No upcoming primaries" notice — in the merged panel the battlefield is the body and an empty notice is noise. This is the deliberate seasonal death the mock's annotations promised; comment it so nobody adds an empty state back.
- A11y: real `<button>`s, `aria-expanded` on the open date, the detail row labelled by its date.

**Retirements, swept like the phantom probe taught.** `DashboardPrimaries.tsx` deletes; the `dash-prim-*` CSS block deletes or tombstones per the file's own convention. Then **grep the whole tree (CSS comments included) for `DashboardPrimaries`, `RacesPanelTabs`, and `dash-prim`** — a surviving comment naming a deleted component is the `globals.css:1563` vouching shape, and this HO does not mint another instance. `getDashboardPrimaries` (the query) **stays**, re-pointed at the line.

---

## §4 — Verification

- Typecheck; build; route map unchanged.
- On every §2.1 route: sub-tab row absent from the DOM, NEXT PRIMARIES line present with live dates, click opens exactly one detail, × and re-click close it, ALL → resolves.
- **Popover confinement:** hover the cards on the default-variant surface; the popover stays inside the panel on all four cells (the §2.2 risk, exercised, not assumed).
- **Height:** HEARINGS↔RACES flip does not jump the right column; state the before/after panel heights.
- Empty-window branch proven, not assumed: scratch-force `cards` to `[]` and confirm the line renders nothing and the body holds; revert.
- `npm run test:e2e` locally with the known local artifacts named; any fixture updated per §2.5.
- Direct to main (UI, the preview-dedup rule), then `verify:deploy` under the consecutive-match gate; record what each check reads if the work never happened.

---

## §5 — Commits

| # | Kind | Contents | Ref |
|---|------|----------|-----|
| 1 | `feat` | components + CSS + the count removal + any fixture updates | direct to main |
| 2 | `docs` | roadmap block (convention from the file's recent blocks); backlog — the merge loop closed, plus anything §2 surfaced | review ref |
| 3 | `docs` | SKILL — the `getDashboardPrimaries` entry re-pointed at the line; the PRIMARIES-tab and `RacesPanelTabs` passages become RECORD (deleted at HO 657), presented as deletions, not left live | review ref, self-mod guard, alone |

Explicit pathspec staging, ancestry eyeball, `--numstat` for append-only claims. Docs and code never ride together.

## Guards

1. §0 before anything; §2 reported before §3 begins.
2. The containment chrome lands per §2.2 or the HO halts — no improvising a new stacking context.
3. `getDashboardPrimaries` SQL untouched; `/primaries` and the subnav untouched; `RaceCard` untouched.
4. The empty-window scratch perturbation is reverted before commit.
5. No comment survives that presents `RacesPanelTabs` or `DashboardPrimaries` as live.
6. If the mock and the conventions arc disagree on spacing or type, the conventions win and the deviation is noted in the ship report.
