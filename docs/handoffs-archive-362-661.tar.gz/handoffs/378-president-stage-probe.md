# 378 — President stage probe (read-only)

**Self-claim:** if `docs/handoffs/378-*.md` already exists, bump to the next free number (`ls docs/handoffs/ | sort -V | tail`) and rename before starting.

**Read-only. No writes, no schema changes, no classifier edits.** This handoff only diagnoses. The output is a written verdict pasted back, not a code change.

## Why

The home Stage Distribution bar shows PRESIDENT = 0 of 15,048. Clicking it filters to an empty set, and because the bar is zero-width the click lands on OTHER's tooltip instead (that zero-width-bar interactivity problem is a separate UX issue, out of scope here). Settle whether 0 is correct before deciding any fix.

Two hypotheses:

- **Transient-empty (0 is correct).** PRESIDENT means presented to the president, awaiting signature, a window of a few days before a bill flips to ENACTED. A snapshot of 0 is plausible if every presented bill has already been signed (87 are in ENACTED).
- **Classifier gap (0 is wrong).** The stage classifier has no `president` branch, or it's ordered so presented bills match ENACTED/signed first, so the stage is permanently dead and those bills are mis-staged.

## Resolved premises — do not re-derive

- **Stage enum (from the live UI):** INTRO, COMMITTEE, FLOOR, OTHER, PRESIDENT, ENACTED. The six buckets partition the corpus cleanly (482 + 13,741 + 693 + 45 + 0 + 87 = 15,048), so any presented bill not in PRESIDENT is sitting in another bucket, almost certainly ENACTED if already signed. Confirm against the classifier.
- **PRESIDENT semantics:** passed both chambers, presented to the president, not yet signed/vetoed/enacted. The stage *between* FLOOR and ENACTED. Do not redefine it.
- **Congress.gov latest-action vocabulary around presentment** (you may not have this; checking only one string is the main failure mode):
  - Presented: `Presented to President.` (sometimes `Cleared for White House.`)
  - Signed / enacted: `Signed by President.`, `Became Public Law No: 119-NN.`
  - Veto path: `Vetoed by President.`, `Pocket Vetoed by President.`
- **A bill is _currently_ in PRESIDENT iff its LATEST action is presented-but-unresolved** — latest action matches `Presented to President` AND does not also show signed / public-law / vetoed. The bills table stores only the latest action, so "currently presented" = the presentment line with no later resolution. Counting all-time presentments and lumping them with ENACTED is the wrong read.

## What to find

1. **Locate the stage classifier.** Grep for where `stage` is assigned (the sync-time function mapping latest action → stage). Paste it.
2. **President branch?** Does it have a `president` / `PRESIDENT` case? If yes, paste it. If no, that alone is the gap.
3. **Ordering hazard.** If a president branch exists, check its match order against the signed / public-law / enacted branches. If `includes('President')` is tested before the public-law and signed checks, presented-and-signed bills wrongly land in PRESIDENT; if enacted is checked first, PRESIDENT only catches the narrow unresolved window (correct). State which way it runs.
4. **Confirm the real column names** on the bills table: the stage column, the latest-action-text column, and latest-action-date if present. Report them — the fix handoff needs them exact.
5. **Run the diagnostic queries** (read-only, adapt to the real column names). One-off manual run: local script via `getDb()` under `scripts/diagnostic/`, or the turso shell, your call. No request route, so the Vercel 20s abort doesn't apply; `LIKE '%…%'` is an unindexed scan over ~15k rows, which is fine — no `INDEXED BY` needed.

   **a. True president candidates (currently presented, unresolved) — the money query:**
   ```sql
   SELECT <bill_id>, <stage>, <latest_action_text>, <latest_action_date>
   FROM bills
   WHERE <latest_action_text> LIKE '%Presented to President%'
     AND <latest_action_text> NOT LIKE '%Became Public Law%'
     AND <latest_action_text> NOT LIKE '%Signed by President%'
     AND <latest_action_text> NOT LIKE '%Vetoed%'
   ORDER BY <latest_action_date> DESC;
   ```
   Count + the stage each row got. Rows that exist but aren't stage=PRESIDENT ⇒ classifier is mis-staging them. Zero rows ⇒ 0 is genuinely correct.

   **b. All-time presentment vocab by assigned stage (catches mis-staging either direction):**
   ```sql
   SELECT <stage>, COUNT(*)
   FROM bills
   WHERE <latest_action_text> LIKE '%Presented to President%'
   GROUP BY <stage>;
   ```

   **c. Sanity — anything presidential / public-law by stage:**
   ```sql
   SELECT <stage>, COUNT(*)
   FROM bills
   WHERE <latest_action_text> LIKE '%President%'
      OR <latest_action_text> LIKE '%Public Law%'
      OR <latest_action_text> LIKE '%White House%'
   GROUP BY <stage>;
   ```

## Report back

A short verdict:

- president branch: exists / missing (+ the code)
- ordering: correct / inverted (which checks run first)
- query (a): N currently-presented bills, assigned stages = …, with bill IDs if any are not PRESIDENT
- query (b)/(c): presentment-vocab counts by stage
- **Verdict:** either "0 is correct, transient empty window, fix is empty-stage UX" or "classifier gap, these bills are mis-staged, fix is the classifier."
- Column names found (stage col, latest-action col, date col) for the fix handoff.
