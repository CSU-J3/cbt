# HO 453 — Doc sweep: actions-walk NO-GO, retire the status-model fork (closes 452)

Docs-only, one commit. The HO 452 probe (`67ed564`) came back **NO-GO** — walking `/actions` recovers **0%** disposition beyond the top-level `latest_action_text` (the silent 91% is genuinely filed-never-acted). No build followed; this sweep records the finding, retires the status-model fork, banks the one orthogonal lead the probe surfaced (`recordedVotes` → amendment-vote-linkage), and **fixes the two stale premises the NO-GO breaks** in sibling docs.

Four files: `docs/roadmap.md`, `docs/oddities.md`, `docs/backlog.md`, `.claude/skills/cbt/SKILL.md`. **SKILL.md rides behind the self-mod guard** (diff + explicit approval before staging); show all four diffs before the commit.

---

## 1. `docs/roadmap.md` — append-only block + pointer bump

Insert **immediately after the HO 450 block** (`**Also (HO 450), the member-hub sponsored-amendments section…**`, ~line 306) and **before the `**Banked / unbuilt:**` line**. Verbatim:

---

**Also (HO 452), the actions-walk disposition probe — NO-GO, the status-model fork retired, no theme-% change.** The third fork banked in the HO 446–448 block (bill-hub → 448; member-hub → 450; this probes and **closes** the persisted status/disposition model). Probe committed `67ed564`, read-only, no build followed. **The question:** the display-only disposition dot (HO 448/450) colors only the **8.6%** of amendments with a top-level `latest_action_text`; the persisted-enum model would walk each amendment's `/actions` sub-resource to recover dispositions for the silent 91% — but that ~doubles the backfill (~6,800 → ~13,600 requests, ~85 → ~195 min), so it's only worth it if `/actions` actually carries those dispositions. **The finding: it doesn't — 0% recovery.** A stratified 155-amendment walk (`scripts/diagnostic/amendments-actions-probe-452.ts`, 0 errors / 0 throttles) found that no-top-level-action == **genuinely filed-never-acted**: both the general silent-91% stratum and the decisive `119-sconres-7` vote-a-rama stratum returned **100% submit/propose-only** `/actions` lists (0% terminal disposition), with an **empty residual** (the starter classifier left zero terminal actions unmatched — the 0% is a real absence, not a classifier miss). A vote-a-rama files ~1,131 amendments and votes on ~24; those ~24 already carry a top-level action, and the rest are never called up, so there's nothing in `/actions` to recover. **The top-level scan is the disposition ceiling** — a persisted enum would only persist what render already computes, for a doubled backfill and no coverage gain (oddities). So the status model closes NO-GO; the display-only dot stays as the complete-for-what's-available surface, not a stopgap. **One capability banked, orthogonal to dispositions:** `/actions` carries **`recordedVotes`** ({chamber, rollNumber, url, date}) — a clean amendment → roll-call-vote link (backlog QUEUED), the source for a future "how did each member vote on this amendment" surface, scoped on its own merits (it'd still pay the `/actions` walk cost, but for vote links, not dispositions). Payload also confirmed structured (`type` / 13 distinct `actionCode`s), though the text is already unambiguous. **No theme-% change** — a probe that retired a fork; no surface. This leaves the amendments pillar at **two live surfaces** (bill-hub, member-hub) with **one QUEUED fork** remaining (the `/amendments` aggregate) plus the new vote-linkage lead. Docs: HO 453. **Also notes now run through HO 452.**

---

No other roadmap edit; don't touch the `**Banked / unbuilt:**` standing line.

---

## 2. `docs/oddities.md` — one new entry, newest at top

Insert **above the current top entry** (`## Amendment latest_action_text coverage is 8.6%…`, ~line 9) — it directly extends and closes that thread. Verbatim:

---

## No-top-level-action amendments are genuinely filed-never-acted — the `/actions` walk recovers 0% disposition, so the top-level scan is the ceiling (HO 452, Jul 2026)

The HO 448 entry (below) flagged the `/actions` walk as the deferred path to classify the silent 91% of amendments the top-level `latest_action_text` doesn't cover. HO 452 probed it and **closed it NO-GO**: walking `/actions` recovers **0%** additional dispositions.

The intuition it disproves: "a sparse top-level `latestAction` means the disposition is hiding in the `/actions` sub-resource." It isn't. A stratified 155-amendment walk found no-top-level-action == **filed-never-acted**, not "acted-but-not-summarized-at-top-level." Both the general silent stratum and the decisive `119-sconres-7` vote-a-rama stratum returned **100% submit/propose-only** action lists (0% terminal disposition), and — the guard that makes this trustworthy — an **empty residual**: the starter classifier left zero terminal-disposition actions unmatched, so the 0% is a real absence, not a classifier miss. The mechanism: a Senate vote-a-rama *files* ~1,131 amendments (sconres-7) and *votes on* ~24; the ~24 already carry a top-level action (they're part of the 8.6%), and the rest are never called up. So there is nothing in `/actions` to recover — the top-level `latest_action_text` scan is the **disposition ceiling**, and the HO 448/450 display-only dot already colors the full classifiable set. A persisted status enum would persist exactly what render computes, at the cost of ~doubling the backfill (~6,800 → ~13,600 requests) for zero coverage gain — which is why the status-model fork closed NO-GO (backlog DONE). If a future reader re-proposes walking `/actions` to "fill in" the missing dispositions, this is the record that it was measured and there is nothing there.

**What `/actions` *does* uniquely offer (not disposition):** `recordedVotes` on an action ({chamber, rollNumber, url, date}) — a clean amendment → roll-call-vote link, banked as a vote-linkage lead (a different feature, scoped on its own merits).

---

## 3. `docs/backlog.md` — retire the status-model fork, bank the vote-linkage lead, fix the aggregate's stale premise

**(a) Remove the status-model item from QUEUED** (~line 80) and add a **DONE tombstone** (top of DONE, matching the section format):

- **Amendments status/disposition model** — **CLOSED NO-GO HO 452** (probe `67ed564`). The persisted-enum model would have walked each amendment's `/actions` sub-resource to classify the silent 91% the top-level `latest_action_text` misses, at ~2× the backfill (~6,800 → ~13,600 requests). The probe (`scripts/diagnostic/amendments-actions-probe-452.ts`, stratified n=155, 0 errors) found **0% recovery**: no-top-level-action == genuinely filed-never-acted — both the general silent stratum and the decisive `119-sconres-7` vote-a-rama stratum returned 100% submit/propose-only `/actions`, empty residual (a real absence, not a classifier miss). A vote-a-rama files ~1,131 and votes on ~24; the ~24 already carry a top-level action. So the top-level scan is the disposition ceiling and the HO 448/450 display-only dot is already the complete surface — a persisted enum would persist what render computes for a doubled backfill and no coverage gain (oddities). *Orthogonal lead surfaced by the probe:* `/actions` `recordedVotes` → amendment-vote-linkage, banked separately in QUEUED (a vote feature, not disposition).

**(b) Add a new QUEUED item** for the vote-linkage lead:

- **Amendment → roll-call-vote linkage (`recordedVotes`)** — surfaced by the HO 452 probe. Amendment `/actions` objects carry `recordedVotes` ({chamber, rollNumber, url, date}), a clean link from a voted amendment to its roll call — the source for a future "how did each member vote on this amendment" surface (member-level yea/nay on a specific amendment via a `member_votes` join). *Cost:* still needs the `/actions` walk (~2× the amendments backfill the HO 452 probe measured), but the payoff is **vote links, not dispositions** (the walk does NOT recover dispositions — see DONE, status-model NO-GO). *Sparse by nature:* only the ~8.6% of amendments that were actually voted on carry a `recordedVotes` at all. *Gate:* build if amendment-level vote detail becomes wanted. *Owner:* Corey.

**(c) Fix the stale premise in the `/amendments` aggregate QUEUED item** (~line 79). It currently ends "...the SAMDT/HAMDT type split, disposition rates once the status model lands." The status model won't land — update that clause to:

> ...the SAMDT/HAMDT type split, and disposition rates computed from the top-level `latest_action_text` set (the status-model enrichment closed NO-GO at HO 452 — the ~8.6% *acted* amendments are the full available disposition data, so rates read honestly as a share of acted, not all filed).

Leave the rest of that item unchanged.

---

## 4. `.claude/skills/cbt/SKILL.md` — fix the now-stale "deferred status model" framing + a don't-relearn note (SELF-MOD GUARD)

**(a) The `getBillAmendments(billId)` query-helper bullet** currently ends calling the status model "the deferred persisted status model (which needs the actions walk the sync skips)." It's no longer deferred — it's NO-GO. Replace that trailing clause with:

> …NOT a persisted status model — the `/actions`-walk enrichment that would have classified the silent 91% closed **NO-GO at HO 452** (the walk recovers 0% disposition; no-top-level-action == filed-never-acted; oddities), so the top-level scan is the disposition ceiling and this dot is the complete surface.

(Keep the HO 450 `getMemberAmendments` sibling sentence that follows it, if the ordering allows — append/splice so both survive.)

**(b) The `sync:amendments` backfill entry** — append a one-clause don't-relearn note where the actions-walk skip is relevant (the entry already notes the sync takes top-level `latestAction`, not an `/actions` walk):

> The `/actions` sub-resource is deliberately **not** walked and shouldn't be added for dispositions — HO 452 proved it recovers 0% beyond the top-level `latest_action_text` (oddities). `/actions` uniquely offers only `recordedVotes` (an amendment→roll-call-vote link, banked as its own feature).

No other SKILL.md change.

---

## Git discipline

- Show all four diffs. **SKILL.md waits for explicit approval before staging** (self-mod guard); the roadmap append + oddities entry + backlog edits follow their file conventions (append-only roadmap block, newest-at-top oddities, QUEUED→DONE + the two in-place QUEUED edits) but still show before commit.
- One commit, **explicit pathspec**: `docs/roadmap.md` + `docs/oddities.md` + `docs/backlog.md` + `.claude/skills/cbt/SKILL.md`. Docs-only — no code, no `scripts/` (the probe is already committed at `67ed564`).
- Commit message: `docs(sweep): retire the amendments status-model fork on the HO 452 NO-GO (HO 453, closes 452)`
- Ancestry eyeball before push: one commit riding, clean fast-forward, nothing behind, nothing unrelated staged, the concurrent session's files (`RaceCard.tsx` / `CompetitiveRacesBlock.tsx` / `CompetitiveRacesStrip.tsx` / `globals.css`) untouched and their history preserved. Push, report the remote SHA. No verify:deploy — docs-only.

---

read docs/handoffs/453-doc-sweep-452.md and follow it
