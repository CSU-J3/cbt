# HO 446 — Amendments source probe (read-only, GO/NO-GO)

New pillar: **congressional amendments**, along the bill spine. This is the *probe*, not the build. Same split as HO 434→435 (LDA) and 439→440 (bill-drill): measure shape, volume, and join reality first; the data layer is HO 447.

Amendments were picked over nominations because they **dual-attach**: an amendment record carries `amendedBill` (→ `bills.id`) *and* `sponsors` (→ `bioguide_id`), the cleanest possible spine join. Nominations have no bill and the nominee isn't a tracked member — a committee/`/president` pillar, sequenced later. Amendments reuse the existing Congress.gov client (`lib/sync.ts` mechanics) wholesale — one new endpoint, one future table.

The API is **not** a liveness unknown (it's the product's workhorse). So this probe is narrower than the LDA source probe: **field shape + corpus size + `amendedBill` resolution + action vocabulary**. No schema. No sync. No surface. One committed diagnostic. A GO/NO-GO with numbers.

---

## Scope guardrail

- **Read-only against the API + a read-only lookup against the live `bills` table.** No writes, no new table, no migration.
- **One deliverable:** `scripts/diagnostic/amendments-probe-446.ts` (sibling to `lda-coverage-435.ts`), plus a short findings write-back in chat.
- Do **not** ingest, do **not** design a schema, do **not** touch `vercel.json`. Those are HO 447.
- Uses the existing `CONGRESS_API_KEY` env and `getDb()` — both available locally.

---

## Endpoints (so you don't guess)

Base `https://api.congress.gov/v3`, `api_key` query param, `format=json`, `limit` up to 250. Same 429-backoff shape as `fetchJson` in `lib/sync.ts` — reuse that helper's pattern.

- **List:** `GET /amendment/{congress}?limit=250&offset=N` → `{ amendments: [...], pagination: { count, next } }`. List items are **thin**: `{ congress, type, number, url, latestAction, updateDate }`. `amendedBill`/`sponsors`/`purpose` are **detail-only**.
- **Detail:** `GET /amendment/{congress}/{type}/{number}` → `{ amendment: {...} }`. Expect: `type` (**HAMDT** / **SAMDT** / **SUAMDT**), `purpose`, `description`, `sponsors[]`, `latestAction`, and **exactly one of** `amendedBill` (`{congress,type,number,...}`) **or** `amendedAmendment` (this amendment amends another amendment — a sub-amendment, no direct bill), plus `amendmentsToAmendment {count,url}`, `actions {count,url}`, `cosponsors {count}`.
- `{congress}` = `getCurrentCongress()` (119).

**Join key construction:** from `amendedBill` build `` `${congress}-${type.toLowerCase()}-${number}` `` and look it up in `bills.id`. That's the resolution check.

---

## What to measure

1. **Endpoint shape.** Pull the list page-1, then fetch detail for a **stratified sample of ~40**: mix all three types (HAMDT/SAMDT/SUAMDT) and span low + high amendment numbers (lifecycle variety — freshly-offered vs. long-disposed). Dump 2–3 full detail JSONs verbatim into the findings so we see the real field set (especially whether it's `amendedBill` vs `amendedAmendment`, and the `latestAction.text` phrasing).

2. **Corpus size + type split.** Read `pagination.count` for the total 119th amendment count. Then break down by type — cheapest is three list calls filtering nothing and tallying `type` across a few pages, or if the API supports a type-scoped list path, use it; otherwise report the count and the type distribution observed in the sample + note the method. **This number decides live-vs-precompute** — if it's LDA-scale (10⁵) we precompute; if it's bills-scale or smaller (10³–10⁴) live aggregation may be viable (but that gets cold-instrumented in the build, not assumed here).

3. **Join reality** (the load-bearing number, mirrors LDA's 25.4%):
   - Of the sampled details, **% carrying `amendedBill`** vs **% carrying `amendedAmendment`** (bill-amend vs sub-amend) vs **% with neither**.
   - Of those with `amendedBill`, **% whose constructed `bills.id` resolves to a row we already track** (SELECT against live `bills`). We sync the whole current Congress, so expect high — but measure; named/appropriations bills or cross-Congress references could miss.
   - Report all three as fractions of the sample with n.

4. **Action / status vocabulary.** Collect the distinct `latestAction.text` values across the sample (and, for ~5 amendments, walk the `actions` sub-resource). We need the raw phrasing for an amendment-status model later — the analogues of `computeStage`'s inputs: *agreed to* / *rejected* / *withdrawn* / *fell* / *ruled out of order* / *not germane* / *proposed*. Just enumerate what appears; don't classify.

5. **Backfill cost sizing.** From `pagination.count` and `PAGE_SIZE=250`, report: list pages for a full 119th sweep, and the detail-fetch count if we hydrate every amendment (vs. list-only). Note whether the thin list carries enough (`amendedBill` is detail-only, so a bill-linked surface needs detail hydration — flag that cost). This sizes the HO 447 sync and tells us if it fits the 300s cron budget or needs the resumable DB-frontier pattern like `sync:lda`.

---

## Answer these explicitly (the GO/NO-GO)

- **GO/NO-GO** on amendments as a pillar.
- Total 119th amendment count + HAMDT/SAMDT/SUAMDT split.
- `amendedBill` presence rate, `amendedAmendment` rate, neither rate (sample n).
- Bill-resolution rate against live `bills` (sample n).
- The `latestAction` vocabulary observed.
- Full-backfill cost estimate (list pages + detail fetches) and whether one cron run covers it or it needs resumable framing.
- Any surprise (pagination quirk, a type with a different field shape, `amendedBill` pointing at amendments-to-amendments transitively, rate-limit behavior at limit 250).

---

## Git discipline

Standing rules apply even for a one-file diagnostic:

- Propose the plan first, show the diff, **wait for approval before committing**. No auto-commit.
- **Explicit pathspec** — stage only `scripts/diagnostic/amendments-probe-446.ts`. Nothing else rides.
- Eyeball ancestry before any push: one commit riding, clean integrate, no unrelated files staged.

---

## What this unblocks

The arc, so the shape is visible:

- **446 (this)** — probe: shape + size + join reality + action vocab. GO/NO-GO.
- **447** — data layer: `amendments` (+ maybe `amendment_bills` if the sub-amendment/multi-bill fan-out warrants a link table, which #3 will tell us) + `sync:amendments` + cron. The build reports ingest cost.
- **surface** — instrument the query cold *before* speccing the query layer (the standing LDA lesson: a clean EXPLAIN says nothing about cold latency). Placement (bill-hub section on `/bill/[id]` reusing the LOBBYING-section pattern, vs. a standalone `/amendments` analytical surface like `/lobbying`) gets decided once we have the numbers — Corey's call, not baked here.

---

read docs/handoffs/446-amendments-source-probe.md and follow it
