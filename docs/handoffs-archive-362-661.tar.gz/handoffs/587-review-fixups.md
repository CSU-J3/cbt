# HO 587 — read-out verdict + three surgical fixups, then land

This file replaces a chat block that didn't survive the relay (second swallow this cycle; `587-review` confirmed still at `e8fead4` via `ls-remote`). It is self-contained — assume none of the swallowed block arrived.

## Read-out verdict: APPROVED, with three text fixups below

Verified out of the repo: ancestry FF-clean (two commits, `a1a97a8` an ancestor), scope exactly the four docs files with docs/SKILL split, `--numstat` identical under `--ignore-cr-at-eol` (no CRLF churn), pointer sequence 580→582→584→586 monotonic with the 584 block byte-untouched.

All four flagged decisions approved:
1. **Oddities append-at-end** — correct call. The file header is the convention; the spec's "newest-first" was wrong and came from stale memory on the review side, now corrected there. The in-repo convention wins over any spec wording.
2. **Roadmap as one dense paragraph** — house style, approved.
3. **SKILL two hunks** — both are stale-claim reconciliations 586 forced; the query-helper note is now the best single description of `getPrimaryForRace` in the record. Approved.
4. **AK note folded into the block** — approved.

## The three fixups (FIND/REPLACE-exact; one docs commit onto 587-review; SKILL untouched)

Two of the three defects originate from the review side and the record should stay honest about that — B misattributes a catch, C propagates a conflation the review's discharge message introduced.

### A. Oddities, branch-blindness entry — the parenthetical states the wrong mechanism
The branch never fired because the first build's `district != null` GUARD skipped NULLs before any lookup ran; padding never executed. The parenthetical instead narrates the (wrong) padding hypothesis as the mechanism.

FIND (match verbatim incl. backticks):
`(had the \`members.district=NULL\` → \`primaries."00"\` padding been wrong, the null would have missed the district row)`
REPLACE:
`(the first build's \`district != null\` guard skipped a NULL district before any lookup could run)`

### B. Oddities, reviewer-injected entry — the catch is misattributed
The re-run did NOT catch the ordering defect; the review-ref diff read did. The re-run then proved the corrected ordering a no-op (byte-identical M-series). Crediting an instrument with a catch it didn't make is the same failure class as recording an unfired guard as protection.

FIND:
`The **re-run-after-change discipline caught it** — re-running the M-series against the built query surfaced the mis-ordering before it left the branch.`
REPLACE:
`**The review-ref diff read caught it** — the mis-ordering was spotted in the built SQL off \`586-review\`, and the mandated re-run-after-change then proved the corrected ordering a no-op on current data (byte-identical M-series). The diff read is what caught it; the re-run is what made the fix safe to ship.`

Same entry, closing clause — FIND:
`faithful implementation of an under-specified spec is a defect path, and the re-run is what exists to catch it`
REPLACE:
`faithful implementation of an under-specified spec is a defect path, and reading the built artifact rather than the spec is what catches it`

### C. Backlog P3 + oddities entry 4 — 11+8 decomposes the 19, not the 77
Your M5 report had it right ("the 19 are just the incumbents who sit in those rows"); the review's discharge message compressed 11+8 into the 77's composition and it propagated into both docs. As written, the close criterion can read green while 58 rows stay unexamined.

Backlog — FIND:
`M5 ran the composition down: **11** are the incumbent's-party primary being genuinely uncontested (honestly no votebox — the district page parsed fine), **8** are both-party-empty district holes`
REPLACE:
`Of the 77, the **19** that currently host a sitting member's chip were run down by M5: **11** are the incumbent's-party primary being genuinely uncontested (honestly no votebox — the district page parsed fine), **8** are both-party-empty district holes`

Backlog, same item — FIND:
`— pre-existing HO 563-class roster residue or dual-uncontested, undetermined which.`
REPLACE:
`— pre-existing HO 563-class roster residue or dual-uncontested, undetermined which; **the remaining 58 rows host no current member's chip and are uncharacterized as of HO 586.**`

Backlog close criterion — FIND:
`*Close:* each of the 8 either explained as genuinely uncontested or traced to a parse gap.`
REPLACE:
`*Close:* the zero-candidate past-row count either falls or every remaining row is explained as genuinely uncontested — the 8 holes explained-or-traced AND the 58 uncharacterized at least bucketed (uncontested vs hole); the count instrument must not read 77 while the item reads closed.`

Oddities entry 4 — FIND:
`(11 uncontested-with-a-rostered-sibling + 8 both-party-empty holes, pre-existing)`
REPLACE:
`(the 19 rows hosting a current member decompose as 11 uncontested-with-a-rostered-sibling + 8 both-party-empty holes; the other 58 are uncharacterized — pre-existing)`

## Then land, on your own report — no further round-trip

These are FIND/REPLACE-exact, so after pushing the fixup commit onto `587-review`: fast-forward main to the new HEAD (`git push origin origin/587-review:main` equivalent from your local — fast-forward, no force), then `git push origin --delete 587-review`. Docs-only; no deploy verification owed. Report the final SHAs.
