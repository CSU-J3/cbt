# HO 439 — bill-keyed lobbying cost probe (read-only diagnostic)

## What this is

A cold-latency measurement, **not** a surface spec. Before building bill-keyed lobbying on `/bill/[id]` (the other fork of the LDA arc, banked in the HO 437 roadmap block), measure whether the per-bill query can run **live** on the request path or must be **precomputed** like the `/lobbying` rollup.

The arc's load-bearing lesson (see the `lib/lda-rollup.ts` header + oddities): this Turso is slow at random row-fetch-by-id and fine at sequential scans, and a clean `EXPLAIN` tells you nothing about cold latency. So we instrument before we spec.

**Do not write the surface. Report the numbers and a live-vs-precompute recommendation. The surface is HO 440, spec'd off this result.**

## The query shape under test

For a `bill_id` like `119-hr-1` (`bills.id` = `${congress}-${type}-${number}`, type lowercased), the bill page runs the same shape as the `/lobbying` per-code drill but scoped by bill instead of issue code:

1. **Seek** (`idx_lda_activity_bills_bill`): `SELECT filing_uuid, activity_ordinal FROM lda_activity_bills WHERE bill_id = ?` → distinct `filing_uuid`s. Bounded index seek — expected cheap.
2. **Fetch filing rows** (PK `IN`-lookup, chunked at `HYDRATE_CHUNK = 400`): `registrant_name, client_name, income, expenses, dt_posted, filing_type, filing_period` from `lda_filings` for those uuids. **This is the random row-fetch that bit the per-code drill.**
3. **Hydrate codes/bills** — reuse `hydrateFilings(db, uuids)` from `lib/lda-rollup.ts` (chunked distinct issue codes + resolved bill ids).
4. **Aggregate in JS** — top firms / top clients ranked by **distinct filings**, not raw activity count (the HO 435 rule: one registrant skewed 119-hr-1 to 11,567 raw vs 1,506 distinct); recent N; per-bill issue-code breakdown.

The measurement is only useful if it times the **real** shape. Write the actual query the bill page would use, then time it — not a synthetic `SELECT COUNT(*)`.

## Target

`119-hr-1` is the known worst case (most-lobbied; HO 435 measured ~1,506 distinct filings / 11,567 raw activity rows). **Confirm it's still #1 before timing:**

```sql
SELECT bill_id, COUNT(*) c FROM lda_activity_bills GROUP BY bill_id ORDER BY c DESC LIMIT 5;
```

That's a full scan of the 174k-row `lda_activity_bills` (the *small* table, sequential — this Turso is fine at it). Time the bill query against whatever's actually #1.

## Also measure the fan-out distribution

119-hr-1 might be a lone outlier or the head of a fat tail — that changes the architecture. Report the **distinct-filing-count per bill** distribution across bill-linked bills: count of bills with ≥1 link, and p50 / p90 / p99 / max distinct filings (dedupe to distinct `filing_uuid` per `bill_id` from the same GROUP BY). A lone outlier admits a live query with a per-bill cap; a fat tail forces precompute.

## Methodology

- Use the **uncapped client** (`uncappedLdaClient()` from `lib/lda-rollup.ts`, 240s abort) so a slow cold run reports its true number instead of truncating at the `getDb` `boundedFetch` 10s cap.
- **Cold is the number that matters.** Run the full bill query as the FIRST statement on a fresh client (fresh process / fresh `createClient`), before any warming query. Report cold total wall.
- Then **re-run warm** (same client, second call) and report it — the cold/warm delta is the whole point.
- **Break down by stage:** time (a) the seek alone, (b) the filing-row fetch alone, (c) `hydrateFilings` alone, (d) the JS aggregation. We need to know WHERE the cost is (predicted: seek cheap, fetch expensive).
- Script as `scripts/diagnostic/lda-bill-cost-439.ts`, sibling to `lda-coverage-435.ts`. Run against prod Turso. **Don't commit yet** — the deliverable is the report; committing the script is a wrap decision.

## Report back

- Confirmed worst-case `bill_id` + raw activity count + distinct filing count.
- Fan-out distribution: bills-with-links count; p50 / p90 / p99 / max distinct filings.
- Cold total wall for the worst-case bill query; warm total; per-stage breakdown.
- Whether cold total fits under the `getDb` 10s `boundedFetch` cap (the live-safe line), and with how much margin.

## Decision framework — for the HO 440 spec, not this handoff

- **Cold total comfortably < ~2–3s, well under 10s** → build **LIVE**: per-bill query on the request path through `getDb`, `unstable_cache` keyed by `bill_id`, tag `"lda"`. No blob, no staleness, scopes to any bill for free. Preferred.
- **Worst case slow but a lone outlier** (p99 fine) → live with a per-bill hydration **cap**: `LIMIT` the seek to the top-N most-recent filings for the drill, honest "+N more" overflow, so the pathological bill can't 500.
- **Fat tail / broadly slow** → **precompute**, near-free path: extend `computeLdaRollup` to also emit a per-bill drill for bill-linked filings **in the same sequential in-memory pass** — it already reads all three tables whole and holds `filings` + `billsByUuid` + `linkedUuids`, so grouping by `bill_id` instead of `general_issue_code` is the same JS operation. Store as a second `dashboard_state` blob (or a `drillByBill` field), threshold to bills with ≥N filings to bound size, served O(1). Only ~25% of bills get an entry; the rest show the empty state. **Note this path in the report so 440 can cost it — don't build it here.**

## Constraints

- Read-only. No schema change, no `migrate.ts` edit, no `dashboard_state` writes.
- No surface, no `/bill/[id]` edit, no new helper in `queries.ts` — this is a measurement.
- Don't commit the diagnostic script; hold for the wrap.
