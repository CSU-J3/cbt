# HO 507 — `/bill/[id]` redesign: panel-family hero + sectioned layout

## Why

`/bill/[id]` is the page carrying the most accumulated debt with the least attention. It has had only incremental chrome since HO 125 (committees 145, masthead 184/185, then sections bolted on in arrival order: hearings 267/324, lobbying 440, amendments 448) while every browse surface moved to the current design generation (`/members` 328, `/lobbying` 486, `/bills` 496). Concretely:

- **One undifferentiated box.** Every section stacks inside a single `bg-row-hover` div separated by `<Divider/>` rules — the pre-328 idiom. The member hub's sectioned layout is the detail-page precedent and this page never got it.
- **The summary is buried 6th.** The product exists to answer "WTF is this bill"; the Gemini summary IS that answer and it sits below Committees, Hearings, Amendments, and Lobbying.
- **The feed's hover panel outclasses the dedicated page.** `BillExpandPanel` (HO 317) has the colored stage pipeline with the pulsing current node; the page has plain `StageIndicator` arrow text. The panel shows RELATED NEWS via `getNewsForBill`; the page never calls it — the ⚡ media-attention signal links here and finds nothing.
- **The last borderless `TopicTags` holdout** (backlog §115b, banked at HO 316).

The redesign: **the page becomes the expand panel's big sibling** — same stage bar, same summary treatment, same news rows, same boxed meta card — plus the four deep sections only the page carries, each in a member-hub section shell. Approved mock: `mock-507-bill-detail.html` (built from verbatim `globals.css` tokens + the shipped `.bxp-*`/`.v2f-bar` CSS).

## Ground truth

Clone / hard-reset to `origin/main` first — HEAD should be **`22fd265`** (HO 506 docs). Re-grep every line reference below at write time.

## Scope

One file rewritten: `app/bill/[id]/page.tsx`. Zero query-layer changes beyond adding one existing cached read to the page's `Promise.all`. Section CONTENT components (`BillCommitteeItem` rows, `HearingMeetingsEmbed`, `BillAmendments`, `BillLobbying`) render **unchanged** — this is chrome restructuring, the rows-out-of-scope convention from HO 484/496.

**No probe.** The only added read is `getNewsForBill(bill.id, 5)` — the exact query `/api/bill/[id]/panel` already runs on every feed expand (bounded `bill_id = ?` seek, `unstable_cache`d). No new cold shape.

## Build

### 1. Data

Extend the existing `Promise.all` with `getNewsForBill(bill.id, 5)` (import from `@/lib/queries`; it returns `NewsMention[]`). Everything else the page needs it already fetches.

### 2. Hero card

Replaces the current title row + `Field` dt/dd grid. A `bg-row-hover` bordered card (keep the existing card wrapper treatment) containing:

- **Title row:** bill id (16px, `--accent-amber`, `formatBillId`, `title` attr = `BILL_TYPE_LABELS`) · title (15px, sans via inline `fontFamily: "var(--sans)"` or the existing pattern) · `WatchlistToggle` right. Unchanged in substance from today.
- **`BillStageBar`** full width — import from `@/components/BillExpandPanel` (exported, HO 317; it's a `"use client"` module, importing into this server page just creates the client boundary — props `bill` + `nowMs` are serializable, and `BillDetail extends FeedBill` so `bill` satisfies the prop type directly). Handles null/off-path stage by returning null — no placeholder needed. **This replaces the `StageIndicator` Field.** Do NOT delete `StageIndicator` — hearings surfaces still consume it (HO 467 exemption).
- **`.bxp-body` grid** (the panel's 1.35fr/1fr):
  - **Left (`.bxp-left`):** `SUMMARY` relhdr + the summary as `.bxp-summary` prose (falls back to omitting the block when `bill.summary` is null, same as today) → `RELATED NEWS` `.bxp-relblock` with up to 5 `.bxp-relnews` rows (sans title, `SOURCE · age` meta via `formatRelativeAge`... use the existing news-row idiom from the panel, `article_url` external links) + a foot link `all coverage → /news?bill=${bill.id}` (the HO 501 route). Empty state: `NO RELATED NEWS` (`.bxp-relempty`), matching the panel.
  - **Right (`.bxp-metabox`):** rows in order — **Sponsor** (name as member link where bioguide resolves + `PartyTag` bracket; today's plain-text fallback preserved) · **Cosponsors** (amber count + the 5-seg `.bxp-cosbar`, `cosponsorSegments` — lift or re-inline the 1-line helper, `Math.min(5, Math.ceil(count/10))`) · **Topics** (`TopicChips` — the shared bordered chip, **closing the HO 316 holdout**) · **Introduced** (`formatDateLong`) · **Last action** (`formatDateLong` + `· Nd ago` rel age, **plus the full `latest_action_text` below it** in an 11.5px muted sans block, 3-line clamp (`-webkit-line-clamp: 3`), full text in the `title` attr — this **replaces the standalone LATEST ACTION section**, which is gone) · a final row holding the **`CONGRESS.GOV ↗`** external link (moves out of the footer buttons). **No Committee row** — the panel has one because it has no committees section; this page's full section is directly below, don't duplicate. The clamp rule is page-specific → it lives under the `.bdp` scope (§5), not in `.bxp-*`.

### 3. Section shells (member-hub idiom, condensed per the approved mock)

Each a `<section>` — `border border-strong`, `bg-panel`, header bar (`flex justify-between px-4 py-3 border-b`, 12px uppercase `--text-dim` heading with the count). The condensation moves (all with the HO 492 `/lobbying`-compaction precedent):

1. **`COMMITTEES (N)` | `HEARINGS (N)` side-by-side** — a 2-col pair grid (`1fr 1fr`, 16px gap, single-column ≤900px — the 492 `.lob-secs` pattern; the grid rule goes under `.bdp` scope). Left: the existing `BillCommitteeItem` rows, no header out-link (each row already links its committee hub); at half width the chamber/parent/activity meta drops to a second line — that's a page-level wrapper concern, keep the row component untouched. Right: `HearingMeetingsEmbed` + the existing `BILL_MEETINGS_CAP`/overflow foot unchanged; header right-link `/hearings →`; header shortened to `HEARINGS` (the half-width bar can't afford "COVERING THIS BILL"). **When exactly one of the pair is empty, the survivor renders full-width** (no half-width orphan); both empty → neither renders, as today.
2. **`AMENDMENTS (N) · X AGREED · Y FAILED`** — **the header absorbs the component's internal stat line** ("6 amendments · 2 agreed · 1 failed" duplicated the header count; the page computes the agreed/failed tallies from `rows` via the same `deriveDisposition` values the dots use — or `BillAmendments` exposes them; your call, cheapest wins). Remove the stat line from `BillAmendments` — **grep first to confirm it's single-consumer** (`/bill/[id]` only; backlog says yes, verify), which keeps this out of the HO 486 riding-regression class. Header right-link **`/amendments?bill=${bill.id} →`** — the aggregate shipped at HO 461, so the component's "no /amendments surface to link yet" comment is stale; fix the comment in the same edit. **Bound the body** — `max-height: 340px`, internal scroll (`.bdp` scope, the 492 `.lob-sec-scroll` pattern) — so the 60-row magnet render (`119-sconres-7`) stops setting the page height.
3. **`LOBBYING (N FILINGS · M CLIENTS)`** — same move: header absorbs `BillLobbying`'s internal stat line; remove it from the component (**same single-consumer grep-verify**). **No header out-link** — the component's `see all lobbying →` foot survives; don't double-link.

The standalone `LATEST ACTION` section is **gone** (folded into the metabox, §2). Section omission rules otherwise identical to today: each section renders only when its data is non-empty/non-null.

### 4. Footer — one row

`← Back to feed` · `▸ Raw JSON` toggle · `Summary by {model} · {date}` attribution right-aligned (`margin-left: auto`), all on a single flex row. Congress.gov moved to the metabox (above). Raw JSON stays a **no-JS `<details>`** if you can make the open state render the `<pre>` full-width beneath the row cleanly (e.g. `details` as a full-width wrapper with the summary absolutely positioned into the row, or the row inside the details); if that fights the flex layout, a minimal client toggle island is acceptable — the constraint is: collapsed = one footer row, open = pre full-width below it.

### 5. CSS containment — the load-bearing rule

This page becomes a **new consumer of the shared `.bxp-*` and `.v2f-bar` classes. Zero edits to those rules** — the HO 486 riding-regression class (editing a shared component/class for one consumer's benefit) is exactly the trap here; the feed panel must render byte-identical after this ships.

Any page-specific deviation goes under a **new `.bdp` wrapper scope** (bill-detail-page), additive rules only — the HO 486/492/496 scoped-wrapper pattern. The known set:

```css
/* mobile: metabox stacks under the left column */
@media (max-width: 760px) {
  .bdp .bxp-body { grid-template-columns: 1fr; }
  .bdp .bxp-left { padding-right: 0; }
  .bdp .bxp-metabox { margin-top: 14px; }
}
/* committees|hearings pair (492 .lob-secs pattern) */
.bdp .bdp-pair { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
@media (max-width: 900px) { .bdp .bdp-pair { grid-template-columns: 1fr; } }
/* amendments magnet bound (492 scroll pattern) */
.bdp .bdp-amend-scroll { max-height: 340px; overflow-y: auto; }
/* metabox latest-action clamp */
.bdp .bdp-latext { display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }
```

(class names yours to pick; the scoping is the requirement). Section shells otherwise use the member-hub Tailwind-inline idiom — no new global classes.

### 6. `TopicTags` orphan check

After the metabox swap, `grep -rn "TopicTags" app/ components/`. If `/bill/[id]` was the last consumer (backlog says it is — verify, don't trust), **delete `components/TopicTags.tsx` + any CSS only it used, in this same commit** — the orphaning is caused by this change, so removal rides with it (not the ride-along-refactor class). If another consumer surfaces, leave it and report.

## Verification

- `/bill/119-hr-1` (heavy: blob-path lobbying, amendments, hearings, news) — every section populated, stage bar renders, metabox complete, headers carry the folded tallies.
- `/bill/119-sconres-7` (the 1,131-amendment magnet) — the amendments body scrolls inside its 340px bound instead of setting the page height.
- A committees-empty or hearings-empty bill — the pair survivor renders full-width, no half-width orphan.
- A summary-null or news-empty bill — SUMMARY omitted / `NO RELATED NEWS` empty state, no layout collapse.
- A stage-null bill — no bar, no gap artifact. An enacted bill — bar fully reached, current node `done` (no ping).
- A long `latest_action_text` — clamps at 3 lines in the metabox, full text on hover (`title`).
- `/bills` feed expand panel — **byte-identical before/after** (the containment check).
- A hearings surface using `StageIndicator` still renders.
- Mobile ≤760px — metabox stacks; ≤900px — the committees|hearings pair stacks.
- `npm run typecheck` green (CI runs it — the `nowMs` required-param contract from HO 490 applies to every age call you touch).

## Git discipline

- Clone / hard-reset to `origin/main` first; HEAD `22fd265`.
- Explicit pathspec staging; never `git add .`. Expected files: `app/bill/[id]/page.tsx`, `app/globals.css` (the `.bdp` block only), `components/BillAmendments.tsx` + `components/BillLobbying.tsx` (stat-line removal + the stale comment — single-consumer, grep-verified), possibly `components/TopicTags.tsx` (deletion).
- **Live UI → show the actual diff hunks and wait for approval before committing.**
- One commit: `feat(bill): detail page redesign — panel-family hero + sectioned layout (HO 507)`.
- Ancestry eyeball before push (`git log --oneline @{u}..HEAD` — exactly one commit, clean fast-forward, no concurrent-session files). Fast-forward only.
- No docs in this commit — the roadmap/backlog/SKILL sweep is the follow-on doc-sweep HO.

## Report back

The page diff + the globals.css hunk, a note confirming the feed expand panel renders unchanged, the `TopicTags` grep result, and screenshots (or a prod-verify list) across the four bill shapes above.

---

read docs/handoffs/507-bill-detail-redesign.md and follow it
