# HO 367 — Members header consolidation

Confirm the next free number before saving: `ls docs/handoffs/ | sort -V | tail`. Body assumes 367; if taken, bump to the next free number, rename the file, and report the final name so the read instruction resolves.

## Premise correction — read first

The attached brief treats the Members/Committees two-pane merge as an open thread that will "replace this whole page." It already shipped: **HO 328, prod SHA `6c63cc3`**. `/members` is the merged two-pane browser now — committee rail (312px, left) + member list (1fr, right), with `MemberTopicBar`, committee-scoped rosters, and cross-filtering. `/committees` redirects here.

There's nothing to fold into; this lands standalone. Two consequences:

- The attached mockup (`members-header-consolidated.html`) shows a single-list page with **no committee rail**. That's the pre-merge shape. The rail, `MemberTopicBar`, `CommitteeRailRow`, scoped rosters, cross-filter, the expanded member card — everything HO 328 built — **stays untouched**. The mockup governs the header region only (the title row + filter-bar readout); treat its body as out of date.
- Both edits are scoped to the **member pane**. Nothing left of it gets touched.

**Ground yourself in the live page before editing, not the mockup.** Grep the current `/members` page/component and confirm both things the mockup assumes still exist:
1. a standalone page-level `MEMBERS` title row sitting between the nav row and the member-pane filter bar (the HO 323 chrome arc left per-page secondary titles in place — the same situation HO 366 just removed for `/hearings`);
2. a filter-bar readout currently rendering the `536 … 119th`-style count.

If either is absent or differs materially from the mockup's starting state, **stop and report the actual current header structure** before changing anything. Don't synthesize a title row or readout the live page doesn't have.

## Scope

Member-pane header only. Two edits, both above the member list. Committee rail / topic bar / scoped rosters / expanded card all untouched. Masthead chrome (HO 323/325) untouched.

## Changes

### 1 — Remove the standalone MEMBERS title

Delete the page-level `MEMBERS` secondary title row sitting between the nav row and the filter bar. It echoes the breadcrumb (`…\119TH\Members>`) directly above. Delete the row entirely. This is the members-side analogue of HO 366 (hearings): same redundant-secondary-title removal, supersedes what the HO 323 arc left in place here.

The member-pane filter bar moves up one row as a result. That's the only layout effect; no spacing rework. After removal, **verify clean borders** — the filter bar should sit directly under the nav row's bottom border with a single rule: no doubled border (nav's `border-bottom` plus a leftover `border-top` on the filter bar) and no orphaned divider where the title row was.

### 2 — Chamber-split readout on the filter bar

The filter bar's left-edge readout currently reads `MEMBERS {n} of the 119th` (whatever the live string is). Replace its content with a live chamber split. Same left position, same row. The controls on the right (ALL/HOUSE/SENATE, ALL PARTIES, ALL STATES, VOLUME/PASS RATE, INCLUDE CEREMONIAL, search) stay exactly where they are, untouched.

Format, by chamber-toggle state:
- CHAMBER=ALL → `{house} HOUSE · {senate} SENATE`
- CHAMBER=HOUSE → `{house} HOUSE`
- CHAMBER=SENATE → `{senate} SENATE`

The `·` separator appears only at CHAMBER=ALL.

**Computed live from the active member-pane result set, never hardcoded.** Same source that produces the current count. PARTIES / STATES / search narrow it. And because this is the merged page: **committee scope narrows it too** — with a committee scoped (`?committee=`), the readout reflects that roster's chamber split, not the full chamber. The readout always describes what the member list is currently showing.

No noun, no congress number (both live in the breadcrumb already), so "Members" drops out of the readout. Reuse the existing readout's type hierarchy — numbers in its emphasis color, chamber labels muted — no new tokens. Mono, tabular numerals on the counts.

## Confirm before building — data check (brief open Q1)

The current readout says `536 of the 119th`, but 435 House + 100 Senate = 535. `536` is the deduped distinct-member count (HO 199 landed there after merging split sponsors on `bioguide_id`). Grep the source feeding it, bucket those members by chamber, and report the real house/senate split plus what the 536th is — non-voting delegate, a member with a null/other chamber value, a vacancy artifact. The readout renders whatever the live query returns; this check is so the displayed split is honest. If one member falls outside both buckets (so the two numbers sum to 535, not 536, with one unclassified), report it — don't silently drop the member or pad a bucket.

## Constraints

- **HO 328 merge untouched.** Committee rail, `MemberTopicBar`, `CommitteeRailRow`, scoped rosters, cross-filter, expanded member card, `/committees`→`/members` redirect: no edits.
- **Masthead untouched.** Breadcrumb title row, LAST SYNC subhead (HO 325), nav row: no edits. The mockup's masthead is context only.
- **Controls untouched.** Chamber segmented control, party/state dropdowns, VOLUME/PASS RATE, INCLUDE CEREMONIAL, search, columns, sort, pagination: all as shipped.
- Static. No new color tokens. Mono. Tabular numerals on the counts.

## Docs / backlog

Don't run a doc sweep — single consolidation, sweep with the next batch. But:
- Removing the secondary title may orphan CSS classes or a page/component prop (the count plumbing). Flag orphans for `docs/backlog.md` cleanup (the HO 323/326 pattern); don't fold them into this commit.
- If `docs/backlog.md` OPEN LOOPS tracks a members-header item, reconcile it.

## Ship

- `tsc` clean → `npm run build` clean.
- Named `git add` by pathspec, never `-A`. Re-check HEAD before push.
- `git push`, then `npm run verify:deploy` until served SHA === HEAD.
- Stale `.next` serves a stale CSS hash → 404 on the stylesheet → unstyled page. `tsc` + 200 + payload don't prove a styled render. If the dev server's been up a while, `rm -rf .next` + restart, and confirm the stylesheet loads before eyeballing.
- Live-verify on `/members`:
  - standalone `MEMBERS` title row gone; filter bar one row higher under a single clean border;
  - readout reads `{h} HOUSE · {s} SENATE`; toggling CHAMBER collapses it to the single active chamber; party / state / search / committee-scope all move the counts;
  - committee rail and member list render and cross-filter exactly as HO 328 shipped — no regression left of the member pane.
- Report: the data-check finding (real house/senate split + what the 536th is); and confirm the live page matched the mockup's starting assumptions (title row + readout present) or, if not, what you found and how you adapted.
