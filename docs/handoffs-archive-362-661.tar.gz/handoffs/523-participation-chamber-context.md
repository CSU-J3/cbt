# HO 523 — Participation cut 1 (B1): chamber context on the member hub

First build of the member-scorecard arc's participation half (the HO 522 verdict: B1 GO, ship first). **Scoped tight by what already exists** — see below. Code build: diff shown before commit; no doc edits, no SKILL, one code commit.

## What already exists (don't rebuild it)

The 119th per-member missed-vote rate is **already computed and surfaced**. `getMemberVoteStats(bioguideId)` (`lib/queries.ts` ~6769) returns `{ total, notVoting }` (total = `member_votes` rows for the member; notVoting = `SUM(position='not_voting')`), and the member hub hero (`app/members/[bioguideId]/page.tsx` ~636–651) already renders **"Votes cast N of M"** + **"Missed X%"** (`missedPct = round(notVoting/total*100)`). Code's probe sample (Bennet 9.3%, Blackburn 5.2%, Baldwin 0.1%) *is* this existing stat.

So B1's delta is **not** the rate — it's **contextualizing** it: a bare "Missed 9.3%" is a stat; "Missed 9.3% · Senate median 4.1%" is a scorecard metric. That context (chamber distribution) is the all-member piece the probe flagged. That's this HO.

**Do not touch the existing "Scorecard" tab** (~541) — that's the USCPR (Senate-Dems-only, conditional) external scorecard, a different thing. Participation is universal and belongs in the hero stat block.

## §1 — Query layer (cached, no new table)

Add a cached helper (e.g. `getChamberParticipationContext()`) that returns, **per chamber**, enough of the missed-rate distribution to derive a member's standing + the **chamber median**:

- Metric defined **identically to the hero** — `not_voting / total_rows` per member (reuse the `getMemberVoteStats` definition; do not diverge, or the context won't match the number next to it).
- **Per chamber only** (House ranked against House, Senate against Senate; a member's `member_votes` rows are already chamber-scoped).
- **Exclude members with no vote rows** (total = 0 → no denominator) from the distribution.
- **Small-denominator floor (decided — shapes the query, not the copy):** the missed-% denominator scopes to tenure, so a mid-cycle entrant (e.g. the just-added SC appointee, ~tens of votes) reads a noisy rate off almost no signal and would distort a chamber rank/median. Compute the distribution — **both the median and the rank** — over members with **≥ F eligible votes**, default **F = 50**. The same `total >= F` predicate does double duty: it scopes the reference population **and** gates rank-eligibility (§2), so no separate render check is needed. A member's **own rate is unaffected** — it still uses their real denominator (their number on the hero doesn't change); the floor only governs who *counts toward*, and *receives*, a chamber rank/median. Confirm F against the actual per-member eligible-votes distribution (you're already computing it) — it should cleanly separate the newest-entrant tail from the full-tenure body; report the chosen F + how many members (and who) it floors out. If 50 leaves noise or clips a legitimately-seated member, adjust and say so.
- Use **`unstable_cache`** matching `getMemberVoteStats`'s existing pattern/cadence — the distribution is ~553 rows (one grouped aggregate over `member_votes`), so a **cached all-member query beats both** a request-time all-member rank on every page load **and** standing up a rollup table for the 119th cut. **No new table, no cron.**
- **Note for B2:** the career cut (Voteview, ~500MB) *will* need a precomputed table/blob (the LDA-rollup precedent) — B1 deliberately stays on a cached query; the rollup arrives at B2, not here.

Sanity-EXPLAIN it warm against prod once (the grouped aggregate over `member_votes` should ride an index, not a fat SCAN) — if it wants an `INDEXED BY` per the standing OR-lure/plan discipline, add it.

## §2 — Surface (member hub hero)

Next to the existing "Missed X%" stat (~636–651, guarded on `voteStats.total > 0` — keep that guard), add the chamber context, using the existing **`mhp-stat` component + design tokens** (JetBrains Mono, the `mhp-stat-l`/`mhp-stat-v` layout):

- **Primary reference: chamber median** — unambiguous and light (e.g. `Missed 9.3% · Sen median 4.1%`).
- **Optional rank/percentile**, rendered **only for members in the floored population** (`total ≥ F`, §1) — sub-floor members show **rate + chamber median but no rank** (the floor already excludes them, so this needs no extra guard). Frame any rank **unambiguously**: lower missed = better attendance (so it must read "fewest-missed = best", e.g. `#78 of {floored chamber size} for attendance`, not a bare percentile that invites "of what?"). Median-only is an acceptable ship if rank crowds the layout.
- **Label it 119th-Congress** clearly, so B2's career figure won't collide with it later.
- Optionally thread the same context into the Voting-record tab's stats component (`stats={voteStats}`, ~404) if it lands cleanly — not required.

Match the member-hub design system; read `/mnt/skills/public/frontend-design/SKILL.md` before adding any new styled element.

## Guardrails + deliverable

- **Diff shown before commit** (user-facing page + query layer). Explicit pathspec staging; ancestry eyeball; fast-forward only.
- **No doc edits, no SKILL.** The doc sweep + the Member-depth bar accounting is a **separate follow-on** — fold it with B2 into one participation-sub-arc sweep (or sweep after B1 if preferred). B1 alone is the first cut, not the full 99→100 close (that's the whole arc: context + career + the scorecard question).
- **One code commit.** Report back the computed context for a couple of members (e.g. the probe's Bennet / Blackburn / Baldwin) so the median/rank sanity-checks against their known rates.

read docs/handoffs/523-participation-chamber-context.md and follow it
