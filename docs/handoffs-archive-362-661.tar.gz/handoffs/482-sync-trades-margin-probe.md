# HO 482 — /api/sync margin probe (sync-tail + trades)

**Type:** read-only diagnostic. Measure → classify → recommend. **Do not fix anything.**
**Precedent:** HO 405/407/479-class margin probe. HEAD `7a66f43` (HO 481). Roadmap runs through HO 481; this is 482.

## Why this exists

HO 480/481 collapsed the `/api/sync` lead step from a ~14s cold-DB-stall to ~1–3s (`INDEXED BY` off the OR-lure). Post-deploy verification (`5bf9354`) confirmed three clean successes — tick `id` **#3446, #3499, #3558** — with `payload.timings.lead` at 957–2,249ms.

**The banked observation:** #3446 still landed at **50.0s** total elapsed, ~10s over the roadmap's own post-fix wall math — `sync(~30, budget-pinned) + lead(~1–3) + trades(2.4–7.5) ≈ 33–40s`. Lead is exonerated (it's ~1s now). So the ~10s excess lives in a **sync tail past the 30s budget**, in **trades**, or in **unaccounted overhead**. This probe names which, and answers the only question that made it worth banking: **is 50.0s a one-off, or a structural margin that breaches the 55s soft cap as corpus/disclosure volume climbs?**

## Two settled premises — do not re-litigate

- **FMP does not hang.** HO 480 found the `-latest` endpoint 402s past page 0, so `maxPagesPerChamber:3` is effectively page-0-only per chamber; the GETs never stalled. Trades' 2.4–7.5s is ~200 sequential `INSERT OR IGNORE` round-trips (Turso latency × rows), not network. **The FMP `AbortController` is NOT a live cause** — this probe *confirms the 402 finding still holds*, it does not re-raise the hang hypothesis.
- **`payload.trades` is not persisted.** `app/api/sync/route.ts` only `console.log`s the trades counters (`pagesFetched`/`inserted`/`matched`); `payload` carries `{ timings, sync, reportCatchup }` and no `trades` key. So trades-time-vs-rows is **not** readable from `cron_runs` — Part B estimates it instead.

## The route (HEAD 7a66f43, already instrumented — no instrumentation pass)

`app/api/sync/route.ts`, four steps, each wall-timed into `cron_runs.payload.timings.{reportCatchup,sync,lead,trades}`:

1. **reportCatchup** — runs first. No-op day ≈ tens of ms; gap day = full 15–29s weekly-report gen (`payload.reportCatchup.generated != null`).
2. **sync** — `runSync({ deadlineMs: routeStart + SYNC_BUDGET_MS })`, `SYNC_BUDGET_MS = 30_000`. Stops *starting* new bills at 30s, but an in-flight bill fetch tails past it. Counters persisted at `payload.sync`: `seen`/`upserted`/`skipped`/`failed`/`timedOut`/`budgetStopped`.
3. **lead** — `generateDashboardLead` → `writeDashboardLead`, non-fatal. Now hinted (HO 480/481).
4. **trades** — `ingestTrades({ maxPagesPerChamber: 3 })`, best-effort, non-fatal. Counters **console-only** (not in payload).

Soft cap `DEFAULT_SOFT_TIMEOUT_MS = 55_000` (5s under `maxDuration = 60`). `cron_runs` columns: `id`, `route`, `started_at`, `status`, `elapsed_ms`, `payload` (TEXT JSON).

---

## Part A — prod telemetry (this is the primary answer)

Pull the last **40** `cron_runs` rows for `route = '/api/sync'` (`0 */6` cadence → ~28/week; 40 gives margin), `JSON.parse(payload)` each.

**Isolate the post-fix cohort:** rows with `id >= 3446` **≡** `timings.lead < 5000` (pre-fix lead was 14–20s; the two filters should name the same set — if they disagree, report it). All distributions below are over the **post-fix cohort only**; do the pre/post split explicitly.

Compute and print:

1. **Lead regression guard.** `timings.lead` min/p50/p90/max across *all* post-fix rows — not just the 3 hand-verified. If any post-fix tick shows lead climbing back toward the stall band, the hint isn't holding on some plan → **finding** (higher priority than the margin question).
2. **Post-fix step distribution.** min / p50 / p90 / max for `timings.sync`, `timings.trades`, `elapsed_ms`, and the **residual** `elapsed_ms − (reportCatchup + sync + lead + trades)`.
3. **Sync-tail check (the core margin question).** Count post-fix rows where `timings.sync > 30_000`; tabulate the overshoot (`timings.sync − 30_000`, min/max/p90) and cross-tab against `payload.sync.budgetStopped`. A `budgetStopped = true` row with `sync > 30_000` is the in-flight-bill tail eating the lead+trades headroom. Correlate the overshoot against `payload.sync.seen` / `.upserted` — does a bigger delta drive a longer tail?
4. **Trades wall spread.** `timings.trades` distribution again, flag any post-fix tick **> 10s** (insert-count scaling or an FMP behavior change). Wall-time only — no per-tick insert count in payload.
5. **Residual audit.** If the residual (2) is large and positive, cost lives outside the four timed steps (the four `revalidateTag` calls, `wrapCronRoute` finalize, the timeout race). Flag it — it changes the fix.
6. **#3446 decomposition.** Print the full per-step breakdown + residual for **#3446, #3499, #3558** side by side. Name exactly where #3446's 50.0s came from vs the 33–40s prediction: sync-tail, trades, or residual. This is the anchor the bank was written on.

---

## Part B — isolate the two live suspects (confirm cause)

Part A says *which* bucket. Part B says *why*, and confirms the settled FMP finding still holds. **Read-only. Do NOT run `ingestTrades` (it writes). Do NOT call `writeDashboardLead`.**

- **Sync tail** — already answered by Part A (the `payload.sync` counters are persisted). No isolation run; just interpret §3.
- **Trades fetch half (confirms the 402 finding).** Cold-time the FMP GETs only — `fetchSenateTrades({ page })` / `fetchHouseTrades({ page })` (or the internal fetch they wrap) for pages **0, 1, 2**, no insert loop (these don't write). Report per-page latency and status. **Expected:** page 0 returns rows; pages 1–2 return 402 / empty (the `maxPagesPerChamber:3` no-op HO 480 found). **If pages 1–2 now return data, that's a finding** — FMP changed and trades will scale with page count. Put a **20s soft ceiling** on each fetch; if one trips it, that itself is a finding (fetch stall).
- **Trades insert cost (estimate — don't run the loop).** Gauge per-tick insert volume from `stock_trades`: if the table has an ingest/created timestamp, group counts by day; else use `transaction_date` / disclosure-date as a daily-volume proxy. Then benchmark a **single** `INSERT OR IGNORE` round-trip against `stock_trades` (a throwaway row that collides → ignored, or wrap-and-rollback) and multiply by the typical daily insert count. This confirms whether trades-time is insert-bound (Turso round-trips), as the roadmap claims, and gives the forward projection for Part C.

---

## Part C — the margin verdict (the "if volumes climb" answer)

Compute `margin = 55_000 − p90(elapsed_ms)` over the post-fix cohort. Then classify and recommend:

- **`margin > ~12s`** → #3446's 50.0s was a one-off (a fat-delta sync tail on one tick). **Recommend: watch, no fix.** Bank a concrete re-probe trigger — e.g. re-run if any single tick breaches **48s**, or if `stock_trades` daily insert volume doubles from the current baseline. State the baseline you measured.
- **`margin < ~8s`** → structural risk that will breach the cap as volume climbs. Recommend, in preference order (this probe does **not** build any of them):
  1. **Split trades to its own cron slot.** `ingestTrades` is fully independent of sync (own data, own `member-trades` tag) — a dedicated `/api/cron/trades` removes trades' whole 2.4–7.5s+ from the sync wall. Cleanest decouple; the roadmap already floats "split-trades."
  2. **Batch the trades inserts.** Collapse the ~200 sequential `INSERT OR IGNORE` round-trips into one multi-row `INSERT` (or a single transaction) — kills most of the trades time regardless of slot. The win if Part B confirms trades is insert-bound.
  3. **Tighten the sync tail.** Bound the in-flight bill fetch so it can't tail ~10s past the 30s `budgetStopped`. The win if §3 shows sync routinely running 35–40s.
- **`8s ≤ margin ≤ 12s`** → call it: name the dominant contributor from Part A and recommend the matching single fix from the list, framed as "do it before the next volume bump," not "urgent."

**Close criterion:** the report names where the current margin lives (sync-tail / trades / residual), states the measured p90 elapsed and the margin, confirms the FMP-402 finding still holds (or flags that it changed), and lands a fix-or-watch call with a specific numeric trigger. No build follows this HO.

## Deliverable + discipline

- One read-only diagnostic script, `scripts/diagnostic/sync-trades-margin-482.ts`. Prints the Part A tables, Part B timings, and the Part C verdict. Writes nothing to prod (the insert-cost benchmark rolls back or collides-then-ignores; note which).
- Report findings back before any commit. If the script is committed: explicit pathspec stage of just that file, diff shown and approved first, ancestry checked immediately before push (one commit riding, clean fast-forward), no force, concurrent-session files untouched. Diagnostic-only commit — no docs sweep in the same commit.
