# HO 479 — `/api/sync` trailing-step timeout probe

**Type:** read-only probe → GO/NO-GO on the fix direction. No build, no route change, no schema change. Exactly one file staged: the diagnostic. Everything else stays untouched.

This is the *probe-before-fixing* step the OPEN LOOP demands. Diagnose which step overruns and why; the fix is a separate HO scoped off your numbers.

---

## The loop (backlog, 2026-07-17, surfaced by HO 477)

`/api/sync` hit the 55s soft cap on ~6 of its last 7 ticks. Bills commit fine (`revalidateTag("bills")` fires, corpus ~1h fresh every tick), but a trailing step runs past the cap, so `wrapCronRoute` finalizes the row `timeout` and the last clean `success` is ~37h back. `/api/health` correctly reads it **alive** (a `timeout` row proves the cron fired and executed — HO 139 soft-resume), so this is **not** a freshness failure. It's the HO 405–406 (summarize) / HO 407 (weekly-report) *step-overruns-the-wall* class, 4th/5th appearance.

**Close criterion (for the later fix HO, not this one):** the route finalizes `success` within the soft cap — the trailing step budgeted, or split to its own cron slot — OR it's ruled acceptable-degraded and documented.

**Do not fix anything here.** Measure, classify, recommend.

---

## The route — already instrumented, so no instrumentation pass is needed

`app/api/sync/route.ts` runs four steps in order, each wall-clock-timed into `cron_runs.payload.timings`:

1. **reportCatchup** (`runReportCatchup`) — runs FIRST (HO 285 deviation). No-op day = one indexed PK lookup (~tens of ms); gap day = the full 15–29s weekly-report gen. `payload.reportCatchup.generated` is non-null only on a gap day.
2. **sync** (`runSync`) — deadline-gated at `routeStart + SYNC_BUDGET_MS` (`SYNC_BUDGET_MS = 30_000`). Stops *starting* new bills at 30s from route start, but an in-flight bill fetch can tail past it.
3. **lead** (`generateDashboardLead` → `writeDashboardLead`) — one Gemini 2.5 Flash `generateContent` call (SUMMARY_MODEL), non-fatal.
4. **trades** (`ingestTrades({ maxPagesPerChamber: 3 })`) — up to 3 FMP disclosure-page GETs per chamber (senate + house = ≤6 fetches) + per-row inserts, with a page-all-seen → break short-circuit. **The FMP fetches carry no AbortController** — a slow/stuck endpoint hangs unbounded.

**Budget math:** soft cap `DEFAULT_SOFT_TIMEOUT_MS = 55_000` (5s under the 60s `maxDuration`). The route comment claims ~25s headroom for lead + trades after the 30s sync budget. On a no-op-catchup day the wall is roughly `catchup(~0) + sync(≤30) + lead + trades ≤ 55`. The overrun means `lead + trades` (± a sync tail) is blowing that ~25s.

The route's own comment on the `timings` object: *"so a future 'step X is overrunning its share of the budget' investigation has data without an instrumentation pass first."* That's this. The telemetry exists — read it.

---

## Part A — read prod telemetry (this is the primary answer)

Pull the last **40** `cron_runs` rows for `route = '/api/sync'` (a week+ at the HO 433 `0 */6` cadence ≈ 28 rows; 40 gives margin). For each: `started_at`, `status`, `elapsed_ms`, and `JSON.parse(payload)` → `.timings.{reportCatchup,sync,lead,trades}`, `.sync` (the runSync counters), `.reportCatchup.generated`.

Compute and print:

- **Per-step distribution** (min / p50 / p90 / max) across all rows for each of the four timings, plus `elapsed_ms`.
- **Timeout correlation** — for the `status = 'timeout'` rows specifically, which single step was largest each time, and its value. This names the overrunning step directly from prod. Tabulate: `timeout N of M rows; largest step = trades in K, lead in L, sync in J`.
- **Gap-day discriminator** — of the timeout rows, how many had `reportCatchup.generated != null` (a real report gen ran) vs `null` (no-op). If most timeouts are `null`, reportCatchup is exonerated and the cause is downstream. If timeouts cluster on `generated != null`, catchup is squeezing the budget on gap days.
- **Sync-tail check** — how often `timings.sync` exceeds `SYNC_BUDGET_MS` (30s), and by how much. Tells you whether the 30s budget itself is being violated by an in-flight bill tail (sync eating the lead+trades headroom) vs. sync finishing clean and the overrun living purely in lead+trades.
- **Unaccounted time** — `elapsed_ms − (reportCatchup + sync + lead + trades)` per row. If this is large and positive, there's cost outside the four timed steps (the four `revalidateTag` calls, `wrapCronRoute` overhead, the timeout race). Flag it; it changes the fix.

---

## Part B — cold-time the suspects in isolation (confirm the cause)

Part A says *which* step. Part B says *why*, and distinguishes a **cold-DB-stall** (the HO 405/407 `boundedFetch` double-timeout signature — a query mis-planning into a full scan) from a **genuinely slow external call** (Gemini latency, FMP page count, an FMP hang). Different causes, different fixes.

Run each from cold (first call after idle), wall-clock each, **read-only — do not run `ingestTrades` and do not call `writeDashboardLead`; neither writes here**:

- **lead:** time `gatherLeadData()` (its DB reads) and `generateDashboardLead()` (reads + the Gemini call, no write) separately. Splits the lead cost into DB vs Gemini. If `gatherLeadData` alone is slow → it's the query-plan class (cold-stall), same as 405/407. If the Gemini call dominates → it's latency, not a plan.
- **trades:** time `fetchHouseTrades({ page })` and `fetchSenateTrades({ page })` for pages 0, 1, 2 — the FMP GETs only, no insert loop. Reports the per-page fetch latency and whether any page stalls (the no-AbortController hang). This is the network cost the cron pays; the insert loop is cheap by comparison but note if the corpus suggests otherwise.

Keep a wall-clock ceiling on each Part B call (e.g. a 20s soft guard) so a genuine FMP hang doesn't wedge the probe itself — and if one trips it, **that's a finding** (unbounded fetch confirmed).

---

## Hypothesis to test (don't assume it — the loop's own precedent is HO 420/422: a logged claim is a claim)

Likely **latency-dominated, not volume-dominated.** The HO 433 cadence flip (`0 9` daily → `0 */6`, 4×/day) makes each tick *lighter* on accumulated deltas (6h vs 24h), and `maxPagesPerChamber: 3` + the all-seen short-circuit caps trades work per tick — so a *volume* explanation predicts the overrun should have eased, not appeared. That points at per-call latency: the Gemini lead call and/or the unbounded FMP fetches. Part B settles it. If Part A instead shows `timings.sync` routinely > 30s, the story is a sync tail and the hypothesis is wrong — report what the data says.

---

## The decision to return (GO/NO-GO on the fix direction)

Close with a one-paragraph recommendation picking one of the three close-criterion paths, backed by the numbers:

- **(a) Budget the trailing step in place** — e.g. wrap the FMP fetches in an AbortController, or tighten `SYNC_BUDGET_MS` / `maxPagesPerChamber`, keeping the four steps on one tick. Cheapest if the overrun is a bounded, occasional tail.
- **(b) Split the step to its own cron slot** — the HO 115 (summarize) / HO 117 (news) precedent. Trades especially has no reason to co-tick with the bill sync; a `/api/cron/trades` on its own schedule removes it from the sync wall entirely. Strongest if trades is the consistent culprit and its FMP cost is inherently variable.
- **(c) Accept-degraded + document** — if the `timeout` is cosmetic (bills always commit before the trailing step runs, lead/trades are both non-fatal and self-heal next tick, `/api/health` already reads it alive), the honest move may be to raise or annotate the watchdog's expectation and log the route as intentionally soft-timing. No code.

State which, and why, in one paragraph. That paragraph is what scopes the next HO.

---

## Deliverable

`scripts/diagnostic/sync-trailing-cost-479.ts` — read-only, sibling to `scripts/diagnostic/markets-cadence-474.ts` / `lda-bill-cost-439.ts` / `amendments-actions-probe-452.ts`. Prints the Part A tables, the Part B isolation timings, and the classification. Uses the existing Turso client + the same env the other diagnostics read.

## Guardrails

- **Read-only.** No `INSERT`/`UPDATE`/`DELETE`, no `writeDashboardLead`, no `ingestTrades`, no migrate, no route/`vercel.json`/schema touch. Reads `cron_runs`, times the fetch/gen paths, prints.
- **One file staged.** `git add scripts/diagnostic/sync-trailing-cost-479.ts` by explicit pathspec — a concurrent session may hold uncommitted files that must not be staged.
- **No auto-commit.** Show me the diff and the probe's console output; wait for explicit approval before committing. Check ancestry immediately before any push (one commit riding, clean fast-forward, concurrent session's files untouched).
- **Report the numbers, then stop.** No fix in this HO.

---

read docs/handoffs/479-sync-trailing-step-probe.md and follow it
