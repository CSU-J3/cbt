# HO 642 continuation — two probes

**Ground truth:** `origin/main` at `3de13e6`, six HO 642 commits landed. Roadmap's latest pointer still reads **641** — the doc sweep hasn't run, so 642 has no block yet. **These stay HO 642**: both close questions 642 itself opened (§8's verdict, and the fallout of §5's S-MI eyeball). Do not take 643 off a commit message; the next number is established by the sweep that writes 642's block.

Both are **read-only**. No product code, no CSS, no render change. Each is its own commit.

---

## P1 — Is the empty roster one seat or a class?

`race_candidates` for `S-MI-2026` is empty, and the card renders `no challenger filed` — a positive claim — while Kalshi, Polymarket and the PAC line all name candidates. Before anything is fixed, measure how many rated seats are in that state. **A one-seat staleness and a sixty-seat class have different fixes, and the fix cannot be chosen from an exhibit.**

Write `scripts/diagnostic/roster-coverage-642.ts`. Predicate every count (`WHERE … IS NOT NULL`) — a bare `COUNT(*)` is answered from B-tree interior pages and under-reports by 227–416× (HO 624 M0).

**M1 — coverage across the rated set.** For every seat in `getRacesIndex(2026)`, report the count of `race_candidates` rows, bucketed: 0 rows · 1 row · 2+ rows. Give the totals and the full id list for the 0-row bucket.

**M2 — which of those are derivable.** For each 0-row seat, does a matching `primary_candidates` row with `status='winner'` exist (the shape `backfill:race-challengers` harvests from)? Split the 0-row bucket into **derivable** (a winner exists and the harvest simply hasn't reached it) and **underivable** (no winner recorded — the ME shape from HO 638, where the harvest is inert). Report both counts and both id lists.

**M3 — the detector's live exhibit count.** For each 0-row seat, does the card have a *contradicting* element — a Kalshi favourite, a Polymarket favourite, or a PAC IE direction row that names a person? Count the seats where at least one names someone while the roster names nobody. **This is the population the HO 639 queued detector would fire on**, and it is the number that decides whether that detector is worth building.

**M4 — the conflation, sized.** Across the whole rated set, how many seats reach `challenger.kind === "empty"` with a **non-empty** `race_candidates` (a real "no challenger filed") versus an **empty** one (an unknown rendered as a finding)? These are the two states the render currently cannot tell apart, and M4 is how many of each the product actually has.

**M5 — freshness.** Newest `race_candidates.updated_at` (or equivalent) across the table, and the newest `primary_candidates` row for a completed 2026 primary. If the gap is large, say so plainly — the inference that `backfill:race-challengers` hasn't run since 2026-08-04 is currently untested, and a timestamp either supports it or kills it.

**Report the numbers and stop.** Do not run `backfill:race-challengers`, do not touch `ChallengerShape`, do not edit `RaceCard`. The likely shape of the fix — splitting `kind: "empty"` into *roster present, no challengers* and *roster absent, unknown*, which the caller can distinguish on `hubs[i].candidates.length` — is recorded here so it isn't rediscovered, **not authorised**. It gets a number after the sweep.

**Also check PA-10.** It is the other seat commit B newly featured and nobody has looked at it. One line: what does its challenger row render, and how many `race_candidates` rows back it.

---

## P2 — Sweep the at-risk lower bound

`[5,30)` returned median 4 / p90 7 / **max 9** against a pre-fixed ceiling of 6. The ceiling stands; 5 was chosen to make a snapshot legible and was never measured. Find the boundary that satisfies the constraint, or establish that none does.

Extend the occupancy replay. **Zero new queries** — the control's position matrix is already in memory and this is another loop over it. Same 60-cursor windows, and **pool on the date axis, not the cursor index** (your correction; house cursor 0 is 2026-07-23 and senate cursor 0 is 2026-08-08, and summing by index adds two different moments).

For **W ∈ [6, 20]**, report per chamber and pooled: median, p90 and max occupancy of `[W, 30)`, plus the count of distinct members who enter the band at any cursor in the window.

**The upper bound of the sweep is a product constraint, not a convenience.** The band must span at least 10 roll calls, or a member promotes to MIA within a couple of sessions of appearing and the tier warns nobody about anything. W > 20 is a tier that cannot function, so it is not searched.

**The MIA bar stays at 30 and is not swept.** The S=30 review is a separate open loop gated on the House returning from recess, and the House's newest roll in this window is 20 days old — that gate is still shut. Moving both boundaries in one pass would make neither attributable.

### Selection rule, fixed now

- Choose the **smallest** W in [6,20] where **max occupancy ≤ 6** AND **median ≥ 1**. Smallest, because the most inclusive band that respects the ceiling gives the most warning.
- If some W clears the ceiling but none of those also clears median ≥ 1, that is **CONDITIONAL — rare**: report the W and its numbers, and stop. Whether a band that usually renders nothing earns its slot is an owner call.
- If **no** W in [6,20] clears the ceiling, the tier is **DECLINED** on measurement: it cannot be both a warning and an alarm. Report the numbers, and do not extend the range to rescue it.

Report the whole table regardless of which rung fires — the verdict is one row of it, and the shape of the curve is what a later reader needs.

### Two things to fix in the probe's own output

1. The pooling axis (above), applied to the sweep as well as the existing series.
2. The verdict string. A canned line printed *"sits empty at the median"* under a median of 4 — a summary that does not read its own numbers, which is the same-as-success shape in the reporting layer. Derive the verdict text from the values or drop the prose and print the table.

Both of these, plus the cursor-index-as-timestamp pooling error, are **oddities entries owed to the doc sweep**. Note them in the commit message so the sweep inherits them rather than rediscovering them.

---

## Commits

| # | Commit |
|---|---|
| 1 | `probe(HO 642): rated-seat roster coverage and the empty-roster render class` |
| 2 | `probe(HO 642): at-risk lower-bound sweep, W in [6,20]` |

Explicit pathspec staging, `npm run typecheck` before each push, ancestry eyeball, fast-forward only. Probes never ride with builds and never with each other.
