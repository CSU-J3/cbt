# HO 500 — `/news` route extraction: scoping probe REPORT

Read-only survey. No files under `app/`, `components/`, `lib/` were touched. This report is the deliverable; the build HO follows from it.

## TL;DR

The split is an **arrow inversion**, exactly as the brief predicted. `NewsView` (`app/bills/page.tsx:468-600`, ~133 lines) is self-contained and moves cleanly. **No shared component needs a signature change** — every news-side link site either hard-codes `/bills?...` internally (flip the literal) or receives `basePath`/`carry` as a prop (change the prop value, not the component). The one real *decision* is the cross-carry contract (Step 2); my recommendation is **(a) drop it**, matching the brief's prior. Sizing points to **one commit** (extraction + link-flips together), with an optional second commit only if you decide the mode toggle should physically relocate.

---

## Step 1 — the complete inbound-link set

Every construction of a news-mode URL, verified against the codebase. "Flip" = must point at `/news` post-split; "Stay" = bills-mode-only, untouched.

| # | file:line | what it constructs | verdict |
|---|-----------|--------------------|---------|
| 1 | `components/MediaAttentionCell.tsx:28` | `` `/bills?mode=news&bill=${id}` `` — the ⚡ press chip on every bill row | **FLIP** → `` `/news?bill=${id}` `` |
| 2 | `app/news/page.tsx:21-22` | redirect target `/bills?mode=news[&bill=]` | **INVERT** — this file *becomes* the news page; the redirect goes away (see Step 4) |
| 3 | `components/BreakingNewsBlock.tsx:62` | `<Link href="/news">` — home "view all news" expander | **STAYS `/news`** — already correct; it's the one link that survives the inversion untouched |
| 4 | `app/bills/page.tsx:90` | `buildModeHref` sets `mode=news` — the LEGISLATION/NEWS toggle | **BECOMES NAV** — toggle turns into a `/news` ⇄ `/bills` link pair (Step 5) |
| 5 | `app/bills/page.tsx:501` | `newsCarry.set("mode","news")` — pager carry in NewsView | **MOVES** into `app/news/page.tsx`; `mode` marker drops (route identity replaces it) |
| 6 | `app/bills/page.tsx:517` | `filterCarry.set("mode","news")` — NewsFilters chip carry | **MOVES** into `app/news/page.tsx`; `mode` marker drops |
| 7 | `app/bills/page.tsx:535` | `<HeaderBar basePath="/bills" mode="news" />` | **MOVES**; `basePath` → `/news`, drop `mode="news"` (see Step 3 breadcrumb note) |
| 8 | `app/bills/page.tsx:538` | `<GroupTabs group="feed" active="news" />` | **MOVES**; `active="news"` handling — see Step 5 |
| 9 | `app/bills/page.tsx:558,593` | `<Pagination basePath="/bills" carry={newsCarry} />` (×2) | **MOVES**; `basePath` → `/news` |
| 10 | `components/NewsFilters.tsx:70` | `buildHref` returns `` `/bills?${qs}` `` (hard-coded) | **FLIP** → `/news` — see Step 3 (this is the one component with a *baked-in* base path, not a prop) |

### Programmatic `mode=news` writers (all in `app/bills/page.tsx`)
- `sanitizeMode` (`:63-65`), the `FeedMode` type (`:40`), `SearchParams.mode` (`:43`), the `if (mode === "news")` branch (`:107`), and `buildModeHref`'s `mode` handling (`:86,90`) — all **removed or gutted** once news is its own route. See Step 4 for whether `mode` stays as a legacy alias.

### Docs / non-code references (don't break the build; become stale)
- `docs/backlog.md:63` — the **"Split `/news` to its own route"** backlog item itself. Its close criterion ("`/news` is its own route") is met by this build → mark CLOSED.
- `docs/backlog.md:197,199,214` — audit notes describing `/news 307→/bills?mode=news (intentional)`. Now wrong; update to "`/bills?mode=news → /news`".
- `e2e/fit-finish.spec.ts:614` — test title *"/news loads clean (redirects to /bills?mode=news)"* and `e2e/smoke.spec.ts:59` (`{ slug: "news", path: "/news" }`). The smoke assertion still passes (it just fetches `/news`); the fit-finish **title** becomes a lie (no redirect anymore). Retitle, and consider asserting `/news` renders the feed directly rather than 200-after-redirect.
- `lib/queries.ts` comments at `:3915, :3918, :4223, :4264` and `scripts/diagnostic/cold-start-audit-332.ts:265,269` — reference `/news?bill=` / `/bills?mode=news` as the data-layer's consumer. Comment-only; correct opportunistically.
- `next.config.ts:7` — the `/feed → /bills` redirect comment mentions `mode=news` as an example; harmless, leave.

**Verdict on the brief's "known starting set":** all five claims verified accurate. The brief missed only #3 (`BreakingNewsBlock`, the one link that's *already* `/news`) and #10's key property (NewsFilters bakes the base path in a string rather than taking it as a prop — noted in Step 3).

---

## Step 2 — the param-carry contract → **recommend (a): drop the cross-carry**

**What exists today.** Because it's one page, both modes deliberately round-trip each other's params (`app/bills/page.tsx:80-93` toggle; `:200-211` bills→news carry; `:507-511` + `:518-521` news→bills carry). NewsView threads eight BILLS params it never reads — `topics, stage, q, sponsor, sort, chamber, ceremonial, cluster` — purely so a toggle back to BILLS restores that view.

**Recommendation: (a) drop it entirely.** `/news` carries only `source, topic, window, bill, signal, page`; `/bills` carries only its own set. Reasoning:

1. **The cross-carry is an artifact of shared-page mechanics, not a feature anyone asked for.** It exists because a `?mode=` toggle can't *not* carry the URL's other params without extra code. Separate routes are the moment that constraint disappears — keeping it means writing *new* code to preserve an accident.
2. **A route advertising eight params it never reads is precisely the confusion the split is meant to end** (the backlog item's own rationale: "`.mc-fbar` keeps absorbing more... harder to reason about").
3. **The realistic loss is small.** The path that matters — the ⚡ chip (`MediaAttentionCell`) → news-for-this-bill → click the bill → `/bill/[id]` — never round-trips through bills filters. And the toggle-to-compare-then-toggle-back workflow is served by the browser Back button, which restores the prior URL's params for free.
4. **Option (b) doesn't remove complexity, it relocates it** — every nav-link site would need the full opposite-route param set, re-import­ing the exact coupling we're trying to sever. Option (c) (preserve `q` only) is defensible but `q` is a *bill-text* search with no news analog; carrying it into `/news` where nothing reads it reintroduces the dead-param smell for marginal benefit.

**Open question flagged, not resolved:** if you have telemetry showing users actually toggle bills⇄news mid-filter-session (I can't see analytics from here), that's the one fact that would argue for (c). Absent it, (a).

---

## Step 3 — shared-component blast radius → **zero signature changes**

Per-component, the question that matters (does the *component* change, or only its props?):

| component | used by | takes basePath/carry? | extraction requires… |
|-----------|---------|----------------------|----------------------|
| **`Pagination`** | both views + many other pages | `basePath` prop (default `/`), `carry` prop | **prop only** — pass `basePath="/news"`. Component untouched. |
| **`NewsFilters`** | **news-only** | ❌ no basePath prop — `buildHref` **hard-codes** `` `/bills?${qs}` `` at `:70` | **one-line change to the component**, but it's news-only so there's no other consumer to regress. Either flip the literal to `/news` or (cleaner) add a `basePath` prop. **This is the only component that must be edited**, and it's safe precisely because it has a single caller. |
| **`HeaderBar`** | every inner page | `basePath` prop; `mode?: "bills"\|"news"` prop feeds the breadcrumb | **prop only** — `basePath="/news"`. The `mode` prop becomes redundant: `breadcrumbSegments("/news")` would need to yield `["News"]`. **See breadcrumb note below** — this is the one spot that needs a lib touch beyond props. |
| **`GroupTabs`** | every group page | `group` + `active` props | **prop only** (and see Step 5 — `active="news"` currently matches no tab, so it's already a no-op). `pathToNavKey` needs a `/news → "feed"` line so the top-nav still lights (see below). |
| **`NewsRow`** | NewsView **+ `SearchResultsNews` + `RaceNewsRow`** | no route props — links to `/bill/[id]` only | **untouched.** Its 3 consumers are unaffected by the route move; it constructs no `mode=news` link. |
| **`SegmentedToggle`** (the toggle) | bills page + chamber filter | `buildHref` prop | see Step 5 — the *mode* usage becomes a nav link; the *chamber* usage is unrelated and stays. |

**Two small `lib` touches that are NOT signature changes but must happen (flag for the build):**
- `lib/breadcrumb.ts:29` — currently `if (basePath === "/bills") return [mode === "news" ? "News" : "Legislation"]`. Add `if (basePath === "/news") return ["News"]` and the `/bills` line reverts to plain `["Legislation"]` (the `mode` param can then be dropped from the signature, or left inert).
- `components/GroupTabs.tsx:110` (`pathToNavKey`) — add `if (basePath === "/news") return "feed"` so `/news` lights the Legislation top-nav item, mirroring the existing `/bills → "feed"` line.

**HO 486 regression check (the reason this step exists):** the danger case — "changing a shared component for one consumer's benefit" — **does not occur here.** The only component that gets *edited* (NewsFilters) is single-consumer. Everything genuinely shared (Pagination, HeaderBar, GroupTabs, NewsRow) changes at the *prop* layer or not at all. No every-consumer audit is triggered. The build is prop-flips + one single-consumer component edit + two additive `lib` lines.

---

## Step 4 — the redirect inversion

**Post-split target state:** `app/news/page.tsx` *renders the feed* (no longer redirects). `/bills?mode=news` should **redirect to `/news`, carrying `?bill=` (and any other news params) through.**

- **Why redirect rather than 404/ignore:** live bookmarks and any cached `/bills?mode=news` URLs (the chip pointed there for HO 130→499) must keep landing on news. Cheapest: in `app/bills/page.tsx`, before the BillsView render, `if (sanitizeMode(params.mode) === "news") redirect(buildNewsUrl(params))` — preserving `bill/source/topic/window/signal/page`. This keeps `mode` as a **legacy alias** (recommended over stripping) so no bookmark 404s.
- **`mode` param disposition:** keep `sanitizeMode` alive *only* as the redirect trigger in `/bills`; remove it from the render path, the `FeedMode` type's news branch, the toggle, and `SearchParams` documentation-of-intent. Don't strip it entirely — the alias is one cheap `if` and buys bookmark safety.
- **Redirect-loop risk during partial deploy:** **real but bounded.** Sequence matters. If `/news` starts redirecting to `/bills?mode=news` (old code) while `/bills?mode=news` starts redirecting to `/news` (new code), a request ping-pongs. **Mitigation:** ship as a single atomic deploy (Next redeploys the whole route tree together — the two files flip in the same build, so there's no window where old-`/news` and new-`/bills` coexist). The only residual risk is a **client with a cached RSC payload** of old `/news`; a hard nav resolves it. Flag: do not split the `/news` render and the `/bills` redirect across two separate deploys.

---

## Step 5 — what the mode toggle becomes

Today `SegmentedToggle` + `buildModeHref` (`app/bills/page.tsx:83-105`) is a segmented control flipping `?mode=` in place. Across routes it's **navigation between two URLs** (`/bills` ⇄ `/news`).

- **Where it should live:** keep it in **both page bodies** as-is (a two-segment toggle whose `buildHref` returns the sibling route), rather than hoisting into HeaderBar/GroupTabs. Reason: it's visually a mode switch sitting above the filter bar; moving it into the nav chrome is a design change out of scope for a route extraction. Minimal diff = each page renders `SegmentedToggle` with `buildHref = (v) => v === "news" ? "/news" : "/bills"` (plus whatever carry policy Step 2 lands on — with (a), no carry).
- **Does `GroupTabs`' `active="news"` already do this job?** **No — and that's fine.** `GROUP_TABS.feed` (`:29-33`) is `changes/president/reports`; there is **no `news` tab** in the group (HO 184 deliberately removed Bills+News from that row, ceding mode-switching to the segmented toggle). So `active="news"` currently matches nothing and renders no active tab — it's already inert. Post-split it stays inert (harmless), or you drop the `active` arg. GroupTabs is **not** secretly already switching modes; the segmented toggle is the only switch.

---

## Step 6 — sizing → **one commit**

Rough line accounting in `app/bills/page.tsx` (601 lines today):
- **`NewsView`** (`:468-600`) ≈ **133 lines** move out to `app/news/page.tsx`.
- **Wrapper shrinkage** (`FeedPage` `:67-121`): the `mode` branch, `buildModeHref`, `sanitizeMode`, the news half of `SearchParams`, and the news-carry block in BillsView (`:200-211`) — ≈ **40-50 lines** deleted or reduced to a redirect stub.
- **`app/news/page.tsx`**: 24-line redirect stub → ≈ **150-line** real page (NewsView body + imports + `nowMs`/`searchParams` boilerplate).
- **Call-site flips:** #1 (MediaAttentionCell), #10 (NewsFilters), plus the two `lib` additions (breadcrumb, pathToNavKey). ~4 edits, all one-to-few lines.

**One commit, not two.** The extraction and the link-flips are interdependent (flipping MediaAttentionCell before `/news` renders would break the chip; flipping after leaves a redirect hop) — they must land together to avoid a broken intermediate state, and the total diff is modest (~1 file created, ~2 files shrunk, ~4 call sites). **The only thing that would justify a second commit** is if you decide the mode toggle should physically relocate into HeaderBar/GroupTabs (Step 5 recommends against it) — that's a separable design change. Per Step 3, **no shared-component signature change falls out**, so the "Step 3 turns up a signature change → its own commit" branch in the brief does not fire.

---

## Open questions (reported, not silently resolved)

1. **Toggle-mid-session telemetry** (Step 2): do users actually flip bills⇄news while filtered? If yes → reconsider (c) preserve-`q`. I can't see analytics; recommendation assumes the answer is "rarely."
2. **`mode` alias longevity** (Step 4): keep the `/bills?mode=news → /news` redirect forever, or sunset it after a deprecation window like `/dashboard-classic`? Recommend keep — it's one `if`, and the ⚡ chip's historical hrefs may be bookmarked. A future cleanup HO can retire it.
3. **Deploy atomicity** (Step 4): confirm the build ships `/news` render + `/bills` redirect in a single deploy. Low risk given Next's whole-tree redeploy, but it's the one sequencing gotcha worth stating in the build HO's verification step.
