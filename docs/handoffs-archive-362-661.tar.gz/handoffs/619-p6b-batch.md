# HO 619 — P6b: the batch, the rails go `start`, the chip rule converges, and the residues get their formal names.

HEAD `913bb8b`. Pointer "run through HO 615." **Next free is 619.** This is the arc's last work HO; 620 is the close (final crawl, instrument filings, the sweep). Scope from the refreshed table: `/patterns` 3 · `/electoral` 2 (+ M2 2×52px) · `/vote` 2 · `/welcome` 1 (M3 8.86) · six routes at 1 each — plus the three rulings above, executed here.

## 1. Commit 1 — the rails: `align-items: start`, seams to the container

`/members` (2,618px) and `/bills` (1,807px): the two-pane rail caps at its content. Before the edit, check what paints the seam — if a full-height border or background on the rail box is load-bearing for the two-column read, move that line to the grid container or the gap so it survives the cap. `/welcome`'s 775px live aside gets the same treatment if its decomposition matches; its landing-module CSS is in scope since HO 604. Eyeball all touched routes at 1440/2560 with short-rail states (a filtered `/bills`, a scoped `/members`); **if a capped rail reads broken, HALT with the screenshot** — the ruling anticipated a seam fix, not a redesign.

Score: site M2 5 → ≤2 (the `/electoral` 2×52px may resolve in §3 or stay as named trivia).

`fix(layout): HO 619 — rails size to content; seams move to the container (C7 does not rotate)`

## 2. Commit 2 — the chip-rule audit across BillRow surfaces

Enumerate every surface rendering BillRow topic chips (`/bills`, `/stale`, `/changes`, `/president`, stage feeds, anywhere the grep says) and classify each chip **by function**: click-to-filter or link → bordered chip stays; static label → plain dim text. Two specific checks inside that:

- **§2-of-618's plainified `/stale` chips**: were they links? If yes, the quiet pass removed an affordance — restore the border (the rule outranks the pass).
- **`/changes`' bordered chips**: if they filter, they're already correct and the "divergence" was principled; record it as such rather than converging looks.

The commit converges every surface on the rule; the HALT lists the classification table (surface × function × dress).

`fix(chips): HO 619 — BillRow chip surfaces converge on the chip rule: function decides the border`

## 3. Commit 3 — the batch

`/patterns` 3 · `/electoral` 2 + its two 52px panels · `/welcome`'s quiet pass (M3 8.86 → decomposed target, survivors named — the landing page's one real C3 item) · the six singletons, each decomposed: most are known accepted residues (`/trades`' 196px header, `/lobbying`'s artifact-class 1) and get **formal-acceptance lines**, not work. Kit as law for anything real; a no-op per route is a legitimate disposition when the decomposition says so, stated per route.

`fix(batch): HO 619 — P6b batch: patterns, electoral, welcome quieted; singletons resolved to their decompositions`

## 4. The formal acceptances — the arc's standing residue, named once

The HALT prints the **permanent-residue register** the arc close will carry verbatim: `/members` 11 knee-marginal + 2 header-axis (priced at HO 612, formally accepted here, reopening costs 16 truncations) · `/trades` 1 header-axis (196px) · `/vote` 2 plateau-residual · whatever §3 adds. Each with its px, its class, and its price. This register plus the exemption registry **is** the definition of "the arc is done": site M1 = accepted residue + M1x, nothing unexplained.

## 5. P6b closes by its scope list

Seven-route table (plus the two rail routes touched by §1), permitted dispositions, the refreshed site line (M1 / M1x / M2 / M3 spread / M4 furniture-split). Fixture legs green before any zero; spot-unmoved: `/`, `/stale` 0/6.55, `/changes` 0, `/committee-detail` 0.

## 6. Guards

1. Three commits in order, typecheck + build, explicit pathspecs; narrow buckets on every touched route, (a)/(b)/scroll-cited, bucket (b) not worse anywhere.
2. Any marking: applied curve, both units, registry queue, arithmetic restated (314). None is expected; the batch routes' hits are singletons, not axes.
3. Prod-verify converged. **HALT** with the tables, the chip classification, the residue register. No sweep, no instrument work — 620's.
4. Absence Watch untouched, one HO from the end as at the start. `--fs` tokens 9–14px.
