# HO 485 — LDA filing-expand cost + shape probe

**Type:** read-only diagnostic. No schema, no writes, no surface, no build. Commit the diagnostic script (sibling to `scripts/diagnostic/lda-bill-cost-439.ts`), report the numbers back.

## Why

The `/lobbying` redesign (members-style two-pane) makes each `FilingRow` **expand inline** to show the per-activity LD-2 detail — the `lda_activities.description` free text ("the FULL specific-issues free text" per the migrate.ts comment), which is stored but surfaced nowhere today. The collapsed row only shows registrant→client + first 3 issue codes + resolved bills.

The expand is a **live per-click server read** (URL-param driven, one filing at a time — the `/members` `?expanded=` idiom), not a precompute blob. Before I spec `getFilingActivities(filingUuid)` + the panel, this probe gates two things:

1. **Cost** — is the single-filing activities read fast cold, even for the worst filing? Expected GO (`lda_activities` PK is `(filing_uuid, activity_ordinal)`, so `WHERE filing_uuid = ?` is a PK-prefix seek — the *inverse* of the HO 439 per-bill drill that random-fetched thousands of `lda_filings` rows at 44.5s). But the standing rule holds: **a clean EXPLAIN says nothing about cold latency — instrument it.**
2. **Shape** — max activities/filing, description-length distribution, resolved-bills/filing. This sizes the panel (cap? scroll? how many bill chips?). This is the real output regardless of the GO.

## Build

Create `scripts/diagnostic/lda-filing-expand-cost-485.ts`, mirroring the existing diagnostic scaffolding (same DB client import as `lda-bill-cost-439.ts` / `lda-coverage-435.ts`, `tsx` runnable, read-only). Add a small percentile helper (p50/p90/p99/max over a number[]).

**Cold discipline:** run **Q2 (worst-case single-filing read) as the very first query after connect**, before any aggregate warms the connection — that's the request-path-shaped query, and its cold number is the verdict. The aggregates (Q1/Q4/Q5) are diagnostic-only; their latency is irrelevant.

### Q0 — plan check (confirm PK seek, no scan)
```sql
EXPLAIN QUERY PLAN
SELECT general_issue_code, general_issue_code_display, description, bill_ids
FROM lda_activities WHERE filing_uuid = ? ORDER BY activity_ordinal;
```
Report the plan verbatim. Expect `SEARCH lda_activities USING PRIMARY KEY (filing_uuid=?)`. Any `SCAN` is a red flag.

### Q1 — activities-per-filing distribution + heaviest filings
```sql
SELECT filing_uuid, COUNT(*) c FROM lda_activities GROUP BY filing_uuid ORDER BY c DESC;
```
Pull all group counts → report **p50 / p90 / p99 / max** in JS, plus the **top-5 heaviest** `(filing_uuid, count)`. (This is the omnibus-LD-2 ceiling — a single filing can cover dozens of issue areas.)

### Q2 — worst-case single-filing read (COLD, run first)
Take the heaviest `filing_uuid` from Q1. Time the real read:
```sql
SELECT general_issue_code, general_issue_code_display, description, bill_ids
FROM lda_activities WHERE filing_uuid = ? ORDER BY activity_ordinal;
```
Report **ms (cold) + row count**. Also dump a **sample of the first 3 rows** for that filing: `general_issue_code`, `general_issue_code_display`, `LENGTH(description)`, `substr(description,1,140)`, `bill_ids` — so I can see real content shape for the panel layout.

### Q3 — recent-filing single read (representative of what users actually expand)
```sql
SELECT filing_uuid FROM lda_filings ORDER BY dt_posted DESC LIMIT 3;
```
Time the same Q2 read for each of those 3 recent UUIDs. Report ms + row count per filing.

### Q4 — description-length distribution
```sql
SELECT LENGTH(description) n FROM lda_activities WHERE description IS NOT NULL;
```
Report **p50 / p90 / p99 / max** char length, and the **% of activities where description IS NULL or ''**. (Decides whether the panel needs a clamp/scroll on long narratives and how often the field is empty.)

### Q5 — resolved-bills-per-filing (bounds the panel's bill chips)
```sql
SELECT filing_uuid, COUNT(*) c FROM lda_activity_bills GROUP BY filing_uuid ORDER BY c DESC;
```
Report **p50 / p90 / p99 / max** + top-5, and specifically **how many resolved bills the Q1-heaviest filing carries**. (The panel shows per-activity bills; this caps the chip count.)

## Verdict criteria

- **GO** (live per-click expand viable): worst-case single-filing read (Q2) **< ~1s cold**, comfortably under the 10s `boundedFetch` cap. Given the PK-prefix seek, I expect sub-100ms — but confirm.
- **NO-GO** (unexpected): if Q2 is slow cold, note the plan (Q0) and whether it's the seek or the sort. Fallback would be a first-N-activities clamp, but don't design it — just flag.
- **Regardless of GO**, the shape numbers (Q1 max, Q4 lengths, Q5 bill counts) are what I need — they determine the panel's cap/scroll and chip layout.

## Constraints

- Read-only. No `INSERT`/`UPDATE`/`CREATE`/migration. No changes to `app/`, `lib/`, `components/`.
- Commit **only** the diagnostic script — it's a durable sibling to the other `lda-*` diagnostics, not a throwaway (the 435/439/461/474 precedent: probes are committed).
- No build, no surface — that's the follow-up HO once this verdicts GO.

## Git discipline

- Clone / hard-reset to `origin/main` first (HEAD should be `ded2cf8`); establish ground truth before touching anything.
- Stage the one new file by explicit pathspec (`git add scripts/diagnostic/lda-filing-expand-cost-485.ts`) — never `git add .`.
- Inert diagnostic → **approve on summary** (no diff hunk needed), but show the ancestry eyeball before push: `git log --oneline @{u}..HEAD` = exactly one commit riding, clean fast-forward, no concurrent-session files touched.
- One commit. Fast-forward only, no force-push. Commit message style: `chore(diag): probe lda filing-expand cost + shape (HO 485)`.

## Report back

Paste: Q0 plan, Q2 cold ms + the 3-row sample, Q3 per-filing ms, and the Q1/Q4/Q5 percentile blocks. That's the GO/NO-GO + the panel-sizing inputs. I'll write the build handoff from it.

---

read docs/handoffs/485-lda-filing-expand-cost-probe.md and follow it
