# HO 536 — doc sweep for HO 535 (participation sort on /members)

Records the participation *sort* — the ranked-list twin of the HO 527 dotplot — and banks the SQLite ORDER-BY-scoping gotcha the probe caught. **No theme-% change** — an enabling surface on `/members`; the combined bar and Member depth are untouched (the HO 425/527 dotplot precedent). **No bar edits anywhere.** Two commits:

- **Commit A (normal):** `docs/roadmap.md` + `docs/backlog.md` + `docs/oddities.md`. Diff shown, approved, FF push.
- **Commit B (SKILL, review-ref route):** `.claude/skills/cbt/SKILL.md` alone → `git push origin HEAD:refs/heads/536-review` → I read the diff off the ref and approve → FF main → delete the ref. Do **not** paste the SKILL diff (relay swallows it — HO 508).

---

## §1 — `docs/roadmap.md` (Commit A)

Insert **after the "Also (HO 532–533)" block, before the "Owed eyeball:" line**; the block's trailing pointer bumps the running pointer to 535 (add the block, don't retro-edit prior blocks — append-only, HO 418).

```
**Also (HO 535), the participation *sort* on the /members roster — the ranked-list twin of the 527 dotplot, no theme-% change.** The banked participation sort/rank (the constraint the HO 523/525 carve-out was written for) — the "who misses the most votes" ranked list, complementing the HO 527 dotplot's distribution. Shipped `b565c13`. Adds a **MISSED** segment beside VOLUME / PASS RATE that orders the roster by each member's **119th missed-vote rate** (`SUM(not_voting)/COUNT(*)` over `member_votes`, `HAVING COUNT(*) >= PARTICIPATION_FLOOR=50` — the identical dotplot/B1 metric). **No new column — the shared `.mc-row` grid stays untouched:** `.mc-row` backs both `/members` AND `/lobbying`'s `FilingRow` (the filing rows fell back to the members grid), so widening it would reshape the lobbying rows; instead the existing **RATE column repurposes** to the missed-rate when the missed sort is active (amber vs passrate's green, `—` for null, the header swaps RATE→MISSED), leaving `.mc-row`/`.mc-r-num`/`/lobbying` byte-identical. **The delegate carve-out adapts HO 527 to a roster:** the dotplot *drops* the 6 non-voting delegates; a list can't drop members, so they're carved from the **ranking** (rate exposed NULL via the territorial predicate `chamber='house' AND state IN ('DC','AS','GU','MP','PR','VI')` → sort last + `—`, disclosed "non-voting delegates unranked") but kept in the list — same population-correctness principle, different mechanism. Threaded into **both** `getMembersRanked` (full list) and `getCommitteeRoster` (scoped view) via a shared `participationAggCte` + a shared `MISSED_CARVE_EXPR`, both gaining a **`votes` cache tag** (they read `member_votes` now, else they'd only refresh on the 86400s backstop — the `getChamberParticipationContext` precedent). **One spec bug the probe caught (oddities):** the handoff ordered by the bare `missed_pct` column, but SQLite resolves an unqualified column *inside an ORDER BY expression* against the input tables (`part_agg`'s raw rate), NOT the carved SELECT alias — so delegates (Radewagen 82%, Plaskett 50%) sorted to the top while displaying `—`; fixed by repeating the carve in the ORDER BY via the shared `MISSED_CARVE_EXPR`, re-probe confirmed. **No probe HO** (the missed-rate is the dotplot's own cheap ~536-row aggregate), but the build's throwaway probe verified the ranking: **TOP by MISSED = Wilson 29.0% → Hunt 24.6% → Kean 22.8%** (all voting members, matching the HO 527 dotplot tail), **BOTTOM = the 6 delegates + below-floor Graham showing `—`**. **No theme-% change — an enabling surface on `/members`; Member depth holds at 100** (the HO 425/527 dotplot precedent). **Banked:** a **career missed-rate sort** (its NULL-coverage set differs — the reason the dotplot's career toggle is banked) and the **career chamber-median context** on the hub (still the deliberate 4-stat-hero hold). Docs: HO 536. **Also notes now run through HO 535.**
```

## §2 — `docs/backlog.md` (Commit A)

**(a)** Replace the BANKED constraint item at line ~153 (opens `- **BANKED constraint — participation *rank* surfaces need a delegate-eligibility carve-out (HO 523/525; dotplot half SHIPPED HO 527).**`) — the sort/rank half has now shipped:

```
- **BANKED constraint — participation *rank* surfaces need a delegate-eligibility carve-out (HO 523/525; dotplot SHIPPED HO 527, sort SHIPPED HO 535).** Both the **`/members` dotplot (HO 527, `7fa729c`)** and the **MISSED sort (HO 535, `b565c13`)** ship WITH the carve-out — the territorial predicate `chamber='house' AND state IN ('DC','AS','GU','MP','PR','VI')` (dotplot drops delegates from cloud+median; the sort exposes their rate NULL so they sort last + display `—`, disclosed). The carve-out is **population-correctness, not outlier-trimming** — the real high-miss tail is a *voting* member (Wilson 29%), not the delegates (oddities). See roadmap "Also (HO 527)" / "Also (HO 535)" + DONE tombstones. **Still banked from the arc:** a **career missed-rate sort** (NULL-coverage set differs — the dotplot-career-toggle reason) and a **career chamber-median context** on the hub (deliberately unbuilt to avoid a 4-stat hero). *Gate:* Corey's appetite for the career cuts. *Owner:* Corey.
```

**(b)** Append to the **DONE** section (append-only tombstones):

```
- ~~**Participation MISSED sort on the /members roster (HO 535)**~~ — **SHIPPED `b565c13`**, live-verified. The ranked-list twin of the HO 527 dotplot ("who misses the most votes"). A **MISSED** `SegmentedToggle` segment beside VOLUME / PASS RATE orders the roster by the 119th missed-rate (`SUM(not_voting)/COUNT(*)`, `HAVING >= PARTICIPATION_FLOOR`, the dotplot/B1 metric), threaded into `getMembersRanked` + `getCommitteeRoster` via a shared `participationAggCte` + `MISSED_CARVE_EXPR` (both +`votes` tag). **No new `.mc-row` column** (shared with `/lobbying` FilingRow) — the RATE column repurposes to the missed-rate under the missed sort (amber, `—` for null, header RATE→MISSED). **Delegate carve adapted to a roster:** carved from the ranking (rate NULL → sort last + `—`, disclosed) but kept in the list. The ORDER-BY-carve gotcha (unqualified column in an ORDER BY expression resolves against input tables, not the SELECT alias) caught by the probe → fixed via the shared `MISSED_CARVE_EXPR` (oddities). Probe: Wilson 29% #1 (voting members, matching the dotplot tail), delegates + below-floor Graham `—` at the bottom. **No theme-% change** — enabling surface, Member depth holds at 100. See roadmap "Also (HO 535)". Docs: HO 536.
```

## §3 — `docs/oddities.md` (Commit A)

Append a new `## …` entry (tail-of-file):

```
## An unqualified column inside an ORDER BY *expression* resolves against input tables, not SELECT aliases (HO 535, Jul 2026)

The `/members` MISSED sort (HO 535) carves delegates by exposing their missed-rate as NULL in the SELECT — `CASE WHEN <delegate predicate> THEN NULL ELSE pa.missed_pct END AS missed_pct` — so their rows display `—`. The handoff then ordered by `CASE WHEN ? = 'missed' THEN missed_pct END DESC`, expecting that carved (NULL-for-delegates) value. It didn't get it: SQLite lets an ORDER BY reference a bare SELECT alias **only when the alias stands alone as the entire ORDER BY term**; the moment the name appears *inside an expression* (here, inside the CASE), it resolves against the FROM/JOIN tables instead — picking up `part_agg`'s raw, un-carved rate. So Radewagen (82%) and Plaskett (50%) sorted to the **top** of "most missed" while their rows still displayed `—` (the SELECT carve worked; the ORDER-BY carve silently didn't). Fix: repeat the carve expression in the ORDER BY — a shared `MISSED_CARVE_EXPR` constant used in **both** the SELECT and the ORDER BY, so they can't diverge. General rule: a SELECT alias is NOT visible to an *expression* in ORDER BY / WHERE / GROUP BY — only as a standalone ORDER BY term; any computed ordering that must match a computed column has to repeat the expression (or wrap the query and order the outer). The probe caught it (delegates-on-top before commit) — the diagnose-before-fixing discipline; same "verify the mechanism, not just that it compiles" class as the HO 533 cache-hit lesson, on the SQL-scoping axis.
```

---

## §4 — `.claude/skills/cbt/SKILL.md` (Commit B — review-ref route, SKILL alone)

Two edits, both in the `/members` area. Build locally, push to `536-review`, wait for approval, FF main + delete ref.

**Edit 1** — in the `/members` route description (line ~1438), replace the sort-toggle clause `VOLUME/PASS RATE \`SegmentedToggle\` (\`?sort=volume|passrate\`, \`getMembersRanked\` ORDER BY swap)` with:

```
VOLUME/PASS RATE/**MISSED** `SegmentedToggle` (`?sort=volume|passrate|missed`, `getMembersRanked` ORDER BY swap; **MISSED** = HO 535, the 119th missed-vote-rate sort — the ranked twin of the HO 527 dotplot). The MISSED sort adds a shared `participationAggCte` (`SUM(not_voting)/COUNT(*)`, `HAVING >= PARTICIPATION_FLOOR`) + a shared `MISSED_CARVE_EXPR` to **both** `getMembersRanked` and `getCommitteeRoster` (both +`votes` tag), carving delegates via the territorial predicate — rate NULL → they sort last + display `—`, disclosed "non-voting delegates unranked". **No new `.mc-row` column** (shared with `/lobbying` FilingRow — don't widen it): the RATE column **repurposes** to the missed-rate under the missed sort (amber vs passrate green, `—` for null, header RATE→MISSED). `MISSED_CARVE_EXPR` is used in BOTH the SELECT and the ORDER BY — an unqualified column inside an ORDER BY *expression* resolves against input tables not the SELECT alias, so the carve must be repeated there or delegates rank to the top while showing `—` (oddities)
```

**Edit 2** — in the participation-rank-constraint bullet (line ~1290), replace the sentence `**Still binds any future participation SORT/rank / Voting-tab rank** — same carve-out required.` with:

```
The **`/members` MISSED sort (HO 535) is the second surface bound by this** and applies the same carve in `getMembersRanked` + `getCommitteeRoster` (delegate rate → NULL, sorts last + `—`, via the shared `MISSED_CARVE_EXPR` repeated in SELECT and ORDER BY — oddities). **Still binds any future participation rank** (a career sort, a Voting-tab rank) — same carve-out required.
```

---

## Guardrails + deliverable

- **Commit A first** (roadmap + backlog + oddities): explicit pathspec, diff shown + approved, ancestry eyeball (`git log --oneline @{u}..HEAD` — one commit riding, clean FF, concurrent-session files untouched), FF push.
- **Commit B (SKILL alone) via the review-ref route:** local commit → `git push origin HEAD:refs/heads/536-review` → I read the diff off the ref and approve → FF main → `git push origin :536-review`. SKILL never lands on main without an approved diff.
- No `git add .` — pathspec only. Two commits total, neither riding with code. **No bar edits anywhere** (enabling surface → the combined bar and Member depth hold).

read docs/handoffs/536-doc-sweep-535.md and follow it
