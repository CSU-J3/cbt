# HO 627 — the dead space: the feed fills its column, distributions stop hiding, and 624–627 close.

HEAD `e9d2aad`. Pointer "run through HO 623" — blocks for 624–626 are owed and ride this HO's close. **Next free is 627.**

The owner's screenshot decomposes into two causes, neither of which is the layout arc misbehaving — both are pre-arc content *limits* surviving into a shell that budgets far more room:

1. **The right column renders 5 rows inside a full-viewport sticky budget.** `.bills` is `max-height: calc(100vh - 32px)` with `.feed { overflow-y: auto }` — shipped at 609 and ready to scroll — but the movers/stalls/new slices are still the old 5-row props, so the column caps at ~370px and the rest of the viewport beside it is empty. The mock fills the column and scrolls.
2. **The distributions panel hides half its designed content.** The committed mock's DISTRIBUTION panel is **BY STAGE + BY TOPIC stacked in one panel**; shipped kept the HO 320 tabs, so TOPIC is behind a click and the panel is half its designed height. Mock wins, the standing precedent.

The left column being short below that is recess plus C4 doing their jobs — empty states collapsed, panels content-sized — and it is **not** to be fixed by resurrecting anything the arc cut. The fix is depth of what's already ranked, not breadth of what was removed.

## 1. Commit 1 — the feed fills its column

Find the slice knob per tab (server fetch limit or client slice — cite where it lives) and raise the rendered depth so the column consumes its budget: **movers ~30, new ~30, stalls all** (there are 5). The column keeps `max-height`; the feed scrolls within it; the `[+N MORE →]` pfoot stays pinned and its N stays honest against the new slice.

Two things this must not disturb, proven not assumed:

- **Expand inside scroll** — the standing product requirement. Re-run the 609 §2 reproduction: expand a row from the *last visible position* of a scrolled feed at 1440 and 2560; the panel opens fully, the title popover still escapes (it's viewport-fixed).
- **Cost** — state what the deeper slice reads. If the tabs fetch server-side, a 5→30 limit changes a query's rows; put the number in the HALT (the ledger discipline applies even to 25 extra feed rows).

`feat(dashboard): HO 627 — the feed renders to its column budget (30/30/all); scroll + expand re-proven`

## 2. Commit 2 — breaking 5 → 10

Same shape, one line: the 72h window holds 40; render 10. The `[+N MORE →]` count follows.

`feat(dashboard): HO 627 — breaking depth 5→10`

## 3. Commit 3 — distributions to the mock: stage + topic, co-visible

Retire the STAGE/TOPIC tabs; the panel renders **BY STAGE** (the funnel, `data-viz-row` and its M1x count unchanged) above **BY TOPIC** (the ranked topic list), per the mock's stacked layout with its `16,861 BILLS` header line pattern. **Click-to-filter survives on both halves identically** — HO 56/320's behavior, now reachable without a tab switch; the active-filter interplay (a clicked topic rebasing the funnel) keeps working exactly as it does today, verified by clicking through one topic and one stage in the eyeball.

If the co-visible panel makes the twoup pair (BREAKING beside DISTRIBUTION) height-lopsided, that's `align-items: start` doing its job — C7, not a defect; do not re-balance by padding.

`feat(dashboard): HO 627 — distributions un-tab to the mock's stacked panel; filter clicks preserved`

## 4. Verification

1. Typecheck + build per commit; fixture legs before any zero.
2. `--route home` at 2560 before/after: **M1 holds 0**, M1x may move if the topic list's rows read as an axis — decompose rather than mark anything new; **M4f will rise with row count and that's furniture arithmetic, labeled, not a defect**; M4-true holds.
3. Eyeball 1440 and 2560: the right column now runs the viewport with internal scroll; breaking at 10; both distribution halves visible with filters clicking through; the page's bottom edge sits near the fold at 2560 instead of half a screen up. At 1440 the taller feed must scroll, not push the page.
4. Prod-verify converged. Screenshots at both widths in the HALT — this HO's acceptance is the owner's eyes.

## 5. The close — `refs/heads/627-review`

One docs commit: the roadmap block for **624–627**, pointer → 627 — the ghost probe and its ruling (the ledger-dating rule, 595's true credit ~68%), the 625 filing, the 626 one-liner with the equivalence check and the currencies discipline holding, and 627's density pass with the mock's distribution panel as the authority. Backlog: nothing new opens; the density items were never filed and close in the block. HALT on the ref with the block; land on approval; gates: "HO 623" ×1, "HO 627" ×1.

## 6. Guards

1. Nothing cut in the arc returns — no polarization band, no week grid, no masthead counts, no date groups. Depth, not resurrection.
2. The absence band, hearings interior, wstrip: untouched.
3. `--fs` tokens 9–14px; no new `data-viz-row` without a curve; explicit pathspecs; code and docs never mixed.
