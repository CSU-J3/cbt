# HO 511 — doc sweep for the RecordTabs arc (HO 509–510)

Docs only. No code, no CSS, no component changes.

Ground truth: hard-reset to `origin/main`, HEAD **`d22fe66`**. Shipped in this arc: HO 509 (`8538660`, member hub + the shared box) and HO 510 (`d22fe66`, `/bill/[id]` migration).

**Two commits, in this order.** They cannot ride together — the SKILL self-mod guard requires its own diff-and-approve cycle.

---

## Commit 1 — `docs/roadmap.md` + `docs/backlog.md` + `docs/oddities.md`

### `docs/roadmap.md`

**Append-only.** Add one new dated block after the HO 507 block (~L342) and bump the running pointer to **510**. Do **not** retro-edit the 507 block — it describes `.bdp-pair`, the 340px `.bdp-amend-scroll` bound and "the arc that opened at HO 328 is complete," all of which this arc supersedes. That's what the changelog is for; the HO 418 precedent is the standing rule.

The new block, `**Also (HO 509–510), the shared record box — two detail pages onto one tabbed shell, no theme-% change.**`, should carry:

- **The problem, stated once for both pages.** The member hub was the last detail surface still in the pre-328 idiom — four unboxed strips above the first section (`MemberHeader` / `MemberStats` / `MemberAffiliations` / `MemberFundraisingLine`), the DW-NOMINATE axis buried *inside* the Voting-record section three sections down, and six full-width sections stacking to ~3,400px with two of them empty states on a typical House member. `/bill/[id]` had the same stack four sections deep.
- **HO 509 (`8538660`) — the component + the member hub.** New `components/RecordTabs.tsx`, a `"use client"` island on the `ActivityTabs` (HO 132/249) contract: holds **only** tab state, takes pre-rendered `ReactNode`s as props, so the server page keeps every fetch. All panels mount with `hidden` (unmounting would drop an open `BillRowList` row on every swap); `tabs.length === 0` → `null`. The hero became one bordered card in three bands — identity + a five-figure inline stat run (band 1), `MemberIdeology` **promoted out of Voting record** as the page's spine (band 2), and the metabox **unrolled sideways** into a `data-cells` N-up that collapses to 2-up/1-up when a cell is absent (band 3). Six sections → one box: Bills · Votes · Committees · Amendments · Press · Trades, plus a conditional **Scorecard** tab (Senate Democrats only — genuinely inapplicable, not merely zero). **Two components deleted**, both grep-confirmed single-consumer: `MemberAffiliations` (it printed the same badges `MemberHeader`'s meta line already carried) and `MemberStats` (absorbed into the band-1 run).
- **The 509 follow-up, three fixes before the push.** `.rec-body` went from a fixed `430px` to `min-height: 260px; max-height: 430px` — **HO 244's no-jump rationale doesn't transfer**, because 244 protected content *below* its panel while the record box is the last element before the footer, so the only thing a swap moves is the footer; bounded shift beat pervasive dead space on the majority of tabs. Out-links regressed to plain `<a>` and were put back on `next/link` for internal hrefs (external keeps `target="_blank"`). And the **election readout was printing twice** — `MemberHeader`'s chip plus band 3's cell — so it consolidated into band 3 (which also **fixed a live bug**: band 3 checked only `nextElectionYear != null` and rendered a stale "Next election 2024" where `MemberHeader` had correctly branched to "Former member"). `MemberHeader` lost its election-chip block, its `rating` prop and its **local `ratingColor()`** — the one carrying a "keep in sync with `RatingChip`" warning, so the duplicate map is discharged; the page imports the shared `lib/race-colors` one.
- **HO 510 (`d22fe66`) — the second consumer.** `/bill/[id]`'s four sections became the same box: Committees · Hearings · Amendments · Lobbying, **fixed legislative-process order** (referral → hearings → floor amendments → outside money, the order the sections already sat in). One additive prop, **`initialKey`**, opens the heaviest tab without the strip ever reordering — so `119-s-4784` opens on Amendments (872) and a one-referral bill opens on Committees. **The hero was not touched**: HO 507's containment rule held, no `.bxp-*` line moved, feed expand panel byte-identical. **Retired:** the page-local `SectionShell`, `.bdp-pair` (+ its `> section` rule and ≤900px query), `.bdp-amend-scroll` and `.bdp-out` — ~40 lines of `.bdp` CSS, three weeks after HO 507 landed it. The HO 507 stat lines that had been folded into section headers moved down one level into `.rec-note` sticky strips.
- **The two empty-state policies are opposite and both correct** — the arc's most transferable decision. Member tabs render at zero and dim (`TRADES (0)` is a fact about a person); bill tabs are **omitted** at zero, so a bill with none of the four gets **no box at all**, preserving HO 507's section-omission behavior exactly. See oddities.
- **`key={entity}` on both call sites** — `key={bill.id}` and `key={member.bioguideId}`, added as insurance, not a demonstrated bug. See oddities.
- **No theme-% change** — chrome restructure on existing surfaces, the HO 486 / 492–493 / 495–496 / 507 precedent. Note that this **extends** the HO 328 vocabulary arc the 507 block called complete rather than contradicting it: the browse surfaces converged on `.mc-*`, and the two detail pages have now converged on a second shared shell.
- Close with `Docs: HO 511.` and `**Also notes now run through HO 510.**`

### `docs/backlog.md`

- **Close the moot QUEUED item at ~L183** — "`.bdp-pair` narrow-viewport stack with BOTH sections populated (HO 507)." The selector is deleted; the owed eyeball can never be paid. Strike it with a one-line note that the box supersedes side-by-side pairing, and confirm the parenthetical it carries (the standing **hearings LIVE state** owed-eyeball) survives untouched on the roadmap where it lives.
- **Add a DONE tombstone for the arc** in the same shape as the HO 507 one at ~L231: the shared box, both consumers, the four retired selectors, the two deleted member components, the `MemberHeader` chip/`ratingColor` removal, and the two empty-state policies. Point at the new roadmap block.
- **Check whether any QUEUED item assumed the old member-hub layout** and reword if so — particularly the HO 393 "Member-hub IE overlay" thread (~L43), which describes an overlay on a page that no longer has the sections it names. Report what you find rather than guessing at intent.
- **One new QUEUED item:** the member hub's Press tab has **no out-link** — `/news` carries `source`/`topic`/`window`/`bill`/`signal` only (HO 501), so there's no `?member=` to link to. A `member` param on `/news` would light it. Small, real, unbuilt.

### `docs/oddities.md`

Two new entries, appended in the file's existing `## Heading (HO N, Mon YYYY)` style:

1. **`## Empty-state policy is a property of the data's cardinality, not of the component (HO 509–510, Jul 2026)`** — the same `RecordTabs` shell makes opposite calls on its two consumers and both are right. A member always *is* something, so `TRADES (0)` dimmed is information about that person; but most of the 15k-bill corpus has no committees, no hearings, no amendments and no lobbying, so rendering four dimmed tabs would be noise on the majority of the corpus. The rule to carry: decide show-vs-omit from **how often the zero case fires across the corpus**, not from a single surface's aesthetics — and let the component stay dumb about it (membership is the page's contract; `RecordTabs` only knows `tabs.length === 0 → null`).

2. **`## A client island's lazy useState initializer doesn't re-run on a same-instance route reconcile — key it to the entity (HO 510, Jul 2026)`** — `RecordTabs` resolves `initialKey` in a lazy `useState` initializer, which runs on **mount only**. If the App Router ever reconciles `/bill/a` → `/bill/b` as the same component instance rather than remounting, the tab index carries across and `initialKey` is silently ignored on arrival; the `active < tabs.length` backstop prevents a crash but yields an arbitrary opening tab. Fixed with `key={bill.id}` / `key={member.bioguideId}`. **State it honestly: this was never observed firing** — no bill→bill or member→member client nav is reachable from inside either page today, so it's cheap insurance against a future link, not a diagnosed bug. The generalizable form: any per-entity client island whose initial state derives from props needs an entity `key`, or that derivation is mount-only.

**Commit 1:** `docs: roadmap/backlog/oddities for the RecordTabs arc (HO 511)`

---

## Commit 2 — `.claude/skills/cbt/SKILL.md` (self-mod guarded)

**The guard applies: commit locally, push to `refs/heads/ho-511-skill-review`, and wait for explicit approval of the actual diff before this lands on main.** Default to the review ref rather than pasting — SKILL edits are exactly the ones where the text has to be read, not summarized (the HO 508 relay swallow).

Three entries need work:

- **`/members/[bioguideId]` (~L1418)** — the most stale thing in the file. It still describes the stat block, the affiliations row, "Top 10 sponsored bills," a Voting-record section, a Committees section "between Sponsored Bills and Voting Record," and the trades block "below the voting section" — the entire section stack this arc replaced. Rewrite it around the three-band hero and the seven-tab box. **Keep** everything still true: the `PalestineBadge` grade tiers and their tooltip-only attribution, the HO 138→142 hub+list reversal, `getMemberVotes`'s no-chamber-filter behavior, the friendly-not-found branch, and the sync commands.
- **`/bill/[id]` (~L1401)** — replace the `.bdp-pair` / `.bdp-amend-scroll` / `SectionShell` description with the tab set, the fixed process order, `initialKey`, and the omit-when-empty rule including the **no-box** case. **Keep** the hero paragraph verbatim (it's unchanged and load-bearing), the additive-scope rule, `sponsorDisplayName()`, the `getBillById` optional-column note, and the durable committees/lobbying null-safety behaviors.
- **The client-island roster (~L1392)** — `RecordTabs` joins the `"use client"` set; `MemberStats` and `MemberAffiliations` leave it. The entry quotes a component count (`~53`) and an exact grep number — **re-run the grep and correct both numbers**, don't adjust them by arithmetic.

Add a short **`RecordTabs` contract** note wherever shared-component conventions live (near the HO 486 shared-component layout rule reads right): order and membership are the **page's** contract, never the component's; `initialKey` separates default-open from strip order so a page can open on its heaviest tab without a reshuffling strip; all panels mount with `hidden`; `tabs.length === 0 → null`; and the entity `key` requirement.

Also sweep for incidental staleness the arc created: `grep -n "bdp-pair\|bdp-amend-scroll\|bdp-out\|SectionShell\|MemberStats\|MemberAffiliations" .claude/skills/cbt/SKILL.md` and fix every hit. `getMemberStats` and `getMemberAffiliations` are **queries that survive** — don't strike those from the query registry (~L1254–1255) just because the components of nearly the same name are gone. `getMemberAffiliations` still feeds `MemberHeader`.

**Commit 2:** `docs(skill): member hub + /bill/[id] on the shared record box (HO 511)`

---

## Report back

Commit 1's diff in full. Then the review ref for commit 2, with the corrected client-island counts called out explicitly and the `grep` results for the stale-selector sweep.

---

read docs/handoffs/511-doc-sweep-record-box.md and follow it
