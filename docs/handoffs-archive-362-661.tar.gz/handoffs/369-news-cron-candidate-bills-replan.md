# HO 369 — News cron: replan getCandidateBills (kill the full-table scan)

Confirm the next free number before saving: `ls docs/handoffs/ | sort -V | tail`. Body assumes 369.

## What this is

The news cron (`/api/cron/news`, `0 14 * * *`) has failed 5 straight days. Root cause is pinned (prior diagnostic): `getCandidateBills(30)` mis-plans into a near-full-table scan over the 16,581-row `bills` corpus, blows the 10s bounded-fetch, retries once, and aborts the route at ~20.2s. The other two ingest-path DB calls are healthy. This handoff applies the query fix, verifies the resulting plan, and logs both this and the separate roll_call feed issue into the living docs.

One-line change to the query plus a required plan check. Not a timeout bump — HO 238's 10s bound stands.

## Resolved premises (verified live, 2026-06-26 — don't re-derive)

- **Call site:** `getCandidateBills(30)` at `lib/queries.ts:2937`, invoked once per run at `lib/news-ingest.ts:98`. The arg makes the window `-30 days`, LIMIT 500.
- **Current SQL:**
  ```sql
  SELECT id, title, summary
  FROM bills
  WHERE latest_action_date >= date('now', ?)   -- '-30 days'
    AND summary IS NOT NULL
    AND (is_ceremonial = 0 OR is_ceremonial IS NULL)
  ORDER BY latest_action_date DESC
  LIMIT ?                                        -- 500
  ```
- **Current plan (the bug):** `MULTI-INDEX OR` driving off `idx_bills_is_ceremonial`, plus `USE TEMP B-TREE FOR ORDER BY`. `is_ceremonial = 0` matches ~the whole table (only ceremonial rows are 1), so it reads the full corpus, then filters on date/summary, then temp-sorts. Reproduced as a hard 10s→retry→~20s abort against live Turso from a laptop, matching the cron_runs signature one-for-one.
- **The right index already exists:** `idx_bills_latest_action ON bills(latest_action_date DESC)`. It matches both the range predicate and the ORDER BY. The planner never picks it because the OR clause lures it into the multi-index-OR decomposition.
- **Don't touch the other two ingest calls.** `recordMention`'s existence check is a PK covering lookup (~110ms); the `news_mentions` upsert is ~42ms. Both fine.
- **Timeout is correct.** ~20.2s = 10s `DB_REQUEST_TIMEOUT_MS` + retry-once (HO 238). Do NOT raise it. The fix is to make the query fit.

## Fix

Add an `INDEXED BY idx_bills_latest_action` hint to the `getCandidateBills` query. Leave the predicate semantics unchanged — keep `(is_ceremonial = 0 OR is_ceremonial IS NULL)` as-is. The hint alone defeats the multi-index-OR decomposition and satisfies `ORDER BY latest_action_date DESC` from the index's own DESC order, so the temp b-tree sort disappears and only the ~30-day window is walked. The is_ceremonial / summary clauses become cheap residual filters on the rows visited.

```sql
SELECT id, title, summary
FROM bills INDEXED BY idx_bills_latest_action
WHERE latest_action_date >= date('now', ?)
  AND summary IS NOT NULL
  AND (is_ceremonial = 0 OR is_ceremonial IS NULL)
ORDER BY latest_action_date DESC
LIMIT ?
```

Adapt to the actual builder form at the call site — if it's a template string, the hint goes right after the table name; the column list and params don't change.

## Verify before committing (gate — don't commit a guess)

1. **EXPLAIN QUERY PLAN** the modified query against live Turso. It MUST show:
   - `SEARCH bills USING INDEX idx_bills_latest_action`
   - NO `USE TEMP B-TREE FOR ORDER BY`
   - NO `MULTI-INDEX OR`

   If any of those three fail, stop and report the plan. Don't commit.

2. **Run `npm run sync:news` locally** (same live Turso instance). It must complete with no `[db] timeout, retrying` line, well under the 10s wall, and insert rows. Capture the getCandidateBills elapsed.

## Ship

Named pathspec only (parallel sessions share the tree):

```
git add lib/queries.ts
git commit -m "fix(news): force idx_bills_latest_action on getCandidateBills — kills full-table scan that timed out the cron"
git push
npm run verify:deploy   # poll until served SHA matches HEAD
```

## Docs (separate commit — this is the hiccup write-up)

Insert in place to match the neighbouring entries; don't blind-append.

→ **docs/oddities.md** — add:

> **News-cron error at ~20s elapsed = a stalled Turso call, not the news budget.** `/api/cron/news` has a 45s `NEWS_BUDGET_MS` under a 60s function ceiling, but any single Turso request is bounded by HO 238's `DB_REQUEST_TIMEOUT_MS` (10s) + retry-once, so a stuck DB call aborts the whole route at ~20.2s (2× 10s). A `cron_runs` row with `status=error` and `elapsed ≈ 20,200ms` means a specific query is stalling (mis-plan against a fat table), not the ingest budget or the function timeout. Confirmed 2026-06-26: `getCandidateBills` was driving off `idx_bills_is_ceremonial` (is_ceremonial=0 ≈ whole corpus) instead of `idx_bills_latest_action`; the `(is_ceremonial = 0 OR is_ceremonial IS NULL)` clause triggered a MULTI-INDEX OR. Fix is an `INDEXED BY` hint, not a timeout bump.

→ **docs/backlog.md, OPEN LOOPS** — resolve the timeout loop, keep roll_call, add the soak:

- Move the news-cron-timeout entry to DONE (or strike it), noting: fixed in HO 369 via `INDEXED BY idx_bills_latest_action` on getCandidateBills; query now plans to a covering SEARCH inside 10s.
- **Keep** the roll_call entry OPEN, untouched by this fix.
- **Add:** "Confirm deployed news cron succeeds on its own tick (opened 2026-06-26). HO 369 fixed the query and a local `sync:news` inserted rows, but the deployed cron hasn't fired post-fix. Close when the next `0 14 * * *` run logs `status=ok` in cron_runs and `last_ingest` on news_mentions goes fresh (breaking_now should repopulate). If it still errors at ~20s, the plan fix didn't hold on Vercel egress and we escalate to Turso region/latency."

```
git add docs/oddities.md docs/backlog.md
git commit -m "docs: log news cron timeout root cause + fix, roll_call feed drift, post-fix cron soak"
```

## Out of scope

- **roll_call feed.** Dead since Jun 7 (0 inserts on otherwise-successful runs) — feed-URL drift, separate and parked behind this. Don't chase it here.
- Predicate rewrites beyond the hint. The `IS NOT 1` / `COALESCE` forms floated in the diagnostic are unnecessary once the hint forces the drive order; don't change semantics.

## Ship report

Lead with the post-fix EXPLAIN plan (the three assertions) and the local `sync:news` elapsed + rows inserted. Confirm build clean, verify:deploy SHA matches, both commits landed with named paths. Note the post-fix cron soak stays open until the next 14:00 UTC tick.
