# HO 504 — prod e2e automation + spec hardening (the Phase 2 loop, closed the other way)

Confirm 504 is the next free number before saving. Build handoff; HO 503's probe returned **don't build the fixture**, and that verdict is accepted. This ships what replaces it. The doc sweep is HO 505, not folded here.

## What the probe actually settled

Three commits' worth of work, and the load-bearing finding is not the one the probe was sent to get.

`file:` works through `getDb()` untouched — good, and now moot. The bucket count came back 95% fixture-servable — also moot. **What decides this is the inversion:** the specs are wrapped in `if (await x.count()) … test.skip`, so an under-seeded fixture doesn't fail loudly, it *passes* while exercising nothing. ~22 tests would go green against a corpus that can't support them. A green suite that proves nothing is worse than no suite, and worse than the red-blindness the whole Phase-2 push existed to avoid.

Against a single-committer workflow with diff approval and prod verification on every change, pre-merge protection buys minutes. It does not buy a hundreds-of-row artifact whose dominant failure mode is silent green, maintained forever against a 132-statement schema. Verdict stands.

**But the guard finding doesn't stay contained to the fixture.** Those `test.skip`-on-empty guards are in the specs *today*, running against *prod*. Playwright reports a skip as not-a-failure. So a surface that regresses to zero rows — a cron dies, a blob goes missing, a query starts returning nothing — **skips its test and the run stays green**. The fixture didn't create that hole; the probe just found it while looking somewhere else. That is the durable output of HO 503, and it's a live defect in the harness regardless of which path we took.

So: no fixture, and fix the thing the probe found.

## Commit 1 — `.github/workflows/e2e-prod.yml`

A **new workflow file**, not a job in `ci.yml`. Keeping it separate sidesteps the `paths-ignore` / branch-protection landmine entirely (it's not on the PR path, so it can never be a required check that fails to report).

**Step 0, verify before writing the trigger.** The original loop (HO 379, Jun 30) wanted **post-deploy**, not scheduled — those catch different things. Post-deploy catches "this deploy broke prod." Scheduled catches "prod is broken now," including cron/data rot. We want both if post-deploy is available.

Check whether Vercel emits GitHub `deployment_status` events to this repo — `gh api repos/CSU-J3/cbt/deployments` and look for recent production entries with statuses. **Report what you find before writing the file.** If they're there, the workflow takes both triggers:

```yaml
on:
  deployment_status:
  schedule:
    - cron: '0 15 * * *'
  workflow_dispatch:
```

…with the deployment job gated on `github.event.deployment_status.state == 'success'` and the production environment. If Vercel does **not** emit them, drop to `schedule` + `workflow_dispatch` and say so — don't wire a trigger that never fires and call it post-deploy coverage.

**What runs:** `e2e/smoke.spec.ts` only. `fit-finish.spec.ts` stays manual — it's interaction-heavy, BotID-exposed, and its flake surface would train exactly the red-blindness we're avoiding. Use a grep tag or `--project`, your call, but the selection must be **explicit in the workflow**, not a filename glob that silently picks up whatever lands in `e2e/` next.

**Exclude the markets-hover case** (`smoke.spec.ts:240`). It's bucket D and it fails consistently headless. Worth recording *why*, because the backlog has been carrying the wrong fix for it since June: the loop's hardening #1 is "freeze the marquee animation so the hover lands on a stable item" — but prod withholds the tape from headless Chrome entirely under BotID, so there is nothing to hover and freezing an animation that isn't rendering fixes nothing. **Hardening #1 is moot-under-BotID, not done.** Exclude the test, note the reason.

**Retries.** `playwright.config.ts` sets `retries: 0`, correct for a manual run against a live target you're watching. Wrong for an unattended scheduled run — prod cold-start and transient Vercel will produce red that nobody reads. Set **`retries: 2` for this run only** (CLI flag or a CI-conditional in the config; prefer the flag so the committed config stays honest about the manual default). Real breakage still fails three times; a cold-start blip doesn't page anyone.

Steps: checkout, setup-node 20 with npm cache, `npm ci`, `npx playwright install --with-deps chromium`, run. Upload the HTML report as an artifact on failure. Use `actions/checkout@v4` / `actions/setup-node@v4` to match `ci.yml` — the v5 bump is its own tracked loop, don't do it here and don't let it ride.

Failure surfacing is the workflow's own red X plus GitHub's default scheduled-failure email. **Do not build an issue-opening bot.**

## Commit 2 — spec hardening

Two changes to `e2e/smoke.spec.ts`, code-only, separate commit from the workflow.

**(a) The skip-guard audit — the HO 503 finding.** Go through the `test.skip`-on-empty guards and split them:

- Surfaces where **empty is a real prod regression** — bills, members, committees, the base route crawl. A zero here means something broke. Convert the guard to a **hard assertion**: assert the precondition, don't skip on it.
- Surfaces where **empty is legitimate data variability** — races with news, a member with zero amendments, a bill with zero lobbying. Keep the guard; a skip is honest there.

Don't sweep all 73. **Enumerate which guards you're converting and why, and show me that list before editing.** The line between "regression" and "variability" is a judgment call per surface and I want to see it made explicitly, not applied by pattern-match.

**(b) Hardening #3, carried since Jun 30.** The bill-presence check asserts on element type, and the `<li role=button>` v2 feed rows have broken an `<a href>` selector assumption twice. Re-point it at row text or a `data-` attribute. Locate the actual assertion first — the backlog describes it from memory and that description is a claim, not a fact.

Hardening #2 (console-error allowlist) already exists in `fit-finish.spec.ts:40-44`. Check whether `smoke.spec.ts` has an equivalent; if it doesn't and the crawl asserts console-clean, it needs one or the `MissingSecret` noise will red every run.

## What is NOT in scope

- **No fixture.** No seed script, no committed `.db`, no `migrate.ts` changes.
- **No `lib/db.ts` touch.** The probe proved it isn't needed; that stays true.
- **No `ci.yml` edits.** Phase 1 stands alone and stays untouched.
- **No branch protection.** Still not wired, still deliberate.
- Code and docs never ride together; three commits max here, docs are HO 505.

## Report back

Step-0 `deployment_status` finding and the trigger set you landed on · the workflow file diff · the guard-split list **before** you edit it · the bill-presence assertion's actual current shape and its replacement · confirmation `fit-finish.spec.ts` and `ci.yml` are untouched.

Show diffs as raw fenced text in your reply body. Approval before each commit, pathspec staging, ancestry eyeball before push.

---

Two things for the HO 505 sweep, so they don't drift — **don't act on them here:**

1. The loop closes by **explicit tombstone, not by meeting its criterion.** The backlog's close line reads "the e2e job runs green in CI with a real DB and the interaction hardenings in place." We are not doing that. The tombstone has to say plainly that the criterion was replaced and why (the false-green mechanism), or a future session reads it as satisfied and wonders where the fixture went.
2. The probe's one open question — whether every (A) route 200s on a migrated-but-empty DB, or 500s on a `rows[0]` access — is **moot under this verdict** and should be recorded as such rather than left dangling as a thing the build was supposed to measure.
