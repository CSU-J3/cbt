# HO 437 — LDA lobbying surface (issue-code-first)

**Type:** Feature build (query layer + UI). Additive. Builds on the HO 434–435 data
layer (`lda_filings` / `lda_activities` / `lda_activity_bills`). **No schema change** —
the surface rides entirely on the existing indexes (verified below).

**Direction — Corey's call, confirmed: issue-code-first.** This ships the "what's being
lobbied" surface. The bill-keyed "who lobbied THIS bill" cut on `/bill/[id]` is a separate
follow-on (HO 438) and is **out of scope here** (named in the banked list so it can't creep in).

## Why

The data layer landed 108,707 filings / 233,499 activities / 173,885 bill-links. The join
reality (HO 435): only **22.8% of activities carry a bill number** and **25.4% of filings
resolve to a tracked bill**, and the extractor is blind to named-not-numbered bills (NDAA,
appropriations, CRs — the most-lobbied). So **issue-code is the spine, the bill link an
overlay.** Bill-keyed-first would debut empty on three-quarters of bills and absent on exactly
the marquee ones. Issue-code-first shows the real corpus at scale with no coverage cliff, and
is the honest shape of the data.

## Surface: `/lobbying` — a new top-level analytical surface

Standalone index, same class as `/patterns` / `/trends` (an aggregate lens, **not** an entity
hub — the IA three-depth-levels rule doesn't apply). It reuses the **`/patterns` two-column
idiom almost verbatim** (ranked bars left, drill-on-selection right). Build to that idiom; don't
invent a new layout.

### Chrome
- `HeaderBar basePath="/lobbying"` (title bar + inline `· LAST SYNC` subhead + nav; the shared
  `<MarketsTape />` mounts under it automatically, app-wide). **No `GroupTabs`** — standalone,
  like `/patterns`.
- Breadcrumb: `Congressional Terminal:\119TH\Lobbying>` — add the crumb in `lib/breadcrumb.ts`.
- `export const dynamic = "force-dynamic"` (the page `await`s `searchParams` for `?issue=` +
  `?page=`).

### Nav wiring
- Add a top-level `NAV_ITEMS` entry **`Lobbying` → `/lobbying`**, grouped with the analytical
  items (near `Patterns`). Exact slot / divider placement is your call against the live nav.
- `pathToNavKey("/lobbying") → "lobbying"` (a special-case matcher, same as `/reports`).
- Heads-up: this is the 8th top-level item. The HO 281 header type-scale reflows nav to a clean
  2nd line under ~1420px, so it won't break — but eyeball that the nav still reads on a 1366
  laptop. Wrapping is acceptable.

### Section 1 — readout + blurb (mirror the `/patterns` H1 + meta line)
- H1 `LOBBYING`. Meta line (live, from `getLobbyingStats()`):
  `{filings} filings · {activities} activities · {registrants} registrants · {clients} clients · {billLinkedPct}% name a tracked bill`.
- Sans blurb (the `--sans` prose face, like the `/patterns` blurb): *"Who's paying to move what.
  LD-2 quarterly lobbying reports for the 119th, bucketed by issue area. The bill link is an
  overlay: only about 1 in 4 filings names a numbered bill, so the issue area is the spine."*

### Section 2 — two-column (the `/patterns` shape)

**LEFT — `IssueBars`** (clone `components/PatternBars.tsx`; server component, URL-driven):
- One row per `general_issue_code`. **Bar length = filing count** (linear, scaled to max).
  Columns `Issue · [bar] · Filings`. Label = `general_issue_code_display` (the human name) +
  the 3-letter `general_issue_code` as a dim slug — mirror `.pattern-bar-name` /
  `.pattern-bar-slug`. Truncate long display names gracefully (some are verbose, e.g.
  "Taxation/Internal Revenue Code").
- **Native LDA labels — do NOT crosswalk to the 24 CBT topics** (`lib/topic-colors.ts`). The LDA
  taxonomy is ~79 codes; forcing it onto 24 topics is lossy (Aviation / Aerospace / Automotive
  all collapse to "transportation"). Show the source's own vocabulary. The CBT-topic crosswalk
  is banked (below).
- Selection is URL-driven via `?issue=<code>`, `scroll={false}`, and **a code is always
  selected** — auto-select the top (highest-count) code when the URL carries none, so the right
  column is never blank (exactly the `/patterns` auto-select-top behavior).
- **Bar color:** neutral single hue for v1 (`--accent-amber` at ~50% alpha, or
  `--text-secondary`). There's no natural progress ramp here like Patterns' "% past committee."
  *(Optional honest encoding if you want it: color by the issue's share of activities that carry
  a resolved bill link, dim→amber — surfaces which issue areas lobby specific bills vs. broad
  agendas. Your call; neutral is the safe v1.)*

**RIGHT — `IssueDrill`** for the selected code (mirror `PatternDrilldownPanel`), from
`getIssueDrill(code)`:
- Headline line: `{filings} filings · {activities} activities · {distinctClients} clients · {billLinked} bill-linked`.
- **TOP CLIENTS** — top-5 by filing count, as party-neutral mini ranked bars (reuse the
  `PatternDrilldownPanel` top-5 sponsor mini-bar idiom; truncate names, count right-aligned
  `tabular-nums`). Client = who hired the lobbying.
- **TOP FIRMS** — top-5 registrants by filing count, same mini-bar idiom. Registrant = the
  lobbying shop / in-house filer.
- **RECENT** — the ~10 most-recent filings citing this code, rendered as `FilingRow` compact
  (below).

### Section 3 — corpus-wide recent filings (the `/trades` recency analog)
A paginated `FilingRow` list, corpus-wide, `dt_posted DESC` — the "what's new in lobbying" pulse
the daily cron exists to serve. Backed by `getRecentFilings({page, pageSize})` (template =
`getRecentTrades`, same `{items, total, page, pageSize, totalPages}` shape + the shared
`Pagination`). `pageSize` ~25.

### `FilingRow` (new component)
Compact row: `{relative age of dt_posted} · {registrant} → {client} · [issue chips] · [bill chips]`.
- Registrant / client = plain text (no entity pages for lobbying orgs in v1).
- Issue chips = the filing's distinct `general_issue_code`s, small dim tags (the `<MicroTag>`
  9px idiom). Show first ~3 + `+N`.
- Bill chips = resolved `lda_activity_bills.bill_id`s, each a `<Link>` to `/bill/[id]` styled
  like the id chip (`--accent-amber` border). **Omit the bill segment entirely when there are
  none** (the honest-gap discipline — no "—").
- `income` / `expenses` are **not** row figures (see the dollars note). A per-filing dollar
  detail in the row `title`/hover is fine if you want it.

## Query layer (`lib/queries.ts`, all `unstable_cache`, tag `"lda"`, `revalidate: 3600`)

Sketches — write the real SQL and **EXPLAIN each** per the cold-start discipline (the HO
277–280 arc):

1. `getLobbyingStats()` → `{filings, activities, registrants, clients, billLinkedPct}`.
   `registrants = COUNT(DISTINCT registrant_name)`, `clients = COUNT(DISTINCT client_name)` off
   `lda_filings`; `billLinkedPct` = filings with ≥1 `lda_activity_bills` row ÷ total filings.

2. `getLobbyingIssueBars()` → `IssueStat[] = {code, display, filings, activities, billLinked}`,
   `GROUP BY general_issue_code ORDER BY filings DESC`, driving off `idx_lda_activities_issue`.
   `filings = COUNT(DISTINCT filing_uuid)` per code (a filing counts toward each distinct code
   among its activities — correct). `display = MAX(general_issue_code_display)` (stable per code).

3. `getIssueDrill(code)` →
   `{filings, activities, distinctClients, billLinked, topClients:{name,filings}[], topFirms:{name,filings}[], recentFilings: FilingSummary[]}`.
   Top clients/firms:
   `SELECT f.client_name /* or registrant_name */, COUNT(DISTINCT f.filing_uuid) n
    FROM lda_activities a JOIN lda_filings f USING(filing_uuid)
    WHERE a.general_issue_code=? GROUP BY 1 ORDER BY n DESC LIMIT 5`.
   The issue seek narrows first, so the group is over a bounded subset — **no filing-name index
   needed** (confirm with EXPLAIN; the largest codes, TAX/BUD, group ~20k rows, fine for a cached
   query). `recentFilings` = filings with an activity of this code, `dt_posted DESC LIMIT 10`,
   hydrated with issue codes + bill links — **batch the hydration for the 10 uuids, no N+1**.

4. `getRecentFilings({page, pageSize})` → paginated corpus-wide `lda_filings` `dt_posted DESC`
   (uses `idx_lda_filings_dt_posted`), hydrated per-page with each filing's distinct issue codes
   + resolved bill links via ONE grouped query over the page's `filing_uuid`s (not per-row).
   Shape mirrors `getRecentTrades`.

5. `sanitizeIssueCode(raw)` → uppercase, `^[A-Z]{2,8}$`, else `null` (→ page auto-selects the
   top code). `sanitizePage` already exists — reuse it.

## Cron / cache wiring
- `app/api/cron/lda/route.ts`: after a successful tick, `revalidateTag("lda")` (import from
  `next/cache`) inside the finalize block, so a new-filings tick flushes the surface. The
  `revalidate: 3600` on the helpers is the fallback if a tick doesn't fire.
- `app/api/revalidate/route.ts`: add `"lda"` to `ALLOWED_TAGS` (so `POST /api/revalidate?tag=lda`
  works for a manual flush after the backfill).

## Two commits (discipline: data/wiring separate from surface)
- **Commit 1 — query layer + cache wiring:** the 4 helpers + `sanitizeIssueCode` in
  `lib/queries.ts`, the LDA cron `revalidateTag("lda")`, the `"lda"` allowlist entry. No UI.
  *Verify:* `getLobbyingIssueBars()` and `getIssueDrill("TAX")` return sane rows locally; EXPLAIN
  the drill's grouped join (confirm it seeks the issue index, no full `lda_filings` scan).
- **Commit 2 — surface:** `app/lobbying/page.tsx`, `IssueBars` / `IssueDrill` / `FilingRow`, the
  `NAV_ITEMS` entry + `pathToNavKey` + the breadcrumb crumb. *Verify:* `/lobbying` renders, the
  top issue auto-selects, `?issue=DEF` reselects, the feed paginates, bill chips deep-link to
  `/bill/[id]`, and it serves **200 cold after idle** (the HO 277–280 cold-start discipline).

## Explicitly out of scope — banked (named so they don't creep in)
- **Bill-keyed lobbying on `/bill/[id]`** — HO 438 (the other fork), reuses `lda_activity_bills`.
- **CBT-topic crosswalk** (LDA ~79 codes → 24 topics) — an optional overlay for a later cut; v1
  shows native labels.
- **Dollar aggregation** — `income`/`expenses` are per-filing, firm-side (income) vs in-house-side
  (expenses), mutually exclusive by filing type, so there's no honest corpus sum. Ranking is
  filing count. (Same "no clean dollar source" honesty as the PAC-IE surface — see
  `docs/oddities.md`.) A per-filing dollar detail in a row hover is acceptable.
- **Corpus-wide TOP FIRMS leaderboard** — the per-issue drill's top-firms is the sharper cut; a
  static "biggest shops" leaderboard is banked.
- **Named-not-numbered bill recovery** — needs the banked Congress.gov title-enrichment sync;
  until it lands, the bill overlay skews toward minor bills (documented, expected).

read docs/handoffs/437-lda-lobbying-surface.md and follow it
