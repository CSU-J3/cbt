# HO 468 — chip-family party leg (B6 arc)

Kill the ~8-way `partyColor` fork and route every `[P-ST]` bracket through the shared `PartyTag`. **Decision 3 (Corey): tint stays ON** — party color is the feed's core at-a-glance signal, so the spec's "tint off by default" is declined. That makes this a **pure refactor with no visible change**: one canonical color helper, one bracket component, zero pixels move. (The HO 465 audit's premise correction stands: the feed bracket is built client-side from structured `sponsor_party`/`sponsor_state`, not baked into `sponsor_name` — so there's no data-side blocker.) Closes the party leg + the B6 chip arc.

One commit. Re-grep every `partyColor` copy and bracket render at write time.

## Build

### 1. One canonical color helper

`lib/race-colors.ts` `partyColor` handles R/D/I but is typed `PartyKey` and misses the `"ID"` variant that `PartyTag` handles. Widen it (backward-compatible — `PartyKey` is a subset of `string`):

```ts
export function partyColor(party: string | null | undefined): string {
  const p = party === "ID" ? "I" : party;
  if (p === "R") return "var(--party-republican)";
  if (p === "D") return "var(--party-democrat)";
  if (p === "I") return "var(--party-independent)";
  return "var(--text-dim)";
}
```

(If `normalizePartyVariant` covers more cases, use it for the normalize step instead of the inline `"ID"` check — grep it.)

### 2. `PartyTag` — the canonical bracket component

- Replace its local `partyColor` switch with the shared import from `lib/race-colors.ts`.
- Add an optional `className` prop so bracket call-sites can pass their layout classes:

```tsx
export function PartyTag({
  party,
  state,
  className,
}: {
  party: string | null;
  state: string | null;
  className?: string;
}) {
  if (!party && !state) return null;
  return (
    <span className={className} style={{ color: partyColor(party) }}>
      [{party ?? "?"}-{state ?? "?"}]
    </span>
  );
}
```

### 3. Route the inline brackets through `PartyTag` (transparent — identical `[P-ST]` format + color)

- **`V2FeedList.tsx`** (`.v2f-subline-bracket`, ~L132): renders `[${sponsor_party ?? "?"}-${sponsor_state ?? "?"}]` — byte-identical to `PartyTag`. Swap to `<PartyTag party={bill.sponsor_party} state={bill.sponsor_state} className="v2f-subline-bracket" />`. Delete the local `partyColor` (~L88).
- **`app/members/page.tsx`** (`.mc-brk`, ~L340): renders `[{m.party ?? "?"}-{m.state ?? "?"}]`. Swap to `<PartyTag party={m.party} state={m.state} className="mc-brk shrink-0 tabular-nums" />`. Delete `partyColorFor` (~L67).

### 4. Color-converge the remaining helpers (color only — keep each surface's own rendering)

Repoint these onto the shared `partyColor`, deleting their local copies — but **do not** change their markup/format:

- **`SponsorExpandedPanel.tsx`** `partyColorFor` (~L46).
- **`SponsorHoverName`** local party color (~L29).
- **`MemberHeader.tsx`** local `partyColor` (~L18) — **exempt from `PartyTag`**: its identity meta line is `D-CT-3 · Born 1970` (dash-joined, includes district, no brackets), not the `[P-ST]` tag idiom. Converge its color helper only; leave `metaLine` alone.

### 5. Exempt (leave as-is, or color-converge only)

- **`PrimaryRow.partyChip`** (~L56): a labeled `DEM / REP / OPEN` chip — a different idiom, not a `[P-ST]` bracket. Leave it (color-converge only if it has its own copy).
- **`IdeologyStrip` / `RaceDistrictCard` / `MemberIdeology`** party-colored dots/fills: data-viz, not tags — untouched.

## Guardrail — no visible change

Tint stays ON. After the swap, `[D-CT]` must render **identically** (same text, same party color) everywhere it did before — feed, `/members` list, hearings, bill hub. The only change is source-of-truth consolidation. The `className` passthrough on `PartyTag` must preserve `.v2f-subline-bracket` and `.mc-brk`'s layout/spacing.

## Commit & verify

One commit, explicit pathspec, show diff, wait for approval, ancestry eyeball before push.

```
refactor(chips): one canonical partyColor + brackets through PartyTag (HO 468)
```

Prod-verify after deploy: dashboard feed `[D-CT]` and `/members` list `[D-CT]` render exactly as before (party-colored, same spacing); bill-hub + hearings party tags unchanged; member hub identity line unchanged; primary rows' DEM/REP/OPEN chips unchanged. Diff should show deletions of duplicate helpers, not visual churn. Zero new console errors.

---

**B6 chip arc close:** with the topic (HO 316), ID (466), stage (467), and party (468) legs done, the chip-family migration deferred from HO 287 is complete. A doc sweep (roadmap `Also` + backlog tombstones for the three legs, close the QUEUED chip-family item) follows as its own HO.
