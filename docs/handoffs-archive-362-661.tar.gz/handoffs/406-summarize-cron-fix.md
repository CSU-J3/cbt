# HO 406 — Summarize cron stall: the fix

> Renumber if HEAD has moved past 404. HEAD is `05d8c61` (HO 404). HO 405 was the read-only probe; this is its fix.
>
> This is a **code + one-index change**, so it runs spec-driven: propose the plan (exact DDL, the queue-read rewrite, the concurrency shape, where the 45s budget lives), **wait for my review, show diffs, never auto-commit.** HALT before the migration and before any deploy.

## What HO 405 proved (don't re-run — this is the input)

Two causes, co-occurring, and both must be fixed or the backlog keeps growing:

- **Mode 1 (primary):** the queue read at `lib/summarize-runner.ts:148` has no `LIMIT`. `EXPLAIN` = `SCAN bills USING INDEX idx_bills_update_date` over all 16,623 rows, row-looking-up `summary IS NULL` and materializing text columns for all ~1,374 eligible rows, unbounded. Cost scales with the backlog → doom loop. The 06-30 `error` at 20,146ms is the 10s `DB_REQUEST_TIMEOUT_MS` + one retry; the 07-02 / 06-29 55s soft-timeouts are the same slow read compressing the window until the run overruns.
- **Mode 3 (structural):** every success is `budgetStopped` at ~15–24 bills (the 45s budget wall, never the 50-cap). Inflow ≈ 30/day, healthy throughput ≈ 23/tick. So even with the read fixed, once-daily-at-45s is ~7/day underwater and the 1,374 backlog can't drain.
- **Mode 2 (ruled out):** Gemini ~1s/call, ~100-token outputs, zero 429/503, abort present. Leave it alone.

Root origin: **HO 383** removed the `LIMIT` to fetch the full set for app-side stage-priority sorting. Its inline note "the set is small, runs with no request cap" is now false at 1,374. We keep HO 383's stage-priority; we correct its unbounded read.

## Fix A — bound the queue read to unsummarized rows (Mode 1)

The read must stop touching the full corpus. The fix is a **partial index on the unsummarized set** so the planner scans ~1,374 rows, not 16,623:

- Add (idempotent, into `migrate.ts` `statements[]`): a partial index `... ON bills(<the priority sort keys>) WHERE summary IS NULL`. Propose the exact key list from HO 383's actual stage-priority comparator — the goal is that the index serves both the `summary IS NULL` filter and the priority ordering so the read is a bounded partial-index scan, not a corpus scan + row lookups. `CREATE INDEX IF NOT EXISTS`.
- Keep HO 383's stage-priority. Two ways, your call in the plan: push the priority ordering into SQL with `LIMIT N` (cleanest — the partial index serves it and only N rows return), or keep the app-side sort but now over the bounded null set the partial index returns. Either exits the 16k scan; pick whichever keeps the priority logic honest with the least churn.
- **EXPLAIN before/after** in the plan, and confirm cold — a clean plan once doesn't guarantee cold stability on this project, so state whether it needs an `INDEXED BY` hint to hold (the stateless planner mis-plans fat-table queries without one). The read should drop from a 16,623-row scan to a ~null-count scan.

Fix A alone stops the aborts. It does **not** drain the backlog — that's Fix B.

## Fix B — multiply per-tick throughput (Mode 3)

The window is fixed: Hobby caps cron at once-daily and functions at 60s (`maxDuration=60`, `wrapCronRoute` soft-stop 55s, runner budget 45s). You can't widen the window on Hobby, so the only lever is **more bills per window**, and Gemini being healthy at ~1s/call means the calls are just serialized. Parallelize them.

- **Bounded concurrency on the summarize calls.** Run the per-bill Gemini+write work through a concurrency limiter at **C≈5** (tunable — propose the number). At ~1.9s/bill, C=5 turns ~23 bills/45s into ~100+/tick. Keep the per-bill 15s `AbortController` per call, and keep the 45s budget as the outer wall. Guard: Turso is single-writer so the `UPDATE` writes serialize at the DB (fine, they're ms); Gemini 2.5 Flash RPM has plenty of headroom for C=5; confirm no shared mutable state in the runner breaks under parallelism.
- **Exclude ceremonial from the queue.** The read has no ceremonial filter, so the ~174 `is_ceremonial=1` bills get summarized despite the feed hiding them. Add `AND (is_ceremonial = 0 OR is_ceremonial IS NULL)` to the queue read — free inflow reduction, and it matches the feed predicate.

Together with Fix A this exits the doom loop permanently: A bounds the read to the null set, B keeps the null set small, so the read stays fast because the backlog stays near zero. Target: one daily tick clears a day's ~30 inflow with room to spare, and the accumulated backlog drains.

## Catch-up — one manual drain

Even fixed, the cron drains 1,374 over several ticks. Faster: the CLI `npm run summarize` runs locally with **no Vercel 60s ceiling**, so one long local run clears the whole backlog at once (with Fix B's concurrency, ~minutes). So: ship A+B, then run `npm run summarize` locally once to drain to ~0, and let the fixed cron maintain.

- **Prerequisite:** confirm the 45s budget wall is applied in the **cron wrapper only**, not inside `summarize-runner.ts` — if the runner itself enforces 45s, the CLI inherits it and can't drain. If it's in the runner, make the budget a caller-supplied param (large/none for CLI, 45s for cron). Flag this in the plan.

## Verification (before reporting shipped)

- `EXPLAIN` on the new read: bounded scan, not the 16k corpus.
- After deploy, one real cron tick (or a manual prod-config run): throughput up (well past ~23), no `error`/soft-timeout, `budgetStopped` at a much higher count or the queue cleared.
- `summary IS NULL` trending **down** across the next ticks, not up.
- Cold-time the read once more from idle to confirm the plan holds cold.

## Non-goals

- **No schedule change, no Pro upgrade.** Concurrency makes once-daily sufficient — don't add cron slots or move tiers.
- No model change, no prompt change (Mode 2 is fine).
- Don't touch the weekly-report cron (separate surfaced finding, its own handoff).
- Don't reverse HO 383's stage-priority — preserve it; only the unbounded read is wrong.

## Files

- `lib/summarize-runner.ts` — bound + ceremonial-filter the queue read; wrap the per-bill work in the concurrency limiter; budget-as-param if it currently lives in the runner.
- `scripts/migrate.ts` — the partial index (into `statements[]`, `IF NOT EXISTS`).
- The cron wrapper — only if the budget needs to move out of the runner.
- `package.json` unchanged (`summarize` script exists).

## Rollback

Drop the partial index; revert `summarize-runner.ts`. The runner reverts to the (slow but functional-at-low-backlog) unbounded serial read. Nothing else touched.
