# HO 645 — the absence band becomes cards, and gains the at-risk tier

**Ground truth:** `main` at `30b8d7c`. Roadmap's pointer reads **643**; the 643 block authorised R1's fix as "the number this sweep establishes," which is 644 and is landed. So this is **645**, derived from the roadmap chain and not from a filename.

**Ruled artifact:** `docs/design/mock-645-absence-cards-v6.html` — the owner has it. Commit it as a **docs commit of its own** (it never rides with code), then build against it. Where this handoff and the mock disagree, this handoff wins; where the mock shows a field, see §3 before assuming the data exists.

Two commits, each complete and correct on its own. **A does not ship the at-risk tier** — that matters, because a half-landed version would render at-risk members in MIA styling and make the band claim five people are missing when two are.

| # | Commit |
|---|---|
| A | `feat(HO 645): the absence band renders member cards` |
| B | `feat(HO 645): at-risk tier at W = 8` |

Standing rules: explicit pathspec staging, `npm run typecheck` before each push, ancestry eyeball, fast-forward only.

---

## §1 — Commit A: the band becomes cards

**No query change. No data change. MIA members only, exactly the population that renders today.** This commit is a render rework and nothing else, which is what makes it independently correct.

### 1a — Rename the island

`components/AbsenceWatchRows.tsx` → `components/AbsenceWatchCards.tsx`, export renamed to match, and the one import in `AbsenceWatchBand.tsx` updated. **Grep for other consumers before moving it** — the comment-claims base rate applies to my assertion that there is only one.

**The no-clock gate survives the rewrite verbatim.** That file's header states it must contain no timestamp constructor and no current-time read, and the check is a search over the file expecting zero lines. Re-run it after the rewrite and report the result. `sinceLabel` keeps arriving pre-formatted from the server band.

**Keep, unchanged:** the plain-click-expands / modified-click-navigates split including the `stopPropagation` on the modified branch (HO 627's mirrored defect), single-open, and the `rowRefs` focus return on Esc — a card that closes into nowhere strands a keyboard reader.

### 1b — The card

126px wide, ~176 tall. Structure from the mock:

```
button.abw-card                     ← the whole card is the toggle
  div.abw-card-mat        padding 5px, bg #151d29   ← the Topps border
    div.abw-card-face     height 134, overflow hidden, 1px rgba(0,0,0,.55)
      <photo>
      span.abw-card-disc  streak, top-left, tier fill, dark text
      span.abw-card-cut   the 6px mitre under the disc
      span.abw-card-pos   SEN / HSE, top-right
      span.abw-card-plate name + party over a bottom scrim
    dl.abw-card-stats     LAST | 119TH, two cells, hairline between
```

The mat is what makes it read as a card rather than a tile — do not collapse it to a border.

**Tokens only.** Every size in the 9–14px range is an `--fs-*` token. `--vote-nay` for the MIA frame and disc; party colour appears only on the plate line, never on the frame. That separation is load-bearing and the band's existing comment already states why: `--vote-nay` is chosen there *because* it is not a party token, so a red frame on a Republican card collapses alarm into party.

**C3:** the surname is the card's one bright element (`#fff` against the scrim). Disc, position chip and stat cells are dim or tier-coloured.

### 1c — The photo, with one implementation

Reuse `components/SponsorPhoto.tsx` — specifically its bioguide URL construction and its `onError`→initials fallback. **There must be exactly one implementation of both.** `SponsorPhoto` is 3:4 and the card face is 114×134 (0.85), so read it and decide: extend it with an aspect/height prop, or extract the URL + fallback into a shared helper the card uses. Do not copy the URL string into a second file (HO 507's shared-component rule).

Real portraits replace the mock's silhouettes 1:1. **Check two live bioguide photos in the 114×134 crop before committing** — silhouettes flatter a crop that photos may not, and `object-fit: cover` on a 3:4 source in a 0.85 box crops the sides.

### 1d — The back

The mock's back is **not** `SponsorExpandedPanel`. Build `components/AbsenceCardBack.tsx` — 330px, ruled stat rows, inside the same mat. See §3 for what goes in it.

The band currently renders `SponsorExpandedPanel` server-side and passes it down as a ReactNode. **Keep that idiom** — the new back is also a server component receiving the same `m.card` payload, rendered in `AbsenceWatchBand` and passed into the island as `ReactNode`. The island still only decides whether to mount it, so `lib/queries` and `next/cache` stay out of the client bundle.

`SponsorExpandedPanel` is **not** modified. `/members` is its other consumer and any change reaches both.

**Update the band's header comments.** They currently narrate the row anatomy, the single-column ruling, and the verbatim reuse of `SponsorExpandedPanel` — all three stop being true here. A comment describing a design that no longer exists is worse than none.

### 1e — Positioning

**Vertical, in CSS, no measurement.** Give the card `<ul>` `position: relative` and anchor the back to it:

```css
.abw-cards { position: relative; padding: 12px var(--space-md); }
.abw-cardback { position: absolute; top: calc(100% - 12px + 8px); }
```

`100% - 12px` is the ul's bottom padding, landing on the bottom edge of the **lowest** card; `+ 8px` is exactly how far a 12px square rotated 45° pokes above its box, so the notch tip meets the card rather than nearly meeting it.

Anchoring to the lowest card rather than the open one is deliberate: with one row they are the same card and the notch touches, and if the list ever wraps the panel drops below both rows instead of covering the second. Covering other members is what HO 631 ruled against and the reason survives the rework.

**Confirm no ancestor clips it.** The panel escapes the `<ul>`; if `.abw` or anything above it carries `overflow: hidden`, this silently truncates.

**Horizontal, measured on the client.** On open and on resize, read the open card's `offsetLeft`/`offsetWidth` and set the panel's `left` clamped to `[12, bandWidth - 330 - 12]`, plus the notch's own `left` clamped inside the panel. Inline styles from the island.

### 1f — Accepted cost, stated so it isn't rediscovered

The open panel **covers the band's footnote**, which carries the delegate-carve disclosure. Ruled acceptable by the owner. The carve stays in the footnote — do not duplicate it onto the back to compensate.

---

## §2 — Commit B: the at-risk tier

**W = 8**, ruled at HO 642 P2 by the criterion fixed before the numbers existed: smallest W in [6,20] with pooled max ≤ 6 and median ≥ 1.

### 2a — Query

`queryAbsenceWatch`'s Phase A currently runs `HAVING nv = n AND nv > 0` over the most recent `ABSENCE_WINDOW = 30` rolls, so a member on a 15-roll streak is not a candidate and Phase B never sees them. Widen Phase A's window to **8** and leave Phase B's exact walk against `ABSENCE_WALK_BOUND = 120` **byte-identical**. Then bucket on the streak Phase B already computes:

- `streak >= ABSENCE_STREAK_MIN` (30) → `tier: "mia"`
- `8 <= streak < 30` → `tier: "warn"`

`ABSENCE_STREAK_MIN` stays at 30 and is **not swept here.** The S=30 review is a separate open loop gated on the House returning from recess, and moving both boundaries in one pass makes neither attributable.

Add `tier` to `AbsentMember`. Order: MIA by streak desc, then at-risk by streak desc.

**Re-measure, don't inherit.** The probe found Phase A gets *cheaper* at a narrower window (house 26,120 → 8,674 `rows_read`) and Phase B unchanged at 480. Confirm both at W = 8 on the current corpus and report; the corpus has moved since. Predicate every count — a bare `COUNT(*)` under-reports by 227–416× (HO 624 M0).

### 2b — Header and styling

Header becomes `▲ MIA (n) · AT RISK (n)`. **Each segment is independently conditional (C4):** at-risk 0 renders no AT RISK segment and no separator; MIA 0 renders no MIA segment. Both 0 still renders `null` for the whole band — on this surface empty is the good-news state.

At-risk cards: `--accent-amber` frame and disc, `·` instead of `▲` in the badge, surname at `--text-secondary` rather than `#fff`. Amber is attention, red is alarm; the two tiers must not read as one list.

### 2c — Falsification, and this one is not optional

The occupancy replay found the `[8,30)` band **empty at the newest cursors** — the House's most recent roll in that window is 20 days old and the five newest cursors read zero. So **the amber branch may ship rendering nothing**, and an unexercised branch is unproven, not protection (HO 552).

Fire it on real HEAD with real data: temporarily raise `ABSENCE_STREAK_MIN` to 40, which moves Wilson (streak 34) into `[8,40)` and through the amber path — real member, real query, real render. Confirm the amber card renders, the header shows both segments, and the back opens. Then revert, `git status` clean, **commit nothing**.

Do not fabricate a member. Do not lower W to force a hit — that changes the thing under test.

---

## §3 — What goes on the back, and what does not

The mock shows six rows. **Two of them have no source in the current payload, and the mock is illustrative** — the backlog's own HO 631 lesson is that illustrative mock data never sets an expectation for a build.

In hand from `AbsentMember` + `m.card`: **streak**, **lastCastDate**, **missedPct**, **committees**, **recentBills**, name/party/state/chamber.

Not in hand, and **not to be added in this HO**:
- **The last vote's bill id** (the mock's `JUN 11 · S 2201`) — the query returns a date, not the roll call's subject.
- **Seniority** (`41 yrs · rank 1`) — needs a `terms_json` parse and a rank computation across the chamber.

Render the rows you have in the mock's ruled form. **Report which mock rows had no source** rather than inventing them or silently dropping them. If either is worth having, it is a scoped item with its own cost, not a detail of this build.

Check whether `m.card.stats` already carries a vote count for the `119TH VOTES` row's `1,061/1,262` denominator; if not, render the percentage alone.

---

## §4 — Re-price the payload before shipping B

The backlog's absence-band payload entry set its own trigger: *"band membership grows past a handful — at today's 2 members the whole prefetch is 236 rows/regeneration and the payload is not the problem it becomes at ten."* **B is that trigger firing** — the band goes from 2 members to a measured median of 4 and a max of 9 pooled.

Measure, before pushing B, the cached `getAbsenceWatch` value: row count and serialized bytes, at the live population and again with `ABSENCE_STREAK_MIN` temporarily at 40 as a higher-population proxy.

**Ruling criterion, fixed now:** if the blob exceeds **2× its current 15,481-byte post-HO-631 size**, take the entry's named second move — the SQL-side count for `getSponsorTopTopics`, still counted in JS over the full raw row set — before shipping. If it does not, say so and re-price the trigger in the backlog against the new population rather than leaving a clause that has already fired.

Note the direction this may cut: if `AbsenceCardBack` consumes less of `m.card` than `SponsorExpandedPanel` did, the assembly can narrow and the payload **falls**. Verify by id, not by byte total — a total can coincide (HO 631).

---

## §5 — Verification

1. Cards render for both live MIA members; open, close, switch, `Esc`, click-outside all behave; the notch tip lands on the open card.
2. Modified-click on the name navigates and does **not** leave a card open — the HO 627 mirrored defect.
3. Esc returns focus to the card that opened the panel.
4. The no-clock search over the renamed island returns zero lines.
5. Two real bioguide photos eyeballed in the 114×134 crop.
6. After B: the amber branch fired per §2c, and both header segments render.
7. `/members` byte-identical — `SponsorExpandedPanel` is untouched and this is the check that proves it.
8. `npm run typecheck` clean; `pageErr` count unchanged.

Check `/api/version` before believing prod: `getAbsenceWatch` is `unstable_cache`d and the Data Cache survives deploys. Hit until the value converges and holds.

---

## §6 — Not in this HO

- **`ABSENCE_STREAK_MIN` is not swept.** Separate loop, still gated on the House returning.
- **No new queries** for seniority or the last vote's bill id.
- **`SponsorExpandedPanel` is not modified.**
- **No backfill runs**, no detector, no 2024-margin work — all separately scoped in backlog.
