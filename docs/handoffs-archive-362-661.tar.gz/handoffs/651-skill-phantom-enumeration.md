# HO 651 — enumerate what SKILL names that does not exist

**Ground truth:** `main` at `0ee0570` (`docs(HO 650): close the orphans finding, and file what it turned up`), `ls-remote` reads main only.

**Number:** roadmap pointer **646**, commit subjects run to **650**, so `max(646, 650) + 1` = **651**.

**This is a PROBE. It fixes nothing.** No SKILL edit, no deletion, no prose corrected. HO 650's ruling stands and is the reason this exists: the documented-and-nonexistent set is unmeasured, and editing SKILL against a hand-assembled list is how `~53` and `~67` came to sit on two lines describing the same set.

**Commits:**

| # | Kind | Contents |
|---|------|----------|
| 1 | `chore` | `scripts/diagnostic/skill-phantoms-651.ts` |
| 2 | `docs` | backlog — what M1/M2 price, appended, only if there is something to file |

---

## §1 — What scoping already measured, so you do not re-derive it

Run on `0ee0570`. SKILL names **286** backtick-quoted PascalCase identifiers. Two filters were tried against them and **the answer is neither number**:

| filter | candidates | fails how |
|---|---|---|
| no occurrence anywhere in repo source (string presence) | **22** | too tight — it **clears the motivating case** |
| no file and no `export` of that name (definition) | **122** | too loose — sweeps in non-component vocabulary |

**The tight filter clears `DistributionsTabs`, which is the exact defect HO 650 was filed on.** Its only occurrence anywhere in the repo is `app/globals.css:1563` — *inside a comment*, describing the deleted treemap's pane behaviour. So **one stale artifact vouches for another**, and a string-presence check reads two pieces of drift as one live component. That is the design constraint this probe is built around: **existence means a definition, never a mention.**

The loose filter's noise is a vocabulary problem, not a logic one — it catches SQL keywords (`EXPLAIN`, `HAVING`, `INSERT`, `DESC`), FRED and Kalshi tickers (`CPIAUCSL`, `DGS10`, `KXFEDDECISION`), bioguide and FEC ids (`C001103`, `C00799031`), Web APIs (`AbortController`, `ReactNode`), and UI label strings (`BREAKING`, `CONFIRMED`, `MISSED`). All of those are correctly present in SKILL and none is a component.

**One precedent from the scoping itself, and it belongs in the report.** The first definition-filter pass returned **145** and flagged `MarketsTape`, `HeaderBar` and `WeeklyBand` as nonexistent. The bug was `ls a b`, which exits non-zero when *either* path is missing, so the file test never fired and everything fell through to the export regex. It was caught by adding a control, not by reading the list. **Third consecutive HO in which an identifier-matching check was wrong on first write** — and this one was in the handoff for the probe designed against that class. Treat the filter as guilty.

---

## §2 — M1: candidates

For each of the 286, exclude on **definition**: a file at `components/<Name>.tsx` or `components/svg/<Name>.tsx`, or an `export` of that name anywhere under `app/ components/ lib/ scripts/`. Test the file paths **separately**, per §1.

Then split the remainder by **whether the tight filter would have cleared it**, and report that column. A candidate cleared only by a string occurrence is a **paired-drift** case — the SKILL mention plus whatever vouched for it — and both need naming. `DistributionsTabs` is the known member; report how many others there are, because that count is the answer to "is `globals.css:1563` a one-off."

**Do not hand-curate the vocabulary noise.** Emit every candidate with the reason it survived the filter. Whoever reads it can see that `HAVING` is SQL; a list that has already been pruned to look sensible cannot be checked.

---

## §3 — M2: classification is PER MENTION, not per name

SKILL is full of correct deletion records and they are load-bearing history, not drift: `DashboardBubbleChart`, `MemberProductivityScatter`, `EnactedBanner`, `PatternBubbleSVG`, `MemberStats`, `MemberAffiliations`. An instrument that cannot separate those from `DistributionsTabs` returns a hundred candidates and no signal.

So M2 emits **every mention** of every M1 candidate — line number and enough surrounding text to read the sentence — and each mention is classified as exactly one of:

- **PHANTOM** — the mention presents the name as a live component, route, or surface. Work.
- **RECORD** — the mention states the thing was deleted, replaced, superseded, retired, or dropped. Correct as written, no action.
- **NOT-A-COMPONENT** — vocabulary, per §1's noise classes. No action.

**Report mentions, not names.** A name can be RECORD at one line and PHANTOM at another — `DashboardTopicTreemap` was exactly that before HO 650, correctly recorded as replaced at one site and listed as a live island at three others.

---

## §4 — The trap, and the negative control that is already committed

The obvious mechanization of §3 is proximity: mark a mention RECORD if a deletion marker (`deleted`, `removed`, `superseded`, `replaced`, `retired`, `dropped`) sits near it. **That heuristic fails on the case this HO exists for, and the failure is in the tree right now.**

Post-`123e4c3`, SKILL L2043 reads `…and the treemap file was **deleted at HO 650**…), DistributionsTabs (**HO 244**, STAGE | TOPIC tab state…`. The deletion marker is **four characters** from a phantom, and it is about a different component. Proximity clears it.

**So use it as a negative control.** The probe must classify **L2043's `DistributionsTabs` mention as PHANTOM.** If the classifier clears it, the classifier is wrong, whatever else the run reports. Build the control before the classifier and let it fail first — a control written after the code that passes it is a restatement of the code.

This is the same shape as HO 649's `import type` bug: the compiler-erased edge and the adjacent-marker both make a dead thing emit a live signal.

---

## §5 — Controls

1. **Negative, §4:** L2043 `DistributionsTabs` reads PHANTOM. Proven able to fail — remove whatever check catches it and confirm it flips to RECORD, then restore.
2. **Positive:** `DashboardBubbleChart` reads RECORD at every mention. It is the canonical correctly-recorded deletion; if it reads PHANTOM the classifier is inverted and every count is noise in the other direction.
3. **Filter control:** `MarketsTape`, `HeaderBar`, `WeeklyBand`, `TopStalls`, `TopicDistributionList` must all be **excluded at M1**. These are the five the broken `ls` test wrongly flagged during scoping; they are the regression case for §1's bug.
4. **Anchor check, HO 610 rule.** Control 1 anchors on a specific product line that a later HO will fix. **Say so in the script**, with what re-anchoring costs — the same expiry that hit C3a at HO 650, named at write time rather than discovered.

**Report all four before any finding.**

---

## §6 — What the report must contain

- The four control readings, first.
- M1 counts: 286 named · excluded by definition · candidates · of those, paired-drift (tight filter would clear).
- The candidate list **in full, unpruned**, with the survival reason per entry.
- M2 counts by class, **in mentions**, and the PHANTOM list in full with line numbers.
- The paired-drift partners — for each, the non-SKILL artifact that vouched for it, with file and line. `app/globals.css:1563` is one; report the rest.
- **What this cannot see.** At minimum: it reads SKILL only, so the same class in `docs/*.md` is unmeasured; and a mention that names a live component while describing behaviour it no longer has reads as clean, which is the HO 646 passage's defect and is a fourth direction nobody has instrumented.

**No recommendations, no fixes, no SKILL edits.** What to do with the PHANTOM list is 652's question, and it should be scoped from the enumeration rather than from this handoff.

---

## §7 — Commits

Commit 1 is the script alone. Commit 2, if it happens, is backlog only, appended, expected `--numstat` stated before running.

Report the diff before pushing. Explicit pathspec staging, no `git add .`, ancestry eyeball, fast-forward on `main`. No review ref needed unless a backlog entry's wording wants reading — this touches no SKILL.
