# HO 397 — Land the brand rename (CBT → "Congressional Terminal")

Confirm 397 is the next free number before saving (`ls docs/handoffs/ | sort -V | tail`); body assumes 397.

## What this is

There's an uncommitted CBT → "Congressional Terminal" brand rename sitting in the working tree from a prior session. A dirty tree mid-rename is the concurrent-session hazard the handoffs keep guarding against: the next build that touches shared files risks an entangled commit or an ancestry mess. This audits that WIP, scopes it correctly, and lands it as one clean commit so the tree is clean for the next feature.

Audit first. Do NOT commit until I've approved the scope (standing rule: no commits until I've seen the diff).

## Assess (read-only)

- `git status` + `git diff`. The uncommitted changes should be the brand rename and nothing else. If unrelated WIP is mixed in, separate it and tell me — don't commit the mix.
- Classify every changed file:
  - **Keep (the rename):** user-facing copy and metadata — page titles, masthead/header strings, `<title>`, OG/meta tags, web manifest, README brand prose, any on-screen brand string.
  - **Scope back (should NOT change in a brand rename):** identifiers and config — package name, route paths, type/interface/component names, env var names, DB names, and especially the repo slug `cbt` and the Vercel project `cbt-chi-silk`. If the find-replace leaked `CBT` → "Congressional Terminal" into any of these, back it out. Flag each one.
- Confirm the tree still builds: `tsc` clean, `npm run build` passes, no broken imports, no dead routes. A half-touched rename (symbol renamed at its definition but not its references, or the reverse) is the tell — report it.

## Report for approval — HALT

Post back:
- The changed-file list, classified (copy/metadata vs anything that leaked into identifiers/config).
- Any scope-backs you recommend.
- tsc / build status.

Wait for my approval on the scope before committing anything.

## After approval — land it

- Commit as ONE commit, explicit pathspecs on the approved files only. Never `git add -A` (other WIP may be in the tree).
  `chore: rename brand CBT → Congressional Terminal (user-facing)`
- Recheck ancestry before push (the whole point is the concurrent-session hazard).
- `npm run verify:deploy` — served SHA matches HEAD.
- Spot-check one deployed user-facing surface (dashboard `<title>` / masthead) reads "Congressional Terminal". Report what you saw.

## Report back

- Final commit SHA, served-SHA match, the surface spot-check.
- Confirm `git status` is now clean so the next build has a clean base.

Note: the repo slug (`cbt`) and Vercel project (`cbt-chi-silk`) can't change from code and aren't in scope. Live URL and repo stay as-is; this is a display-name change only. README's brand strings land here (they were deliberately held out of the 0855626 doc sweep to avoid sweeping this WIP into a docs commit).
