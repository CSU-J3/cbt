# HO 554 — motion-aware amendment outcomes (the Senate procedural residual)

Builds the surface HO 550 GO'd. **STEP 0 is read-only and HALTS for a verdict** — do not
write build code until STEP 0 is reported and approved.

---

## 0. What's settled going in

HO 550's probe (`scripts/diagnostic/procedural-amendment-votes-550.ts`, committed `9383b9f`)
priced this and returned GO:

- **Vocabulary CLOSED at 4 classes**, tail 0 — `table` 9 · `cloture` 4 · `chair` 1 · `waiver` 50 = **64 Senate roll calls**
- **100% number resolution** (64/64). The waiver form's `Amdt. No. N` is the **same** Senate
  `S.Amdt` namespace, confirmed by 42/43 sponsor-surname match — not a parallel numbering
- **60 amendments would gain a line**; **4** already carry an anchored decisive vote
- **Polarity 54/56 (96%)** against **full** coverage (64/64 residual amendments carry
  `latest_action_text` — a procedural floor vote always generates an action, so this is *not*
  the corpus-wide ~8.6% that makes a high rate on small N meaningless)
- Cold ~162ms for the residual × `member_votes` split

### Correct the value proposition before you build to it

"60 would gain a line" does **not** mean 60 amendments gain an *outcome*. The outcome is
already there: `deriveDisposition(latest_action_text)` already handles
`motion to table.*agreed to` → `failed`, and the probe measured full action-text coverage on
this set — so **the disposition dot is already correct on these rows today.**

What the motion line actually adds is what the action text can't carry: **the roll-call tally,
the D/R/I party split, and the `/vote/[id]` drill.** That is exactly the delta `VoteLine`
already adds over action text on the decisive path. Real value, honestly stated. Build to
that, not to "we're fixing the outcome."

**STEP 0 M2 tests whether that framing is right.** If it isn't, this handoff's render design
changes and you halt.

---

## 1. Scope guards — hard, non-negotiable

1. **Do NOT widen `SENATE_AMDT_Q` / `SENATE_AMDT_QUESTION_LIKE` / `HOUSE_AMDT_Q` /
   `HOUSE_AMDT_QUESTION_LIKE`** in `lib/amendment-vote-key.ts`. That leaf's SCOPE note says
   procedural votes are deliberately excluded and must stay excluded — this surface is the
   motion-aware model that note points at, built *alongside* it, not a matcher tweak. The
   decisive path stays byte-identical.
2. **Do NOT write motion rows into `amendment_votes`.** Procedural rows in that table were a
   live P1 three HOs ago (HO 550 M5 → HO 551 fix). Every existing consumer reads it
   unfiltered: `getBillAmendmentVotes` step 2b, `hydratePageAmendmentVotes`, the `/amendments`
   "voted" `EXISTS` predicate, and the member-side reads near `lib/queries.ts:7469`. Adding a
   `kind` column means auditing and amending all of them — wrong trade for 64 rows. Motions
   live in a **live-parsed, store-free path**.
3. **Do NOT change** `deriveDisposition`, `dispositionColor`, `voteVerb`, or `VoteLine`. The
   disposition dot keeps its existing two-tier authority (`vote ? vote.disposition : a.disposition`).
   A motion **never** drives the dot — that would be a third authority over one number.
4. **Do NOT change the `/amendments` "voted" filter.** A motion-only amendment is not "voted"
   under the current definition and stays that way in v1. Banked, not built.
5. **House is out of scope.** The residual is Senate-only. House procedural roll calls reach a
   HAMDT only through the `/actions` walk, which HO 551 now gates at INSERT — there is no
   House motion store and recovering one means re-widening the walk that fix closed. Say so in
   a code comment so nobody reads the absence as "the House has no procedural votes."
6. **No migration, no new table, no sync change, no `amendments-sync.ts` / `amendment-votes-walk.ts` touch.**

---

## 2. STEP 0 — read-only diagnostic, COMMIT, then HALT

New file: `scripts/diagnostic/motion-outcome-model-554.ts`

Same idiom as HO 550: raw `@libsql/client`, **no `boundedFetch`** (the 10s bound aborts a cold
query and hides its true cost), `SELECT` / `EXPLAIN QUERY PLAN` only, `dotenv/config`,
`npx tsx` entry point. Import the classifiers from HO 550's probe or re-declare them — do
**not** create the production leaf yet.

### M1 — reconcile the off-by-one (the smell HO 553 refused to paper over)

HO 550's M4 exclusion math is `64 − 5 orthogonal − 2 withdrawn = 57` expected clean pairs, but
`N` came back **56**. One vote is unaccounted for. From reading the probe, it fell through the
`if (actual === "other" || implied === "other") continue;` branch. **Identify it and report
which side returned `other`:**

- **`implied === "other"`** — `motionOutcome(votes.result)` couldn't classify the motion's own
  result string. This is a **render gap**: the surface would have a motion it can't give a verb
  to. Report the exact `votes.id`, `question`, and `result`.
- **`actual === "other"`** — `actualFate(latest_action_text)` couldn't classify the amendment's
  action text. This is only a **validation-coverage** gap; the surface is unaffected.

Print the vote either way. Do not assume which it is.

### M2 — dot delta (P1 tripwire — run and report this first)

For each of the residual-resolved amendments, compare:

- `deriveDisposition(amendments.latest_action_text)` — **what the dot shows on prod today**
- `impliedFate(class, votes.result)` — what the motion model implies

Bucket and report counts:

| bucket | meaning |
|---|---|
| **AGREE** | dot and motion agree — confirms §0's framing, dot stays untouched |
| **DOT-OTHER** | dot is muted `other`, motion implies a clean fate — the surface would add outcome, not just tally |
| **ORTHOGONAL** | cloture/chair — no implied fate, excluded |
| **DISAGREE** | dot says one fate, motion implies the opposite |

**`DISAGREE > 0` is a HALT.** One of the two is wrong on live prod today, and a wrong outcome
outranks the feature — the HO 550 M5 precedent exactly. Print every disagreeing row
(`amendment_id`, dot value, implied value, `votes.result`, `latest_action_text`) and stop.

`DOT-OTHER > 0` is not a halt but it **changes the spec** — report the count and the rows; I'll
make the call on whether the motion may promote a muted dot.

### M3 — cardinality: motions per amendment

HO 550's M2 reported 64 distinct resolved amendments against 64 residual votes, implying 1:1
(no amendment carries two motions). **Confirm it directly** — group the residual votes by
resolved `amendment_id` and report `MAX(count)` plus any id with `> 1`.

This decides whether the `+N earlier` overflow branch is reachable on live data. If it's 1:1,
the branch ships unexercised and §6 applies.

### M4 — the exact hydrate query's plan and cold cost

`EXPLAIN QUERY PLAN` + cold timing for the query B2 will actually run — the residual `votes`
select plus the `member_votes` × `members` party-split join over its vote ids, **as two
statements** (matching the shape of `hydratePageAmendmentVotes`), not HO 550's single
`LEFT JOIN … GROUP BY`. Report both plans and both timings from idle.

Note whether the residual select rides an index or scans `votes`. A scan over the current
`votes` table is fine at this size — measure it, don't assert it, and report the row count so
the WATCH in §7 has a baseline.

### Commit and halt

```
diag: HO 554 STEP 0 — motion-aware amendment-outcome model (read-only)
```

Explicit pathspec, script only. Report M1–M4 and **stop**. No build code, no component, no
query-layer edit until I return a GO.

---

## 3. Build — B1: the leaf

New file: `lib/amendment-motion-key.ts`, the sibling of `lib/amendment-vote-key.ts`.

It must be a **leaf** — no `next/cache`, no `lib/queries.ts` import — for the same reason
`amendment-vote-key.ts` is (a `scripts/` entry point must be able to import it, and diagnostics
will want it). Header comment should state that relationship and point at the decisive leaf.

Exports:

```ts
export type MotionClass = "table" | "cloture" | "chair" | "waiver";

// The SQL pre-filter pair for the residual set: mentions an amendment, is NOT the
// up-or-down form. Exported so the query and any diagnostic share ONE predicate.
export const SENATE_MOTION_QUESTION_LIKE = "%Amdt%";
// (paired at the call site with NOT LIKE SENATE_AMDT_QUESTION_LIKE from the decisive leaf)

export function classifyMotion(question: string): MotionClass | null;
export function parseMotionAmendmentNumber(cls: MotionClass, question: string): number | null;
export function motionOutcome(result: string | null): "agreed" | "failed" | "other";
export function impliedFate(cls: MotionClass, result: string | null):
  "agreed" | "failed" | "orthogonal" | "other";
```

Lift the regexes verbatim from HO 550's probe — they're the measured, validated set. Two
things the header must record, because they're the load-bearing non-obvious facts:

- **The number token differs by class.** `table`/`cloture`/`chair` carry `S.Amdt. N`; `waiver`
  carries `Amdt. No. N`. Same namespace (M2's 42/43 sponsor match), different token.
- **`table` inverts.** Tabling agreed = amendment **killed**; tabling failed = amendment
  **survived**. `waiver` does not invert (waive agreed = amendment survives). `cloture` and
  `chair` are **orthogonal** — they decide procedure, not the amendment's fate, and must never
  produce one.

`classifyMotion` returns `null` for the tail rather than a `"tail"` member — the vocabulary is
closed today, and a `null` at the call site is a skip, not a render. If the tail ever grows, it
silently drops rather than rendering a class the model can't reason about.

---

## 4. Build — B2: the query layer

All in `lib/queries.ts`. Two additions, one shared helper.

### Type

```ts
export interface AmendmentMotion {
  voteId: string;              // votes.id → /vote/[id]
  cls: MotionClass;
  motionResult: string | null; // votes.result, verbatim
  outcome: "agreed" | "failed" | "other";     // motionOutcome(result) — the MOTION's own fate
  impliedFate: "agreed" | "failed" | "orthogonal" | "other"; // the AMENDMENT's fate, or not one
  yea: number; nay: number; present: number; notVoting: number;
  date: string | null;
  party: { D: {yea:number;nay:number}; R: {yea:number;nay:number}; I: {yea:number;nay:number} };
}
```

**Serialization rule (HO 533):** plain objects, numbers, strings, `null` only. No `Map`, `Set`,
`Date`, or class instance anywhere in a value that crosses `unstable_cache` — `tsc` cannot
catch it and the annotation stays honest while the cache layer breaks it on the *hit* path.

### Shared helper

```ts
async function hydrateAmendmentMotions(
  db: ReturnType<typeof getDb>,
  amendmentIds: string[],
): Promise<Record<string, AmendmentMotion[]>>
```

Mechanism — the amendment number lives in `votes.question` text, so it **cannot** be filtered
in SQL by amendment id. Therefore:

1. `SELECT id, congress, question, result, vote_date, yea_count, nay_count, present_count, not_voting_count FROM votes WHERE chamber='senate' AND question LIKE ? AND question NOT LIKE ?`
   (args: `SENATE_MOTION_QUESTION_LIKE`, `SENATE_AMDT_QUESTION_LIKE`) — the full residual set,
   ~64 rows.
2. In JS: `classifyMotion` → skip `null`; `parseMotionAmendmentNumber` → skip `null`; build
   `${congress}-samdt-${n}`; **intersect against the requested `amendmentIds` set**.
3. Party split over the surviving vote ids — the identical two-query shape
   `hydratePageAmendmentVotes` uses (`member_votes` ⋈ `members`, `GROUP BY vote_id, party, position`,
   `normalizePartyVariant`, yea/nay only).
4. Sort each list `date DESC` (the `VoteLine` list[0]-is-canonical convention).

Fetch the party split **unconditionally**, even when it may come back all-zero — same reasoning
as `hydratePageAmendmentVotes`' comment: not fetching renders identically to not-yet-synced and
quietly lies.

The residual select is a fixed cost independent of page size. That's the trade for keeping the
data out of `amendment_votes`; M4 prices it and §7 watches it.

### Cached entry point for `/bill/[id]`

```ts
export const getBillAmendmentMotions = unstable_cache(
  async (billId: string): Promise<Record<string, AmendmentMotion[]>> => { … },
  ["getBillAmendmentMotions"],
  { revalidate: 3600, tags: ["votes", "amendments"] },
);
```

A **new sibling**, not a reshape of `getBillAmendmentVotes` — the HO 496/512 discipline, and
the same reason HO 530 built a separate query rather than widening `getBillAmendments`.

Body: select this bill's `SAMDT` amendment ids (`amended_bill_id = ?`, type `SAMDT` only —
HAMDT can't appear in a Senate residual), then `hydrateAmendmentMotions`. Empty in →
empty out, no second query.

**`try/catch` → `{}`**, matching `getBillAmendmentVotes`' `[amendments] … live miss` log line
and its degrade-never-500 comment. It runs inside the bill page's `Promise.all`; a throw takes
the whole page down.

Tags `["votes","amendments"]` match `getBillAmendmentVotes` — `votes` flushes on a votes
re-sync, `amendments` on the amendments cron.

### Corpus feed

Add `motions: AmendmentMotion[]` to `AmendmentListRow`, populated in `getAmendments` by calling
`hydrateAmendmentMotions(db, pageIds)` alongside the existing `hydratePageAmendmentVotes` call —
same page-scoped id set, run them in parallel. `getAmendments`' existing tags already cover it.

---

## 5. Build — B3/B4: render and wiring

### New component: `components/AmendmentMotionLine.tsx`

Do not add this to `AmendmentVoteLine.tsx`. That file is the *decisive* vocabulary shared by
three consumers; a motion is a different grammar and mixing them invites exactly the confusion
this surface exists to prevent.

Same visual grammar as `VoteLine` — one dim mono line, `mt-1 text-[11px] tabular-nums`,
`var(--font-mono)`, `var(--text-muted)`, tally linked to `/vote/${voteId}` in
`var(--text-secondary)` with `hover:underline`. **Reuse those tokens; introduce none.**

Copy, per class:

| class | line |
|---|---|
| `table` (agreed) | `Motion to table agreed 52–47 · amendment killed · D … · R …` |
| `table` (failed) | `Motion to table rejected 47–52 · amendment survived · D … · R …` |
| `waiver` (agreed) | `Budget waiver agreed 60–39 · amendment survived · D … · R …` |
| `waiver` (failed) | `Budget waiver rejected 52–47 · amendment fell · D … · R …` |
| `cloture` | `Cloture motion rejected 57–43 · D … · R …` — **no fate clause** |
| `chair` | `Decision of the Chair sustained 51–48 · D … · R …` — **no fate clause** |
| any, `outcome === "other"` | motion name + tally + split, **no verb, no fate clause** |

The fate clause renders **only** when `impliedFate` is `agreed` or `failed`. `orthogonal` and
`other` render the motion and its tally and stop — stating a fate the model can't support is
the wrong-worse-than-absent failure this whole line is designed around.

Reuse `VoteLine`'s split suppression verbatim: when `D.yea+D.nay+R.yea+R.nay+I.yea+I.nay === 0`,
suppress the split (positions not yet synced, HO 533). `present` / `notVoting` clauses render
only when `> 0`. `+N earlier` when the list has more than one — see §6.

### Wiring — `/bill/[id]`

- `app/bill/[id]/page.tsx`: add `getBillAmendmentMotions(bill.id)` to the existing `Promise.all`
  (alongside `getBillAmendmentVotes` at line ~145), pass through to `<BillAmendments … motions={…} />`.
- `components/BillAmendments.tsx`: thread `motions: Record<string, AmendmentMotion[]>` down to
  its inner `AmendmentRow`. Render **after** the `VoteLine` slot, **before** the `↳ amends` line.

### Wiring — `/amendments`

- `components/AmendmentRow.tsx`: read `a.motions`, same placement.

### Suppression rule (both surfaces, identical)

```
render a motion line ONLY when the amendment has NO decisive vote.
```

`/bill/[id]`: `votes[a.id]` empty. `/amendments`: `a.votes` empty. This is the 4 already-anchored
amendments from M3. Showing both lines invites reading the motion tally as the amendment's tally —
the precise misread that made HO 550's M5 a P1. **Suppress entirely** in v1; a combined
decisive-plus-procedural history is banked, not built.

### Copy coherence — one required check

`app/amendments/page.tsx:224` currently reads:

> Counts up-or-down floor votes on the amendment; procedural votes (tabling, cloture, budget waivers) are excluded.

That stays **true of the count** (guard #4 keeps the "voted" filter unchanged), but once motion
lines render in the rows below it, a reader can fairly read it as "we don't show those." Extend
it minimally so it scopes the exclusion to the count, e.g. `…are excluded from this count`.
Copy only — do not touch the query behind it.

---

## 6. Falsification (HO 549/553 discipline — required, nothing committed)

Before any doc records a branch as working, **fire it**. Hand-apply the perturbation on current
HEAD in scratch — **never** a checkout of pre-fix files — run, confirm, revert, `git status`
clean, commit nothing.

Branches to prove, ranked:

1. **The `+N earlier` motion overflow** — if M3 confirms 1:1, this branch cannot fire on live
   data. Perturb a residual `question`'s number in scratch so two motions resolve to one
   amendment, confirm the head renders and `+1 earlier` appears, revert. If the local
   environment can't demonstrate it, that is **ambiguous, not a disproof** — record it as
   UNPROVEN in a WATCH rather than claiming protection.
2. **The `orthogonal` no-fate-clause branch** — 5 rows exist (cloture 4 + chair 1); confirm on
   live data whether any lands on a rendered page. If none does, perturb to force one.
3. **The all-zero split suppression** — same posture as the standing `BillVoteRow` `bvote-none`
   WATCH; note it rather than forcing it if live data doesn't exercise it.

---

## 7. Verification

**Cache-hit, not cache-miss (HO 533/549).** A check immediately after deploy only exercises the
`unstable_cache` MISS path, which builds the value fresh in-process and works even when the
serialized round-trip is broken. **Hit each URL 2–3 times** — the second hit is the real test.
This is why the HO 533 `Map` bug shipped three times.

Then:

1. **A motion-bearing bill page** — pick one from STEP 0's would-gain set. Motion line renders,
   tally links to `/vote/[id]`, party split present, correct fate clause, **dot unchanged**
   versus pre-build.
2. **A cloture/chair amendment** — line renders with **no** fate clause.
3. **One of the 4 already-anchored** — decisive `VoteLine` renders, **no** motion line.
4. **`/amendments` corpus feed** — same three checks in the row context; pagination and the
   `?disposition=` / `voted` filters behave identically to pre-build.
5. **Regression gate:** a bill with decisive votes and no motions (`119-hr-8800`, the HO 551
   19-amendment control) renders **byte-identical** to pre-build.
6. `npx tsc --noEmit` clean; `e2e/fit-finish.spec.ts` + `e2e/smoke.spec.ts` green locally.

Add to the WATCH set for the doc sweep: the fixed-cost residual select (row count from M4 as
the baseline; it grows with the Congress and is un-indexed by construction — promote to a
`kind`-column materialization only if it ever approaches the 10s `DB_REQUEST_TIMEOUT_MS` wall,
and note that materializing means auditing every `amendment_votes` consumer per guard #2).

---

## 8. Commits — boundaries

Explicit pathspec staging only, never `git add .`. **Show me the full diff hunk before each
build commit** — these are live production surfaces, not inert probes. If the relay swallows a
pasted diff twice, stop pasting and use the review-ref route
(`git push origin HEAD:refs/heads/554-review`), then main fast-forwards and the ref is deleted.

1. `diag: HO 554 STEP 0 — motion-aware amendment-outcome model (read-only)` — **then HALT**
2. `feat(amendments): HO 554 — motion-aware outcome model (leaf + query layer)` — B1 + B2
3. `feat(amendments): HO 554 — motion line on /bill/[id] + /amendments` — B3 + B4 + the copy fix

Code and docs never ride together — the doc sweep is **HO 555**, a separate commit, after the
build is prod-verified on the cache-hit path.

---

## 9. Report back

After STEP 0: M1 (which side returned `other`, with the row) · M2 (four bucket counts; every
DISAGREE row printed) · M3 (`MAX(motions per amendment)`) · M4 (both plans, both cold timings,
residual row count). Then stop.

After the build: the diff, the six verification results, and the falsification outcome per
branch — including any branch recorded UNPROVEN rather than claimed as protection.
