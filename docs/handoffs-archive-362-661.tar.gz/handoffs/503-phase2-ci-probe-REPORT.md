# HO 503 — Phase 2 CI probe: REPORT

Read-only probe. No edits to `.github/`, `e2e/`, `playwright.config.ts`, `lib/db.ts`,
`scripts/migrate.ts`. Two throwaway probe scripts (`_probe.mjs`, `_probe2.mjs`) and
scratch `file:` DBs were created outside/gitignored, run, and deleted — `git status`
confirmed clean, nothing entered the tree.

**Headline: the fixture is technically cheap (no `lib/db.ts` change, migrate runs clean
on `file:`) and covers ~95% of the suite — but the handoff's premise is inverted. The
risk was never false-RED against an empty corpus; the specs are written so defensively
(skip-if-absent, soft, `if(count)` guards) that an under-seeded fixture goes false-GREEN,
which is worse than the red-blindness it was meant to cure. My call is Step 6 option
(don't build the fixture); reasoning at the end.**

---

## Step 1 — does `file:` work through `getDb()`? **YES. No `lib/db.ts` change needed.**

`@libsql/client` installed version: **0.14.0** (`^0.14.0`).

I replicated the exact `lib/db.ts:70` call shape against a `file:` URL and ran queries.
Three cases, all live:

| Case | Config passed | Result |
|---|---|---|
| **1 — exact `getDb()` shape** | `createClient({ url:"file:…", authToken: undefined, fetch: boundedFetch })` | **createClient OK, CREATE+INSERT+SELECT OK** (read back n=1) |
| 2 — fetch key, no authToken key | `createClient({ url:"file:…", fetch: boundedFetch })` | OK, query OK |
| 3 — bare control | `createClient({ url:"file:…" })` | OK |

The local sqlite path **silently ignores** both the `fetch` key and `authToken: undefined`.
`boundedFetch` (the HO 238 timeout/abort/retry wrapper) is never invoked on a `file:` URL —
it only exists on the HTTP/hrana transport, which a `file:` URL doesn't take. So the HO 238
semantics on the HTTP path are provably unaffected: the code path isn't even reached.

**Blast radius stays at `config + fixture`.** No scheme-sniff, no edit to the single most
load-bearing module in the repo, no separate pre-commit. This is the good outcome.

### migrate.ts against `file:` — **runs clean, exit 0.**

`TURSO_DATABASE_URL=file:… npx tsx scripts/migrate.ts` → **`migration complete`, exit 0.**
All ~132 DDL statements applied: every `CREATE TABLE`, every idempotent `ALTER … added
column`, the `already exists` guards fired correctly, **`bills_fts` (FTS5) populated** — so
local libsql ships FTS5, no Turso-only pragma blocks the build. **52 tables** created.
`migrate.ts` is a clean, portable schema source; the fixture can be built from it.

**One schema gap that matters for Step 2 (C):** the four names the handoff lists under
bucket C — `lda_lobbying_rollup`, `lda_top_firms`, `lda_topic_crosswalk`, `lda_bill_drill` —
are **NOT tables**. `migrate.ts` creates only the raw `lda_filings / lda_activities /
lda_activity_bills`. The four rollup names are **`dashboard_state` keys** (confirmed:
`lib/lda-rollup.ts:22,431,523,601,673` upsert them as blobs; `weekly_lead` likewise via
`lib/dashboard-lead.ts:6,175`). So even a perfectly-seeded fixture has them **absent**
unless the rollup script (`npm run lda:rollup`) and lead generator also run in CI. That's
the real (C) cost — see Step 3.

---

## Step 2 — the data-dependence audit (the deliverable)

Bucketing every `test()` in both files. Legend: **A** shape-only · **B** needs corpus rows ·
**C** needs a `dashboard_state` blob · **D** needs live external state · **E** needs prod
egress specifically. "guard" = the test has a `test.skip`/`if(await x.count())` that makes it
**pass-without-asserting** when the data is absent (the false-green surface).

### `e2e/smoke.spec.ts` (HO 379 — default target PROD)

| Test(s) | Bucket | Note |
|---|---|---|
| route-crawl × 32 (home, 6 stages, welcome, bills, members, members/pass-rate, races, electoral, primaries, reports, hearings, news, changes, stale, trends, patterns, search, president, amendments, nominations, lobbying, trades, committees-redirect, watchlist, dashboard-classic, dashboard-v2) | **A** | asserts only 200 + zero failed/bad/console/pageErr. Survives near-empty DB. `/lobbying` here is A — the crawl only checks 200/clean, which holds even with the blob absent (omit-when-null path). |
| route-crawl × 5 detail (`/bill/119-s-2`, `/members/A000055`, `/race/AL-01-2026`, `/committee/hlig00`, `/reports/2026-06-15`) | **B** | need those **exact seed IDs** or they 404/500 instead of 200. |
| gate deep-link param drop | **A** | pure routing + no cookie; `/welcome` renders. Local-reproducible — **not (E)**. |
| expand a bill row → `.bxp` | **B** | needs bills that render `.v2f-row`. |
| race district drawer → `.rdm-panel` | **B** *(guard)* | skips if no `.us-map-state`. |
| B2 markets hover | **D** *(guard)* | skips if 0 `.markets-tape-item` (BotID note). |
| PRESIDENT stage row → clean filter | **B** | needs bills bucketed across stages to render the funnel. |

**smoke totals: A 33 · B 8 · C 0 · D 1 · E 0 = 42**

### `e2e/fit-finish.spec.ts` (HO 472 — default target LOCALHOST)

| Test | Bucket | Note |
|---|---|---|
| home: feed expand single-open/re-click/Esc | **B** | ≥2 `.v2f-row`. |
| home: id chip → `/bill/[id]` | **B** | bills. |
| home: markets tape hover → portal | **D** *(guard)* | seeds `market_ticks` freshness; skips if 0 (flags on local). |
| home: WeeklyBand metric hover | **B** *(guard)* | needs the weekly band to render metrics; skips if 0. |
| home: distributions click-to-filter | **B** | stage funnel rows. |
| home: HEARINGS/RACES tab + racesLastView | **B** *(guard)* | races/hearings; skips if <2 tabs. |
| home: sponsor hover card | **B** *(soft note)* | bills + resolved member sponsor; notes if none. |
| electoral: state click → modal | **B** *(guard)* | races/districts. |
| electoral: primary timeline bar | **B** *(guard)* | primaries. |
| electoral: MAP/LIST accordion | **B** *(guard)* | races. |
| aggregate: /amendments chips rebase | **B** *(guard)* | load-clean is A; chip-rebase needs amendments rows. |
| aggregate: /nominations facet rebase | **B** *(guard)* | load-clean A; facet needs nominations. |
| aggregate: /lobbying issue drill + crosswalk | **C** *(guard)* | issue drill + BY-CBT-TOPIC crosswalk read `lda_lobbying_rollup` + `lda_topic_crosswalk` blobs. Load-clean is A. |
| aggregate: /lobbying pagination keeps ?issue= | **C** *(guard)* | recent-filings feed depends on the rollup + `lda_filings`; skips if no pager. |
| aggregate: /trades rollup + member link | **B** *(guard)* | `stock_trades`. |
| aggregate: /trades?member= scoped | **B** | `stock_trades` for that member (soft). |
| detail × 5 (bill/member/committee/report/race) | **B** | the 5 exact seed IDs. |
| members: browser + committee rail | **B** | members + committees (asserts rail links > 0). |
| members: committee-scoped view 200 | **B** | `?committee=hlig00`. |
| lighter: /stale + procedural toggle | **A** *(guard)* | asserts clean only; toggle guarded. |
| lighter: /hearings loads clean | **A** | HO 502(a): 200 + no-redirect + **static** breadcrumb "Hearings". No corpus. |
| lighter: /search tabs + query | **A** | search over empty FTS still 200/clean; tab guarded. |
| lighter: /president loads clean | **A** | HO 502: 200 + no-redirect + **static copy** "racing the 10-day clock". |
| lighter: /news loads clean | **A** | HO 502: 200 + no-redirect + **static** NewsFilters "most recent". |
| lighter: /watchlist anonymous 200 | **A** | |
| dropdown hunt × 2 (desktop/mobile) | **A** | counts select/combobox on `/`, asserts clean. |

**fit-finish totals: A 8 · B 20 · C 2 · D 1 · E 0 = 31**

### Grand totals — **A 41 · B 28 · C 2 · D 2 · E 0 = 73 tests**

- **A + B = 69 / 73 (95%)** are fixture-servable.
- **C = 2**, both `/lobbying`, both self-guarded.
- **D = 2**, both markets-hover, both self-guarded (skip on empty tape).
- **E = 0.** Two candidates the handoff floated dissolve on inspection:
  - The **gate → /welcome redirect** is a `cookies()` + `auth()` check in `app/page.tsx:74`
    (no middleware, no egress) — **local-reproducible, bucket A.**
  - `/changes` + `/patterns` "localhost-500" (fit-finish header caveat) is a **network-latency**
    artifact — the 10 s `boundedFetch` bound vs the us-west-2 round-trip. A **`file:` fixture
    has zero round-trip**, so that class *disappears* under a local fixture rather than
    needing prod. They're A against a fixture.

**This number is the decision, and it inverts the handoff's hypothesis.** C+D+E do *not*
dominate — they're 4 tests, all self-guarding. The specs are overwhelmingly shape-checks and
seedable corpus-checks. The worry that "every assertion reaches for a real district / drill /
ticker and fails as red CI" is not what the code does: those assertions are wrapped in
`if(await x.count())` / `test.skip` guards precisely because they were built to run against a
*live, changing* corpus. That defensiveness makes them fixture-tolerant.

### The catch that replaces it — false-green, not false-red

The same guards that prevent red **also prevent the assertion from running when the fixture is
under-seeded.** 18 of the 28 (B) tests and all 4 (C)/(D) tests are guarded. On a thin fixture
they go **green while exercising nothing** — the `/amendments` chip never clicks, the race
modal never opens, the lobbying drill never fires. That is a *worse* failure than red CI: red
is visible, hollow-green is not. **The fixture's job is therefore not "avoid red" — it's "seed
richly enough to trip every guard so the assertions actually execute."** That reframes the cost
(Step 3) and is the core reason my recommendation is cautious.

### Tests already asserting nothing (free to note)

Beyond the HO 502(a) `/hearings` case already caught: the guarded (B)/(C) tests above are all
**conditionally-null** today when run against a corpus that happens to lack the row — e.g.
`/trades` member-link, `/lobbying` crosswalk, sponsor-hover. They're not *broken*, but they
inflate the apparent suite size: a naive "31 fit-finish tests pass" overstates coverage
whenever the live corpus is thin on that surface. No new *always-null* test found besides the
one HO 502 already fixed.

---

## Step 3 — fixture provenance and rot (costed, because Step 2 says A+B is servable)

**Provenance — recommend (b) a seed script, with eyes open.** Ranking:
- **(a) committed binary `.db`** — fast, opaque, **rots silently** against `migrate.ts` (a new
  table/column appears in migrate, the blob doesn't, nothing complains). Rejected: silent rot
  is the exact hollow-green failure mode we're trying to avoid.
- **(b) seed script over a freshly-migrated `file:` DB** — transparent, diffable, and it
  **inherits the real schema** by running `migrate.ts` first (so it can't drift *structurally*).
  Its liability is that it becomes **a second data-shape consumer** (column semantics, enum
  values, the `stage` bucketing, sponsor resolution) that drifts against the app's read
  expectations. **Recommended** — the drift is at least loud-ish (a renamed enum breaks a guard's
  `if(count)` → the test goes green-empty → detectable by a "coverage floor" assertion, below).
- **(c) sanitized prod export** — realistic but a standing re-export obligation + a data-in-repo
  question. Overkill for shape+guard coverage.

**Size — this is the real bill.** To trip *every* guard (not just 200 the pages), the minimum is
roughly:

| Table | ~min rows | Why |
|---|---|---|
| `bills` | ~30–50 | ≥1 per stage across all 6 (`introduced…enacted`) with `summary` + resolved sponsor + topics, so the feed, funnel, stage filters, expand panel, and sponsor-hover all populate. |
| `members` | ~10 | sponsors + committee rail + the `A000055` seed + ideology strip. |
| `committees` + `committee_members` | ~3 + rows | rail + `hlig00` seed + scoped roster. |
| `races` + `race_candidates` + `primaries` + `primary_candidates` | ~10 + rows | map cells, district modal, `AL-01-2026` seed, electoral timeline bars. |
| `amendments`, `nominations` | ~10 each | chip/facet rebase. |
| `stock_trades` | ~10 | rollup + member link + scoped view. |
| `lda_filings` (+ `lda_activities`) | ~20 | so the rollup has something to compute + pagination. |
| `dashboard_state` | 5 blobs | **must run `lib/lda-rollup.ts` + `lib/dashboard-lead.ts`** post-seed to synthesize `lda_lobbying_rollup / lda_top_firms / lda_topic_crosswalk / lda_bill_drill / weekly_lead`, or the (C) tests hollow-green. |
| `market_ticks` (+ `kalshi_odds`/`polymarket_odds`) | ~10 fresh | only if you want the (D) markets tests to *run* — and freshness is **now-relative**, which fights CI's frozen clock. Recommend **not** seeding these; let (D) skip. |
| the 5 seed detail IDs | exact | `119-s-2`, `A000055`, `AL-01-2026`, `hlig00`, `2026-06-15` — hard-coded in both specs. |

**Verdict on size: "hundreds of rows across ~15 tables, hand-maintained, PLUS re-running two
rollup scripts in the seed step" — yes, plainly.** This is a non-trivial standing artifact.

**What detects rot?** Nothing automatic today, and that's the danger. A committed `.db` (a)
detects nothing. A seed script (b) detects *structural* drift (migrate adds a NOT-NULL column →
seed insert throws → loud). It does **not** detect *semantic* drift (a guard's selector class
renames → test green-empty). The only real rot-detector is a **coverage-floor assertion**: after
seeding, assert e.g. `.v2f-row` count ≥ N, `.us-map-state` ≥ N, a lobbying drill link exists —
i.e. convert the guards' silent skips into hard failures *in the fixture context only*. That's
extra build surface, and it's mandatory if the fixture is to be worth more than the prod crawl.

---

## Step 4 — the three blockers, verified live

1. **`webServer` block — CONFIRMED absent.** `playwright.config.ts` has no `webServer` key
   (read in full). To run locally in CI it needs
   `webServer: { command: "npm run build && npm run start", url: "http://localhost:3000",
   reuseExistingServer: !process.env.CI }`. **Use `build && start`, not `next dev`** — the
   #418 hydration class (HO 489/490) is a *production-build* phenomenon; `next dev` suppresses
   the React warnings that make it visible (fit-finish `isKnownNoise` even filters `[Fast
   Refresh]` defensively). Port pin `-p 3000` already lives in the `start`/`dev` scripts
   (`package.json:7,9`). ✓
2. **`TURSO_*` repo secrets — CONFIRMED moot under the fixture path.** `getDb()` reads
   `TURSO_DATABASE_URL`; set it to `file:./ci-fixture.db` in the job env and **no secret is
   needed at all**. The build is already secretless (HO 488). So the fixture path removes the
   secrets question entirely rather than managing it — as the backlog predicted. ✓ (verified,
   not assumed.)
3. **markets-hover `.hover()` — bucket (D), does not get "fixed."** Both markets tests
   (`smoke` B2, `fit-finish` tape-hover) self-skip on 0 tape items. In CI-fixture without fresh
   `market_ticks` they skip; on prod they skip anyway (BotID withholds the tape from headless).
   They only truly *run* on local-with-fresh-data. **Recommend: exclude from the CI project,
   keep in the local/prod-manual run.** ✓

---

## Step 5 — recommended shape (if built)

- **Filter mechanism: a `@ci` grep tag, not duplicated spec files and not two whole projects.**
  Tag only the tests the fixture actually feeds (the A crawl + the seedable, guard-tripped B
  set). Leave (C) blob, (D) markets, and the prod-egress crawl **untagged** so they stay in the
  existing manual/local invocation. A tag is lighter than a second spec tree and — critically —
  keeps you from tagging a guarded test the fixture can't feed (which would re-introduce
  false-green). One new `ci` project in the config with `grep: /@ci/`, `baseURL:
  http://localhost:3000`, `webServer` as in Step 4.
- **Job placement: a SEPARATE workflow (`e2e.yml`), NOT a job inside `ci.yml`.** Two reasons,
  both already documented in `ci.yml`'s own header: (i) the `paths-ignore` + required-check
  branch-protection landmine — an ignored-path PR never reports a check added there; (ii) it's
  minutes-long and would tax the one-commit-at-a-time rhythm that `checks` deliberately keeps
  fast. Trigger on `pull_request` (or `workflow_dispatch`) only.
- **Runtime estimate:** `npm ci` (~30–60 s cached) + `playwright install chromium` (~30–60 s,
  cacheable) + `next build` (~60–120 s) + fixture seed (instant, `file:`) + tagged run
  (~30–60 s) ≈ **3–5 min per PR**. That is a real tax; state it plainly to whoever approves.

---

## Step 6 — my call: **don't build the fixture. Wire the existing prod crawl as scheduled CI.**

The probe was supposed to answer "is A+B high enough that a fixture is the right shape." A+B is
95%, so *technically* yes. But "right shape" is a value question, and three facts point away
from the fixture:

1. **The fixture's marginal value over what exists is thin.** Phase-1 (`typecheck + build`)
   already catches the `3ed533c` class. The e2e suite's *unique* catch is the
   console-error/`#418`-hydration class (build doesn't render pages) — and that class is bucket
   **A**, which already runs against **prod** today with `BASE_URL` and no fixture. A fixture
   would move that catch from *post-deploy* to *pre-merge*. Worth something, given fast Vercel
   deploys — not worth a hundreds-of-rows, 15-table, two-rollup-scripts standing artifact.
2. **The fixture introduces a failure mode worse than the one it cures.** The guards make an
   under-seeded fixture go **hollow-green**. Curing that requires the extra coverage-floor
   assertions (Step 3) — i.e. you don't just build the fixture, you build a fixture *plus* a
   second assertion layer to prove the fixture didn't rot. That's the expensive-theater the
   handoff feared, just relocated from "red-blindness" to "green-blindness."
3. **The buckets that carry the e2e's real value (egress, cold-start, BotID, live markets) are
   still unservable by a fixture** — but they're *already served*, manually, against prod, and
   they work.

**Recommendation, concretely:**

- **Primary (build this):** a scheduled `e2e-prod.yml` — `schedule` (e.g. every 6 h) +
  `workflow_dispatch` — running the **existing** `smoke.spec.ts` (bucket A crawl) against
  `BASE_URL=<prod>`. No fixture, no secrets, no schema-drift obligation, off the per-commit
  path. Catches the console-error/#418/egress/cold-start regressions that build cannot, within a
  6 h window. (Vercel owns deploys — memory `project_markets_cron_reliability` — so there's no
  GitHub deploy step to chain a true post-deploy job onto; a schedule is the pragmatic wiring.)
- **Only if pre-merge #418 protection is explicitly wanted:** the thin middle path the handoff
  names — a fixture backing **only the (A) shape-crawl tagged `@ci`**, plus the 5 seed detail
  IDs, on `pull_request` in a separate `e2e.yml`. **Do not** tag the guarded (B) interaction
  tests (false-green) or (C)/(D). This is a *few-dozen-row* fixture, not the hundreds-of-rows
  one — because you're only feeding "does the page render + stay console-clean," not tripping
  every interaction guard.
- **Do NOT** build the full corpus fixture to automate the (B)/(C)/(D) interaction suite. Those
  belong in the local/manual `fit-finish` run where a developer eyeballs the screenshots;
  automating them buys guarded coverage that hollows out silently and costs a permanent seed
  obligation.

**Close the "Phase 2 Playwright-in-CI" loop as: "not a fixture — wired as a scheduled prod
smoke."** The build HO writes `e2e-prod.yml`; the tombstone records that the fixture was costed
(95% servable, no `lib/db.ts` change, migrate-portable) and *declined* because its marginal
value over Phase-1 + the existing prod crawl didn't justify a hundreds-of-row / two-rollup-script
standing artifact whose dominant failure mode is silent green.

---

## Open questions (unresolved — flagged, not guessed)

1. **Empty-migrated-DB behavior is unmeasured.** I did not stand a server against the unseeded
   `file:` DB (would edge toward "building to see if it works"). Whether every (A) route **200s
   on a migrated-but-empty DB** — vs 500 on a `rows[0]`/`[0].x` access with no rows — is the
   first thing the build should measure, because it sets the true floor of bucket A. My
   classification assumes the pages guard empties (most Next server components map over arrays
   that are simply empty), but that is an assumption, not a measurement.
2. **`market_ticks` freshness vs CI's frozen clock.** Even if you *wanted* the (D) markets tests
   to run in CI, tape freshness is `now`-relative and CI has no stable clock to seed against.
   Treated as "leave (D) skipping"; not solved.
3. **Playwright browser-download in CI** (`playwright install`) network/cache behavior on the
   runner is estimated, not measured (no CI run performed — read-only probe).
