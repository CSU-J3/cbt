# HO 604 — C2, the viewport type scale. Ship today.

**Numbering re-established from the repo, not from the arc doc.** `docs/roadmap.md`'s pointer reads *"Also notes now run through HO 602"*; HEAD is **`e8279c1`** and carries HO 603 (Parts A–C + residual). The arc doc's "591" anchor is twelve HOs stale — HOs 591–603 landed between the plan and now. **Next free number is 604.**

The arc itself is already filed: `docs/backlog.md:130`, written at HO 603 Part A, records C1–C8, the M1–M7 instrument, and the scoping findings. That entry is the standing record. This HO discharges **C2 only** and does not touch the other seven.

---

## 0. Three corrections to the plan, and the one that makes today possible

**(a) The blast radius was understated, and HO 603 was right to re-measure it — but its own count was also short.** Re-measured against `e8279c1`:

| surface | sites |
|---|---|
| `app/globals.css` | 416 |
| `app/welcome/landing.module.css` | **22** |
| `text-[Npx]` in `app/` + `components/` `.tsx` | 355 |
| inline `fontSize` props | 35 |
| **total type sites** | **828** |

The arc logged ~450. HO 603 corrected to 784 with `grep -roh "font-size:" app/*.css` — **that glob misses `app/welcome/landing.module.css` entirely** (it's a directory down), and the file writes its declarations **without a space after the colon** (`font-size:11px`), so a substitution regex tuned to the globals.css style would silently skip all 22 and report clean. Same shape as the HO 549/553 rule: a pattern that structurally can't match reads identical to nothing to match. **Both CSS files are in scope and the regex takes `font-size:\s*Npx`.**

**(b) The six-value finding — this is why the day is possible.** 828 sites is not a hand-edit job. But the values are extremely concentrated:

```
globals.css   11px ×115  12px ×97  13px ×48  10px ×47  9px ×27  14px ×19   → 353 / 416
landing.css   11px ×8    9px ×3    10px ×3   14/13/12 ×1 each             →  17 / 22
text-[Npx]    12px ×177  11px ×66  13px ×51  14px ×38  10px ×12           → 344 / 355
```

**714 of 828 sites (86%) are six values**, reachable by **eleven find-and-replace operations** — six regexes across the two CSS files, five across TSX. Not 828 edits. That is the whole argument for shipping this today rather than treating C2 as a multi-session sweep.

**(c) The `@media` risk is a non-issue, measured not assumed.** Only **4 of 438** CSS `font-size` declarations sit inside a media block (26px, 16px, 15px, 12px — one each), and just one is in the substitution set. The mobile overrides don't fight the scale. This was flagged in the plan as potentially blocking; it isn't.

---

## 1. Why C2 goes first, and why the audit does not

The arc doc put the audit at P0. Reverse it — but for a narrower reason than "the measurements go void." They don't entirely: whether a row pins an element right is structural, so the *identity* of offending rows survives a type change. What doesn't survive is the **before/after delta**. Baseline at 12px, remediate at 15px, and the improvement is the type change and the layout change tangled together — and tangled in the flattering direction, since bigger text closes gaps on its own. The arc is scored on M1 reaching zero, so the baseline has to be taken at the size the remediation happens at.

The audit becomes HO 605, run against the scaled site. The arc's own argument survives intact — it says do C2 before the *route work*, and that still holds.

---

## 2. The safety property: ship the plumbing at identity

The substitution is **value-preserving by construction**. `--fs-11: 11px` replacing `font-size: 11px` renders byte-identical. So C1 below ships **with no media queries at all** and must produce **zero visual change at every width**. The scale is a separate commit that can be reverted alone.

This splits the two risks cleanly:

- **C1's risk is missed sites and broken syntax** — caught by residual grep + typecheck + build + a computed-size diff.
- **C2's risk is the ladder being wrong** — caught by eyeball, and revertable without unpicking 714 substitutions.

Do not collapse them into one commit.

---

## 3. C0 — commit the two mocks. First, alone.

`docs/backlog.md:130` says this arc "points at nothing," and the HO 590 mock is recorded as **absent from disk, not merely untracked**. Two artifacts exist only in chat right now and are one session from the same fate:

- `mock-591-dashboard-layout.html` → **`docs/design/dashboard-layout-target.html`**
- `mock-591-conventions.html` → **`docs/design/layout-conventions-c1-c8.html`**

Descriptive names, no HO number — matching the seven files already in `docs/design/`. Commit verbatim, no edits.

`docs(design): HO 604 C0 — the layout target and the C1-C8 convention dictionary`

The backlog line-130 correction (the arc no longer points at nothing) belongs to the doc sweep, not here.

---

## 4. C1 — the plumbing, at identity

**Add to `:root` in `app/globals.css`**, beside the existing `--space-*` scale, with a comment recording that they are deliberately at identity in this commit and that the ladder lands in the next:

```css
--fs-9: 9px;  --fs-10: 10px; --fs-11: 11px;
--fs-12: 12px; --fs-13: 13px; --fs-14: 14px;
```

**Six regexes across both CSS files** (`app/globals.css`, `app/welcome/landing.module.css`) — `font-size:\s*9px\b` → `font-size: var(--fs-9)`, and the same for 10/11/12/13/14. The `\b` matters: `9px` must not match inside `9.5px`. Verify by counting `9.5px` / `10.5px` / `11.5px` / `12.5px` occurrences before and after and asserting they're unchanged.

**Five regexes across `app/**/*.tsx` and `components/**/*.tsx`** — `text-[10px]` → `text-[length:var(--fs-10)]`, and the same for 11/12/13/14. Tailwind is **v4.2.4** with `@import "tailwindcss"`; the `length:` hint is required or the arbitrary value is ambiguous with a color.

**Leave alone:** the 35 inline `fontSize` props, and every one-off size (8 / 8.5 / 9.5 / 10.5 / 11.5 / 12.5 / 15 / 16 / 17 / 18 / 19 / 20 / 22 / 23 / 24 / 26 / 38). Report their counts; they're the next pass, not this one.

**Gate — and note what each one can and cannot detect, because the obvious gate here is a non-instrument.**

A computed-`fontSize` diff across the identity change **cannot detect a missed site.** A site left as literal `font-size: 11px` renders 11px, which is exactly what `--fs-11` renders. If C1 substituted *nothing at all*, the diff would read zero differences and pass perfectly. State what the instrument reads if the work never happened: same as success. So it isn't the coverage instrument, and must not be treated as one.

1. **Coverage — the residual grep, run twice.** Before the substitution it must return **714**; after, **0**. Both numbers get reported. Running it only afterwards is the same defect as above: a grep pointed at the wrong path returns zero before *and* after, and looks like a clean sweep.
2. `npm run typecheck`.
3. `npm run build` — no new Tailwind warnings.
4. **Breakage — the computed-size diff.** Throwaway script (not committed): against `npm run start`, walk every element on `/`, `/bills`, `/members` at 1440, record `getComputedStyle(el).fontSize`, run pre- and post-change, assert zero differences. This catches a mangled regex (`var(--fs-11)px`), a wrong var value, and a cascade change from the Tailwind class swap. Those are the C1 failure modes. It is not evidence of coverage.

One cascade check while you're there: pick an element carrying both a `text-[length:var(--fs-N)]` class and a `globals.css` rule setting `font-size`, and confirm the winner is unchanged. It should be — v4 puts utilities in `@layer utilities`, which loses to the unlayered rules in globals.css regardless of source order — but confirm rather than reason.

`refactor(type): HO 604 C1 — six --fs tokens substituted at identity (no visual change)`

---

## 5. C2 — the ladder

Three media queries in `app/globals.css`, immediately after `:root`:

```css
@media (min-width: 1600px) { :root { --fs-9:10px;  --fs-10:11px; --fs-11:12px; --fs-12:13px; --fs-13:14px; --fs-14:15px; } }
@media (min-width: 2000px) { :root { --fs-9:11px;  --fs-10:12px; --fs-11:13px; --fs-12:14px; --fs-13:15px; --fs-14:16px; } }
@media (min-width: 2400px) { :root { --fs-9:12px;  --fs-10:13px; --fs-11:14px; --fs-12:15px; --fs-13:16px; --fs-14:17px; } }
```

**Flat +1px per stop across all six tokens.** This lands the 12px token on exactly the mock's 12 → 13 → 14 → 15 ladder, stays integer at every stop, and compresses slightly at the top end (9px gains 33%, 14px gains 21%) — which is the right direction, since the small labels are the ones that are unreadable at 2560. The multiplicative alternative (×1.083 / ×1.167 / ×1.25) matches the mock equally well at 12px but produces fractional sizes at every other token; rejected for that.

**Explicitly out of scope, and named rather than dropped:** C2's clause about row padding and fixed-size glyph strips stepping at the same breakpoints. Type first. Once the ladder is live you can see which paddings actually need it, instead of guessing — that's a follow-on item, and the backlog should get it.

**Known, bounded consequence, stated so it isn't filed later as a bug:** the 114 one-off sizes stay fixed while the six scale. At 2400 a 20px heading sits over 15px body instead of over 12px body, so the type hierarchy compresses at wide widths. Not broken, but real. Same follow-on item.

**Gate — this is where coverage actually becomes falsifiable.**

1. **Re-run the computed walk at 2560**, same script as C1 step 4. Every element's `fontSize` must land in the scaled set `{12,13,14,15,16,17}` or on the documented one-off list. **Anything still reading 9/10/11/12px unscaled and not on that list is a missed site.** This is the instrument that reads differently depending on whether the work happened — at identity nothing could distinguish a substituted site from a skipped one; under the ladder they diverge by design. Report the count and the selectors.
2. `npm run build`.
3. Eyeball `/`, `/bills`, `/members`, `/hearings`, `/lobbying`, `/bill/119-s-2` at **1440** (indistinguishable from pre-arc) and **2560** (visibly larger, no overflow, no new wrap). `/welcome` too — C1 brought the landing module into scope and it's the one surface no route crawl checks against a signed-out visitor. Note anything that overflows rather than fixing it.

`feat(type): HO 604 C2 — the viewport type ladder (1600/2000/2400)`

---

## 6. Guards

1. **Three commits, never mixed.** C0 docs, C1 refactor, C2 feature. Explicit pathspec on each.
2. **Type only.** No structural edits — no `app/page.tsx`, no component JSX, no layout, no color, no padding. If a substitution seems to want a structural fix, note it and move on.
3. **`npm run typecheck` before every push.** Ancestry eyeball (`git log --oneline @{u}..HEAD`) immediately before. Fast-forward only.
4. **The C1 identity gate is not optional.** If the computed-size diff shows any difference, stop and report it — do not proceed to C2 on top of an unexplained delta.
5. **Not today, and not to be pulled in:** the layout audit script (HO 605, and it should be named for the HO that builds it — `docs/backlog.md:130` names `layout-audit-591.ts`, which is now a wrong name that the audit HO's sweep should correct), the dashboard rework (C1/C3/C4/C7), the padding and glyph half of C2, and Absence Watch.
6. **HALT after C2.** Report: the residual grep result, the computed-diff result, the substitution counts per file, the one-off size distribution that got left behind, and anything the 2560 eyeball turned up.

---

## 7. What to report back

- The residual grep **both times** — 714 before, 0 after, per file. A before-count that isn't 714 means the grep is pointed wrong and nothing downstream of it can be trusted.
- The C1 computed-size diff: zero, or the exact deltas (breakage only — not coverage).
- The C2 walk at 2560: count of elements still reading an unscaled size and not on the one-off list. **This is the coverage number.**
- The leftover distribution (one-offs + the 35 inline `fontSize`), so the follow-on pass is scoped on a number.
- 2560 eyeball findings per route, noted not fixed.
- Whether anything in `/welcome` broke — it's the surface with the least coverage and it just entered scope.
