# HO 643 — doc sweep of HO 642

**Ground truth:** `origin/main` at `058b5ef`. Eight HO 642 commits (four build, one coupling fix, three probe). Roadmap's latest pointer reads **641**, so this sweep is **643** and it is what moves the pointer.

**Delivery: review ref.** Push to `refs/heads/643-review`, do not touch `main`. The roadmap block is append-only — a wrong clause is permanent and correctable only by a later block — and SKILL.md edits ride the self-mod guard. Both need the reviewer to read the real text, and chat relay swallows diffs in this direction. Force-with-lease on the review ref to amend is fine; `main` only ever fast-forwards.

Three commits on the ref, in this order. Docs never ride with code; SKILL never rides with anything else.

---

## Commit 1 — `docs(HO 643): the 642 arc, and four rulings taken on measurement`

`docs/roadmap.md`. **Append a new block with its own frozen pointer.** Do not retro-edit 641's block, its clauses or its pointer. Each distinct HO N appears exactly once, monotonic.

The block covers HO 642 and 643. What it has to carry:

**The build.** Polarization chip cut from `/` (ideology is `/members` only; the query stays, `/` no longer reads it). Breaking-hover cross-column dim and overlay drop-shadow both removed — the opaque fill and 1px border carry the overlay alone, verified at a 351px overrun. `.v2f-title` was never bold: computed weight 400, the perceived weight was `--text-primary` contrast, fixed by stepping to `--text-secondary`. `.abw-name` moved to `var(--sans)` at 500 — it was an unfamilied 600 inheriting `--font-mono`, asking a face for a weight it doesn't ship and getting synthesis. Record that mechanism as **unfalsified hypothesis**, not finding: the fix is correct on every platform regardless, and the falsification is the owner's eye.

**`PER_CHAMBER` 2 → 3.** `.race-grid` is `auto-fit minmax(400px)`, which resolves to 1 / 2 / 3 columns at 1440 / 1920 / 2560; 6 divides all three, 4 divides none of them. Record the measured `.dash-left` widths (756 / 1020 / 1372) and that the orphan was a ≥~2350px phenomenon — the handoff stated ~1370px as the general case when it was the 2560 reading alone. Record the unpriced cost: at 1440 the grid is one column, so six cards add ~500px of height at a width that never had an orphan.

**Chamber selector.** `FeedFilters.chamber` and `buildFeedWhere` already carried it; only `getNewBillsThisWeek` / `getNewBillsThisWeekCount` needed signatures, and they move in lockstep by their own comment. The load-bearing correction: `getStageChangesCount` computes `total` from `buildChangesWhere({}, days, dashboard)` — it **drops its own `filters` argument by construction**, so a chamber can never reach `.total`. Both call sites read `.filtered`. Verified by exact partition (335 → 116/219, 173 → 44/129).

**The count coupling, closed.** `remaining` was pinned at the corpus value 305 under an active topic filter while the badge above it read 57 — pinned, not imprecise. Passing `filters` to the count makes it exact and costs nothing (same cache key the page already uses). Zero branch fired: `[ VIEW ALL CHANGES → ]`, not `+ 0`.

**R1 — `challenger.kind === "empty"` renders a finding it has never earned.** M4 measured 0 true-empty against 129 unknown-as-fact across 186 rated seats. `/electoral`'s `RaceMapCard` already renders the same state correctly as an absence. Two surfaces, one state, two contradicting claims, and the hedged one was never questioned. **The fix is authorised and takes the number this sweep establishes.** Record its shape: the caller distinguishes on roster length, so `empty` splits into *roster absent → hedge* and *roster present, uncontested → the finding*. Record that the second branch has **zero members in the live corpus** and therefore must be hand-fired on HEAD before it is ever recorded as working — scratch only, never a checkout of pre-fix files, confirm it fires, revert, `git status` clean, commit nothing.

**R2 — the harvest is scoped separately and the render fix does not wait for it.** `backfill:race-challengers` reach stops at `primary_date` 2026-06-02 while winners exist through 2026-08-06; sentinel rows at 82/53 seats match SKILL's first-run figure exactly, so it has effectively never advanced, and the rated set growing 137 → 186 is a second contributor. Of the 129, only **62 are derivable** — running it closes under half the class and leaves the lie standing on 67. Record the earlier "hasn't run since 2026-08-04" as **corrected**: it was an inference, the measurement is two months, and `race_candidates` has no `updated_at` so the bracket is behavioural (newest reached vs newest reachable), which is stronger than a timestamp.

**R3 — the HO 639 detector is not built.** M3 = 88 of 186 contradiction exhibits. An alarm firing on 47% of the rated set reads the staleness, not the defect it was conceived for, and calibrating it against a stale harvest bakes that staleness into the baseline. **Trigger for revisiting: re-measure M3 after the harvest is current.** Build only if it collapses to the ME-shape handful.

**R4 — at-risk lower bound is W = 8**, by the rule fixed before the numbers existed: smallest W in [6,20] with pooled max ≤ 6 and median ≥ 1. Record the plateau as the real finding — pooled max sits at 5 for every W from 8 to 20 while distinct members drain 24 → 7, because the peak is set by ~5 persistent long House absences no bound in range excludes. Raising W buys no peak reduction, only thins transient traffic. **WATCH:** selected on a window whose House newest roll is 20 days old and lies entirely pre-recess. Re-read after the House returns, alongside the still-open S=30 review. The tier itself remains unbuilt and belongs to the deferred MIA redesign.

**R5 — scope, stated so a later reader can't over-read it.** 129 is population-at-risk. The string lives in `RaceCard`, which renders only the dashboard's featured seats: **1 of 6 prints it today**. PA-10 is clean — one hand-curated Ballotpedia row that the harvest's `NOT EXISTS` guard correctly skips, the HO 213 seed-safe guard working.

**What 642 refused.** The at-risk tier was not declined off the one-cursor snapshot; the ceiling of 6 was not moved to fit a W; the harvest was not run to make an exhibit go green before the class was measured. Each refusal names what would have closed the question prematurely.

**Verify before pushing:** `git diff --numstat HEAD~1 HEAD -- docs/roadmap.md` shows **0 in the deletions column**. That is the ruled instrument and the only one that survived both HO 639–641 failure modes. Do not use `grep -c '^-[^-]'` (a deleted `- **bullet**` diffs to `-- **bullet**` and the class excludes it — both Claude and Code reported that zero as verification). Do not diff against `git show HEAD:file` (core.autocrlf is true with no .gitattributes; an LF blob against a CRLF worktree reports every line changed).

---

## Commit 2 — `docs(HO 643): four instrument failures from the 642 arc`

`docs/oddities.md`. **Entries are APPENDED AT THE END** — the file header says so and the in-repo convention wins over any memory or spec claim about ordering.

Four instances, but **name the family once rather than filing four unconnected entries**. Three of them are the same failure: an instrument that reads a proxy for the thing instead of the thing.

1. **An index is not a clock.** Two time series pooled by array position when their index 0 were 16 days apart (house cursor 0 = 2026-07-23, senate = 2026-08-08). It moved the headline: median 3 / max 7 by index against 4 / 9 by date. Same family as the `race_id` runoff-key misread — a field that looks like the axis you want and isn't.
2. **Element rect is not rendered ink.** Battlefield label collision measured on `.cm-lbl` bounding boxes reported five overlaps at 1440; the boxes are wider than their glyphs and centred on the dot. Re-measured by ink span it was clean (gaps 51/35/35/33/30px), and the screenshot agreed.
3. **`grep -c '^-[^-]'` is not a deletion count** — carried forward from 639–641 if not already filed, since it belongs with 1 and 2.
4. **A verdict string that doesn't read its own numbers.** A canned line printed "sits empty at the median" under a median of 4. Distinct from 1–3: the computation was right and the sentence was wrong, which is the half no assertion covers. Same-as-success, in the reporting layer.

Also file the sampling lesson, which is not an instrument failure but a design one: **occupancy of a transient state is not measurable from one sample.** The snapshot wrote "any WARN in 5..29 selects zero" from a single cursor; the replay refuted it outright (median 4, 31 distinct). Members transit the band en route to MIA, so one cursor lands between crossings and reports a permanently-empty band that is routinely occupied. Note the structural fix that followed — `occupancyFor(W)` is one function serving both the display band and every sweep rung, so the pooling cannot drift between them.

`docs/backlog.md`, same commit. Four lines:

- The **`--numstat` diff instrument** clause owed from the 639–641 arc. This is its ride.
- **Harvest currency** (R2): 62 derivable / 67 underivable, reach stops 2026-06-02, sentinel rows 82/53. Needs its own scoping; not a run-it chore.
- **M3 re-measure** (R3) as the detector's build trigger.
- **Display orphans:** `.home-grid:has(.breaking-row:hover) .home-col-right` joins the existing `DashboardTopicTreemap` / `V2FeedList` chore. Dead by grep, not by verified deletion — file it as a claim.

---

## Commit 3 — `docs(HO 643): rated set is 186, not 137`

`.claude/skills/cbt/SKILL.md`, alone, behind the self-mod guard.

The rated set is stated as **"137 races / 44 states" in two places**. Measured: 186. Correct both, and state the measured date beside the number so the next reader knows what it's a reading of rather than treating it as a constant. The 61-vs-137 predicate warning stays — it is right in kind and only the figure aged.

Note in the commit message that this is the measured-number rule applied to the document that carries the rule.

---

## Close

Push all three to `refs/heads/643-review` and report the ref SHA. Do not fast-forward `main` — I read the diff from the repo first. Ground-truth check is `git ls-remote --heads origin`, not the pasted transcript.

`npm run typecheck` before pushing even though this is docs-only; the review ref builds as a Vercel preview and a red build on a docs commit is noise worth not creating.
