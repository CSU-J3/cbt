# HO 618 — P6a: `/stale`, the age-heat fix at source, and `/changes` closes by verification.

HEAD `cd8c3d7`. Pointer "run through HO 615." **Next free is 618.** P6a's premise is replaced by the HO 617 remainder table: this is a **C1 + C3** HO (`/stale` M1 47, M3 13.58 against a 2–5 norm, ~223px real M4), and `/changes` is already M1-clean at M3 3.00 — it closes by verification, not by work. Sweeps wait for the arc close; interim M4 reporting uses the hand-split furniture/non-furniture columns from 617.

## 1. Commit 1 — `/stale` C1: the 47

Decompose from the artifact first. The standing note (613) says the momentum-overlay rows; expected shape is one component's rows plus whatever headers ride them, but expected is not measured. Kit as law. One live question the decomposition may raise: if the momentum overlay renders **per-row bars on a shared origin**, that's the registry question — clause 1 by inspection (magnitude or sequence? the ideology/v2f pair is the precedent for how the same method splits), clause 2 by an **applied** curve, and the verdict is the curve's, not the pattern's. If they're glyphs or text, it's a pack.

Score: `--route stale` M1 47 → ~0 decomposed (accepted-residue and exemptions in permitted forms only).

`fix(stale): HO 618 — the momentum rows resolved by decomposition (C1; curve if an axis, pack if not)`

## 2. Commit 2 — `/stale` C3, and the age heat dies at source

M3 13.58 means ~13 own-styled descendants per row against the arc's 2–5 norm. The quiet pass, same moves as 609's reference row: labels to plain dim text, borders only on interactive affordances, one bright element, stage/state colors staying because they're meaning.

**The ruling that reaches past this route:** `daysSinceColor` (`BillRow.tsx:17–26`) paints staleness with `--party-republican` — the oddity filed at 610, forbidden by the SKILL party rule since, and live on `/stale` and `/bills`. **It dies at source, in `BillRow`, this commit.** Staleness renders dim; the number carries the information, and on the route whose premise *is* staleness, per-row red is alarm-shaped noise. `/bills` inherits the fix — labeled as shared-component drift, expected, and its M3 should tick down with it. If anything else consumes the helper, the grep says so before the edit.

Score: `--route stale` M3 13.58 → ≤5 with the surviving set named (the members precedent: hitting 2 would mean something functional got deleted). `--route bills` M3 delta labeled.

`fix(stale): HO 618 — the quiet pass; party-red age heat dies at source in BillRow (C3; the 610 oddity closes)`

## 3. `/changes` — verify-close, no commit

Confirm at HEAD: M1 0, M3 ~3.00, M4 non-furniture ~123px, fixture legs green, one eyeball at 1440/2560. Disposition: **worked to zero by shared-component inheritance** (the 613 BillRow pack), stated in exactly those words — the phase's standing evidence that C1 was a convention defect, closing the route that proved it.

## 4. P6a closes by its scope list

Two routes, the table, permitted dispositions. Also print the updated remainder table for P6b (its scope list, refreshed by this HO's own movement — commit 2 will move `/bills`' M3, and the furniture split rides along).

## 5. Verification and guards

1. Two commits in order (§1 then §2 — the C1 decomposition first, so the quiet pass isn't scored through unpacked rows), typecheck + build each, explicit pathspecs; fixture legs before any zero.
2. Spot-unmoved: `/`, `/members` 13, `/trades` 1, `/committee-detail` 0. `/bills`' movement is expected and labeled (§2).
3. Narrow buckets for `/stale` at 1024/900/720, (a)/(b)/scroll-cited.
4. Any marking: applied curve, both units, registry queue, site M1x arithmetic restated (currently 314).
5. Eyeball 1440/2560: `/stale` rows quiet with momentum still readable, a very stale bill and a barely stale one (the heat's absence must not flatten the page's premise — the days number and sort order carry it), `/bills` one row spot-checked.
6. Prod-verify converged. **HALT** with both scope rows, the decompositions, the curve if one fired, and the refreshed P6b table. No P6b work, no rail decision, no sweep.
7. Absence Watch untouched. `--fs` tokens 9–14px.
