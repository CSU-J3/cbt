# HO 471 — doc sweep: the race→news NEW-badge arc (HO 470 / 432)

Docs-only. No code changes in this handoff (one code landmine is **flagged, not fixed** — see §5). Work spec-driven: propose the plan, show diffs, **no auto-commit**. The SKILL.md self-mod guard applies — show me that diff explicitly before committing.

Re-grep every line anchor below; they drift. Four files: `docs/roadmap.md`, `docs/backlog.md`, `docs/oddities.md`, `.claude/skills/cbt/SKILL.md`.

## Context (what shipped)

Commit `35bf8d5` — `feat(races): race→news — light the RACES-tab NEW badge + classic popover news (HO 432)` — landed on main. The story to record: a parallel session had built the complete implementation from an earlier "badge + drawer" handoff (HO 432) and left it **uncommitted**; the HO 470 session (a fresh badge-only respec) found it, verified it clean (7cbcd37 ancestor of HEAD, diff additive over HO 466/467, tsc/build green, CDP-eyeballed), shipped it, and dropped HO 470's own redundant spec. The badge is lit; race-news-in-the-popover shipped **classic-only** (variant reality, §4). No theme-% change.

## 1. `docs/roadmap.md` — append the Also block + bump the pointer

The current pointer is `**Also notes now run through HO 468.**` (end of the "Also (HO 466–468)" chip-family block). Append a new block after it, and change that pointer to `**Also notes now run through HO 470.**`

Block to add (adapt wording to house style if you tighten it, but keep every load-bearing fact — provenance, variant reality, no-new-query, the finding, no theme-% change):

> **Also (HO 470 / 432), race→news on the dashboard — the NEW badge lit, no theme-% change.** The HO 272 RACES-tab `NEW` badge (wired but dark since the news→race join was absent) is now live off the HO 394 observation layer. Provenance twist worth recording: the feature **shipped as commit `35bf8d5`, git-labeled HO 432** — a parallel session had built the complete implementation from an earlier "badge + drawer" handoff (HO 432) and left it **uncommitted** in the tree; the HO 470 session (a fresh badge-only respec) found it, verified it clean (`7cbcd37` is an ancestor of HEAD, diff purely additive over HO 466/467, tsc/build green), shipped it, then **dropped HO 470's own redundant spec** (a local gitignored file, just `rm`'d). **What lit:** `RacesBoxTabs` gained a `newsSet` registry beside `movedSet` (`newCount = newsSet.size`, replacing the hardcoded `0`); a per-card `RaceNewIndicator` (mirror of `RaceMovedIndicator`) registers when its latest-news date postdates the browser's `cbt:racesLastView` stamp, rendering a red `.rc-new` NEWS pip; opening RACES stamps `now` and clears both badges. **No new query** — the badge reads the existing **`getRaceNews(incumbent, 3)`** (threaded via `hubs[i].news[0].observedAt`), so the HO 414 "fold `getRaceNews`+`getMemberNews` into `getObservationNews` on the 3rd consumer" debt **stays deferred** (this adds callers, not a third projection). **The variant reality (corrects a premise stale across BOTH handoffs):** live `/` renders `<CompetitiveRacesBlock variant="v2" />` — whole-`<Link>` `RaceCard`s with **no popover** — so HO 432's second half (race news in the competitive **popover**: `RaceHubBody preview` + a hover-bridge) renders **only on the default variant = `/dashboard-classic`** (the sunset route), **not** the live dashboard. So the live dashboard's race→news is the **NEW badge only**; the news content lives on the `/race/[id]` hub (HO 398) every card links to. Both HO 432's author and the executing session had asserted "the dashboard has a race-news popover" by reading the popover branch in `CompetitiveRacesStrip` without checking the variant the caller passes — recorded in oddities. **The finding:** at ship, **3 of 4 featured incumbents carry ≥1 person-observation** (Ossoff / Collins / Kean; Nunn 0) → the badge lights **"New 3"** today; CDP-verified the pips + badge render and clear on RACES open (NJ-07 co-renders MOVED+NEWS, IA-03 correctly bare). **This discharges the QUEUED "HO 272 NEW badge + race→news drawer" item in full** — badge lit; the "drawer" resolved as a scope finding (no live drawer exists; popover-news shipped on classic); non-incumbent challengers stay unjoinable (no bioguide — the expected HO 398 coverage edge). **No theme-% change — Races held at 99** (a within-theme dashboard signal, matching the HO 398/414 race/member→news v1s). Docs: HO 471. **Also notes now run through HO 470.**

Note on the number: the block is titled **HO 470 / 432** and the pointer moves to **470** (the session that shipped it); the git commit is labeled 432 (the origin handoff). The prose reconciles all three entry points (470, 432, `35bf8d5`) so archaeology from any of them lands here. No STATUS-block theme-% edit.

## 2. `docs/backlog.md` — close two items + add a DONE tombstone

**Strike the QUEUED item (currently ~line 62)** — `**member→news DONE (HO 414); residual: the HO 272 NEW badge + race→news drawer/challengers.**` Wrap its header in `~~…~~` and prepend a close line:

> `~~**member→news DONE (HO 414); residual: the HO 272 NEW badge + race→news drawer/challengers.**~~` — **CLOSED HO 470/432** (`35bf8d5`). The two residuals are discharged: the HO 272 `NEW` badge is **lit** (`newsSet` registry + `RaceNewIndicator` off `getRaceNews(incumbent, 3)`), and "race→news drawer" resolved as a **scope finding** — the live v2 dashboard has no drawer (whole-`<Link>` cards); the popover-news half shipped on `/dashboard-classic` (default variant, sunset) only. Non-incumbent challengers stay unjoinable (no bioguide — expected HO 398 edge). See DONE → HO 470/432 + oddities (variant mis-read).

**Strike the BANKED pointer (currently ~line 110)** — `~~**race→news linkage arc**~~ — **UNBLOCKED, promoted to QUEUED (HO 394).**` Append to its close: `**Now fully CLOSED at HO 470/432** — the promoted QUEUED item shipped (badge lit; popover-news classic-only). See DONE → HO 470/432.`

**Add to DONE** (top of the DONE section, matching the existing tombstone format):

> `- ~~**HO 272 NEW badge + race→news dashboard surface (HO 432 / 470)**~~` — **SHIPPED `35bf8d5`** (git-labeled HO 432; landed a parallel session's uncommitted HO 432 build — found, verified clean [`7cbcd37` ancestor of HEAD, additive over HO 466/467, tsc/build green, CDP-eyeballed], and shipped by the HO 470 session, which then dropped its own redundant spec, a gitignored `rm`). The dark HO 272 RACES-tab `NEW` badge is **lit**: `newsSet` registry in `RacesBoxTabs` (`newCount = newsSet.size`) + a per-card `RaceNewIndicator` (mirror of `RaceMovedIndicator`) off the browser `cbt:racesLastView` stamp, red `.rc-new` pip. **No new query** — reads the existing `getRaceNews(incumbent, 3)` via `hubs[i].news[0].observedAt`, so the HO 414 3rd-consumer `getObservationNews` fold stays deferred. Race news also renders in the competitive **popover** (`RaceHubBody preview` + a `.competitive-race-popover::before` hover-bridge) — but that's the **default variant = `/dashboard-classic`** (sunset) only; live `/` is `variant="v2"` (whole-`<Link>` cards, no popover), so the live dashboard's race→news is the **badge only** (content on the `/race/[id]` hub). Coverage at ship: 3/4 featured incumbents have observations → "New 3", CDP-verified (NJ-07 MOVED+NEWS, IA-03 bare). **Closes the QUEUED "NEW badge + race→news drawer" item in full.** Variant mis-read recorded in oddities. See roadmap "Also (HO 470 / 432)". Docs: HO 471.

## 3. `docs/oddities.md` — the variant mis-read entry

Append a new entry (match the `## Title (HO, date)` header format of the recent entries):

> **## The dashboard competitive popover renders only on the default variant, not live `/` (v2) (HO 470 / 432, Jul 2026)**
>
> `CompetitiveRacesStrip` has two render branches: `variant === "v2"` renders the whole-`<Link>` `RaceCard` (no popover); the default (else) branch renders the `.competitive-race-cell` hover **popover** (`RaceHubBody preview`). Live `/` passes `variant="v2"` (`app/page.tsx:123`), and the **only** route that reaches the default popover branch is `/dashboard-classic` (`app/dashboard-classic/page.tsx:97`, the sole `<CompetitiveRacesBlock />` with no variant) — the sunset route. So anything added to that popover (e.g. HO 432's race-news "IN THE PRESS" block + hover-bridge) ships on **classic only**, invisible on the live dashboard.
>
> Both HO 432's author and the HO 470 executing session independently asserted "the dashboard has a race-news popover to extend" by grepping the popover branch **without checking which variant the caller passes** — a stale premise that survived two handoffs (HO 470's own "no live drawer" read was correct but stated too flatly, which made the disagreement look real). **Lesson: `CompetitiveRacesStrip` branches on `variant`; confirm the caller's variant (`app/page.tsx` = v2, `/dashboard-classic` = default) before reasoning about which card/popover renders.** Landmine that will re-trigger this: the comment at `CompetitiveRacesStrip.tsx:69` still reads "`/` keeps the default variant" — **stale since the HO 311 v2→`/` swap**; fix on next touch of that file (a code change, deliberately not folded into this doc sweep).

## 4. `.claude/skills/cbt/SKILL.md` — the update-badge idiom + the variant note

Add to the **Race surface** section (`## Race surface`, ~line 1739) a compact note (re-grep the exact insertion point):

> **RACES-tab update badges (HO 272 MOVES / HO 432 NEW).** `RacesBoxTabs` provides `RacesUpdatesContext`: a `localStorage["cbt:racesLastView"]` timestamp + two registries (`movedSet` / `newsSet`). Each featured `RaceCard` renders a per-card indicator — `RaceMovedIndicator` (latest rating-move date) and `RaceNewIndicator` (latest news date) — that **registers itself when its date postdates the last-view stamp**; the tab badge count is literally the registry size (`movesCount` / `newsCount`), and opening the RACES tab stamps `now`, flipping every indicator false so both badges clear. Hydration-safe: `lastViewMs` is null until the localStorage read, so SSR and first client render show no badges. NEW pip = `.rc-new` (red `--ticker-closed`, matching the tab `.rbx-badge-new` — deliberately not a party red). **The NEW badge adds NO query** — it reads the existing `getRaceNews(incumbent, 3)` (fetched into the hub prefetch, latest date via `hubs[i].news[0].observedAt`), so the HO 414 "fold into `getObservationNews` on the 3rd consumer" debt stays deferred (this adds callers, not a third `RaceNewsItem` projection).
>
> **Variant reality:** the race-news **popover** (`RaceHubBody preview`, HO 432) renders only on the **default** `CompetitiveRacesStrip` variant = `/dashboard-classic` (sunset). Live `/` is `variant="v2"` — whole-`<Link>` `RaceCard`s, no popover — so the live dashboard's race→news signal is the **NEW badge only**; content lives on the `/race/[id]` hub. (See oddities: don't reason about which card/popover renders without checking the caller's variant.)

If `getRaceNews` appears in the **Query helpers** registry (`### Query helpers`, ~line 1039), add its new consumers (the dashboard popover + the NEW badge, both `race-news`-tagged); if it isn't listed there, skip — don't add a new registry entry for it.

## 5. Do NOT touch code

This is a docs sweep. The stale `CompetitiveRacesStrip.tsx:69` comment ("`/` keeps the default variant") is **flagged in oddities/backlog for a fix on next touch**, not fixed here — code changes stay separate from doc sweeps.

## Commit

One docs-only commit, explicit pathspec:

```
git add docs/roadmap.md docs/backlog.md docs/oddities.md .claude/skills/cbt/SKILL.md
```

Show me all four diffs — the SKILL.md diff explicitly, per the self-mod guard — and wait for approval before committing. Suggested message:

```
docs(sweep): record the race→news NEW-badge arc + the variant mis-read (HO 471)

Roadmap "Also (HO 470 / 432)" + pointer → 470; backlog closes the QUEUED
"NEW badge + race→news drawer" item and the BANKED linkage-arc pointer, adds a
DONE tombstone; SKILL gets the RACES-tab update-badge idiom + the v2-vs-default
popover-variant note; oddities records the two-handoff variant mis-read.
No theme-% change (Races held at 99).
```

Before pushing: ancestry eyeball (one commit riding, clean fast-forward, no concurrent-session files touched). This closes the arc — HO 470/432 shipped, docs reconciled through HO 470.
