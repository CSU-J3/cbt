# HO 629 — the bills column boundary moves left: 31% → 45%, owner ruling

Main is `97eed89` plus HO 628's landing; run 628's close first if it hasn't landed, and take its hairline as present in this HO's screenshots. This is **629**.

## The ask

Owner ruling: the column widens, 31% → **45%**. The value was chosen off the interactive mock (`mock-629-bills-boundary.html`, candidate set 31/36/40/42/45 with a live fraction knob) — not estimated from stills. Not a side flip; the J-revision arrangement (bills full-height on the right) stands.

The screenshot evidence at ~2560: four movers titles truncate at today's ~794px while the left region carries surplus width.

## Why this is inside C8, not an exemption

C8 (SKILL:1829) caps **rows**: past ~900px a row of text gains nothing, "it just pushes its right-hand element further away, which is C1 again." Two facts break that mechanism for this column:

1. The feed row has **no right-hand element** — HO 609 removed the pinned metric/caret columns and HO 627's glyph is leading. The title is packed-left, `nowrap` + `ellipsis`: every added pixel is a visible character until the title fits, and short titles end mid-row without opening a C1 gap (nothing is anchored past them).
2. The expanded panel answers C8's "wide screens buy columns" clause literally — wide mode is two panes (summary | metabox).

The CSS comment at globals.css ~752 claims an ~850px ceiling "past which a row of text buys nothing" — untested at 623 because both values sat under it, and false for a truncating row. Rewrite the comment: cite C8's actual scope (rows with right-anchored elements), the ellipsis argument, and this HO.

## Commit 1 — the boundary

globals.css line ~756:

```css
grid-template-columns: minmax(0, 1fr) minmax(480px, 45%);
```

Measured expectations (state actuals in the commit): **2560 → ~1150px** (from ~794, the boundary moves ~355px left), **1440 → ~648px** (45% binds; the 480 floor goes dormant above ~1067 and stays as-is). Left region: ~1350 at 2560, ~760 at 1440 — the two-up panels compress (roughly 800/540 and 450/300 at the 1.5fr/1fr split), the DISTRIBUTION side getting tight at the floor. That tightness was visible on the mock's knob and is part of what the ruling accepted; if a left panel actually *breaks* (overflow, wrap failure), HALT and report rather than patching it inside this HO.

**The fraction is the knob.** 45% is the ruled value; the owner can still tune it at HALT 1. Do not add a px cap — the ~850 number is retired with its comment.

## Derived check — the bxp flip boundary (HO 623's rule)

"A container-query threshold is derived from the container it was tuned against, so widening the container obliges you to re-derive the threshold." Current threshold: `@container bxp (max-width: 520px)` (globals.css ~4600). At 45% the ambiguity the 42% draft carried is gone: the panel's inner width at 1440 lands around **~588px** (column 648 minus chrome; 623 measured ~60px overhead at the old width — re-measure, don't reuse), comfortably past 520. Expectation: **wide mode everywhere the two-column grid is active down to ~1290**, stacked only in the narrow band below that before the grid's own breakpoint takes over.

So: threshold stays 520. Verify by measurement — state the actual inner width at 1440 and the actual viewport where the mode flips in the commit. `/bills` is unaffected by construction (~1140px panel at 1440, per the 623 check) — confirm with one measurement, don't re-derive.

## HALT 1 — owner's eyes, both widths

Screenshots at 1440 and 2560: feed closed and scrolled mid-list, one open mid-feed group in wide mode, full page showing the new boundary. The ruled 45% should match what the mock showed; if live disagrees with the mock, the fraction tunes from here — one line, re-screenshot, no new HO.

## Guards

1. **Click gate re-runs, 16/16** — row geometry changed width; real clicks at target centers from a scrolled feed, both widths. The pinned HO 627 requirement.
2. Audit `--route home` at 2560: **M1 holds 0, M1x holds 30** (the topic-bar voids shrink proportionally with their tracks; the exemption's proportionality argument is width-invariant), M4-true 1 / 42px. Falsification leg per standing practice.
3. Nothing in the left region's components changes — compression is the grid doing its job.
4. No `--fs` changes, no new tokens. Typecheck + build per commit, explicit pathspecs, code and docs never mixed.

## Verification

Prod-verify by stylesheet on the deployed hash (the HO 212 trap): the served CSS carries `45%`. Then the screenshots.

## Close — `refs/heads/629-review`

Docs commit: roadmap block for HO 629, pointer → 629 — the owner ruling and that it was made off the live-knob mock, the C8 argument (rows-with-right-elements scope, the ellipsis conversion), the measured widths, the bxp check outcome. The mock itself is committed in the same docs commit as `docs/design/mock-629-bills-boundary.html` (the owner drops it there before the close) — it is the ruling's record, the house mock convention. Grep gates: "HO 629" ×1, previous block's pointer reads 1.

Housekeeping in the same session, separate from the docs commit: delete the stale `refs/heads/620-review` on origin — it should have gone at 620's landing.
