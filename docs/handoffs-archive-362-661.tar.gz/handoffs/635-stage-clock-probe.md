# HO 635 — `stage_changed_at` is an observation clock: read-only probe

HEAD `33e5910`. Pointer runs through HO 634. **Next free is 635.**

Promotes the WATCH opened at HO 634 (`docs/backlog.md`, `bills.stage_changed_at` records when the sync observed the advance). Read-only throughout. **No schema, no writes, no display change, no backfill.** Findings, then HALT.

---

## The reframe, and it is why this is worth a probe rather than a fix

HO 634 filed this against HO 632's day-grouping, because that is where it surfaced: MOVERS buckets TODAY / YESTERDAY / EARLIER THIS WEEK off `stage_changed_at`, so the feed groups by when the sync looked rather than when Congress acted. That framing understates the exposure by a lot.

The field has **11 production readers across `lib/` and `components/`**, and the grouping is the least consequential of them. The ones that matter:

- `lib/enacted-this-week.ts` — the dashboard's `0 ENACTED ▼3`, a headline figure with a week-over-week delta, windowed on `stage_changed_at`.
- `getStageChangesCount` — `243 STAGE TRANSITIONS ▲15`, same shape, and read at three sites on `/` (`WeeklyBand`, `page.tsx`, `ActivityTicker`).
- `lib/dashboard-lead.ts` — the LEAD story is *selected* on a `stage_changed_at` range.
- Stale detection — `stage_changed_at <= datetime('now','-7 days')`.
- `V2FeedList` / `StagePillStrip` / `BillExpandPanel` — every row's `→ FLOOR 3h` age.

**A count windowed on an observation clock counts observations.** So `243 STAGE TRANSITIONS ▲15` is transitions *we noticed* this week against transitions we noticed last week, and the delta partly measures sync behaviour rather than congressional behaviour. A sync outage produces a dip followed by a spike on the catch-up run, and both read on the dashboard as activity in Congress. Same for `ENACTED ▼3`. That is a P1 shape (wrong data shown), where the grouping is a P2, and neither was priced when the WATCH was filed.

Two things pull the other way and belong in the report, not in a footnote. The batch stamp is benign in origin: a sync run that picks up a week of referrals at once stamps them together, which is the correct behaviour of a field named for observation. And for a terminal answering "what's happening in Congress", "we learned this today" is a defensible thing to surface. **The defect is that a field named for occurrence is read as occurrence by eleven consumers, not that the field is wrong about what it records.**

---

## Step 0 — re-verify before measuring

The standing rule: a logged item is a claim. HO 634's evidence was 40 rows and two code reads. Confirm both still hold at `33e5910` before anything below.

- The two write sites: `lib/sync.ts:235` (`stageAdvanced ? new Date().toISOString() : null`) and `lib/summarize-runner.ts:314` (`new Date().toISOString()`). Confirm neither has a third sibling. Grep by function (a wall-clock stamp assigned to a stage field), not by variable name.
- One sanity read that HO 634 did not do: **are there rows where `stage_changed_at` PRECEDES `latest_action_date`?** If the field were occurrence-shaped anywhere, that is where it would show. Expect zero; a nonzero count is a finding that changes this probe's premise.

---

## M1 — consumer census, with each reader classified

Enumerate every production read (ignore `scripts/`, note them separately). For each: what it computes, and which of three classes it falls in.

- **(A) Order / recency** — sorting a feed, picking a lead, "most recent first". Observation time is arguably *correct* here: the newest thing we learned is a reasonable ordering for a terminal.
- **(B) Display age** — `→ FLOOR 3h`. Reads as how long ago the stage moved, and is wrong by the lag.
- **(C) Windowed count or delta** — `ENACTED ▼3`, `243 ▲15`, stale `> 7 days`. Wrong in a way that compounds, because the window boundary is an observation boundary.

The census is the deliverable, not a summary of it. **Class (C) is the priority order for whatever comes next**, and if it turns out (C) is one or two call sites rather than five, the whole item is much smaller than this handoff assumes. Report the true count either way.

---

## M2 — how wrong is it, against the right anchor

HO 634 measured lag against `latest_action_date`, which is the date of the *most recent* action, not the action that caused the advance. A bill that moved to committee on the 8th and picked up a cosponsor on the 9th has a `latest_action_date` of the 9th, so the existing median of 3.76 days is an approximation of the wrong quantity.

Measure against the **stage-advancing action**: for a sample of rows with a non-null `stage_changed_at`, find the action in the bill's own actions that caused the stage to reach its current value (`computeStage`'s own predicate is the authority — use it, do not re-implement it), and take that action's date as the occurrence date.

Report: lag distribution (min / median / p90 / max, n), the share of rows where lag ≥ 1 calendar day in ET, and the share where the ET calendar day differs. That last figure is the one that decides whether the day-grouping is visibly wrong or merely wrong in principle. HO 632 measured 17% of MOVERS rows landing on a different day under UTC-vs-ET bucketing, which is the comparable number and the bar this should be read against.

**Stratify by write site if you can tell them apart.** The sync path and the summarize-runner path may have different lag profiles, and if one is tight and the other is loose, that changes the fix.

---

## M3 — is an occurrence date recoverable, and for how much of the corpus

M2 answers this for a sample. M3 asks whether it generalises.

- What share of rows with a non-null `stage_changed_at` have an identifiable stage-advancing action? Anything that can't be resolved is a row no backfill can reach.
- Note the shape of the unresolvable set rather than just its size: is it the 14k legacy NULL cohort `StagePillStrip` already documents, is it concentrated in one stage, is it old?
- **`stage_transitions`** — HO 239 built it, HO 383 wired sync-side logging. Does it hold a better timestamp than `bills.stage_changed_at`, or the same wall clock? If it already carries occurrence dates, most of this item collapses into a join. Check its actual columns rather than assuming from the name; history began 2026-05-11, so it cannot cover the corpus regardless.

---

## M4 — the counts, computed both ways

The measurement that prices the P1. For the current week and the three prior:

- `ENACTED THIS WEEK` and its WoW delta, by observation clock (as shipped) and by occurrence date.
- `STAGE TRANSITIONS` and its WoW delta, the same pair.

Report the four pairs side by side. **A large divergence in the delta with a small divergence in the level is the worst case and the one to look for**, because the level is a number nobody checks and the delta is the number the strip exists to show.

If a sync gap is visible in `cron_runs` over that span, say so and note whether it lines up with a spike. A catch-up run reading as congressional activity would be this defect arriving on the dashboard, and it is the difference between a principled complaint and a demonstrated one.

---

## Output — GO / NO-GO with dispositions costed, then HALT

Close with a recommendation in one of three forms, each with what M1–M4 say it costs:

1. **Leave it, document it.** Defensible if class (C) is small and M4's divergence is negligible. The cost is that eleven consumers keep reading a field whose name misleads, so this disposition ships a comment at both write sites and a SKILL clause, not silence.
2. **Rename, don't re-source.** `stage_observed_at`, so every reader confronts what it is getting. Cheap, touches no data, and fixes the class of defect (a field named for occurrence read as occurrence) without fixing any instance. M1's class (C) then reads as a deliberate choice rather than an unexamined one.
3. **Add an occurrence column** and move class (C) onto it, leaving (A) and possibly (B) on the observation clock. This is the real fix and the expensive one: a migration, a backfill bounded by M3's recoverable share, a second field for every writer to maintain, and a decision per consumer. Do not spec it here. Price it.

**Do not pick.** The counts are the owner's call once the numbers exist.

---

## Guards

1. **Read-only. No writes, no schema, no migration, no display change, no backfill.** If the probe wants to write anything, it has left scope.
2. Commit the probe to `scripts/diagnostic/stage-clock-635.ts` with a header comment naming what it measures and its date. Reuse HO 634's `634-artifacts/stage-clock-probe.ts` as a starting point rather than rewriting from scratch; it is repo-ignored, so the committed version is the one that survives.
3. **Use `computeStage`'s own predicate to identify the stage-advancing action.** Re-implementing it in the probe would measure the probe's opinion of the stage rather than the product's.
4. Turso reads are a live budget. This walks `bills` plus actions for a sample; **bound the sample and state its size**, and do not full-scan actions across the corpus to answer M3 when a stratified sample answers it.
5. Report figures with corpus size and date attached. The `getBillLobbying` undated-comment WATCH is the standing example of what happens otherwise.
6. Explicit pathspec staging. `npm run typecheck` before pushing. Docs and code never ride together.

## Ship report

M1's census with every reader classified A/B/C · M2's lag distribution against the stage-advancing action, stratified by write site · M3's recoverable share and the shape of what isn't, plus what `stage_transitions` actually holds · M4's four count pairs with any sync gap named · the GO/NO-GO with all three dispositions priced · anything else found, filed not fixed.
