# HO 525 — Career participation (B2): Voteview rollup + member-hub surface

The build, on the HO 524 GO. Stands up a career-participation rollup table from Voteview's per-Congress votes files and surfaces each current member's career missed-vote rate on the hub, alongside B1's 119th figure. All the probe's confirmed facts are baked below — don't re-derive them.

**Code build.** Touches `migrate.ts` (new table), a new sync script, a query helper, and the hub surface. Diff shown before commit; **no doc edits, no SKILL** (the roadmap/backlog/oddities/SKILL sweep + the Member-depth 99→100 accounting folds B1+B2 into one sweep after this lands).

## Baked from the HO 524 probe (facts — do not re-check)
- **Range: derive `min(congress)` per current icpsr from `HSall_members.csv`** (6.2MB, one fetch), floor there → `earliest`→119. Probe found earliest = **94** (Grassley); derive it live so it self-adjusts, don't hardcode.
- **Filenames zero-padded width 3:** `H094_votes.csv` (unpadded `H94` 404s), `H119_votes.csv`. Always pad to 3.
- **`cast_code` rule (the probe's correction — the {0,1–6,9} model was wrong):** **cast = 1–8** (7/8 = Present, folded in per the decision above), **miss = 9** (Not Voting), **exclude = 0** (not seated — rare; non-seated members usually have *no row* rather than a 0-row, so this is a guard, not the main path).
- **Cost:** 52 files, ~356MB, ~8s dl + ~8s parse, peak RSS ~130MB **flat** (accumulator is 536 members × a few ints; memory doesn't grow with range). Stream per-file, discard, next.
- **Coverage:** 536/537 current members carry an icpsr; the **1 without = G000608 Darline Graham** (new SC appointee, not yet in Voteview) → no rollup row → **graceful null on the hub** (same as B1's no-row case; no special-casing).
- **Keying:** icpsr→bioguide via `member_ideology`; store keyed by **bioguide**.

## §1 — Table (`migrate.ts`)
Add `member_career_votes`, keyed by bioguide:
```
bioguide_id       TEXT PRIMARY KEY
icpsr             INTEGER
career_eligible   INTEGER   -- Σ(cast 1–8 + miss 9) across served congresses
career_missed     INTEGER   -- Σ(code==9)
career_missed_pct REAL      -- career_missed / career_eligible
first_congress    INTEGER   -- min congress with any 1–9 row
congresses_served INTEGER   -- count of distinct congresses with a 1–9 row
synced_at         TEXT
```
No `career_present` column (folded into cast; add later only if a Present surface lands). Run `migrate` — additive `CREATE TABLE`, no data loss.

## §2 — Sync (`scripts/sync-career-votes.ts`, npm `sync:career-votes`)
Extend the `scripts/voteview-source.ts` CSV-over-HTTP fetch/parse pattern. Manual script — career rates move glacially and Voteview updates per-Congress, so **not a cron**; run on-demand.

1. Load current-member icpsr→bioguide map from `member_ideology` (536 rows; Graham excluded, no icpsr).
2. Fetch `HSall_members.csv`, filter to those icpsrs, derive `earliest = min(congress)`.
3. For `congress` in `earliest..119`, for each chamber, fetch `{H,S}{congress:03d}_votes.csv`, **stream-parse row-by-row** (a Congress's House file is ~280–550k rows — do not full-load), filter to the current-icpsr set, and accumulate per icpsr: `cast` (1–8), `miss` (9); track `first_congress` (min congress with a 1–9 row) and `congresses_served` (distinct congresses with a 1–9 row). Discard the file; next.
4. Compute `career_eligible = cast + miss`, `career_missed = miss`, `career_missed_pct`. **Truncate-then-insert** the whole table (full recompute from an API-reproducible source each run — the safe pattern for a list-only source-derived table; avoids the two-phase SET-clause staleness trap). Stamp `synced_at`.
5. Run it once to populate prod (the manual-sync-against-prod pattern, like `sync:ideology`). **Verify before wiring the surface:** cross-check a few members against GovTrack's published career missed-% — Grassley near-perfect (probe partial 1.2%), plus one high-miss and one mid to confirm both tails. Report the numbers.

## §3 — Surface (member hub)
Add a `getMemberCareerVotes(bioguideId)` cached point-lookup on the rollup, and render the career figure in the **hero stat block, next to B1's "Missed · 119th / …"** (same inline `mhp-stat` pattern, no new CSS):

- Show **career missed % + tenure context** — e.g. `Career / 6.4% · 15 Congresses` (read `career_missed_pct`, `congresses_served`; optionally `first_congress`→"since 'YY"). Tenure is the right companion for a lifetime stat (the 119th figure already carries the chamber-median good/bad read; a *career* chamber median is a cheap later follow-on from the rollup, not built here — avoids a 4-stat hero).
- **Label it "Career" clearly** so it never collides with the "119th" figure beside it.
- **Guard on row-exists** — members with no rollup row (Graham; any Voteview-missing) render no career stat, gracefully (same as B1).
- Delegate note: this is a member's **own displayed rate**, so no delegate carve-out (the banked constraint is for *rank* surfaces only — consistent with B1).

Read `/mnt/skills/public/frontend-design/SKILL.md` before touching styled elements (there shouldn't be any new ones — reuse B1's inline stat).

## Guardrails + deliverable
- **Diff shown before commit.** Explicit pathspec (migrate.ts + the sync script + queries.ts + the hub page — and confirm the untracked probe/design files stay untracked). Ancestry eyeball, fast-forward only. One code commit.
- Populate the table (run the sync) and **verify the cross-checks before the surface reads it live**; then ship + `verify:deploy`.
- **No doc edits, no SKILL** — the combined B1+B2 doc sweep (roadmap "Also" block + Member-depth accounting + backlog tombstones + oddities [the cast_code 7/8 Present catch is worth an oddities line] + SKILL schema/source note) is the **next HO after this**, once B2 is live.

read docs/handoffs/525-career-participation-build.md and follow it
