# HO 524 — Career participation (B2): Voteview ingest cost probe

Instrument-first step for the heavy cut. HO 522 GO'd the **source** (votes files live/no-auth, `cast_code` semantics, icpsr↔bioguide join solved) — but never parsed a file or measured the ingest. B2 stands up a **new rollup table from ~500MB across ~50 per-Congress files**, so per your convention it gets a cost probe before the build is spec'd. This HO answers the four remaining unknowns and returns a **GO + confirmed range/cost/shape**; the full sync + table + surface is **HO 525**, gated on this.

**READ-ONLY-ish:** downloads to `/tmp` and measures. **No DB writes, no new table, no commit.** Throwaway probe script (extend the `scripts/voteview-source.ts` CSV-over-HTTP pattern locally — don't commit the extension). Inert diagnostic → approved on summary.

## What's known (don't re-check)
Votes files at `voteview.com/static/data/out/votes/{H,S}{congress}_votes.csv`, no auth. `cast_code`: **9 = Not Voting (the miss)**, **1–6 = cast**, **0 = not seated → exclude from denominator**. Current-member icpsr lives in `member_ideology.icpsr` (one row per current member, congress 119) — also in `member_ids.icpsr` (the crosswalk). The 119th member file fetch/parse is already `fetchVoteview119()`.

## The four unknowns to settle

### 1 — Current-member icpsr coverage (who gets a career figure at all)
Pull the current-member icpsr set from `member_ideology.icpsr`. Report how many of the ~536 current members carry an icpsr (the probe said 100% — confirm) and **name any without one** — those get **no career figure** (graceful null, same as B1's no-row case). This is the denominator of "members B2 can actually surface."

### 2 — The Congress range (which files to pull)
`member_ideology` only has the 119th row, so it can't tell you how far back each member served. Fetch Voteview's **combined members file** (`HSall_members.csv` — small: one row per member-Congress, ~tens of thousands of rows total, not the huge votes matrix), filter to the current-member icpsrs, and take **`min(congress)` per icpsr → the earliest file to download**. Report the **earliest served Congress** across current members (likely ~93rd–97th for the longest servers — Grassley served in the House from the 94th) and therefore the **file range** = earliest → 119th, × 2 chambers. This is the input to the cost extrapolation.

### 3 — Ingest cost + accumulation correctness (the real risk)
Download **2 real votes files** to `/tmp`: the **119th** (H + S) and **one deep-historical** (the earliest from §2, or a known-old one where a current long-server appears). Then:
- Measure **download size + time per file**.
- **Stream-parse one file row-by-row** (do NOT full-load — a Congress's House file is ~437 members × ~645 rollcalls ≈ 280k rows), filter to the current-member icpsr set, accumulate **`cast_code==9` (miss)** vs **1–6 (cast)** vs **0 (excluded)**. Measure **parse time + peak memory**, and report rows-total vs rows-matching-current-icpsrs (the filter should shrink 280k → the handful of current members who served that Congress).
- **Confirm `cast_code` semantics on real rows** (that 9/1–6/0 mean what the probe said).
- **Extrapolate to the full range** (§2 file count × per-file size/time): report projected **total download MB + total parse seconds + peak memory**. This is the GO/NO-GO number — if it's tens of seconds and bounded memory, GO; if it's minutes+ or memory blows past a Vercel-safe envelope, flag it (a manual local sync has more headroom than a cron, but say so).

### 4 — Rollup shape + a known-value cross-check
Confirm the per-member rollup the build will store: **`career_eligible`** (Σ cast+miss across served Congresses), **`career_missed`** (Σ `cast_code==9`), **`career_missed_pct`**, **`first_congress`**, **`congresses_served`**, keyed by **bioguide** (join icpsr→bioguide via the member file / `member_ideology`). Then **sanity-check one long-server** against a published figure: from the 2 downloaded files compute a partial career miss-rate for, e.g., Grassley or another current long-tenure member, and confirm the direction/magnitude is plausible against **GovTrack's published career missed-%** for them (GovTrack showed the late Lindsey Graham at 6.4% career — pick a live long-server and eyeball the same stat once the range is assembled, or at minimum confirm the per-file accumulation is arithmetically sane on the 2 files).

## Deliverable → gates HO 525
A **GO/NO-GO** with: (1) icpsr coverage + the members-without list, (2) the confirmed earliest Congress + file range, (3) projected total download/parse/memory + the per-file measurements, (4) the confirmed rollup shape + the cross-check. On GO, HO 525 builds the full-range sync (incremental per-Congress, streaming) + the rollup table + the member-hub career stat (alongside B1's "119th" figure, clearly labeled career vs 119th — note the banked delegate-inflation constraint applies to any *rank*, not to a member's own displayed rate, so B2's own-rate display needs no delegate carve-out, consistent with B1).

**No DB writes, no commit, no doc edits.** Report back and I'll spec HO 525 from the numbers.

read docs/handoffs/524-career-votes-cost-probe.md and follow it
