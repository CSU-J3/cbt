# HO 474 — markets/kalshi cron migration: recon probe (read-only)

**Type:** read-only recon. No commits, no `vercel.json` / workflow / route edits, and **do not POST to any cron endpoint** — both `/api/cron/markets` and `/api/cron/kalshi` write on every hit, so the probe must stay read-only. Report findings inline; they become the cutover build HO.

**Goal:** the three GitHub-Actions market crons are moving to Vercel Pro (a reliability play, not a cadence change — HO 313 measured GitHub dropping ~20% of scheduled slots). I've already read the routes + workflows, so the design-critical questions are answered below. What's left is a handful of **live-environment** facts a static clone can't give me, plus the symbol enumeration for the exact `vercel.json` diff.

---

## Already established from the code — verify only if cheap, don't re-derive

**Three workflows / two routes:**

| workflow | schedule (UTC) | endpoint | writes |
|---|---|---|---|
| `markets-tick.yml` | `0,30 13-21 * * 1-5` | `POST /api/cron/markets?source=fmp` | FMP indices only (SPX/NDQ/DOW) |
| `markets-daily.yml` | `0 */4 * * *` | `POST /api/cron/markets` (bare) | full roster: FRED EOD (TNX/WTI) + FRED monthly (CPI/UNEMP) + macro tape ODDS (SHUTDOWN/FEDCUT/FEDCUT-SEP/RECESSION + POLY halves) |
| `kalshi-tick.yml` | `15 */2 * * *` | `POST /api/cron/kalshi` | per-seat race-card odds (a **different** dataset from the macro tape odds) |

All three: `curl -fsSL -X POST -H "Authorization: Bearer $CRON_SECRET"` against the canonical `congressional-terminal-chi-silk.vercel.app` host.

**Write shape — the double-write question, answered:**
- `/api/cron/markets` does a **plain `INSERT INTO market_ticks`** (one row/symbol/run, no `ON CONFLICT`). Overlap = **redundant history rows, not corruption** — the daily workflow comment calls the extra rows "harmless charting fuel," and the tape reads latest via `revalidateTag("markets")` / `getLatestMarketTicks`. A Vercel↔GitHub overlap window during cutover is **benign**, so ordering isn't fraught.
- `/api/cron/kalshi` does `INSERT ... ON CONFLICT(race_id) DO UPDATE` — **fully idempotent**, last-write-wins, zero bloat. Overlap totally safe.

**`?source=fmp` handling, answered:** the route reads `searchParams.get("source")` and filters `MARKET_SYMBOLS` by `s.source === source`; bare = all. Vercel cron `path` carries a query string fine, so `"/api/cron/markets?source=fmp"` is a valid cron entry.

**Auth, answered in shape:** both routes require `authorization === "Bearer " + CRON_SECRET` else 401. Vercel Cron auto-attaches exactly that header **iff `CRON_SECRET` is set in the Vercel project env** (the route comment says it's built to work for both). The only open auth question is the env check (#2 below).

---

## Live checks — the actual probe (report each)

1. **Does the `30 21` Vercel markets floor fire now on Pro?** `vercel.json` already carries `{ "/api/cron/markets", "30 21 * * *" }`. The `markets-daily.yml` comment says it was NOT firing, but that note (HO 362) predates the HO 433 Hobby→Pro move. Check `cron_runs` for a `/api/cron/markets` row at ~21:xx UTC over the last few days (and/or the Vercel dashboard Cron tab). **This shapes the diff:** if it fires, a daily bare full-roster run already exists on Vercel (partly overlapping GitHub markets-daily) and the build *reconciles*; if it's dead, the floor entry gets replaced wholesale.

2. **Is `CRON_SECRET` set in Vercel *Production* env?** (Corey — Vercel dashboard. Or infer it: are the existing `vercel.json` crons — `summarize` / `news` / `sync` — succeeding in `cron_runs`? Same auth class, so consistent success ⇒ Vercel is attaching the Bearer ⇒ markets/kalshi will authorize too.) This is the hard gate — no secret ⇒ Vercel crons 401 silently (green-looking, unauthorized). Same class as the open NextAuth `MissingSecret` gap; worth confirming both are actually in Vercel env while you're in there.

3. **`MARKET_SYMBOLS` split** (read `lib/markets.ts`): list every symbol by `source` and `cadence`. I need the exact `source` values (`fmp` / `fred` / the odds source[s]) and which are `cadence:"daily"` vs not, to write the precise cron split and the FRED-once-daily gate in the build.

4. **FRED re-fetch situation:** confirm the FRED symbols are the `source:"fred"` set, that the bare 4h run re-fetches them every tick (append, same-value redundant rows per the route comment), and that there's **no existing once-daily gate**. Report only — the gate is a build decision.

5. **`market_ticks` bloat / retention:** read-only `SELECT symbol, COUNT(*) n, MIN(ticked_at), MAX(ticked_at) FROM market_ticks GROUP BY symbol ORDER BY n DESC` plus total row count. Tells us how much redundant append has accumulated and whether the build should ride a retention/cleanup step. If scripted: `scripts/diagnostic/markets-cadence-474.ts`, read-only, committed alone — but inline output is fine.

---

## Deliverable (inline, no commit)

A short findings report I can turn into the cutover build HO:

1. `30 21` floor verdict (fires on Pro / dead) + the existing-crons-succeed auth proxy
2. `CRON_SECRET`-in-Vercel-env status (or the proxy inference)
3. `MARKET_SYMBOLS` by-source/cadence table
4. FRED re-fetch confirmation + no-gate
5. `market_ticks` bloat readout
6. a recommended cutover: the three `vercel.json` cron entries to add (tick `?source=fmp` at `0,30 13-21 * * 1-5`; full-roster bare at a cadence to pick; kalshi `15 */2 * * *`), how to fold/replace the `30 21` floor, the FRED-gate approach, and the workflow-retirement step — noting overlap is benign (append/upsert) so this is a clean single cutover, not a zero-gap dance. Flag which OPEN LOOPS it closes (the optional "Intraday-reliable markets upgrade" loop is exactly this move; "Markets watchdog" pairs with it).

**Constraints:** read-only; no edits to `vercel.json` / workflows / routes; do not POST any cron endpoint. Any diagnostic script is read-only and committed alone.
