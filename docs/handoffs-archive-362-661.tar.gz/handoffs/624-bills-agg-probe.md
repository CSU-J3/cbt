# HO 624 — the `bills_agg` probe: is the ledger's largest line a real cost or HO 595's ghost?

HEAD `5e33c26`. Pointer "run through HO 623." **Next free is 624.** Probe HO — read-only, one diag commit, HALT for the ruling; the build (if any) is 625.

## 0. The hypothesis this probe exists to test, stated before any number is taken

The backlog entry (HO 602) says `bills_agg` is **110M rows / 26% of the 30-day budget at 317 calls × ~347k rows**. Two facts from the clone cast doubt on the attribution, not the arithmetic:

1. **~347k is not a `bills`-shaped number.** The corpus is ~17k bills; even the whole covering index is that order. But **`member_votes` was 365,996 rows** — and until HO 595, `participationAggCte()` full-scanned it **inside the very same `getMembersRanked` query** that `bills_agg` lives in. The per-query ledger attributes by query text; both CTEs share one statement.
2. **The HO 602 measurement window straddled the HO 595 fix.** A 30-day view read in early August covers weeks of pre-materialization executions at ~366k rows each.

So the null hypothesis is uncomfortable and specific: **the 110M line is mostly the participation scan HO 595 already killed, wearing `bills_agg`'s name**, and the true current cost of this statement may be ~25× smaller. If that's so, the "largest single read consumer" title belongs to something else, and optimizing `bills_agg` now would be tuning a ghost — the HO 420/577 invalidation class, at ledger scale. The probe's job is to make the statement's *current* per-call cost an arithmetic fact.

## 1. The one commit — `scripts/diagnostic/bills-agg-cost-624.ts`

Read-only, raw `@libsql/client`, house header per `absence-watch-588.ts`, bounded — the probe must not itself become a burn event: **counts and EXPLAINs freely; full statement executions exactly twice.**

**M1 — the components, counted.** `COUNT(*)` over: `bills` total; `sponsor_bioguide_id IS NOT NULL`; that split by `congress` (does the table span the 118th? a `congress = 119` clause is the narrowing lever only if it excludes something); the ceremonial split (the CTE has two variants); `member_participation` rows; `members` current; `palestine_scorecard` rows. These are the addends.

**M2 — the plans, verified.** `EXPLAIN QUERY PLAN` for `billsAggCte(false)` standalone and for the full `getMembersRanked` statement (volume sort and missed sort): confirm `idx_bills_sponsor_agg` still reads `SEARCH ... COVERING INDEX` and `part_agg` reads the materialized table. The HO 277 comment's "96ms / index-only" is a claim about a plan; re-verify the plan, not the comment.

**M3 — the reconciliation, which is the verdict.** Sum M1's addends into the expected rows-read per call of the *current* statement. Then put it against the ledger's ~347k:

- Expected ≈ 347k → the premise **holds**, the cost is real and present-tense, and 625 optimizes (M4 feeds it).
- Expected ≈ 20–40k and **347k ≈ the pre-595 `member_votes` scan** → the premise is a **ghost**; the deliverable becomes a ledger correction plus re-attribution, and 625's target is whatever a *post-595 window* actually ranks first. State the coincidence test explicitly: |347k − 365,996| vs |347k − expected|.

**M4 — the levers, priced but not pulled** (only meaningful if M3 says real): rows excluded by a `congress = 119` clause (from M1's split — note the index already carries `congress` as its fourth column); and the materialization sketch's write-side size (rows in a `member_sponsorship` table = distinct sponsors × ceremonial variants, refreshed by the daily sync, the HO 594/595 shape). Also inventory the statement's **cache-variant surface** — `getMembersRanked` keys on filters × sort × page, `getCommitteeRoster` per committee, plus the standalone lean copy in `searchMembers` (`queries.ts:7584`, per-query-string keyed at 600s) — because 317 calls/30 days is ~10/day and the variant count is what turns one cheap query into many.

**M5 — two live executions, timed and only two:** the full `getMembersRanked` statement once per sort (volume, missed), default filters, page 1. This is ~2× one `/members` render — acceptable — and it pins wall-time against the M2 plans. No loops, no sweeps over variants.

`diag(reads): HO 624 — bills_agg cost probe: component counts, plan check, and the ghost-attribution reconciliation`

Typecheck, explicit pathspec, ancestry reads one, push, then run.

## 2. HALT — what the ruling reads

Full output, then the four lines called out: **M3's verdict** with the coincidence arithmetic; the congress split (is narrowing even available); the variant-surface count; the M5 timings against the 96ms claim. Plus one thing the probe can't produce and only the dashboard can: **whether the Turso per-query view supports a custom window** — if a post-595-only window exists, one owner screenshot of its top line is the direct confirmation and I'll ask for it at the ruling; if the view is fixed at 30 days, the window won't be clean of the ghost until ~early September, and M3's arithmetic is the record until then.

No optimization, no schema, no `queries.ts` touch, no ledger edit — the backlog correction (if the ghost is real) is 625's docs work, written against this output.

## 3. Guards

1. Read-only throughout; the two M5 executions are the entire query burn.
2. The probe copies predicates verbatim from `queries.ts` with line refs, per the 588/621 pattern — and states that they were re-read at HEAD, since this file's line numbers have moved twice this month.
3. No conclusions in the script's own output beyond the arithmetic — the verdict language lives in the HALT, the ruling lives with me.
