# HO 398 — Race → news surface (first cut of the observation join)

**Gate: run only after HO 397 has landed and `git status` is clean.** 397 exists to clear the dirty rename tree; building this on a half-committed rename is the exact hazard it's clearing.

Confirm 398 is the next free number before saving (`ls docs/handoffs/ | sort -V | tail`); body assumes 398.

## What this is

The observation layer (HO 394–395) made race→news joinable: `observation_entities` links to a race's incumbent via `entity_value = incumbent_bioguide_id` at `entity_type = 'person'`. The pilot already joined 18 races cleanly on covering indexes. This puts "news around this race" on the race detail surface.

First cut is race→news on the race detail. Member→news is the sibling (same query keyed by bioguide on the member hub) and comes as a fast-follow — not in this handoff.

## Scope — honest v1

- The join is by bioguide, so this catches news mentioning the **incumbent** (plus any challenger who's a sitting member with a bioguide, which is rare). Most challengers have no bioguide, so v1 is effectively incumbent news. Reflect that in the label/empty copy — don't imply "all race news."
- No new visual idiom. Reuse the existing news-row pattern (the `BreakingNewsBlock` / `/news` feed row: headline, source, relative timestamp, link out). Data-scoped reuse, so no design review.

## Verify live first

- Find the race detail component that's actually mounted now. There've been several drawer/modal iterations (HO 166 / 225 / 260); grep for the live one, don't assume. The section slots into that component.
- Confirm the race record exposes `incumbent_bioguide_id` at that component (the join key).
- Read the existing news-row component so the new section matches it exactly (styling, truncation, link behavior).

## Build (spec-driven — plan, then diffs, no commit until I approve)

- Query helper in `lib/queries.ts`: `getRaceNews(incumbentBioguideId, limit)`. Join `observation_entities` (entity_type='person', entity_value = bioguide) → `observations`; return recent obs (title, source publisher, url, observed_at), `ORDER BY observed_at DESC`, LIMIT ~8. Wrap in `unstable_cache` with a race-news tag. Add that tag to the news cron's `revalidateTag` calls AND to the allowlist — a new tag silently 400s its first flush otherwise.
- EXPLAIN the query. The pilot verified the covering-index path (`idx_obs_entities_type_value` + the observations index); confirm it still plans clean with the ORDER/LIMIT. Add `INDEXED BY` only if the planner strays.
- Section component: header matching existing casing ("NEWS · around this race" or similar), the news rows, empty state ("No recent news linked to this race's incumbent."). Slot below the existing detail content.
- Null guard: if `incumbent_bioguide_id` is null (open seat), render the empty state — don't query with a null key.

## Verify

- A race with a newsy incumbent shows rows; each links to the article URL.
- An open-seat / no-incumbent race degrades to empty state, no error.
- Force a news cron tick (or the revalidate) and confirm the section updates.
- `tsc` clean, build passes.

## Report back

- The EXPLAIN plan for `getRaceNews`.
- Description/screenshot of the section on a populated race and an empty one.
- Diffs for approval. No commit until I sign off.
