# HO 555 — widen `deriveDisposition` to the real kill vocabulary

A correctness fix on an existing surface, surfaced by HO 554's STEP 0. Ships **before** the
motion-line build (which becomes HO 556). **STEP 0 is read-only and HALTS.**

---

## 0. The finding

HO 554 STEP 0 M2 measured, on the 64-amendment Senate procedural residual:

| bucket | count |
|---|---|
| AGREE | 6 |
| **DOT-OTHER** | **53** |
| ORTHOGONAL | 5 |
| DISAGREE | 0 |

83% of that set renders a **muted `other` dot on prod today** while the amendment's own
`latest_action_text` states an unambiguous fate — overwhelmingly
`Amendment SA N ruled out of order by the chair` (the point-of-order kill after a failed budget
waiver), plus `fell when SA M fell` and `withdrawn`.

`deriveDisposition` (`lib/queries.ts`, the prod dot authority) tests only
`not agreed to | rejected | failed | motion to table.*agreed to` → `failed` and
`agreed to | adopted | passed` → `agreed`. It does not know `ruled out of order` or `fell`.
HO 550's probe classifier `actualFate` **does** — which is exactly why the probe could measure
"full action-text coverage" while the live dot stayed grey.

**This is not scoped to those 64.** The gap applies to every amendment in the corpus whose
action text dies by one of these phrasings, including amendments with no roll call at all — rows
the HO 554 motion surface will never see. That is the whole reason this is its own HO and not a
clause inside the feature: promoting the dot from the motion would fix a subset and leave the
defect standing.

**DISAGREE = 0**, so nothing renders a *wrong* fate today. The defect is under-reading, not
mis-reading. That sets the severity at **P2, not P1** — no halt on the existing build, but it
gates HO 556 because otherwise 53 rows ship a grey dot beside an `· amendment fell` clause.

---

## 1. Blast radius — why this can't ride in a feature commit

`deriveDisposition` is one function applied to **two different inputs**:

1. **`amendments.latest_action_text`** — `getBillAmendments`, `getMemberAmendments`,
   `getAmendments` (the `AmendmentListRow.disposition` that drives the dot on `/bill/[id]`,
   `/members/[bioguideId]`, `/amendments`), and `getAmendmentsSummary`'s acted block
   (`lib/queries.ts` ~3534) which produces `agreed` / `failed` / `otherActed`.
2. **`votes.result`** — the `AmendmentVote.disposition` in `getBillAmendmentVotes` and
   `hydratePageAmendmentVotes`, and `getAmendmentsSummary`'s **voted** block (~3557) which
   produces `votedAgreed` / `votedFailed` / `votedOther`.

Widening it therefore **moves rendered numbers** on the `/amendments` "By status" hero strip and
flips dots on three surfaces. Adding action-text vocabulary to a shared function could also
**misfire on a result string** — `fell` or `out of order` appearing in a `votes.result` would
silently reclassify a roll-call outcome. Measure both populations before writing the predicate.

**Not affected:** the SQL `?disposition=` filter is COARSE (acted / filed) and does not call
`deriveDisposition` — see the in-repo comment at ~3728. The `/amendments` "voted" `EXISTS`
predicate is likewise untouched. Confirm both in STEP 0 rather than trusting this paragraph.

---

## 2. STEP 0 — read-only, COMMIT, then HALT

New file: `scripts/diagnostic/disposition-vocabulary-555.ts`. Raw `@libsql/client`, no
`boundedFetch`, `SELECT` / `EXPLAIN` only.

**Derive the predicate from the population, not from the three examples above.** That is the
HO 551 discipline and it is the point of this step.

### M1 — the `other` population on `latest_action_text`

`SELECT latest_action_text FROM amendments WHERE latest_action_text IS NOT NULL`, run each
through the **current** `deriveDisposition`, keep the `other` bucket. Then normalise and cluster:
lowercase, strip `SA \d+` / `S.Amdt. \d+` / `H.Amdt. \d+` / dates / chamber suffixes, and report
the **top 30 distinct shapes by frequency** with counts, plus the total `other` count and what
share of `acted` it represents.

For each cluster, tag it by hand in the output as one of: `KILL` · `PASS` · `NEITHER`
(withdrawn / pending / procedural-noise) · `AMBIGUOUS`. I want to read the actual strings — do
not summarise them away.

### M2 — the `other` population on `votes.result`

Same treatment over the distinct `votes.result` values reachable through the amendment paths
(`amendment_votes ⋈ votes`, plus the Senate up-or-down parse set). Report **every distinct
`result` string with its count** — this vocabulary is small and I want it whole, not top-N.

**The question this answers:** does any candidate token from M1 (`ruled out of order`, `fell`,
etc.) appear in a `votes.result` string? If yes, the widening cannot be a single shared function
and §3 changes to a two-function split. Report explicitly either way.

### M3 — before/after delta on every rendered number

Implement the **candidate** widened classifier inside the script only (do not touch
`lib/queries.ts` yet) and report old → new for:

- `getAmendmentsSummary` acted block: `agreed`, `failed`, `otherActed` (and confirm
  `acted` / `filedOnly` are unchanged — they're counts, not classifications)
- `getAmendmentsSummary` voted block: `votedAgreed`, `votedFailed`, `votedOther`
- corpus-wide dot distribution across all amendments: agreed / failed / other

Then the safety direction: report **any row that moves `agreed` → `failed` or `failed` →
`agreed`.** That count must be **0** — this widening may only move rows *out of* `other`. Any
flip between two decided states means the predicate is wrong or ordering broke. **Non-zero is a
HALT**, print every row.

### M4 — confirm the non-affected paths

Grep-verify and report: the `?disposition=` SQL filter and the "voted" `EXISTS` predicate do not
call `deriveDisposition`. One line each, with the file:line. If either does, say so — §1 is
wrong and the blast radius is larger than stated.

### Commit and halt

```
diag: HO 555 STEP 0 — amendment disposition vocabulary (read-only)
```

Report M1–M4 and stop.

---

## 3. Build (after GO)

Single edit to `deriveDisposition` in `lib/queries.ts`, predicate taken from the M1 clusters I
approve — not from this document's examples.

Constraints:

- **Failed-family tested first**, preserving the existing ordering guarantee (so
  `not agreed to` can never read as `agreed to`, and a tabling-agreed stays a kill).
- **`withdrawn` stays `other`.** It is genuinely neither — the amendment survived the vote and
  was pulled later. Same for `rendered moot` (HO 554 M1's `119-samdt-3849`: the text describes
  the *cloture motion* being moot, not the amendment's fate). Do not classify what the text
  doesn't state.
- **Only `other` may move.** Enforced by M3's zero-flip gate, re-run post-edit.
- If M2 found token collision with `votes.result`, split into two functions
  (`deriveActionDisposition` / `deriveVoteDisposition`) sharing a common core, and update the
  two call-site families accordingly. Otherwise keep one function.
- Update the function's header comment: it currently says the tail
  "(withdrawn / out of order / pending) falls to `other` — honest, never mislabeled." Out-of-order
  is no longer in that tail. Correct the comment in the same commit; a stale comment asserting
  the old behaviour is how the next reader re-derives the bug.

```
fix(amendments): HO 555 — widen deriveDisposition to the measured kill vocabulary
```

Show me the full diff hunk before committing. If the relay swallows it twice, use the review-ref
route (`git push origin HEAD:refs/heads/555-review`).

---

## 4. Verification

**Hit each URL 2–3 times** — a check immediately after deploy exercises only the `unstable_cache`
MISS path. The second hit is the real test (HO 533/549).

1. `/amendments` — the "By status" hero numbers match M3's *new* column exactly. Not
   approximately: read them off the page and compare.
2. `/bill/[id]` for a bill carrying a ruled-out-of-order amendment (pick one from M1) — the dot
   is red, not grey, and the action text beside it is unchanged.
3. `/members/[bioguideId]` for that amendment's sponsor — same dot, same value.
4. A control bill with only ordinary agreed/rejected amendments (`119-hr-8800`, the HO 551
   19-amendment control) — **byte-identical** to pre-build.
5. Re-run the STEP 0 script post-edit: `other` count matches M3's new figure, flip count still 0.
6. `npx tsc --noEmit` clean; `e2e/smoke.spec.ts` + `e2e/fit-finish.spec.ts` green locally.

---

## 5. After this lands

HO 556 = **B1–B4 of `554-motion-aware-amendment-outcomes.md`, verbatim.** The render design does
not change. §0's framing of that document becomes true rather than false: with the dot corrected
here, the motion line's contribution really is the tally, the party split, and the `/vote/[id]`
drill, rendered beside a dot that is already right.

The HO 554 STEP 0 commit `be0fc4d` stays local and unpushed until then — it rides with the arc.

Carry forward into HO 556 unchanged: guard #3 (the motion never drives the dot), the
suppress-when-decisive rule, the store-free live-parse path, and §6's falsification obligation on
the `+N earlier` branch (HO 554 M3 confirmed 1:1, so it ships unexercised — prove it by scratch
perturbation or record it UNPROVEN).

---

## 6. Report back

M1 (top-30 clusters with your hand tags, verbatim strings) · M2 (every distinct `votes.result`,
plus the collision verdict) · M3 (old → new for all three number sets, plus the flip count) ·
M4 (the two file:line confirmations). Then stop.
