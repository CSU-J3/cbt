# HO 414 — Member→news surface on the member hub

> Self-claim the next free number: `ls docs/handoffs/ | sort -V | tail`. Body assumes 414. If HEAD has moved past 413, renumber.
>
> Spec-driven: propose the plan (query, mount point, row-component reuse decision, cache tag), **wait for my review, show diffs, no auto-commit.** Code and any docs stay separate commits, explicit pathspec, ancestry re-checked immediately before push.

## What this is

The deferred sibling of **HO 398** (`5f26ee9`), which put "news around this race's incumbent" on `/race/[id]` by joining `observation_entities` to a race's incumbent bioguide. This is the same query keyed on the **member's own bioguide**, surfaced on the member hub. It's the second consumer of the observation layer (HO 394–395), and it's the surface that's been holding Member depth at 98.

No new infra, no new visual idiom, no new join — 398 built and verified all of it. This hangs the same section off the member detail page.

## Grounding (verified in HO 398 — don't re-derive, confirm still-live at the gate)

- The join: `observation_entities` at `entity_type = 'person'`, `entity_value = <bioguide>` → `observations`. Covering-index path is `idx_obs_entities_type_value` + the observations index; 398 EXPLAINed it clean with `ORDER BY observed_at DESC` + `LIMIT`, selective index drive + PK join + two small temp b-trees over the handful of matched rows per person, no scan.
- 398's shape to mirror: `getRaceNews(incumbentBioguideId, limit)` in `lib/queries.ts` (returns title, source publisher, url, observed_at), `unstable_cache` with a race-news tag; the tag was added to **both** the news cron's `revalidateTag` calls **and** the `/api/revalidate` allowlist (a new tag silently 400s its first flush otherwise — 398 verified with a bogus-tag 400 control).
- 398's architecture call: the **server page** does the DB fetch and passes rows as **props into the pure body component** (`RaceHubBody` can't hit the DB). Mirror that split here so the DB stays out of any shared/drawer component.
- Row renderer: 398 added `components/RaceNewsRow.tsx` + one `app/globals.css` grid modifier, matching the `/news` (`BreakingNewsBlock`) row idiom.

## Gate — confirm before building (read-only, report back)

1. **The 398 template is intact.** Grep `getRaceNews`, `RaceNewsRow`, and the race-news cache tag. Confirm the surface still exists as shipped in `5f26ee9` and the observation join still plans clean. If 398 was reverted or refactored since, say so — the plan adapts.
2. **The live member hub component.** There've been many member-surface iterations (member hub, expanded card, sponsor card, list bar, scatter — HO 89 / 192 / 194 / 196 / 198 / 328). Grep for the component actually mounted on the member detail route now, and its route path (`app/member/...` or wherever it lives). The section slots into that component; don't assume from the handoff history.
3. **Bioguide at the mount point.** Confirm the member record exposes its `bioguide` (the join key) as a prop at that component. It always should — the member is keyed by bioguide — but confirm it's in scope where the section renders.
4. **`RaceNewsRow` reuse.** Read it. If its props are observation-generic (title/source/url/observed_at with no race-specific field), it's directly reusable. Report whether reuse-as-is is clean or whether the name should generalize (see the build note).

## Build (plan → diffs → approval)

- **Query helper** `getMemberNews(bioguideId, limit)` in `lib/queries.ts` — mirror `getRaceNews` exactly, same join and columns, `ORDER BY observed_at DESC`, `LIMIT ~8`. `unstable_cache` with a dedicated **`member-news`** tag.
- **Cache tag wiring:** add `member-news` to the news cron's `revalidateTag` calls **and** the `/api/revalidate` allowlist. This is the load-bearing gotcha — without the allowlist entry the first flush silently 400s. (If 398 made the tag generic across obs consumers rather than race-specific, fold member news under that instead of adding a new tag — your call in the plan, but a dedicated tag matches 398's precedent.)
- **EXPLAIN** the member query. It's the identical shape 398 proved, so the covering-index plan should hold — but confirm it **cold** (stateless planner), and add `INDEXED BY` only if it strays. Cheap insurance, mandatory for any observations/bills-family query.
- **Section on the member hub:** the **server page** fetches via `getMemberNews` and passes rows as props into the pure member-hub body (mirror 398's server-page-into-pure-body split — keep the DB out of any shared component). Header matching the existing casing (e.g. `NEWS · in the press` or whatever reads consistent with the race section's label). Slot below the existing member detail content.
- **Row component:** reuse `RaceNewsRow` if its props are obs-generic. If reuse is clean but the race-specific name grates, rename it to a neutral `NewsRow` (or `ObservationRow`) and update the race import **in the same commit** — but only if that rename is trivial and contained. If it risks touching more than the import, reuse as-is and note the naming debt; don't expand scope for a cosmetic rename.
- **Empty state:** `"No recent news linked to this member."` No open-seat / null-key case exists here — a member always has a bioguide, so unlike 398 there's no unreachable open-seat branch. The empty state is the only degenerate case (member with zero linked observations), and it's reachable for low-profile members, so get the copy right.

## Verify (before reporting shipped)

- A high-coverage member (pick a leadership figure with known press) shows rows; each links to the article URL.
- A low-profile member with no linked observations degrades to the empty state, no error, no null-key query.
- Force a news cron tick (or hit the `member-news` revalidate) and confirm the section updates. Bogus-tag control → 400, to prove the tag is genuinely allowlisted (398 ran this check — repeat it).
- `tsc --noEmit` + `npm run build` green (the member route compiles dynamic if it fetches per-request).
- `npm run verify:deploy` — served SHA (`/api/version` → `VERCEL_GIT_COMMIT_SHA`) === pushed HEAD. Then spot-check the member hub on prod shows the section.

## Non-goals / scope boundaries

- **Not the dashboard drawer.** Same boundary as 398: the section lives on the full member hub page only. If the member surface has a drawer/preview that can't hit the DB, it doesn't get news here — wiring news through a hub API for the drawer is a separate deferred fast-follow (the sibling of 398's `/api/race/[id]/hub` note).
- **Incumbent/member news only.** The join is by bioguide, so it's news mentioning that specific member. No challenger/non-member coverage — same honest v1 boundary as 398.
- **No changes to the observation pipeline, resolver, or news cron logic** beyond adding the one `member-news` tag to its revalidate list.

## Roadmap note (for the eventual doc sweep, not this commit)

This closes **one** of the two holds keeping Member depth at 98. The other is the FEC `by_size` gap (~61 members unpopulated, self-heals on a `sync:fec` run). Don't bump 98→99 off this alone — the roadmap reconciliation should confirm FEC `by_size` is populated too before the point lands.
