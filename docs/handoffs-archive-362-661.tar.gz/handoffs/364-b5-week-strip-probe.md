# HO 364 — B5 week strip: data probe (sparkline + four breakdowns)

> Claim the next free HO number; if 364 is taken in `docs/handoffs/`, use the next
> available and rename this file.

Read-only. No migrations, no code changes, no commits. The job is to confirm what's
queryable for the B5 strip redesign so the build handoff can carry resolved premises
instead of guesses. Report every answer in chat with the actual table/column/helper
name and a one-line example query or `EXPLAIN QUERY PLAN` where cost is in question.

The redesign supersedes the strip shipped by HO 283 (WoW deltas) + 284 (HEARINGS
metric, flat popovers). It reformats the date, folds FILLER into the metric run,
replaces the flat one-line popover with a richer card (header + 8-week sparkline +
metric-specific breakdown), and re-targets the report link. The card's sparkline and
breakdowns are the data unknowns this probe resolves.

One prior open question is now closed by design and needs no probing, only a one-line
query confirmation (folded into Q1): the report link. There is no current-week report
mid-week — reports finalize per completed week — so the button points at the most
recent finalized report and its label is dated (`JUN 15 REPORT →`, dynamic to that
report's week, never hardcoded, never the literal word "last week"). This overrides
283 audit #8 ("point at the current week's report"), which assumed a current-week
report that doesn't exist mid-week. The build carries that as a resolved premise.

The project copies lag the live repo. Confirm everything below against the running
code and the live Turso DB, not against the handoff `.md` files or `/mnt/project`.

## Anchors (starting points, confirm live — do not trust the copy)

- HO 242 Part B added three integer count columns to `reports` (laws / intro / moves
  per its naming) and a `scripts/backfill-report-counts.ts` that recomputes them from
  each report's `week_start..week_end`. The strip's this-week/last-week deltas (HO 283)
  read from here.
- HO 263 `committee_meetings` schema: `meeting_type` (raw string), `chamber`
  (`house`|`senate`), `meeting_date` (ISO), indexed on `(meeting_date)`.
- HO 352 stage-movements ladder buckets a week's transitions by **destination stage**
  in `assembleMarkdown` / the report data-assembly helpers.
- `bills` carries `stage`, `previous_stage`, `stage_changed_at`, `topics` (JSON array),
  and a bill-id of form `{congress}-{type}-{number}`.

## Q1 — Sparkline source: 8 weeks × 4 counts

The card wants 8 consecutive weekly values for ENACTED, NEW BILLS, STAGE TRANSITIONS,
HEARINGS, current week lit.

1. Confirm the three HO 242 count columns exist on `reports` and report their **actual
   names**. Confirm `SELECT week_start, <laws>, <intro>, <moves> FROM reports ORDER BY
   week_start DESC LIMIT 8` returns 8 rows of frozen counts (read the persisted column,
   not a live re-derivation — `moves` over `stage_changed_at` is mutable and would drift
   for older weeks; the persisted column is the stable source).
2. Is there a **hearings count column** on `reports`? Check whether 284 / HO 268
   persisted one. If yes, the sparkline is four columns from one tiny query — done.
   If **no**, report it as the single gap and answer: is the cheaper fix (a) add a
   `hearings_count` column + backfill, mirroring the 242 pattern exactly (meeting_date
   is immutable so the backfill is a clean `COUNT(*)` per week range), or (b) derive
   live from `committee_meetings` grouped by week at render? Recommend one.
3. How many rows does `reports` hold? (Confirms the sparkline query never touches a fat
   table.) If fewer than 8 reports exist, say so — the sparkline degrades to however
   many weeks are persisted, not a backfill scramble.
4. While in `reports`, confirm the dated READ FULL target: `SELECT slug, week_start FROM
   reports ORDER BY week_start DESC LIMIT 1` returns last week's finalized report. Report
   the column giving the week date for the `MON DD REPORT →` label (`week_start`?) and the
   report-URL pattern built from `slug`. Flag if the top row is ever a partial/incomplete
   week (the HO 110 incomplete-week guard should prevent this) so the link can't land on a
   non-finalized report.

Decision this gates: **keep the sparkline** (history is cheap, all four metrics resolve)
or **cut it** (gap can't be closed cheaply). Per the spec, if cut, the breakdown alone
carries the card.

## Q2 — STAGE TRANSITIONS breakdown ("where they went")

Destination-stage split for the current week: →COMMITTEE / →FLOOR / →OTHER CHAMBER /
→ENACTED, counts summing to the headline `moves`.

- Confirm the HO 352 helper (or the data-assembly function it calls) returns destination
  counts for an **arbitrary `week_start..week_end`**, not just baked into `content_md`.
  Name the function and its return shape.
- If the bucketing is only computed inside `assembleMarkdown` and emitted as markdown,
  report the base query that would back a live card instead: `bills` grouped by `stage`
  where `stage_changed_at` in the week. Confirm `stage` values map to the four card rows
  (note `president` — the mock shows four rows ending at ENACTED; confirm whether
  `president` collapses into another row or is dropped, and flag it).
- Cost: this hits `bills`. Report the `EXPLAIN QUERY PLAN` for the week-bounded grouped
  query and whether it needs an `INDEXED BY` hint on `stage_changed_at` (the stateless
  planner mis-plans feed-style queries against fat tables — known trap).

## Q3 — HEARINGS breakdown (type + chamber)

Card wants BY TYPE (HEARINGS / MARKUPS / BUSINESS, summing to headline) + inline CHAMBER
(HOUSE n · SENATE n) for the current week.

- Confirm the week's hearings group by `meeting_type` and `chamber` from
  `committee_meetings` filtered on `meeting_date`. Trivial query, but report it.
- **Normalization is the real question.** The mock collapses raw types into three
  buckets. HO 261 found the raw `meeting_type` values are mixed: House → Hearing /
  Markup / Meeting; Senate → Open Hearing / Open Business Meeting / Closed Business
  Meeting / Open Markup Session. Run `SELECT DISTINCT meeting_type, COUNT(*) FROM
  committee_meetings GROUP BY meeting_type` and report the actual distinct values present.
  Then confirm a **total** 3-bucket map (no orphan type falls outside HEARINGS / MARKUPS
  / BUSINESS). Proposed: Hearing + Open Hearing → HEARINGS; Markup + Open Markup Session
  → MARKUPS; Meeting + Open/Closed Business Meeting → BUSINESS. Flag any value that
  doesn't fit so the build can decide a bucket rather than silently dropping it.

## Q4 — NEW BILLS breakdown (chamber + top topics)

Card wants BY CHAMBER (HOUSE / SENATE) + inline TOP TOPICS (top 3, e.g. HEALTH n ·
DEFENSE n · TAX n) for the week's new bills.

- Chamber: is there an explicit chamber/origin column on `bills`, or is it derived from
  the bill-type prefix (`hr/hres/hjres/hconres` → House; `s/sres/sjres/sconres` → Senate)?
  Report which, and confirm the derivation is unambiguous for the bill-id format in use.
- Top topics: `bills.topics` is a JSON array in a TEXT column. Confirm how the existing
  feed aggregates topics (SQLite `json_each` in SQL vs app-side parse) and report whether
  a "top-3 topics among this week's new bills" rollup is cheap on that path. Name the
  topic-display formatter (`topicLabel()` or equivalent) so the card labels match the
  rest of the app.
- "This week's new bills" — confirm the immutable date column used (introduced /
  created date, not `update_date`, which churns).

## Q5 — ENACTED breakdown (list + 0-week degrade)

- Confirm the week's enacted bills (IDs) are a trivial query (`bills` where enacted in the
  week). For weeks with >0, the card lists ID + count rows.
- For the 0-week degrade ("NONE REACHED THE PRESIDENT" + inline LAST ENACTED HR NNNN ·
  date): confirm the most-recent enacted bill + its enactment date is queryable
  (single row, `ORDER BY <enacted_date> DESC LIMIT 1`). Name the date column.

## Report-back format

For each Q, a tight block I can lift straight into the build handoff's resolved-premise
section:

- **Source:** exact table.column or helper name.
- **Queryable per arbitrary week?** yes / no (and if no, the base query that backs it).
- **Cost:** trivial / fat-table-needs-INDEXED-BY (with the plan line if relevant).
- **Gap / caveat:** anything the build must handle (hearings count column, `president`
  row, orphan meeting_type, topic aggregation path).

Then one bottom-line recommendation: **sparkline kept or cut**, and **which of the four
breakdowns are ready as-is vs need a small build step** (e.g. a `hearings_count` column,
a destination-stage helper that takes a week range, a meeting_type normalization map).

Do not start the build. Report findings and stop.
