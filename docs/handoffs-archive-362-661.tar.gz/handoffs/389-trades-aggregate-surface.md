# Handoff 389 — Stocks aggregate surface (`/trades` index)

Scoped from the HO 388 probe (signed off in chat). **No source work** — the data is already live: `stock_trades` ingests daily from FMP `/stable/` inside `/api/sync` (548 rows on probe day, 0 unmatched, bioguide-keyed via `senateID`). This handoff is **UI only** on existing data.

## Resolved premises — do not re-derive (from HO 388)

- **FMP is NOT dead.** HO 70 was rebuilt onto `/stable/senate-latest` + `/stable/house-latest`; the pipeline is healthy and fresh daily. Do not re-probe FMP, Capitol Trades (503 from egress), Finnhub, or PDF parsers — the data layer is solved.
- **`stock_trades` is fresh, not stale** — no row-clearing, no re-ingest. Amounts are raw filing band strings (`"$1,001 - $15,000"`); `transaction_type`/`owner` are raw FMP strings; `bioguide_id` is populated (0 unmatched on probe day).
- The member hub already renders a per-member `Recent trades · N disclosed` block (`components/TradeRow.tsx`, `getMemberTrades`/`getMemberTradeCount`, tag `member-trades`).
- **The gap this fills:** the member hub's `View all {N} trades →` is **dead decorative text** (a `<span>`, no route). There is **no `/trades` route** and **no cross-member trades view**.

## Scope — a `/trades` index page

A corpus-wide trades surface answering "who's trading what, lately." Mirror the existing list-page chrome (`HeaderBar` + `GroupTabs` where it fits; reuse `TradeRow`).

Suggested cuts (decide depth at build; lead with the recency feed):
1. **Recent disclosures feed** — newest `disclosure_date` DESC, paginated, `TradeRow` per row with a member link (`/members/[bioguideId]`) and chamber. This is the spine.
2. **Most-traded tickers** (optional aggregate) — `GROUP BY ticker` over a trailing window, count + member-count. A simple ranked-bar list (the dashboard idiom), not a chart lib.
3. Make the member-hub `View all {N} trades →` a real `<Link href="/trades?member=<bioguideId>">` (or a member-scoped filter on the index) so the dead span becomes live.

## Query layer

New helpers in `lib/queries.ts`, all `unstable_cache` **tag `member-trades`** (reuse the existing tag — the trades cron/ingest path should `revalidateTag("member-trades")` if it doesn't already; verify). Force `INDEXED BY idx_trades_disclosure_date` on the recency feed (the index exists). Amount bands stay raw strings — **do not parse min/max in v1** (the schema note is explicit; a band→numeric parse is its own decision).

## Out of scope / watch

- No new ingestion, no source changes, no amount-band numeric parsing.
- Party/topic cross-analysis of trades = future. Keep v1 to recency + a ticker rollup.
- Honest-gap discipline: a trade whose `bioguide_id` is NULL has no member link — render the raw name, don't drop it (matches `getMemberTrades` filtering behavior).

## Acceptance

`/trades` renders a paginated recent-disclosures feed from live data; member links resolve; the member-hub "View all trades" becomes a working link. Ship step per convention: eyeball locally (fresh restart, assert CSS loads), then `git push && npm run verify:deploy`, report the live SHA.
