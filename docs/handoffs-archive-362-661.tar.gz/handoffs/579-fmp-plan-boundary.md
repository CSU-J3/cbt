# HO 579 — The FMP `page` 402 is a plan boundary, not an error

Confirm the number from `docs/roadmap.md`: the pointer runs through **HO 577** and HO 578 was its sweep, so this should be **579**. Take it from the roadmap, not from a filename.

Small, one commit. No probe needed — the mechanism is already confirmed against the live API.

## What's happening

`/api/sync` logs this every tick:

```
[sync] trades error: FMP house-latest page 1 failed: 402 Premium Query Parameter:
'Special Parameters : The values for 'page' can only be 0 based on your current
subscription.
```

Confirmed by hand against the live endpoint with the current key: page 0 returns data, page 1 returns the 402. The account is on FMP's **Free plan**, which permits `page=0` only. This is an entitlement gate, not a rate limit — it fires regardless of how few calls have been made, and the usage meter reads 0/250 while it happens.

Nothing is misconfigured. The key is valid and page 0 works, so the sync is still capturing every new disclosure (the `-latest` endpoints return newest first). What's lost is backfill depth per tick, and what's gained is a recurring error in the cron log for a condition that is permanent and expected.

## The current flow

`app/api/sync/route.ts:131` calls `ingestTrades({ maxPagesPerChamber: 3 })`. `lib/trades-ingest.ts:119` loops `for (let page = 0; page < maxPages; page++)`, and on a throw it pushes the message into `result.errors` and breaks. So today: page 0 succeeds, page 1 throws the 402, the message lands in `errors`, the loop breaks, page 0's rows are kept.

`lib/fmp.ts:75` treats only 429 and 5xx as retryable, so the 402 goes straight to the throw at `:86`. Correct — it should not be retried. It just shouldn't be an *error*.

`scripts/sync-trades.ts:10` requests 20 pages for manual backfill.

## The change

**Do not hardcode the cap at the call sites.** Leaving `maxPagesPerChamber` at 3 and 20 means an eventual plan upgrade needs no code change — the loop simply gets further before it stops. Hardcoding `1` would bake today's plan into the call sites and quietly cap a future paid plan.

Instead, make the boundary something the code recognizes:

1. **`lib/fmp.ts`** — detect the plan gate specifically. A 402 whose body names the `page` parameter is a plan boundary. Give it a distinguishable type (an exported error subclass, or an exported predicate over the thrown error) so callers can tell it apart from a genuine failure. Match on **402 plus the page-parameter text**, not 402 alone: a 402 on some other parameter is still a real error and should stay one.
2. **`lib/trades-ingest.ts`** — in the catch at `:122`, if it's the plan boundary, `break` **without** pushing to `result.errors`. Record it on the result instead as its own field (`planCappedAtPage: number` or similar) so the condition stays visible without being reported as a failure. Anything that isn't the plan boundary keeps today's behavior exactly.
3. **Surface it once, quietly.** A `console.info`-level line naming the cap is fine; a `console.warn`/`error` is what we're removing. The `/api/sync` response should carry the new field so the state is observable from the route rather than inferred from silence.

That's the whole change. Two files.

## What this deliberately does not do

- **No plan purchase decision.** FMP does offer a 30% student discount, applied by contacting support with a student email or ID rather than a code at checkout. Whether Starter even lifts the `page` gate on `stable/house-latest` and `stable/senate-latest` is unconfirmed — FMP gates by endpoint, not only by volume. That's a question for their support, and it's out of scope here.
- **No change to `maxPagesPerChamber` at either call site.**
- **No retry on 402.** It is correctly non-retryable today.
- **No touching the FMP key or env vars.**

## Falsification

Unusually, this one needs no scratch setup: **the plan-boundary branch fires on the current plan every tick**, so a normal run exercises it. Confirm it actually took the new path rather than the old one — the run should show the cap recorded on the result and `result.errors` empty for that chamber.

Note the inverse for the docs sweep: if the plan is ever upgraded, this branch becomes untriggered and reverts to the usual can't-tell-working-from-dead state. Worth recording as a WATCH rather than pretending it stays proven.

## Verification

- `npm run typecheck` clean.
- Run the trades ingest locally against the live API. Expect: page 0 returns rows, page 1 hits the gate, the loop stops cleanly, `errors` is empty for that chamber, and the cap is recorded.
- **The landing instrument:** the `[sync] trades error: FMP house-latest page 1 failed: 402` line **disappears** from the next `/api/sync` cron run. That reads differently if the work never happened, so it's a real instrument rather than a regression gate.
- Confirm a non-plan failure still lands in `errors` — force a bad endpoint path in scratch, verify it's reported as an error, revert, `git status` clean.
- Ship: `git push` (fast-forward, ancestry eyeball first), then `npm run verify:deploy` until served SHA === HEAD. Check the next `/api/sync` tick in the logs.

## Ship report

- SHA, the two files.
- The exact predicate you used to identify the plan gate, and why it can't swallow a real 402.
- Local run output showing the clean stop and empty `errors`.
- Confirmation the scratch non-plan failure still errors.
- The cron log line after the next tick — gone, or not.

## Docs

HO 580 sweeps this. Four unrelated corrections are already owed and should ride along there rather than here:

- `backlog.md:33` — the `MissingSecret` entry's stated root cause ("no `AUTH_SECRET` in the environment") is false. `vercel env ls` shows `AUTH_SECRET` in Production, set 37 days ago, and 13 hours of warn-and-above prod logs contain no `MissingSecret` at all. The auth vars are **Production-scoped only**, so previews lack them — that's the likely origin of the original observation.
- The same entry's `FEC_API_KEY`-not-in-Vercel-Production claim is also false; it's been in Production for 73 days.
- `oddities.md:85` — says `AUTH_SECRET` "lives only in `.env.production.local`". That file is a `vercel env pull` artifact where every value reads blank because it's encrypted; it was never the source of truth.
- **`LDA_API_KEY` is genuinely absent from Vercel** and `lib/lda-sync.ts:115` only attaches the auth header when the key exists. The lobbying cron is therefore running anonymously, getting 429'd, waiting 39s, and 504ing — visible in the logs. That's a real prod failure and wants its own item, not a doc line.
