# HO 549 — falsify the hit-2 detector, then sweep HO 548

Number confirmed from the roadmap pointer (currently "run through HO 547"), not from a filename.

Two steps. **STEP 0 commits nothing** — it's a scratch-tree experiment that must leave the working tree clean. The sweep is one docs commit, plus a SKILL commit through the review ref.

## STEP 0 — prove the instrument can fail

HO 548's hit-2 assertion swept 36 routes clean. That result is currently uninterpretable: a detector that works and a detector that structurally cannot fire produce the same green log. The backlog preamble already names this failure mode — *state what the instrument reads if the work never happened; if that's the same as success, it isn't an instrument*. So before any doc records the detector as protection, demonstrate it firing.

The defect shape is exact, from `85d6660`: `getBillAmendmentVotes` returned a `Map`, `unstable_cache` round-tripped it to `{}` on a hit, and `BillAmendments`' `.get` threw — 500ing every amendment-bearing `/bill/[id]` on hit 2 while hit 1 200'd.

**Do not time-travel the files.** `git checkout 85d6660^ -- lib/queries.ts` would drag back a version predating HO 537/540/542 and break unrelated callers. Hand-apply the minimal defect on top of current HEAD instead:

1. In `getBillAmendmentVotes`, wrap the assembled return so it hands back a `Map` (`new Map(Object.entries(out))`).
2. In `BillAmendments`, read it back with `.get(a.id)` instead of `votes[a.id]`.

That's the same serialization class at the same site, in three lines.

Then: `npm run build && npm start`, and run the smoke crawl against **localhost** scoped to the one route — `/bill/119-hr-8800` (amendment-bearing, the HO 533 verification bill). Use `BASE_URL=http://localhost:3000` and grep the specific route rather than running all 36.

**The result you're looking for:** `hit1=200 … | hit2=500`. That is the detector firing, and it makes HO 548's clean sweep mean something.

**If it doesn't fire, say so plainly and do not paper over it.** A local `next start` keeps the Data Cache on the filesystem, so the miss→hit transition should happen — but local cache behaviour is not guaranteed identical to Vercel's, so a non-firing result is *ambiguous, not a disproof*. In that case the honest outcome is: the sweep records hit-2 as **unproven** in WATCH with the reason, rather than claiming protection we haven't demonstrated. Don't go hunting for a way to make it go green.

**Cleanup is part of the step**, not an afterthought: revert the two edits, confirm `git status` is clean and `git diff HEAD` is empty before touching any doc. Nothing from STEP 0 commits — no scratch script, no defect, no stash left behind. Report the raw log line either way.

## The sweep

Four files. `docs/roadmap.md` + `docs/backlog.md` + `docs/oddities.md` ride one commit; `SKILL.md` is separate and gated.

**`docs/roadmap.md`** — append one new `**Also (HO 548)**` block carrying its own frozen `Also notes now run through HO 548` pointer. Do not touch HO 547's pointer or any prior block's clause; the convention note at the head of the Status block spells out why (the HO 518 §1b near-miss). No theme-% change — this is harness work on already-counted surfaces.

The block should carry: the two gaps 548 closed (single-hit crawl inside the post-deploy miss window; five arcs with no interaction coverage since 472), the six areas now covered with their HO provenance, the five seeds, **the STEP 0 falsification result**, and the clean-sweep finding stated as a real result rather than an absence. Also record the one design detail worth keeping — the guarded-log-not-skip choice on the bill-hub scroll-reset, and why a permanently-red `expect.soft` was the wrong shape for a committed test.

**`docs/backlog.md`** — the QUEUED **"Fit & finish browser pass"** line is a claim, not a fact; check it before editing. It reads as unbuilt, but HO 472 shipped the interaction pass and the current spec has a `dropdown hunt (Part C)` describe block, which is that line's third clause. Determine whether it was already discharged at 472/473 and never struck, or genuinely still open. Strike it to DONE with the right provenance if discharged; leave it with a note about what remains if not. Either way, state which you found — don't split the difference.

Add a DONE tombstone for 548, and a WATCH entry for the doubled prod-crawl load (~52 requests/run against a config that documents "keep the run gentle") with a promote-if criterion.

**`docs/oddities.md`** — the cache-hit verification lesson is **already there** from the HO 534 sweep. Grep first and **extend that entry**; do not add a second one. What's new is that the discipline is now mechanized in the crawl rather than resting on someone remembering to hit a URL twice — plus, if STEP 0 fired, the demonstrated proof that the mechanism catches it.

**`SKILL.md`** — the testing section needs the double-hit convention documented (why every route is hit twice, what hit-2 means, the full-route-cache caveat that keeps a green hit-2 from being over-read) and the fit-finish areas updated to include the six new ones. **Separate commit, and route it through the review ref** per the self-mod guard: push to `refs/heads/549-review`, I read the diff out of the repo and approve, then main fast-forwards and the ref is deleted.

## Constraints

- Docs only after STEP 0. No app code, no CSS, no test-file edits.
- Code and docs never ride together; the SKILL commit is separate from the roadmap/backlog/oddities commit.
- Explicit pathspec staging. Show me the diff before each commit — for the roadmap block especially, since an append-only block is permanent and correctable only by a later one.
- Fast-forward only, ancestry eyeballed against current HEAD immediately before push.

## Ship report

- STEP 0: the raw `hit1=… | hit2=…` line, whether the detector fired, and confirmation the working tree is clean with nothing committed from the step.
- Which way the "Fit & finish browser pass" backlog line resolved, and the evidence.
- Confirmation the oddities entry was extended rather than duplicated (show the grep).
- The roadmap pointer grep: `run through HO 548` appears exactly once, `run through HO 547` still appears exactly once.
