# HO 363 — B2 ticker restyle (MARKETS / ODDS strips)

Pure restyle of the two pinned-label tape strips. Per-instrument styling and inter-instrument spacing only. Structure, marquee, width-pinning, status cell, and the <700px hide all stay. Approved design out of the design chat; build as specified. No data-layer changes. Independent of the odds-STALE freshness work (separate handoff) — if that landed first, re-check HEAD before push.

## Verify live state first
Grep the current B2 tape component and confirm the actual render order, font-weights, token names, and the width-pinning implementation before editing. Don't build from `/mnt/project` or from the design mockup's CSS. The mockup uses demo variable names (`--amber`, `--prim`, `--muted`) and demo data; the real token names are below. The mockup is a visual aid only, not a source to port.

## MARKETS item — order: SYM · VALUE · Δ · QUAL
- SYM: `--accent-amber`, weight 500.
- VALUE: `--text-primary`, weight 600, tabular-nums. This is the change: value was muted/400, now it's the bright element.
- Δ: `▲`/`▼` ±x%, weight 600, `--stage-enacted` (green) on up / `--party-republican` (red) on down. Omitted on level series (CPI, UNEMP, WTI when no change) — render no Δ element at all, not a blank slot.
- QUAL: the EOD/MO micro-tag from HO 287 (bordered, 9px, `--text-dim`). Reuse the existing chip component, don't fork it. Move it to TRAIL the quote. It currently sits between SYM and VALUE; that placement is the visual mess being fixed.

## ODDS item — order: NAME · K val · P val
- NAME: `--accent-amber`, weight 500.
- K / P source marks: `--kalshi` (#4DE4B2) / `--poly` (#2E5CFF), weight 600. Unchanged from HO 287.
- values: `--text-primary`, weight 600. Were muted; now bright, same as MARKETS values.

## Separator — wide gap, no glyph
Inter-instrument spacing is a wide gap only. No pipe, no dot. Inter-instrument gap ≈ 4–5× the within-instrument gap (start ~28px between instruments vs ~6px within). The gap is the entire chunking fix. The mockup ships a pipe/dot/gap toggle and renders pipe by default — ignore that; the approved choice is GAP. Don't build the toggle. The gap is inter-item track spacing, outside each item's pinned width box (see constraint below).

## Pinned label cell
Add a 2px `--accent-amber` left border on the MARKETS / ODDS label cell. New element. Label text stays `--text-dim`, 10px, uppercase (unchanged).

## Status cell (right, pinned) — keep as-is
`AS OF HH:MM MT · STATE`, STATE colored: CLOSED `--text-dim`, STALE `--accent-amber-bright`, OPEN `--stage-enacted`. Matches current. Confirm the classes exist and render; don't restyle.

## Constraint — do not break the marquee width-pin (HO 175/176)
This is the one that bites. Each item is `ch`-width-pinned so values updating per poll don't reflow and jump the marquee. The restyle is render-order and weight only, but weight 400→600 makes the same string wider, and `ch` is weight-dependent. Confirm the pin's measurement is taken at the same font-weight the value now renders at (600). If the `ch` count is computed on a measuring element at the old weight while the rendered value is 600, the pin under-sizes and either clips or jumps — fix so measurement weight and render weight match. After the change, the pin must still fully contain the widest possible value per poll with zero poll-to-poll reflow. tabular-nums stays. Reordering QUAL to trail is width-neutral; the weight change is the width-relevant one.

## Out of scope
No new tokens. No structural change to the strip. No marquee or animation change. No new interactions, no URL params. Reduced-motion and <700px hide unchanged. No data-layer touch.

## Ship
`tsc` clean → `npm run build` clean → `git push` (explicit pathspec, never `-A`) → `npm run verify:deploy` until the served SHA matches HEAD. UI change, so verify the stylesheet actually loads on prod (a drifted `.next` serves a stale CSS hash and the page goes unstyled), not just tsc + 200 + payload. Then eyeball both tapes on prod: bright values, trailing EOD/MO tags, wide gaps between instruments, amber left border on the labels, correct STATE colors, and the marquee scrolling with no jump on poll and no clipped values.
