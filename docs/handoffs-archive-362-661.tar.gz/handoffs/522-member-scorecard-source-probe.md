# HO 522 — Member-scorecard arc: source-liveness probe

**READ-ONLY. No writes, no commits, no schema.** First step of the member-scorecard arc — the named **99→100 hold on Member depth**. Graveyard discipline: verify source liveness + shape + cost + **join feasibility** before scoping any build. Deliverable is a **GO/NO-GO per source** + a recommended build path; the build is HO 523+, gated on this verdict.

Inert diagnostic — approved on summary, report back. **No commit** (if a reusable fetch/inspect helper falls out, propose it separately; default none).

The arc = **"career vote participation + external scorecards."** Both halves have external dependencies that must be liveness-checked first. Two tracks below.

---

## Track A — External interest-group scorecards (the risky half)

The class that rots. **Do NOT probe the tombstoned sources** — OpenSecrets (dead Apr 2025), ProPublica Congress API (dead), FiveThirtyEight (dead) are already in the graveyard.

### A1 — Primary target: VoteSmart (pre-checked live, two risks to settle)

Pre-check (2026-07-25): the org is active (2024 financials), `justfacts.votesmart.org` serves per-SIG rating pages (ACU, national SIGs, per-group rating pages), and `api.votesmart.org/docs/Rating.html` still documents the ratings methods (`getSigRatings`, `getRating`, `getCandidateRating`). So the **data is live** — the two open questions are access and join:

1. **API key — obtainable or partner-only/dead-in-practice?** VoteSmart restricted public API-key issuance a few years back. Verify: is there a working key-request path, or is the API effectively closed? Try the documented `api.votesmart.org` ratings endpoints (they'll 401/403 without a key). **If no key is obtainable, the realistic ingest path is scraping `justfacts.votesmart.org`** — assess whether the per-SIG rating pages are cleanly structured (stable HTML/JSON, per-group ID + per-candidate rating), paginated, and rate-tolerant.
2. **THE JOIN (make-or-break).** VoteSmart keys candidates by its **own candidate ID, not bioguide**. Assess whether a VoteSmart-candidate → bioguide crosswalk is feasible:
   - Best case: justfacts candidate pages expose an **FEC ID or bioguide** (→ join through the existing `unitedstates/congress-legislators` crosswalk CBT already runs). Check a few member pages for external IDs.
   - Worst case: **name + state + chamber fuzzy match only** — the error-prone LDA-registrant class (homonyms, "Jr./III", nicknames, mid-cycle seat changes like the SC one). If this is the only path, weight it heavily against VoteSmart.
   - Report: which case applies, and for the fuzzy case, an estimated match rate against CBT's ~535 current members.
3. Shape/coverage: does VoteSmart carry **119th-relevant** ratings (recent enough), for **both chambers**, across a useful set of groups (ACU, ADA, LCV, NRA, Chamber, Planned Parenthood, etc.)? How many distinct SIGs with current-Congress ratings? License/ToS for redisplaying scraped ratings.

### A2 — Fallback: direct individual-group sources (if VoteSmart's join is non-viable)

If A1's join kills it, the alternative is ingesting a few groups directly. Probe these for liveness + keying + bulk-vs-scrape:
- **LCV National Environmental Scorecard** (`scorecard.lcv.org`) — annual, often per-member and downloadable; check keying (bioguide? name+state?) and whether a bulk file exists.
- **Heritage Action** (`heritageaction.com/scorecard`) — live web scorecard; check structure + keying.
- **ADA (Americans for Democratic Action)** voting records (`adaction.org`) — annual "Liberal Quotient"; check format.

The tradeoff to state explicitly: **VoteSmart = one source / many groups / hard join** vs **individual groups = clean-ish join / N scrapers / narrow coverage / N maintenance surfaces**. Recommend which shape is worth it, or whether the scorecard half is NO-GO for now.

---

## Track B — Career / historical vote participation (likely the cleaner win)

Two cuts, cheap-floor and full-career — the probe scopes which is buildable:

### B1 — In-corpus floor: 119th-only participation (zero external dependency)

CBT already has 119th vote records (house/senate votes, HO 77/80). Confirm from the **schema** whether a per-member **119th missed-votes rate** is computable from existing tables — i.e. do the vote tables record **per-member cast/not-cast per roll call**, or only aggregate Yea/Nay tallies? (If only tallies, even 119th participation needs member-level cast records, which changes the cost.) This is the buildable-regardless floor if Track A stalls.

### B2 — Full career: Voteview roll-call votes (multi-Congress)

Voteview is **already wired** for ideology (`member_ideology`, ICPSR-keyed) — so it's a trusted, non-rotting source with the join already solved. Voteview publishes per-Congress **roll-call vote CSVs** (member × rollcall, Yea/Nay/abstain codes). Verify:
- The historical vote files exist + are fetchable (voteview.com data downloads), carry **abstentions/not-voting** (the codes that define a missed vote), and **span members' careers** (enough Congresses back).
- Keyed by **ICPSR** → joinable to bioguide via the **existing crosswalk / ideology layer** (this join already works for ideology — confirm it carries to the vote files).
- Cost: per-Congress file sizes and how many Congresses to assemble a "career" participation figure (this is the LDA-side-table lesson — if it's a large-table full-read, note it so the build precomputes into a blob rather than request-time aggregates).

**Scope fork this surfaces:** ship **119th-participation (cheap, in-corpus)** first, or go straight to **career-participation (Voteview, heavier)**? Report feasibility of both.

---

## Deliverable

A **GO/NO-GO per source** (liveness · shape/coverage · keying-join · cost · license), plus a **recommended build path**:
1. Scorecards: VoteSmart-scrape / individual-groups / NO-GO — and if GO, the join mechanism + expected match rate.
2. Participation: 119th-only (in-corpus) vs career (Voteview) — feasibility + cost of each.
3. Sequencing: whether to **ship participation-first** (likely the clean 99→100 mover) and treat scorecards as gated on a viable-source verdict — or whether a scorecard source is clean enough to build alongside.

Read-only; no writes, no commits, no doc edits. Report back and we scope HO 523+ from the verdict.

read docs/handoffs/522-member-scorecard-source-probe.md and follow it
