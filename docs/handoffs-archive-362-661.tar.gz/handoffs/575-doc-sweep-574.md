# HO 575 — Doc sweep for HO 574 (the `pageErr` probe)

Confirm the number: the roadmap's pointer runs through **HO 572**; HO 573 was its sweep, HO 574 was the probe + instrumentation commit (`57395b9`). So this is **575**.

Docs only. Two commits, both through the review ref. Verify every quoted line against the repo at `57395b9` before editing.

---

## Commit 1 — `docs/roadmap.md` + `docs/backlog.md` + `docs/oddities.md`

### `docs/roadmap.md` — a new "Also (HO 574)" block

**Append-only.** Previous closer must still read **572** after your edit; yours reads **574**.

- **The design paid, and why it nearly didn't.** The probe was built artifact-first against a **14-day retention clock**. All four failed-run artifacts were live, and the verbatim message was **identical across all four runs** — a single cause. It is **React #418, `args[]=HTML`**: the hydration text-content mismatch variant. The message had been captured all along (`smoke.spec.ts:129` pushes `err.message`) but only the **count** was ever printed (`:200`), so the diagnostic existed for weeks and was reachable only through an expiring artifact.
- **Route/hit breakdown**, per Code's table: run 30506188415 (`/?stage=committee`, `/?stage=other_chamber`, hit-2); 30510430349 (`/`, `/?stage=other_chamber`, hit-1 + hit-2); 30470412500, the 07-29 schedule (`/`, four `?stage=` variants, `/president`, both hits); 30572418753 (five `?stage=` variants + `/members`, hit-2). **Fires on hit-1 as well as hit-2**, which rules out the HO 533 cache-serialization class.
- **H1 falsified.** `/president` and `/members` fired, and both are non-tape inner pages (HO 323/326 stripped the tape; no `MarketsTape` in `HeaderBar`). The HO 572 "tape-bearing set" observation does not hold. Code killed it on the artifact route pattern rather than a local test, which is the stronger evidence and the right call.
- **The block's real lesson — the firing set has been re-characterised twice, from growing samples.** Two runs supported "tape-bearing." Four runs supported "the relative-age feed surfaces," after two non-tape pages fired. **Neither characterization was wrong on its data; both were premature**, and the tell is that the set *grew* with sampling rather than converging — 2 routes, then 6, then 6 including a non-tape inner page. **State plainly that the current characterization is also provisional**, and that the fix HO must not scope around the observed route set until it stops growing. The confound is still live either way: those pages are also the heaviest client-island pages, so "relative-age" and "most islands" remain perfectly confounded.
- **H2 supported, component unidentified.** Time-derived hydration is the shape that fits (#418 by message, both hits, sometimes recovering on retry), but it is a **new** cause, not the HO 473 `<title>` mechanism — re-confirmed falsified, all four `<title>` sites single-child at `290e239`. Nearest prior art is the HO 489/490 relative-age arc, so a gap or regression in the prop-drilled `nowMs` fix is a candidate the fix HO starts from, not a conclusion this one reached.
- **Not reproducible locally.** Two full local smoke crawls, route-crawl `pageErr=0` throughout. Record this as a **result, not a gap** — the handoff pre-authorised it, and an unreproduced intermittent with the instrument shipped is a complete outcome.
- **C1 (`57395b9`), `e2e/smoke.spec.ts` only.** A second log line, emitted only when non-empty, carrying the actual messages whitespace-collapsed and truncated to 200 chars each, `pageErr` first. **Falsified before being recorded as working** (the HO 549/553 rule): a scratch client-only throw in `CyclingTimestamp` produced a real `pageerror` through the unchanged capture and the new line printed it, with console messages cut at 200. Scratch reverted, nothing committed from it.
- **Handoff premise corrected — carry this, it's a doc error not a code one.** The HO 574 handoff said `attachCollectors`/`logClean`/`assertClean`/`settle` are shared between the specs. **They are not.** `e2e/fit-finish.spec.ts:56` defines its own `attachCollectors`; it imports only `isKnownNoise` from `console-noise.ts`. The claim came from SKILL `:1913`, which is corrected in commit 2. So C1 is smoke-only and fit-finish is provably unaffected (re-confirmed 41/0).
- **No theme-% change** — a read-only probe plus test instrumentation; no user-facing surface, no bar moves (the HO 379 / 382–386 / 503–504 / 548 harness precedent).
- **Numbering — the 572 → 574 pointer jump skips no block:** HO 573 was the doc sweep for 572. Close with `Docs: HO 575.` and `**Also notes now run through HO 574.**`

### `docs/backlog.md` — reconcile in place

**Update the `pageErr` OPEN LOOP** (currently titled UNCHARACTERIZED). It is now partly characterized, and the title should say so rather than staying at UNCHARACTERIZED or jumping to solved:

- **Characterized:** React #418 `args[]=HTML` (hydration text-content mismatch), identical message across all four failed runs, so a single cause. Fires on both hits, so not the HO 533 class.
- **Ruled out:** H1 (tape / empty-payload client island) — falsified by `/president` and `/members`; the HO 473 `<title>` mechanism — re-confirmed at `290e239`; the concurrency-cancellation WATCH — checked at HO 572.
- **Supported, unidentified:** H2, a time-derived render input. Nearest prior art is HO 489/490.
- **Scoping guard for the fix HO — the important addition:** do **not** scope the fix around the observed route set. Two characterizations of that set have already been superseded by additional samples, and it has not been shown to have stopped growing.
- **Close criterion:** keep "a named cause PLUS green runs, never green runs alone." Note that "named cause" is now **half-met** — the error *class* is named, the *component* is not, and the class alone is not a cause you can fix.
- **Instrument, updated:** the HO 574 log line means the next prod occurrence prints its own message, so diagnosis no longer depends on downloading an artifact inside a 14-day window. That is a real improvement in the instrument and worth saying.

**New FIT & FINISH · P3 — the collector helpers are duplicated, and have now drifted.** `attachCollectors` / `logClean` / `assertClean` / `settle` exist as **two independent copies** (`smoke.spec.ts:109`, `fit-finish.spec.ts:56`). HO 504 extracted `isKnownNoise` to a shared `console-noise.ts` and left the rest duplicated; SKILL then described the whole set as shared, which is the error commit 2 fixes. **HO 574 C1 edited the smoke copy only, so the two have now provably diverged** — smoke prints messages, fit-finish prints counts. Fix shape: finish the HO 504 extraction into the shared module, the same anti-drift discipline already applied to `NEWS_ARTICLE_KEY_SQL`, `MISSED_CARVE_EXPR`, and `lib/amendment-vote-key.ts`. *Close:* one definition, two importers. Not urgent, but it should not be discovered a third time.

**Light touch on the `fit-finish.spec.ts` manual-posture WATCH:** the HO 573 caution said `smoke.spec.ts` isn't reliably green. That still holds and is now *characterized* rather than mysterious. One clause, don't rewrite the entry.

### `docs/oddities.md` — append at the end

Two entries:

1. **A failing set characterised from too few samples names the wrong shared property (HO 572 → 574, Jul 2026).** Two runs made the `pageErr` firing set look tape-bearing; four made it look like the relative-age feed surfaces, after two non-tape pages fired. Each reading was defensible on its data and each was premature, and the tell was that the set **grew** with sampling instead of converging. The rule: **before naming the shared property of a failing set, check whether the set has stopped growing — a property shared by everything you have seen so far is not yet a property that identifies a cause.** The contrast is the load-bearing half: HO 563's contiguous CA-1…8 gap and HO 566's empty 1–4 partial bucket are the *successful* versions of exactly this reasoning, and what made them work was that the shape was **stable and bounded** before it was read. Cross-reference both rather than restating them; the transferable difference is sample stability, not cleverness.
2. **A collector that captures more than it prints is a diagnostic you can only use retroactively (HO 574, Jul 2026).** `smoke.spec.ts:129` had been recording `err.message` from the start; `:200` printed only `pageErr=${n}`. So every failing prod run since the crawl was wired had the answer in hand and surfaced a number instead, and the message survived only inside an expiring 14-day artifact — recoverable here only because someone went looking before the window closed. The rule: **if a collector stores a string, print the string.** A count tells you something happened; it can't tell you what, and by the time you want to know, the run that knew is usually gone.

Commit: `docs: HO 575 — sweep HO 574 (the artifact answered it: #418, H1 falsified, the set still moving)`

---

## Commit 2 — `.claude/skills/cbt/SKILL.md` (its own commit)

1. **`:1913` — the factual error.** It says `fit-finish.spec.ts` "reuses `attachCollectors`/`logClean`/`assertClean`/`settle` + the `GATE_COOKIE` `beforeEach`." Each spec defines its own copy; the only genuinely shared import is `isKnownNoise` from `console-noise.ts`. Correct it, and say the duplication is **known and filed** rather than silently fixing the wording into something that reads like a design choice. Check the `GATE_COOKIE` half of that clause too rather than assuming it's right — the sentence has already been wrong once.
2. **The testing section gains the HO 574 log line** in one clause: on a non-clean route the crawl now prints the actual `pageErr`/console messages (collapsed, truncated to 200 chars) on a second line, so a failing unattended run is self-diagnosing. Smoke only, for now, because of the duplication above.

**Ownership split:** oddities owns both new mechanisms (the sample-stability rule, the capture-vs-print rule). SKILL names and points. If you write the same sentence into both files, cut SKILL's copy before the commit lands.

Commit: `docs(skill): HO 575 — correct the shared-helpers claim, record the message logging`

---

## Ship — review ref, then main

1. Both commits local, explicit pathspec, never `git add .`.
2. `git push origin HEAD:refs/heads/575-review`
3. **HALT.** Report both SHAs and stop.
4. On approval: fast-forward main, delete the ref.

## Scope guards

1. Docs only. A `.ts`/`.tsx`/`.yml` file in either diff is a scope failure.
2. SKILL never shares a commit with the other docs.
3. Roadmap append-only — add a block, never edit a prior pointer or clause.
4. **Do not extract the duplicated collectors here.** File it; that's code.
5. **Do not scope the fix.** The pageErr entry records what's known and what's ruled out. No component names, no candidate fixes, no probe design.

## Verification

- **Pointer gate:** previous closer still **572**, exactly one reads **574**, every distinct N once and monotonic.
- `git diff --stat` shows markdown only.
- The duplication claim is checkable and should be re-checked rather than copied: `fit-finish.spec.ts` defines `attachCollectors` and imports only `isKnownNoise`.
- Every run id, SHA, and route in the new block resolves against Code's HO 574 report.

## Ship report

- Two SHAs, files per commit, ref name.
- Pointer gate confirmation (previous 572, new 574).
- Confirmation the `pageErr` entry carries the **scoping guard** about the still-growing route set, and that its close criterion still reads named-cause-plus-green with "named cause" marked half-met.
- The new P3 duplication entry, and confirmation SKILL's corrected `:1913` points at it rather than papering over it.
- The two oddities titles as written.
- Anything stale you found and didn't fix — list it.
