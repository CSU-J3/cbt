# HO 509 — `RecordTabs` + the `/members/[bioguideId]` redesign

## Why

The member hub is the last detail page still in the pre-328 idiom, and HO 507 just set the pattern next door. Concretely, on the live page:

- **Four unboxed strips stack above the first section** — `MemberHeader`, `MemberStats` in a bare `border-t/border-b` div, `MemberAffiliations`, `MemberFundraisingLine` — none of them a card, all floating on `--bg-base`. `/bill/[id]` absorbed exactly this shape into a bordered hero.
- **`MemberAffiliations` is a duplicate.** `MemberHeader` prints the top-2 caucus badges in its meta line (`affiliations.slice(0, 2)`); `MemberAffiliations` prints the same badges again ~40px below. On a two-caucus member the two blocks are identical.
- **The ideology axis is buried.** `MemberIdeology` (HO 421) renders *inside* the Voting-record section body, under `MemberVoteStats`, three sections down. It's the one element that answers "who is this person" at a glance and it's below the fold.
- **Six full-width sections stack to ~3,400px** — sponsored bills, amendments, committees, voting record, scorecard, trades, news — and on a typical House member two of them are empty states occupying a full box each ("No disclosed trades on file", "No recent news linked to this member").

The redesign: **hero carries the spine, one tabbed record box carries everything else.** Approved mock: `mock-509-member-hub-v2.html` (built from verbatim `globals.css` tokens + the shipped `.ideology-axis-*` / `.member-*` CSS).

This handoff also **extracts the box as a shared component**, because `/bill/[id]` is its second consumer at HO 510 (approved mock `mock-510-bill-detail-record-box.html`). Build it shared now rather than copying it later — the HO 428-A precedent.

## Ground truth

Clone / hard-reset to `origin/main` first — HEAD should be **`0108409`** (HO 508 docs). Re-grep every line reference below at write time; they're from a clone, not gospel.

## Scope

Three files: one new component (`components/RecordTabs.tsx`), one CSS block (`app/globals.css`, additive `.rec-*` + `.mhp-*`), one page rewritten (`app/members/[bioguideId]/page.tsx`). Plus up to two component deletions, gated on grep (below).

**Zero query-layer changes. No new reads, no probe.** Every tab's content comes from the page's existing `Promise.all` — all fifteen queries already run on every request today. This is chrome only.

**Row components render unchanged** — `BillRowList`, `CommitteeAssignmentRow`, `MemberVoteRow`, `MemberAmendmentRow`, `TradeRow`, `RaceNewsRow`, `MemberVoteStats`, `MemberIdeology`, `MemberFundraisingLine`, `MemberHeader`, `StageLegend`. The rows-out-of-scope convention (HO 484/496/507).

**Do NOT touch `/bill/[id]` in this handoff.** It migrates onto `RecordTabs` at HO 510, after this one proves the component in prod.

---

## 1. `components/RecordTabs.tsx` (new, `"use client"`)

The `ActivityTabs` shape exactly: a client island that holds **only** tab state and takes pre-rendered `ReactNode`s as props, so the server page keeps every fetch.

```tsx
export type RecordTab = {
  key: string;            // stable, used as React key + panel id
  label: string;          // "Bills"
  count: number;          // shown in the strip; 0 dims the tab
  outLabel?: string;      // "View all 53 bills →" — omit for no out-link
  outHref?: string;       // required when outLabel is set
  content: ReactNode;     // rendered by the server page
};

export function RecordTabs({
  tabs,
  ariaLabel,
}: {
  tabs: RecordTab[];
  ariaLabel: string;
}) { … }
```

Behavior:

- **Returns `null` when `tabs.length === 0`.** The page decides membership; the component never decides what to show.
- **Active tab defaults to `tabs[0]`** — tab ORDER is the page's contract, not the component's. (HO 510 wants the bill page ordered by weight; this page wants a fixed order. Keeping ranking out of the component is what makes it reusable.)
- **All panels mount; inactive ones carry `hidden`.** Not conditional mounting — `BillRowList` is a client component with its own expand state, and unmounting it would drop an open row on every tab swap.
- **Zero-count tabs still render, still clickable**, with `data-empty="true"` for the 50% opacity (the `.search-tabs [data-empty]` idiom). `0 disclosed trades` is a fact worth stating, not an absence to hide.
- **The out-link sits right-aligned in the strip and swaps with the tab.** Render nothing in that slot when the active tab has no `outLabel`.
- **Scroll resets to top on tab change** (`ref` on the body, `scrollTop = 0`).
- **Local `useState`, no URL param.** The page is `export const dynamic = "force-dynamic"` — a `?tab=` round-trip would re-run all fifteen queries to move a highlight. (The `?expanded=` convention on `/members` exists because that state is worth linking to; a tab isn't. If we later want shareable tabs, that's an additive `defaultTab` prop, not a rework.)
- a11y: strip is `role="tablist"` with `aria-label={ariaLabel}`, tabs are `<button type="button" role="tab">`, active carries **`aria-current="page"`** (this is the CSS hook — match `ActivityTabs`, don't invent `aria-selected` styling), panels are `role="tabpanel"` with `hidden`. Arrow-key navigation is out of scope; `ActivityTabs` doesn't have it either.

## 2. CSS — `app/globals.css`, additive

**Write a fresh `.rec-*` block. Do NOT widen `.breaking-stalls-tabs` or `.search-tabs`** to serve this — that's the HO 486 riding-regression trap, and both have consumers (the dashboard quadrant and the search page) that would move with them. A third tab-strip variant is consistent with existing practice; the box-header context genuinely differs (padding inside a bordered box, right-aligned out-link, `margin-bottom: -1px` to overlap the box border).

Pull the rules verbatim from the mock's `.rec-*` block: `.rec` · `.rec-hdr` · `.rec-tab` (+ `:hover`, `[aria-current="page"]`, `[data-empty]`, `:focus-visible`, `.count`) · `.rec-out` · `.rec-body` · `.rec-panel[hidden]` · `.rec-note` · `.rec-empty`, plus the ≤900px wrap.

**`.rec-body { height: 430px; overflow-y: auto; }`** — fixed, not `max-height`. Rationale is HO 244's `.distributions-panel-body`: a fixed body means a tab swap never resizes the box or shifts the footer. **The known cost: a 1-row Committees panel leaves ~380px of dead space.** Eyeball it in prod; if it reads badly the fallback is `min-height: 260px; max-height: 430px`, which caps the jump instead of eliminating it. Report which you'd keep — don't change it unilaterally.

Hero bands go under a new **`.mhp`** page scope (member-hub-page), the same additive-wrapper rule `.bdp` follows: `.mhp-hb1` / `.mhp-hb2` / `.mhp-hb3` / `.mhp-stats` / `.mhp-stat*` / `.mhp-mix*`. Nothing under `.mhp` may restyle `.member-header`, `.member-photo`, `.ideology-axis-*` or any `.bxp-*` rule.

## 3. Page rewrite — `app/members/[bioguideId]/page.tsx`

### Hero — one bordered card (`bg-row-hover` + `border-strong`), three bands

**Band 1 (`.mhp-hb1`)** — a flex row: `<MemberHeader>` **unchanged** as `flex: 1` (it already renders photo + name + meta chips), and a right-aligned `flex: none` stat run. This is why `MemberHeader` needs no edit — the page composes around it.

The stat run is five figures, label above value, right-aligned, tabular:
`SPONSORED 53 · ENACTED 0 (0.0%) · AVG COSPONSORS 21.9 · VOTES CAST {total − notVoting} (of {total}) · MISSED {pct}%`
The first three come from `stats` (the values `MemberStats` renders today), the last two from `voteStats`. Suppress the two vote figures entirely when `voteStats.total === 0` — don't print `0 of 0`.

**Band 2 (`.mhp-hb2`)** — `<MemberIdeology ideology={ideology} party={member.party} />` **unchanged, full width.** Note a deliberate divergence from the mock: the mock splits the axis left and a readout right, and adds a "0.06 left of the D median" line. **Don't build that** — the split would require editing `MemberIdeology`, and the delta line is a computed stat that doesn't exist today. Chrome handoff, no new numbers. Render the component as-is; the promotion out of Voting record is the whole win here.

**Band 3 (`.mhp-hb3`)** — a 3-up grid across the hero's full width, `0.5px solid var(--border-soft)` dividers between cells. This is the metabox unrolled sideways:

1. **SEAT** — `House · Georgia 5th · sworn {n}` / sub-line `119th Congress · {committeeAssignments.length} committee assignments`. Use only fields already on `member`; if a "sworn in" year isn't on the record, drop that clause rather than deriving one.
2. **NEXT ELECTION** — the year + `RatingChip`-colored rating (the same `headerRating` the meta chip uses), and **the primary line moves here** from its current standalone position under `MemberHeader`, including the `≤30d` red day-count branch. Cell absent entirely when `member.nextElectionYear` is null.
3. **FUNDRAISING** — `<MemberFundraisingLine fundraising={fundraising} />` **unchanged** (it already renders the numbers, the donor-mix bar and the FEC link, and already returns `null` when there's no row).

**Empty-cell rule:** cells with nothing to render are omitted and the grid becomes 2-up or 1-up — no empty thirds. Same shape as `.bdp-pair`'s lone-survivor branch.

**`MemberAffiliations` is deleted from the page** — the header meta line already carries the badges, and the standalone block was printing them twice. `grep -rn "MemberAffiliations" app/ components/`: if `/members/[bioguideId]` is the last consumer, **delete `components/MemberAffiliations.tsx` in this same commit** (the orphaning is caused by this change — the HO 507 `TopicTags` precedent, not the ride-along-refactor class). If another consumer surfaces, leave the file and report. Note `getMemberAffiliations` **stays** — `MemberHeader` consumes it.

Same grep, same rule, for **`MemberStats`**: its three tiles are absorbed into the band-1 stat run. If single-consumer, delete; if not, leave it and report.

### The record box

One `<RecordTabs ariaLabel="Member record" tabs={[…]} />` replacing all six sections. Fixed order (rationale: authoring → voting → assignment → coverage, most-used first; not count-ranked, because a member page should open the same way every time):

| # | Label | Count | Out-link | Panel content |
|---|---|---|---|---|
| 1 | Bills | `stats.billsSponsored` | `View all N bills →` → `/bills?sponsor=` **only when `stats.billsSponsored > bills.length`** | `<StageLegend/>` in a `.rec-note` sticky strip, then `<BillRowList bills watchedIds nowMs/>`. Empty → `No bills sponsored`. |
| 2 | Votes | `voteStats.total` | none (no `/members/[id]/votes` route exists — **verified, don't invent one**) | `<MemberVoteStats stats chamber/>` as the sticky `.rec-note` line, then the existing `.vote-header-row` + `MemberVoteRow` list. Empty → the existing chamber-specific copy. |
| 3 | Committees | `committeeAssignments.length` | none (each row links its own committee hub) | the existing `<ul>` of `CommitteeAssignmentRow`. Empty → `No committee assignments on file.` |
| 4 | Amendments | `sponsoredAmendments?.length ?? 0` | none (`/amendments` has no sponsor filter — HO 461 params are `type`/`disposition`/`bill`/`page`) | `MemberAmendmentRow` × `MEMBER_AMENDMENT_LIMIT` (60), the `N more` foot preserved. Empty → `No amendments sponsored`. |
| 5 | Press | `news.length` | none (`/news` carries `source`/`topic`/`window`/`bill`/`signal` only — **no `member` param**, HO 501) | `RaceNewsRow` × N with `nowMs`. Empty → `No recent news linked to this member.` |
| 6 | Trades | `tradeCount` | `View all N trades →` → `/trades?member=` **only when `tradeCount > trades.length`** | the existing `.trade-header-row` + `TradeRow` list. Empty → `No disclosed trades on file`. |
| 7 | Scorecard | `scorecard` present only | `via USCPR ↗` (the existing Google Sheets href) | the existing grade + score + rank block and the per-vote outcome list, unchanged. |

Two convention changes to state in the commit message so nobody reads them as drift:

- **The amendments section's hide-when-empty rule (HO 450) is superseded.** It existed because an empty section cost a full box; a dimmed tab costs ~90px of a strip that's rendering anyway, and `AMENDMENTS (0)` is a truer readout for a House member than silence. Same reasoning admits Press and Trades as permanent tabs.
- **Scorecard is the one conditional tab** — it's genuinely inapplicable (Senate Democrats only, 47 of 535), not merely zero.

Everything above the tabs — `HeaderBar`, the `← Back to members` link, the member-not-found branch — is unchanged. Preserve the HO 490 `nowMs` threading into `BillRowList` and `RaceNewsRow`.

### Footer

One row, the `.bdp-foot` shape minus the raw-JSON `<details>` (there's no raw member JSON): `← Back to members` button, and right-aligned `margin-left: auto` attribution — `Member data via Congress.gov · Ideology via Voteview · Fundraising via FEC`. The mock's second `Open in feed →` button is decoration; drop it.

---

## Verification

Prod-verify across these shapes — pick real bioguides, don't assume:

- **`W000788` (Williams)** — the mock's subject: 53 bills, 0 amendments, 0 trades, 0 news, 3 committees, no scorecard. Four dimmed tabs, hero 3-up complete.
- **A heavy amender** — `B001267` (Bennet, 271): the capped 60 + `211 more` scrolls **inside** the 430px body, doesn't set page height.
- **A member with trades** — pick the top `bioguide_id` by `stock_trades` count: the trades tab renders its six-column grid at full box width and the out-link appears.
- **A Senate Democrat with a scorecard** — the seventh tab appears; on everyone else it's absent, not empty.
- **A member with no `member_ideology` row** — band 2 renders `MemberIdeology`'s own empty state, no gap artifact.
- **A member with no fundraising row** — band 3 collapses to 2-up, no empty third.
- **A freshman with no committees** — the tab reads `(0)`, dimmed, and its empty state renders.
- **An unknown bioguide** — the friendly not-found branch still renders (not Next's `notFound()`).
- **Tab mechanics** — expand a bill row, switch tabs, switch back: the row is still open (the mount-all-panels contract). Out-link swaps with the tab. Body scroll resets on swap.
- **≤900px** — bands stack, the stat run left-aligns, the tab strip wraps, the out-link drops below.
- **`/bill/[id]`, `/bills`, `/lobbying` unchanged** — diff `globals.css` and confirm no `.bxp-*`, `.bdp-*`, `.mc-*`, `.search-tabs` or `.breaking-stalls-tabs` rule was edited. All new rules are `.rec-*` / `.mhp-*`.
- **`npm run typecheck`** green (CI runs it; the HO 490 `nowMs` required-param contract applies to every age call you touch).

## Git discipline

- Clone / hard-reset to `origin/main` first; HEAD `0108409`.
- Explicit pathspec staging; never `git add .`. Expected: `components/RecordTabs.tsx` (new), `app/globals.css` (the `.rec-*` + `.mhp-*` blocks only), `app/members/[bioguideId]/page.tsx`, plus `components/MemberAffiliations.tsx` and/or `components/MemberStats.tsx` **deletions if and only if the grep confirms single-consumer**.
- **Live UI → show the actual diff hunks and wait for approval before committing.** Report both greps before you delete anything.
- One commit: `feat(members): member hub redesign — hero + shared RecordTabs box (HO 509)`.
- Ancestry eyeball before push (`git log --oneline @{u}..HEAD` — exactly one commit riding, clean fast-forward, no concurrent-session files). Fast-forward only.
- **No docs in this commit.** The roadmap/backlog/SKILL sweep is a later HO, after `/bill/[id]` migrates at 510.

## Report back

The page diff, the `globals.css` hunk, `RecordTabs.tsx` in full, both grep results, your read on the fixed-430px dead-space question, and the prod-verify list above.

---

read docs/handoffs/509-member-hub-record-box.md and follow it
