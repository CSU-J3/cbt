# HO 564 — the House roster-erasure fix (P1, live)

HO 563 M3 measured **12 of 40 sampled resulted House districts (30%) returning `no_section` on a live scrape**, every one of them holding results, every one of them one cursor visit from `syncHouseDistricts`' fall-through deleting its roster and inserting nothing. This is not a hazard to guard against later. It is a loop that is running now, and the cursor sits mid-sweep at house offset 288 of 435, so the next ~147 districts get visited over roughly the next six days.

**HO 560 C3 doubled the rate.** Taking the primaries cron to twice daily was correct for the SC special and it also doubled how fast this erases. That is on this arc, and the fix is the answer rather than reverting the cadence.

The 143 zero-candidate rows are partly this bug's own past victims: M2 found **66 of 96** districts parse fine live while sitting empty in the database, which is the signature of a roster that was deleted and has not yet been rewritten.

## §0 — Preconditions

1. `git fetch && git status` clean, `main` even with `origin/main`, `git rev-parse HEAD` = `921e752`.
2. `npm run typecheck` clean.
3. Read `syncHouseDistricts` in `lib/primaries-sync.ts`: the status fork at **L713 / L721 / L735 / L739** and the write block that follows, plus `syncSenateCandidates`' equivalent per-contest write. Read `scripts/diagnostic/zero-candidate-primaries-563.ts` for the M2/M3 queries.

## §1 — The rule

**A sync must never convert absence of evidence into deletion.** Concretely, across both chambers:

- The per-contest `DELETE FROM primary_candidates` runs **only when the incoming roster for that contest is non-empty**. Replacing something with nothing is never an authoritative act, because the two causes (the contest genuinely emptied, versus the page stopped parsing) are indistinguishable at that point and one of them is destructive.
- **`no_section` must not create a `primaries` row.** A missing `Candidates_and_election_results` anchor after three retries is a parse failure, not evidence a contest exists. Fall through to the empty-districts log and `continue`.
- **`no_candidates` may still create the row** (a reachable, parsing page with zero candidates is a legitimate uncontested contest, which is HO 563's benign slice of 17) but **must not delete an existing roster**, which the rule above already secures.

This generalizes the HO 560 lesson rather than repeating it. That guard refused a *rewrite* on a settled row, which is substitution. This refuses a *delete* backed by nothing, which is erasure. HO 563 §3 called that distinction and M3's non-zero result settles it.

## §2 — STEP 0 (read-only, inline, report before touching code)

Baselines the fix has to be measured against, all from the DB, no network:

**S1** — count House `primary_candidates` rows and the number of House contests carrying at least one row, plus the count carrying at least one `vote_pct`. These are the numbers that must not go down.

**S2** — re-run HO 563's M1 zero-candidate count so the repair in §4 has a before figure on the same day.

**S3** — the Senate exposure, unmeasured until now: how many Senate contests currently hold a roster, and how many of those are **not** protected by the HO 560 settled freeze (past-dated with no share, or future-dated). Those are the rows the same edge could erase on an `ok` parse that returns an empty per-contest roster. Report the count; §3 C2 fixes it regardless, but the number belongs on the record.

## §3 — Build

**C1 — House.** In `syncHouseDistricts`: move `no_section` up to `continue` beside `special` and `no_page`, leaving `no_candidates` on the row-creating path; and gate the per-contest `DELETE`+insert on `roster.length > 0`. Keep every existing log bucket populated (`emptyDistricts` must still record what was skipped and why, now distinguishing the skipped-parse-failure case from the empty-but-parsed case).

**C2 — Senate.** Apply the same `roster.length > 0` gate to the per-contest write in `syncSenateCandidates`. The status fork there already `continue`s on every non-`ok` status, so no fork change is needed; the exposure is only the empty-per-contest-roster path on an otherwise good parse. Do not touch the HO 560 settled guard or the HO 561 special pass, both of which sit in this function.

**Surface what was refused.** Add a counter to both summaries (`rosterDeletesRefused` or similar) listing the primary ids where a delete was declined, so the cron payload shows the guard working instead of the guard being invisible. A protection nobody can see is the thing this project keeps writing WATCH entries about.

## §4 — Falsification, then repair

**Falsify first, per the HO 549 / 553 discipline. Neither branch may be recorded as protection until it has fired.**

On current HEAD, in scratch only, never committed: force `scrapeHouseCandidates` to return `no_section` for one district that currently holds a roster, run the sync for that district, and confirm the roster **survives** and the refusal is logged. Then force an `ok` parse whose per-contest roster is empty for a rostered district and confirm the same. Revert, confirm `git status` clean, commit nothing. If the local environment cannot drive that, say so and record UNPROVEN in a WATCH rather than claiming the guard works.

**Then repair.** With the fix landed, re-run the House sync across all four regions so the 66 parse-fine-but-empty districts repopulate, and re-measure S2's zero-candidate count. Expect it to fall toward the roughly 30 that genuinely do not parse or are genuinely uncontested. Report before and after. If the number does not move, the fix addressed a different bug than the one M2 described and that needs saying.

## §5 — Scope guards

1. No cron, `vercel.json`, cadence, slice-constant, or `DEADLINE_MS` change. **The cadence stays at twice daily**; the fix removes the loss, so halving the rate of a fixed bug buys nothing and adds churn.
2. No edits to `lib/primary-candidates-scrape.ts`. The parse statuses are correct; this is about what the caller does with them.
3. No change to the HO 560 settled guard or the HO 561 special-page pass and dated trigger.
4. No migration, index, schema, or seed change.
5. No backfill script. Repair rides the existing sync, which is the point of fixing the writer rather than patching the data.
6. Do not touch `docs/`. The sweep is its own HO.

## §6 — Commits, ref, gates

1. `feat(primaries): HO 564 C1 — never delete a House roster on a non-parsing scrape`
2. `feat(primaries): HO 564 C2 — same non-empty-roster gate on the Senate write`
3. Push to `refs/heads/564-review`, report STEP 0, the falsification transcript, the repair before/after, and the SHAs. Halt. No diffs pasted.
4. On approval: ancestry eyeball, fast-forward, delete the ref.

**Gates:** diff = 1 file, 2 commits · S1's three counts unchanged or higher after the repair run · `git status` clean after falsification with nothing from the scratch edits committed · no diff under `docs/`, `data/`, `scripts/`, `components/`, `app/`, or `vercel.json`.
