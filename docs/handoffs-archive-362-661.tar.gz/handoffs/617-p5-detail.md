# HO 617 — P5: the detail routes. One big route, four small ones, and the C3/C4 remainder table.

HEAD `1b9d334`. Pointer "run through HO 615." **Next free is 617.** Baseline v3: `/committee-detail` **28 · M2 2 · M4 662px** — four fifths of the phase, and the last stretched panels outside `/electoral` — then `/bill-detail` 4 (M4 129px) · `/member-detail` 4 (**M4 2,312px**) · `/vote` 3 · `/race-detail` 0. Sweeps wait for the arc close; this HALT feeds it.

The kit and the registry are law and are not restated: decompose from the artifact before designing, applied curves only, wrap-don't-pin, minmax-not-fixed, both-ends derivation, `M1x <candidates>/<rows>` for any marking, fixture legs before any trusted zero.

## 1. Commit 1 — `/committee-detail`

Decompose the 28 + the 2 M2 + the 662px from the artifact's worst-10 first; the page's imports say the likely families, and each has a standing answer:

- **`BillRow` / `NominationRow` lists** — both packed in P4; any hits here are the committee page's own wrappers or headers around them, not the rows. Fix the wrapper, don't reopen the row.
- **`CommitteeActivityChart` / `CommitteeTopicDistribution`** — if their rows are the hits, that's the registry question again: clause 1 by inspection (real bars? shared origin?), clause 2 by an **applied** curve, attribute on the table, entry queued. If they're SVG they never entered M1 and the hits are their headers.
- **The two M2 panels** — decompose to cause: `align-items` stretch from a sibling (the `start` fix) or reserved height (the C4 collapse). Name which before fixing.
- **`GroupTabs` / page headers / the 662px** — standard pack and collapse.

Score: `--route committee-detail` → M1 ~0 decomposed, **M2 2 → 0** (the site's M2 then reads 6, all `/electoral` + `/bills`), M4 → near-0 named.

`fix(committee): HO 617 — committee detail packed; the last non-electoral stretched panels die (C1/C4/C7)`

## 2. Commit 2 — the small four

`/member-detail`'s 2,312px M4 is the one item here that isn't routine — decompose it (expected: a reserved empty-state panel that C4 collapses to a line, but expected is not measured). Then the 11 M1 across `/member-detail`, `/bill-detail`, `/vote`: standard kit, per-route decomposition in the HALT. `/race-detail` at 0 gets a verify-only line. `pre.bdp-rawpre` on `/bill-detail` at 720 is already classified scroll-by-design — cite the backlog entry, do not chase it, do not widen M5x.

One commit if the fixes stay small; split and say so if any route grows.

`fix(detail): HO 617 — member/bill/vote detail packed; the 2,312px reserved panel collapses (C1/C4)`

## 3. P5 closes by its scope list

The HALT prints the five-route table — `committee-detail · bill-detail · member-detail · vote · race-detail` — each with v3 numbers and a permitted disposition (worked-to-zero / accepted-residue-decomposed / exempted-with-curve). Second enforcement of the SKILL rule; same standard as P4's.

## 4. The C3/C4 remainder table — P6's scope list, set from data

After the route work, print the **site M2 / M3 / M4 remainder** per route. P6a and P6b close on C3/C4, and their scope lists should come from this table, not the plan's snapshot — `/bills` carries **5,123px** of M4 the four-HO plan never named, `/changes` 31,323px, `/stale` 20,123px, `/patterns` 1,983px, and whatever this HO's own work moves. The table is the P6 handoffs' opening premise; getting it here means neither inherits a stale list, which is the scope-list rule applied *forward* for once.

## 5. Verification and guards

1. Commits in order, typecheck + build each, explicit pathspecs; fixture legs before any zero.
2. Per-route v3 tables; spot-unmoved: `/`, `/members` (13), `/trades` (1), `/amendments` (0 + M1x 94).
3. Narrow buckets for the two worked routes at 1024/900/720, (a)/(b)/scroll-cited split.
4. Any marking: applied curve in the commit body, registry queue with both units, site M1x arithmetic restated.
5. Eyeball 1440/2560 both worked routes, one committee with a big roster and one with none (the C4 case), one bill with amendments and one without. Prod-verify converged. **HALT** with the scope table, the remainder table, the decompositions. No P6 work, no sweep.
6. Absence Watch untouched. `--fs` tokens 9–14px. `/stale` and `/changes` untouched — P6a's, and the remainder table is the only thing this HO owes them.
