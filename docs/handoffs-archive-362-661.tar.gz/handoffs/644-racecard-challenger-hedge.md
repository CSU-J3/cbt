# HO 644 — the card stops rendering an unknown as a finding

**Ground truth:** `main` at `a487b31` once 643-review lands. Roadmap's pointer reads **643**, so this is **644**.

Authorised by R1 (roadmap, HO 642–643 block). One commit. Small diff, and the reason it took three probes to get here is that the exhibit and the class had different fixes.

**Measured, not assumed:** across 186 rated seats, **129 reach `challenger.kind === "empty"` and 0 of them are true-empty**. The branch has never once rendered a true statement. `/electoral`'s `RaceMapCard` already renders the same underlying state correctly. This is a copy, not a design decision.

---

## §1 — `lib/race-matchup.ts`

`deriveMatchup(row, candidates)` receives the raw roster, so it can make the distinction itself. **No caller changes.**

Add a fourth variant:

```ts
export type ChallengerShape =
  | { kind: "empty" }
  | { kind: "unknown" }
  | { kind: "nominee"; ... }
  | { kind: "leader"; ... }
  | { kind: "nolead"; ... };
```

Change the initialiser (`:174`) so the discriminator is the roster's existence, not the active set's:

```ts
// HO 644 — these are two different states and the card rendered both as one.
//   candidates.length === 0  -> nothing has ever been harvested for this seat.
//     The card knows NOTHING about the challenger field. `unknown`.
//   candidates.length > 0, active.length === 0 -> a roster exists and contains
//     no active non-incumbent. That is a real finding. `empty`.
// Measured at HO 642 P1: 129 of 186 rated seats are the first case and ZERO are
// the second, so the branch that shipped ("no challenger filed") has never once
// been true. See roadmap R1.
let challenger: ChallengerShape =
  candidates.length === 0 ? { kind: "unknown" } : { kind: "empty" };
```

Everything below it is untouched — `active.length > 0` overwrites either initialiser exactly as it does today.

**Name the sub-case in the comment, do not build for it.** `activeChallengers` filters withdrawn and ineligible candidates, so a roster whose challengers have all withdrawn reaches `empty` and renders "no challenger filed" — arguably wrong for a field that was filed and vacated. It has no members today. Flag it in the comment so the next reader doesn't discover it as a surprise; a third variant on zero evidence is the mistake this HO is fixing.

---

## §2 — `components/RaceCard.tsx`

Add the `unknown` branch beside the existing `empty` one (`:192`). **Verbatim from `components/RaceMapCard.tsx:216`** — the two surfaces describe one state and they must not diverge again:

```tsx
} else if (challenger.kind === "unknown") {
  challengerInner = (
    <>
      <span className="rc-dot8 is-hollow" />
      <span className="rc-nm rc-nm--empty">Challenger field not yet available</span>
      <span className="rc-line-meta">—</span>
    </>
  );
}
```

Leave the `empty` branch exactly as it is. Reuse `.rc-nm--empty` (`--text-dim`) and `.rc-dot8.is-hollow` — **no new CSS**; a hedge and a negative finding are both absences and read the same.

**If the longer string overflows at any rendered card width, shorten BOTH sites in the same commit.** Never let the two surfaces drift apart again — that divergence is the whole defect.

---

## §3 — Falsification: fire the branch that just lost all its members

After §1, `empty` has **zero live members**. An unexercised branch is unproven, not protection (HO 552), and this one is about to be recorded as the correct handling of a case nothing in the corpus produces.

Prove the discriminator routes correctly with a **scratch call** to `deriveMatchup` — real function, real logic, no monkey-patching — passing a hand-built `candidates` array of one withdrawn candidate. `candidates.length > 0` and `active.length === 0`, so it must return `{ kind: "empty" }` and **not** `unknown`. Confirm it, then delete the scratch. `git status` clean. **Commit nothing.**

This is the whole falsification. The render side needs none: `empty`'s JSX is unchanged and currently exercised on 129 seats, and `unknown` inherits those 129 the moment §1 lands, so both render paths run on real data.

---

## §4 — Scope, proven rather than assumed

`deriveMatchup` / `ChallengerShape` have exactly **two** consumers:

- `components/RaceCard.tsx:120` — the surface being fixed.
- `components/CompetitiveRacesStrip.tsx:111` — reads `.presumptiveParty` **only**, which this change never touches.

`RaceMapCard` (`/electoral`) does **not** import either. Confirm that with your own grep before editing rather than taking this file's word for it, then verify `/electoral` renders byte-identical after — it is the surface whose string is being copied, and it must not move.

---

## §5 — Verification

1. **S-MI-2026** on the dashboard RACES tab renders the hedge, not "no challenger filed".
2. **PA-10-2026** still renders Janelle Stelson as nominee — it has one hand-curated row, so it must take the `nominee` path and prove the fix didn't swallow populated rosters.
3. **"no challenger filed" appears zero times** in the rendered dashboard. That is the positive check that the class moved rather than the exhibit: 0 true-empty measured, so 0 renders expected. A non-zero count means the discriminator is wrong.
4. `/electoral` unchanged.
5. `npm run typecheck` clean. Explicit pathspec staging, ancestry eyeball, fast-forward only.

Check `/api/version` before believing any of this on prod — the Data Cache survives deploys and the race queries carry the `races` tag. Hit until the value converges and holds.

---

## §6 — Not in this HO

**Do not run `backfill:race-challengers`.** R2: reach stops at `primary_date` 2026-06-02, only 62 of the 129 are derivable, and running it would close under half the class while making the S-MI exhibit go green — which is precisely the move that would have closed the wrong question three probes ago. It is separately scoped in backlog.

**Do not build the market-vs-roster detector.** R3: M3 is 88 of 186, and an alarm firing on 47% of the rated set reads the harvest's staleness. Its trigger is a re-measurement, not this commit.

**Do not touch the 2024-margin gap.** Its own backlog line.
