# HO 393 (rev) — Build: UDP independent-expenditure DIRECTION on competitive race cards

Confirm the number before saving: `ls docs/handoffs/ | sort -V | tail`. Keep this as `393-pac-ie-race-cards.md` — it **supersedes the halted dollar-figure build of the same number**. If the repo has the prior 393, overwrite it.

## Read this first — what changed and why

The prior 393 tried to ship dollar figures and correctly HALTED at the reconcile gate: FEC Schedule E has no clean dollar source. Raw sums ~5×; the periodic/`by_candidate` paths silently drop recent notice-only spend, which zeroed out UDP's two largest 2026 targets (Stevens $14.7M, Boafo $11.5M); and the committee-reported total is itself periodic-lagged, so it can't anchor a reconciliation. Only per-transaction `back_reference` dedup is correct, and there's no external oracle to validate it against. Full write-up already banked in `docs/oddities.md` (commit fd8eb7c) — **don't re-add it.**

This rev drops dollars from the app entirely. We ship **direction** — who UDP is backing and opposing in each race — which is a per-row fact in the raw data, needs zero dedup, and is never wrong. The magnitude (the actual "$14.7M backing Stevens" story) is delivered by **deep-linking each direction to the live FEC filings**, so the reader sees the real numbers at the source without the app asserting a total it can't stand behind. Same posture as USCPR: show the signal, link the source, don't reproduce it as gospel. The `amount` column stays in the schema but nullable and unpopulated, so an audited dollar backfill can layer in later without a rebuild.

## Resolved premises (HO 392/393, verified live — don't re-derive)

- **Sole spender:** UDP `C00799031`, Super PAC (IE-only). DMFI is a rounding error; the AIPAC connected PAC bundles direct contributions (Schedule A/B), not IEs. UDP is the whole feature.
- **Fields present in raw Schedule E:** `candidate_id`, `candidate_name`, `support_oppose_indicator` (S/O), `expenditure_date`, `candidate_office` (H/S), `candidate_office_state`, `candidate_office_district`.
- **Direction + dates are clean from raw rows.** `support_oppose_indicator` is a per-row fact, unaffected by double-counting; MIN/MAX `expenditure_date` over duplicated rows still gives the true span. No dedup needed for either.
- **Dollars are OUT this rev** (see above). Deferred to backlog with the reason.
- **Join key:** `candidate_office`/`candidate_office_state`/`candidate_office_district` → `races(chamber, state, district, cycle)` → `race_id`, resolved by table lookup. No `fec_candidate_id` backfill; `members.fec_candidate_id` is the wrong join (incumbents only) and belongs to the deferred member overlay.
- **Coverage:** ~8 UDP targets, ~6 land in tracked races, ~3 cards light up (IL-07, S-MI, KY-04). Targets outside the rated set (MD-05, NJ-11) get logged, not shown.

## Data model

```sql
pac_ie_spending (
  id             INTEGER PRIMARY KEY,
  committee_id   TEXT NOT NULL,     -- 'C00799031'
  spender        TEXT NOT NULL,     -- 'UDP'
  race_id        TEXT NOT NULL,     -- resolved at sync time
  candidate_id   TEXT NOT NULL,     -- FEC candidate id (target) — also builds the FEC deep-link
  candidate_name TEXT NOT NULL,
  support_oppose TEXT NOT NULL,     -- 'S' | 'O'  — the payload
  amount         REAL,              -- NULLABLE, reserved for a future audited backfill; unpopulated in v1
  earliest_date  TEXT,              -- MIN(expenditure_date) for this candidate × S/O — powers "since May"
  latest_date    TEXT,              -- MAX(expenditure_date) — freshness, available if wanted
  cycle          INTEGER NOT NULL,  -- 2026
  as_of          TEXT NOT NULL,     -- sync timestamp
  UNIQUE(committee_id, candidate_id, support_oppose, cycle)
)
```

Grain: one row per (committee, target, support/oppose, cycle). ~8–12 rows. Index on `pac_ie_spending(race_id, cycle)` for the card lookup. Idempotent upsert on the UNIQUE key.

## Sync (`scripts/sync-pac-ie.ts`, `npm run sync:pac-ie`)

Reuse the existing FEC client / base / `FEC_API_KEY` from the donor-mix code. Cycle constant `PAC_IE_CYCLE = 2026`. This is now a straight pull — no `by_candidate`, no dedup, no reconciliation.

1. Pull raw `schedule_e` for `committee_id=C00799031`, cycle 2026.
2. Collapse to distinct `(candidate_id, candidate_name, support_oppose, office, state, district)`, with `MIN`/`MAX(expenditure_date)` per group. No dollar aggregation.
3. Resolve `race_id` by lookup, not string-building: `SELECT race_id FROM races WHERE chamber=? AND state=? AND district=? AND cycle=2026`, mapping office H→house / S→senate and matching the races table's district format (FEC is 2-digit zero-padded, '00' at-large; Senate has no district). No row → drop the target and log it (office/state/district) so coverage gaps stay visible.
4. Upsert resolved rows on the UNIQUE key, `amount` left NULL, dates populated, `as_of` stamped.
5. Fold into the existing FEC cron (daily is fine). Mind the api.data.gov rate limit shared with the Congress.gov key.

No dollar reconciliation gate this rev — no dollars are shipped. The only correctness checks are that each row's `race_id` resolves and (below) each FEC link renders the right filtered view.

## FEC deep-link — verify before wiring

Each direction line links to the live FEC independent-expenditures browser, filtered to UDP + that candidate + direction, so the reader sees the actual expenditures (dates, amounts) at the source. Intended URL shape:

```
https://www.fec.gov/data/independent-expenditures/?committee_id=C00799031&candidate_id=<candidate_id>&support_oppose_indicator=<S|O>&two_year_transaction_period=2026
```

**Confirm this resolves before wiring it.** Construct the Stevens link, load it, verify it renders UDP's IEs targeting her (and only her). A link that 404s or shows unfiltered data is worse than no link. If the browser uses different param names than the API, adapt the builder. Store nothing extra — the link is built from `committee_id` + `candidate_id` + `support_oppose` already on the row.

## Surface — competitive race card

Locate the competitive race-card component (COMPETITIVE RACES on the dashboard + `/races`). Add a `PAC SPENDING` line, conditional: render only when `pac_ie_spending` has rows for that `race_id`; absent otherwise, no empty slot (USCPR-badge convention).

Format, compact, in the existing card chrome:

```
PAC SPENDING · via FEC
UDP  backing Stevens ↗   opposing Massie ↗   · since May
```

- `S` → "backing [name] ↗", `O` → "opposing [name] ↗"; each name/arrow is the FEC deep-link for that candidate × direction. Format `candidate_name` (LAST, FIRST → First Last) or borrow the cleaner name from the race roster if trivial.
- "since {month}" from `earliest_date`, subordinate — if it crowds the card, drop it; direction + link is the core.
- Neutral visible label. The spender's full identity ("United Democracy Project — AIPAC-affiliated super PAC · via FEC") lives in the tooltip, mirroring USCPR attribution. **Open decision for Corey:** whether the visible label reads "UDP" or names AIPAC directly — surface it in the ship report, don't decide it unilaterally.
- Fit the established rating-chip / attribution idiom. If the line forces a card layout change, **stop and flag for a design pass** — data-label additions don't need design review, layout changes do.

## Cache / revalidate

If the card query gets a new `unstable_cache` tag, allowlist it on the revalidate route (first self-flush 400s silently otherwise). The sync revalidates the race-surface tag after upsert.

## Ship

Named pathspecs only (parallel sessions share the tree). Build, typecheck. Present the diff summary for greenlight before pushing. On greenlight:

```
git add lib/queries.ts scripts/sync-pac-ie.ts <card component> <schema/migration> package.json <revalidate route if touched>
git commit -m "feat(races): UDP independent-expenditure direction on competitive race cards (HO 393)"
git push
npm run verify:deploy
```

## Docs (separate commit)

- **docs/oddities.md** — already banked (fd8eb7c). Do NOT re-add.
- **SKILL.md** — under the races surface: `PAC SPENDING` direction line, `pac_ie_spending` table (`amount` nullable/reserved), UDP-only scope, office/state/district→race_id join, per-candidate FEC deep-link, and a one-line pointer that in-app dollar figures are deferred (see the oddities note).
- **docs/backlog.md OPEN LOOPS** —
  (a) **Audited dollar backfill (deferred).** Populating `pac_ie_spending.amount` needs per-transaction `back_reference` dedup, and there is no external oracle to validate the result (the committee total is periodic-lagged). That's standing per-cycle / per-spender validation burden for what is currently 3 cards. Revisit only if pro-Israel-PAC money in races becomes a real multi-spender / multi-cycle theme where the dedup infra amortizes. Column already reserved; direction + FEC deep-link ships the story without it.
  (b) Member-hub IE overlay deferred (office/state/district join works for races; `members.fec_candidate_id` catches incumbents only — best-effort, separate scope).
  (c) Coverage gap: UDP targets outside the rated race set (MD-05, NJ-11 today) don't surface until those races are added — expected, revisit as the primary calendar heats up.
  (d) DMFI (`C90022864`) is a trivial fast-follow if a second spender is ever wanted — same shape, smaller.

```
git add SKILL.md docs/backlog.md
git commit -m "docs: PAC SPENDING direction feature, deferred dollar backfill + IE overlays"
```

## Out of scope

- Dollar figures rendered in-app (deferred; delivered via FEC deep-link instead).
- Transaction-level dedup (deferred with the dollar backfill).
- Member-hub IE overlay (incumbent-only join).
- DMFI and any non-UDP spender.
- Adding new races to surface outside-set targets.
- The AIPAC connected PAC's bundled contributions (Schedule A/B).
