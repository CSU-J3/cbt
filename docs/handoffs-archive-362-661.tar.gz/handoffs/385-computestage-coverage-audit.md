# 385 — computeStage coverage audit

**Self-claim:** if `docs/handoffs/385-*.md` exists, bump to the next free number (`ls docs/handoffs/ | sort -V | tail`) and rename before starting.

**Scope:** close the computeStage under-recognition gap the 384 would-regress review surfaced. Add rules for the action-text patterns computeStage currently misses, unit-test them, re-check the corpus, report the residual. Pure-function change in `lib/enums.ts`, plus an optional incremental backfill if the new rules surface under-stored rows. Show the diff, hold for approval.

## Why (resolved premises)

- 383 made `computeStage(latestActionText)` the sole stage authority; the runner ignores the LLM's stage. 384's dry-run confirmed the forward path and backfill are working.
- 384's would-regress bucket (1,530 bills, all correctly held by the `decideStage` guard) exposed where computeStage under-recognizes: it returns introduced/committee for action texts whose elevating signal its keyword rules don't cover. The LLM read the richer text and set the correct higher stage; those bills are safe today only because they carry that higher LLM-set stored value and the guard keeps it.
- The exposure is forward-only and narrow: a future bill whose sole stage-elevating signal is an unrecognized pattern, with no prior catchable action and no LLM value to lean on (383 removed that), under-stages. The existing 1,530 are not at risk.
- 384 handed us the exact pattern list. This handoff closes the catchable subset.

## Patterns to cover (ground each in the would-regress corpus before assigning)

Candidate mappings from the review. Pull real `latest_action_text` examples for each from the would-regress set and confirm the rung before writing the rule:

- **Cross-chamber receipt → `other_chamber`:** "Received in the Senate", "Received in the House", "Held at the desk". These imply passage in the originating chamber, so the bill has cleared one chamber.
- **Floor-stage → `floor`:** "Placed on the Union Calendar", "Placed on the Senate Calendar", "Submitted ... and agreed to", "Agreed to in [House/Senate]" / resolution "agreed to".
- **Committee-activity → `committee`** (the introduced→committee misses): "Forwarded by Subcommittee", "Hearings held", "Subcommittee Consideration", "Ordered to be Reported", "Marked up".

**Resolve one semantic question first:** does the `floor` rung mean "passed a chamber's floor" or "at floor stage (reported / on calendar / passed)"? Calendar-placement is reported-but-not-passed. If `floor` means passed, calendar maps to `committee`, not `floor`; if it means at-floor-stage, calendar maps to `floor`. The LLM put calendar bills at `floor` in the would-regress data. Resolve from how the rung is used elsewhere (the funnel's semantics) and pick consistently, don't guess per-rule.

## Constraints

- Slot new patterns at their rung in the existing ordered ladder (enacted → president → other_chamber → floor → committee → introduced, first match wins). Do not reorder existing rules and do not touch the 383 guards (Senate-officer false positives, post-passage procedural → floor).
- Keep the `computeStage(latestActionText)` signature. Latest-action text only. Cases where the elevating action is a *prior* action not present in the latest text are structurally uncatchable here; those are the residual to report, not to solve by re-architecting the signature in this handoff.

## Steps

1. Pull the would-regress set, group by distinct `latest_action_text` shape, confirm the candidate mappings against real examples, resolve the floor-rung question.
2. Add the rules to `computeStage`. Extend the unit suite (383 had 16/16): a case per new pattern asserting the expected rung, plus a guard that no existing case regressed.
3. Re-run 384's dry-run with the updated function. Report any **incremental advances** (bills now computing higher that are currently stored lower than the new computed value). If there are any, that's a small follow-up apply under the same 384 discipline: advance-only, `stage` column only, dry-run already shown, go/no-go before writing.
4. Report the **residual would-regress count**: how many bills still have stored > computeStage after the new rules, i.e. the cases uncatchable from latest-action text alone. This number gates HO 386.
5. Show the diff (`lib/enums.ts` + tests), hold for approval. No deploy until approved.

## Report back

The confirmed pattern→rung mappings, the floor-rung decision, unit results, incremental-advance count (and dry-run if any), and the residual-uncatchable count.
