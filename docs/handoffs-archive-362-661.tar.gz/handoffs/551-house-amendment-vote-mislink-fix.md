# HO 551 — House amendment-vote mislink: procedural roll calls rendering as amendment outcomes (P1)

Number from the roadmap pointer + the HO 549/550 sequence. HO 550's M5 found it; this fixes it. **The motion-aware surface is NOT in scope** — it's a legitimate GO but it's a separate build, and this is wrong data serving now.

## What's wrong

`lib/amendment-votes-walk.ts` (HO 532) links **every** `recordedVotes` entry off a HAMDT's `/actions`, with no question filter. The Senate materializer does the opposite — `SENATE_AMDT_Q` is anchored to the up-or-down form and procedural votes are deliberately excluded. So the two chambers disagree about what counts as an amendment's vote, and the House side lets motions through.

Two rows are live today:

- `119-hamdt-40` → `house-119-1-187`, "On Ordering the Previous Question", Passed 214–212
- `119-hamdt-175` → `house-119-2-122`, "On Ordering the Previous Question", Passed 211–210

Ordering the previous question ends debate; it decides whether the House votes, not what it decides. Both render through the amendment-framed `VoteLine` as the amendment's own tally, with a green agreed dot from `deriveDisposition("Passed")`. Wrong on the number and wrong on the outcome.

## STEP 0 — enumerate before writing a predicate

**Do not filter to `"On Agreeing to the Amendment%"` off the back of the two offenders.** That predicate was derived from the exceptions, not from the population, and over-filtering is the mirror of the bug being fixed: it would silently drop legitimate decisive votes phrased some other way, and a missing amendment vote is far harder to notice than a wrong one. The Senate matcher was only safe because M8 enumerated all 161 questions and established the vocabulary was closed.

Read-only, before any edit: enumerate the **distinct `question` values across every House-linked row in `amendment_votes`**, with counts. Print the whole list. Then classify each form as decisive or procedural and state which predicate covers the decisive set exactly — no more, no less. If the vocabulary turns out open-ended or ambiguous, say so and halt rather than guessing; a partial filter is worse than the status quo because it looks fixed.

Also report, for the two offenders: does each amendment carry **any other** linked vote? If a procedural row is an amendment's only link, then after the fix it correctly shows no vote at all — expected, but I want it stated before it shows up as a surprise in verification.

## The fix

Three parts, and the third is the one that's easy to miss.

**1. The predicate belongs in `lib/amendment-vote-key.ts`, next to the Senate one.** That module exists precisely so the request-time parse and the sync-time materializer can't drift (the `NEWS_ARTICLE_KEY_SQL` / `MISSED_CARVE_EXPR` precedent). Right now it documents the Senate scope in a long comment and the House has no counterpart, which is exactly how the asymmetry survived unnoticed. Add the House predicate there with the same treatment: what it matches, what it excludes, and why — including the two concrete offenders, so the next reader can't re-widen it casually.

**2. Filter the walk.** Apply the predicate in `amendment-votes-walk.ts` before the `INSERT`. Note the walk constructs `vote_id` from the `/actions` payload and doesn't have the question text in hand at that point — resolve how to apply the filter (join against `votes` at link time, or filter on the recordedVotes shape if it carries enough) and say which you chose and why.

**3. Delete the existing bad rows — the walk will not self-heal.** `amendment_vote_walked_at` is stamped on exit and the queue predicate skips walked rows, so a filter alone stops *new* mislinks and leaves the two in place permanently. They need an explicit one-time delete, scoped to the rows the STEP 0 enumeration identifies as procedural. Scope it by the enumerated set, not a blanket delete.

## Constraints

- Fix only. No motion-aware model, no new surface, no `VoteLine` change — the existing component is correct, it's being fed the wrong rows.
- The one-time delete is a data write: show me the exact statement and the row count it will touch **before** running it, and confirm the count matches STEP 0's enumeration.
- Separate commits: STEP 0 diagnostic (if it warrants a committed script — a throwaway query reported in chat is fine here), then the fix. Docs sweep is its own HO after.
- Explicit pathspec. Full diff hunks before the fix commit — this touches a live render path.
- Prod-verify on the **cache-hit path**, 2–3 hits: `/bill/[id]` for the bills carrying `119-hamdt-40` and `119-hamdt-175` show the amendment with no vote line (or with only its legitimate votes, per STEP 0), and a known-good amendment-bearing bill (`119-hr-8800`, 19 amendment votes) is **unchanged** — that's the over-filter check, and it's the one that catches part 1 going too far.

## Report back

- The full distinct-question enumeration with counts, and the predicate you derived from it.
- Whether either offender had other linked votes.
- Where the filter landed in the walk and why.
- The delete statement, its row count, and confirmation it matched.
- Cache-hit verification on both the fixed bills and the unchanged control.
