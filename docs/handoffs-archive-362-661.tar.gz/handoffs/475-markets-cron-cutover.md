# HO 475 — markets/kalshi cron migration: GitHub Actions → Vercel Pro (cutover)

Recon (HO 474) cleared it: writes are benign (markets = plain append, kalshi = `ON CONFLICT` upsert), auth is green (`CRON_SECRET` proven in Vercel Production — the existing crons succeed and the `30 21` markets floor already fires on Vercel), bloat is a non-issue (3,773 rows / 51 days, no retention step), and the `30 21` floor **already fires on Pro** — so we *repurpose* it, not add from zero. The cutover is a near-pure `vercel.json` change in two phases: arm the Vercel crons, verify a day, retire the workflows. Overlap during the verification day is harmless by append/upsert.

**First, the recon diagnostic:** commit `scripts/diagnostic/markets-cadence-474.ts` alone as the HO 474 record (matches the `lda-bill-cost-439` committed-probe precedent) or `rm` it — your call, low stakes. Keep it off the cutover commits either way.

---

## Phase 1 — arm the Vercel crons (commit A: `vercel.json` only)

Three edits to the `crons` array (add two, repurpose one). Show the diff and wait for approval before committing.

- **Repurpose the existing floor** — change its schedule in place, do NOT add alongside:
  `{ "path": "/api/cron/markets", "schedule": "30 21 * * *" }` → `"0 */4 * * *"`
  The every-4h bare run is a superset of `markets-daily.yml` (full roster: FRED EOD + FRED monthly + the macro tape odds), so this one edit *is* the markets-daily replacement — no separate daily floor left to reconcile.
- **Add the intraday fmp tick** (replaces `markets-tick.yml`):
  `{ "path": "/api/cron/markets?source=fmp", "schedule": "0,30 13-21 * * 1-5" }`
  (the 7 latency-sensitive equity/index symbols; weekday market hours, covers both DST regimes)
- **Add the per-seat odds tick** (replaces `kalshi-tick.yml`):
  `{ "path": "/api/cron/kalshi", "schedule": "15 */2 * * *" }`

No `functions` / route edits — `maxDuration: 60` is already set for both routes and kalshi runs ~30s live. The two `/api/cron/markets` entries are distinct by full path string (`?source=fmp` vs bare); Vercel keys crons on the path including query, so both register.

**Git discipline:** explicit pathspec (`git add vercel.json`), show the diff, wait for Corey's OK, check ancestry immediately before push (one commit riding, clean fast-forward, concurrent-session files untouched), no force-push.

## Phase 2 — verify one day (overlap is benign)

After deploy, read `cron_runs` for ~24h. Expect:

- **markets fmp** — weekday, every 30m 13:00–21:00 UTC, ~1.7s, clean payload (fmp-only, no POLY symbols).
- **markets bare** — every 4h (00/04/08/12/16/20 UTC), full roster, ~8s, carrying a **POLY-SHUTDOWN `failed=1` chronicErr**. This is the pre-existing "shutdown ghost" (0-row, no-liquid-market), **NOT a migration regression** — do not read the permanent `failed=1` as a break. The rest of the roster ticks.
- **kalshi** — every 2h at :15, ~30s, success.
- The three GitHub workflows still fire this day too, so you'll see duplicate bare/fmp runs and redundant kalshi upserts. Harmless (append rows / last-write-wins). That's the intended overlap window — it's why we retire *after* verifying, not before.

## Phase 3 — retire the workflows (commit B: workflow deletions only, after Phase 2 passes)

```
git rm .github/workflows/markets-tick.yml .github/workflows/markets-daily.yml .github/workflows/kalshi-tick.yml
```

Separate commit from Phase 1. The arm/retire split keeps the rollback boundary clean: if the Vercel crons had misbehaved during the verification day, the GitHub fallback is still there to revert to — we only delete it once Vercel is proven. Explicit pathspec, diff, wait, ancestry check, no force-push.

---

## Deferred / banked (do NOT build here)

- **FRED once-daily gate — deferred.** The bare 4h run re-fetches the 4 FRED symbols ~6×/day (~20 redundant same-value rows/day). A real gate needs a route insert-guard (skip when a `(symbol, market_date=today)` row already exists) — a route edit that would take this off a pure-config cutover. Bloat is a non-issue, so skip it; revisit only if a future cadence bump makes it matter.
- **Dead-symbol prune — banked, cosmetic.** ~200 frozen Stooq-era rows (DOW/GOLD/BTC/VIX/DXY/…) sit inert in `market_ticks` (not in `MARKET_SYMBOLS`, never rendered). A one-time `DELETE` is pure cosmetics, zero functional benefit — bank as low/optional, don't ride the cutover.
- **Markets watchdog — banked, the natural pairing.** A `cron_runs` health check asserting markets/kalshi fired within their expected windows (and that the only chronic failure is the known POLY-SHUTDOWN ghost). Its own follow-on, not this HO.

## Docs

Doc sweep is **HO 476** (the standing "Docs: HO N+1" convention) — I'll write it once you confirm the cutover is live and verified, so it can carry the real shipped SHAs. It'll close the **"Intraday-reliable markets upgrade"** OPEN LOOP (this migration *is* that move; the HO 474 hour-histogram measured GitHub's slot-drop — 17h:12 vs 15h:3 / 16h:3 / 18h:3 / 19h:2 where weekday `0,30 13-21` should give ~10/hr), discharge the HO 433 "migration banked as its own HO" flag, add a roadmap "Also (HO 475)" block, and note the watchdog pairing + the banked dead-symbol prune. Nothing doc-related lands in this HO.

---

Report the Phase-1 diff for approval, then the Phase-2 `cron_runs` readout, before Phase 3.
