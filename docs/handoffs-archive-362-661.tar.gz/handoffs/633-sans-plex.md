# HO 633 — the sans is IBM Plex, self-hosted, and the HO 257 reversal gets recorded

Precondition: HO 632 fully landed (C4 weight fix + docs, pointer → 632). If the C4/landing relay hasn't run, run it first; this HO starts from that close. Owner ruling off `mock-633-sans-specimen.html` (four-face knob on the real surfaces): **IBM PLEX SANS.** The mock should already be extracted from `633-mock-delivery.md` (checksum `c9b081e06acbde420cb103e2ca363d6d`, 12,571 B) to `docs/design/` with the wrapper deleted — verify, extract now if the delivery is still sitting there, halt if neither exists.

The ruling supersedes HO 257's "CBT has no --sans" — a rule the 609-era title work already reversed silently, leaving two live comments asserting the opposite of the shipped state (globals.css ~3903, ~4190). This HO makes the reversal explicit and corrects the record.

## Commit 1 — the face

`next/font/google`, `IBM_Plex_Sans`, in the root layout:

- **Weights: grep before loading.** Enumerate every `var(--sans)` consumer's `font-weight` and load exactly that set (expect 400 + 700 — the card's `.who` and the band's names are 700; titles and prose are 400 — but state what the grep found, don't trust my expectation). Subset `latin`; verify one accented member name renders (Velázquez is the live case).
- **Wiring preserves the token as the seam:** the font's `variable` class goes on the root element; globals.css line 98 becomes `--sans: var(--font-plex-sans), system-ui, -apple-system, "Segoe UI", Roboto, sans-serif` — the old stack demoted to fallback behind the shipped face. Zero consumer edits; the token is the scope, which is why no per-route ruling is needed — the specimen showed the representative surfaces and every `var(--sans)` site moves together by construction.
- **Self-hosting verified, not assumed:** next/font downloads at build and serves from `/_next/static/media`. In the served production HTML and CSS: the `@font-face` with the self-hosted woff2 URL present, and **zero occurrences of `fonts.googleapis` / `gstatic`** — the mock's CDN load was transport only, and the no-external-requests claim is checked in both directions.
- **Payload stated:** the woff2 bytes per weight, measured, in the commit — the ledger habit in the bytes currency.

## Commit 2 — the record

The two stale comments rewritten. Their mono *choices* were correct and stand; their *justification* ("CBT has no --sans") has been false since the title work. The true rule they now cite: **chrome, labels, and ids are mono; `--sans` is the reading face for titles and prose, and the face is IBM Plex Sans (HO 633, superseding HO 257).** Grep for any third assertion of the old rule before calling it two.

## Commit 3 — SKILL, own commit, standard ceremony

One sentence in the design-system section recording the face, the self-hosting, and the supersession. Diff on the review ref like any SKILL change.

## Gates and the one expectation set in advance

1. Click gate 36/36 — text metrics change row geometry; cheap, pinned.
2. Audit: `--route home` closed state per main baselines — **and this is the HO where knee-marginal residue can legitimately move.** Plex's metrics differ from Segoe's; `/members`' 11 knee-marginal `a.mc-row` at 121–131px sit within text-width noise of the 120 threshold. Run `/members` too. If residue counts move, that is PRODUCT (real widths changed), not instrument: decompose which rows crossed and by how many px, restate the register with the new figures, and do not force the old numbers. Named now so a moved 17 isn't filed as a regression or quietly retuned.
3. Hydration: next/font is SSR-safe; the clock grep-gate still runs on principle.
4. Typecheck + build per commit; explicit pathspecs; code, docs, SKILL never mixed.

## HALT 1 — owner's eyes

Screenshots at 1440 and 2560: the grouped feed in Plex (titles + one open panel's summary), the MIA card, and one `/members` shot since its residue register is the text-sensitive surface. Fallback flash note if any observed.

## Close — `refs/heads/633-review`

Docs commit: block for HO 633 — the ruling off the specimen with the four candidates named, the HO 257 supersession and both comment corrections, the loaded weights and measured payload, the zero-external verification both directions, and the residue outcome (moved-and-decomposed, or held). `docs/design/mock-633-sans-specimen.html` rides as the ruling's record. Pointer → 633, grep gates, SKILL commit alongside per ceremony. Delete the ref and the delivery wrapper after landing.
