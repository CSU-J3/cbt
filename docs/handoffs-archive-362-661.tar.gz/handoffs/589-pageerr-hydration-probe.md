# HO 589 — the `pageErr` React #418 probe: two corrected premises, then measure, then HALT

**Numbering.** `docs/roadmap.md`'s latest block reads *"Also notes now run through HO 586"* with *"Docs: HO 587."* That makes 588 next — but **588 is already spoken for**: `7ce1f0e` is `diag(dashboard): HO 588 — absence-watch rule probe`, a read-only STEP 0 that has not been read out and whose roadmap block will be written when that arc ships. So this is **589**. Confirm against `docs/roadmap.md` + `git log --oneline -5` before saving; the roadmap wins over this filename.

**This handoff builds nothing.** STEP 0 only: five measurements, then a hard HALT and a report. No fix code, no component edits, no config flips, no `e2e-prod.yml` change. The fix phase gets scoped from what M1–M5 actually return, not from this document's guesses.

---

## §0 — Two documented claims that are wrong, and why it matters

`docs/backlog.md` and the roadmap's "Also (HO 574)" block both characterise this failure as:

> React #418 `args[]=HTML` — **the hydration text-content mismatch variant** … the **identical message across all four failed runs**, so a **single cause**.

Both halves look wrong on inspection. Treat them as claims to verify in M1/M2, not as facts to build on — and if M1/M2 confirm the corrections, **the docs get fixed as part of this arc**, because every downstream hypothesis was aimed by them.

### §0.1 `args[]=HTML` is the *structural* variant, not the text one

React 19's error table (`scripts/error-codes/codes.json`, code 418) reads:

> Hydration failed because the server rendered **%s** didn't match the client. As a result this tree will be regenerated on the client. This can happen if a SSR-ed Client Component used: a server/client branch `if (typeof window !== 'undefined')`; variable input such as `Date.now()` or `Math.random()`; date formatting in a user's locale which doesn't match the server; external changing data without sending a snapshot along with the HTML; invalid HTML tag nesting. … https://react.dev/link/hydration-mismatch**%s**

Two `%s` slots. The **first** is the word `HTML` or `text`. So `args[]=HTML` means the mismatch was in **markup** — an element present/absent, a different tag, a different attribute set — and explicitly **not** a text-content difference, which would have read `args[]=text`.

Why this reshapes the hunt: H2 as written ("a time-derived render input") predicts a *string* drifting — a relative age, a formatted timestamp — which produces `args[]=text`. The surviving version of H2 is narrower and sharper: **a non-deterministic value that gates whether a NODE renders**, not one that formats a string inside a node. A stale-badge that appears on the client and not in the server HTML is an `HTML` mismatch; "3 days ago" vs "4 days ago" is a `text` one. The repo has both shapes; only the first can be this error.

### §0.2 "identical message ⇒ single cause" does not follow in a minified build

The second `%s` — the diff, which is what names the offending component — is produced by `describeDiff`, which is **DEV-only**. In a production React build the appended diff is empty and there is no component stack on the error. So the minified string is:

`Minified React error #418; visit https://react.dev/errors/418?args[]=HTML&args[]= …`

…and that string is **byte-identical for every structural hydration mismatch anywhere in the app**. Message identity across four runs is therefore consistent with one cause *and* with five; it carries no information about cause count. The inference has to be withdrawn.

This matters concretely because it **partially reopens H1**. HO 574 falsified "the tape" by noting `/president` and `/members` fired and carry no tape — that is confirmed and still true (`MarketsTape` is imported only by `HomeHeader` and `DashboardV2Header`; `HeaderBar`, which is what `/president` and `/members` use, does not import it). But that falsifies the tape as **the only cause**, not as **a** cause. Under §0.2 the dashboard's mismatch and the inner pages' mismatch can be two different bugs emitting one string.

### §0.3 The consequence for the shipped instrument

HO 574 C1 truncates each captured message to 200 chars (`smoke.spec.ts` `detail()`, `.slice(0, 200)`). If §0.1/§0.2 hold, **raising that limit buys nothing** — there is no diff to reveal in a prod build, and the ~90-char minified prefix plus an empty second arg is the whole message. The instrument is at its ceiling, and identification has to come from somewhere else. M5 is that somewhere else.

---

## STEP 0 — five measurements, read-only, then HALT

Script: `scripts/diagnostic/pageerr-hydration-589.ts` for M1–M4 (same idiom as `absence-watch-588.ts` / `motion-outcome-model-554.ts` — `dotenv/config`, `npx tsx`, no writes). M5 is a Playwright spec run, not a script — see below.

Commit the diagnostic, **then HALT**. Do not proceed to a fix in the same session.

### M1 — confirm the arg semantics from the source of truth

Fetch React's `codes.json` (`https://raw.githubusercontent.com/facebook/react/main/scripts/error-codes/codes.json`) and print entry `418` verbatim alongside the installed `react-dom` version from `package.json` (currently `^19.2.5`). Then answer, in the report:

- (a) Is the first `%s` the HTML/text discriminator? Quote the string.
- (b) Is the diff `%s` DEV-gated in 19.2.x? Check the installed `react-dom` in `node_modules` — grep the production `cjs`/`esm` bundle for `hydration-mismatch` and record whether a diff is concatenated in the non-DEV path.
- (c) State plainly whether §0.1 and §0.3 are **CONFIRMED** or **REFUTED**. If refuted, say so and stop treating this handoff's framing as authoritative.

### M2 — is any cause-discriminating content available at all?

From the four HO 574 failure artifacts (if any are still inside the 14-day window — check first, and record it as unavailable rather than guessing if not): print the full captured `pageErr` string, unmodified, and the full `consoleErr` array for the same route/hit. Answer:

- Does anything in the captured payload differ between the four runs? Byte-compare.
- Does React emit a *separate* `console.error` alongside the thrown recoverable error, and does it carry anything the `pageerror` message doesn't?
- Does `err.stack` (not captured today — the collector pushes `err.message` only) carry anything usable given `productionBrowserSourceMaps` is unset, i.e. `false`?

The output of M2 is a yes/no on whether the unattended prod crawl can *ever* self-identify the component as currently built. If no, that is the finding, and the fix HO's first job is an instrument, not a fix.

### M3 — the non-determinism inventory, superset, route-annotated

**Do not scope this to the observed route set.** HO 574's scoping guard is explicit and the set has been re-characterised twice from growing samples. Build the full inventory and *annotate* it by route so the intersection is visible without being assumed.

Enumerate every site in a **client component** (`"use client"`, checked by grep for the directive anywhere in the file head, not just line 1) that reads a non-deterministic input **during render** — render body, lazy `useState(() => …)` initialiser, or `useMemo` — from any of: `Date.now()`, `new Date()` with no argument, `Math.random()`, `window.*`, `localStorage`, `sessionStorage`, `matchMedia`, `navigator`, `Intl` with a defaulted locale/timezone, `useSearchParams()`, `usePathname()`.

For each, a row with: file:line · source · **render-time or effect-time** · **does it gate node existence / element identity, or only text?** · which routes render it.

Reads inside `useEffect` are safe by construction and belong in the table marked as such, not omitted — the point is a complete map. The known-safe patterns should come back marked safe and that is a result: `lib/zone-cycle.ts`'s `useZoneCycle` pins MT for both SSR and first client paint; `HearingsTab` passes a **server-computed** `nowMs` down (`Date.now()` in a server component serialises into the RSC payload, so server and client share one value — the HO 489/490 fix); `MarketsTapeClient`'s HO 376 shuffle is `null`-until-mounted for exactly this reason. Confirm each of those still holds at HEAD rather than trusting this paragraph.

The rows that matter are the ones that are **render-time AND structural**. As a starting pointer, not a conclusion: `MarketsTapeClient:714` initialises `const [now] = useState(() => Date.now())` and derives `stripStale` (`:826`), `marketHoursClosed` (`:834`, `isMarketOpen(new Date(now))`) and `overdue` (`:844`) from it. Those gate badges. A page whose HTML was rendered before a market open/close boundary and hydrated after it would flip which nodes exist. Verify whether those actually add/remove nodes or only swap class names and text — that determines whether it can produce `args[]=HTML` at all, and it is the single check that promotes or kills this lead.

### M4 — H4: `useSearchParams()` against the route's render mode

A hypothesis this handoff is raising fresh, because it is the only one so far that covers the whole firing set without a confound. `useSearchParams()` in a client component returns empty during a **static prerender** and the real values on the client; on a **dynamic** render it returns the real values on both sides. If a firing route is statically prerendered and a `useSearchParams()` consumer gates a node, that is a structural mismatch that fires per-URL — which would explain why the `?stage=` variants fire as separate entries.

Measure, don't assume:

- Run `next build` and capture the route table. Record `○ Static` / `ƒ Dynamic` / `● SSG` for `/`, `/president`, `/members`, `/news`, and every route in `ROUTES`.
- Enumerate `useSearchParams()` consumers and map them to those routes. At HEAD the consumers are `IssueRailRow`, `DashboardTopicTreemap`, `NewsTopicRailRow`, `SearchBox`, `NewsMemberRailRow`, `CommitteeRailRow`, `SortDropdown`, `TopicRailRow`, `CeremonialToggle`, `ProceduralToggle`, `StageFunnel` — re-derive, don't trust the list.
- For each consumer on a firing route: is it inside a `<Suspense>` boundary? Does the param gate a node or only a class?

**Expect this to weaken for `/`**: `app/page.tsx:1` calls `cookies()`, which forces dynamic rendering, and a dynamic render gets real search params server-side. If the build table confirms `/` is `ƒ`, say so and let H4 fall for that route rather than reaching for it. `/president` and `/members` may differ. A hypothesis that only covers part of the set is a partial answer, and partial is fine — inventing coverage is not.

### M5 — the reproduction lever: manufacture the skew in a DEV build

This is the measurement that can actually name a component, and it exists because M1 establishes the prod message never will.

The natural failure is intermittent because it needs the server's HTML and the client's hydration to sit on opposite sides of some boundary. That skew is manufacturable. Playwright 1.61 ships the clock API, so:

1. Run against **`next dev`**, not a production build. This is the whole point — in DEV, React 19 appends the `describeDiff` output, so a fired #418 prints the server-vs-client tree **with component names**. HO 574's two clean local crawls were correct results, not gaps; they simply had no skew and no diff to read.
2. For each route in `ROUTES` (all of them, per the scoping guard), `await page.clock.install({ time: T })` before `goto`, with `T` swept across the boundaries M3 surfaced — at minimum: either side of a US market open (09:30 ET) and close (16:00 ET), either side of `STALE_THRESHOLD_MS` from the newest `market_ticks` row, and either side of any hearings `watchState` window edge. Plus a large offset (say +30d) as a blunt control.
3. Record, per route × skew: fired or not, and on a fire, the **full DEV diff verbatim**.

Two outcomes, both useful:

- **Fires** → the diff names the component. That is the identification the whole open loop has been missing, and the fix HO scopes off it.
- **Does not fire on any route at any skew** → H2/H3 are falsified as a class, the mechanism is not clock skew, and the fix HO starts from H4 or from an instrument-first approach instead. Record it as a **result, not a gap** — the same posture HO 574 took with its unreproduced crawls, which the handoff pre-authorised and which was the right call.

Do not commit the M5 spec into `e2e/`. It is scratch instrumentation for this probe; if a permanent version is wanted it gets scoped in the fix HO, where the question of whether a clock-skew test belongs in the unattended runner can be argued on its merits.

---

## HALT

Commit the diagnostic (`diag(e2e): HO 589 STEP 0 — pageErr #418 hydration probe`) and stop. Report:

- M1 (a)(b)(c) — CONFIRMED or REFUTED on §0.1 and §0.3.
- M2 — can the prod crawl self-identify, yes or no.
- M3 — the full table, with the render-time-AND-structural rows called out.
- M4 — the build render-mode table + the consumer map + H4's verdict per route.
- M5 — per route × skew, and any DEV diff verbatim.

If M1 refutes §0.1, say so first and loudly; this document's framing collapses and the fix HO re-scopes from M3 alone.

---

## Scope guards

Six, all hard:

1. **No fix code in this HO.** The diagnostic commit is the only commit.
2. **Do not scope around the observed route set** (`/`, the `?stage=` variants, `/president`, `/members`). HO 574 recorded that the set has grown with every sample and has not been shown to have stopped. M3 and M5 cover all of `ROUTES`.
3. **Do not silence it.** No `suppressHydrationWarning`, and no new entry in `e2e/console-noise.ts` — the WATCH on that file says an entry added to mask a real regression is itself a promotion trigger, and this is a real regression.
4. **No `e2e-prod.yml` change** — not the cadence, not the concurrency group, not the spec list. The doubled-crawl WATCH already tracks that surface.
5. **No `productionBrowserSourceMaps` flip.** It is a plausible instrument and it is also a prod bundle + source-exposure decision. If M2 concludes it is the only path to identification, say so and let it be argued in the fix HO.
6. **No touching `smoke.spec.ts`'s assertions, collectors, or the HO 574 detail line.** M2 reads what it currently captures; changing the instrument mid-measurement destroys the comparison against the four existing artifacts.

## Docs owed (fix HO, not this one)

If M1/M2 confirm, three corrections land with the fix, not before: the backlog's `pageErr` OPEN LOOP ("the hydration text-content mismatch variant" → the structural variant; "single cause" → cause count unknown), the roadmap — **by appending a new block, never by retro-editing the HO 574 one** — and any SKILL line that repeats either claim. The close criterion on the OPEN LOOP stays as written: a **named cause plus green runs**, never green runs alone, because an intermittent's absence reads identical to a fix.
