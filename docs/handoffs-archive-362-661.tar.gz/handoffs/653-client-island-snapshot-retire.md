# HO 653 — the client-island list stops being a list

**Ground truth:** `main` at `f47b807` (`docs(HO 652): note what a re-run now measures, and what 653 inherits`), `ls-remote` reads main only.

**Number:** roadmap pointer **646**, commit subjects run to **652**, so **653**.

**The ruling, Corey's:** drop the hardcoded snapshot, keep the changelog prose demoted to history. The enumeration becomes the refresh command plus what the command cannot tell you. Nothing is lost and the list cannot drift, because there is nothing left to go stale.

**Two commits, both docs, both on a review ref** — this edits SKILL, self-mod guard:

| # | Kind | Contents |
|---|------|----------|
| 1 | `docs` | SKILL — L1711 and L2044 lose the snapshot |
| 2 | `docs` | backlog — the HO 651 entry's `### Server / client split` clause |

---

## §1 — The snapshot is already wrong again, one HO after being repaired

This is the whole argument for the shape, and it was measured on `f47b807`:

SKILL reads **"~67 `"use client"` components — 69 `^"use client"` grep matches under `components/` incl. the 2 hook files."**

| reading of *"under `components/`"* | matches |
|---|---|
| `components/*.tsx` only | **69** |
| `components/*.ts` + `components/*.tsx` | **71** |
| recursive, incl. `components/svg/` | **71** (no client files under `svg/`) |

The **69** in SKILL is the `.tsx`-only count. The hook files are `.ts`, so that count **does not contain them** — and SKILL subtracts them from it anyway. The correct chain is **71 matches − 2 hooks = 69 components**, not 67.

HO 650 moved this line from `~53` to `~67` and it was wrong on arrival. **The mechanism is the ambiguity of the refresh instruction sitting beside it:** *"grep `^"use client"` under `components/`"* does not say whether it means `.tsx`, all files, or recursive, and the three readings differ. A snapshot maintained by an ambiguous command will disagree with itself, which is exactly the `~53`-vs-`~67` history.

**Report the corrected measurement in the commit and the backlog clause.** The record should show the snapshot was wrong at the moment it was deleted — that is the justification, and without it a later reader sees only a doc getting vaguer.

---

## §2 — Scope: L1711 and L2044, and nothing else

These two are **the pair that produced the contradiction**. L1711 sits in the design section and L2044 is the canonical `### Server / client split` entry; both carry the same snapshot and the same name groupings. **Both must lose it, or the pair can disagree again** — repairing one is what created `~53` vs `~67` in the first place.

**L2043 is OUT OF SCOPE.** It is the `/`-route island list, it was repaired at HO 652 with grounded `file:line` citations, and it is currently correct. It is route-scoped rather than a global enumeration, so it is a different artifact with a different derivation. Leave it byte-identical.

**Do not touch** the section's other three lines (all-pages-are-server-components, the watchlist POST), `app/globals.css:1563`, or any other section.

---

## §3 — What replaces the snapshot

**(a) One unambiguous refresh command.** Not *"grep under `components/`"* — the exact invocation, with the glob spelled out, and what it returns split into hooks and components. Write it so that two people running it get the same number, which is the property the current instruction lacks.

**(b) The residue the grep cannot tell you, which is the valuable half and must survive intact:**

- the **2 hook files** (`useSingleOpenPanel.ts`, `use-watch-toggle.ts`) that the grep catches and that are not components;
- **`PrimaryRow.tsx` co-locating a second client export**, `PrimaryExpandProvider` — one file, not two islands;
- **`MobileNavDrawer` dormant**;
- the **server components that look interactive** — `TopicFilter`, `SegmentedToggle`, `NewsFilters`, `Pagination`, `MemberTopicBar`, `PatternDrilldownPanel`, `MarketsTape`, `BreadcrumbMasthead`, `GroupTabs`, `DashboardPrimaries`, `WeeklyBand`, `ActiveFilterStrip`, and `PatternBars` — which render `<Link>`s and let the router carry state. **This is the part no grep produces and the part a reader actually needs.** It is a claim about *why* something is a server component, and it does not go stale the way a count does.

**(c) The changelog, DEMOTED — reframed, never deleted.** *HO 509 added `RecordTabs` and deleted `MemberStats` + `MemberAffiliations`*, *HO 328 added `CommitteeRailRow` + `RosterShowAll`*, and the rest stay as **history of how the set changed**. They must **not** read as an assertion of current membership. The reframing is the whole difficulty: a sentence that says *HO 210 added `CartogramShell` / `RaceMapCard` / `PrimaryMapCard`* is true history and a false present tense, since two of those three are deleted.

**One name needs care.** `MemberProductivityScatter` appears in the roadmap **zero** times and the backlog once. Four of the five changelog names spot-checked are recorded elsewhere; that one is nearly SKILL-only. **Demoting it is fine — deleting it would destroy the record.** Do not resolve any of this by moving history into the roadmap: that is an append-only file and a separate decision.

---

## §4 — Phantoms, and the trap of writing for the classifier

Re-run `scripts/diagnostic/skill-phantoms-651.ts` and report the section's PHANTOM count before and after.

**Expect a residue, and expect it to be mostly the list-marker artifact.** HO 652 established that a single deletion marker serving a list — *`A` / `B` / `C` are retired* — lands only in the last name's ownership scope, so earlier names read PHANTOM while the sentence is a correct record. A demoted changelog is built almost entirely of such sentences, so **the count will overstate the drift and that is not a defect to fix.**

**DO NOT CONTORT PROSE TO SATISFY THE HEURISTIC.** HO 652 held this line and it holds here. Report each survivor with its reason. A section rewritten so a classifier reads clean is a section optimised for the instrument rather than the reader, and that is a worse failure than the count.

---

## §5 — Verification

**5.1 — the discriminating check, and it is mechanical.** After the edit, **SKILL contains zero hardcoded counts of the client-island set.** Grep for it and report the result. If the work did not happen the counts are still there, so this reading differs between success and no-op — which is what makes it an instrument rather than a restatement.

**5.2** — Every name kept in the residue lists at §3(b) is verified against the tree: the server-components-that-look-interactive set is a claim about current code, so each one must still exist and still lack `"use client"`. **Report that check per name.** It is the one part of the new text that can be wrong in the same way the snapshot was.

**5.3** — `--numstat` on SKILL, stated before running. Both columns; this is in-place editing.

**5.4** — The probe re-run, §4.

**5.5** — No build, typecheck, or render check applies. Say so rather than offering a green one as evidence.

**Watch the C1 control.** It is a fixture as of HO 652 and no longer expires on line shifts — but L1711 sits above thousands of lines and this edit will move them, so **confirm C1 still passes** rather than assuming the fixture covers it. That assumption is what HO 652 disproved about anchors generally.

---

## §6 — Commit 2

One clause on the HO 651 phantom entry, in the HO 652 shape: what a re-run measures now, and that `### Server / client split` is discharged. **Carry the §1 measurement** — 71 matches, 2 hooks, 69 components, and that the deleted snapshot read 67 — because that is the evidence the snapshot could not be maintained, not merely that it was replaced.

Do not restate the entry's historical counts. They are correctly SHA-stamped.

---

## §7 — Delivery

Both commits to `refs/heads/653-review`. Report the ref SHA, per-commit numstat, the §5.1 grep result, and the §5.2 per-name check. Main stays at `f47b807` until the SKILL text is read.

Explicit pathspec staging, no `git add .`, ancestry eyeball, fast-forward only.
