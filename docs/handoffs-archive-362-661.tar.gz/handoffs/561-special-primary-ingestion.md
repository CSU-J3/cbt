# HO 561 — populating the special-primary rows (the SC Aug 11 path)

HO 560 seeded `senate-SC-2026-special-{D,R}` as dated, rosterless rows and recorded honestly that **no automated path can fill them**. This HO builds that path. Aug 11 is the fuse.

## §0 — Preconditions

1. `git fetch && git status` clean, `main` even with `origin/main`, HEAD = `65d0692`.
2. `npm run typecheck` clean.
3. Read: `lib/primary-candidates-scrape.ts` (`scrapeSenateCandidates` ~L386–415, `senatePageUrl` / `senateSpecialPageUrl` ~L96–102, the `CandidateScrapeResult` type ~L72), `lib/primaries-sync.ts` `syncSenateCandidates` including the HO 560 C2 guard, `scripts/seed-special-primaries.ts`, `data/special-primary-seeds/sc-2026-senate.json`.

## §1 — The hole that shapes this build, stated before you design around it

The obvious design is to route on which URL served: `scrapeSenateCandidates` already falls back to `senateSpecialPageUrl(slug)` (built for the FL and OH 2026 specials), the success path preserves the winning URL on `result.url`, so a roster arriving off the special page could be written to `-special-` ids instead of the base ones. That works, and **for SC it never fires.**

The fallback is conditional on the standard page missing. HO 560 S1 established that Ballotpedia's standard SC Senate page **exists and returns 200**, carrying the June 9 regular with results. So SC's scrape succeeds on the first attempt every time, returns the standard URL, routes to `senate-SC-2026-{D,R}`, and those ids are now frozen by the C2 guard. The special page is never requested. Routing alone leaves the seeded rows exactly as empty as they are today.

So the special page has to be fetched **in addition to** the standard one, for states that have seeded special rows. That is the build.

**Second constraint: cadence.** The cursor visits SC's Senate unit once per full cycle, which HO 559 M4 measured at 44.6 days and HO 560 C3 halved to roughly 22. Election night is Aug 11 and the runoff is Aug 25. A once-per-cycle visit can miss both. A dated contest needs a dated trigger, not a queue position.

## §2 — STEP 0 (read-only, report, then proceed unless a HALT fires)

**S1 — seeded special registry.** List every `primaries` row whose id matches `senate-%-2026-special-%`: id, state, party, `primary_date`, `runoff_date`, roster count. Expect the two SC rows, rosterless. This set is the opt-in registry for §3, so its size is the blast radius.

**S2 — who currently serves off the special URL.** For each state in `SENATE_STATES_2026`, report whether `senatePageUrl(slug)` returns 200. Any state where it does not is a state whose roster **today** comes from the special-election page and lands in base ids. Expect FL and OH. **This is the regression surface**: §3 must not change where their rosters go. If the count is larger than FL/OH, report it and proceed, but name every state.

**S3 — the SC special page.** Fetch `senateSpecialPageUrl("South_Carolina")` and report status plus, if 200, whether `parseCandidatesPage` yields a roster and whether any candidate carries a share. HO 560 saw a 404 under a browser UA. **If it now returns 200 with a roster, say so loudly** — that is the field publishing, and it changes this HO from "build the pipe" to "build the pipe and run it."

**S4 — guard interaction.** Confirm by reading (not by running) that the C2 settled predicate applied to a `-special-` id behaves correctly: rosterless rows have no shares, so they are never settled, so they never freeze before their results land. Then confirm the intended post-Aug-11 behavior: once shares land and the date is past, the special rows freeze like any other settled contest.

**HALT** only if S2 shows a state serving off the special URL that also has a seeded `-special-` row, since that state would flip routing under §3 and needs its own ruling.

## §3 — Build

### C1 — the special-page pass, opt-in by seed presence

In `syncSenateCandidates`, after the existing per-state pass completes, add a second pass for that state **only when seeded `-special-` rows exist for it** (query the registry once before the state loop, not per state):

- Fetch `senateSpecialPageUrl(slug)` under the same 8s cap as the normal path, with the same 700ms politeness sleep after it.
- On a miss, including the expected 404 while the field is unpublished, record it under the existing `fetchFailures` bucket with a `-special` marker and continue. A 404 here is the normal pre-publication state, not an error condition, so it must not fail the state or the tick.
- On a hit, `parseCandidatesPage`, then write each contest's roster to `senate-{ST}-2026-special-{contest}`, reusing the existing delete-then-insert plus the member-matching helper unchanged.
- **The C2 guard applies to these writes too.** Same predicate, same call. Do not special-case it.

**Opt-in by seed presence is the whole safety story.** A state with no seeded special row is never given a second fetch and its routing is untouched, so FL and OH keep landing in base ids exactly as they do today and S2's regression surface is closed by construction rather than by care. Do not route on `result.url`, and do not touch the fallback inside `scrapeSenateCandidates`.

**Never auto-create a `primaries` row from a scrape.** A scraped page has no trustworthy contest date, and inventing one is how a row acquires a date nothing verified. The seed file is the registry; an unseeded special is a no-op with a log line.

### C2 — the dated trigger

A cursor position cannot serve Aug 11. Add a bounded priority pass at the top of `runPrimariesCronTick`, before the cursor slice is read:

- Select seeded special contests whose `primary_date` or `runoff_date` is within **±7 days of today** and which carry no shares.
- Run C1's special-page pass for those states, capped at **3 states per tick**, before the normal unit work.
- The cursor is **not advanced** by this pass and its budget comes out of the same `DEADLINE_MS`, so a slow priority pass shortens the slice rather than overrunning the tick. Surface the ids touched in `PrimariesCronResult` as `priorityScraped: string[]`.
- Outside every window this selects zero rows and costs one indexed query per tick.

At twice-daily (HO 560 C3) this gives roughly 14 attempts across the Aug 11 window and another 14 across Aug 25.

## §4 — Decisions taken

1. **No general priority pass.** This triggers on seeded specials in a date window, not on staleness. HO 559 M5(a) already refuted the general re-poll worry, and a broad priority queue would compete with the cursor for the same budget.
2. **No new surface.** Once populated, the special renders as its Aug 11 tick through `getPrimaryCalendar` → `PrimaryTimeline`. The race hub does not show it, because `getRunoffsForRace` is runoff-only and no query reads `primaries` by `race_id` at primary round. Surfacing a special result on `/race/[id]` is a real gap and a separate call; name it in the report.
3. **The member-hub chip stays on June 9**, per the HO 560 §3.1 follow-on. Unchanged here.
4. **House specials are out of scope.** No seeded House specials exist; the registry pattern extends to them when one does.

## §5 — Scope guards

1. No edits to `lib/primary-candidates-scrape.ts` at all, including the FL/OH fallback.
2. No edits to `syncCalendar`, `syncHouseDistricts`, or `scripts/seed-special-primaries.ts`.
3. No change to the HO 560 C2 guard predicate, `CRON_HOUSE_SLICE`, `CRON_SENATE_SLICE`, `DEADLINE_MS`, or `vercel.json`.
4. No migration, no index, no new column, no cache tag.
5. No component, page, or query edits.
6. Do not hand-populate the SC roster. If S3 shows the page live, C1 running is what fills it.

## §6 — Commits, ref, gates

1. `diag: HO 561 STEP 0 — special-primary registry + senate page-availability sweep (read-only)`
2. `feat(primaries): HO 561 C1 — special-page pass for seeded special contests`
3. `feat(primaries): HO 561 C2 — dated priority trigger for special primaries`
4. Push to `refs/heads/561-review`, report the four STEP 0 blocks plus SHAs, halt. No diffs pasted.

**Verification owed:** a forced `syncSenateCandidates(["SC"])` reports the special-page attempt and its outcome, and either populates the special rows (if S3 is live) or logs a clean 404 skip while leaving the June rows **and** the empty special rosters untouched; a forced tick with the window artificially satisfied shows `priorityScraped` non-empty and the cursor unmoved; a forced tick outside any window shows `priorityScraped: []` and a cursor advance identical to today's behavior. That last one is the regression gate: the common path must be byte-identical.
