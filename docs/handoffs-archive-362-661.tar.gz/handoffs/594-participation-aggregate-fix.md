# HO 594 — the participation aggregates vs the 10s bound: measure, choose, fix, prove

**Numbering.** Next from `docs/roadmap.md`'s pointer. 593 is the correlation probe (`a34f0ea`); 588 remains the parked absence-watch probe with its block owed. Confirm against the roadmap and `git log`.

**STEP 0 first, then HALT.** The fix shape is genuinely undecided between two house patterns and the choice is a measurement, not a preference. No fix code in the STEP 0 commit.

---

## §0 — What 593 established

Digest `4101894172` — `TimeoutError: The operation was aborted due to timeout` — the HO 238 `DB_REQUEST_TIMEOUT_MS` 10s abort. Two named queries:

- **`getParticipationStrip`** → `/members` (7 in 24h)
- **`getChamberParticipationContext`** → `/members/[bioguideId]` (4 in 24h)

Both shipped at HO 527 (`7fa729c`, 2026-07-26); both error groups first appear 07-30/07-31. Both are unhinted full aggregates over `member_votes JOIN members … GROUP BY bioguide_id`, cached at `revalidate: 3600`. So the 500 is the **blocking cache-miss recompute** breaching the bound — which is why it's intermittent and why concurrency stays clean (a burst is one miss and N-1 hits).

It is a **whole-route** 500 (`__next_error__` shell), not a failed segment after a flushed shell. That is what makes it a separate fault from the `pageErr` #418 loop, which stays open and untouched by this HO.

**Same class, same digest, third time.** The backlog names digest `4101894172` at line 358 for the HO 379/381/382 filtered-view 500. `oddities.md:366` records *"A 1-row 500 can still be a full-corpus scan — size-independent in failure, not in work."* `oddities.md:432` records *"EXPLAIN prices the plan, not the runtime scan — a plan-only audit is blind to leading-`%` LIKE and unbounded aggregates; those need a runtime timing check."* Both entries predate HO 527, and HO 527 shipped anyway with a comment justifying a skipped index as *"Small grouped aggregate (~537 rows)"* — sizing by **rows returned** while the scan covers all of `member_votes`. That is the documented anti-pattern verbatim.

**Read that as placement, not ignorance.** The rule is written where people read post-mortems and not where people write queries. The docs consequence is owed to the sweep HO, but M4 below is the part that belongs here: find out whether this reasoning is load-bearing anywhere else before it 500s a third route.

---

## STEP 0 — four measurements, read-only, then HALT

Script: `scripts/diagnostic/participation-aggregate-cost-594.ts`. Commit, then HALT.

### M1 — time the two queries, cold, at the runtime

Per `oddities.md:432`, **an `EXPLAIN` is not the measurement** — it prices the plan, and a full-corpus scan has a clean-looking plan. Time the actual execution:

- `getParticipationStrip` and `getChamberParticipationContext`, cold, against prod's Turso, several runs each.
- Report median and worst, against the **10s** `DB_REQUEST_TIMEOUT_MS` bound. A query at 8s is already failing intermittently; it just hasn't been sampled yet.
- Row counts: `member_votes` total, `members` total, rows scanned vs rows returned. The gap between those two numbers is the finding.

### M2 — the two candidate fix shapes, priced against each other

Both are house patterns with precedent, and the discriminator is measured cost:

**(a) Index-drive.** The HO 382 fix shape — index-drive the aggregate, with an explicit `INDEXED BY` hint if the planner won't take it (the `/news` rail precedent: `INDEXED BY idx_news_mentions_published` is documented as MANDATORY there, unhinted 2231ms vs hinted 29–64ms). Price: what index, what write cost, does the planner actually use it, what's the timed result.

**(b) Precompute into `dashboard_state`.** The LDA lesson: on an oversized side table, request-time aggregation is not viable, and a full sequential read plus in-memory JS precompute beat covering-index SQL. Price: which cron carries it, staleness tolerance, blob size.

Report both with numbers and a recommendation. **Do not pick on aesthetics** — if the index gets it to 200ms, (b) is over-engineering; if `member_votes` is large enough that the scan is irreducible, (a) is a delay not a fix.

### M3 — does the cached-miss shape need changing regardless?

Even a fast query 500s the request that recomputes it if the recompute ever exceeds the bound. Worth measuring whether the cache posture itself is part of the fix: is `revalidate: 3600` on a blocking miss the right shape here, or should the value be warmed by a cron so no user request is ever the one that computes it? Answer with the measured recompute cost from M1, not in the abstract.

### M4 — the inventory: where else does this reasoning live?

The important one. Sweep `lib/queries.ts` (and anywhere else that queries the large tables — `member_votes`, `lda_*`, `bills`, `news_mentions`, `observation_entities`) for **unbounded aggregates without an index hint**. For each: rows scanned vs rows returned, and a **timed** run — not a plan read.

Two specific tells to grep for, since both are on the record as having preceded a 500:

- A comment sizing a query by **rows returned** ("small aggregate", "~N rows", "only N groups") where the scan is over a large table.
- A `GROUP BY` over a join to a large table with no `INDEXED BY` and no bounding `WHERE`.

**Inventory only — fix nothing here.** The output is a ranked list by measured runtime against the 10s bound, so the fix phase knows whether it's fixing one query or a family.

---

## HALT

Commit as `diag(db): HO 594 STEP 0 — participation aggregate cost`, then stop. Report M1's timings, M2's two priced options plus a recommendation, M3's verdict on the cache posture, and M4's ranked inventory.

---

## The fix (phase 2, after approval)

Scope from M2/M4. Falsification is two-sided and the margin is part of it:

- **RED, deterministic.** Reproduce the 500 by forcing the cache miss — not by hammering prod and waiting for luck. 593's stage A got 2/20 by chance; a fix proven against a stochastic red is proven against nothing.
- **GREEN.** Same forced-miss shape, 0 failures, **and the cold recompute timed with a stated margin under 10s.** A fix landing at 9.2s is not a fix, it's a smaller dice roll. State the margin as a number in the commit message.
- **CONTROL.** The strip and the context still render the same values they did before. A fix that makes the query fast by changing what it counts is a regression wearing a green.

## Scope guards

1. **Do not touch the `pageErr` #418 OPEN LOOP.** 593 proved these are separate faults; this HO closes the 500, not that.
2. **Do not raise `DB_REQUEST_TIMEOUT_MS`.** HO 238 set that bound deliberately; raising it converts a 500 into a hung request.
3. **Fix the named queries plus whatever M4 promotes with evidence.** No speculative widening into untimed queries.
4. **No `smoke.spec.ts` / `e2e-prod.yml` changes.**
5. **No unrequested SKILL.md edits.** The placement fix for the full-scan rule is real and is owed to the sweep HO — report it, don't write it here.
6. **Commits separate:** diagnostic · fix · docs, and any migration in its own commit.

## Owed to the sweep HO

- The full-scan rule's **placement** — it exists at `oddities.md:366` and `:432` and did not reach a query author. It belongs in SKILL's query-authoring path, with "sizing an aggregate by rows returned" named as the recognisable tell.
- 593's verdict, the `30595816107` reclassification from "transient 500" to **site-wide outage** (216/216 cells) — a new roadmap block, never a retro-edit of the 589 one.
- The M2 stage table recorded **without** ranking the stages; the counts are 2/0/0/1/1/1 and won't carry a rank.
- Route-disjointness phrased as **"disjoint in the crawl sample"** — M3's digest lists `/stale`, `/`, and `/members` over 24h, so `/` is not immune, it was unsampled.
- Two instrument-integrity instances, recorded under the existing close-criterion rule rather than as a new oddity: an empty `gh run view --log` (keyring contention under parallel invocation) reads identical to a clean run, and `npx tsc --noEmit; echo "tsc ok"` prints ok whether or not tsc passed. Both are success signals that don't depend on the check succeeding.
