# HO 459 — Nominations committee cross-link: hydrate `committee_system_code` + `/committee/[systemCode]` section + `?committee=` filter

The QUEUED cross-link, built on the HO 458 GO (98% civilian referral presence, 100% resolution to tracked committees, per-part `raw_json.url` is the record, ~1.98 fetches/row, 830 rows ≈ 277–500s → CLI backfill + bounded cron delta). Two commits, data → surface.

**The populate rule 458 settled:** hydration keys per `(pn_number, part_number)` by following each stored row's `raw_json.url` (the base `/nomination/{c}/{n}` is a stub with `committees` absent for multi-part PNs — do NOT key on base). `committees` is a sub-resource `{count, url}` on every record, so it's a second fetch when `count > 0`. Store the **first** committee (primary referral); the 6/150 dual-referral tail drops its secondary (disclosed, not a link table — a single `committee_system_code` column, the 458 cardinality call).

**The finding that shrinks commit 1:** the sync's `ON CONFLICT(id) DO UPDATE SET` (in `buildNominationStatement`) already **omits** `committee_system_code`/`nominee_count`, so a bulk-refresh re-upsert preserves them. The new `committee_hydrated_at` column is likewise absent from both the INSERT list and the SET clause, so new rows insert NULL (→ hydration queue) and re-syncs preserve the hydration state. **`syncNominations` / `buildNominationStatement` need NO change** — do not add the new column to the SET clause (that would re-null hydrated rows every bulk-refresh day).

---

## Commit 1 — data: migration + `hydrateNominations` + CLI flag + cron step

### 1a. Migration (`scripts/migrate.ts`)

One sentinel column + a pending-work partial index (so incremental re-runs never re-fetch already-hydrated rows, including the ~2% that legitimately have no committee):

- Add `committee_hydrated_at TEXT` to the `nominations` CREATE TABLE (fresh DBs) **and** an `ensureColumn(db, "nominations", "committee_hydrated_at", "TEXT")` call (the live populated DB — match the existing call-site form at ~925–941).
- Add to the index DDL array: `CREATE INDEX IF NOT EXISTS idx_nominations_hydrate ON nominations(pn_number) WHERE is_military = 0 AND committee_hydrated_at IS NULL` — the HO 406 summarize-queue precedent: a partial index over exactly the un-hydrated civilian rows, so as rows hydrate they drop out and the queue scan stays tiny. Hydration queries it with `INDEXED BY` (Turso's statless planner mis-plans an `IS NULL` scan unhinted — the HO 406/407/369 lesson).

### 1b. `hydrateNominations(opts)` (`lib/nominations-sync.ts`)

Mirror the module's existing shape (reuse `dbRetry`, `fetchJson`, `getDb`, the `FLUSH_AT` batch flush, the deadline pattern). New export:

```ts
export interface HydrateOptions { backfill?: boolean; deadlineMs?: number; cap?: number }
export interface HydrateResult {
  mode: "backfill" | "delta"; processed: number; withCommittee: number; noCommittee: number;
  resolvedAgainstTracked: number; unresolved: number; dualReferralDropped: number;
  fetches: number; throttled429: number; deadlineHit: boolean; remaining: number;
}
export async function hydrateNominations(opts: HydrateOptions = {}): Promise<HydrateResult>
```

- **Queue:** `SELECT id, pn_number, part_number, raw_json FROM nominations INDEXED BY idx_nominations_hydrate WHERE is_military = 0 AND committee_hydrated_at IS NULL ORDER BY pn_number ASC LIMIT ?` — `cap` = `opts.cap ?? (backfill ? 100_000 : 40)`. Deterministic ascending order so it's resumable.
- **Tracked set (for the `unresolved` tally only, not storage-gating):** `SELECT system_code FROM committees` → `Set`. Store whatever the API returns (loose-link convention); just COUNT any code not in the set — the 458 probe saw 0 unresolved, so a nonzero here is a `sync:committees` drift signal worth surfacing.
- **Per row:** `JSON.parse(raw_json)` → the item's `url`. `withKey(u)` = append `api_key` (+ `format=json` if absent), mirroring the 454 sub-resource pattern (`${u}${u.includes("?") ? "&" : "?"}...`). Fetch the detail; read `committees` `{count, url}`. If `count > 0`, fetch `withKey(committees.url)` → `committees[0].systemCode` (lowercase — matches `committees.system_code`); tally `withCommittee`, `resolvedAgainstTracked`/`unresolved`, and `dualReferralDropped` when `committees.length > 1`. If `count === 0`, `noCommittee++`, code stays NULL.
- **Patch (not upsert — the row exists):** `UPDATE nominations SET committee_system_code = ?, committee_hydrated_at = ? WHERE id = ?` (code or NULL; `committee_hydrated_at = new Date().toISOString()` on **every** processed row so no-committee rows exit the queue and never re-fetch). Batch + flush at `FLUSH_AT`.
- **Bounds:** stop starting rows at `deadlineMs` (set `deadlineHit`); `remaining` = queue count still NULL at exit. `mode` = `backfill ? "backfill" : "delta"`.

### 1c. CLI (`scripts/sync-nominations.ts`)

Add `--hydrate` alongside `--backfill`/`--repair`: `if (process.argv.includes("--hydrate"))` → `hydrateNominations({ backfill: true })`, print `[nominations] hydrate processed=… withCommittee=… noCommittee=… resolved=… unresolved=… dualDropped=… fetches=… remaining=… (Ns)`, exit `remaining === 0 ? 0 : 1`. Add the usage comment line (`# per-part committee referral hydration`).

### 1d. Cron step (`app/api/cron/nominations/route.ts`)

Add a **bounded** hydration pass after the sync, under the existing `maxDuration = 60` (the delta is tiny — the 830-row initial populate is the CLI run, §1e). Restructure the two budgets so both fit:

- Sync deadline `routeStart + 45_000` (was 50s — list-only sync drains in seconds on a normal tick, and even a bulk-refresh re-fetch is ~8 pages; 45s is ample).
- Then `hydrateNominations({ deadlineMs: routeStart + 55_000, cap: 40 })` — `HYDRATE_CAP_PER_TICK = 40`. Worst case ~40×~2 fetches ≈ under the 55s wall; a bulk-refresh day leaves hydrate ~10s → fewer rows, drained next tick.
- Fold the hydrate result into the payload; extend `chronicErr` with `hydrate deadline hit (remaining N)` when `deadlineHit`, and `hydrate unresolved: N` when `unresolved > 0`. Keep the single `revalidateTag("nominations")`.

### 1e. Initial populate (DB op, no diff)

After the migration commit, run `npm run sync:nominations -- --hydrate` **once** — the full 830-civilian walk (~5–8 min per the 458 projection). Report the result line (expect `withCommittee ~813 / noCommittee ~17 / resolved == withCommittee / unresolved 0 / dualDropped ~30 / remaining 0`). The cron only ever faces the delta after this. (Same pattern as the `--backfill` initial populate — CLI does the bulk, cron does the trickle.)

---

## Commit 2 — surface: query helpers + `/committee` section + `?committee=` filter

### 2a. `getCommitteeNominations(systemCode, limit)` (`lib/queries.ts`)

Civilian, this committee's referred nominations, newest-first — reuses `NominationListRow`:

```sql
SELECT id, citation, description, organization, disposition,
       latest_action_text, latest_action_date, received_date
FROM nominations
WHERE is_military = 0 AND committee_system_code = ?
ORDER BY COALESCE(latest_action_date, received_date) DESC, pn_number DESC
LIMIT ?
```
Sibling aggregate for the header: `SELECT COUNT(*) AS total, SUM(disposition = 'confirmed') AS confirmed FROM nominations WHERE is_military = 0 AND committee_system_code = ?`. Return `{ rows: NominationListRow[]; total: number; confirmed: number }`. `unstable_cache`, `tags: ["nominations"]`, `revalidate: 3600`, try/catch → `{ rows: [], total: 0, confirmed: 0 }` (a non-Senate committee returns empty → the section omits itself; a read error degrades, never 500s). Pass `code` already lowercased (the page does `systemCode.toLowerCase()`), matching the stored lowercase code.

### 2b. `committee` filter on `getNominations` (`lib/queries.ts`)

Extend the opts type with `committee?: string` and add one branch to the existing where-builder (the `is_military = 0` block at ~3108):
```ts
if (opts.committee) { where.push("committee_system_code = ?"); args.push(opts.committee); }
```
Injection-safe (bound arg), composes cleanly with `agency`/`disposition`/pagination — nothing else changes.

### 2c. `/nominations` page (`app/nominations/page.tsx`)

- Read `?committee=` from `searchParams`; pass to `getNominations({ agency, disposition, committee, page })`.
- When `?committee=` is present, resolve its name for the chip via `getCommitteeBySystemCode(code)` (already imported elsewhere; a cheap cached read) — render a removable committee chip (`{name} ✕` → clears `committee`) beside the existing agency/disposition chips, and include it in the clear-filters reset. If the code resolves to no committee, show the raw code in the chip (honest fallback).

### 2d. `/committee/[systemCode]` NOMINATIONS section (`app/committee/[systemCode]/page.tsx`)

- Add `getCommitteeNominations(committee.systemCode, NOMINATIONS_CAP)` to the existing `Promise.all` (`NOMINATIONS_CAP = 25`, mirroring `RECENT_LIMIT`).
- Render a **full-width `<section>` after "Hearings & meetings"** (nominations = the Senate committee's confirmation workload, a distinct band from the legislative bill/hearing work; it sits last). Match the section idiom exactly: `border` / `border-strong`, a `border-b px-3 py-2 bg-panel` header with a `text-[12px] uppercase tracking-[0.5px] text-secondary` label **"Nominations referred"** + a `text-[11px] text-muted tabular-nums` count `{total} referred · {confirmed} confirmed`, body = `<ul>` of `NominationRow` (reuse — non-linked, matches `/nominations`).
- **Omit the section entirely when `total === 0`** (the `meetingGroups.length > 0` conditional idiom) — House/joint committees structurally have none, so no "No nominations" noise; the section appears only where it's meaningful (Senate committees with referrals).
- If `total > NOMINATIONS_CAP`, a foot (the `hearings-embed-foot` grammar) `{total - shown} more referred · see all on /nominations →` linking `/nominations?committee={committee.systemCode}` (the 2b/2c filter — this makes the cross-link bidirectional and gives busy committees like Judiciary/Foreign Relations a real overflow path).

---

## Explicitly NOT in 459 (scope guard)

- **`nominee_count` stays deferred / NULL.** 458 confirmed it's a cheap embedded read on the same walk, but it's **military-only** (civilian PNs are 1 nominee) and orthogonal to the committee cross-link — folding it in means bolting a ~1,051-PN military detail walk onto the civilian hydration for a stat with **no consumer** (no military view; `/nomination/[id]` still BANKED). The column stays NULLABLE for a future military-view HO. Civilian committee hydration only.
- **No `nomination_committees` link table.** Single `committee_system_code`, primary referral; the 6/150 dual-referral secondary is dropped (disclosed here, not surfaced). Revisit only if sequential referral turns out to matter.
- **No `/nomination/[id]` detail page** — still BANKED; the committee-section rows and `/nominations` rows stay non-linked.
- **No new nav item, no new cron route** — the section rides `/committee/[systemCode]`; hydration rides the existing `/api/cron/nominations`.

---

## Git discipline

- Plan → diff → **wait for approval.** No auto-commit. Two commits, explicit pathspec:
  - **Commit 1 (data):** `scripts/migrate.ts` + `lib/nominations-sync.ts` + `scripts/sync-nominations.ts` + `app/api/cron/nominations/route.ts`. Message: `feat(nominations): committee hydration — detail walk + hydrate mode + cron step (HO 459)`.
  - **Commit 2 (surface):** `lib/queries.ts` + `app/nominations/page.tsx` + `app/committee/[systemCode]/page.tsx`. Message: `feat(nominations): committee cross-link — /committee section + ?committee filter (HO 459)`.
- The initial `--hydrate` populate (§1e) is a DB op between the commits — no diff; report the result line.
- Eyeball ancestry before each push: commits riding, clean fast-forward, nothing behind, nothing unrelated staged, and the **concurrent session's 7 race-UI files untouched** (`globals.css`, `RaceCard.tsx`, `CompetitiveRacesBlock.tsx`, `CompetitiveRacesStrip.tsx`, `RaceHubBody.tsx`, `RacesBoxTabs.tsx`, `RacesUpdatesContext.tsx`). Report each SHA.
- **Prod-verify:** a busy Senate committee (`ssfr00` Foreign Relations or `ssju00` Judiciary) renders the Nominations-referred section with the confirmed count + "see all" foot; `/nominations?committee=ssju00` filters the list and shows a removable committee chip; a House committee (`hsju00`) omits the section; the hydration report shows ~98% withCommittee / 100% resolved / 0 unresolved. Then `verify:deploy` and report prod-green. (No doc churn — the arc narrates into the roadmap block at its sweep, per the 446/454 precedent.)

---

read docs/handoffs/459-nominations-committee-crosslink.md and follow it
