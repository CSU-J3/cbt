# HO 528 — doc sweep for HO 527 (participation dotplot)

Records the HO 527 `/members` participation dotplot across the four docs. **No bar move** — it rode as an enabling surface (Member depth already 100, the HO 425 dotplot precedent). Two commits, in this order:

- **Commit A (normal):** `docs/roadmap.md` + `docs/backlog.md` + `docs/oddities.md`. Diff shown, approved, FF push.
- **Commit B (SKILL, review-ref route):** `.claude/skills/cbt/SKILL.md` alone — the self-mod guard. Build it locally, `git push origin HEAD:refs/heads/528-review`, I fetch + read the diff out of the repo and approve, then you FF main and delete the ref. **Do not** paste the SKILL diff into chat (the relay swallows it — HO 508); the review-ref is the route.

Docs and code never ride together (527 code already landed at `7fa729c`); the two doc commits stay separate.

---

## §1 — `docs/roadmap.md` (Commit A)

Insert this block **after the "Also (HO 522–525)" block and before the "Banked / unbuilt:" line**, then bump the pointer.

```
**Also (HO 527), the `/members` participation dotplot — the participation arc's population cut, no bar move.** The population twin of the member-hub participation display (B1 523 + B2 525), built as `IdeologyStrip`'s sibling — the exact member-hub→`/members`-dotplot progression the ideology arc took (hub axis 421 → dotplot 425). Shipped + prod-verified; live SHA `7fa729c`. **`getParticipationStrip()`** (`lib/queries.ts`) is a new sibling of `getIdeologyStrip` (NOT an extension of `getChamberParticipationContext`, which returns only per-chamber medians): every floored current member (`is_current=1`, `HAVING total >= PARTICIPATION_FLOOR`, metric `not_voting/total` — the **identical B1 population**, so the strip's client-computed chamber medians echo the hub context by construction) plus an `is_delegate` flag; small-table population read, no `INDEXED BY`/no new index (the `getIdeologyStrip`/band regime), `unstable_cache` tag `votes`/3600. **`ParticipationStrip`** (`components/ParticipationStrip.tsx`) is `IdeologyStrip` cloned with the metric deltas: domain **0..CAP=30** (locked from STEP 0's non-delegate max 29.02, not a mockup number), 0.5pp Wilkinson bins, dots **party-colored** (so high-miss clustering by party reads — roadmap lens #4), median ticks on the **CHAMBER split** (HSE/SEN, neutral amber — NOT party, the meaningful split since the House votes far more than the Senate), no empty-center annotation (participation is unimodal-skewed). Placed **open directly below** `IdeologyStrip`, rescoped by the same chamber toggle only (`partDots` mirrors `stripDots`); CSS **additive under `.part-strip-*`**, `IdeologyStrip` byte-identical (the containment rule's next test). **The delegate carve-out is the load-bearing detail (the HO 523/525 banked constraint, now discharged for the dotplot):** non-voting delegates are excluded from both cloud and median via the territorial predicate `chamber='house' AND state IN ('DC','AS','GU','MP','PR','VI')` (there is no delegate flag — the 6-code set catches exactly the 6 non-voting members), with the excluded count disclosed in the footer (the LDA/nominations disclose-the-exclusion posture). **The STEP-0 finding corrected a premise (oddities):** the carve-out is **population-correctness, not outlier-trimming** — only 2 of 6 delegates (Radewagen 82%, Plaskett 50%) are extreme outliers; the real high-miss tail is a **voting** member (Frederica Wilson 29% > 4 of the 6 delegates), which is what sets CAP. So delegates are dropped because they're structurally ineligible on final passage, NOT because they're the high scores. Prod-verified: HSE med 1.9% / SEN med 2.1% (= the B1 medians), chamber toggle rescopes (ALL 2 ticks 530/6 · HOUSE 1 tick 431/6 · SENATE 1 tick 99/0), delegates absent from the cloud, hover→hub. **Member depth holds at 100** — an enabling surface, no bar move (the HO 425 dotplot precedent, which also held). **Banked from the arc, still unbuilt:** a participation *sort/rank* on the roster (the carve-out constraint still binds it) + a career-chamber-median context (cheap from `member_career_votes`, deliberately unbuilt to avoid a 4-stat hero). Docs: HO 528. **Also notes now run through HO 527.**
```

Then change the pointer on the **HO 522–525 block's last line** from `**Also notes now run through HO 525.**` to `**Also notes now run through HO 527.**` — wait: that pointer lives inside the 522–525 block. **Do NOT retro-edit the 522–525 block** (append-only changelog rule — HO 418 precedent). The running pointer is carried by the NEWEST block only; the new HO 527 block above already ends `**Also notes now run through HO 527.**`, so the pointer is bumped by adding the block, not by touching the old one. Leave the 522–525 block's own trailing pointer as-is.

## §2 — `docs/backlog.md` (Commit A)

**(a)** Replace the BANKED constraint line (currently opens `- **BANKED constraint — participation *rank* surfaces need a delegate-eligibility carve-out (HO 523/525).**`) with:

```
- **BANKED constraint — participation *rank* surfaces need a delegate-eligibility carve-out (HO 523/525; dotplot half SHIPPED HO 527).** The **`/members` participation dotplot SHIPPED HO 527** (`7fa729c`) WITH the carve-out — the territorial predicate `chamber='house' AND state IN ('DC','AS','GU','MP','PR','VI')` excludes the 6 non-voting delegates from both cloud and median, count disclosed (roadmap "Also (HO 527)" + the DONE tombstone below). The STEP-0 read sharpened the rule: the carve-out is **population-correctness, not outlier-trimming** — the real high-miss tail is a *voting* member (Wilson 29%), not the delegates (oddities). **The constraint still binds the two unbuilt surfaces:** a participation **sort/rank** on the roster or a Voting-tab rank thread must carry the same carve-out (a member's own-rate display stays fine without it — the B1/B2/HO-527-median precedent). **Also still banked from the arc:** a **career chamber-median context** (cheap from the `member_career_votes` rollup, deliberately unbuilt to avoid a 4-stat hero). *Gate:* a sort/rank surface actually landing. *Owner:* Corey.
```

**(b)** Append to the **DONE** section (append-only tombstones), in the HO 425 line-260 style:

```
- ~~**`/members` participation dotplot (HO 527)**~~ — SHIPPED `7fa729c`, verified live. The population cut of the participation arc — `IdeologyStrip`'s twin on the 119th missed-vote rate. **`getParticipationStrip()`** (sibling of `getIdeologyStrip`, NOT an extension of `getChamberParticipationContext`) returns every floored current member (the identical B1 population — `is_current=1`, `HAVING total >= PARTICIPATION_FLOOR`, `not_voting/total`) + an `is_delegate` flag; **`ParticipationStrip`** clones `IdeologyStrip` with the metric deltas (domain 0..CAP=30, 0.5pp Wilkinson bins, party-colored dots, chamber-split HSE/SEN median ticks in neutral amber, no empty-center annotation). Delegates carved from cloud+median via the territorial predicate (`chamber='house' AND state IN` the 6 territorial codes), count disclosed in the footer. Placed open below `IdeologyStrip`, rescoped by the chamber toggle only; CSS additive under `.part-strip-*`, `IdeologyStrip` byte-identical. STEP-0 finding: the carve-out is population-correctness, not outlier-trimming — the real high tail is a voting member (Wilson 29% > 4 of 6 delegates); only Radewagen 82% / Plaskett 50% are extreme (oddities). No bar move (enabling surface, the HO 425 precedent). Docs: HO 528.
```

## §3 — `docs/oddities.md` (Commit A)

Append a new `## …` entry (the tail-of-file convention):

```
## A delegate carve-out on a participation dotplot is population-correctness, not outlier-trimming — the real high tail is voting members (HO 527, Jul 2026)

The `/members` participation dotplot (HO 527) carves out the 6 non-voting House delegates — `chamber='house' AND state IN ('DC','AS','GU','MP','PR','VI')` (there is no delegate flag; that territorial set is the reliable predicate, and it caught exactly 6). The HO 527 handoff's premise was that the carve-out earns its place because "the delegates are the high outliers." The STEP-0 distribution read shows that's only half-true. Only **2 of 6** delegates are extreme outliers (Radewagen AS **82%**, Plaskett VI **50%**); King-Hinds (MP 22.6%) is mild; and Moylan/Norton/Hernández (GU 13.1 / DC 8.3 / PR 6.0%) sit **inside the normal cloud**. Conversely the non-delegate max is **29.02%** — Frederica Wilson, a full voting member — **higher than 4 of the 6 delegates**, with Hunt (24.7%) and Kean (22.8%) right behind. So the carve-out is a **population-correctness rule** (delegates are structurally ineligible on final-passage votes, Voteview `cast_code=9`, regardless of where their rate lands), **not** an outlier trim — and the surface's right edge (`CAP=30`) is set by real absentee **voting** members, not the carved delegates. Dropping the 2 extreme delegates genuinely rescues the domain (82%/50% would blow the x-axis to 5–6× the real ~29% spread), but the footer's "delegates excluded (non-voting)" disclosure is honest precisely because it's framed as structural ineligibility, not "worst attendance." The transferable rule: when a carve-out is justified as "removing the outliers," check whether the excluded set actually *is* the tail — here it isn't, and the correct justification (structural ineligibility) is stronger and survives the data not matching the premise. Same probe-the-premise class as the backlog-mechanism corrections (HO 512/514), on the distribution-shape axis.
```

---

## §4 — `.claude/skills/cbt/SKILL.md` (Commit B — review-ref route, SKILL alone)

Three edits. **Build locally, push to `528-review`, wait for my approval, then FF main + delete the ref.**

**Edit 1** — replace the participation-rank-constraint bullet (opens `- **Participation *rank* constraint (banked, applies to any future rank/sort surface).**`) with:

```
- **Participation *rank* constraint (HO 523/525; the DOTPLOT half now SHIPPED HO 527).** Both hub stats above are a member's **own displayed rate** — no carve-out needed. The **`/members` participation dotplot (HO 527) is the first surface bound by this** and applies the carve-out: `getParticipationStrip` flags delegates via **`chamber='house' AND state IN ('DC','AS','GU','MP','PR','VI')`** (there is no delegate column — that territorial set is the reliable predicate, and it catches exactly the 6 non-voting members), and `ParticipationStrip` excludes them from both the cloud and the chamber median, disclosing the count. **Still binds any future participation SORT/rank / Voting-tab rank** — same carve-out required. **The carve-out is population-correctness, NOT outlier-trimming** (the HO 527 STEP-0 finding — the real high-miss tail is a *voting* member, Wilson 29% > 4 of 6 delegates; only Radewagen 82% / Plaskett 50% are extreme; oddities). The median is robust to delegates; a rank is not. See oddities + backlog.
```

**Edit 2** — immediately after the `getIdeologyStrip()` helper bullet (opens `- \`getIdeologyStrip()\` — **HO 425**, the \`/members\` polarization dotplot.`), insert:

```
- `getParticipationStrip()` — **HO 527**, the `/members` participation dotplot (the participation twin of `getIdeologyStrip`). A **new sibling, NOT an extension of `getChamberParticipationContext`** (which returns only per-chamber medians). Returns every floored current member — `is_current=1`, `HAVING total >= PARTICIPATION_FLOOR`, metric `not_voting/total` (the **identical B1 population**, so the component's client-computed chamber medians echo the hub context by construction) — as `{ bioguideId, name, party, chamber, missedPct, isDelegate }`, with `is_delegate` = `chamber='house' AND state IN ('DC','AS','GU','MP','PR','VI')`. Small-table population read, **no `INDEXED BY`/no new index** (the `getIdeologyStrip`/band regime), `unstable_cache` tag **`votes`**/3600. The `ParticipationStrip` component filters to the live chamber scope, **excludes delegates from the cloud + median** (disclosing the count in the footer), maps the missed-rate onto a fixed **0..CAP=30** domain (0.5pp Wilkinson bins), colors dots by **party**, and ticks the **chamber** medians (HSE/SEN, neutral amber — not party). CSS additive under `.part-strip-*` (`IdeologyStrip` byte-identical).
```

**Edit 3** — in the `/members` route description, the sentence opening `**Two ideology surfaces mount above the browser:** the HO 425 \`IdeologyStrip\` dotplot, and — new at **HO 428** — \`PolarizationOverTime\` **collapsed by default** at the very top` — rewrite its lead so it names the participation strip as a third population strip:

```
**Three population strips mount above the browser:** the HO 425 `IdeologyStrip` dotplot; the HO 527 **`ParticipationStrip`** dotplot (119th missed-vote rate, non-voting delegates carved out — rendered open directly below `IdeologyStrip`, same chamber-toggle-only scope, `partDots` mirroring `stripDots`); and — from **HO 428** — `PolarizationOverTime` **collapsed by default** at the very top
```

(keep the rest of that sentence — the `~384px over-time chart … Promise.all` tail — unchanged; this is a lead-clause replace only).

---

## Guardrails + deliverable

- **Commit A first** (roadmap + backlog + oddities): explicit pathspec, diff shown + approved, ancestry eyeball (`git log --oneline @{u}..HEAD` — one commit riding, clean FF, concurrent-session files untouched), FF push.
- **Commit B (SKILL alone) via the review-ref route:** local commit → `git push origin HEAD:refs/heads/528-review` → I read the diff from the ref and approve → FF main → `git push origin :528-review` to delete. SKILL never lands on main without an approved diff.
- No `git add .` — pathspec only. Two commits total, neither riding with code. No bar edits anywhere (enabling surface).

read docs/handoffs/528-doc-sweep-527.md and follow it
