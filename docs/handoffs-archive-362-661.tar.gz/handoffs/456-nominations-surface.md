# HO 456 — `/nominations` surface: civilian nominations by agency + disposition

The nominations pillar's surface, on the HO 455 data layer (1,879 distinct PNs, 830 civilian, persisted disposition at 100% coverage). A **standalone** page (nominations have no bill spine and no member-sponsor — probe-confirmed), civilian-focused, leading with the **disposition distribution** the status model unlocks — the differentiator vs amendments. Closest precedent is `/lobbying` (standalone route + nav item + facet lens), but **simpler: live aggregation, no rollup blob** — the corpus is 1,879 rows (smaller than bills), so a `GROUP BY` computes live, the amendments/bills-scale call, not the `lda_*` precompute one.

Two commits: the disposition-rule tune (sync logic) lands first and gets re-backfilled, then the surface.

---

## Step 0 (commit 1) — the `computeNominationDisposition` tune + re-backfill

The HO 455 diagnostic left one genuine residual (0.05%): a confirmed nomination whose latest action is `Motion to reconsider … laid on the table` reads `received`. A motion to reconsider is only entered on a *completed* vote, and for nominations that vote is a confirmation ~always (rejections get withdrawn/returned, never voted down), so tabling-the-reconsider = **confirmation finalized**. Add the rule to `lib/nominations-sync.ts`, in the terminal-first block, **requiring the word `reconsider`** so a bare "motion to table [the nomination]" (a different, negative outcome) can't match it:

```ts
if (/\bconfirmed\b/.test(t)) return "confirmed";
if (/reconsider/.test(t) && /(tabled|laid on the table)/.test(t)) return "confirmed";  // reconsider tabled = confirmation finalized
if (/returned to the president/.test(t)) return "returned";
// … rest unchanged
```

Then re-run `npm run sync:nominations -- --backfill` (idempotent upsert recomputes `disposition` on every row, ~34s) and confirm the residual drops to the **2 genuinely-pending** rows (`unanimous consent agreement, vote {date}` → correctly `received`). Re-backfill is a DB op (no file diff) — the commit is just the one-line rule in `lib/nominations-sync.ts`. Message: `fix(nominations): reconsider-tabled disposition reads confirmed (HO 456)`.

---

## Step 1 (commit 2) — query layer in `lib/queries.ts`

Both live, `unstable_cache`, `tags: ["nominations"]`, `revalidate: 3600`, try/catch → null. **Civilian-scoped by default** (`is_military = 0`) — the surface's target; military (1,049 bulk service PNs) is excluded and disclosed, not shown.

**`getNominationsSummary()`** — the aggregates, one live pass over 1,879 rows (trivial):

```ts
export interface NominationsSummary {
  byDisposition: { disposition: NominationDisposition; count: number }[]; // is_military=0, pipeline order
  byAgency: { organization: string; count: number }[];                    // is_military=0, count desc
  civilianTotal: number;
  militaryTotal: number;
}
```
`byDisposition`: `SELECT disposition, COUNT(*) … WHERE is_military=0 GROUP BY disposition`, then order to the pipeline sequence (confirmed, returned, withdrawn, calendar, reported, hearings, referred, received) in JS, not alphabetically. `byAgency`: `… WHERE is_military=0 GROUP BY organization ORDER BY COUNT(*) DESC`. `civilianTotal`/`militaryTotal`: two `COUNT(*)` by `is_military`.

**`getNominations({ agency?, disposition?, page })`** — the filtered civilian list, paginated:

```sql
SELECT id, citation, description, organization, disposition,
       latest_action_text, latest_action_date, received_date
FROM nominations
WHERE is_military = 0
  [AND organization = :agency]
  [AND disposition = :disposition]
ORDER BY COALESCE(latest_action_date, received_date) DESC, pn_number DESC
LIMIT :size OFFSET :off
```
Return `{ rows, total }` (a sibling `COUNT(*)` with the same WHERE sizes the pager). `PAGE_SIZE = 25`. **No `MAX_FEED_PAGES` clamp** — 830 civilian rows have no deep-OFFSET tail problem (the `/lobbying` clamp existed only because of its 108k-row table); the full civilian list is explorable. Validate `disposition` against the enum and `agency` against a known-organizations set (or just parameterize — both are equality filters, injection-safe via bound args).

---

## Step 2 (commit 2) — components

**`NominationDispositionBadge`** (`components/NominationDispositionBadge.tsx`) — maps the enum to a colored badge, reusing the existing stage/status palette (don't invent one):
- `confirmed` → positive green (the enacted/passed stage green).
- `returned`, `withdrawn` → negative red (the failed stage red).
- `calendar`, `reported`, `hearings`, `referred`, `received` → in-pipeline amber/neutral (`--accent-amber` or `--text-muted`).
Label the badge with a readable disposition name (`confirmed`, `returned to president`, `in committee` for referred, `hearings held`, etc — a small display-label map; keep the enum value as the filter key).

**`NominationRow`** (`components/NominationRow.tsx`) — one list row, non-linked in v1 (no `/nomination/[id]` detail page — the list is the surface):
- **Lead:** `description` (the civilian nominee + position, e.g. "Johnny Figueroa, of Florida, to be Ambassador…"), `text-[13px]`, clamp 2 lines. No parsing — the description reads cleanly as-is.
- **Meta row:** `organization` (agency, as a muted tag) · `NominationDispositionBadge` · the date (`COALESCE(latest_action_date, received_date)` via `formatDateLong`) · `citation` (PN246-17) in `--text-muted` mono as a reference.
- Match the member/lobbying row grammar (`px-4`, `0.5px solid var(--border-soft)` dividers).

**Disposition strip + agency facet** — inline in the page or small components, mirroring `IssueBars`' clickable-facet pattern (`components/IssueBars.tsx` is the reference):
- **Disposition strip** (the headline): the `byDisposition` civilian distribution as a horizontal stacked/segmented bar or a stat row, each segment colored by the badge palette and **clickable to filter** (`?disposition=confirmed`), with counts. This is the differentiator visual — lead with it.
- **Agency facet:** `byAgency` top agencies (State, Justice, The Judiciary, Defense, …) as clickable rows/bars (`?agency=State`), count-sorted. Cap the visible list (top ~15) with the rest foldable or omitted.

---

## Step 3 (commit 2) — the page `app/nominations/page.tsx`

Mirror `/lobbying`'s shell (`HeaderBar basePath="/nominations"`, `export const dynamic = "force-dynamic"`, `searchParams` for filters). Structure:

- `searchParams: { agency?, disposition?, page? }`.
- `getNominationsSummary()` first (it sizes the pager context and drives the facets), then `getNominations({ agency, disposition, page })`.
- Null-guard: if the summary is null (shouldn't happen post-backfill, but guard it), render an honest empty state like `/lobbying`.
- **H1 + disclosure:** "Nominations" and a count line: `{civilianTotal} civilian nominations · {militaryTotal} military service nominations excluded` (the honest disclosure that military exists and is out of the civilian view — the LDA-style lossiness disclosure).
- **Disposition strip** (headline) → **agency facet** → **the list** (with active-filter chips for agency/disposition + a clear-filters link, and `Pagination` reusing the existing component).
- Active filters: reflect `?agency=` / `?disposition=` as removable chips; the list + pager honor them.

---

## Step 4 (commit 2) — nav

Add a `nominations` item to `NAV_ITEMS` in `components/HeaderBar.tsx`, in the **middle process-lens group** adjacent to `lobbying` (both are "Congress process" lenses beyond bills). Adjust the divider logic so `nominations` stays in the middle group (before the `reports` divider — the divider currently sits before `reports`; shift it so the new item is above it). Add the `pathToNavKey` mapping for `/nominations` if that map exists. Icon: a distinct glyph consistent with the set (propose `◈`; not `⚖`, which would misread as courts-only since The Judiciary is only one of 84 agencies). Label `Nominations`, tooltip `Presidential nominations — who's being confirmed, by agency and status`.

---

## Explicitly NOT in 456 (scope guard)

- **No military view** — civilian-only surface (disclosed count). A military-confirmations toggle is a later add if ever wanted; the `is_military` flag makes it a clean filter.
- **No `/nomination/[id]` detail page** — the list is the surface; rows are non-linked in v1.
- **No committee cross-link, no nominee-count, no detail hydration** — still deferred (the `committee_system_code`/`nominee_count` columns stay NULL). The `/committees/[id]` nominations cross-link is its own later HO (it owns the part-specific-detail fetch + the civilian committee-referral re-measure the probe flagged).
- **No rollup blob, no new cron step** — the cron already exists (HO 455, 09:00); this is a live-query surface under the existing `revalidateTag("nominations")`.

---

## Git discipline

- Plan → diff → **wait for approval.** No auto-commit. Two commits, explicit pathspec:
  - Commit 1 (tune): `lib/nominations-sync.ts`. Message: `fix(nominations): reconsider-tabled disposition reads confirmed (HO 456)`. Re-backfill after (DB op, no diff); report the residual dropping to 2.
  - Commit 2 (surface): `lib/queries.ts` + `components/NominationRow.tsx` + `components/NominationDispositionBadge.tsx` + (`components/IssueBars`-style facet bits if new files) + `app/nominations/page.tsx` + `components/HeaderBar.tsx`. Message: `feat(nominations): /nominations surface — by agency + disposition (HO 456)`.
- Eyeball ancestry before each push: commits riding, clean fast-forward, nothing behind, nothing unrelated staged, the concurrent session's files (`RaceCard.tsx` / `CompetitiveRacesBlock.tsx` / `CompetitiveRacesStrip.tsx` / `globals.css`) untouched and history preserved. Report each SHA.
- Prod-verify: `/nominations` renders the disposition strip (civilian ~60% confirmed) + agency facet (State/Justice/Judiciary…); clicking a disposition and an agency filters the list and the pager; the count line discloses the military exclusion; a filtered deep page loads (no tail 500). Then run `verify:deploy` and report prod-green.

---

read docs/handoffs/456-nominations-surface.md and follow it
