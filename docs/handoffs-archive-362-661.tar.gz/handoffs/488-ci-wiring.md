# HO 488 — CI wiring (GitHub Actions)

Stand up CI. There is none today: no `.github/` directory (the markets/kalshi workflows went away with the HO 475 Vercel-cron cutover), no `test` script, and the Playwright specs (`e2e/smoke.spec.ts` HO 379, `e2e/fit-finish.spec.ts` HO 472) can only be run by hand.

**Motivating failure, not hypothetical:** the HO 485 probe pushed at `3ed533c` with a broken `npm run typecheck`, undetected until the next session (fixed at `0614a66`). HO 487 wrote the pre-push typecheck gate into SKILL.md as a convention. A convention depends on remembering; CI doesn't.

## Sequencing — two phases, and Phase 1 is the whole point

**Phase 1 is secretless and catches the real failure. Do Phase 1 first and land it before touching Phase 2.** Don't bundle them. If Phase 2 turns out to need secrets you don't want to provision, Phase 1 still stands on its own and the arc is a success.

---

## Phase 1 — secretless CI (typecheck + lint + build)

### Step 1 — determine whether `next build` needs DB credentials

**Probe before writing the workflow.** Next 15 App Router will attempt to prerender any route that isn't dynamic; CBT's pages read Turso through `unstable_cache`. If any route prerenders at build time, `next build` fails in CI without `TURSO_DATABASE_URL` / `TURSO_AUTH_TOKEN`.

Test it locally with the DB env deliberately unset:

```bash
env -u TURSO_DATABASE_URL -u TURSO_AUTH_TOKEN -u GEMINI_API_KEY npm run build
```

Report the outcome. Three cases:
- **Build succeeds** → Phase 1 includes `build`. Best case.
- **Build fails only on specific routes** → name them and report whether they're already `export const dynamic = "force-dynamic"`. Do **not** add `force-dynamic` to make CI pass; changing runtime rendering behavior to satisfy a build check is backwards, and it's a live-surface change riding in a CI commit. Report and stop.
- **Build fails broadly** → Phase 1 is `typecheck` + `lint` only. Still catches `3ed533c`. Note it and move on.

### Step 2 — scripts (`package.json`)

Add, matching existing style:
- `"lint": "next lint"` — only if it isn't already wired; check first.
- `"test:e2e": "playwright test"` — Phase 2 uses it, but add it now so the harness is invokable by name.

Don't touch existing scripts.

### Step 3 — `.github/workflows/ci.yml`

- Triggers: `pull_request`, and `push` to `main`.
- `runs-on: ubuntu-latest`, single job `checks`.
- Node version pinned to match local — read it from `package.json` `engines` if set, otherwise `20`. State which you used.
- `actions/checkout@v4` → `actions/setup-node@v4` with `cache: npm` → `npm ci`.
- Steps, in order, each its own named step so a failure names itself: **typecheck** (`npm run typecheck`), **lint**, then **build** (only per the Step 1 verdict).
- `concurrency` group keyed on the ref with `cancel-in-progress: true`, so a rapid re-push doesn't queue redundant runs.
- No secrets, no `env:` block in Phase 1.

### Step 4 — verify it actually runs

Push to a branch and open a PR so the workflow fires. **A green check on a run that skipped every step is not a pass.** Confirm from the Actions log that typecheck genuinely executed. Then prove it catches the real thing: locally introduce a deliberate type error, confirm `npm run typecheck` fails, revert. Report both.

---

## Phase 2 — Playwright in CI (separate commit, only after Phase 1 is green)

E2E needs a running app, which needs DB credentials. Two routes:

- **Against the Vercel preview deploy** — no secrets, but needs the preview URL and the deploy to have finished. `verify:deploy` already polls for SHA promotion, so the pattern exists in-repo. **Blocker to check first: BotID.** HO 486 established that prod withholds content from headless browsers. If preview does the same, Playwright-against-preview is dead and you should say so rather than fight it.
- **Against a CI-local dev server** with `TURSO_DATABASE_URL` / `TURSO_AUTH_TOKEN` as repo secrets, using Playwright's `webServer` config.

**Report which is viable before building either.** Check `playwright.config.ts` for an existing `baseURL` / `webServer` block and say what's there. If BotID blocks preview and Corey hasn't provisioned secrets, stop and report — Phase 1 alone is a complete result.

Also report: how long the two specs take locally, and whether either is flaky across three consecutive runs. A flaky suite wired to `pull_request` trains people to ignore red, which is worse than no CI.

## Constraints

- **No changes to `app/`, `components/`, `lib/`, or any runtime surface.** CI config, workflow files, and `package.json` scripts only. If CI reveals a real failure, report it — don't fix it in this HO.
- No `force-dynamic` or rendering changes to make a build pass (see Step 1).
- Don't add test *content*; the specs exist. This is wiring.

## Git discipline

- Clone / hard-reset to `origin/main` first — HEAD should be **`87fd133`** (HO 487 skill commit).
- Explicit pathspec staging. Never `git add .` — there are untracked diagnostic and design files in the tree that must stay out.
- **Phase 1 and Phase 2 are separate commits.** Phase 1: `ci: typecheck + build on PR and main (HO 488)`.
- Ancestry eyeball before push: `git log --oneline @{u}..HEAD`, clean fast-forward, no concurrent-session files touched. Fast-forward only, no force-push.
- Run `npm run typecheck` before pushing — the gate this HO is automating.

## Report back

The Step 1 build verdict (with the failing route names if any), the `ci.yml` diff, confirmation the workflow ran with steps genuinely executing, and the deliberate-type-error result. Then the Phase 2 viability finding (BotID on preview, existing `webServer` config, spec runtimes, flakiness across three runs) before building it.

---

read docs/handoffs/488-ci-wiring.md and follow it
