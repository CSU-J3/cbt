# HO 489 — React #418 hydration mismatch probe

Read-only diagnostic. **Identify the mismatching output; do not fix anything.** The fix HO comes after this reports.

## Why now

The HO 488 smoke run surfaced intermittent React #418 (hydration mismatch) on `/bills`, `/changes`, and `/dashboard-v2`. This is the blocker on CI Phase 2 — a suite that fails 3 of 41 tests intermittently can't be wired to `pull_request` without training everyone to ignore red. Fixing this unblocks e2e CI.

## The instrument matters — dev, not prod

Production React minifies error text: `#418` with no component name, no diff. **Development builds print the actual mismatch** ("Server: … Client: …") plus a component stack. Chasing this against the live URL is the wrong tool and will burn the session.

Run everything below against `npm run dev` locally.

## Probe on the hypothesis, not around it

The working theory is server-vs-client relative-timestamp rendering. **That is a claim, not a fact** — confirm or kill it with the dev-mode diff text before anyone scopes a fix. If the mismatch turns out to be something else, that's the useful finding.

There is already evidence for **two distinct root causes**, so don't collapse them:

- **`/dashboard-v2` is statically prerendered** (HO 488 build output: static route). Anything `now`-derived in a static page mismatches *structurally* — the HTML is frozen at build time, the client hydrates hours or days later. Expect a large, consistent delta, not a boundary-straddle.
- **`/bills` and `/changes` are dynamic.** These can only mismatch when the server render and the client hydration land in different buckets (minute/hour/day rollover), which fits the intermittency.

Same error code, different mechanisms. Report them separately.

## Steps

1. **Reproduce in dev with the real message.** Load each of `/bills`, `/changes`, `/dashboard-v2`. Capture from the browser console: the full hydration warning, the **exact** server-vs-client text values, and the component stack. Verbatim — the specific strings are the whole point.

2. **Confirm or kill the timestamp theory.** If the diff shows time-shaped values ("1d ago" vs "2d ago", a clock, a date), the theory holds. If it shows something else, report what.

3. **Enumerate the `now`-derived render paths on the three routes.** `grep` for `Date.now()`, `new Date()`, and the relative-time helpers in the components those pages render. Include the HO 183 cycling timezone stamp and the "LAST SYNC" header — both render a time and both appear in shared chrome, which would explain why three unrelated pages fail the same way.

4. **Nail the static case specifically.** For `/dashboard-v2`, report which value is baked into the build-time HTML and how stale it is at hydration. If a static page renders a live timestamp, that's a standalone finding worth writing down regardless of the others.

5. **Check whether shared chrome is the common factor.** If the mismatching element lives in a layout or header rendered by all three routes, the fix is one place, not three. Say so explicitly either way.

6. **Re-run smoke three times against dev** and report which of the four failures reproduce. The markets-hover failure was consistent headless and is probably a separate matter — say whether it's hydration-related or not.

## Constraints

- **No fixes.** Not the timestamp, not the components, nothing.
- **Do not reach for `suppressHydrationWarning`.** It silences the warning while leaving React discarding server HTML and re-rendering on the client. If it already appears anywhere in the tree, report where — it may be hiding related mismatches.
- No changes to `app/`, `components/`, `lib/`. If a throwaway script helps, keep it out of the commit.
- Nothing to commit unless a diagnostic script is genuinely reusable; if not, this HO produces a report only.

## Git discipline

If there's nothing durable to commit, **push nothing** and just report. If a script is worth keeping, it goes in `scripts/diagnostic/` by explicit pathspec, one commit, typecheck clean before push (now enforced by CI at `3aa677c`), ancestry eyeball, fast-forward only.

## Report back

Per route: the verbatim server-vs-client diff, the component stack, and which mechanism it is (static-staleness vs dynamic boundary-straddle). Then whether shared chrome is the common factor, and the three-run reproduction results. I'll scope the fix from that — and it may be two fixes.

---

read docs/handoffs/489-hydration-mismatch-probe.md and follow it
