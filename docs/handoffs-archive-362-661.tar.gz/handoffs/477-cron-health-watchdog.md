# HO 477 — cron-health watchdog (generalizes the banked markets watchdog)

The banked "Markets watchdog" — catch a cron that silently **stops firing**, which the HO 314→475 floor bounds staleness for but doesn't *detect*. The load-bearing insight: a stopped cron is **invisible to Vercel's own monitoring** — no invocation means no function error to alert on — so the only thing that catches it is an external "is the data fresh?" **pull**. Generalize to the whole fleet: the infra is identical, HO 135 already aimed at all routes (just went stale at HO 433), and a stopped `summarize`/`news`/`sync` is worse than stale markets. **Build-not-probe:** the reads ride `idx_cron_runs_route_started`, no new cold query.

## What exists (ground truth @ `45e70f6`)

- **`cron_runs`** — `route` / `started_at` / `ended_at` / `elapsed_ms` / `status` (`running`/`success`/`error`/`timeout`/`orphaned`) / `payload` / `error_message`. Indexed `(route, started_at DESC)` + `(status)`. Every tick logs via `wrapCronRoute` (`lib/cron-log.ts`): hard failures → `error`/`timeout`; chronic-but-non-fatal → `success` + `error_message` (the ghost pattern).
- **`scripts/diagnostic/cron-health-135.ts`** — a read-only CLI rollup, but its `ROUTES` list is **stale**: 7 pre-HO-433 routes at daily times, missing markets/kalshi/lda/amendments/nominations/committees/rating-history.
- **POLY-SHUTDOWN ghost** = a `/api/cron/markets` **`success`** row with `error_message = "markets fetch failures: <…POLY-SHUTDOWN…>"` (the chronicErr at markets/route.ts:140, fired whenever `failed.length > 0`).
- **Route-string reality (shapes the registry):** the markets route logs a **fixed `route="/api/cron/markets"` regardless of `?source`** (markets/route.ts:104), so the bare (`0 */4`) and fmp (`0,30 13-21`) Vercel crons are **indistinguishable by the `route` column** — only by payload symbol-count. Kalshi logs `/api/cron/kalshi` (clean). So the registry has **14 route keys**, and `/api/cron/markets` is watched at the **bare 4h cadence** (fmp-specific freshness → banked, needs payload inspection).
- No existing `/api/health` or `/api/status` route (there's a `/api/version` for `verify:deploy`, unrelated).

## Build (one cohesive commit)

### 1. `lib/cron-health.ts` — shared health module (single source of truth)

- **`CRON_ROUTES` registry** — the 14 keys with `{ path, schedule, maxStaleMs, windowOnly? }`. `maxStaleMs` ≈ **2× cadence + ~1h grace**, from `vercel.json@45e70f6`:
  - `summarize` `*/10` → ~30m · `news` `*/30` → ~70m · `kalshi` `15 */2` → ~5h · `markets` (bare) `0 */4` → ~9h · `sync` `0 */6` → ~13h · `committees` `0 */12` → ~25h · daily (`sync-votes` `0 10`, `primaries` `0 12`, `rating-history` `0 15`, `lda` `0 8`, `amendments` `0 7`, `nominations` `0 9`) → ~26h.
  - **`windowOnly`** (weekly, so a flat age would false-alarm on the off-days): `weekly-report` `30 9 * * 1` and `sync-race-ratings` `0 11 * * 3` → generous flat **~9 days** MVP (window-aware next-fire precision banked).
- **`computeCronHealth()`** — for each route, read the most-recent run (`idx_cron_runs_route_started`). A route is **unhealthy** if EITHER (a) its most-recent **`success`** is older than `maxStaleMs` (stopped firing, or failing every tick), OR (b) its most-recent run is a hard `error`/`timeout`. **POLY-SHUTDOWN whitelist:** a `/api/cron/markets` `success` row is **healthy even with `error_message`, provided the only failing symbol is POLY-SHUTDOWN** — parse the `markets fetch failures:` list; if it names anything beyond POLY-SHUTDOWN, that's a real break → unhealthy. Returns `{ healthy, checkedAt, routes: [{ path, lastRunAt, lastStatus, ageMs, healthy, note? }], unhealthy: string[] }`.

### 2. `app/api/health/route.ts` — the pull surface (200 / 503)

- **GET**, calls `computeCronHealth()`, returns the JSON with HTTP **200 when `healthy`, 503 when not**. This is what an external uptime monitor watches — the only thing that catches a silently-stopped cron. **Do NOT wrap it in `wrapCronRoute`** (it's not a cron; it must not log itself into `cron_runs`). No writes, cheap.
- **Auth — recommend UNAUTHED public GET** (health checks conventionally are, and it exposes only cron freshness/timestamps, nothing sensitive). If you'd rather gate it, a `?token=CRON_SECRET` check is one line — your call.

### 3. Refresh `scripts/diagnostic/cron-health-135.ts`

- Point its `ROUTES` at the shared **`CRON_ROUTES`** registry (single source of truth, so the CLI and the endpoint never drift), picking up the 8 missing routes + the corrected HO-433 cadences. Keep its rich rollup (14-day per-route, errors/timeouts, chronic-OK, freshness, duration buckets). It stays a read-only manual diagnostic; the endpoint is the automated pull.

## Git + verify

- **Build-not-probe** (cron_runs indexed, no cold query). **One cohesive commit** (module + endpoint + diagnostic refresh — they share the registry; splitting orphans the module or leaves the diagnostic stale mid-arc). Explicit pathspec, show diff, wait for OK, ancestry check off `45e70f6`, no force.
- **Prod-verify:** hit `/api/health` on prod → expect **200 + `healthy: true`** with all 14 routes fresh; confirm the **POLY-SHUTDOWN ghost does NOT flip markets to unhealthy** (a markets `success`-with-ghost row reads healthy). Sanity-check one threshold against `cron_runs` (e.g., `summarize` `*/10` last success < 30m).

## The one external step (your call, out of repo)

The endpoint is a *pull* surface. For real *push* alerts, wire an external uptime monitor (UptimeRobot / cron-job.org / Better Uptime) at `https://congressional-terminal-chi-silk.vercel.app/api/health`, alerting on non-200. ~2 min, external — that's the "alert" the backlog wanted, and the only layer that catches a stopped cron. Recommended; nothing in-repo depends on it.

## Banked (not this HO)

- **fmp-specific freshness** — the markets route logs one `route` string for both bare + fmp, so fmp stopping while bare keeps firing isn't route-detectable; needs payload inspection (symbol-count or a `?source=fmp` marker). Bank.
- **Window-aware thresholds** for `weekly-report` / `sync-race-ratings` — the flat 9-day MVP catches a total stop; precise next-fire needs cron-expression parsing.

## Docs

Doc sweep is **HO 478** (the standing Docs: HO N+1) — written once the endpoint's confirmed live: close the "Markets watchdog" OPEN LOOP (generalized + shipped), roadmap "Also (HO 477)", a SKILL cron-health / `/api/health` note (self-mod guarded). Nothing doc-related lands in this HO.

---

Report the diff for approval; then the prod `/api/health` readout.
