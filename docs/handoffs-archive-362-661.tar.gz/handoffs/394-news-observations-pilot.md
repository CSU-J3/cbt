# HO 394 — News-as-Observations pilot

> Renumber to your next free HO if HEAD is past 393. Roadmap status block reads "As of HO 391"; this assumes 394 is free.

Prove the watchcore `Observation` contract on CBT's single most broken surface — news — as a fully reversible, additive pilot. The result decides a strategic question by measurement, not argument: does restructuring event surfaces as graded, bitemporal, entity-typed observations pay for CBT, or not.

## How to work this handoff

Spec-driven, per standing rules:

1. Read this file and the two watchcore references below. Do **not** write code yet.
2. Propose an implementation plan: exact files touched, the `observations` + `observation_entities` schema you'll add, the TS `Observation` shape, and the entity-extraction approach. Call out every decision this handoff leaves to you (PK/dedup mechanism, hash algorithm, match thresholds).
3. Wait for my review of the plan.
4. Implement. Show diffs. **Never auto-commit.** No commits, pushes, or destructive git ops until I've approved the diff.
5. Run the measurement script and report the numbers back verbatim so we can make the adopt/borrow call from data.

Reference before planning: the watchcore repo, `docs/observation-schema.md` (the contract, the SQLite storage mapping, the collector rule, the two-stage dedup) and its `src/watchcore/observation.py` (the pydantic model to port). We are porting the **contract** to TypeScript, not importing the Python runtime.

## Why this surface, why now

The probe (2026-07-01) put hard numbers on it: **113 of 16,623 bills carry any news mention — 0.68%** — over a six-week window (273 `news_mentions` rows since 2026-05-15). The media-attention theme can't rank what it barely touches. And `news_mentions` is bill-keyed with `bill_id NOT NULL`, so every article that references a member, committee, or race but no specific bill is **dropped on the floor** — which is exactly why race→news and member→news are impossible today (the join wall the roadmap flags on every non-bill surface).

News is the right pilot because it is (a) measurably broken, (b) tiny (273 rows — trivial to reshape), and (c) the place watchcore's model fits hardest: the coverage gap and the join wall are both an **entity-resolution + near-dup** problem, which is precisely `entities[]` + `content_hash`/`cluster_id`.

**The funnel probe (2026-07-01) confirmed the premise and sharpened the fix.** One live ingest: 55 articles fetched, all 55 passed the keyword pre-filter, the bill-ID regex hit **0** (RSS subheads cite by topic, never by bill number), and the LLM matcher returned no_match on **42 of 55** — those 42 are dropped uncounted at the `if (billMatches.length === 0) continue` gate. The loss is not ingestion volume and not the pre-filter; it is that most congressional news is about **members, committees, caucuses, and floor procedure, not a specific numbered bill**, and the pipeline can only see bills. The dropped set is dominated by exactly what entity extraction rescues — Kean's return to the House, a Lawler/Raskin hearing clash, Gallego at Senate Ethics, Cassidy on Trump, Slotkin and the CBC, House Oversight subpoenas — all member/committee-joinable, all discarded today. Only ~3 of 30 sampled were pure noise; a handful were executive-branch (an EPA rule, Trump's financial disclosure — a preview of the Washington-downstream direction, out of scope here).

Efficiency kicker: every one of those 55 articles already costs a Gemini call, and 42 of them are spent reaching no_match and throwing the article away. Reframing that **same** call from bill-matching to entity-extraction converts the waste into member/committee tags at no new API cost.

One honest limit the probe sets: absolute volume is modest (~55/day from the current feeds), so the pilot's win is joinability and drop-rescue rate, not raw coverage. Scaling volume is later work — adding feeds under the collectors model — not this handoff. Gate B (joinability) is the real bar, not article count.

Reversibility is the whole point. This adds two new tables alongside the current schema and **dual-writes** — `news_mentions` stays intact as the live UI source and the rollback path. Nothing migrates. Delete the two tables and remove the dual-write hook and CBT is byte-for-byte where it is today.

## What to build

Four pieces, all additive.

### 1. The contract, in TypeScript — `lib/observation.ts`

Port watchcore's `Observation` to a plain TS interface plus a small constructor/validator. **No new dependency** (no zod) — hand-roll a strict `makeObservation(...)` that mirrors pydantic's `extra="forbid"` by rejecting unknown keys, and a `validateObservation(...)` that enforces the invariants below. Note zod as a possible later upgrade if we formalize; not for the pilot.

Fields (mirror the schema doc exactly): `schema_version`, `obs_id`, `source {collector, source_type, publisher?, url?, native_id?}`, `fetched_at`, `observed_at`, `obs_type`, `title`, `reliability` (A–F), `credibility` (1–6), `raw`, then optional `summary`, `entities[]`, `content_hash`, `cluster_id`, `first_seen`, `last_seen`, `supersedes`. Skip `geo`/`valid_from`/`valid_to` for the pilot (no geospatial or duration data in news) — but keep them reserved in the type as optional so the shape stays contract-compatible.

`obs_id` is a **deterministic** hash of `(collector, native_id || url || normalized(title), observed_at)` — watchcore's `make_id` scheme. Use a stable, portable algorithm (blake2b sliced to 32 hex chars matches watchcore's 16-byte digest if Node exposes it; sha256-sliced is an acceptable fallback). The exact algo is your plan decision, but it must be deterministic so re-ingesting the same RSS item upserts instead of duplicating — that is stage-one dedup for free.

`content_hash` = hash of normalized `title + summary` (lowercased, punctuation stripped, whitespace collapsed) — watchcore's stage-one near-dup key.

Invariants to enforce in `validateObservation`: both timestamps UTC and tz-aware; `fetched_at >= observed_at` in the normal case (flag, don't silently store, a violation); `reliability` and `credibility` always present; unknown keys rejected.

### 2. Schema — extend `scripts/migrate.ts`

Two new tables, idempotent `CREATE TABLE IF NOT EXISTS` alongside the existing 34. Follow CBT's established main-table + join-table idiom (`meeting_bills`, `committee_bills`).

- `observations` — one row per record. Scalar fields as columns; `source`, `raw`, `entities` as JSON `TEXT` (fidelity copy). Indexes on `observed_at DESC`, `obs_type`, `cluster_id`, `content_hash`; PK on `obs_id`.
- `observation_entities` — the **flattened, indexed** entity index that makes the joins fast (json_extract joins are the wrong tool here). Columns: `obs_id` (FK), `entity_type` (`bill | person | org | committee | location`), `entity_value` (normalized id: `bill_id`, `bioguide_id`, committee `system_code`; nullable for orgs with no id), `entity_name`, `role`. Index on `(entity_type, entity_value)`. Re-ingest must be idempotent — one row per (observation, entity); pick the PK/dedup mechanism in your plan (note `entity_value` can be null).

### 3. Dual-write news → observations — hook into `lib/news-ingest.ts`

Keep the existing `news_mentions` write **exactly as-is**. Add a parallel path that maps each ingested article to one `Observation` and writes it (plus its flattened entities). New mapper file, e.g. `lib/news-to-observation.ts`.

Per article:
- `source`: `collector = "news_<sourceId>"`, `source_type = "rss"`, `publisher` = outlet, `url`, `native_id` = RSS guid.
- `observed_at` = article `published_at`; `fetched_at` = `ingested_at`. **This split is the fix for the thing the roadmap got bitten by** (`stage_changed_at` history only starting 2026-05-11 — you could chart when you scraped, not when things happened). Only `observed_at` goes on a timeline.
- `obs_type = "news"`.
- `reliability` / `credibility` = a **per-source baseline** from `lib/news-sources.ts` config (an official/wire feed is not the trust level of an aggregator — e.g. Roll Call / The Hill / Politico ≈ B2, softer sources lower). This is the principled version of the `match_confidence` concern CBT already carries.
- `entities[]` — the crux (below).

### 4. Entity extraction — extend `lib/news-matcher.ts`

This is where coverage is won, and the probe pins the mechanism. Today the matcher's LLM call asks *"which bill(s) does this article reference?"*, fires on every article (all 55 pass the pre-filter), returns no_match for 42 of 55, and those articles vanish. **Reframe that same call** from bill-matching to typed-entity extraction — one call per article, no extra Gemini spend — now emitting:

- **Bills**: keep the regex bill-ID path but expect ~0 hits on RSS (probe: 0/55 — subheads never cite bill numbers); bill entities come from the LLM extraction. Emit `{type:"bill", value:"119-hr-1234"}`. Bill entities still feed the existing `news_mentions` write (dual-write unchanged).
- **Members**: extract against the `members` table (531 rows) → `{type:"person", value:<bioguide_id>, name:<display>}`. **Precision over recall** — bare last-name matches are noisy; require full name or a last name disambiguated by chamber/state/party. A wrong entity poisons the join; under-matching beats over-matching.
- **Committees / caucuses**: match `committees` names → `{type:"committee", value:<system_code>}`; caucus mentions (CBC, Freedom Caucus) map via the existing `caucus-config` / `affiliations`.

The win is structural: "Shouting match erupts between Lawler and Raskin at immigration hearing" — dropped today — lands as an observation with two `person` entities plus a `committee` entity, joinable to both members and the hearing. That is member→news and race→news (via `races.incumbent_bioguide_id`) existing for the first time.

**Acceptance set** — these real dropped titles must resolve to the right entities (all were no_match today):
- "Kean returns to House, says depression diagnosis led to 4-month absence" → person: Kean (NJ-07)
- "Senate Ethics dismisses allegations against Ruben Gallego" → person: Gallego
- "Congressional Black Caucus blasts Slotkin over her calls for new leadership" → person: Slotkin + caucus: CBC
- "House panel subpoenas Leon Black, escalating tactics in Epstein investigation" → committee: House Oversight
- Counter-case (must NOT over-tag): "Parasitic illness cases are spiking…" → empty `entities[]` (pure noise, correctly captured).

Per-entity match confidence is a phase-2 refinement; for the pilot, the extraction threshold handles precision and the observation grade carries source trust.

### 5. Cluster (stage-one only) — in the store path

Exact near-dup only: equal `content_hash` → shared `cluster_id`. **No MinHash/fuzzy** — deferred, matching watchcore's staging and CBT's "regex first, embeddings later" pattern. Set `first_seen`/`last_seen` on the cluster.

## Measurement — `scripts/diagnostic/news-observations-coverage.ts`

A read-only probe (CBT's `scripts/diagnostic/*` pattern) that prints, before and after a news run. **Baseline to beat (HO 394 probe, one run):** 55 fetched → 13 bill-matched → 42 dropped; the target is that ~76% dropped population landing as member/committee-tagged observations.

- Article intake vs capture: articles seen vs rows in `news_mentions` (bill-matched, current) vs rows in `observations` (all captured). **The delta is the coverage gain** — quantify the % of ingested articles that mention a member/committee but no bill (the currently-dropped population).
- `bills` with ≥1 news observation (compare to the 113 / 0.68% baseline).
- `members` with ≥1 news observation (via `observation_entities`).
- `races` with ≥1 news observation (join `observation_entities.entity_value` → `races.incumbent_bioguide_id`).

## Decision gates

Report the numbers; these decide adopt vs borrow:

- **Gate A — coverage.** Observations capture materially more articles than `news_mentions` (the dropped non-bill population now lands and is member/committee-tagged).
- **Gate B — joinability.** member→news and race→news return non-trivial counts via `observation_entities`.
- **Gate C — build cost.** The contract was clean to implement in TS and the dual-write did not destabilize the news cron (`app/api/cron/news/route.ts` still green).

A + B + C pass → **adopt**: next surfaces are `stock_trades`, `committee_meetings`, then bill actions, one at a time; entity tables never move. Any gate fails → the abstraction doesn't pay for CBT; drop the two tables, remove the dual-write, keep `news_mentions`, and pursue the plain source catalog instead.

## Non-goals (hold the line)

- **No** migration or edit of existing tables. `news_mentions` stays and remains the live UI source.
- **No** UI. This pilot is data + measurement only; the member→news / race→news surfaces are the reward *after* Gate B passes, not part of this handoff.
- **No** other event surfaces (trades/hearings/actions) — phase 2, gated on this result.
- **No** fuzzy/MinHash dedup, **no** geospatial, **no** normalize/detect/serve pipeline stages.
- **No** new runtime dependency; **no** decision on formal-adopt-vs-borrow (the numbers make it).

## Files likely touched

New: `lib/observation.ts`, `lib/news-to-observation.ts`, `scripts/diagnostic/news-observations-coverage.ts`.
Edited: `scripts/migrate.ts`, `lib/news-ingest.ts`, `lib/news-matcher.ts`, `lib/news-sources.ts` (per-source grade baselines). Read-through: `lib/db.ts`.

## Rollback

Drop `observations` + `observation_entities`, remove the dual-write hook in `lib/news-ingest.ts` and the mapper file. `news_mentions` and every other table are untouched throughout.
