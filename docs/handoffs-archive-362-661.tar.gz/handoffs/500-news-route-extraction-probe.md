# HO 500 — `/news` route extraction: scoping probe

Read-only survey. **No route changes, no extraction, no redirect flips, no deletions.** Produce a report; the build HO follows from it. Nothing to commit unless a durable script falls out — most likely this is a report only.

## Why a probe for a "just move it" task

The premise going in was that splitting `/news` off `/bills` is a greenfield route build. It isn't: **`app/news/page.tsx` already exists as a redirect stub** pointing *at* `/bills?mode=news`. The split was half-started and abandoned, so the real work is **inverting an existing arrow**, not laying a new one.

That makes the risk profile inbound-link-shaped, not query-shaped. `NewsView` in `app/bills/page.tsx` is self-contained and moves cleanly; what breaks a route extraction is the caller you didn't find, the redirect that now bounces twice, and the param contract nobody wrote down. This probe finds those before anything moves.

## Step 1 — the complete inbound-link set

Find **every** construction of a news-mode URL. Grep across `app/`, `components/`, `lib/`:

- Literal `/bills?mode=news` and `mode=news` in any string
- `/news` references (there may be existing external-facing links)
- Anywhere `mode` is set to `"news"` programmatically (`sp.set("mode", "news")`, object literals, ternaries)
- `basePath` props threaded into shared components — `Pagination`, `NewsFilters`, `HeaderBar`, `GroupTabs` all take a base path today; each is a link-construction site

Known starting set (**verify, don't trust — this list is a claim**): `components/MediaAttentionCell.tsx:28`, `app/news/page.tsx:21-22`, `components/NewsFilters.tsx:70`, `app/bills/page.tsx` (the mode toggle + `newsCarry`/`filterCarry` builders), `components/NewsRow.tsx`.

For each hit, report: file:line, what it constructs, and **whether it must flip** to `/news` or is bills-mode-only and stays.

**Also check `docs/` and `README`** for documented URLs — those don't break the build but they become wrong.

## Step 2 — the param-carry contract (the real decision)

Today the two modes **deliberately preserve each other's params across the toggle** (`app/bills/page.tsx` ~line 80: *"switching modes does NOT clear the other mode's params; they persist in the URL across switches"*). `NewsView` builds two carry sets (`newsCarry`, `filterCarry`) that round-trip eight BILLS-mode params — `topics`, `stage`, `q`, `sponsor`, `sort`, `chamber`, `ceremonial`, `cluster` — none of which news reads.

Once these are separate routes that cross-carry is either dead weight or a deliberate hand-off. **Report the options and recommend one:**

- **(a) Drop the cross-carry.** `/news` carries only news params (`source`, `topic`, `window`, `bill`, `signal`, `page`); `/bills` carries only bills params. Cleanest contract. Cost: navigating news → bills loses your bills filter state, which today survives.
- **(b) Preserve it via the nav link.** The `/bills` ⇄ `/news` links carry the other route's params along. Keeps today's behavior, but every link-construction site now needs the full param set — the complexity moves rather than leaves.
- **(c) Drop it, but preserve `q`** (or whichever single param is genuinely cross-cutting).

Say which you'd pick and why. **My prior is (a)** — the cross-carry exists because it's one page; separate routes are the moment to shed it, and a route carrying eight params it never reads is exactly the confusion the split is meant to end. Argue me out of it if the code says otherwise.

## Step 3 — shared-component blast radius

`NewsView` and `BillsView` share components. For each of `Pagination`, `NewsFilters`, `HeaderBar`, `GroupTabs`, `NewsRow` (plus anything else the render tree touches), report:

- Is it used by **both** views, or news-only?
- Does it take a `basePath`/`carry` prop, and what would the new value be?
- **Would extraction require changing the component itself, or only its props?**

That last question is the one that matters. **HO 486's `/bill/[id]` regression came from changing a shared component for one consumer's benefit.** If a component needs an actual signature change, flag it loudly — that's the part of the build that needs the every-consumer audit, not the route move.

## Step 4 — the redirect inversion

Currently `/news` → `/bills?mode=news`. After, `/bills?mode=news` → `/news`.

Report:
- What should `/bills?mode=news` do post-split — redirect to `/news` preserving news params, or 404/ignore the param? (Recommend one. Existing bookmarks and `MediaAttentionCell`'s current href argue for a redirect that carries `?bill=`.)
- **Any risk of a redirect loop** if both routes redirect at each other during a partial deploy.
- Whether the `mode` param should be **stripped entirely** from `/bills` (`sanitizeMode`, the toggle, `SearchParams.mode`) or kept as a legacy alias.

## Step 5 — what the mode toggle becomes

Today it's a segmented control switching a param in place. Across routes it becomes navigation. Report where it should live (stay in both page bodies? move into `HeaderBar`/`GroupTabs`?) and whether `GroupTabs`' existing `group="feed"` / `active="news"` handling already covers it — it may be doing this job already.

## Step 6 — sizing

Rough line counts: how much moves out of `app/bills/page.tsx`, how much lands in `app/news/page.tsx`, how many call sites flip. This decides whether the build is one commit or two (extraction, then link-flips).

## Constraints

- **Read-only.** No file moves, no edits to `app/`, `components/`, `lib/`.
- Don't start the extraction "to see if it works." The report is the deliverable.
- If something looks ambiguous — a caller you can't classify, a component that resists — **report it as an open question** rather than resolving it silently. Unresolved questions in the report are useful; guesses in the build are not.

## Report back

Step 1 table (every call site, flip-or-stay), Step 2 recommendation with reasoning, Step 3 per-component verdict flagging any signature change, Step 4 redirect decision, Step 5 toggle placement, Step 6 sizing. I'll write the build from it — and if Step 3 turns up a shared-component signature change, that may become its own commit.

---

read docs/handoffs/500-news-route-extraction-probe.md and follow it
