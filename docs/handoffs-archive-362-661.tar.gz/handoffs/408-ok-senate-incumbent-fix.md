# HO 408 — P1 fix: `S-OK-2026` wrong incumbent (Lankford → R-held open seat)

> Self-claim the next free number: `ls docs/handoffs/ | sort -V | tail`. If HEAD has moved past 407, renumber.
>
> This is the follow-on fix HO 404 §5 flagged as an immediate P1. Scope is **one race card**. It is not the general odd-year-Senate / `is_current` integrity arc — that stays the separate 404 OPEN LOOP.

## Target state

`/races` (and `/race/S-OK-2026`, and the dashboard battlefield strip if S-OK surfaces there) renders the 2026 Oklahoma Senate seat as a correct **R-held open seat**:

- incumbent = **Alan Armstrong (R)** — appointed 2026-03-24, barred from running
- `incumbent_running = 0` → OPEN tag renders, incumbent cash suppressed (the HO 221 treatment)
- **Lankford removed** — he is not this seat

If naming Armstrong isn't cleanly possible (see the members branch below), the acceptable floor is a correct R-held OPEN seat with no incumbent name — but not by nulling the bioguide (that trips the untested vacancy path; read on).

## Resolved premises — do not re-derive, both verified

**Real-world (verified live 2026-07-03).** The 2026 OK Senate race is the **Class II** seat: Inhofe (elected 2020) → Mullin (2022 special) → Mullin resigned **2026-03-23** to become DHS Secretary → Gov. Stitt appointed **Alan S. Armstrong (R)** on **2026-03-24**, who by OK law signed an oath **not to run** for the seat. So it is a genuinely open seat. **Kevin Hern** (OK-01) already won the **June 16** Republican primary with ~70% and is the nominee; the Democratic side goes to an **Aug 25 runoff** (Priest vs. Thomas). **James Lankford is the Class III OK senator, up in 2028** (term runs through Jan 2029) — he is a different seat entirely. The current `S-OK-2026 → Lankford` mapping is the bug.

**Architecture (confirmed from HO 84 / 260 / 221).** The card's incumbent is the `races.incumbent_bioguide_id → members` LEFT JOIN (`m.full_name AS incumbent_name`, the `getRacesIndex` pattern — NOT the `seat_incumbent_bioguide` subquery, which was corrected out in HO 254). So "Lankford" on the card = Lankford's bioguide sitting on the S-OK race row and resolving through members. The join is also where the departing/held party on an open seat comes from. Open-seat state is expressed by the HO 221 flag `incumbent_running` (`0` = not running → OPEN tag + cash suppression, `1` = running, `NULL` = uncurated). HO 221 **deliberately held S-OK out** of the retirement seed, so its `incumbent_running` is still `NULL` (no OPEN tag today). Per HO 221, `incumbent_bioguide_id IS NULL` means **vacancy / unmapped seat — 0 cases today, untested render path**; do **not** use a null bioguide to mean "open." Express open via `incumbent_running = 0` on a *mapped* incumbent.

**Don't confuse** `getRacesIndex` (137 rows, INNER JOIN on `race_ratings`) with `getMostCompetitiveRaces` (61 rows, `ABS(score) ≤ 1`) — swapping them broke HO 210. And this general-election open-seat flag is **not** the primaries `'open'` party-enum (e.g. `house-LA-01-2026-open` is an open *primary*, unrelated).

## Confirm before writing — three greps, report them, then apply

The fix is small, but two facts decide *where* it lands and *what value* gets written. Grep, paste the three results, and state the exact one-line change + the exact `incumbent_bioguide_id` you're about to write **before** editing anything.

1. **The race row.**
   `SELECT id, state, district, seat_type, incumbent_bioguide_id, incumbent_running FROM races WHERE id = 'S-OK-2026';`
   Confirm `incumbent_bioguide_id` is Lankford's (expected `L000575`) and `incumbent_running` is `NULL`. Also confirm whether a `retirement_note` column exists on `races` (HO 221 chose the boolean over the note, but line 35 referenced a note — grep the schema).

2. **Is Armstrong in `members`, and what is his real bioguide?**
   `SELECT bioguide_id, full_name, party, state, type, is_current FROM members WHERE state = 'OK' AND (type = 'sen' OR full_name LIKE '%Armstrong%');`
   **Read his bioguide_id from this result — do not type one from memory.** If he isn't there, note it; congress-legislators lists him (`legislators-current.yaml`, `terms[].class = 2`, sworn 2026-03-24), so he can be added via the standard members-sync path.

3. **Where the Lankford value is durably seeded.**
   Grep for the source of `races.incumbent_bioguide_id` for S-OK so the correction survives the next re-seed. Check `data/races-seed.json` (does it carry an incumbent mapping, or — per HO 171 — only rosters, `{ "races": [] }`?) and the HO 84 races-index seed build (the inline `[race_id, …, incumbent_bioguide_id, …]` array in `scripts/`). Identify which one holds `S-OK-2026 → L000575`. That file is where the durable fix goes; a bare DB `UPDATE` alone would be clobbered on the next re-seed.

## Apply (per what the greps show)

Point the S-OK race row at Armstrong and mark the seat open:

- **Correct the durable source** (whichever of `races-seed.json` / the index-seed array holds S-OK's incumbent) so `S-OK-2026 → incumbent_bioguide_id = <Armstrong's bioguide>` and `incumbent_running = 0`. Then re-run `npm run seed:races` (idempotent UPDATE) and confirm **only the S-OK row changed** — no other race's incumbent, rating, or roster touched.

- **Members branch:**
  - **Armstrong present (expected):** use his real bioguide from grep 2. Done.
  - **Armstrong absent:** add him via the standard members-sync path (`sync:members` / `sync:crosswalk` — whatever pulls `legislators-current.yaml`). He is a legitimately current senator, so this is a correct roster addition, not pollution. Re-read his bioguide after the add and use it. **Do not** fall back to nulling `incumbent_bioguide_id` to fake "open" — that makes S-OK the first `IS NULL` race (untested vacancy path, HO 221) and drops the R attribution. If, and only if, a targeted member add is undesirable for a reason the grep surfaces, stop and report rather than nulling — we'll decide together.

- **Cache:** if `/races` reads through `unstable_cache`, `revalidateTag` the races tag (allowlisted per SKILL) so the fix shows without waiting on TTL. Confirm the tag name against the live cache wiring before calling it.

## Verify live

- `npm run verify:deploy` — served SHA == pushed HEAD before claiming anything shipped.
- Cold-hit prod: `/races` shows the OK Senate card as **Armstrong (R) + OPEN tag, incumbent cash suppressed, no Lankford**. Check `/race/S-OK-2026` too, and the dashboard battlefield strip if S-OK appears there.
- **No regression:** a normal incumbent race still shows its incumbent + cash; a known retirement (S-KY McConnell or NY-21 Stefanik) still shows the OPEN tag. Nothing else moved.

## Scope / non-goals

- One card. The general fix — race→incumbent mapping has **no class-awareness**, which is the same root as the 404 "odd-year Senate dates + `is_current`" integrity OPEN LOOP — is out of scope. This corrects the one live P1 by hand; note in the backlog that the class-aware mapping remains the open integrity item (S-OK is the first instance discharged).
- Don't touch the candidate roster (Hern R / the Aug-25 D runoff) — that's current and lives in `race_candidates`.
- No full member re-sync beyond a targeted Armstrong add if grep 2 shows him missing.

## Rollback

Revert the seed edit + re-run `seed:races`. If Armstrong was added to `members`, that's a valid current-member record — leave it, or revert independently; it doesn't depend on the race fix.

## Doc sweep (rides the fix commit or a separate docs-only commit)

- `backlog.md` FIT & FINISH: close the **P1 S-OK-2026 wrong incumbent**. Leave the class-aware-mapping / odd-year-Senate integrity loop OPEN with a note that S-OK was the first instance fixed by hand.
- `oddities.md`: field note — race→incumbent mapping is not class-aware; `S-OK-2026` pointed at the wrong-class senator (Lankford/Class-III) for a Class-II seat, hand-corrected in HO 408. Appointee caretakers barred from running are the OPEN case even though `incumbent_running` was authored for retirements.
- `SKILL.md` only if the `incumbent_running` semantics or the seed apply-path actually changed (it trips its self-mod guard — re-approve, don't route around).
- Explicit pathspec on add + commit, ancestry re-checked, docs kept separate from code.
