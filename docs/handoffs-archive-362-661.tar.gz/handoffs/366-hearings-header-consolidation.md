# HO 366 — Hearings header consolidation

Confirm the next free number before saving: `ls docs/handoffs/ | sort -V | tail`. Body assumes 366; if taken, bump to the next free number, rename the file, and report the final name so the read instruction resolves.

Scope: `/hearings` page header only. Cut the redundant secondary `Hearings:\>` title, relocate its meeting count to the filter bar's right edge as a filter-reactive readout, and re-cluster the week stat next to the WEEK OF label, bare. Calendar grid (HO 306) untouched. Masthead chrome (HO 323/325) untouched.

## Mockups — which file governs which region

Two mockups attached:
- `hearings-header-consolidated.html` — full-page reference. Governs the masthead context (shown for orientation only, **do not edit**), the filter-bar layout + corpus readout, and the calendar.
- `week-stat-clustered.html` — week-strip exploration. Its variant **A1** (the LEAN one: `WEEK OF JUN 22 · 54 ▲37`, clustered, bare) governs the week strip.

They conflict on one detail. The full-page mock renders the week strip space-between and worded (`54 MEETINGS ▲37`); A1 clusters it left and drops the noun. **A1 wins** — clustered, bare. The spec is explicit ("clustered immediately after the label... No noun word"). The full-page mock's week strip is the older treatment; ignore it.

## Confirm before building

1. **What does the count represent? (data check)** The secondary header HO 323 preserved carries `· N MEETINGS · HOUSE x / SENATE y`. That count is what moves to the filter bar. Grep the query/source feeding it and determine its window: full 119th-Congress meeting total, or a bounded/rolling load (recent + upcoming weeks). The mockup's `69` sits right next to the week's `54`, and 54 is nearly all of 69, which reads like a window rather than a full-Congress total. If it's a window, the readout label must say so (qualify it with the actual range) so 69-next-to-54 isn't misleading. If it's genuinely the unbounded corpus, leave the label bare. Report which, and the qualifier wording if any.

2. **Share boundary (re-confirm HO 306).** HO 306 built the hearings calendar (filter bar + week header + grid) as one component serving both `/hearings` and the dashboard-v2 HEARINGS tab (B4). Confirm that still holds. It decides how the filter-bar and week-strip edits get scoped (next section). If they've diverged into two components, report it.

## Changes

### 1 — Remove the secondary title (`/hearings` page content)

Delete the `Hearings:\>_` secondary title line and its `· 119TH CONGRESS` tail (the page-level subtitle below the masthead, the one HO 323 left in place). Both echo the breadcrumb (`…\119TH\Hearings>_`) directly above. The meeting count currently riding this line doesn't disappear, it relocates to the filter bar (change 2). This supersedes HO 323's constraint that preserved the Hearings secondary header.

The calendar moves up one row as a result. That's the only layout effect; no spacing rework.

`/hearings`-scoped. The dashboard HEARINGS tab never rendered this title — leave it alone.

### 2 — Corpus readout on the filter bar (`/hearings`)

Add a right-aligned readout to the existing filter bar's right edge, same row as the TYPE / CHAMBER groups (which stay on the left, unchanged):

`{count} {TYPE-noun} · {h} HOUSE / {s} SENATE`

- Tabular nums on all counts. Dim noun-label, secondary-text numbers, muted chamber tags — match the mockup (`--text-dim` / `--text-secondary` / `--text-muted`). No new tokens.
- **Reactive to the same TYPE/CHAMBER state that already drives the week stat + grid (HO 306).** Not new filter behavior — the readout mirrors the active filter.
  - **Noun follows TYPE:** ALL → `MEETINGS`, HEARINGS → `HEARINGS`, MARKUPS → `MARKUPS`, BUSINESS → `BUSINESS`. (This is why the week strip can go bare — the active noun lives here.)
  - **Counts follow TYPE + CHAMBER.**
  - **Split shows only at CHAMBER=ALL.** CHAMBER=HOUSE or SENATE collapses to a single count plus that chamber tag: `{n} {TYPE-noun} · HOUSE` (drop the slash split).
- If the count is a window (premise 1), fold the qualifier in here.

Scope: `/hearings` only. If the filter bar is the shared component (premise 2), gate the readout so it renders on `/hearings` and not on the dashboard HEARINGS tab — that tab is height-pinned (HO 282/304/306) and space-constrained, and this count was never on it. Don't add it there; don't change that tab's height. If a clean prop/slot gate isn't possible, stop and report before forcing it.

### 3 — Cluster the week stat, bare (`/hearings`)

Today the week header (HO 306) is `WEEK OF …` left, `{count} {noun} {delta}` right. Re-cluster: stat immediately after the label, left-aligned, noun dropped.

`WEEK OF JUN 22 · 54 ▲37`

- Keep everything HO 306 already built on this stat: the count stays TYPE+CHAMBER-reactive, the delta stays week-over-week with the directional colors (▲ green `--stage-enacted` up / ▼ red down), and the hover breakdown (this week N · last week M · delta) stays anchored to the clustered stat. You're relocating and de-nouning the existing stat, not rebuilding it.
- Right edge clears (the readout is up in the filter bar now).
- **Bare always** — see the call below.

Scope: `/hearings`. If the week header is shared (premise 2), prefer applying the cluster in the shared component so the two surfaces don't drift (the HO 306 anti-drift principle), UNLESS that visibly alters the dashboard tab's pinned layout, in which case scope it to `/hearings`. Report what you did.

## Resolved calls

**Noun on the week stat → bare always** (spec open question 2). When TYPE≠ALL the bare `54` loses the noun that `17 HEARINGS` used to carry. Keep it bare anyway:
- the noun now lives in the filter-bar readout, reactive to TYPE, always on screen;
- the active TYPE chip (`[HEARINGS]`) already names what's counted;
- a conditional noun makes the stat grow and shrink on filter change, reintroducing the duplication and layout shift this consolidation removes.

**Week-strip treatment → clustered + bare** (mockup fork). A1 over the full-page mock, per above.

## Constraints

- **Masthead untouched.** Title row, LAST SYNC subhead (HO 325, stays count-free — the count lives in page content per 323/325), nav row: no edits. The mockup's masthead is context only; don't touch nav labels.
- **Calendar grid unchanged (HO 306).** Per-day counts stay in the column headers. Today-highlight, entries, hover card, live status: all as-is.
- **Dashboard HEARINGS tab no-regress.** No new readout, no height change, no visual drift. Its pinned height (HO 282/304/306) holds.
- Static. No new color tokens. Mono throughout. Tabular nums on every count.

## Docs / backlog

Don't run a doc sweep — single consolidation, sweep with the next batch. But:
- HO 323's "Hearings secondary header survives" constraint is now superseded; if `docs/backlog.md` OPEN LOOPS tracks that header, reconcile the entry.
- Removing the secondary title may orphan CSS classes or a page/component prop (the count plumbing). Flag orphans for `docs/backlog.md` cleanup (HO 323 pattern), don't sweep them into this commit.

## Ship

- `tsc` clean → `npm run build` clean.
- Named `git add` by pathspec, never `-A`. Re-check HEAD before push.
- `git push`, then `npm run verify:deploy` until served SHA === HEAD.
- Stale `.next` serves a stale CSS hash → 404 on the stylesheet → unstyled page. `tsc` + 200 + payload don't prove a styled render. If the dev server's been up a while, `rm -rf .next` + restart, and confirm the stylesheet loads before eyeballing.
- Live-verify on `/hearings`:
  - secondary `Hearings:>` title + `· 119TH CONGRESS` gone; calendar one row higher;
  - filter bar shows the corpus readout right-aligned; toggling TYPE changes the noun + counts, toggling CHAMBER collapses the split to a single chamber count, the readout tracks the grid's filter;
  - week stat clustered immediately after the label, bare `WEEK OF … · N ▲M`; hover breakdown still fires; delta direction and colors match HO 306;
  - if premise 1 found a window, the readout carries the qualifier.
- Regression: dashboard HEARINGS tab unchanged and still height-pinned; `/` untouched.
- Report: premise 1 finding (window or full corpus, plus any qualifier); premise 2 (shared or split component) and how you scoped each edit.
