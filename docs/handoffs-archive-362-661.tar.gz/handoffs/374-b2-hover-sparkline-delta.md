# HO 374 — B2 hover: sparkline + 1W delta

Add a 7d sparkline and a 1W delta to the HO 303 hover, both read from `market_ticks` history. HO 373 settled the parameters. No new data source, no schema change. Build on the existing tape data fetch and its cache.

## Resolved premises (HO 373 — do not re-derive)

- **Roll-stability is structural.** The markets cron writes `symbol.internal` (a stable key); the rolling Kalshi event ticker (`KXFEDDECISION-26JUL` → `-26SEP`) lives only in discovery inside `fetchKalshi` and never reaches `market_ticks.symbol`. One clean series per displayed odds item. Build no roll/merge logic.
- **Window 7d, x-axis time-based.** Plot each point at its true time position over [now−7d, now]; connect across gaps. Equities show wide flat weekend/holiday spans — correct, not a bug.
- **Key the series off the displayed tape roster's internal keys, not `SELECT DISTINCT symbol`.** 13 dead symbols sit in the table and must be ignored.
- **POLY-SHUTDOWN has zero rows.** Its figure renders N/A (as now). Shutdown's sparkline draws from the Kalshi `SHUTDOWN` key. Polymarket never drives a sparkline (below), so the empty Poly key is a non-issue for the spark.
- **Monthly cohort (CPI, UNEMP) has ~0–1 points in 7d.** Falls out of the ≥2-points gate automatically, renders figure + freshness only as it does now. No special-case.

## Scope — one new pair, applied uniformly

- **7d sparkline**, gated on ≥2 points in the window.
- **1W delta**, gated on a 7d anchor within +2d tolerance (suppressed for the <7d cohort).
- **Not adding a 24h delta.** Markets already show day-change on the figure (a 24h delta would echo it); for odds the sparkline carries the short-term shape. Keeps the box from bloating.

## Layout (HO 303 box, insert two rows before freshness)

1. name + sector — unchanged
2. note — unchanged
3. figure — unchanged (markets: value + day-change ▲/▼; odds: K/P, no change line)
4. **1W delta — NEW.** `1W +1.1pts` (odds) / `1W −2.1%` (markets), up/down colored, dim `1W` label. Omitted when suppressed.
5. **sparkline — NEW.** 7d, stroke-only, direction-colored, sized to box width, ~22px tall. Omitted when <2 pts.
6. freshness — unchanged

## Sparkline source per item

- markets / FRED-daily: that symbol's own series.
- odds (dual-source): **Kalshi series only** (deeper venue, HO 251). Polymarket stays the secondary figure number, not a second line. `POLY-*` keys never sparkline.

## Units

- markets / indices / FRED-daily delta: **percent**, `(now − anchor) / anchor`.
- odds delta: **percentage points**, `now − anchor` (price is already a probability).

## Rendering

- `y = (p − min) / (max − min)` over the series, SVG-inverted; `x` = time-normalized over [windowStart, now]. Flat series (`min == max`) → centered flat line; guard the divide-by-zero.
- stroke 1px, color = up-token if `last ≥ first` else down-token (existing tokens, **no new CSS var**). No fill, no axis, no labels.
- Connect across time gaps; don't break the path.

## Data + cache

- One batched query: the 7d series for the roster's internal keys, grouped in JS to per-symbol `{ticked_at, price}[]` ordered by time. Compute the 1W delta + suppression flags server-side; pass a clean shape to the hover component.
- **Fold this into the existing tape data fetch** so it's one cached object on the same revalidate tag. Do not add a separate uncached per-hover fetch (cold-start hazard; route-level `revalidate` is inert in Next 15 — cache at the query layer). The series adds ~500 rows to a query that's already trivial and well inside the 10s abort.

## Verify on ship

- POLY-SHUTDOWN figure N/A, shutdown still shows a (Kalshi) sparkline.
- CPI / UNEMP show no sparkline or delta (unchanged).
- A <7d item shows a sparkline spanning its lifetime but no 1W delta.
- An equity shows a weekend flat span in the spark, not a compressed or broken line.

## Ship

Commit the data helper + component changes (named `git add`, separate from anything unrelated). `git push`, `npm run verify:deploy`, served SHA === HEAD. On this UI ship confirm the stylesheet loads (HO 212 trap: a drifted `.next` serves a stale CSS hash → 404 on `layout.css` → unstyled page; `rm -rf .next` + restart if the server's been up a while). Live-verify: hover a market (1W delta + 7d spark, day-change still on the figure), Fed-cut odds (Kalshi spark, K/P figures, 1W in pts), shutdown (Poly N/A, Kalshi spark present), CPI (no spark, unchanged).

## Deferred (track in backlog at next sweep, don't build here)

- Resolution-date label on odds — HO 251 stores the event date; surface "next FOMC Jul 29" in the hover. Separate cheap handoff.
- Context-fields tier — day range / 52w-from-high for equities, OI / liquidity for odds. FMP `/stable/quote` and Kalshi already return these; surfacing them needs the fetch + `market_ticks` schema widened to persist them. Its own arc.
