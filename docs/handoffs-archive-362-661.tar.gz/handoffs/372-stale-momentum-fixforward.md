# HO 372 — /stale momentum overlay fix-forward

If `372` is taken (`ls docs/handoffs/ | sort -V | tail`), self-claim the next free number and rename.

Three issues found eyeballing the HO 371 expand on /stale before push. 371 is committed (`9f59b50`) but not pushed; fix these, then push 371+372 together. Each issue has a verify-first so nothing gets changed on a misread. Diff against `docs/design/stale-momentum-row.html` for the intended hearing-line format.

## Issue 1 — hearing date format (momentum-mode HEARING slot)

Live renders `MARKUP · SCHEDULED · TUE MAR 25 · 10:00m ET · 2141 Rayburn House Office Building`. The date has no year and a weekday, so on a 527-day-stale bill it reads like an upcoming hearing and undercuts the "then silent" line below it. The mock's format is `MARKUP · HELD · FEB 11, 2025 · 10:15 ET · 2175 RHOB`.

Fix: in the momentum-mode hearing render (the path HO 371 added that surfaces the most-recent past hearing), format the date as `MON DD, YYYY` and drop the weekday. The year is the point: it's what makes a past hearing unambiguous. Leave the non-momentum (HO 324 upcoming) path's format alone.

Same line: the time prints as `10:00m ET`, which looks malformed. Check the time helper feeding the hearing meta; it should read like `10:00 ET` (or `10:00 AM ET`). Low priority, fix in the same pass if the helper's obvious.

(Don't try to relabel `SCHEDULED` to `HELD`. A scheduled meeting may have been cancelled or postponed and never held, so asserting HELD can be wrong. The year plus the amber `NO ACTION IN Nd` carry the meaning once the date isn't ambiguous.)

## Issue 2 — cosponsor count disagrees with itself

On HR 28 the collapsed support figure shows `+83`; the expand COSPONSORS row shows `82`. Same bill, two numbers.

Verify-first: grep both reads. The collapsed `+N` figure uses `FeedBill.cosponsor_count` (the stored column, from `getStaleBills`). Find what `BillExpandPanel`'s COSPONSORS row uses for its count. If it derives the number a different way (counting a cosponsors array from a detail fetch, which differs from the stored `cosponsor_count` when there are withdrawn cosponsors), that's the divergence. If both already read the same field and the numbers still differ, do **not** patch it: report the two values and their sources, it's a sync/cache question, not a render one.

Fix (if the sources differ): point the expand's COSPONSORS value at the same `cosponsor_count` the collapsed figure uses, so the two always agree. The 5-segment bar's `ceil(count/10)` math then keys off the same number too.

## Issue 3 — dev overlay "2 issues"

The dev overlay shows a "2 issues" counter near the Preventing Violence row. Open it and report what the two are. If they're hydration mismatches introduced by the `showMomentum` conditional rendering or the new bar/hearing markup (server output not matching client), fix them so the gated subtree renders identically on both sides. If they're pre-existing or benign (and not from the 371 change), note them and leave them. Don't fix unrelated console noise in this pass.

## Ship
`tsc` clean. Commit with an explicit pathspec naming only what's touched (likely `BillExpandPanel` and a date/time format helper; the queries file only if Issue 2 turns out to be query-side). Never `git add -A`. Ancestry recheck. Corey pushes 371+372 together and runs `npm run verify:deploy`. After the SHA matches, re-eyeball the same HR 28 expand: year on the hearing date, one cosponsor number across collapsed and expand, dev overlay clean.
