# HO 612 — P4: `/members`. Pack the row, buy the pane, re-anchor leg C.

HEAD `42efcee`. Roadmap pointer: "run through HO 610" (P4 sweeps at phase close). **Next free is 612.**

Baseline (v2): `/members` M1 **548** (0 M1a / 548 M1b) · M2 1 · M3 3.14 · M4 2/84px. Narrow: 721/222/1297 overflow at 1024/900/720 — **read §4 before treating those as targets.** The 548 is one component: `.mc-row`'s `grid-template-columns: 1fr 320px 56px 64px 52px` (`globals.css:5563`) puts ~350px of name-cluster ink in a ~1,900px track at 2560, and every roster row donates that gap. Remediation is priced per component, and the component count here is one.

## 1. Commit 1 — the rider: HeaderBar's titlebar packs left

611's decomposition showed `/hearings`' entire M1 residue is `header` / `header > .header-titlebar` at 1,875px — site-wide chrome, two rows on every route. Same class as the strip rider: find what pins the titlebar's right cluster (`margin-left:auto` / `justify-content:space-between` in the `.header-*` CSS), pack it left after the breadcrumb with the house `·` separators, trailing gap right. The masthead set the precedent at 610 and SKILL owns the convention.

**One escape valve:** if the right cluster holds interactive controls whose edge position is load-bearing for discoverability (a search box users find by corner), HALT with a screenshot and a proposal instead of shipping — chrome consistency is the goal, not chrome surprise. Otherwise ship it.

Score: `--route hearings` (its M1 3 → 1, only `.hcal-filterbar` remains) and spot one more route. Eyeball `/bills` + `/members` headers at 1440/2560.

`fix(chrome): HO 612 — HeaderBar titlebar packs left (C1; −2 M1 on every route)`

## 2. Commit 2 — pack `.mc-row`

Cap the name track and let the row pack: `grid-template-columns: minmax(0, <CAP>) 320px 56px 64px 52px; justify-content: start`. **Derive the cap, don't tune it**: measure the widest rendered `.mc-mem` ink at 2560 (longest name + PartyTag + role badge + Palestine badge at the widest combination actually in the data) and set CAP to that plus ~2ch. Report the derivation the way 610's 50px bound was reported. The trailing gap then collects at the row's right edge, which is the target state and is measured-not-counted.

Nothing else in the row moves: the three numeric columns keep their shared right-aligned axis (that's a value axis, same logic as the funnel — but no `data-viz-row` here; the axis sits inside the packed span, so it never enters M1 once the row packs). The header row `.mc-row-hdr` takes the same template by inheritance — verify, don't assume.

Score: `--route members` — **M1 548 → ~0**. Decompose any residual before touching anything else; if the name→bar gap survives at some cap edge case, the cap derivation was wrong, not the threshold.

`fix(members): HO 612 — cap the name track; the roster row packs left (C1; 548 M1b from one grid line)`

## 3. Commit 3 — the pane (C8)

At **≥1750px** the roster renders as **two half-split lists side by side** (ranks 1–⌈N/2⌉ left, rest right), `align-items:start`, the `.mc-row-hdr` header repeated per pane. Below 1750px: single list, exactly as today. Split-half, not interleave — adjacent ranks stacking vertically is how a ranked list scans.

Mechanics that matter:

- **Two real `<ul>`s in a grid, not CSS `columns`** — an expanded `SponsorExpandedPanel` must grow its own pane without column-breaking or reflowing the sibling pane's rows.
- The split point is computed from the *rendered* list (after filters/search/RosterShowAll), so the panes stay balanced under every filter state.
- Expansion, `rowHref` replace/scroll behavior, and keyboard focus order all keep working; focus order follows DOM order, which under split-half is left-pane-then-right — acceptable and matches visual order.
- The strips, scatter, filter bar, and everything above the roster: untouched.

Score: `--route members` again at 2560 — M1 holds ~0, M2 stays ≤1 (`align-items:start` means neither pane stretches), and the page's vertical height roughly halves, which the eyeball confirms rather than an instrument.

`feat(members): HO 612 — two-pane roster at ≥1750px (C8: the freed width buys members, not gap)`

## 4. The narrow numbers: decompose once, fix only what's real

721/222/1297 predates this HO and is now known-contaminated: M5-overflow counts design-ellipsis (611 finding 1), and 548 `.truncate` names will each register at widths where they ellipsize. So:

- **Decompose, don't chase.** After commit 3, sample the per-element M5 output at 1024/900/720 and bucket it: (a) design-ellipsis (`.truncate`/`text-overflow` elements), (b) real overflow (anything else). Paste the split — it's the sizing input for the P4-close M5 v2 work.
- **The acceptance for this HO is the honest subset:** document-level `scrollWidth ≤ viewport` at all three widths, zero clipped *controls* (filters, toggles, search usable), and bucket (b) not larger than baseline. Bucket (a) is expected to be huge and is not a defect.
- If bucket (b) reveals something real and small (a fixed-width strip, a toggle row), fix it under the wrap-not-pin guard; if real and large, file it for the phase close rather than growing this HO.

## 5. Commit 4 — re-anchor leg C (the control this HO destroys)

v2's known-BAD control is "`/members` holds ~548." Commits 2–3 take it to ~0 **by design**, which is the falsification-anchor-expiry oddity on schedule: after this HO, a silenced instrument and a successful remediation read identically on the old anchor. So, **after** the members work is scored on the old anchor (pre-change run) and shipped:

- Re-point leg C at `/changes`, expect ≥ ~400 (it holds 471 and is P6 work, untouched until phase 6) — and add the fallback shape `2469404` gave the M2 leg, so the leg names where it fired rather than hard-failing when the next remediation lands.
- One-line comment in the script citing the oddity, so the next person re-anchors on purpose instead of by surprise.

`diag(layout): HO 612 — leg C re-anchors to /changes (the members anchor expired by remediation, as the oddity predicts)`

## 6. Verification and guards

1. Typecheck + build per commit; four commits in §1/§2/§3/§5 order; explicit pathspecs.
2. Falsification runs **before commits 2–3 on the old anchor** (it must hold 548 one last time) and **after commit 4 on the new one** (it must fire on `/changes`). Both prints in the HALT.
3. `--route members` at each stage as specced; `--route hearings` for the rider; `/` spot-checked unmoved (M1 0 · M2 0 · M4 42 · M1x 13).
4. Eyeball at 1440 / 1750-boundary / 2560: single→two-pane transition clean, expansion in each pane, header row per pane, sort/filter/search working, HeaderBar packed on three routes.
5. Prod-verify to the SHA, converged. **HALT** with: the cap derivation, all score tables (v2-labeled), the §4 bucket split, both falsification prints. No bills/news/trades work, no sweep.
6. Absence Watch untouched. The dotplot/ideology strips untouched. `--fs` tokens for anything 9–14px. The `data-viz-row` attribute is not used anywhere in this HO.
