# HO 636 — the HO 635 doc sweep: rename, close, and the two corrections

HEAD `bb54c22`. Roadmap pointer runs through HO 634. **Next free is 636** (635 is the code arc, five commits, landed).

Docs only. No code, no schema, no migration. Two commits minimum — docs and SKILL never ride together — and both go to `refs/heads/636-review` for a read before main fast-forwards.

---

## The two corrections go in first

Both were established after the code landed, and both correct something the record would otherwise carry wrong.

**1. The three participation figures need their labels, and my diagnosis of them was wrong.** I read the trio as accuracy scores against a shared yardstick and concluded 82.5% must be coverage. It isn't; coverage was 100% (40 resolved, 0 unresolved). The correct reading, n=40 throughout:

- **60.0% (24/40)** — the shipped clock agrees with the true advancing-action date, at **week** granularity.
- **85.0% (34/40)** — `latest_action_date` agrees with the true advancing-action date, at **week** granularity.
- **82.5% (33/40)** — `latest_action_date` **equals** the true advancing-action date, at **day** granularity.

The last two are one proxy at two granularities, not a proxy scored against a truth. The ground truth carries no score; it is the yardstick. And 34 ⊇ 33 by construction, since an exact date match is necessarily a same-week match. Disposition (4) shipped on the **85.0% against 60.0%**, both at the granularity the class-(C) readers actually window on.

Write the granularity into the record, not just the numbers. The failure mode is a later reader seeing 85 beside 82.5 and reopening a closed decision.

**2. The stale-value observation was local, not prod.** The `▼3 → ±0` flip was seen against a local `next start` and its `.next/cache`; no stale `▼3` was ever observed on prod, and the first prod read after `bb54c22` already served `±0`. The "won't be visible until `revalidateTag` fires" line was an inference from the local observation plus already-recorded platform behaviour, stated as if it were a prod measurement.

The platform half is **already on the record** (the Vercel Data Cache survives deploys; the first read after a shipped value change serves stale and triggers SWR regen). **Cite it; don't re-file it.** What is new is one clause: a local `next start` reproduces that behaviour against `.next/cache`, so a local render check can show a pre-change value after a correct rebuild. That is verification hygiene, not a platform finding, and it belongs beside the existing entry rather than as a sibling of it.

---

## The rename sweep

32 stale `stage_changed_at` references. Measured: **backlog 9 · roadmap 6 · oddities 6 · SKILL 11.**

Not all are the same job, so don't run one find-and-replace over the lot:

- **SKILL's schema block** (~118 / 131 / 159) documents the column and its index. That is a live contract and must read `stage_observed_at` / `idx_bills_stage_observed_at`. Same for the index-hint line (~1151), the query docs (~1501, ~1517), the stage-decision block (~1629), the `/changes` route line (~1687).
- **Historical roadmap and backlog blocks** are append-only records of what was true then. **Do not retro-edit a closed block's prose to use the new name.** Where a closed entry names the old column, it was correct at the time. If a reader would be misled, the new block carries the correction; the old block stays as written. Apply the same rule to oddities entries that predate 635.
- Use judgement per hit and **say which ones you left alone and why** in the ship report. A sweep that silently rewrites history is worse than one that leaves a stale name in a 2026-07 block.

---

## The WATCH closes partially, and the remainder is a new item

The WATCH at `docs/backlog.md:268` should not simply be renamed. Its subject was that the field records observation time and HO 632's day-grouping reads it. What actually happened:

- The field is renamed, so all 15 consumers now confront what they are reading.
- **One** class-(C) reader moved: `ENACTED` now windows on the enactment date.
- **Eight** class-(C) readers still window on observation time, including `getStageChangesCount` (the `243 ▲15` strip, read at three sites) and `getWeeklyBandPriorWeek`.
- The six class-(B) display-age readers and three class-(A) ordering readers are **deliberately unmoved**. Nothing in the probe says they must move, and observation time is arguably right for ordering a terminal.

So: close the WATCH as **CLOSED HO 635**, and open a new **QUEUED** entry for the remaining eight, carrying what makes it actionable rather than a restatement of the problem:

- Disposition (4) is **proven viable** at 85.0% week-agreement against the shipped clock's 60.0%, corpus-wide, no migration and no backfill.
- Disposition (3) (a new occurrence column) was priced and is **disqualified on population**: a ~29h API backfill reaching 1,758 of 17,520 rows, so the corrected counts would be a partial-population figure with no way to signal that to a reader.
- The measured stakes: `TRANSITIONS` reads 243 on the shipped clock against 163 on occurrence, and the four-week shape **inverts** (112→230→228→243 versus 180→288→114→163). The level is 49% high; the delta diverges threefold. Zero missing cron days across 28, so this is structural to polling cadence, not an outage artifact.

Also close, in the same pass, whatever the probe corrected: `getStaleBills` windows on `latest_action_date` and was never exposed (my handoff misattributed it), and the legacy-NULL cohort is **15,631**, not the "~14k" `StagePillStrip` documents.

---

## Roadmap

One new append-only block covering HO 635. **Take the block/pointer/sweep-numbering convention from the roadmap's own most recent blocks, not from this handoff** — read how 634 and the blocks before it did it and match.

The block's substance, in whatever form the convention takes:

- The defect and its size: a field named for occurrence read as occurrence by 15 consumers, of which 9 window counts on it.
- The disposition and why: rename plus (4) for the counting readers, with (3) disqualified on population.
- What shipped: the ENACTED correction and the rename, and explicitly **what did not** — eight class-(C) readers still on the observation clock, by decision, tracked in backlog.
- The migration shape, since it is reusable: expand → single cutover → idempotent top-up → contract, zero exposure, at the cost of one extra migration run.
- The 60/85/82.5 figures with their granularities.

## Oddities

Four candidates. Judge each on whether it earns an entry; do not pad.

1. **A field named for occurrence gets read as occurrence.** The general form is the entry, not this instance: a timestamp column whose name describes the event rather than the write is read as the event by every consumer that arrives later, and nothing in the type system or the query catches it. 15 consumers here, 9 of them windowing counts.
2. **A verbatim mirror in an instrument passes after the original changes.** `cold-start-audit-332.ts` pins copies of production queries; its `queryEnactedThisWeek` copy still windowed on the old clock after `9e95b21` moved it, so re-running unreconciled would have EXPLAINed a statement that no longer exists in the product and passed it. This is the same-as-success shape **inside the instrument built to catch it**, and it is the third member of that family after the cap-curve flat column and the `!important` no-op. The tell is the reusable part: an instrument that holds a copy needs a check that the copy still matches its original.
3. **Reader-lessness does not license a bare rename.** `stage_transitions.changed_at` has zero production readers, which is what my ruling keyed on. It still needed expand/contract, because both writers name the column in unguarded `db.execute` calls and the column is `NOT NULL` with no default, so the cutover INSERT could not simply stop writing it. Premise held, conclusion didn't: writers bind a schema name as hard as readers do.
4. **The local `.next/cache` clause** — one clause beside the existing Data Cache entry, per the corrections section. Not its own entry.

## SKILL

The schema block and the query/route/index references are mandatory. Beyond those, three clauses worth their space:

- **The migration pattern**, stated so it is reusable: expand (add + backfill + create the correctly-named index) → one cutover commit moving every writer, reader and index hint together → an idempotent top-up **after the deploy is confirmed live** → contract. And the reason the contract is not cleanup: while the old column exists a missed reference is silent, reading a column nobody writes and going stale invisibly. Dropping it is what makes a missed reference fail loudly, so the contract is the falsification leg and its clean run is the proof the cutover was complete.
- **The `ensureColumn` resurrection trap.** A bare rename leaves `migrate.ts`'s `ensureColumn` call for the old name in place, so the next `npm run migrate` recreates it — empty, unread and confusing. The contract step must move in the same change.
- **The index-name lie.** `ALTER TABLE RENAME COLUMN` rewrites an index's SQL body but keeps its name, leaving `idx_bills_stage_changed_at` indexing `stage_observed_at`. Functional and false. Create the correctly-named index in the expand step.

The `PIPESTATUS[1]` self-catch needs nothing new: the clause landed at HO 634 and it fired. Worth one line in the ship report as evidence the rule works, not a second entry.

---

## Guards

1. **Docs only.** No code, no schema, no migration. `git diff -- app/ components/ lib/ scripts/` must be empty at land.
2. Two commits, own ceremony each: docs (backlog + roadmap + oddities) and SKILL.
3. Push to `refs/heads/636-review`. Both the SKILL diff and the append-only roadmap block need reading as real text, not as a summary.
4. **Do not retro-edit closed roadmap or backlog blocks.** New block, append-only; oddities append at the end per the file header.
5. Explicit pathspec staging.

## Ship report

The rename sweep with a count and **which references were deliberately left alone, and why** · the WATCH closure plus the new QUEUED entry for the remaining eight · the roadmap block's pointer and which convention you matched · which oddities candidates earned entries and which were declined · the SKILL clauses landed · pointer greps at land, chosen so they cannot match through a substring of unrelated text (HO 634's `= 15` gate collided with `>= 150`).
