# HO 404 — Full project audit + roadmap/backlog reconciliation

> Renumber if HEAD has moved past 403. HEAD at this writing is `7749de5` (HO 403 doc sweep).
>
> This is the "next full audit" the roadmap STATUS block keeps deferring. It is **read-only + docs-reconcile only** — no schema, no app code. Every code bug it surfaces (masthead UI, wrong incumbent, orphaned CSS) becomes its own follow-on handoff; this pass **finds and specs**, it does not fix.

## Why now

The roadmap STATUS names two un-discharged debts outright — Foundation (96) and Member depth (99) are **off-repo last-known baselines through HO 221, never re-derived**, so both numbers are an un-audited baseline plus a pile of within-theme bumps. Separately, backlog FIT & FINISH carries a **P1 wrong-incumbent** on a live race card and a **masthead bill-count that disagrees with itself across five different numbers**, and a batch of dated OPEN LOOPS have aged past their dates without reconciliation. A full audit closes all of it against live state and leaves the docs honest.

## How to work this handoff

Read-only sweep first, reconcile second, commit last.

1. Read this file. Run the checks in §1–§3, pasting **every number verbatim** — don't summarize away the raw counts.
2. Reconcile the roadmap (§4) and backlog (§5) from those numbers.
3. Show me the reconciled STATUS block + the backlog diffs. **Wait for review.**
4. On approval: docs-only commit, explicit pathspec, ancestry re-checked, separate from any code.

Grounding already done from the repo (don't re-derive): all ~40 sync scripts present in `package.json` incl. `sync:crosswalk`; SKILL.md reconciled through the crosswalk; backlog dated/sectioned; roadmap "Also" notes present through HO 402. The gaps are live-state, below.

---

## §1 — Deploy + corpus ground truth

- `npm run verify:deploy` — confirm served SHA == HEAD (`7749de5`). **If it drifts, stop and report** — a stale deploy is its own health finding, don't audit around it.
- `bills` corpus: total rows; `is_ceremonial = 0` vs `1`; `summary IS NULL` (was **1,011** at Jun 12 — grown, drained, or same?); `stage` distribution via the `computeStage` authority (any NULL/impossible stages; confirm the HO 385 residuals — ~124 uncatchable-from-action-text + the ~75-bill `floor→committee` over-store — are still the only anomalies).
- **Resolve the count incoherence (this closes the QUEUED masthead diagnostic).** The ledger has five bill numbers in flight: 15,120 (HO 311 masthead) · 15,179 (inner, Jun 12) · 15,398 (inner, later) · 16,193 ("BILLS TRACKED", dashboard) · 16,361 (raw total). Grep every surface that renders a bill count (the `DashboardV2Header` masthead "BILLS TRACKED", `/bills` "BILLS", every `HeaderBar` inner-page count) and report the **exact predicate each uses** (`getCorpusStats` / `getFeedStats` / a bare `COUNT(*)`) and its **live value right now**. Deliver: one canonical "tracked" definition, and the list of surfaces that deviate from it (label and/or predicate). The UI unification is a follow-on handoff — this check just produces the honest numbers and the deviation list.

## §2 — Query-plan / cold-start health

- `tsx scripts/diagnostic/cold-start-audit-332.ts` and again with `TIME_WARN=1`. Report **0 unexpected BAD** across the bills/news request-path statements, or list every WARN/BAD (the non-COVERING `USING INDEX` blindspot the probe now prices).
- Cold-time the latency-watch routes on prod (first hit after idle): `/`, `/changes`, `/patterns`, `/members`, `/bills`, `/electoral`, `/reports`. Report actuals. Flag anything past the FIT & FINISH fuse (`/changes` **8.5s** — it was 6.69s) or any cold 500 (the standing "multi-helper fan-out" WATCH).
- Cron health: last ~7 `cron_runs` per cron (`sync` / `summarize` / `news` / `markets` / `meetings` / `kalshi`) — `status` + `elapsed`. Confirm the HO 369 news `INDEXED BY idx_bills_latest_action` fix and the HO 314 markets Vercel daily floor (`30 21 * * *`) are still holding (news ~41–46s success; markets writing daily). Flag any cron erroring or silently dropping ticks.

## §3 — Coverage per theme (feeds the §4 re-derivation)

Enumerate live routes and tables by grep + DB, not from any doc. For each theme, report what has real data vs what's empty/stub — that's the input to an honest %.

- **Foundation** (core pipeline + base UI). Last successful bills-sync tick; summarize backlog (from §1); ceremonial-classification coverage; cluster coverage (`cluster_id` populated %); the forced-`INDEXED BY` set + `bills_fts` intact and populated; the base route set renders. Foundation's number is "is the plumbing complete and healthy," not feature count.
- **Member depth.** Roster (551 total / 537 current); crosswalk (`member_ids` 537/537, `member_fec_ids` 605 — from HO 402); FEC totals + `by_size` split (**463/524** at HO 390 — did the ~61 rate-limited self-heal?); house + senate roll-call vote coverage; committee membership; caucus + palestine-badge coverage; donor-mix; trades. List which member sub-surfaces are live vs empty.
- **Races.** Race roster; per-race ratings coverage; primaries results coverage (CA cert pending — see §5); PAC-IE direction coverage. **Adjudicate HO 398:** read what `5f26ee9` actually shipped for the race→news surface — is it live, and does it close or only partially cover the still-QUEUED "race→news / member→news surface" item? This determines both the §4 bar and the §5 loop.

## §4 — Roadmap reconciliation (the deliverable)

Edit `docs/roadmap.md` STATUS block in place.

- **Re-derive Foundation and Member depth** from §3 against the theme prose in `roadmap.md`. Replace the off-repo 95/90-baseline-plus-bumps with a live-grounded number and annotate provenance: *"re-derived HO 404 against live state; prior was off-repo through HO 221."* If the honest number differs materially from the current 96/99, say so plainly rather than nudging to match.
- **Fold HO 398.** Put the race→news surface where §3's adjudication lands it (a Races bump, or a note under News-CLOSED), and clear the "HO 398 not reflected" OPEN LOOP. The header's "prose reconciled through HO 382–386" line is itself stale (notes exist through 402) — correct it to the real high-water mark.
- Confirm no other shipped-but-uncounted arc (the "Also" notes look complete through 402 — verify, don't assume).
- Recompute **Overall** from the reconciled bars.

## §5 — Backlog reconciliation

Edit `docs/backlog.md` in place; keep the section discipline.

- **OPEN LOOPS staleness sweep.** Reconcile every dated loop now past its date: the CCBT Jun-13 tick check, the **CA certification re-ingest (now due — it's July)**, the FEC `by_size` self-heal, the Playwright smoke CI-wiring loop, the HOUSE-count 436-vs-435 delegate bucketing (relates to §3's roster count). Close, re-date, or confirm-still-open with a fresh note — none should sit silently expired.
- **FIT & FINISH re-verify with fresh measurement.**
  - **P1 · `/races` S-OK-2026 wrong incumbent** — verify live. If the 2026 Oklahoma Senate card still renders Lankford (Class-III/2028) instead of the Class-II seat up in 2026, flag it at the top of the report as an **immediate follow-on fix** — a wrong senator on a live card is a core-credibility bug for this product.
  - **P2 · `/changes` latency** — re-measure against the 8.5s fuse (§2).
  - **P2 · masthead incoherence** — resolved at the data layer by §1; record the canonical count + deviation list, and note the UI fix is a queued follow-on handoff.
  - **P3 · orphaned CSS** (`.hearings-*` HO 366, members-header plumbing HO 367) — confirm still dead, keep banked.
- Confirm the HO 402/403 crosswalk loops read correctly; close any roster loop the resync already discharged.
- **Handoff ledger:** `docs/handoffs/` numeric range + any gaps; confirm HEAD's HO number matches the STATUS marker.

## §6 — Report back

- All §1–§3 numbers verbatim, P1 finding first.
- The reconciled STATUS block and the backlog diffs, for review before commit.
- On approval: `git add docs/roadmap.md docs/backlog.md` (+ `.claude/skills/cbt/SKILL.md` / `docs/oddities.md` only if a convention or field note actually changed — SKILL.md trips its self-mod guard, re-approve rather than route around). Docs-only, explicit pathspec, ancestry re-checked, separate from any code commit.

## Non-goals

- No app-code or schema changes. The masthead UI unification, the P1 incumbent fix, and the orphaned-CSS sweep are **separate follow-on handoffs** — this audit surfaces and specs them, nothing more.
- No new features from QUEUED. This reconciles state; it doesn't build.

## Rollback

Revert the docs-only commit. Nothing else is touched.
