# HO 608 — P3 slice 1: the shell. `/` restructured to the committed mock's two regions.

HEAD `f1db62a`. Roadmap pointer: "Also notes now run through HO 606." 607 is closed on main. **Next free is 608.**

**Read first, in order:** `docs/design/dashboard-layout-target.html` (the committed mock — it is the target, and this handoff cites it by class name), the C1–C8 section in SKILL.md, the arc doc's phase table, and the Dashboard-redesign backlog entry (the HO 590 revision-J decisions). Where this handoff and the mock disagree, **the mock wins**; where the mock and the revision-J backlog entry disagree, the mock wins too — it's the later artifact and it's the one on main.

## 0. P3 is three slices; this HO is slice 1 only

| Slice | HO | Scope |
|---|---|---|
| **1 — shell** | **608 (this)** | Audit-script touch-up · `dashboard-classic` removal · the two-region `.page` grid, masthead C5 cut, nav regroup, PolarizationBand fold |
| 2 — feed interior | 609 | The right column's rows: two-line quiet format, stage-only color, date groups, and the internal-scroll + hover-card question |
| 3 — hearings interior + packing | 610 | HearingsTab → single-day schedule + week ribbon (C4), C1 pack across breaking/wstrip/masthead, C7 start, then the `/` audit re-run and the sweep |

The slice map is provisional past 608. **608 moves regions; it does not redesign the contents of any panel.** Every component relocates as-is unless a line below says otherwise.

## 1. The mapping — current `app/page.tsx` → mock

Current composition (verified at `f1db62a`): `DashboardV2Header` (masthead + tapes + nav + counts) → `ActiveFilterStrip` → `RacesBoxTabs` (HEARINGS|RACES) → `PolarizationBand` → `WeeklyBand` → `.dv2-grid` two columns (left: Breaking panel + DistributionsTabs; right: `ActivityTabs` MOVERS|STALLS|NEW).

Mock structure (`div.page` at ≥1400px: `minmax(0,1fr)` left + `minmax(400px,27%)` right, `align-items:start`):

| Mock region | Gets | Change in this slice |
|---|---|---|
| `.left` header block | masthead, MARKETS tape, ODDS tape, nav | Masthead numbers **5 → 2** (see §3). Nav regroup (see §4). Tapes relocate untouched. |
| *(absence slot)* | nothing | The shell's stack order accommodates a future band between nav and hearings. **No reserved box — C4.** Absence Watch is not built here. |
| `.left` hearings `.panel` | `RacesBoxTabs` as-is | Relocation only. Interior (single-day + ribbon) is slice 3. |
| `.left` `.wstrip` | `WeeklyBand` **+ the polarization chips** | See §5. |
| `.left` `.twoup` | Breaking panel + `DistributionsTabs`, side by side | Currently stacked in `dv2-col-left`; becomes the mock's two-up pair. `align-items:start` — this is one of the three M2 hits on `/`. |
| `.bills` (right, sticky) | `ActivityTabs` (MOVERS \| STALLS \| NEW) | Full column height **from the very top, level with the masthead** — revision-J decision 1, the arc's defining move. |
| *(removed)* | `PolarizationBand` full-width band | Dies. Its numbers move into the week strip (§5). |

`ActiveFilterStrip` isn't in the mock. It's conditional chrome (renders only when filters are active), which is exactly C4-compliant; keep it, at the top of `.left` below the nav.

## 2. Commit 1 — the audit script touch-up (the "next run" items)

`scripts/diagnostic/layout-audit-606.ts`, two changes Code already queued:

- Remove the three redirect aliases from the route list (`/races`, `/primaries`, `/members/pass-rate`, ~lines 95–98). The site totals were already arithmetically corrected in the 607 block; this makes the script agree with them.
- Add a `--route <slug>` filter (env or argv, match the house style) so a single route can be measured, and accept the existing widths behind it. Slice scoring for 608–610 depends on this: `--route home` before and after each slice, ~4 page loads instead of 80.

`diag(layout): HO 608 — drop the three alias routes; add --route for slice scoring`

Run `--route home` at 2560 **on this commit, before any shell work** — that's the slice baseline (expect ≈ the 606 numbers: 31 M1 dedup, M2 3, M4 1,190px).

## 3. Commit 2 — `dashboard-classic` removal (per the corrected M6)

- `git rm app/dashboard-classic/page.tsx`. `FILTER_BASE` dies with the file.
- Remove the smoke-crawl entry (`e2e/smoke.spec.ts:83`).
- Comment sweep, **grep-driven, not the hand list** (the M6 lesson): `git grep -n "dashboard-classic" -- app/ components/ lib/` and clean every hit. Expected set is the five component comments + two `queries.ts` comments + `DashboardV2Header.tsx:76` + `globals.css:6507`, but the grep output is the spec.
- **Leave alone:** the `basePath` props themselves (default `/`, used by the live dashboard) and `app/dashboard-v2/page.tsx` (the 308 — verified alive, bookmarks depend on it).
- Gate: the grep returns zero afterwards; `npm run build` passes; the smoke suite's route count drops by exactly one.

`chore(routes): HO 608 — remove dashboard-classic (unlinked since HO 311; coupling was comments + FILTER_BASE only)`

## 4. Commit 3 — the shell

**Grid.** Adopt the mock's `.page` mechanics into the dashboard's CSS (house-named classes, not the mock's minified ones): single column below 1400px, `minmax(0,1fr) / minmax(400px,27%)` at ≥1400px, `align-items:start`, ~10px gap. The right column: `position:sticky; top:16px; max-height:calc(100vh - 32px)` per the mock's `.bills` block. **Do not add the mock's internal `overflow-y:auto` on the feed in this slice** — the sponsor hover card escapes via the panel's `overflow-visible` (HO 300, the comment is on `home-feed-panel`), and the mock's internal scroll would clip it. Sticky with natural height is the 608 state; scroll-vs-hover-card is resolved in 609 together with the row rework, where both live. Note this in the CSS comment so 609 finds it.

**Masthead (C5).** `DashboardV2Header` currently renders the five-count readout; the mock keeps exactly two numbers: **`16,861 tracked · 97 enacted`** (cyan total, green enacted, per `.mast .counts`), plus LAST SYNC and SIGN IN, all packed left with a `.sp` spacer. The three middle counts (committee / floor / other chamber) leave the masthead; `StageFunnel` in the distributions panel already owns the full split. No query changes — `corpus`/`stageDistFull` keep flowing to the header; the header just renders less of it.

**Nav.** `NAV_ITEMS` (`HeaderBar.tsx:36`) reorders to the mock: **DASHBOARD, WATCHLIST, divider, LEGISLATION, HEARINGS, MEMBERS, ELECTORAL, PATTERNS, LOBBYING, NOMINATIONS, AMENDMENTS, REPORTS** — Watchlist moves from last to second, "mine" styling per the mock's `.nav a.mine`, one `.div` separator after it. `NAV_ITEMS` is shared with every inner page's `HeaderBar`, so this reorder lands site-wide by design; say so in the commit body. Adopt the mock's nav type (`.958em`, tighter padding). Target: one row at ≥1200px; wrapping below that is acceptable and stays measured (the M5 baseline says 1→2 at 1024 today).

**Tapes.** Relocate the MARKETS and ODDS tapes as-is under the masthead per the mock's two `.tape` rows. **They stay horizontal** — revision-J decision 2. If they're currently rendered inside `DashboardV2Header`, they can stay there; the header just becomes the mock's four-row block (mast / tape / tape / nav).

**PolarizationBand.** Delete from `app/page.tsx` (import, the `getPolarizationBand()` call *stays* — §5 consumes it, and `/members` also imports it so the query is shared). The 109-line component becomes dead only if nothing else renders it; check, and if `/members` doesn't use the component itself, `git rm` it in this commit.

`feat(dashboard): HO 608 — the two-region shell per dashboard-layout-target (C5 masthead, nav regroup, sticky feed column)`

## 5. The polarization fold — the one place the mock overrides the backlog

Revision-J decision 6 says CUT the Polarization band. The committed mock refines that: the **band** dies, but the week strip carries **`POLARIZATION 0.92 · HSE 0.92 · SEN 0.92 · IDEOLOGY →`** inline, next to the `JUL 20 REPORT →` link. So `WeeklyBand` gains the three chips + the `/members#ideology` link (or wherever the ideology surface anchors — check `PolarizationOverTime`'s home), fed by the `getPolarizationBand()` result `app/page.tsx` already fetches. This is the mock winning over the backlog's flat cut, and the sweep (in 610) should note the refinement so the backlog entry stops saying "CUT — do not re-add" about numbers that are now deliberately present in miniature.

If the chips make the strip wrap at 1440, drop the two chamber sub-values and keep the single composite + link — the mock's density is the ceiling, not the floor.

## 6. Verification

1. `npm run typecheck`, `npm run build` after each commit.
2. Ancestry eyeball: exactly three commits, in §2/§3/§4 order.
3. **Slice scoring:** `--route home` at 2560 after commit 3, against the §2 baseline. Expected direction, stated so the numbers are interpretable: **M2 3 → 0–1** (the twoup and grid go `start`), **M4 down** (the band's slot returns), **M1 roughly flat** — the feed rows and week strip are untouched until 609/610, and the masthead's M1b may convert from interior-gap to trailing-gap rather than disappear. A big M1 *rise* means the new grid introduced stretch; stop and look.
4. Eyeball `/` at **1440 and 2560**: right column level with the masthead, sticky under scroll, no horizontal overflow, tapes horizontal, nav one row at ≥1200. And **one inner page** (`/bills`) for the nav reorder, since `NAV_ITEMS` is shared.
5. Push (fast-forward, explicit pathspecs), then prod: `/api/version` until the SHA holds, `/` at both widths until it converges — the shell is exactly the kind of change stale SWR HTML can garble for one cycle against new CSS.
6. **HALT.** Paste the before/after `--route home` table and the eyeball notes. No slice-2 work, no sweep — 610 carries the sweep for all of P3.

## 7. Guards

1. Absence Watch: not built, no reserved space, its thread untouched.
2. No feed-row redesign, no HearingsTab interior work, no packing pass — slices 2 and 3.
3. `app/dashboard-v2/page.tsx` untouched.
4. The `--fs` tokens are law (SKILL type rule): any new size in 9–14px is `var(--fs-N)`.
5. Three commits, explicit pathspec, typecheck before every push, no docs mixed in.
