# HO 654 — the TRANSITIONS strip stops claiming to be about Congress

**The number in this filename is not authoritative.** It is derived from an on-disk file, which is the 432/433 collision precedent exactly. §0 establishes the real one.

**Ground truth is not established in this document.** The newest handoff on disk is 653, whose own header read main at `f47b807`, roadmap pointer **646**, commit subjects through **652**. That was true when 653 was written. It may not be now.

**The ruling, Corey's:** decline disposition (4) for the counting strip. Leave the window on `stage_observed_at`, relabel the strip so it states what it counts, and remove the week-over-week delta.

---

## §0 — Ground truth, number, and two halt conditions

Fresh clone. Then, before anything else:

1. `git ls-remote --heads origin` — is main the only ref, or is a `*-review` ref outstanding? If a review ref exists, report it and **HALT**; something is owed that this handoff does not know about.
2. Roadmap's latest pointer, then `git log --oneline` subjects, then next free. **If HO 653's commits are absent, this is 653 and 653 is still owed** — say so and HALT rather than stacking a second unfinished HO on top.
3. `docs/backlog.md` — find the QUEUED entry opened at HO 636 for the class-(C) readers still on the observation clock. **Confirm `getStageChangesCount` is still in it and still undispositioned.** If the entry shows the strip already ruled on in the 638–653 span, the premise of this handoff is dead: report what it says and HALT.

A logged item is a claim. All three of the above are claims until you read them.

---

## §1 — Why decline, in the form that has to survive a later reader

HO 635 measured `TRANSITIONS` at **243** on the shipped observation clock against **163** on occurrence, four-week shape inverting (112→230→228→243 vs 180→288→114→163), zero missing cron days across 28. That is structural to polling cadence, not an outage artifact.

HO 637 then killed the correction. Under disposition (4) the predicate becomes *"the stage has moved at some point, AND the latest action of any kind was recent"* — so a bill referred in May that picks up a cosponsor yesterday enters this week's STAGE TRANSITIONS count without having transitioned this week. **163 was itself computed by windowing on `latest_action_date`, so it carries that membership error.** Disposition (3), a real occurrence column, was disqualified on population: a ~29h backfill reaching 1,758 of 17,520 rows.

So neither number is known true. 243 is a differently-wrong number from 163, not a worse one, and no third anchor exists in the database.

The delta is the part that matters. The level being 49% high is a number nobody audits. `▲15` is the number the strip exists to show, it diverges threefold between clocks, and under the observation clock it partly measures sync behaviour: an outage produces a dip and the catch-up run produces a spike, and both read on the dashboard as activity in Congress. Under an occurrence clock it is biased negative by construction, because 54% of a week's final count arrives after that week closes.

**A delta that cannot be right under either available clock should not be rendered.** That is the whole argument. The count stays because it is a real count of a real thing; the label starts naming that thing; the delta goes.

---

## §2 — Scope fence

This handoff changes **display text and one rendered element**. It does not touch a single window predicate.

Out of scope, explicitly, and do not opportunistically fix any of them:

- **No query edits.** `buildChangesWhere` is untouched, the forced `INDEXED BY idx_bills_stage_observed_at` hint stays, and the comment at `queries.ts:6793` stays true because nothing moves.
- **The stale-tracking guard** (the `:720` reader) does not move and is not in this HO.
- **`gatherReportData`** is out. Its reads sit inside a weekly report about a named week and freeze into immutable artifacts; that is its own decision.
- **The other class-(C) readers** stay queued. One of eight gets a disposition here.
- **No migration, no backfill, no schema change.**

---

## §3 — Enumerate before editing

Read these out of the code. Do not take any of them from this document.

1. **Where the count renders.** HO 635 recorded `getStageChangesCount` read at three sites on `/` — `WeeklyBand`, `page.tsx`, `ActivityTicker`. Confirm the list and confirm it is still three. For each site: does it render the label, the delta, both, or neither?
2. **The ladder coupling.** `getWeeklyBandTransitionLadder` sums to the headline. Verify that in code. If the headline keeps its value (it does — nothing moves), the ladder keeps summing and stays. **But check whether the ladder carries its own header text that independently claims occurrence**, and if so it is in scope for the same relabel.
3. **`getWeeklyBandPriorWeek` — what else calls it.** This is the one to be careful with. It is the prior-week half of a delta and it is on the observation clock. HO 635 moved ENACTED to the occurrence clock. **If this function also supplies ENACTED's prior-week half, then ENACTED's delta currently compares two clocks** — which is a live defect shipped by HO 635, not something this HO created. Report it as a finding with the call sites; **do not fix it here.** It gets its own HO.
4. **What killing the delta orphans.** If `getWeeklyBandPriorWeek` has no remaining caller after the removal, say so and leave it in place with a comment naming this HO. Do not delete a query in a display commit.

Report §3 before making any edit.

---

## §4 — The edit

**Label.** The strip currently reads `STAGE TRANSITIONS`. It becomes a label that says the count is of observations, not congressional events. Proposal: **`TRANSITIONS OBSERVED`**. Constraint that overrides the wording: the layout conventions arc (C1–C8, HO 604–627) governs this band. If `TRANSITIONS OBSERVED` does not fit the established type scale and column width without reflowing the band or wrapping, **do not force it** — report the character budget you actually have and propose wording that fits. A relabel that breaks the grid is a worse outcome than a shorter word.

**Tooltip.** Attach the fuller statement using the existing tooltip primitive (HO 147), matching how neighbouring strip elements do it rather than inventing an attachment. Copy, and this text is the deliverable so keep it exact:

> Counts stage advances the sync observed in this window, not advances Congress made in it. Median observation lag 3.8 days, p90 16.0 days.

If no neighbouring element in this band carries a tooltip, say so and stop before adding the first one — that is a convention decision, not a mechanical edit.

**Delta.** Remove `▲15`. Remove the rendered element, not just its value. Then check what the band's grid does with the freed space: if the layout assumes a fixed element count or reserves the delta's width, report the residue rather than papering over it with a spacer. The layout arc's permanent-residue register is the right home for a bounded gap if one is unavoidable.

---

## §5 — Verification

State, in the ship report, **what each check reads if the work never happened.** A check that returns the same thing either way is not a check.

- `npm run typecheck` clean.
- The three read sites from §3, in the browser: the new label string present, the delta element absent from the DOM (not merely invisible), the headline value unchanged from its pre-edit reading. **Record the pre-edit value before you touch anything**, because "unchanged" is the assertion and it needs a prior number to be an assertion at all.
- The ladder still sums to the headline. Same numbers as before the edit, since no predicate moved.
- Tooltip fires on hover and its text matches the copy above byte-for-byte.
- Playwright: run the existing `fit-finish.spec.ts` and `smoke.spec.ts`. If either pins the old label string, that is a real failure and the fixture updates in the same commit.

---

## §6 — Commits and refs

**The code commit goes direct to main. Not on a review ref.** Reason, and it is the recorded one: a review-ref push builds that SHA as a Vercel preview first, and the later main fast-forward onto the same SHA can dedup and leave prod on the predecessor. That is harmless on docs and a verification blocker on UI. This is UI.

| # | Kind | Path | Ref |
|---|------|------|-----|
| 1 | `fix` | the strip component(s) from §3 | direct to main |
| 2 | `docs` | `docs/roadmap.md`, `docs/backlog.md` | review ref |
| 3 | `docs` | `SKILL.md` | review ref, self-mod guard |

Code first, so prod verification runs before any dedup risk exists. Explicit pathspec staging only. Ancestry eyeball before each push. Docs and code never ride together.

On the docs commits, verify append-only with `git diff --numstat` (or `--stat`'s deletion column). **Not `grep -c '^-[^-]'`** — a deleted markdown bullet diffs to `-- **text**` and the character class excludes it; both Claude and Code reported a zero from that pattern at HO 639 and both were wrong. **Not normal-format `diff` against `git show HEAD:file`** — `core.autocrlf` is true with no `.gitattributes`, so an LF blob against a CRLF working tree reports every line changed.

---

## §7 — Docs contents

**Roadmap** — one new append-only block. Take block shape and pointer convention from the roadmap's own most recent blocks, not from here. Substance: disposition (4c) taken for `getStageChangesCount`; the strip relabelled and the delta cut; the reason stated as *neither clock yields a correct delta and no third anchor exists*, not as *observation is fine*. Name the seven readers still queued. Do not retro-edit any prior block, including the one that states 243-against-163 as "49% high" — if that framing now needs qualifying, the qualification lives in this new block.

**Backlog** — the QUEUED entry drops from eight readers to seven, with the strip's disposition recorded and dated. Add the §3.3 finding (ENACTED's possible cross-clock delta) as its own entry if the enumeration turns it up. Add the owed clause naming `--numstat` as the append-only diff instrument if it has not ridden yet.

**SKILL** — wherever the strip and `getStageChangesCount` are documented, the entry states the count is of observations and that the delta was deliberately removed, with this HO's number. A later reader who finds a count with no delta and no explanation will helpfully add one back.

---

## Guards

1. §0 halts before §1. All three conditions.
2. §3 is reported before §4 begins.
3. No predicate, index hint, or schema touched. If the edit seems to require one, stop and report.
4. The ENACTED cross-clock question is reported, never fixed here.
5. Nothing commits until the §3 report is acknowledged.
