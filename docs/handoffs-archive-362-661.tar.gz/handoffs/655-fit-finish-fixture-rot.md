# HO 655 — the fit-finish fixture asserts a behaviour that was deliberately reversed

**The number in this filename is derived from a read, not from disk, but re-derive it anyway.** At `e23fe3f` the roadmap pointer ran through **654** and HO-numbered commit subjects ran through **654**, so **655**. Confirm both before writing.

**Takes up the entry opened at HO 654:** `fit-finish.spec.ts:143` pins `a.bill-id-chip`, absent from the `/` render. That entry's stated close is *"the assertion targets what the row actually renders."* **That close is wrong and following it produces a test that still fails.** §2 is why.

---

## §0 — Ground truth and halts

Fresh clone. `git ls-remote --heads origin` — main only, or report and HALT. Roadmap pointer, then subjects, then next free.

Then one premise check, because this handoff corrects a claim that was in circulation for two HOs:

- **Confirm no workflow runs `fit-finish.spec.ts`.** `.github/workflows/e2e-prod.yml`'s run step should read `npx playwright test e2e/smoke.spec.ts --grep-invert "@nonci" --retries=2`, and `ci.yml` should invoke no Playwright at all. If either now globs `e2e/`, this handoff's §1 is stale and the disposition changes — report and HALT.

---

## §1 — Correcting the record first, because two documents now carry the wrong shape

The HO 654 entry says a committed test that cannot pass *"trains the next reader to skim past a red `fit-finish`."* The reasoning is right and the setting is wrong: **there is no red run to skim past.** Nothing in CI executes this spec, by an explicit and documented decision (SKILL ~2352 — manual/local, interaction-heavy, BotID-exposed; the Phase-2 fixture was probed at HO 503 and **declined, not deferred**).

The mechanism survives the relocation, which is why the entry is still worth acting on. It just moves: `npm run test:e2e` is `playwright test` with no path, so the **default glob picks up both specs**. Anyone running the documented manual command today gets a failure in `fit-finish` that has nothing to do with whatever they were checking. The rot is real; the audience is a person at a terminal, not a workflow.

**Correct the entry's framing when it closes.** Do not leave "a red gate nobody reads" in the record — no gate ran.

---

## §2 — The proposed close produces a still-failing test, and this is the whole reason for a handoff

Read `components/V2FeedList.tsx` around the `v2f-id` anchor and its comment before touching the spec. What it says:

```
{/* Plain amber id, not the bordered chip (C3). Still a real link
    (href kept for new-tab / copy-link / a11y), but a PLAIN click
    now expands the row like every other pixel in it — see rowLinkClick. */}
```

So `.v2f-id` **is** an `<a>` with `href={/bill/${bill.id}}`. Repointing `a.bill-id-chip` → `a.v2f-id` therefore satisfies line 143 and **fails four lines later instead**, because the spec asserts the opposite of current behaviour:

```
// id-click navigates (stopPropagation means the row does NOT expand)
await idChip.click();
await page.waitForURL(/\/bill\//, ...)
expect(page.url(), ...).toContain("/bill/");
```

A plain click expands the row. It does not navigate. **The test encodes a behaviour HO 609/613 deliberately reversed**, and its title — *"feed id chip navigates to /bill/[id]; body click expands"* — states the old contract in the place a reader forms the belief.

This is the failure mode the entry names, one layer down: the naive repair moves the failure from line 143 to line 150, where it reads as a *regression* rather than as fixture rot, and the next person spends the debugging budget on the app instead of the test. **Verify the click behaviour against the running app before writing the new assertion — do not take it from this handoff or from the source comment alone.**

Note also that `a.bill-id-chip` is not a dead selector globally: `components/BillIdChip.tsx` and `app/globals.css:4389` are live, the primitive is simply no longer used in the v2 feed row. HO 654's "0 occurrences" was scoped to `/` and is correct there. Do not delete the primitive.

---

## §3 — What the test should assert

The current contract is richer than the old one and pinning it is worth more than pinning the old one was. Three claims, and the third is the one that has no coverage today:

1. The row's id is a real link — present, visible, `href` matching `^/bill/`. That preserves the new-tab / copy-link / a11y guarantee the comment claims.
2. A **plain click expands the row** rather than navigating: URL unchanged, `.v2f-group.open` count 1.
3. A **modifier or middle click still navigates** (or opens a new tab), if `rowLinkClick` distinguishes them. **Read `rowLinkClick` and assert only what it actually implements** — if it swallows every click regardless of modifier, say so and assert that instead. Do not write an aspirational assertion.

Rename the test to state the current contract. A test whose title describes the old behaviour is the same defect as the assertion, and it is the part a skimmer reads.

---

## §4 — Bounded census, because one drifted fixture found by accident is not a measurement

This rot surfaced sideways during an unrelated HO. Treating it as the only instance is the reasoning-over-reports move. **Enumerate, do not audit:** two spec files, every DOM selector each asserts, checked against the tree.

For each selector in `e2e/fit-finish.spec.ts` and `e2e/smoke.spec.ts`: does a `className`/`class` producing it exist under `components/` or `app/`? Report per selector, with the spec line. Bound it there — this is a static check plus a live render, not a rewrite of the suite.

Two things to look for specifically, both of which pass while measuring nothing:

- **Selectors that exist but whose surrounding assertion encodes an old behaviour**, which is the §2 class. A static existence check cannot see these; flag any selector whose assertion asserts *navigation*, *stopPropagation*, or a count of `0`, and hand-read those.
- **`toHaveCount(0)` assertions in `smoke.spec.ts`.** That spec runs daily and is green, so nothing there is failing — but an assertion that something is absent passes trivially if the thing it names was renamed. State, per such assertion, what it reads if the feature it guards were entirely removed. If that is the same as success, it is not an instrument. (This is the inert-control family: HO 651's ±120-char window, the cap-curve flat column, the `!important` no-op.)

If the census comes back clean apart from `:143`, that is a real result and worth recording as one.

---

## §5 — The rot question, and it is the one owner call here

A manual instrument rots between uses with no signal. Adding fit-finish to `e2e-prod.yml` is **closed** — declined at HO 503 on the guard-inversion / false-green mechanism, and it is BotID-exposed against prod headless, so this is not a decision to reopen casually.

Report the options with costs and **HALT for the ruling**; do not pick one:

- **(a) Accept manual rot.** Cost: this recurs, discovered by accident again. Zero work.
- **(b) A static selector check** in `npm run typecheck`'s neighbourhood — extract the selectors the specs assert, fail if one has no producer in the tree. Cheap, and it is the HO 651 phantom-probe shape reused. **It would not have caught this one**, since `.v2f-id` exists; say that plainly rather than selling it.
- **(c) Run fit-finish locally on a cadence tied to something that already happens** (a doc-sweep HO, an arc close). Cost: a convention nobody enforces, which is how it rotted.

**(b)'s limitation is the interesting part and belongs in the report either way:** the class that bit here is *selector exists, behaviour moved*, and no static check reaches it. Only running the test does. That argues the honest disposition may be (a) plus a note, and a probe that says so is not a failed probe.

---

## §6 — Verification

The test must **fail before and pass after**, and both halves need demonstrating:

- Run the spec on current HEAD, unmodified. Record the failing line and message. That is the control; without it "it passes now" is not an assertion.
- After the rewrite, run it again. Green.
- **Then perturb** — on a scratch edit, make the plain click navigate (or strip `rowLinkClick`) and confirm the new test goes red. A test for behaviour that never fires against a violation is the same-as-success shape, and this HO exists because one shipped. **Scratch perturbation on current HEAD, never a checkout of pre-fix files.** Revert before committing.
- `npm run typecheck` clean (the spec is TypeScript and `ci.yml` covers `e2e/`).
- `npm run test:e2e` with no path, the documented manual invocation, so the glob picks up both specs and the run is what the next person will actually see.

---

## §7 — Commits

| # | Kind | Contents | Ref |
|---|------|----------|-----|
| 1 | `test` | `e2e/fit-finish.spec.ts` — the rewritten test and its title | direct to main |
| 2 | `docs` | backlog: the HO 654 entry closes with its framing corrected; the census result; the §5 ruling | review ref |

Docs and code never ride together. Explicit pathspec staging. Ancestry eyeball. Append-only checks with `--numstat`, not `grep -c '^-[^-]'`, and not normal-format diff against `git show`.

**Backlog close text must carry the correction, not just the fix:** the entry currently says a red CI run trains a reader to skim. Nothing ran. Say what was actually true, that the reviewer's claim about CI coverage came from memory rather than the workflow file, and that the mechanism relocated to `npm run test:e2e` rather than evaporating.

**SKILL:** only if §5 lands (b) or (c). If the ruling is (a), SKILL's existing line at ~2352 is already correct and needs nothing — do not edit it to record a decision to change nothing.

---

## Guards

1. §0 halts before §1.
2. §2's click behaviour is verified against the running app, not inherited from this handoff.
3. The `bill-id-chip` primitive is not deleted.
4. §4 is an enumeration over two files, not a suite rewrite. If it starts to sprawl, stop and report the bound.
5. §5 halts for the ruling. Do not implement (b) or (c) unprompted.
6. The perturbation in §6 runs on scratch and is reverted before any commit.
