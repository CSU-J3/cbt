# HO 610 — P3 slice 3: hearings interior, the packing pass, cleanup, the full re-run, and P3's sweep.

HEAD `f031673`. Roadmap pointer still "run through HO 606" (608–609 sweeps deferred here by design). **Next free is 610.** This closes P3.

Read first: the hearings panel and breaking/wstrip regions of the mock, the C1–C8 SKILL section, and the two HALT reports from 608/609 (the worklist below is built from their findings).

Order: four code commits → full audit re-run (no commit) → sweep on a review ref. HALT twice — once after the re-run with the numbers, once on the ref for the diff read.

---

## 1. Commit 1 — the hearings interior (C4)

Replace `HearingsTab`'s five-column week grid with the mock's three-part interior. This kills all three standing M2 hits (`#hcal-day-*`, 173–200px slack each) and the two 358px "No meetings" M4 blocks — the residue both prior slices correctly refused to touch.

The mock anatomy, verbatim:

- **`.hbar`** — one flex row, wrap allowed: `TODAY · WED JUL 29 · 5 SCHEDULED` (the `.hday` label; when today has nothing, the bar shows the next day with meetings — `NEXT · MON AUG 10 · 3 SCHEDULED` — never an empty day).
- **`.rib`** — the week ribbon: five compact `MON/TUE/…` cells, `—` for empty days, bold count for scheduled ones, `on` marks the shown day, then `10 THIS WEEK ▼43` as the trailing total. This is the entire footprint empty days get: one dash in a ribbon, not a 358px column.
- **`.sched-wrap`** — the shown day's schedule only: `.srow` flex rows (`stime` 3.6em fixed / `skind` dim / `stitle` ellipsized), `.past` rows at 0.42 opacity, one column, two at ≥1700px with a soft divider.

Recess behavior is the C4 point: a week with nothing renders the hbar (`NEXT · …` pointing into next week if needed), a ribbon of dashes, and one dim line — no grid, no reserved box. Data needs are already met by whatever feeds the current grid (days + counts + per-hearing time/kind/title); if the current query lacks next-day-with-meetings lookahead, extend the existing accessor rather than adding a new query, and say so.

The RACES tab and `RacesBoxTabs` shell are untouched.

`feat(hearings): HO 610 — day schedule + week ribbon replaces the week grid (C4; M2 3→0 on /)`

## 2. Commit 2 — the packing pass (C1) + the race grid

Targets, from the audit's worst-10 on `/` at `f031673`:

- **Breaking rows** to the mock's `.brk-row`: `bid` amber · `bhead` bright, ellipsized · `bago` dim — packed left, trailing gap collects right. Whatever currently pins the timestamp goes.
- **Masthead: pack fully left, deviating from the mock.** The mock's own masthead uses a `.sp{flex:1}` spacer to pin LAST SYNC + SIGN IN right — which is precisely the C1 pattern, and the instrument (ink-measured) will always read it as a large interior gap. SKILL owns the conventions and wins ties, so: counts, `LAST SYNC …`, `SIGN IN` follow the title cluster with `·` separators, spacer deleted. The sweep records the deviation.
- **Week strip**: already content-then-links; verify packed-left flex with the two `→` links as the final items (a trailing gap after the last link is the target state), and fix any interior offender the worst-10 names.
- **`.race-grid`** (the pre-existing 1200–1399 overflow, verified at `1d9c339`): the `repeat(4, 1fr)` tracks can't hold ~342px-min cards below 1400. `repeat(auto-fit, minmax(342px, 1fr))` or an added breakpoint — whichever matches the file's existing pattern. Acceptance: document `scrollWidth` ≤ viewport at 1200/1300/1440/2560 with the RACES tab open.

Goal for the slice: `/` interior-gap count over 120px → **0** (M1a + M1b both), masthead included. If any row can't reach 0 without redesigning a panel's content, name it in the HALT rather than forcing it.

`fix(dashboard): HO 610 — C1 packing pass (breaking, masthead, wstrip) + race-grid track floor`

## 3. Commit 3 — the expand panel's narrow-column collapse

The 609 finding: `BillExpandPanel` at 2–3 words per line inside the 400px column at 1440. The call: **the panel adapts; the column floor stays.** Raising the floor steals from a left column already at 982px, and a shared component that can't survive a narrow container is the component's defect (C8's inverse — narrow containers get stacked layouts).

Container query on the panel's own width: at ≤ ~440px, its internal grid collapses to a single stacked column (label-over-value), full-width rows. `/bills` renders it wide and never crosses the threshold — prove it: `--route bills` flat, plus an eyeball of one expanded row there. Acceptance on `/`: an expanded row at 1440 reads in full-width lines, no 2–3-word wrapping.

`fix(bill-panel): HO 610 — container-query collapse for narrow columns (the 400px feed column)`

## 4. Commit 4 — cleanup (the parked orphans and the stale claim)

- `git rm components/HomeHeader.tsx` (unreferenced since the classic removal — re-verify with grep first).
- Delete the orphaned `.pol-band-*` block from `globals.css`.
- **The HO 300 comment on `home-feed-panel` is now a stale claim on main**: it justifies `overflow-visible` with a sponsor hover card (`SponsorHoverName`) that 609 established has never rendered in this column, and the one overlay that does exist is now viewport-fixed. Correct the comment; if nothing else needs `overflow-visible` there, remove the property too, and re-run the 609 §2 reproduction once to prove the popover still escapes.
- `daysSinceColor` (`BillRow.tsx:17–26`) is **not touched** — it's the `/bills` + `/stale` variant. The sweep files the oddity.

`chore(dashboard): HO 610 — remove HomeHeader + pol-band CSS; correct the stale HO 300 overflow claim`

## 5. The full re-run — P3's exit number (no commit)

`layout-audit-610`-style full pass: all 26 routes at 2560, the 6-route subset at 1024/900/720, same seeds. ~70 loads; print the ledger. Then, against the HO 606 baseline (aliases already excluded from both sides):

- The **per-route delta table** — 606 vs. now — for M1/M2/M3/M4, `/` first.
- `/` targets: M1 over-threshold **0**, M2 **0**, M4 ≤ ~200px (the HEARINGS tab label region may legitimately hold a little).
- **Expected non-zero context, stated so nobody chases it**: `/bills`, `/members`, `/lobbying` et al. are untouched by design — their numbers should match 606 within live-data noise, and *that flatness is itself the control* proving the audit measures the work and not the weather.
- The fresh table re-ranks P4: confirm or revise lobbying-then-members with current numbers.

**First HALT here**: paste the delta table before writing a word of the sweep, since the sweep's claims cite it.

## 6. The sweep — one review ref, docs commit + SKILL commit

`refs/heads/610-review`, same flow as 605/607.

**Roadmap block** covering **608–610**, pointer → 610. It should carry: the three-slice shape and per-slice scores (608: 43/M2-3 baseline → shell; 609: M1 43→32, the v2f interior-0/trailing-274–420 result, the popover fix with its reproduce-first leg; 610: the exit numbers from §5); the two §6-expectation misses in 608 and their exact diagnoses (the 8×54=432 nav arithmetic); the premise corrections (V2FeedList not `BillRowList compact` since HO 311; HO 300's card was `SponsorHoverName` and never rendered in the column); and the mock-deviation on the masthead spacer with its rationale (SKILL wins ties).

**Backlog**: dashboard-redesign entry → SHIPPED across 608–610 with the three supersessions recorded as refinements, not violations (polarization band → chips in the strip; date groups → per-row relative age; masthead spacer → packed left per C1). The nav one-row-at-≥1200 target **retracted** with its reusable shape: *a fixed-width target set before the element moved into a narrower container measures the old container.* The audit entry gains the 610 exit table pointer and the re-ranked P4 order. `BillExpandPanel` narrow-collapse noted as shipped.

**Oddities** (append at end): (1) **the party-color token as age heat** — `daysSinceColor` paints staleness with `--party-republican`; in this UI a red number reads Republican before it reads old; live on `/bills`/`/stale`, filed not fixed. (2) **PowerShell text gates over non-ASCII can false-negative** — `Get-Content` through the console codepage split the en-dash in `M1–M6` and the gate read False on a correct file; decode raw bytes as UTF-8 before believing a failure (HO 607 close). (3) **M3 samples M1a groups only** — a sole-child row (`.v2f-row` in `.v2f-group`) never enters the sample, so the site M3 can sit still while the actual rows improve 9.4→4.4; per-selector probes are the slice tool, site M3 the cross-route one.

**SKILL** (own commit): one durable rule in the design-system section — **party color tokens carry party, nothing else**; age, heat, and severity get their own tokens or stay dim. Two sentences, no more.

**Second HALT on the ref** with the block and both diffs pasted.

## 7. Guards

1. Absence Watch untouched, in every commit.
2. `/bills` proven flat after commits 2–4 (`--route bills`), except where §3's eyeball is the instrument.
3. `--fs` tokens for any size in 9–14px; mock `em` values map to the nearest token.
4. Commits in §1–§4 order, explicit pathspecs, typecheck each, code and docs never mixed, sweep only after the §5 numbers exist.
5. The C1 target is 0 on `/`; anywhere it would take a content redesign to reach, report instead of force.
