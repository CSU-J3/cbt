# HO 371 — /stale momentum overlay (build)

If `371` is taken (`ls docs/handoffs/ | sort -V | tail`), self-claim the next free number and rename.

Build the momentum overlay on `/stale`: a cosponsor support figure and a HEARD badge on the collapsed row, a support bar and a "then silent" line in the expand panel. Annotates the stage-led sort (HO 350), does not re-order it. v1 adds no new sort; SUPPORT sub-sort within stage groups is a later handoff.

**Visual source of truth:** `docs/design/stale-momentum-row.html` (approved). Build to match its layout and structure. Two exceptions below where the mock's eyeballed numbers are overridden by the live distribution — those overrides win.

**Type:** follow live. The row uses sans titles/summary, mono chrome. Do NOT impose all-mono.

## Resolved premises (verified live in scoping — do not re-derive)

1. **Cosponsor count is render-only.** `bills.cosponsor_count` (stored column, not raw_json) is already in `getStaleBills`' SELECT via `SPONSOR_ENRICH_SELECT` (`lib/queries.ts` ~3214 / select line ~56), and already rendered as a Cosponsors row in `BillExpandPanel.tsx:439-447`. Do **not** add a query column and do **not** add a new expand field. Cosponsor work is only: the collapsed figure, the 5-segment bar on the existing expand row, and moving that row to sit directly after SPONSOR if it isn't already. 515/615 of the stale set non-null (83.7%); 100 are NULL.

2. **HEARD needs one column, no index.** Add a correlated `EXISTS (SELECT 1 FROM meeting_bills mb WHERE mb.bill_id = bills.id) AS heard` to the `getStaleBills` SELECT. `idx_meeting_bills_bill` already serves it as a covering point lookup; measured 60ms → 208ms at LIMIT 50, well under the 10s `boundedFetch` abort. **No INDEXED BY.** Then a new optional `FeedBill.heard` field plus one mapping line in `rowToFeedBill`. 142/615 (23%) carry a hearing.

3. **Blast radius is the constraint.** `BillRow` is shared across `/bills`, `/stale`, `/changes`, `/president`, `/watchlist`, `/members`, `/committee`, `/search`, `/patterns`. The cosponsor figure's data (`cosponsor_count`) is present on every one of those via the enrich select, so the collapsed figure **must be explicitly gated to /stale** or it leaks everywhere. `BillExpandPanel` is likewise shared (`/bills`, `/changes`, `/president`, `/watchlist`, dashboard), so its momentum additions gate via a flag threaded down from `BillRow`. The `heard` field only exists on the stale feed, so the badge self-gates, but gate it on the same flag anyway for coherence.

4. **Bands and bar are retuned; the mock's numbers and some of its row colors do not survive.** The mock's 80/30/1 thresholds and `/30` bar math were eyeballed (your Q2). The live distribution (§ below) overrides them. The mock governs layout and structure only; where its example-row colors disagree with the tuned bands, the tuned bands win (e.g. the mock's `+41` is `mid` but tunes to `high`).

## Build

### 1. Data (`getStaleBills` + feed type)
Add the `heard` EXISTS column to the `getStaleBills` SELECT (premise 2). Add optional `heard?: boolean` to the `FeedBill` type. Map it in `rowToFeedBill`. No cosponsor query change. (The new column also rides the dashboard TOP STALLS call to `getStaleBills({}, 5)` — harmless, those components don't read `heard`; the ~150ms is negligible at 5 rows.)

### 2. The gate
Gate the entire overlay (collapsed figure + HEARD, expand bar + silent line) behind a condition true **only on /stale**. If `daysSinceMode === "staleness"` (the flag already producing the "Nd stuck" age) is /stale-exclusive, reuse it. If it's set on any other surface, add a dedicated `showMomentum` prop set true only by the /stale page's row list. Thread the same flag into `BillExpandPanel` so its additions gate too. **Ship-gate:** confirm the overlay renders on /stale and on no other `BillRow` surface before calling this done.

### 3. Collapsed row (`BillRow`, gated)
Line-1 right cluster (`.metrics`), order `[support figure] [HEARD slot] [age] [caret]`:
- **Support figure:** `+N` (the `+` reads as cosponsors and hosts a future delta with no redesign). Banded by the tuned thresholds below. NULL renders `—` in `text-dim`; do not drop those rows.
- **HEARD slot:** fixed 52px, flex-end, always reserved so rows with and without the badge stay column-aligned. The badge (bordered pill, `border-strong` / `text-muted`, 10px, word "HEARD") shows only when `heard`. No date here; the date is in the expand.
- Line 2 (sponsor + topic chips) untouched.

### 4. Expand panel (`BillExpandPanel`, gated)
- **COSPONSORS row:** the existing row at 439-447 — ensure it sits directly after SPONSOR (mock order). Add a 5-segment support bar beside the count: segments-on = `min(5, ceil(count / 10))`, on-segments `accent-amber-bright`, off-segments `border-strong`; count stays `accent-amber-bright` 600.
- **HEARING slot (HO 324):** when populated, append a line `NO ACTION IN Nd` in `accent-amber-bright` (Nd = days since `latest_action_date`). That amber line is the "then silent" payload. No-hearing bills keep the existing empty state. (HO 324 already fetches/renders the committee · type · held · date · time · room meta; only the silent line is new.)

## Tuned values (from the live stale-set distribution: n=515 non-null, p25=1, median=3, p75=12, p90=32, p95=49, max=327)

- **Figure bands:** high `≥30` (`accent-amber-bright`, 600) · mid `10–29` (`text-secondary`) · low `1–9` (`text-dim`) · null `—` (`text-dim`). high lands ≈ top 11%, so it's neither everyone nor no one.
- **Bar:** ceiling 50, segment width 10 (so 5 segments span 1–50; the >50 tail caps at full). This replaces the mock's `/30`/150, which left the bar at 1 segment for the median bill.

## Out of scope
- Cosponsor delta + sparkline — gated on a future append-only `cosponsor_history` table (no backfill). The `+N` form leaves room for it; don't build it.
- The two dashboard widgets (`V2FeedList` stalls mode, `TopStallsList`) do **not** get the overlay this pass. /stale `BillRow` only. `/bill/[id]` is a separate page, unaffected.

## Ship
`tsc` clean. Commit with an explicit pathspec naming exactly the files touched (the `getStaleBills`/queries file, the `FeedBill` type file, the `rowToFeedBill` file, `BillRow`, `BillExpandPanel` — only what's edited). Never `git add -A`. Ancestry recheck before push; Corey runs the push and `npm run verify:deploy`. This is a styled UI change: after the SHA matches, confirm the /stale stylesheet loads (no 404 on the layout CSS asset) and the overlay renders styled, and confirm zero leak on two other `BillRow` surfaces.
