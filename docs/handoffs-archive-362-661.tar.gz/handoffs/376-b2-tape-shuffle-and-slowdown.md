# HO 376 — B2 tape: shuffle order + slow scroll

**Interpretation (redirect before running if wrong).** "Vary the seeds" read as: randomize each strip's item order on mount so the loop doesn't always start from the same SPX run, and the two stacked strips don't scroll in lockstep. Shuffle once per mount, stable after. If you meant varying the seamless-loop duplicate copies, or rotating which symbols appear at all, that's a different build — stop and confirm.

Render-order only. No data path, hover, sparkline, or close-date logic touched — consistent with how HO 374 renders per-item props.

## Shuffle

- Fisher-Yates shuffle each strip's source array once on mount. The two strips (markets top, odds/macro bottom — whatever the current split is) get **independent** shuffles so they look uncorrelated.
- Keep the loop seamless: the marquee duplicates the array as `[items, items]` animating to -50%. Shuffle the base array, then duplicate the *same* shuffled order so the wrap stays seamless.
- **Hydration trap.** This is a client component; shuffling during SSR / first render with `Math.random()` mismatches server vs client. Shuffle post-mount (`useEffect` → `setState`, or a mounted guard): render the stable source order on first paint, then the shuffled order after mount. No hydration warning.

## Slow down

- Find the current scroll duration / rate and slow it ~1.75x as a starting point — a single tunable value. We'll dial the exact feel after it's live.

## Verify

- Item order differs across reloads; the two strips aren't mirrored.
- Loop still seamless (no jump or gap at the wrap).
- Scroll visibly slower.
- Hover, sparkline, and close-date all still work (375 / 374 unaffected).
- No console hydration warning.

## Ship

Named `git add`, push, `verify:deploy` SHA === HEAD, stylesheet loads. Vercel BotID blocks headless prod hover, so verify via served-SHA + stylesheet-class + `/api/markets/latest` payload + local CDP on the matching SHA, then eyeball the live scroll speed and a reload-to-reshuffle manually.
