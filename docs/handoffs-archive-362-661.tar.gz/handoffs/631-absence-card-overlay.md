# HO 631 — the absence card: compact interior, overlay over the page, and the slice that closes the QUEUED line

Main is `24cb7cd`. This is **631**. Owner ruling off `mock-631-absence-card-overlay.html` (live variant knob + working overlay): **COMPACT yes, overlay yes, click-outside-closes yes.** The mock lands in `docs/design/` before you start — the owner is dropping it now; if it isn't there, say so and halt rather than re-running the 629 chase. The mock's Wilson dataset is illustrative; build renders real data.

## Commit 1 — the compact variant, opt-in on the shared card

`SponsorExpandedPanel` grows `density?: "full" | "compact"` defaulting to `"full"` — `/members` passes nothing and must render **byte-identical** (render-diff it, don't assert it; the HO 507 rule is satisfied by explicit opt-in, not by hoping overrides don't leak). The half-built mechanism helps: `committeeCap` is already a prop (line 73); bills need the same lift since `RECENT_BILLS_CAP` (line 25) is a module const.

Compact, per the ruled mock:
- Photo 56px, inline with the name/party block instead of stacked above it; rail gap and padding tightened (mock: `12px 16px` panel padding, rail gap 7).
- Bills cap **10**, committees cap **10**, committees rendered two-column (`column-count: 2`, `break-inside: avoid`), collapsing to one column under the 630 container threshold — the threshold itself doesn't move (container width unchanged by this HO).
- Both columns close with the house `[ + N MORE → ]` drilling to the member page.
- **The count-source fix, and it lands here, not in commit 3:** line 308 gates the bills see-all on `recentBills.length > RECENT_BILLS_CAP`. Move the gate and the N to the stats total (verify which field carries it) for bills; committees can use the pre-cap array length since they are never sliced upstream. Without this, commit 3's slice silently kills the `[+ N MORE →]` exactly when it applies.

## Commit 2 — the overlay

The band stops reshaping the page:

- Anchor on the **band container** (`position: relative`), not the row — both rows and the footnote stay visible while open. The pop: `position: absolute; top: 100%; left: 0; right: 0`, small top margin, amber 1px frame on `--bg-row-hover` (the open-group idiom), shadow, `max-height: min(72vh, 760px)` with internal scroll — the stacked 1440 form is tall and scrolls inside itself now, which is new behavior; the HALT screenshot shows it.
- **Stacking, reasoned then verified:** the pop overlaps only left-region siblings (hearings band, week strip, two-up), all `z-index: auto` — a modest z-index on the pop wins. It never overlaps the sticky bills rail by geometry (`right: 0` of the band, which ends at the column gap). State this reasoning in the commit and verify visually at both widths anyway.
- Close semantics, all rulings: Esc closes and **focus returns to the row** (new a11y leg); click outside the band closes, and the outside click's own target proceeds normally — one click, not two, no `preventDefault` on the way out (clicking a feed bill row while the card is open closes the card AND expands that bill); row re-click toggles; clicking the other row switches, single-open persists. `aria-expanded` carries over from 630.
- **The zero-reflow instrument, with its falsification:** rect-top of the first element after the band, closed vs open — delta must read **0**. If this HO never happened it reads ~the card's height (~500px), so the instrument discriminates. Falsify on scratch: strip the absolute positioning on current HEAD, confirm the delta goes nonzero, restore, `git status` clean, nothing committed.

## Commit 3 — the assembly slice; the QUEUED line closes

Slice `expansion.recentBills` to the compact cap at the **band's assembly site** — consumer-side, shared helper untouched, `/members`' unsliced path untouched. Legal only because commit 1 moved the +N gate off array length. Re-measure the served document and state the number next to 630's 650,209-byte baseline — today's saving is small (12→10 and 9→9 at the current band) and the point is the bound, not the bytes; say that honestly. HO 533 serialization check rides the changed return. Tombstone the `absence-band payload` QUEUED line in `docs/backlog.md`, pointing here.

## Gates

1. **Harness:** feed 16 untouched and still green. The absence legs update for the overlay — plain-click opens (overlay, not reflow), ctrl-click name navigates-and-doesn't-open as before — plus new legs: Esc-closes-with-focus-return; outside-click closes AND the clicked target's behavior proceeds (assert both halves — a leg that only checks the close proves less than it prints); open-A-click-B switches. State the new total.
2. **Audit `--route home`, closed state:** cite the legs and read the expected figures **from the current baselines on main**, not from this handoff — the M1x lesson, now policy. The overlay's open state isn't crawled; scope that honestly in the commit.
3. Hydration grep on the island (no clock — listeners are fine); typecheck + build per commit; explicit pathspecs; code and docs never mixed.

## HALT 1 — owner's eyes

Screenshots at 1440 and 2560: closed band, open compact card at each width (2560 three-column, 1440 stacked with the internal scroll visible), and one shot mid-interaction proving the page below didn't move — plus the zero-reflow delta numbers.

## Close — `refs/heads/631-review`

Docs commit: roadmap block for HO 631, pointer → 631 — both rulings (compact interior; overlay with click-outside/Esc semantics) recorded as made off the live mock, the count-source fix and why it preceded the slice, the zero-reflow instrument's figures and falsification, the QUEUED tombstone. `docs/design/mock-631-absence-card-overlay.html` rides this commit as the ruling's record. Grep gates: "HO 631" ×1, previous pointer reads 1. Delete the ref after landing.
