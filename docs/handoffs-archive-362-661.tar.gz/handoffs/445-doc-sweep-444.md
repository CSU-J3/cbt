# HO 445 — doc sweep: reconcile the CBT-topic crosswalk (closes HO 444, closes the HO 437 fork)

Docs-only reconciliation of HO 444 (CBT-topic crosswalk on `/lobbying`, live at `549d81e`). No code. Four files: `docs/roadmap.md`, `docs/oddities.md`, `.claude/skills/cbt/SKILL.md`, `docs/backlog.md`.

Ground-truth anchor: I re-fetched at the start of this session. `origin/main` is `549d81e` (the two 444 feature commits landed clean over `2c23d3e`). The feature commits touched no docs — verified — so the four files below are in their pre-444 state and this sweep is the only thing bringing them current. Re-grep every line number at write time; they're from the `549d81e` fetch.

This closes more than the usual single item: HO 444 was the **last** of the four surfaces banked in the HO 437 block. So the sweep must record the whole fork as discharged, not just tombstone one entry.

## Edit 1 — `docs/roadmap.md` (append-only)

Append a new "Also (HO 444)" block **immediately after** the "Also (HO 442)" block (the paragraph ending `…matching HO 437/439–440. Docs: HO 443. **Also notes now run through HO 442.**`) and **before** the `**Banked / unbuilt:**` line. Bump that trailing pointer 442 → 444.

**Append-only discipline (HO 418 precedent): do NOT edit the HO 442 block.** Its clause "that crosswalk is the other still-banked item" was true when written; the new block supersedes it by recording the ship. Leave every prior dated block untouched — add, don't retro-edit.

Drafted block (match surrounding density; edit freely):

> **Also (HO 444), the CBT-topic crosswalk on `/lobbying` — the LDA arc's last banked surface, no theme-% change.** The final item banked in the HO 437 block (bill-keyed → 439–440; top-firms → 442; this closes the crosswalk), so the **HO 437 four-item fork is now fully discharged — nothing from it stays banked.** Shipped + prod-verified across `8f7d7bd` (data) · `549d81e` (surface); live SHA `549d81e`. **Two calls shaped it. Build, not probe:** unlike every prior `lda_*` surface (434→435, 439→440), it introduced no new cold query — `computeTopicCrosswalk` is a **fourth consumer of the shared `readLdaTables` pass** (beside `computeIssueRollup`/`computeBillDrill`/`computeTopFirms`), one in-memory re-bucketing of the already-loaded `uuidsByCode` sets, so the build/probe split didn't apply (the HO 442 precedent). **`/lobbying` section, not a topic hub:** there is no topic entity route (topics are a filter/facet only), so cross-linking lobbying onto a topic page has no home — the self-contained surface is a **BY-CBT-TOPIC section on `/lobbying`** (new Section 3, between the issue two-column and TOP FIRMS; TOP FIRMS → 4, feed → 5), which does **not** reopen the HO 437/442 native-labels decision (that was about not *replacing* the native `general_issue_code` bars; this sits alongside them, disclosing the lossiness by keeping both, and its payoff is expressing lobbying in the same 24-topic vocabulary as the dashboard's bill distribution). **The map** (`lib/lda-issue-topic-map.ts`, a typed `Record<string, Topic>` — not `enums.ts`, not JSON, so the per-code judgment comments type-check): **79 LDA codes → 23 live CBT topics**; `elections` legitimately empty (no lobbying issue code maps there — an honest gap, not forced); **`other` = 21** industry/profession/contested codes (comprehension-over-coverage, the `TOPIC_ALIASES` posture). Two contested calls resolved on review: **CPT (Copyright/Patent) → `technology`** and **FAM (Family/Abortion/Adoption) → `healthcare`** (the closest single home for a single-valued map; the abuse-vs-industry asymmetry — ALC→healthcare as the *abuse* code, TOB→other as the *industry* code — is deliberate, see oddities). **The multi-code property:** a filing carries multiple issue codes, so it lands in multiple topic buckets — topic-filings sum **213,780 > corpus 110,055**, NOT a partition (the same property the native issue bars have; the section header discloses it, never "share of filings"). Invariants: 23 topics, 0 unmapped (structural — `?? "other"` catch-all), the HO 442 `5,175`-registrant readout holds (same `readLdaTables` map). **No cost probe, no migration, no new cron slot, no new nav item** — the fourth blob (`lda_topic_crosswalk`) rides the same budget-gated cron step under the one `revalidateTag("lda")`. **No theme-% change** — an enabling/aggregate surface on the LDA pillar (the `/patterns` class), matching HO 437/439–440/442. Docs: HO 445. **Also notes now run through HO 444.**

## Edit 2 — `docs/oddities.md`

Append a new section at the end (match the `## Heading (HO X, date)` + prose format). This is the decision record so the map's deliberate asymmetries aren't re-litigated:

> ## LDA issue → CBT topic is deliberately lossy, single-valued, and non-partitioning (HO 444, Jul 2026)
>
> The `LDA_ISSUE_TO_TOPIC` map (`lib/lda-issue-topic-map.ts`, 79 codes → 23 live topics) makes several calls that read as inconsistencies but are decisions — don't "fix" them.
>
> **Abuse-code vs industry-code asymmetry.** ALC (Alcohol & Drug Abuse) → `healthcare` because it's LDA's *substance-abuse* code (public health); TOB (Tobacco) → `other` because it's the *industry* code (like BEV). The divergence is intentional — an auditor seeing ALC-in-healthcare and TOB-in-other should not collapse them.
>
> **`elections` is legitimately empty.** No LDA issue code maps to it; force-mapping one would be worse than a visible gap.
>
> **`other` (21 codes) is the honest residue,** not laziness: sector/profession codes with no policy-topic home (aerospace, automotive, gaming, tobacco) plus genuinely contested ones. Comprehension-over-coverage — the same posture as `enums.ts` `TOPIC_ALIASES`.
>
> **Two contested calls, resolved on review (HO 444).** CPT (Copyright/Patent) → `technology`; FAM (Family/Abortion/Adoption) → `healthcare` — the closest single home, since the map is single-valued (a code maps to exactly one topic). `civil_rights` was the FAM alternative; the per-code comment in the map records it.
>
> **Non-partition (a mechanism fact, not a bug).** A filing carries multiple issue codes, so `computeTopicCrosswalk` lets it land in multiple topic buckets — topic-filings sum (213,780) EXCEEDS the corpus (110,055). This is the same property the native issue bars already have; the `/lobbying` section header discloses it. If a future reader "reconciles" the topic sum to `stats.filings`, they've broken the multi-code semantics.

## Edit 3 — `.claude/skills/cbt/SKILL.md` (three edits; diff-gated)

SKILL is tracked and changes are approval-gated — show the diff, wait for the green light before it's in the commit.

**3a. The LDA blob-contract block (~L811–841).** After the `-- HO 442: a THIRD dashboard_state blob (key 'lda_top_firms')…` entry, add a fourth:

> `-- HO 444: a FOURTH dashboard_state blob (key 'lda_topic_crosswalk') — the corpus`
> `-- expressed in CBT's 24-topic vocabulary. computeTopicCrosswalk is a FOURTH`
> `-- consumer of the same readLdaTables pass (beside computeIssueRollup/`
> `-- computeBillDrill/computeTopFirms) — re-buckets the already-loaded uuidsByCode`
> `-- sets through the static LDA_ISSUE_TO_TOPIC map (lib/lda-issue-topic-map.ts,`
> `-- 79 codes → 23 live topics, elections empty, other=21), dedup within topic. No`
> `-- new cold query, so NO probe (unlike 434→435 / 439→440). NON-PARTITION: a`
> `-- filing carries multiple codes → lands in multiple topic buckets, so`
> `-- topic-filings sum (213,780) EXCEEDS stats.filings (110,055) — same property`
> `-- as the native issue bars; the section header discloses it, never "share".`

**3b. The `/lobbying` section list (~L1326).** Insert the crosswalk as the new Section (3), renumber TOP FIRMS → (4) and the feed → (5). Then fix the trailing "banked" clause. Current tail reads `…top-firms leaderboard **shipped HO 442** (…); only the CBT-topic crosswalk still banked.` Replace the final clause with: the crosswalk **shipped HO 444** (the BY-CBT-TOPIC section, `getTopicCrosswalk`, blob `lda_topic_crosswalk`; native issue bars unchanged) — **nothing from the HO 437 block still banked.** Add the new section inline in the same voice as the others: `(3) a **BY CBT TOPIC** section (HO 444) — the corpus re-bucketed into the 24 CBT topics via the static issue→topic map, topic-colored bars (`getTopicCrosswalk`, blob `lda_topic_crosswalk`; null → omitted), non-interactive v1, header labeled "by issue focus" (NOT "share of filings" — multi-code, non-partition);`.

**3c. The query-helper list (~L1190–1191).** Add a `getTopicCrosswalk()` line beside `getLobbyingRollup` / `getBillLobbying`, mirroring the `getTopFirms` doc shape: an O(1) parse of the `lda_topic_crosswalk` `dashboard_state` blob (NOT a live query), tag `lda`, null before the first rollup lands (section omitted), 3600 TTL.

## Edit 4 — `docs/backlog.md` (two edits)

**4a. Strike the BANKED crosswalk entry (~L82).** It currently reads `- **CBT-topic crosswalk (LDA ~79 codes → 24 topics) — HO 437.** …build it only if a topic-aligned view is actually wanted alongside the native labels.` Strike it in place with a SHIPPED pointer, matching the top-firms strike right below it (L83):

> - ~~**CBT-topic crosswalk (LDA ~79 codes → 24 topics) — HO 437.** An optional overlay for a later `/lobbying` cut.~~ — **SHIPPED HO 444** (`8f7d7bd` data · `549d81e` surface), the BY-CBT-TOPIC section on `/lobbying` (79 codes → 23 live topics, `other`=21, `elections` empty). **This closes the HO 437 four-item fork** (439–440 bill-keyed · 442 top-firms · 444 crosswalk). See DONE → HO 444.

**4b. DONE tombstone.** Append to the DONE section (append-only tombstones):

> - **HO 444 — CBT-topic crosswalk on `/lobbying`.** `8f7d7bd` (data) + `549d81e` (surface), prod-verified. `computeTopicCrosswalk` as the 4th `readLdaTables` consumer (no probe — no new cold query, HO 442 precedent); `LDA_ISSUE_TO_TOPIC` (`lib/lda-issue-topic-map.ts`, 79 → 23 live topics, `other`=21, `elections` empty; CPT→technology + FAM→healthcare the resolved contested calls); 4th `dashboard_state` blob (`lda_topic_crosswalk`) + `getTopicCrosswalk`; BY-CBT-TOPIC section (Section 3, top-firms → 4, feed → 5). Non-partition (topic sum 213,780 > corpus 110,055) disclosed in the header. **Closes the HO 437 fork.** Docs: HO 445.

**4c. QUEUED — log the v2 so it's not lost.** Code left the topic→codes→drill interaction as a code comment. Add a small QUEUED item:

> - **`/lobbying` topic crosswalk — click-through to constituent codes (HO 444 v2).** The BY-CBT-TOPIC bars are non-interactive in v1. A clean v2: clicking a topic bar reveals the LDA issue codes that roll into it (from `LDA_ISSUE_TO_TOPIC`) → their existing per-code drills (already built on `/lobbying`). Low-lift — no new data layer, reuses `rollup.drill[code]`. *Close:* a topic bar drills to its codes' existing drill cards.

## Process

- **One commit**, docs-only — the sweep is the standalone "separate from code" commit (the feature already landed at `8f7d7bd` + `549d81e`). All four files staged by **explicit pathspec** (`docs/roadmap.md docs/oddities.md docs/backlog.md .claude/skills/cbt/SKILL.md`) — no `git add -A`.
- **Concurrent session still live** — it holds `components/RaceCard.tsx`, `components/CompetitiveRacesBlock.tsx`, `app/globals.css`. This sweep touches none of them; do not touch them, do not force-push. Their next push expects `549d81e`-descended history.
- **Spec-driven** — propose the plan, show diffs (SKILL's especially — the approval-gated file), wait for approval, then the single commit. No auto-commit.
- **Push** — ancestry eyeball immediately before: one commit riding on `549d81e`, nothing behind, clean fast-forward.

read docs/handoffs/445-doc-sweep-444.md and follow it
