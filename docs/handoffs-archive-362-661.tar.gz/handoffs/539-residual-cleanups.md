# HO 539 — two residual cleanups from the 537 arc

**Next HO after this: 540** (the `/vote/[id]` roll-call page — its own handoff). Take numbering from `docs/roadmap.md`, never from an on-disk filename.

Two unrelated small items, one commit each. Neither is a feature. This is the HO 430 shape (isolated cleanups retiring follow-ups from a just-closed arc).

---

## Item 1 — the `/amendments` blurb's qualitative chamber claim

**Commit 1, code.** `app/amendments/page.tsx` only.

The blurb currently ends:

> And though filings skew heavily Senate ({N}%), the recorded votes split near-evenly by chamber.

"Near-evenly" is a hardcoded judgment sitting on interpolated numbers. True at 97 against 90, wrong the moment the split moves, with nothing to catch it. That's the WATCH entry HO 538 filed.

Restoring the counts is not the fix. HO 537's last commit (`c35837e`) removed them precisely because they duplicated the readout verbatim, and putting them back reopens the HO 509 double-print.

**Do this instead: state the contrast as percentages.** The blurb gets the Senate *share* of recorded votes beside the Senate share of filings, so the sentence carries the finding without an adjective and without repeating the readout's counts:

> And though filings skew heavily Senate ({filingPct}%), recorded votes are only {votedSenatePct}% Senate.

Both interpolated, both derived from `summary`. The readout below keeps the raw counts (`97 Senate · 90 House`), so the two lines share no fragment. If the split ever inverts, the sentence stays true on its own terms.

Two details. Round both percentages the same way (`toFixed(0)`, matching the existing filings figure). And if `voted` is 0 the clause has nothing to say, so guard it out rather than printing `0% Senate`.

Verify on the cache-hit path, three hits: both percentages render, the blurb and readout share no verbatim fragment, and the exclusion-disclosure line below is untouched.

---

## Item 2 — write the review-ref workflow into SKILL.md

**Commit 2, docs.** Separate commit, and it touches `SKILL.md`, so it goes through the review-ref route (which is the thing it documents).

The workflow exists as practice but isn't in `SKILL.md`. It was established at HO 508, when a pasted diff was swallowed three times and only its prose framing arrived. It fired twice more during the 537 arc: the roadmap block was described rather than delivered on two consecutive attempts.

Add a short subsection to the conventions area, near the existing commit-discipline material. It needs to carry:

The mechanism. Commit locally, push to a throwaway ref (`git push origin HEAD:refs/heads/<ho>-review`), the reviewer fetches and reads the diff out of the repo, approves, then main fast-forwards and the ref is deleted. The ref is inert: no main history, deletable, never force-pushed onto anything shared.

Why it satisfies the SKILL self-mod guard rather than bypassing it. The guard exists to stop SKILL landing on main without an approved diff. A review ref is not main.

**The scope, which is wider than SKILL.md.** Use this route by default for any change where the reviewer needs the actual text rather than a summary. That covers SKILL edits, and it covers **append-only roadmap blocks** — a wrong clause there is permanent, correctable only by a later block, so it gets read before it lands. Three swallowed pastes across two arcs is enough to make paste-first the exception.

Recognition symptom, so a future session identifies it fast: a summary of a diff arrives and the diff itself doesn't, twice. Stop pasting at two, switch to the ref.

Also update the promoted doc-duplication WATCH entry in `docs/backlog.md` to note the fifth instance was caught by reading rather than by anything enforcing it. One clause, not a rewrite — the entry already carries the pattern and the ownership-split rule.

---

## Constraints

Explicit pathspec staging. Diff shown and approved before each commit. The two commits stay separate: code and docs never ride together. Commit 2 goes to `refs/heads/539-review` for the SKILL read, then fast-forward and delete.

No roadmap block is owed for this HO unless item 1 is judged a shipped surface change; it isn't (one sentence on an existing page), so fold both into the next doc sweep rather than minting a block. Say so in the sweep.
