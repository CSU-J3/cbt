# HO 641 — doc sweep for HO 640: a falsified class claim, and the settled-guard freeze

Docs only. **No code, no ingester changes, no repair script, no backlog "fix" beyond what's specified here.** The `isSettled` bug is real and is **not** fixed in this HO — it gets filed, with its unresolved design question named, and built under its own number after a probe.

## First: push the probe

`ffde734` is committed and unpushed. Ancestry eyeball (`git log --oneline @{u}..HEAD` — expect exactly `ffde734`), fast-forward, no force. Probes push separately from doc commits, so this goes before anything below.

## Why this is a rewrite, not an amendment

HO 639's backlog line 2 asserts the 11 shares-without-a-winner contests are **two classes with opposite fixes** — top-two/jungle where a single `status='winner'` row is a *category error* and the harvest's model is wrong, and ranked-choice where a winner is well-defined and it's an ingestion gap.

**HO 640 falsified the category-error half by measurement.** Across completed contest-party `open` contests: **CA 52 total, 48 with winners, 48 carrying exactly two winner rows, zero carrying one. WA 10 total, 3 with winners, all 3 carrying two.** Fifty-one top-two contests are marked correctly with two winners each. The schema, the ingester and HO 207's two-★ rule all handle top-two properly.

So the 8 are not a model error. **They are the same missing-marking failure as ME and NJ**, and the 11 collapse into **one class, not two**.

**That claim was mine, not Code's.** I wrote the two-class split into the HO 639 handoff and Code implemented what I specified. I reasoned from what top-two *ought* to imply rather than measuring what the corpus *does*, and the plausible story was the wrong one.

**This is the third instance in this arc and all three are mine.** §1 of the HO 638 handoff ("frozen at HO 171, `last_verified` 2026-06-01" — the run had happened and touched ME); the NJ-07 "shape precedent" cited at seed-diff approval (cosmetic — JSON order feeds nothing); and now the category-error split. Each was tidier than the truth, and each survived until something measured it. Record the pattern in the roadmap block: **a framing that makes the backlog tidier is a hypothesis, not a finding, and this arc produced three of them.**

The count was also wrong in its inputs. **ME is two contests, not one** — `senate-ME-2026-D` and `senate-ME-2026-R` are separate `primaries` rows — so the split is **8 / 2 / 1**, and the genuinely unclassified row is **`house-NJ-09-2026-R` alone**: an ordinary partisan primary, two candidates, Pino at 51.5%, a derivable winner, no top-two or RCV excuse. Flagging that 8 + ME didn't reach 11 was right; inferring "2 uncharacterized contests" from the gap was not.

## The finding that outranks all of it

`isSettled` (`primaries-sync.ts:551`) is **past-dated AND carries a recorded share**, evaluated at all three write paths before the incoming roster is built — and `status` and `vote_pct` are written **in the same INSERT**.

So a contest scraped in the window *after* Ballotpedia posts results but *before* it marks a winner receives shares + `running`, and **becomes settled in that same instant.** Every subsequent tick refuses it. It is a race against Ballotpedia's call, and losing it is permanent — no cadence reaches it, only a repair path outside the guard.

**516 of 718 completed contests are settled-frozen. All 11 are among them.** The 123 shares-less rows are still reachable precisely because they have no share; these 11 are not.

Read the 516 correctly in the write-up: **most of those froze correctly**, having been marked before they settled. The damage is the 11 that froze mid-write. The mechanism, not the count, is the defect — and it keeps catching contests every cycle.

**One-row arithmetic gap, cite it rather than smooth it.** If every winner-carrying contest also carries a share, contests-with-shares is 506 + 11 = **517**, against **516** reported settled. The likely explanation is one contest with a winner and no recorded share (an uncontested seat, or a winner marked from outside a votebox) — but that is an inference, not a measurement. Write it as an open one-row residue with the candidate explanation named, in the HO 633 form: **cited, never subtracted.**

## Commit split

- **Commit A** — `docs/roadmap.md`, `docs/backlog.md`, `docs/oddities.md`
- **Commit B** — `.claude/skills/cbt/SKILL.md`, only if §5 finds a stale claim. If nothing there is wrong, **there is no Commit B** — say so rather than manufacturing an edit.

Explicit pathspec. Diffs read before staging. **The relay swallows diffs in both directions**, so deliver Commit A by pushing to `refs/heads/641-review` — not by pasting, and not to a gitignored file, which I cannot reach.

## Phase 1 — Diagnostic (HALT after)

1. **Locate the exact backlog line 2 text** and quote it, so the rewrite replaces rather than duplicates. Confirm whether it sits in QUEUED (HO 639 placed the three build-shaped lines there).

2. **Read `isSettled` and its three call sites verbatim** and quote the predicate. I am working from your report; the doc entries must be written against the source. Confirm: (a) the predicate is past-date AND has-share with no winner term, (b) `status` and `vote_pct` are written in one INSERT at each path, (c) whether any path bypasses the guard today.

3. **`primaries.race_id` — how dead is it?** Your correction says it is the 3/907 link and not what the harvest joins. Report the exact figure and whether **anything** in the repo reads that column. If nothing does, it is a schema field that looks like the join key and isn't, which is an oddity in its own right; if something does read it, that reader is a defect and gets its own line.

4. **`primary_type = NULL` on all four WA rows.** Confirm, and report how many of the 718 carry NULL. Confirm this is an instance of the existing HO 584 fallback-default WATCH rather than a new finding — quote that WATCH's current text so the doc sweep cites it instead of opening a duplicate.

5. **SKILL check.** Grep for any claim about `primary_candidates.status`, top-two winner marking, or `primaries.race_id` as a join key. String anchors, not line numbers — the repo file is 2411 lines and the project copy is 1691, so line numbers from any handoff including this one are unsafe.

**HALT.** Report 1–5 before writing.

## Phase 2 — Commit A

### `docs/backlog.md`

**Rewrite QUEUED line 2 entirely.** Its two-class premise is dead; an amendment would leave the falsified sentence sitting above its own correction. The replacement says:

- The 11 are **one class**: contests carrying `vote_pct` with no `status='winner'`, all of them frozen by `isSettled`.
- The split is **8 contest-party-open / 2 ME (D and R separately) / 1 NJ-09-R**, and the shape distinction is **descriptive, not causal** — every one of them failed the same way.
- The category-error hypothesis is **falsified with the numbers**: CA 48/48 and WA 3/3 top-two contests carry exactly two winner rows, zero carry one.
- **Product impact is 5, not 11.** Only NJ-09, WA-05, WA-08, ME-D and ME-R sit on rated seats and would harvest if a winner existed; the other 6 are unrated and the harvest never reaches them. Record how that was measured — the real `state` + `chamber` + `CAST(district)` join gated by `race_ratings`, **not** `primaries.race_id`, which was this probe's own first-pass error.
- A fourth shape rides inside ME: `senate-ME-2026-R` has **one candidate, Collins at 100.0%** — uncontested, so there is no votebox contest to mark. This is why the naive fix is wrong (below).

**Add a new QUEUED line for the freeze**, and make it the parent — line 2 is now a symptom of it. It carries the mechanism, the permanence, the 516 with its correct reading, the one-row gap, and this, which is the reason it is not being fixed in this HO:

> **The naive fix is wrong and must not be attempted as a one-liner.** Adding a winner term to `isSettled` un-freezes every contest that legitimately has no winner — uncontested seats like `senate-ME-2026-R`, where Ballotpedia marks no votebox winner because there is no contest — and those would re-scrape forever. A correct fix needs a bounded re-check (eligible for N days past `primary_date`, then settle regardless) or an attempt counter, and N has to be measured against how long Ballotpedia actually takes to call. **That is a probe, then a build, under its own number.**

Note also that the repair of the existing 11 is a **separate decision** from the guard fix: the guard stops new losses, and only a path outside it recovers the 11 already frozen.

### `docs/oddities.md` — append at the END, two entries

1. **A settled-guard that reads one half of a two-column write freezes a partial truth as a complete one.** `status` and `vote_pct` land in the same INSERT; the guard reads only `vote_pct`. A contest scraped between results posting and the winner being called is therefore marked done by the arrival of the half that came first. The tell generalizes: **when a guard's predicate is a subset of what one write produces, the guard can fire on a partial write.** Include the ME/WA exhibit and the permanence.

2. **`primaries.race_id` is a column that looks like the join key and isn't** — pending Phase 1 item 3's figure. The harvest joins on `state` + `chamber` + `CAST(district AS INTEGER)`; the named column links 3 of 907. This probe's own first pass used it and reported all 11 unreachable before re-measuring to 5. **Include that the probe got it wrong first** — a self-corrected measurement is the useful part of the entry, and it is exactly what a later reader will be about to do.

### `docs/roadmap.md` — one appended block, append-only

Header `**Also (HO 640–641)**`, closing `Also notes now run through HO 641.` Never retro-edit a prior block; HO 639's block stays as written and this one carries the correction, the way 635–636 corrected 634's `getStaleBills` misattribution.

The block carries: the partition reproducing exactly at 718/506/212 → 11/123/78 on a verbatim-copied predicate (**a reproduction that matched is what licensed everything after it**); the falsified category-error claim with its 48/48 and 3/3 figures; the corrected 8/2/1 split and the ME double-count; the `isSettled` freeze as the parent finding, with 516, the one-row gap cited, and why the naive fix is refused; the reachability self-correction from 11 to 5; the WA verdict as **structurally missing** with its evidence (`pc.updated_at` at or after 2026-08-04 on all ten, and WA-04/06/10 taking two winners each in the same 2026-08-06 tick that gave WA-05/07/08/09 none); `isWinner` originating at `primary-candidates-scrape.ts:212` off a Ballotpedia votebox CSS class, so no mark means no winner; the WA `primary_type = NULL` as an instance of the HO 584 WATCH, which means **any future branch on `primary_type='top_two'` misses WA entirely**; the cost at 11 statements / 38,864 `rows_read` with both table counts predicated; and the three-wrong-framings pattern named as mine.

## Verification

- Zero deletion lines in roadmap and oddities. **Backlog will show deletions — that is intended**, line 2 is being replaced. Report the deletion count and confirm it is confined to that line.
- Use `diff | grep -c '^<'` or `--stat`'s deletion column, **not** `grep -c '^-[^-]'` — that pattern misses a deleted markdown bullet (`- **text**` diffs to `-- **text**`), which both of us ran and both of us reported as verification at HO 639.
- Roadmap headers monotonic, each HO once, pointer at 641.
- Oddities entries at the END.
- Commit A pushed to `refs/heads/641-review` and nothing else; main untouched until I approve.

## Out of scope

- No `isSettled` change, no repair script, no re-scrape, no ingester touch.
- No new backlog lines beyond the rewrite and the freeze parent.
- The `deriveMatchup` local `won` nit stays parked.
- The HO 503/506/637 citation is **verified correct** — `docs/oddities.md:25` is the origin entry, headed HO 503 / HO 506, naming the self-removing and saturated mechanisms. That open loop is closed; do not revisit it.
