# HO 409 — doc sweep for HO 408 (S-OK-2026 incumbent fix)

> Self-claim the next free number: `ls docs/handoffs/ | sort -V | tail`. If HEAD has moved past 408, renumber.
>
> **Docs-only.** No code, no schema, no re-seed. `git add` only the doc files listed in the commit block — explicit pathspec, ancestry re-checked, separate from any code commit. If `SKILL.md` is touched it trips its self-mod guard: stop and re-approve rather than routing around it.

HO 408 shipped as `d234531` (verified live). This reconciles the four docs against what that fix actually changed and what it surfaced. Reconcile **in place** — don't append.

## What 408 established (grounding for the edits — already verified, don't re-derive)

- The race card's incumbent is **derived**, not seeded: `backfill-races.ts` runs `INSERT OR IGNORE ... incumbent_bioguide_id = m.bioguide_id` where the senate member's `next_election_year = 2026`. There is no seed array holding the incumbent. So a wrong `members.next_election_year` mis-derives the race incumbent.
- `S-OK-2026` derived to **Lankford (L000575)** because Lankford's member row carries `next_election_year = 2026` — wrong; he's Class III / 2028. Corrected to **Armstrong (A000383)** (appointed 2026-03-24, barred from running → open seat).
- The `races` schema has **no `seat_type` and no `retirement_note` column**. Open-seat state is `incumbent_running` alone (`0` = not running → OPEN tag + cash suppression, `1` = running, `NULL` = uncurated). The retirement-only seed pattern (`{ "id": "...", "incumbent_running": 0 }`) sets only the flag; the card still names the departing incumbent via the join (S-KY renders "McConnell · OPEN").
- `seed-races.ts` was extended: `incumbent_bioguide_id?` on `RaceSeed` + a conditional UPDATE that sets **only** that column (+ `last_verified`) when present — an additive curated override over backfill's derivation, never clobbering rating/source/roster.
- Two member-data bugs confirmed and **out of 408's scope, banked here**: Lankford `L000575` `next_election_year=2026` (should be 2028); Armstrong `A000383` `next_election_year=2031` (impossible odd year).

## `backlog.md`

- **Close the P1** in FIT & FINISH: `/races` S-OK-2026 wrong incumbent → DONE (HO 408, `d234531`, verified live). Move to the DONE section with the one-line resolution.
- **Sharpen the integrity OPEN LOOP** (the odd-year-Senate / `is_current` item from HO 404). Add the mechanism and the two concrete rows:
  - Root: race incumbent is derived by `backfill-races.ts` from `members.next_election_year` (`= 2026` → "up this cycle"), with no cross-check against `terms[].class`. Every wrong member-year is a latent wrong-incumbent on some race card. S-OK was the visibly-wrong instance; others may land on a plausible name and go unnoticed.
  - Confirmed wrong rows to fix: **Lankford `L000575` 2026 → 2028**; **Armstrong `A000383` 2031 → (correct even year; he's a caretaker not standing, so his "next election" for *his* seat is 2032 per his `current_term_end_year`, but he is barred from that race — verify the right value when the arc is worked).**
  - Systemic probe for when the arc is picked up: audit `members.next_election_year` against `terms[].class` from congress-legislators across **all** current senators, not just the two caught. That's the fix behind the one-card patch.

## `oddities.md`

Field note (new):

- **Race incumbent is derived from `members.next_election_year`, not seeded.** `backfill-races.ts` sets `races.incumbent_bioguide_id` to the senate member whose `next_election_year = <cycle>`. A wrong member-year therefore produces a wrong race incumbent. First instance: `S-OK-2026` derived to Lankford (his row said 2026; he's 2028/Class-III) instead of the Class-II seat. Hand-overridden via the seed in HO 408.
- **`races` has no `seat_type` / `retirement_note`.** Open-seat state = `incumbent_running` only. The OPEN tag + cash suppression key off `incumbent_running = 0`; the departing incumbent is still named via the `incumbent_bioguide_id → members` join (so a bare `incumbent_running:0` on a wrong incumbent renders "WrongName · OPEN").
- **Appointed caretakers barred from running are the OPEN case** even though `incumbent_running` was authored for retirements. Same signal, different cause.

## `SKILL.md` (only if a convention actually changed — it did)

One line, in the races / seed section:

- `seed-races.ts` now applies a curated `incumbent_bioguide_id` (from `races-seed.json`) as an **additive override** over `backfill-races.ts`'s derivation — sets only that column + `last_verified`, never clobbers rating/source/roster. Use it to correct any mis-derived race incumbent, not just S-OK.

If that's the only SKILL change, still stop and re-approve on the self-mod guard before committing.

## Commit

```
git add docs/backlog.md docs/oddities.md .claude/skills/cbt/SKILL.md   # only the files actually edited
```

Explicit pathspec (drop SKILL.md from the add if it wasn't touched), ancestry re-checked immediately before push, docs-only — no code, no data, separate from `d234531`. Show me the diffs before committing.
