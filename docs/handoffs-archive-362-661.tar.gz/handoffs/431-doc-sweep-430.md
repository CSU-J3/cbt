# HO 431 — doc sweep for HO 430 (shared `median()` + caucus diagnostic fix)

Fold HO 430's two commits into the ledger. Both items still sit in QUEUED as if unbuilt, so next session mis-scopes them. **Docs-only, one commit, no code** — same correctness-not-new-surface bucket as the 405–413 arc, no theme-% change.

Re-grep the two QUEUED line numbers before editing (they drift — currently `docs/backlog.md` L56 median, L57 diagnostic). Confirm the DONE append point (currently L168).

---

## 1. `docs/backlog.md` — strike both QUEUED items, tombstone both to DONE

Remove the two QUEUED bullets (L56 `median()` extraction, L57 ideology diagnostic) and add two append-only DONE tombstones, matching the surrounding format (`~~**Title**~~ — SHIPPED <sha>, …`).

**median() tombstone (`6329a0f`):**
- Four inline copies confirmed byte-identical (only `IdeologyStrip`'s `s`-vs-`sorted` local name differed), replaced with imports of a new zero-import leaf `lib/median.ts` — **that file is now the canonical definition, four importers** (`lib/queries.ts` `./median`; the island `@/lib/median`; the two scripts `../lib/median` / `../../lib/median`), so nothing re-inlines it again.
- The `docs/design` HTML's separate inline `median(a)` is a different signature, not an app consumer, left alone. No fifth consumer.
- Post-extraction 119th cross-check House 0.925 / Senate 0.918, delta 0.000 == the band baseline (no behavior change); `npm run build` + `tsc --noEmit` clean.

**Diagnostic caucus-fix tombstone (`d061284`):**
- `ideology-coverage-419.ts` now flags a member only when Voteview's `party_code` letter matches **neither** registration (`members.party`) **nor** caucus — not caucus-only, which would newly break King/Sanders.
- **Premise correction, record it:** the QUEUED item claimed King, Sanders, *and* Kiley trip the diagnostic. A real run showed **only K000401 Kiley** did. King/Sanders code Voteview `328` (→I), already matching `members.party='I'`, so they agreed all along — the "King, Sanders are the standing Senate pattern" line in the old QUEUED item was wrong. (HO 422's caucus-vs-registration finding confirmed on live data; another "trust the live run, not the logged claim" instance — see oddities.)
- Caucus source: a small typed `INDEPENDENT_CAUCUS` map keyed by real bioguide (King K000383→D, Sanders S000033→D, Kiley K000401→R), commented fail-loud. After: 0 disagreements on a clean roster with all three independents present; the line relabeled to "genuine party mismatches (registration/caucus gap suppressed)". Diagnostic-only — no `members`/`sync-members` touch (Kiley's `I` is correct, HO 422).

## 2. `docs/roadmap.md` — append an "Also (HO 430)" block, bump the pointer

**Append-only.** Add a new block after the HO 427–428 block (~L288). Do **not** retro-edit any prior block's clause (HO 418 precedent, nearly violated at HO 429 edit 6). Match the block voice (terse, cite both SHAs, "no theme-% change"):

- HO 430 retired the ideology arc's two tail items — `6329a0f` extracted the shared strict `median()` to a zero-import leaf `lib/median.ts` (four importers; 119th cross-check unchanged at 0.925/0.918); `d061284` taught `ideology-coverage-419.ts` the caucus-vs-registration distinction (flag only when Voteview matches neither registration nor caucus).
- One clause on the premise correction: the diagnostic's logged "three independents flagged" was wrong — only Kiley tripped it (King/Sanders read Voteview 328→I, already agreeing).
- **No theme-% change** — correctness, not new surface; Member depth holds at 99.
- Move the pointer: **"Also notes now run through HO 430."** (currently 428.)

## 3. `docs/oddities.md` — append the caucus mechanism + premise correction

Append at the tail (after the FEC candidate-ID entries), matching the `## Title (HO X, date)` shape. It belongs in the existing "trust a live grep, not a snapshot/logged claim" family — cross-reference that cluster, don't duplicate it:

> **Voteview `party_code` follows caucus, so genuine independents read 328→I and only a major-party-caucusing independent diverges from registration (HO 430).** The ideology diagnostic's registration-vs-caucus check flags almost nobody: Voteview codes King/Sanders as `328` (I), already matching `members.party='I'`, so they agree — the only current divergence is Kiley (registered `I`, Voteview `200`/R because he caucuses R). The backlog's QUEUED item had logged all three as flagged; a live run showed one. Same lesson as the snapshot-staleness cluster above — the logged claim was a claim, not a fact, and the diagnostic run is the authority. The correct invariant: flag only when Voteview matches neither registration nor caucus.

## Out of scope
- **No SKILL edit.** SKILL already calls this "the shared `median()` helper" and states the strict method verbatim; the extraction makes that language literally true rather than aspirational. A one-line "canonical def in `lib/median.ts`" pointer, if ever wanted, is a separate self-mod-guarded change, not this sweep.
- No code, no `scripts/`, no schema, no `migrate.ts`.

## Commit discipline
One docs-only commit — `docs/backlog.md`, `docs/roadmap.md`, `docs/oddities.md`. Explicit pathspec, ancestry re-checked before push, no auto-commit/push, show the diff.

Suggested message: `docs: fold HO 430 (median extraction + caucus diagnostic) — tombstones, roadmap, oddities (HO 431)`

## Report back
- The diff.
- Confirmation it's docs-only (no code/scripts/schema touched).
- Confirmation both items left QUEUED and landed in DONE against their SHAs, the roadmap pointer reads "through HO 430," and the premise correction (only Kiley tripped, not three) is recorded in both the diagnostic tombstone and oddities.
