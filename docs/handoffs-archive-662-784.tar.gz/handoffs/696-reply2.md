# HO 696 — reply 2, re-delivered. TARGET: SKILL `:1946`, two provenance clauses; not any of your four guesses.

Read on the ref: `585dded`, only the block's §9 paragraph moved since `506ad98`, and the rewrite is accepted as read. §2 (the PIDs) is done and verified; the leaf-first collapse and the two-day-late task notifications are worth the block sentence they got. This file carries the whole of reply 2; the relay carried its subject.

## 1. The slot holds on two provenance clauses in SKILL `:1946`, repeated in six other places

SKILL `:1946` reads *"not the name HO 591 assigned it"* and, of the companion, *"landed at HO 604 C0 under its own downloaded name"*. Both are false against the tracked archive, and the same claims sit in `layout-conventions-arc.md:31`, the roadmap block, the oddities entry (twice), the `mock-591-dashboard-layout.html` allowlist note and the `:110` strike.

- **`604-type-scale.md:62–63`** (in `docs/handoffs-archive-362-661.tar.gz`) names both files by their `mock-591-*` names and assigns the renames: `mock-591-dashboard-layout.html → docs/design/dashboard-layout-target.html` and `mock-591-conventions.html → docs/design/layout-conventions-c1-c8.html`. **`:64` states the policy:** *"Descriptive names, no HO number — matching the seven files already in `docs/design/`."* So `layout-conventions-c1-c8.html` was the rename target the HO 604 handoff assigned, and `dashboard-layout-target.html` is a **deliberate rename**, not a download name. The rename is why the companion citation at `mock-591-conventions.html:166` dangles at all.
- **Timeline, off the commits and the mtime you took:** C0 `c943e07` landed 2026-08-06 **01:42Z**; the dictionary's mtime is **02:30Z**, 48 minutes later; the HO 605 sweep commits landed **02:46–02:47Z**, and **`605-doc-sweep-603-604.md:17`** looked for the file *"in the project root"* and, not finding it there, recorded it as never landed while it sat in `docs/design/` sixteen minutes old. Not a filename guess: a rename target searched for in the wrong directory, and every later reader searched by the target name.

**Replacement for the `:1946` clause, verbatim:** *It was on disk the whole time under the name it carried, not the rename target the HO 604 handoff assigned it (`604-type-scale.md:63`, tracked archive), and the HO 605 sweep looked for it in the project root (`605-doc-sweep-603-604.md:17`) sixteen minutes after it was saved to `docs/design/`.* **For the companion:** *landed at HO 604 C0 renamed from `mock-591-dashboard-layout.html` (`604-type-scale.md:62`), under that handoff's stated policy of descriptive names without HO numbers (`:64`).* Same correction in the other six places; the `historical-name` note says *renamed at 604 C0*, not *downloaded name*.

**One sentence the policy conflict owes,** in README rule 2 and the block: HO 604 C0 chose descriptive names without HO numbers on purpose (`604-type-scale.md:64`); rule 2 reverses that, because a renamed ruling record loses the citation trail its companion kept, which is the dangle this HO found. Stated so the reversal reads as ruled, not as an accident.

## 2. Method § Relay gains the inbound route, marked as a widening

Two inbound swallows in one HO, and you are right that the section states only the outbound remedy. Append to § Relay, in the method commit:

> - **Inbound has the same remedy.** A ruling or reply that arrives as a summary or a subject line is read from its file, saved to `docs/handoffs/` (repo-ignored, local) and named in the relay; it is never inferred from the line that arrived, and an unnamed target is a HALT (HO 696: the STEP 0 ruling and two review replies each arrived as their last line).

## 3. Then

Fixups into the owning commits, `--force-with-lease` on the ref, `git ls-remote`. Paste: the seven new SHAs, `git diff 560b865 <new SKILL commit> -- .claude/skills/cbt/SKILL.md` (one hunk expected), the gate `OK` on the new tip, the run id. The SKILL diff is read off the ref again; FF go follows in one line.

read and follow 696 — reply 2 re-delivered, SKILL :1946 and the inbound route
