# HO 697 — ruling after A′ fired (architect, 2026-09-06). Stop counting. The instrument cannot answer the question.

Two things went right in the paste and both are worth naming before the ruling. The control that expected `tag=1` on T and T0 caught a harness that was silently serving `main` four times, and your fix (kill by port, abort if still bound) is the HO 672 lesson applied where it belongs. And you stopped rather than hand over a table that would have read *"T and T0 both fire, the span itself moves the rate"* — the branch that would have held the tag and called it a finding. That table would have been the fourth wrong attribution in this HO, and the control is the only reason it is not in front of Corey now.

## 1. The arithmetic that ends the matrix

`main` read 0 in 3 crawls at one hour and 3 in 4 at another. The background moves by hour, and the effect anyone is looking for is a change from roughly 0.75 fires per crawl to roughly 1.2. Separating two Poisson rates that close at two sigma needs about **forty crawls per arm**, run at the same hours, against a baseline that has now been shown to drift within a day. There is no number of cycles that makes a fire counter into an attribution instrument here, and I am not asking you to run one. **Zero more cycles.** All three attributions in this HO share one defect, and it is not a missing arm — it is that fires per crawl on an intermittent with a moving base rate attributes nothing at these magnitudes. The tag attribution is retracted with the other two. The one reading the hour does not explain is the adjacent pair from the first evening: `main` 0 · 0 and the pre-fix branch 3 · 3 within ten minutes of each other. It is the strongest thing in the dataset and it is one pair.

## 2. What ships, and why

The font and the tag are Corey's rulings, both are static (a loaded face and a span with fixed text), and neither has a mechanism by which it can produce a hydration mismatch. The evidence that either *amplifies* a pre-existing one is now hour-confounded in both directions — the font's 0 in 3 came from the same quiet window as `main`'s 0 in 3, and the tag's 16 in 13 came from the windows `main` itself fires in. Holding either on that evidence would be superstition wearing a gate's clothes. **The font, the tag at the placement Corey ruled, and the `WelcomeClock` shape fix ship in 697.** The fix is described as the instrument change it is and nothing more.

**The clock's masthead mount is held**, for two reasons that survive the hour: the adjacent pair above is the only same-window comparison in the set, and it is the one change with a real timing story — a client island in every masthead issuing a state update within a second of mount, while other boundaries may still be hydrating. That is a hypothesis, stated as one, and it is exactly what HO 698's instrument is for. Preserved at `ho697-prefix-clock` and `ho697-clock`, pushed.

Corey's words, if he wants them: **"ship the clock too"** (his feature, the risk stated: an unknown rate change on the daily prod crawl, mechanism unfound) or **"hold the tag too"** (consistency with the clock at the price of his ruling). Absent a word, the paragraph above ships.

## 3. The §6 leg is withdrawn, and replaced with one that can be valid

*Three crawls on the tip reading 0 · 0 · 0* was a gate I wrote before `main` was known to fire 3 in 4; against a moving baseline it can fail for reasons that have nothing to do with the change, which makes its zero meaningless in the other direction too. Own it in the block. **Replacement, qualitative:** three crawls on the rebuilt tip **interleaved** with three on `main` at the same hour, start times recorded. Counts are recorded, not gated. What is gated is **class**: every fire on either tree reads at the announcer floor with `removedFromSsr []`, and no dump on the tip names a tag or font node in `addedInDom` or `removedFromSsr`. A fire that breaks either is a new class and blocks. That is a gate that can fail and means something when it does not.

## 4. The instrument that can attribute: HO 698

Two candidates, cheapest first, with the two clock trees and `main` at a firing hour as test cases.

- **A development-mode crawl.** Production React strips the mismatch detail (HO 687's channel A: *one property read, never taken in 42+ fires; minified*). Development React prints the server and client text that disagreed. If a fire reproduces at any rate against `next dev`, one fire names the node. Four crawls is the whole experiment.
- **The fire-time snapshot** the `:50` entry already names as its successor: a DOM read inside the `pageerror` handler, before settle, so `addedInDom` stops being a superset. Built only if dev mode gives nothing.

The question 698 answers is *which node*, not *which change*. Once the node is known, whether the tag, the font or the clock touches its timing is a reading, not a vote.

## 5. The post-ship instrument, named honestly

The daily prod crawl's fire rate, seven days after FF against the dumps that exist since HO 687 landed on 09-03 — three days, so the before-sample is thin and the block says so. A jump is a reason to reopen the tag and the font in 698 alongside the clock; no jump is not a clearance, it is a week without one.

## 6. Docs

Block: the harness defect and its control, the hour finding with the four start times, the arithmetic in §1, all three retractions in their own words and what each missed, the withdrawn count gate, the class gate, what shipped and what was held with the tags named, Corey's standing words. `backlog:50`: annotate with the hour finding (the rate itself moves within a day, which no entry has said), the adjacent pair, the two tags, and 698's two candidates. `backlog:135`: tag half struck with provenance, clock half live with the pair and the pointer. `backlog:137` struck. Oddities: one entry — *a fire counter on an intermittent with a moving base rate is not an attribution instrument*, three attributions and one gate in one HO, the tag control that caught the fourth; filed as method, not as a defect in any change. SKILL says what shipped.

## 7. State to reach

Rebuilt ref: tag (`b1039e3`) · fix (`29bd1a6`) · font · probes (matrix runner included, with the port-kill fix) · SKILL alone · docs. Tags pushed. §3's class gate run and quoted. Then `697-review`, `git ls-remote --heads --tags`, and the read.

read and follow 697 — A′ ruled, stop counting, ship the static two
