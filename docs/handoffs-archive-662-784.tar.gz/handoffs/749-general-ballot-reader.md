# HO 749: the ballot reader. Store every 2026 race's November ballot from Ballotpedia's general box, paced under the wall, and change nothing that renders

`docs/backlog.md` OPEN LOOPS, *The challenger harvest publishes a primary result as a general-election roster, and the two diverge whenever an advancer or nominee leaves the ballot after the primary (HO 741)*, owner Code, high. Its close is a general-box reader whose rows the harvest yields to. HO 747 probed the box (`docs/probes/747-general-box-findings.md`) and found the field wrong both ways: 40 published names off the ballot, 36 of them runoff losers, and about 60 major-party candidates on it unpublished.

This HO is the wire's first half: the reader and its table, on a clock. **Nothing reads the table yet.** The harvest keeps publishing exactly what it publishes today, and no page changes. Making the harvest yield to the ballot, the identity-based incumbent exclusion that comes with it, and the race page's *"Incumbent running for re-election"* sentence are the next HO, once this table has a full pass behind it. Splitting it this way means the reader's egress, pacing and write semantics get read in prod while a bad reading still costs nothing.

**Out of scope:** the harvest, any render code, curated rosters, third parties' publication (Corey's call), the ingest's surname matcher, and results. After 2026-11-03 the same box marks winners; this HO doesn't store the mark, because what a decided race shows is *What a race page shows once its race is decided is unruled…* (HO 747), which is Corey's.

## Ground truth (read at `f970542`; re-derive every `:N` by content)

- The parser to promote is the census's `readPageModel` (`scripts/diagnostic/general-box-census-747.ts:316`) with its helpers (`:85-315`). On 470 pages it found exactly one 2026 general box on 463, none on 7 (LA-01 to LA-06, whose only 2026 box is the Nov-3 primary, and FL-10, whose general was canceled), and two or more on none. Its kept-primary rows equal `parseCandidatesPage`'s own output on all 470. The general boxes: `General election` with class `nonpartisan` (451) or bare (10), and `Special general election` (2). Rows: 1,341 over 463 boxes, 82 write-ins, 0 without a person link; 181 boxes carry a *Withdrawn or disqualified candidates* block, 289 names. Party routes: wrapper 1,134, neither 146, `(X)` suffix 61, and New York and Oregon fusion lines read `I` by the ingest's letter.
- Its fetch is `readRacePage` (`:617`) with an injectable `IO` (`:494`), which is how the census and its controls ran on stubs and saved pages.
- URL builders `houseDistrictUrl`, `senatePageUrl` and `senateSpecialPageUrl` are exported from `lib/primary-candidates-scrape.ts` (`:127`, `:106`, `:110`). `USER_AGENT` (`:42`) and `openContestParty` (`:151`) are not.
- The wall, measured at HO 747: a 2,023-byte JavaScript challenge served as a 202. At one request a second from the box it arrived at request #43, and a retry 2.5s later got the same 202 in about 10ms. At six seconds start to start with one attempt, 387 of 387 pages read with no refusal. Vercel's egress to Ballotpedia is proven by `/api/cron/primaries`, but not at this cadence. HO 228's FRED lesson is that a laptop reading doesn't stand in for the deployed path.
- Identity: `member_ids.ballotpedia_title` (`scripts/migrate.ts:590`, filled by `scripts/sync-crosswalk.ts:121`) is a page title, and the census's `titleKey` (`:150`) turns it into the same key as a ballot row's href. The census matched 325 stored incumbents that way; 31 titles don't match any href (stale titles) and 13 incumbents carry none.
- The closest precedent for a per-item, fetch-heavy cron is `/api/cron/bill-rosters`: a `lib` module that is read-only by default, a CLI and the cron as its two callers, `maxDuration = 300` with a 240s budget and `softTimeoutMs: 290_000` (`app/api/cron/bill-rosters/route.ts`), and a per-item state table stamped last and only then (`bill_roster_state`, `scripts/migrate.ts:1164`).
- `lib/cron-health.ts:53-84` watches 17 route keys across 18 `vercel.json` crons, and its count comment has drifted before (HO 676, HO 737).

## STEP 0

1. HO number from the tree. This file assumes `main` at `f970542` (HO 748 landed), so this is 749. If the tree says otherwise, stop and say so.
2. Re-read every cited `:N` by content. Flag a drift; don't absorb it.
3. Confirm HO 747's saved pages and per-race JSON are still under `docs/handoffs/747-artifacts/`. Leg 1 needs them. If they're gone, stop and say so rather than refetch 470 pages.
4. Paste HO 748's post-FF reading if it's in (the FL-20 tick at 2026-09-26 12:30Z); it goes into this HO's roadmap block. If it isn't in yet, say where it's held.
5. Compute this HO's cron times with `date -u` from the schedule below: the first tick after the FF, and the tick by which a full pass should be done.
6. Proceed without a halt unless something above contradicts this file.

## The build

1. Tables (`scripts/migrate.ts`, the house pattern, with the reasons in comments beside them):
   - `general_ballot`: one row per person in a race's 2026 general box, keyed `(race_id, person_key)`, where `person_key` is the census's href key. Columns: `name` as printed, `printed_party` as printed (fusion lines whole), `party` as a letter (the printed party's first, else `openContestParty`'s precedence), `incumbent_marked` (`<u>`), `write_in`, `withdrawn` (listed in the box's withdrawn block rather than on the ballot), `primary_marked` (the same `person_key` marked winner in a kept primary box on the page), `bioguide_id` (by identity only: `person_key` equals a member's `titleKey(ballotpedia_title)`, else NULL; never by name), `box_prefix`, and `read_at`.
   - `general_ballot_reads`: one row per race. It keeps the last READ apart from the last attempt, so an UNREAD can't pass for a read: `status` (`box`, `no_box` or `ambiguous`, from the last READ), `read_at`, `rows`, `marked` (a count of rows carrying a winner mark, which reads 0 until the election), `source_url` (the URL actually read), `last_attempt_at` and `last_attempt` (`READ`, `UNREAD` or `NO_PAGE`). Stamp it last.
2. `lib/general-ballot.ts`: the census's `readPageModel` and helpers, promoted as they ran rather than rewritten. Shared helpers are exported from where they live (`USER_AGENT` and `openContestParty` from the scrape module), not copied. `readRacePage` keeps its injectable `IO`. A page with two or more general boxes in the section is `ambiguous`: store nothing for it and record the verdict. Never pick one.
3. Writes, one race at a time, in one `db.batch` transaction. On `READ` with a box: delete the race's `general_ballot` rows, insert the new set, stamp `general_ballot_reads`. On `READ` with no box or an ambiguous page: delete the rows and stamp the verdict. On `UNREAD` or `NO_PAGE`: touch only `last_attempt_at` and `last_attempt`. The rows and the last READ stay as they were.
4. The run, one function with two callers, read-only unless the caller passes write mode (the bill-rosters rule):
   - Selection: every 2026 `races` row, least-recently-attempted first (never-attempted first of all), `race_id` breaking ties. No cursor: the reads table is the queue.
   - Pacing: one request in flight, at least 6s start to start between any two requests (a Senate fallback is a second request and waits its turn), and one attempt per race per run. The first `UNREAD` ends the run: it's stamped and goes to the back of the queue, and nothing after it is attempted.
   - Bounds: a budget and a cap, whichever comes first.
5. The cron: `/api/cron/general-ballot` at `20 */2 * * *`, `maxDuration = 300`, a 240s budget, a cap of 40 races, `softTimeoutMs: 290_000`, Bearer `CRON_SECRET`, and `wrapCronRoute`. Twelve ticks a day at 40 races each is 480, so one full pass a day, about 470 requests a day, clear of the primaries ticks at :00. The payload carries `attempted`, the verdict counts, `rowsWritten`, the stop reason (`unread`, `budget`, `cap` or `queue`), and the smallest measured gap between request starts. Any `UNREAD` goes into `chronicErr`. No cache tag is expired, because nothing reads the table.
6. The CLI: `npm run sync:general-ballot`, dry by default, `--write` to write, `--race <id>` for one race, and `--all` to run the whole queue without the cron's budget, at the same 6s pacing with HO 747's stop rule (five UNREAD in a row, a 15-minute pause once, then stop).
7. Registration: `vercel.json` (the cron and its `maxDuration`), and `lib/cron-health.ts` at `maxStaleMs: 5 * HOUR` (two cadences and an hour), with the count comment corrected in the same edit.

## Legs, seen red before green where there's a red

1. Parser equivalence, on HO 747's 470 saved pages: the lib's verdict and rows against the census's per-race JSON, field by field. Expected: identical on every page. Any difference is a stop, not a note.
2. Parser controls, on `AK-AL-2026`'s saved page and stubs: the general box deleted gives `no_box`; its `<h5>` renamed gives `no_box`, with the prefix recorded; a second general box pasted in gives `ambiguous`; a 202 stub gives `UNREAD`; a 404 gives `NO_PAGE`.
3. Writes, on a `file:` copy seeded the HO 746 way (only the tables touched, the URL built as `file:${abs}` by construction, perturbations refusing any other scheme): a READ writes rows and stamps the race; a changed ballot replaces them; a no-box READ clears them; an UNREAD leaves rows, `status` and `read_at` untouched. The atomicity control: force the insert to throw after the delete, and the race's old rows are still there.
4. The run, on the copy, with a fetch shim serving saved pages (HO 744's shim precedent): never-attempted races go first, then the oldest attempts; a shim that returns a 202 on its fifth request ends the run right there, with that race stamped UNREAD and nothing after it attempted; the cap and the budget each stop a run inside the soft timeout with a `success` row. Measure the 6s spacing in real time on at least one short run; the rest may inject a clock.
5. Identity, from the saved pages: FL-20's Wasserman Schultz carries `W000797` and S-AK's senator `S001198`, while S-AK's second Dan Sullivan, the namesake, carries NULL.

## The prod reading

- Egress, before the FF if possible. One POST to the review ref's Preview deployment of `/api/cron/general-ballot`, if Code can reach it with the protection bypass it already uses. Preview shares prod's database, and this writes only the new tables, which nothing reads. Paste the payload: verdict counts, stop reason, smallest gap. If Preview can't be reached, say so, and the first Production tick after the FF is the egress reading instead.
- After the FF: the first two Production ticks' `cron_runs` rows, with any `UNREAD` named. More than one UNREAD in a tick is a stop: report before anything else.
- The full pass. File a WATCH at the head of OPEN LOOPS, dated by the tick computed at STEP 0: every 2026 race carries a READ verdict, compared against HO 747's census as box and no-box counts, rows per race, and every difference named (a real ballot change since 2026-09-25, or a parser difference, which is a stop). The next HO's STEP 0 requires this WATCH read.

## Commits and docs

- `feat(HO 749)`: the tables, `lib/general-ballot.ts`, the exports, the cron, the CLI, and the registrations. Run the migration against prod as the house does, and paste its output.
- `diag(HO 749)`: the legs driver and shim.
- `docs(skill)`, its own commit, approval requested in the paste-back: the External data sources Ballotpedia entry gains the general box (HO 747 probe, HO 749 reader, the pointer to the findings file, the wall's measured pacing); the cron list gains `/api/cron/general-ballot`; and the tables are described where SKILL describes tables.
- `docs(HO 749)`: annotate the HO 741 harvest line (the reader has landed, and the yield is next); file the full-pass WATCH; file one low line for the two page parsers (the promoted one and `parseCandidatesPage` slice the same section separately; HO 747 measured them agreeing on 470 pages, and nothing keeps them agreeing); the roadmap block with HO 748's post-FF reading, pointer 748 → 749. Reconcile OPEN LOOPS at open and close, control `^- \*\*~~` at 0 both times.
- Review ref `749-review`. The FF is held for the SKILL approval and review.

## Gates

The cheap gates: `npm run typecheck`, `npm run check:odds-sites` and `npm run check:design-citations`. No render code changes, so no captures.

## Paste back

- STEP 0's readings;
- the five legs, with their reds;
- the migration's output;
- the egress reading (Preview, or why not);
- the SKILL diff, for approval;
- `git show --stat` per commit, and `--numstat` for the docs commits (the deletions column, not a grep);
- the reconcile;
- the review ref's SHA from `git ls-remote`;
- a last cheap-gate run immediately before the paste, with the reading named.
