# HO 747: what is on the November ballot? A read-only census of Ballotpedia's 2026 general boxes against the rosters we publish

`docs/backlog.md` OPEN LOOPS, *The challenger harvest publishes a primary result as a general-election roster, and the two diverge whenever an advancer or nominee leaves the ballot after the primary (HO 741)*, owner Code, gated on the general-box reader. It was measured once, at `AK-AL-2026`, where the roster the harvest would have published was wrong on two of four names. Everywhere else, the rows we publish as the November field have been checked against the November ballot at no race at all.

It goes ahead of *The committees cron's bills cursor moves past a bill whose fetch or write failed…* (HO 744) on Corey's word, 2026-09-25, verbatim: *"lest do that and keep order"*, replying to the architect's proposal to take the general-box probe next because it's the one with a date on it. The date is the general election, Tuesday 2026-11-03 (`date -u -d 2026-11-03 +%A`). Until then the general box lists the ballot. From that night it marks the winners.

This HO also reads the five seats in *WATCH (HO 743) · five seats carry an incumbent whose party is the opposite of the rater's own call*: CA-01, MO-05, TN-09, TX-09 and TX-32. That line's hypothesis is that the raters score the new mid-decade districts while `races` still carries the old incumbent. The census reads every district page anyway, so it can test the class, not only the five.

**This HO measures. It builds nothing.** No product code, no schema, no write to prod, no POST to any cron route. What the reader looks like, and whether the harvest yields to it everywhere or only where the two disagree, gets decided on this HO's numbers.

## Ground truth (read at `0122971`; re-derive every `:N` by content)

- `lib/primary-candidates-scrape.ts`
  - URL builders: `senatePageUrl` `:106`, `senateSpecialPageUrl` `:110`, `houseDistrictUrl` `:127` (district `0` is `At-large`). The sync builds the slug as `stateName(abbr).replace(/ /g, "_")` (`lib/primaries-sync.ts:905`, `:1255`) and paces about one request a second (`:1257`).
  - `USER_AGENT` `:42`. Ballotpedia answers a bare user agent with a 202 challenge page (the 741 diagnostic's header, `scripts/diagnostic/ak-general-box-741.ts:37-39`).
  - `parseCandidatesPage` `:285` slices the section from the `Candidates_and_election_results` anchor to the next `<h2` (`:300-301`), splits it on `race_header` divs (`:303`), and keeps a box only if its `<h5>` says `primary` and not `runoff` (`:361`). The comment above that line says it drops the general-election boxes on purpose (`:338-339`).
  - `parseVotebox` `:161`: the name is the anchor text of the row's `https://ballotpedia.org/` link (`:173`), and the href is discarded. Incumbents are `<u>`-wrapped (`:211`), and a marked row carries the `winner` class (`:212`).
  - `scrapeHouseCandidates` `:506` reads the dev cache `.cache/ballotpedia` first unless `bypassCache` is set (`:510`, `:518`; the comment at `:514-517` says the cached pages predate the primaries). It tries three times at 2.5s (`:495-496`), doesn't retry a 404 (`:556`), and retries a 2xx page that lacks the anchor. `scrapeSenateCandidates` `:414` falls back to the special-election URL on a non-ok response and never reads the cache.
- `scripts/diagnostic/ak-general-box-741.ts` is this probe's ancestor, and its selector won't survive November. It slices from the anchor to the end of the page (`:62`), which takes in the historical boxes under District history, and it tells the 2026 general box apart by `winners === 0` (`:110`). After the election the 2026 box carries a marked row too. Its header also says "HO 743 is that reader" (`:25`), and 743 went to other work.
- `lib/harvest-challengers.ts`
  - `HARVEST_FROM_WHERE` `:76-88`: `races` joins `primaries` by state, chamber and (House) `CAST(p.district AS INTEGER)`, never by `primaries.race_id`. Winners only, the seat's incumbent excluded by bioguide, and any race with a curated row skipped.
  - The INSERT `:158-167` writes `advanced` for `top_four` and `top_two` and `won_primary` otherwise, with the sentinel `source_url = 'harvest:primary_winner'` (`:54`).
  - It runs as `/api/cron/race-challengers` at `30 12 * * *` (`vercel.json:82-83`), as a DELETE then an INSERT, so a read during that tick can see a half-empty table.
- Schema (`scripts/migrate.ts`)
  - `races` `:140`, with `incumbent_running` added at `:1634`. At-large is `district = 0` (`lib/race-id.ts:43`).
  - `race_candidates` `:158`: `PRIMARY KEY (race_id, name)`, and no person URL.
  - `primaries` `:454` and `primary_candidates` `:466`: no person URL either.
  - `member_ids.ballotpedia_title` `:590`, filled from congress-legislators' `id.ballotpedia` (`scripts/sync-crosswalk.ts:121`). That's a Ballotpedia page title per member, so a stored incumbent can be matched to a ballot row by identity rather than by name.
- What a race page renders is `getRaceCandidates` (`lib/queries.ts:1910`): every `race_candidates` row for the race, with `won_primary`, `nominee` and `advanced` ranked first. Curated rows carry a real page URL in `source_url`; `AK-AL-2026` was seeded from its general box at HO 741.
- Estimates, which STEP 0 replaces: about 470 `races` rows for 2026 (HO 741's reading, 2026-09-20). At HO 741, 60 `top_two` rows over 52 races and 5 `top_four` rows over 2 races published `advanced`, and 218 rows published `won_primary`.

## STEP 0

1. HO number from the tree: `max(roadmap pointer, highest HO in commit subjects) + 1` (method.md § Handoff discipline). At `0122971` both read 746, so this is 747. If the tree says otherwise, the tree wins and the filenames follow it.
2. Re-read every cited `:N` at HEAD by content. A drift is flagged, not absorbed.
3. Measure and print, from prod, SELECTs only:
   - 2026 `races` rows by chamber;
   - `race_candidates` rows for 2026 by source (sentinel against curated) and by status, and the list of curated races;
   - stored incumbents with and without a `member_ids.ballotpedia_title`;
   - the falsification set: `S-AK-2026`, `AK-AL-2026`, and the rated California House races carrying harvested `advanced` rows. There were eleven at HO 741, and the index has moved twice since, so derive the set now:
     ```sql
     SELECT DISTINCT r.id FROM races r
     JOIN race_candidates rc ON rc.race_id = r.id
     WHERE r.cycle = 2026 AND r.chamber = 'house' AND r.state = 'CA'
       AND rc.status = 'advanced' AND rc.source_url = 'harvest:primary_winner'
       AND EXISTS (SELECT 1 FROM race_ratings rr WHERE rr.race_id = r.id AND rr.cycle = 2026)
     ```
   - the newest `cron_runs` rows for `/api/cron/race-challengers` and `/api/cron/primaries`.
4. Fetch `AK-AL-2026`'s page once and print the section's boxes as this HO's selector reads them: each `<h5>`, its `race_header` class modifier, its row count, its marked count, and whether a withdrawn-or-disqualified block follows its table. Beside it, print the 741 diagnostic's selector (`voteboxes()` and `is2026General`, `:59-79` and `:110`) run over the same saved bytes. If the two disagree about which box is the 2026 general, or the general box isn't inside the section, halt with both readings.
5. Otherwise proceed without a halt. The probe is read-only and its scope is fixed.

## The instrument: `scripts/diagnostic/general-box-census-747.ts`

Read-only against prod: SELECTs and Ballotpedia GETs. It imports the scraper's URL builders and `stateName`, so the URL it reads is the pipeline's URL. `USER_AGENT` and `openContestParty` aren't exported, so it copies them and cites their lines, as the 741 diagnostic copies the user agent (`:40-41`). It doesn't call `scrapeHouseCandidates`, whose cache would hand it May's pages, and it never reads or writes `.cache/ballotpedia`.

1. Snapshot the database first: every 2026 `races` row with its incumbent and `incumbent_running`; the rows `getRaceCandidates` would return for each race; and the stored incumbents' names and `ballotpedia_title`.
2. Fetch every 2026 race's page serially, one request in flight and at least a second between requests (the sync's pace). The falsification set goes first, and the controls below run on its saved pages before the rest of the census is fetched. Use the scraper's `USER_AGENT`, an 8s cap per attempt, up to three attempts at 2.5s, and no retry on a 404. For a Senate race, fall back to `senateSpecialPageUrl` on a non-ok response, as `scrapeSenateCandidates` does.
   - Each page ends in exactly one verdict. `READ` is a 2xx carrying the anchor. `NO_PAGE` is a 404, or no page after the Senate fallback. `UNREAD` is a 2xx without the anchor after three attempts, or a timeout. An `UNREAD` page is never classified as having no general box.
   - If five pages in a row come back `UNREAD`, pause 60s once. If the next one is `UNREAD` too, stop and report a partial census with the stop point. Don't raise the rate to finish.
   - Save every page, gzipped, under `docs/handoffs/747-artifacts/pages/`, and log every request (URL, status, bytes, elapsed, attempt) to `requests.log` beside it.
3. Select boxes the way the shipped parser does: the section from the anchor to the next `<h2`, split on `race_header` divs. Record each box's `<h5>` prefix (the text before ` for `, such as `General election`, `Special general election` or `Democratic primary`) and its class modifier. The 2026 general box is a box inside the section whose `<h5>` says `general election` and says neither `primary` nor `runoff`. Also count the general boxes on the page outside the section, so the reading shows what a page-wide selector would have taken.
4. Parse each general box's rows: the anchor text and the href of the person link; the party token and the route that produced it (the thumbnail-wrapper word, the `(X)` suffix after the link, or neither), mapped with `openContestParty`'s precedence (`:151`); `<u>`; the `winner` class; rows without a person link; and any write-in marker, recorded as its raw text. Parse the names and hrefs in a withdrawn-or-disqualified block after the table. Parse the page's 2026 primary boxes (the ones `parseCandidatesPage` keeps) the same way, hrefs included, so identity across the two boxes is by href.
5. Compare the ballot with the published roster, race by race.
   - The ballot, less the stored incumbent, is set against the published rows. Match a published row to a ballot row by href first, through the primary box: the published name equals a primary-box row's anchor text on this page, and that row's href is on the ballot. Fall back to normalized name (NFKD, diacritics folded, case and punctuation dropped). Record which route matched every pair.
   - Classes per candidate: `agree`; `published-not-on-ballot`, split into `withdrawn-listed` and `absent`; `on-ballot-not-published`, split into `marked-in-primary`, `unmarked-in-primary` (a replacement, McDermott's shape) and `in-no-primary-box` (never ran in a primary on this page); and `withdrew-but-on-ballot` for a published `withdrew` row. Break the counts down by roster source (harvested, curated, none) and by the status we publish.
   - List any underlined ballot row that isn't the stored incumbent as `underlined-not-stored-incumbent`.
6. Incumbents. Match each race's stored incumbent to the ballots by identity: `https://ballotpedia.org/` plus the `ballotpedia_title` with spaces as underscores, compared after percent-decoding both sides. If identity finds nothing in the state, try the name route (surname and first initial) against every general-box row in the state, and record the route.
   - Buckets: `on-own-ballot`, `on-other-ballot` (name the district), `on-no-ballot` (split by `incumbent_running`: 0, 1, NULL) and `no-title`.
   - A title that fails identity but passes the name route is `title-mismatch`, not `on-no-ballot`.
7. For each of the five seats, print the general box as read, the stored incumbent and its bucket, and the page's own sentences mentioning `redistrict` and the incumbent's surname, each quoted to at most 200 characters.

Run the prod reading outside the `/api/cron/race-challengers` tick (12:30 UTC) and the `/api/cron/primaries` ticks (00:00 and 12:00 UTC). Read those routes' newest `cron_runs` rows before the snapshot and after the last fetch. If either changed, re-snapshot and re-classify from the saved pages without refetching, and report both readings.

## Controls, seen red before the prod reading

C1 runs on `AK-AL-2026`'s saved page, never on a new fetch, and C2 on stub responses. C3 and C4 run on a `file:` copy seeded from prod the way HO 745's control seeded its copy: only the tables the probe reads, the URL built as `file:${abs}` by construction, and a perturbation step that refuses any URL that isn't `file:` and prints the scheme it ran against. They classify from saved pages. Read each control twice, unperturbed and perturbed. The delta is the reading.

1. C1, the selector. Delete the 2026 general box from a copy of the page. Expected: `no-general-box`, with the outside-section general count unchanged and above zero. On a second copy, rename that box's `<h5>`. Expected: `no-general-box`, with the unrecognized prefix listed in the markup census.
2. C2, the verdict. Feed the page-verdict function a 202 whose body lacks the anchor, and a 404. Expected: `UNREAD` and `NO_PAGE`, neither of them `no-general-box`.
3. C3, the comparison in both directions. On the copy, for one falsification-set race, delete one published nominated row whose person is on the ballot, and insert `ZZ Control Candidate` with status `won_primary` and the sentinel source. Expected on that race: `on-ballot-not-published` +1, `published-not-on-ballot` +1, and nothing else moves.
4. C4, the incumbent. Take two California races from the falsification set whose incumbents both read `on-own-ballot` unperturbed, and name the pair. On the copy, point the first race's `incumbent_bioguide_id` at the second race's incumbent. Expected: the first race moves to `on-other-ballot`, naming the second race's district, and its own underlined row appears as `underlined-not-stored-incumbent`. If the set holds no such pair, say so and fetch two more California districts for it before the census continues.

If any control misses, the instrument is wrong. Stop.

## The prod reading

Name the `cron_runs` rows it follows. The findings go to `docs/probes/747-general-box-findings.md` in the HO 715 shape (base SHA, run window and request budget at the top), with no recommendation in it:

1. Read census: pages attempted, `READ`, `UNREAD` by cause, `NO_PAGE`, Senate fallbacks used, special-election pages, requests, retries, bytes and elapsed.
2. Markup census: `<h5>` prefixes and class modifiers inside the section, with counts; pages with 0, 1 and 2+ 2026 general boxes; pages where a page-wide selector would have taken extra boxes; party-token routes; write-in markers seen; withdrawn blocks; and marked rows in any 2026 general box (expected 0 before the election; list any nonzero with its page).
3. Divergence by class, by roster source and by published status, with every non-`agree` candidate listed in the artifact.
4. Identity: people in both boxes on one page with the same href and different anchor text, every pair listed; and the match route for every published row.
5. Ballot size: candidates per 2026 general box (min, median, max), and the share that are neither D nor R.
6. Incumbents: `ballotpedia_title` coverage, and the buckets per chamber, plus per state for any state with `on-other-ballot` or `underlined-not-stored-incumbent`.
7. The five seats, in full.
8. The falsification set, in full, including `AK-AL-2026`'s seed set against today's ballot.

Per-race JSON and CSV go to `docs/handoffs/747-artifacts/` (repo-ignored) beside the pages.

## What follows the reading (review calls, not Code's)

- The reader's shape is the architect's call, on these numbers: a table of its own or rows in `race_candidates`, the join key, and whether the harvest yields to the ballot everywhere or only where they diverge. Its date is the same 2026-11-03.
- What a ballot-sourced roster renders (every ballot-qualified candidate, or a subset) is Corey's product call, priced by table 5.
- The five-seat WATCH is confirmed as a class and filed as its own line, or ruled a coincidence, on table 6.
- What the box says after the polls close is outside this HO. The census reads the pre-election state and says so.

## Commits and docs

- `diag(HO 747)`: the script.
- `chore(HO 747)`: `scripts/diagnostic/ak-general-box-741.ts:25` names the reader by its subject and points at this HO's probe, in place of "HO 743 is that reader". Comment only.
- `docs(HO 747)`:
  - `docs/probes/747-general-box-findings.md`, new;
  - annotate *The challenger harvest publishes a primary result…* (HO 741) in place with the reading and a pointer to the findings file. It stays open, because its close is the reader;
  - annotate *WATCH (HO 743) · five seats carry an incumbent…* in place with its readings and table 6. It stays open for the review call;
  - annotate *The kalshi cron's comment says a failed chamber-control read leaves the prior blob in place…* (HO 744) with its ruling, text below. No code changes for it in this HO;
  - file the election-night line, text below, at the head of OPEN LOOPS;
  - the roadmap block, pointer 746 → 747.
- No SKILL change. Nothing is wired, and the External data sources pointer lands with the reader it would describe.
- If the reading finds something outside these lines' mechanisms, flag it in the paste-back before filing anything. The likeliest is *`primary_candidates` carries the AK Senate incumbent twice, under two spellings…* (HO 736), which table 4 may explain.
- Reconcile OPEN LOOPS at open and close. At `0122971` it reads 253 live / 297 struck / 550, with the control `^- \*\*~~` at 0. The expected close is 254 / 297 / 551, and backlog `--numstat` 4+/3−: three lines annotated in place and one filed. Explain every deletion.
- Review ref `747-review`. The FF is held for review.

The kalshi annotation, to land verbatim after STEP 0 reads its clauses against the tree:

> **RULED 2026-09-25: branch (1), the comment changes and the code doesn't.** Corey, verbatim, in the CBT maintenance chat: *"lest do that and keep order"*, replying to the architect's recommendation, which he quoted: *"rule (1) and fix the comment. SKILL:1879 and the HO 219 helper comment already describe the null, so the route comment is the lone outlier."* The `LIVE`-pill conditional offered in the same message (`components/RacesHeroBand.tsx:60` renders the pill whether or not the House cell has a price) was not in the quoted text and is not ruled. *Owner:* Code, with no ruling outstanding. The edit rides with *The kalshi and committees cron route headers describe triggers…* (HO 744), which already covers `app/api/cron/kalshi/route.ts`. The close is unchanged: (1), checked by reading.

The election-night line, on the same condition:

> **What a race page shows once its race is decided is unruled, and the general election is 2026-11-03 (raised 2026-09-25, HO 747).** opened 2026-09-25; *Owner:* **Corey**, a product call, then Code. No product code reads a 2026 result. Outside `scripts/diagnostic/`, the only reader of a Ballotpedia general-election box is `scripts/backfill-2024-margin.ts`, and it reads 2024 (`git grep` at `0122971`). The date is handled and the outcome isn't. `/race/*` reads *Election concluded* once `daysToElection` goes negative (`components/RaceHeader.tsx:32-38`, via `RaceHubBody`; `lib/format.ts:139`). The dashboard's battlefield band hardcodes the day and clamps at zero (`components/Battlefield.tsx:19-21`), so from 2026-11-03 it reads `0 DAYS` for as long as it renders. HO 747 reads the general box before the election, when it lists the ballot. After the election the same box marks the winners, so a reader built on it could read results too. That's a new consumer and a scope decision, not a side effect of the ballot reader. *Close:* Corey's word on what a decided race renders (its result, a decided state without one, or nothing new), and the handoff that follows if a build does. *Reads if never done:* on 2026-11-04 a decided race's page carries no result anywhere on it, under *Election concluded*, while the dashboard reads `ELECTION DAY · NOV 3 · 0 DAYS`.

## Gates

Run the cheap gates: `npm run typecheck` (both programs), `npm run check:odds-sites` and `npm run check:design-citations`. No served bytes change, so no captures and no Preview reading are owed. If CI runs one anyway, report it as it comes.

## Paste back

- STEP 0's readings, including the `AK-AL-2026` selector check beside the 741 diagnostic;
- the four controls, unperturbed and perturbed;
- the eight tables, and the `cron_runs` rows read before and after;
- `git show --stat` per commit, and `--numstat` for the docs commit (the deletions column, not a grep);
- the review ref's SHA from `git ls-remote`;
- a last cheap-gate run immediately before the paste, with the reading named.
