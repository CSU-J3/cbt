# HO 696 — review reply 2. One clause holds the slot; everything else is approved as read.

Read on the ref: `696-review` at `506ad98`, seven commits in the §2 order, every touched blob LF. The SKILL diff was read in full off `560b865`. ORPHAN and its registry exemption are right, and the reasoning at the skip is the correct one (a class that cannot fire is not a class; the exit asked for is what caught it). The five exits, the fresh-clone `OK`, the green run on the new tip, the `BuildFailed` attribution as a WATCH with its discriminator, the 244, the `.gitignore` figures, the README restatements, the method widening and the `:45` annotation are all approved. The per-commit gate check on `922b91d` / `33767e3` / `506ad98` is exactly the proof §2 wanted.

## 1. The slot does not close yet: one provenance clause is false against the tracked archive

SKILL `:1946` now reads *"not the name HO 591 assigned it"*, and the companion *"landed at HO 604 C0 under its own downloaded name"*. The same two claims sit in `layout-conventions-arc.md:31`, the roadmap block, the oddities entry (twice), the allowlist note and the `:110` strike. The tracked archive says otherwise, and it is more interesting than either version:

- **`604-type-scale.md:62–63`** (in `docs/handoffs-archive-362-661.tar.gz`) specifies both files by their `mock-591-*` names and assigns the renames: `mock-591-dashboard-layout.html → docs/design/dashboard-layout-target.html` and `mock-591-conventions.html → docs/design/layout-conventions-c1-c8.html`. **`:64` states the policy:** *"Descriptive names, no HO number — matching the seven files already in `docs/design/`."* So `layout-conventions-c1-c8.html` was the rename target the HO 604 handoff assigned, and `dashboard-layout-target.html` is a **deliberate rename**, not a download name. The rename is why the companion citation at `mock-591-conventions.html:166` dangles at all.
- **Timeline, read off the commits and the mtime you took:** C0 `c943e07` landed 2026-08-06 **01:42Z**; the dictionary's mtime is **02:30Z**, 48 minutes later; the HO 605 sweep commits landed **02:46–02:47Z**, and **`605-doc-sweep-603-604.md:17`** looked for the file *"in the project root"* and, not finding it there, recorded it as never landed while it sat in `docs/design/` sixteen minutes old. Not a filename guess, then, but a rename target searched for in the wrong directory, and every later reader searched by the target name.

**Replacement for the `:1946` clause, verbatim:** *It was on disk the whole time under the name it carried, not the rename target the HO 604 handoff assigned it (`604-type-scale.md:63`, tracked archive), and the HO 605 sweep looked for it in the project root (`605-doc-sweep-603-604.md:17`) sixteen minutes after it was saved to `docs/design/`.* And for the companion: *landed at HO 604 C0 renamed from `mock-591-dashboard-layout.html` (`604-type-scale.md:62`), under that handoff's stated policy of descriptive names without HO numbers (`:64`).* Same correction in the other six places; `historical-name`'s note says *renamed at 604 C0*, not *downloaded name*.

**One sentence the policy conflict owes,** in README rule 2 and the block: HO 604 C0 chose descriptive names without HO numbers on purpose (`604-type-scale.md:64`); rule 2 reverses that, because a renamed ruling record loses the citation trail its companion kept, which is the dangle this HO found. Stated so the reversal reads as ruled, not as an accident.

## 2. The twelve orphaned PIDs: pre-ruled, kill them

They are this repo's own diagnostics (`hydration-capture-687.ts` ×2 groups, `scratch/cap689b.ts` ×2, their `npm` parents), hung two days; "foreign PIDs left alone" is about other apps sharing the box, not these. Kill by PID, all twelve, command lines quoted before the kill and a `ps` read-back after (a process supposed to have stopped is verified stopped, HO 672). One sentence in the block records it; whether a tool reported them stopped on 09-03 is unrecorded and stays so unless the 687/689 pastes say. **Corey can say "leave" before the FF step and they stay.**

## 3. Then

Fixups into the owning commits, `--force-with-lease` on the ref, `git ls-remote`. Paste: the seven new SHAs, `git diff 560b865 <new SKILL commit> -- .claude/skills/cbt/SKILL.md` (it should be the one hunk), the gate `OK` on the new tip, the run id. The SKILL diff is read off the ref again; FF go follows in one line.

read and follow 696 — review reply 2, one clause and the PIDs
