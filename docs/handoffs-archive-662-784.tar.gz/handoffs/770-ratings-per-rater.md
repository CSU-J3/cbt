# HO 770: race ratings from each rater's own source. Inside Elections is wired from its export, Cook's and Sabato's rows hold at 09-30, and the MOVED guard reads each rater's own leg

Ballotpedia's widget now answers only a POST carrying a signed per-page token (HO 769 STEP 0), and replaying that token is ruled out. Wikipedia was the next candidate and doesn't hold up. I read it on 10-09:
- The House ratings table dates its Cook, IE and Sabato columns Aug. 25, Aug. 20 and Aug. 26.
- Against Cook's own page, dated Oct 9, 19 of 28 sampled Cook cells differ, including every House race in the 09-30 MOVED batch. Wherever the store holds something newer than August, reading the table would roll it back and log the rollback as a move.
- The Senate table is closer (dated Sep 17-23), but it's still behind Cook's Oct 6 page and IE's Oct 1 file.

So the ratings come from the raters, one reader each:
- **Inside Elections** publishes its ratings as a JSON export, linked from its own ratings pages under *Export → API*. Its `robots.txt` bars only `/wp-admin/`, and the site links no terms of use. This HO wires it for both chambers.
- **Cook** lets anyone read its pages without logging in, but its Terms & Conditions bar "any robot, spider, or other automatic device, process, or means to access the Website for any purpose". **No code in this HO fetches cookpolitical.com, not even a probe.** Cook's API (`/api/race/{house|senate}`, HTTP Basic with an account, at most one call a day) is by request. Getting access is Corey's step, and a later HO wires it.
- **Sabato's Crystal Ball** refused my fetcher, and its 2026 pages were script-rendered at HO 88. STEP 0 takes a census of possible sources (M4), and HO 771 rules on it.

Until Cook and Sabato are wired, their rows stand exactly as Ballotpedia last wrote them on 09-30. There are no upserts and no departures, and `rating_date` shows their age.

**How STEP 0 runs** (method.md, HO 768's rule):
- Claims 1-8 are mine and are a check.
- M1 and M2 carry one stated way through, and a HALT otherwise.
- M4 decides nothing in this HO, so it carries no HALT.

**Base:** `769-review`'s head. This HO stacks on it: `770-review` branches from there, and the FF takes both. HO number: the pointer is 769 and the highest HO in commit subjects is 769, so this is 770.

## Scope

In:
- the ratings transport: `lib/race-ratings-scrape.ts`, `lib/race-ratings-sync.ts` and the route's header;
- the MOVED guard's leg: `lib/move-freshness.ts` and `readRecentRaceMoves`;
- the diagnostics those need, the docs, the README's credits line and SKILL.

Out:
- Cook, entirely;
- wiring Sabato;
- the cron cadence;
- every UI file.

## STEP 0

| # | Claim | Fails if |
|---|---|---|
| 1 | On `769-review`, these files are byte-identical to `140aa77`: `lib/race-ratings-scrape.ts`, `lib/race-ratings-sync.ts`, `lib/move-freshness.ts`, `lib/electoral-general.ts` and `app/api/sync-race-ratings/route.ts` | 769 touched one |
| 2 | The scrape's Ballotpedia transport:<br>• `HOUSE_URL`/`SENATE_URL` (`:105-107`), `BALLOTPEDIA_URL` (`:112-115`), `OFFICE_TYPE` (`:119-122`), the browser `USER_AGENT` (`:125-126`)<br>• `SOURCE_MATCH`/`ID_HEADER` (`:135-146`), `NORMALIZE` (`:160-172`), `fetchHtml` (`:300-319`), `toHouseRaceId`/`toSenateRaceId` (`:355-391`)<br>• `discoverWidgetUrl` (`:431-447`), `captionAsOfDate` (`:450-472`), `parseRatingsTable` (`:480-610`)<br>• `scrapeRatings` and its two callers (`:620-634`), and the `BALLOTPEDIA_*` and `ballotpediaUrlFor` exports (`:636-641`)<br>Its tracked importers are the sync (`:54-60`) and `scripts/diagnostic/race-ratings-shape-742.ts` (`:53-59`: `discoverWidgetUrl`, `parseRatingsTable`, `captionAsOfDate`) | another importer |
| 3 | `runChamberLeg` takes one `source_url` per leg (`:150`) and writes a row only when its label changed (`:191-234`). `applyDepartures` (`:283-323`) deletes on a locked cell, only from a source in `sourcesPresent` and only where the pair exists | |
| 4 | `syncLegOk(run, chamber)` (`lib/move-freshness.ts:52`) reads `payload.chambers.<C>.ok` and `.stats.scraped`, or a pre-HO 744 House run's `payload.stats.scraped`. `isFreshMove` (`:73`) takes no rater. `readRecentRaceMoves` keys its verdicts `` `${date}|${chamber}` `` (`lib/electoral-general.ts:751`). Callers: that function and `scripts/diagnostic/electoral-legs-768.ts:43` | another caller |
| 5 | `wrapCronRoute`'s error path stores `{ok:false, elapsedMs, error, status}` and no handler payload (`lib/cron-log.ts:171-186`), so an `error` run carries no leg detail | |
| 6 | `https://insideelections.com/ratings/house` and `/senate` each carry an *Export* block. Its *API* link is `/wp-content/themes/inside-elections/cache/ratings_latest_{house\|senate}_year=2026_district=all_clean.json?v=<n>`; I read `v` as 1790881928 for the House and 1790878981 for the Senate. The page's own table is rendered from that file: the static HTML shows "Loading". `robots.txt` disallows only `/wp-admin/`, and the footer links no terms | IE has terms that bar automated access: HALT, quoting them |
| 7 | The House file is `{office:"House", total:435, last_updated:"2026-10-01T13:25:04-05:00", generated_at, ratings:[…]}`. Each record carries `district` (`"OH-15"`, `"IA-03"`, at-large `"WY-AL"`), `election_year` `"2026"`, `date`, `rating`, `rating_numeric`, `previous_rating`, `special` and `note`, among others. Solid seats are included. The vocabulary, with `rating_numeric`: Solid Democrat 0, Likely Democrat 1, Lean Democrat 2, Tilt Democrat 3, Toss-up 5, Tilt Republican 7, Lean Republican 8, Likely Republican 9, Solid Republican 10 | |
| 8 | The Senate file has `office:"Senate"` and 100 records, one per seat. The 65 seats not up read `"Not Up This Cycle"`, and each seat's class is in `office` (`I`/`II`/`III`). AK appears twice (class II rated, class III not up). FL and OH are rated once each, under class III, with `special` false. `last_updated` is `2026-10-01T13:23:00-05:00` | |

I read claims 6-8 through a text view. M1 measures them exactly.

**Measurements** (read-only):
- **M1, the files.**
  - Fetch each chamber the way § 1 will: the page, then the file it links.
  - For each, give the status, bytes, `last_updated`, the record count (for the Senate, the rated count too), the distinct `rating` strings with their counts and `rating_numeric`, the district forms, and any duplicates.
  - Save each page and file under `docs/handoffs/770-artifacts/`.
  - If the page or the file answers § 1's user agent with a challenge (a 403 or 503 with a Cloudflare body), HALT with the status and the body's size. Don't switch to a browser user agent.
- **M2, the store against the file.**
  - On prod, by `SELECT`, put every `race_ratings` row with source `inside_elections` beside the file's rating for that race, normalized as § 1 will, by chamber.
  - A difference is explained when the stored label is the record's normalized `previous_rating`. List every difference, explained or not.
  - Also list the file's competitive ratings with no stored row (new pairs, explained when `previous_rating` is Solid) and the stored rows whose record is now Solid (departures).
- **M3, Wikipedia.** If 769's P4 read it, paste P4's numbers; the block carries them beside mine. If it didn't, don't read it now.
- **M4, Sabato's census.** This wires nothing and carries no HALT.
  - Before fetching anything from a host, read its `robots.txt` and its terms. Where either bars automated access, quote the clause and stop at that host.
  - Otherwise, plain-GET `centerforpolitics.org/crystalball/2026-house/` and `/2026-senate/`. Give the status and bytes, and say whether district ratings are in the HTML.
  - Load the same pages in Playwright until the network is idle. For every response that carries district ratings, give its URL, method, status, the headers that differ from a plain GET, the record count and the as-of date.
  - If a page embeds another host's map (270toWin, say), do the same for that host, after its `robots.txt` and terms.
  - Report one line per candidate: the URL, whether a plain GET works (yes or no, and why), the terms (allow, bar or silent, quoted), the shape, the count and the as-of date.

**Go on without stopping** if both of these hold:
- M1 meets § 1's rules for both chambers: exactly one export link per page, House 435, Senate 35 rated, and every label placed;
- M2 has at most 3 unexplained differences per chamber, each one listed.

A `rating` string outside claim 7 doesn't stop you if its `rating_numeric` places it plainly on the scale. Map it and say so.

**HALT** with M1 and M2 otherwise.

## The build

### 1. One reader per rater, with Inside Elections wired (fix)

`lib/race-ratings-scrape.ts`:
- **The header** gains an HO 770 paragraph: the token-gated widget, Wikipedia's column dates, Cook's terms, IE's export. The history above it stays.
- **Delete claim 2's Ballotpedia transport.** Keep `Chamber`, `RatingSource`, `RATING_SCORE`, the locked-label idea, `ScrapedRating`, `LockedCell`, `RatingsScrape` and `FETCH_TIMEOUT_MS`.
- **`USER_AGENT`** is `CBT-ratings-sync/1.0 (+https://github.com/CSU-J3/cbt)`. The browser string existed for Ballotpedia's 202 wall. If a source refuses an honest fetcher, that's a finding to report, never a reason to disguise the fetcher.
- **The fetch** keeps `fetchHtml`'s 8s budget over headers and body. It throws `fetchError` on a non-2xx status, and status 0 on our own timeout. It takes an `Accept` per call: `text/html` for the page, `application/json` for the file.
- **`WIRED: Record<Chamber, readonly RatingSource[]>`** is `{ house: ["inside_elections"], senate: ["inside_elections"] }`. Its comment says why Cook and Sabato aren't in it, and that an unwired rater's rows are left untouched.
- **The IE reader**, both chambers. The page is `https://insideelections.com/ratings/{house|senate}`.
  - **`discoverIeExport(pageHtml, chamber)`**, exported and pure. It collects the hrefs naming `ratings_latest_{house|senate}_year=2026_district=all_clean.json`, decodes `&amp;`, resolves each against the page and de-duplicates. Anything but exactly one throws and lists what it saw. The link is discovered rather than hardcoded because its `?v=` stamp changes with each regeneration, and a hardcoded URL can be answered from a cache.
  - **`parseIeExport(json, chamber)`**, exported and pure. It throws when:
    - `office` doesn't match the chamber (`House` or `Senate`);
    - `ratings` isn't an array of length `total`;
    - a record's `election_year` isn't `"2026"`;
    - a race id repeats (the error names it);
    - the minted rows fall below the floor;
    - no competitive rating is found.
  - **House ids:** a `district` matching `^([A-Z]{2})-(\d{2}|AL)$`, whose state code is in `STATE_ABBR_TO_NAME` and isn't territorial, mints `{ST}-{NN|AL}-2026`. Anything else stays unminted, and the floor decides.
  - **Senate ids:** records reading `Not Up This Cycle` drop out before counting. Rated records mint `S-{ST}-2026` from `district`, and a state rated twice throws. That's the special-election collapse guard, now on IE's side.
  - **Floors:** House 435 and Senate 35, both with tolerance 0, because an export has no spacer rows to forgive. The comment says so beside HO 744's reasoning.
  - **Vocabulary:** IE's own words (claim 7) map to the normalized labels, `Likely D` through `Toss Up` to `Likely R`, with `Solid D` and `Solid R` locked. Any other label is counted and warned with its `rating_numeric`, and never written.
  - **`asOfDate`:** the first ten characters of the record's `date`, which is the publisher's own calendar day. If it doesn't parse, it's null and the sync falls back to the scrape date, as it did for the caption.
  - **`source_url`:** the chamber's IE ratings page.
- **`scrapeChamber(chamber)`** runs the chamber's `WIRED` readers under `Promise.allSettled`. It returns:
  - one `RatingsScrape` over the raters that read, with `sourcesPresent` naming exactly those;
  - each read's `sourceUrl`, `dataUrl` and `asOf` (the file's `last_updated`);
  - the failures.

`lib/race-ratings-sync.ts`:
- The legs work as now: both chambers read together, then the House writes, then the Senate.
- Inside a leg:
  - write every rater that read: upserts first, then departures, with both predicates unchanged;
  - each row cites its own rater's page as `source_url`;
  - then, if any wired rater failed, throw, naming it and the writes that landed, so the leg reads `ok:false` and the run records `error`.
- **Stats:** the chamber totals stay as they are, `scraped` included, since the guard's chamber reading uses it. For each rater that read, add `stats.raters.<source>`: `{ ok: true, scraped, upserted, changed, unchanged, skippedNoRaceRow, deleted, asOf, sourceUrl, dataUrl }`.
- **The header** gains an HO 770 paragraph.

The route header changes in two places:
- "from Ballotpedia" becomes the per-rater sentence;
- the budget line becomes "at most 2 × 8s per leg (IE's page answering just inside the cap, then an export that never does)".

### 2. The MOVED guard reads the move's rater (fix)

With one reader per rater, a chamber leg no longer says that a given rater was read. Once Cook or Sabato is wired after weeks away, IE's weekly legs would vouch for its catch-up. So the leg becomes the rater's:
- **`syncLegOk(run, chamber, source?)`:**
  - With `source`: a run whose leg carries `stats.raters` counts only if `stats.raters[source].ok === true` and that rater's `scraped > 0`.
  - A run whose leg has no `raters` predates HO 770. It counts for every rater on the chamber reading, because one table carried all three. That includes the pre-HO 744 House shape.
  - Without `source`: the chamber reading, as now.
- **`isFreshMove(observedAt, chamber, syncRuns, historyRuns, horizons, source?)`** passes `source` through.
- **`readRecentRaceMoves`** passes each move's source, and its verdict key becomes `` `${date}|${chamber}|${source}` ``.
- **Unchanged:** P; the 8 days; `error` runs counting for nothing (claim 5: they carry no legs); the horizons; the fallback.
- **The file's header** gains the reason in three sentences.

On today's runs nothing changes. Every run so far predates HO 770, so per-rater and per-chamber readings agree. Leg D checks that on the copy.

## Legs

Every leg has a red or a control.

**A, the shape.** `scripts/diagnostic/race-ratings-shape-770.ts --chamber house|senate` replaces `race-ratings-shape-742.ts`, which is retired with its subject. It runs the shipped `discoverIeExport` and `parseIeExport` on M1's saved page and file:
- both chambers parse at the floors, with counts by label and dates;
- the two chambers' id sets don't intersect;
- each of these mangles fires its throw:
  - no export link;
  - two different export links;
  - `office` wrong;
  - `total` ≠ length;
  - a duplicate district;
  - a House record dropped (434);
  - a Senate rated record dropped (34);
  - a district reading `"OH-1"`;
  - every label unknown;
- one unknown label is counted and not written;
- controls: a local server's 404 throws `fetchError` naming the URL, and a local server that accepts and never answers throws status 0 inside 8s.

**B, the sync**, in `scripts/diagnostic/ratings-source-770.ts`, on a `file:` copy seeded from prod by `SELECT`, writing only to the copy:
- both legs read `ok`;
- per chamber, give IE's upserts, changes, new pairs and departures, with every change listed with its record's `date` and `previous_rating`. Each must match M2;
- give the rated-race set (`SELECT DISTINCT race_id FROM race_ratings WHERE cycle = 2026`, the set the index joins on) before and after, by chamber, with the ids that moved;
- every `cook` and `sabato` row's fingerprint is the same before and after;
- a second run changes 0 rows and deletes 0;
- prod's fingerprint is the same before and after.

**C, the hang.** Re-run `ratings-hang-legs-744.ts` on the new build. Point its shim's target at the chamber's IE export fetch, and put its perturbation on an `inside_elections` row in each chamber, since only IE writes now. The shim's edit goes in the `diag` commit.
- **a:** the Senate fetch hangs. The House writes land, the run records `error` naming senate, health reads red, and elapsed is near 8s.
- **b:** the mirror.
- **c, the control:** the cap removed. It times out near 55s, health reads healthy, and nothing is written.

**D, the guard**, in the same script, on planted runs:
- a pre-770 run with the chamber ok counts for cook, inside_elections and sabato;
- a post-770 `success` run whose House leg carries only `inside_elections` counts for IE and not for cook;
- cook wired after three IE-only weeks: its first run's move reads not fresh, while IE's move that day reads fresh;
- an `error` run counts for no rater;
- `electoral-legs-768.ts`'s leg E, unchanged, still passes (no `source`, so the chamber reading);
- on the copy, every move's verdict is the same with its source and without it.

## Docs

**roadmap:** the HO 770 block. It opens with the source census, then what's wired, then the legs. The census covers:
- Wikipedia's dates and cells, with M3 beside them;
- Cook's terms and API;
- IE's export;
- M4's table.

**backlog:**
- **Rewrite HO 768's ratings WATCH; don't strike it.**
  - Lead with what HO 770 sends: IE's export, both chambers. Say that Cook's and Sabato's rows stand at 09-30.
  - *Close:* the first scheduled run after the FF reads `success` with both IE legs at the floors.
  - A failure at IE's fetch from pdx1 makes it an egress question. The honest user agent stays.
- **New line, Cook.** It's wired only through Cook's API, because the terms bar automated access to the site.
  - *Owner:* Corey for access, then Code.
  - *Reads if never done:* Cook's chips hold their 09-30 ratings to Election Day while Cook keeps updating. Its House page was dated 10-09 and its Senate page 10-06, both after our last read.
- **New line, Sabato.** HO 771 rules with M4 in hand.
  - *Owner:* architect.
  - *Reads if never done:* Sabato's chips hold their 09-30 ratings. Its 10-08 changes (NE-02, FL-22, FL-25, WI-01) are already missing.
- Reconcile, control 0.

**oddities:** append this entry, verbatim:

```text
## Wikipedia's 2026 House ratings table ran six weeks behind the raters it cites, and its column dates said so (HO 770, Oct 2026)

Read 2026-10-09, looking for a ratings source after Ballotpedia's widget went behind a signed token. `2026 United States House of Representatives election ratings` lists the 153 seats any of ten raters calls competitive, each rater's date in its column header: Cook Aug. 25, IE Aug. 20, Sabato Aug. 26. Against Cook's own page, dated Oct 9, 19 of 28 sampled Cook cells differed, among them every House race in the 09-30 MOVED batch (AZ-01, CO-05, FL-13, FL-22, FL-27, IA-01, MT-01, NC-11, NJ-07, TX-15, TX-35, WI-01). None of the six Sabato changes of 09-29 and 10-08 checked had landed either. The Senate table was closer (Sep 17-23) and still differed from Cook's Oct 6 page on NH and NC. A compiled table is only as current as its oldest column date, and that date is printed in the header. Wherever the store already held something newer, reading this one would have rolled it back and logged the rollback as a move.
```

**README:** replace the credits line, verbatim.

OLD:

```text
- **Race ratings & candidates** — [Ballotpedia](https://ballotpedia.org) (which
  aggregates Cook, Sabato, and Inside Elections).
```

NEW:

```text
- **Race ratings** — [Inside Elections](https://insideelections.com), read from its
  published ratings export. Cook Political Report and Sabato's Crystal Ball ratings
  are as [Ballotpedia](https://ballotpedia.org) last carried them, on 2026-09-30.
- **Candidates** — [Ballotpedia](https://ballotpedia.org).
```

**SKILL:** four edits, in their own `docs(skill)` commit, last. Quote the diff in the paste for approval.

Edit 1, External data sources, the Ballotpedia bullet's first sentence:

```text
OLD: - **Ballotpedia** scraping — primaries (HO 91-96, 120) and race ratings (HO 71), and since HO 749 **the general-election box**.
NEW: - **Ballotpedia** scraping — primaries (HO 91-96, 120), race ratings from HO 71 until HO 770 (see Inside Elections, below), and since HO 749 **the general-election box**.
```

Edit 2, two bullets inserted before the House Clerk one:

```text
OLD: - **House Clerk + Senate eFD** (planned)
NEW: - **Inside Elections** (`https://insideelections.com/ratings/{house|senate}`, then the *Export → API* file the page links, `…/wp-content/themes/inside-elections/cache/ratings_latest_{house|senate}_year=2026_district=all_clean.json?v=<generation stamp>`; public, no auth, `robots.txt` bars only `/wp-admin/`) — IE's race ratings since HO 770, both chambers, read in `lib/race-ratings-scrape.ts`. The file is what IE's own ratings page renders client-side: every House seat (435 records, Solid included, `district` as `ST-NN` or `ST-AL`) and every Senate seat (100 records, the 65 not up reading `Not Up This Cycle`, the class in `office`), each with its own `date`, a `rating` in IE's words and a `rating_numeric` from 0 to 10. The link is discovered from the page rather than hardcoded, because its `?v=` stamp changes with each regeneration and a hardcoded URL can be answered from a cache.
- **Race-ratings sources weighed and not used (HO 769-770).** Ballotpedia's widget now answers only a POST carrying a signed per-page token (`wgBPWDeferToken`), and replaying it is ruled out. Ballotpedia's data API (`api4.ballotpedia.org`, keyed) carries no ratings. Wikipedia's ratings tables lag the raters: on 2026-10-09 the House table's Cook, IE and Sabato columns were dated Aug. 25, 20 and 26, and 19 of 28 sampled Cook cells differed from Cook's own page. Anyone can read Cook's site, but its Terms & Conditions bar "any robot, spider, or other automatic device, process, or means to access the Website for any purpose", so no code fetches it. Cook's API (`/api/race/{house|senate}`, HTTP Basic with an account, at most one call a day) is by request. Sabato's Crystal Ball: see HO 770's census.
- **House Clerk + Senate eFD** (planned)
```

Edit 3, the ratings cron entry's opening:

```text
OLD: - `/api/sync-race-ratings` — 11:00 UTC **Wednesdays only** (`0 11 * * 3`) — Cook / Inside Elections / Sabato House **and Senate** race ratings from Ballotpedia (handoff 88; rewritten HO 742; Senate added HO 744). **THE TRANSPORT IS A WIDGET, NOT THE WIKI PAGE.**
NEW: - `/api/sync-race-ratings` — 11:00 UTC **Wednesdays only** (`0 11 * * 3`) — House **and Senate** race ratings, **one reader per rater since HO 770**. `WIRED` (`lib/race-ratings-scrape.ts`) names the raters each chamber reads. Today that is Inside Elections alone, from its export (see External data sources). Cook's and Sabato's rows stand as Ballotpedia last wrote them on 2026-09-30: no upserts, no departures, and their `rating_date` shows their age. A leg reads its chamber's wired raters together and writes every rater that read, each row citing its own rater's page as `source_url` and its own record's `date` as `rating_date`. It then fails if any wired rater didn't read, so the run still records `error`. The payload carries `stats.raters.<source>` for each rater that read, and the MOVED guard reads it (see the MOVED entry). The export's floors are House 435 and Senate 35 with **zero** tolerance in both, since an export has no spacer rows. A duplicate race id throws: that is the special-election collapse guard (FL and OH are rated once each, under class III). The user agent is `CBT-ratings-sync/1.0 (+https://github.com/CSU-J3/cbt)`, not a browser's. **Everything below is the Ballotpedia era, HO 742-769. It stays because what it learned carries over unchanged: the four throws, absolute floors per chamber, a chamber passed and never inferred, departures on evidence and never on absence, legs that can't discard each other's writes, and the 8s cap.** **THE TRANSPORT WAS A WIDGET, NOT THE WIKI PAGE.**
```

Edit 4, the MOVED guard sentence:

```text
OLD: and the first ratings run after that tick with the move's chamber leg ok (a `success` row in `cron_runs` whose leg scraped rows) came within 8 days of the leg-ok run before it.
NEW: and the first ratings run after that tick that read the move's rater in its chamber came within 8 days of the last run before it that read that rater. A run reads a rater when it is a `success` row in `cron_runs` whose `stats.raters.<source>` scraped rows. A run from before HO 770 counts for each rater if its chamber leg scraped rows, because one table carried all three. Since HO 770 the leg is the rater's, not the chamber's, so a rater wired after a gap has its catch-up judged against the last run that actually read it.
```

## Commits

On `770-review`, kinds unmixed:
- `fix` for § 1;
- `fix` for § 2;
- `diag`;
- `docs`;
- `docs(skill)`, alone and last.

## Paste back once, for 769 and 770

- **769:** everything its ruling lists. The only change is that its review push is followed straight by this HO, not by a paste.
- **770:**
  - `ls-remote` with both review SHAs;
  - the cache line from the 770 Preview's build log;
  - STEP 0: the claims, M1-M4 and the decision;
  - legs A-D;
  - `--stat` per commit, and `--numstat` for docs with every deletion explained;
  - the reconcile;
  - a last cheap-gate run.

The FF go then carries:
- the FF to `770-review`'s head, which holds 769's commits and these;
- `verify:deploy` and `e2e-prod`;
- one `POST /api/sync-race-ratings` on Production;
- 769's `POST /api/revalidate?tag=palestine`;
- the prod reading.

That POST is the deployed path's first read of IE. A laptop's reading doesn't stand in for pdx1's egress (HO 228). Expect `success` with both IE legs at the floors. Its moves will read not fresh, since IE's last read before it is #21278 on 09-30.
