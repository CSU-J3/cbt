# HO 716 — FF go (architect, 2026-09-12)

**Owner verdict, verbatim: "send it pls"** — Corey, CBT maintenance chat, 2026-09-12, on the architect's read of `716-review` at `57b71b8` off the remote: three commits, kinds pure (`fix`, `docs(skill)` alone, `docs`); `489c414` is an ancestor, so the move is a clean fast-forward. The fix is the two rules ruled at STEP 0 (`.weekly-band-seg { white-space: normal }`, `.wb-metric { white-space: nowrap }`), unconditional, with the mechanism and the 0 → 4 content flip in the CSS comment. Proven three-legged on Preview: right code in the served chunk, right content after `POST /api/revalidate?tag=bills` confirmed before and after the run, and the CI re-run green on all eight formerly-red routes at 390 and 430. The first Preview green, on a cache still serving zero chips, is recorded as the false one.

**What this FF is.** A hotfix that restores the deploy-blocking Production gate on `main`, and the first landing whose close is defined as three readings rather than one: the gate's green means nothing without the element it would fail on present in the page it crawled.

## 1. The move

- `git ls-remote --heads origin` immediately before: `main` at `489c414`, `716-review` at `57b71b8`. Anything else, stop and paste.
- On `main`, the cleanup door: `git merge --ff-only 57b71b8`; `git rev-parse main` must print `57b71b8`. `git push origin main`, no force. `git push origin --delete 716-review`. Then `git ls-remote --heads origin` and `git ls-remote --tags origin` (three tags).
- Each state-changing command on its own line, stderr never suppressed. The commit list is `git log --oneline 489c414..main` off the pushed branch.

## 2. The close — three legs, in this order

- `npm run verify:deploy` until the served SHA is `57b71b8`, five consecutive reads.
- **Leg 1, right code:** the served CSS chunk on production carries `.weekly-band-seg{white-space:normal}` and `.wb-metric{…white-space:nowrap}`, grepped from the chunk the page actually links.
- **Leg 2, right content:** `curl -H "cookie: ct_seen=1" /` and read the enacted segment. It must carry the ids box (today's form: `● 4 enacted ▲3 · HR 5366 HR 1276 HR 2069 +1`, 704 bytes). **If production's cache has rolled to zero enacted, `POST /api/revalidate?tag=bills` with `$CRON_SECRET`, re-read, and only then proceed**; if the week genuinely holds zero enactments after the flush, say so — the close then waits for content, and the paste says it is waiting rather than reporting an empty green.
- **Leg 3, gate green:** the Production `deployment_status` run on `57b71b8`: id and conclusion, the group echo, the eight formerly-red routes at 390 and 430 with `over=0`, the `home` line's `band=N/failed=0` (HO 714's assertion, still in force), wall time. If the run crawled before leg 2 was true, re-run the failed or all jobs on the same SHA after the flush and quote the re-run's id; the first run is recorded as what it was.
- **The three legs pasted together, with timestamps**, so the record shows the content was present at the moment the gate read.
- `ci.yml` and `design-citations` conclusions.

## 3. After the FF

Nothing else is owed by this HO. HO 715 rebases behind it and proceeds. The two filings stand: the oddity (a conditional element sits outside every gate until content creates it, and the same trap fired on the verification), and the gated backlog line for content-independent narrow coverage, carrying the interim practice (flush the tag on the deployment under test and read the segment before trusting the gate).

## 4. Paste

The `ls-remote` line showing `main` at `57b71b8`, the ref gone, three tags; `git rev-parse main`; the three-line log; the five served reads; legs 1–3 with timestamps; the Production run's id, conclusion and the eight routes' lines; `ci.yml` and `design-citations` conclusions.

read and follow 716-ff-go — the file, not this line
