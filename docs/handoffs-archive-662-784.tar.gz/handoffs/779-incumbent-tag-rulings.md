# HO 779: Corey's two tag rulings. A called race keeps its incumbent's tag, a run for the Senate or another district shows its result, and five incumbents read RUNNING FOR GOVERNOR. With HO 778's FF readings

**The rulings** are the backlog line *"The incumbent tag after a race is called, and an incumbent running for governor"* (filed at HO 778, verbatim there). This HO builds both and closes it.

**Why now.** On Nov 4, every called race's page says *not on the ballot* of an incumbent who lost a primary or ran for the Senate (HO 777's rehearsal: AL-01, GA-13 and S-AL). And S-AL calls Tommy Tuberville, Alabama's Republican nominee for governor, RETIRING today.

**Scope, in:**
1. **§ 1,** the tag after a race is called.
2. **§ 2,** RUNNING FOR GOVERNOR.
3. **HO 778's FF go,** into this block, and the Louisiana line struck with its read.
4. **The docs:** the rulings line struck on the legs, the WATCH (HO 758) line's (c) unblocked, and SKILL.

**Out:**
- a governor race's result. CBT reads none, so after election day the governor tag reads RAN FOR GOVERNOR (my call; Corey can overrule it);
- HO 758's qualifier where there's no tag (re-elected, defeated, a runoff, and *not on the ballot* where no tag stands in for it);
- every other OPEN LOOPS line, the Vercel line included;
- any prod write.

**How STEP 0 runs** (method.md, HO 768's rule): the claims are mine and are a check. The measurements are yours.

**Base:** `main` at `0d53dae`, HO 778's FF head. HO number: the pointer is 778 and the highest HO in commit subjects is 778, so this is 779.

## STEP 0

| # | Claim | Fails if |
|---|---|---|
| 1 | `main` is `0d53dae`, and its Production smoke passed (#38299844817, and #38300326794 from Vercel's late record). | either |
| 2 | The race page drops the tag on a decided race: `qualifier={incumbentTag && !result.decided ? null : result.qualifier}` and `tag={result.decided ? null : incumbentTag}` (`components/RaceHubBody.tsx:171-178`), and the card prints the qualifier over the tag (`components/RaceIncumbentCard.tsx:128-138`). | |
| 3 | HO 758's qualifier reads *not on the ballot* for any off-ballot incumbent once election day has passed (`lib/race-result.ts:173`). The gate is `raceResultView`'s, DORMANT while `daysToElection(cycle, nowMs) >= 0` (`:164-165`), on `clockNowMs()` (`lib/clock.ts`), whose `CBT_CLOCK_NOW` seam is honoured only on a `file:` URL. | |
| 4 | A box race is decided by exactly one marked printed row and is a runoff at two or more (`lib/race-result.ts:26-31`, `readRaceResult`). | |
| 5 | The qualifier has three kinds and four reasons (`lib/incumbent-qualifier.ts:61-65`), picks them in `readQualifier` (`:93`, the kinds at `:117`), and reads `general_ballot` without `marked` (`:140`). `getIncumbentQualifiers` caches it, tagged `general-ballot` and `races` (`lib/queries.ts:2296-2300`). | |
| 6 | The tag's words live in `lib/incumbent-tag.ts` (`REASON_TAG` at `:7`, `incumbentTagText` at `:18`) and `components/IncumbentTag.tsx` (`:20`). The `/electoral` open row composes its own holder words (`components/RaceOpenRow.tsx:196-216`), and its member rows' result words are `roleParts` (`:261`, the words at `:271-275`). | |
| 7 | Four places merge the tags: the race page (`app/race/[id]/page.tsx:91`, `:120`), `/electoral` (`app/electoral/page.tsx:108`, `:116`), `/`'s competitive block (`components/CompetitiveRacesBlock.tsx:86-87`) and `/welcome` (`app/welcome/panels.tsx:209`, `:353-355`). | another place prints the tag |
| 8 | Five stored incumbents are on a Nov 3 governor ballot (below). | a race's stored incumbent isn't that bioguide, or one of the five reads `moved` or `senate` today |

**The five,** each the Republican nominee for governor of their state. The source for all five is CQ-Roll Call's *Congress Is Becoming a Pipeline to Governors' Mansions* (Aug 26, 2026), <https://www.governing.com/politics/congress-is-becoming-a-pipeline-to-governors-mansions>, which names every current member on a November governor ballot:

| Race | Incumbent | Bioguide |
|---|---|---|
| S-AL-2026 | Tommy Tuberville | T000278 |
| AZ-05-2026 | Andy Biggs | B001302 |
| WI-07-2026 | Tom Tiffany | T000165 |
| MI-10-2026 | John James | J000307 |
| FL-19-2026 | Byron Donalds | D000032 |

**Not on the list,** so their tags don't change:
- the other members who ran for governor (David Schweikert, Nancy Mace, Ralph Norman, Dusty Johnson, Randy Feenstra, John Rose, Eric Swalwell), none of them on a November ballot by the same source;
- Chip Roy (TX-21), who lost the Texas attorney general runoff on May 26.

**Measure, read on prod by `SELECT` through `readIncumbentQualifierReadings`:**
- today's tags by kind and reason;
- each `senate` and `moved` tag's target race and that race's read status, naming any target that isn't a `box` read;
- the five's qualifiers today.

## § 1: the tag after a race is called (`feat`)

**The race page keeps the tag.** Where the incumbent carries a tag, the card shows it, decided or not, and HO 758's qualifier shows only where there's no tag.

**A `senate` or `moved` tag turns to its own race's result** once election day has passed, by the race page's gate. It reads that race's marks the way a race page reads its own:

| That race | `senate` | `moved` |
|---|---|---|
| not called | RUNNING FOR SENATE | RUNNING IN <seat> |
| decided, their row marked | ELECTED TO THE SENATE | ELECTED IN <seat> |
| decided, another row marked | LOST THE SENATE RACE | LOST IN <seat> |
| a runoff, their row marked | IN THE SENATE RUNOFF | IN THE <seat> RUNOFF |
| a runoff, their row unmarked | OUT OF THE SENATE RUNOFF | OUT OF THE <seat> RUNOFF |

SENATE and the seat keep their link wherever the tag links today. These are the words `/electoral`'s member rows use, as the ruling asked, in the tag's capitals. The last row is the open row's *out of the runoff* with its race named.

**The reason tags stand:** RETIRING, WITHDREW, LOST PRIMARY, NOT ON THE BALLOT.

**Where it lives:**
- The marks ride in the cached read: the qualifier's `general_ballot` read gains `marked`.
- The clock applies on the server, at the four merge points, through one helper. Never in a client component (SKILL, *Client-component clock discipline*, HO 490).
- The words live in one place, `lib/incumbent-tag.ts`, so `IncumbentTag`, `incumbentTagText` and the open row's holder line read the same words.
- The holder line takes the same outcome in lower case, with its seat button or link where it sits today: *elected to the Senate* AL SEN →.

## § 2: RUNNING FOR GOVERNOR (`feat`)

**The list:** a curated file in `data/`, beside `races-seed.json`, one entry per member: race, bioguide, office, state, source and as-of. It holds the five above. The loader is your call.

**The qualifier gains a kind for it,** after `moved` and `senate` and before the reasons, since the kind beats the curated flag as Hinson's does:
- before election day it reads RUNNING FOR GOVERNOR, unlinked, in the kinds' dim style;
- after it, RAN FOR GOVERNOR;
- the open row's holder line reads *running for governor*, then *ran for governor*.

## The legs (`diag`)

Seed a fresh copy of prod by `SELECT` the way HO 777's rehearsal did (a SELECT-only reader, `file:` copies, prod's fingerprint read equal before and after), and run each build's server per copy with `CBT_CLOCK_NOW`.

**Leg 0, today's clock** (with marks planted, to prove the gate):
- every race page's `<main>` byte-identical to HEAD's except the five governor seats' cards;
- every tag on `/electoral`, `/` and `/welcome` (`data-incumbent-tag`) equal to HEAD's except the five's;
- the five read RUNNING FOR GOVERNOR on the tree and their old tag on HEAD;
- no outcome words anywhere.

**Leg 1, the clock at Nov 4,** with marks planted for one case of each class. Pick the cases from STEP 0's census and name them:
- a `senate` tag elected, one lost, one in a runoff, one out of it, and one not called;
- a `moved` tag elected or lost, if the census holds a `moved` tag;
- GA-13 (LOST PRIMARY), a RETIRING, a NOT ON THE BALLOT, and S-AL.

On each case's race page: HEAD red (*not on the ballot* on each decided race, S-AL's among them), the tree green (the table's words, RAN FOR GOVERNOR on S-AL, LOST PRIMARY on GA-13, and no *not on the ballot* beside a tag). For a rated case, also `/electoral`'s holder line, its MAP card, the district modal and the hover meta. For a featured one, `/`'s card.

**Leg 2, the census at Nov 4:** every tag on every race page against the rule computed from the copy's rows, with 0 mismatches.

**Captures,** retained: leg 1's cards and `/electoral`'s rows and MAP card, at 1440 and 430, and a reduced-motion pass at 1440.

## Docs

**roadmap:** the HO 779 block. It opens with **HO 778's FF go as taken** (your paste), then STEP 0, § 1, § 2 and the legs.

**backlog:**
- **The rulings line:** struck on the legs.
- **The Louisiana line:** struck with HO 778's FF go read (#24524: 6 of 6, rows unchanged against the cursor's 12:00:22Z pass).
- **The WATCH (HO 758) line:**
  - (c) is unblocked: drop *"It stays blocked until the FF go's prod read closes the Louisiana line below."*;
  - its reads gain one off-ballot incumbent's tag on a called race.
- Reconcile, with the control at 0.

## SKILL (`docs(skill)`, alone and last)

Rewrite to the tree every SKILL sentence the build makes false, and name each in the paste. I count four places:
- `:1976`, where the qualifier shows on a decided race only;
- `:1980-1986`, the kinds and reasons, which gain the governor kind and the outcome words;
- `:1987`, the kind beating the curated flag, which now includes the governor kind;
- `:1998`, the compact surfaces that *"carry no result state"*.

Add where the list lives and that it's curated with a source each.

## Commits

On `779-review` from `main`, kinds unmixed:
- `feat`, § 1;
- `feat`, § 2;
- `diag`, the legs;
- `docs`;
- `docs(skill)`, alone and last.

Build, then the cheap gates, before every push. If the Preview's Vercel record hasn't come a few minutes after READY, make it by hand as HO 778's go did, and say so.

## Paste back once, after the Preview and `narrow-preview`

- `ls-remote` with `779-review`'s SHA;
- STEP 0, with the measurements;
- legs 0 to 2, red and green, and the captures;
- the Preview, and `narrow-preview`;
- `--stat` per commit, `--numstat` for docs with every deletion explained, and the SKILL diff;
- the reconcile;
- a last cheap-gate run.

Build through to the review push without stopping. A failed claim HALTs; nothing else does.
