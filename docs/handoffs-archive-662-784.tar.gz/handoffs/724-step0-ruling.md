# HO 724 — STEP 0 ruling (architect, 2026-09-14). Half the paste arrived; the four findings that did are ruled, the missing half is re-delivered as a file, and the go is conditional on rows 1–6 having read as the handoff predicted.

**The relay swallowed the front of the paste.** What reached the chat begins mid-sentence at *"Row 7 partially works"* and carries findings 2 through 5 and the HO 723 reading; the closure table (rows 1–8) and finding 1 did not arrive. Per method § Relay this is one strike, so the remedy is the file, never a second paste: save the complete STEP 0 output as `docs/handoffs/724-step0-paste.md` (repo-ignored) and name it in the reply for Corey to attach. Finding 1 is not inferred from the two lines that mention it; it is read from that file.

## 1. The go, pre-ruled on what you already know

Rows 1–6 and 8 were read before the flags were written, and the flags say nothing about them beyond row 5's numbers appearing in finding 4. So: **STEP 1 starts now if, and only if, rows 1–6 and 8 read as the handoff's expected column says** (HEAD at `5dcdf9e` with pointer 723 → 724; the quotes as in ground truth; `excluded.summary_text` at one site; build and typecheck 0; the prod pre-state with `2026-08-31` at 124; `cron_runs` quoted; the CLI's blind path read). Any departure in those rows is a HALT to raise before STEP 1, not a departure to name after it. The re-delivered file carries the table into the record either way, and the paste-back repeats the row-5 `SELECT` beside every probe read as the handoff already asks.

## 2. Finding 2 accepted: the Windows file lock, a bounded retry, and the exit code decided first

`db.close()` returning before the handle is released is the box's behaviour, not the probe's defect, and three timed releases at 154, 161 and 289 ms bound it. Step 8 deletes with a retry loop capped at **10 s**, polling every 100 ms, and prints one line either way: `cleanup: removed after <n> ms` or `cleanup: file left behind after 10 s (EPERM)`. A leftover is harmless (the path is under the ignored `scripts/diagnostic/scratch/`, and step 2 removes it on the next run, which your fresh-process reading already proved), so **the exit code is computed from legs B, C and D before cleanup runs and cleanup cannot change it**. Close the read-only prod client too, so nothing outlives the process by accident. Step 2 stays as written.

## 3. Finding 3 accepted: four places, not three, and the fourth rides the `fix` commit

`app/api/cron/weekly-report/route.ts:70-75` says the same thing SKILL `:1146` says and goes false the same way: after the clause, a refused re-run keeps the stored summary rather than leaving the week with none. One clause there, in the `fix` commit, because it is a comment made false by the code change in the same file (the HO 721 standard, a forced consequence, not a widening). Before writing it, enumerate every statement of the refusal or NULL semantics in one grep across `lib/week-summary.ts`, `app/api/cron/weekly-report/route.ts`, `scripts/backfill-week-summaries.ts`, `scripts/migrate.ts` and `lib/report-generation.ts` (bare substrings: `refus`, `NULL`, `summary_text`), and list each hit in the paste as *stays true* or *amended*. The backfill header `:10-14` (*"that week keeps a NULL summary"*) stays true as written: it writes only on `gen.ok`. SKILL `:1690` stays true, as you read.

## 4. Finding 4 accepted, with the earlier rows named for what they are

The `cron_runs` discriminator exists only for ticks that carried the summary rider, and the first was **2026-09-07**'s (HO 689 deployed 2026-09-03, `4d4f478`; the 08-31 tick predates it and carries neither `summary` nor a `chronicErr`). Rows before that were written by `backfill:week-summaries`, whose refusals go to its console and nowhere else, and whose default `--weeks 3` window means a row can also simply never have been attempted. So the rewritten comments say two things: for ticks from 2026-09-07 on, `cron_runs` separates *refused* from *stored*; for rows before it, NULL is readable as neither. The `2026-08-24` row's 171 chars with the 08-31 tick's `created_at` is the backfill's signature and is quoted in the block as the example of a summary the old clause would have nulled on any CLI re-run of that week.

## 5. Finding 5 accepted, and the two machine findings go to a tracked file

Row 7 from a scratch file instead of `-e` is a named deviation and stands. The `tsx -e` finding and the file-lock finding both bite the next instrument written on this box, and Claude Code's memory does not follow the repo (method § Memory hygiene: anything that must survive a move belongs in a tracked file). One oddity entry, HO 724, carrying both: what `-e` could not do (from finding 1, once it arrives), the lock's timings, and the retry shape. The `docs` commit owns it.

## 6. HO 723's owed reading, carried

Production `34896943834` on `5dcdf9e`: `success`, 37 route lines, all 75 `pageErr=` readings 0, a `deployment_status` sample and not a daily; Preview `34896934850` skipped `smoke`. The HO 724 roadmap block carries this in its own paragraph, the way the 722 block carried 721's, so the 09-17 re-run inherits nothing from chat.

## Amendments to the handoff, collected

- Step 8's delete becomes a 10 s bounded retry with one printed outcome; exit code decided from legs B, C, D before cleanup; the prod client closed (§ 2).
- The `fix` commit gains `route.ts:70-75`, one clause, after a grep that lists every refusal/NULL statement as *stays true* or *amended* (§ 3).
- The rewritten comments date the `cron_runs` discriminator from 2026-09-07 and name pre-09-07 NULLs as unreadable (§ 4).
- One oddity entry for the `tsx -e` and file-lock findings (§ 5); the block carries HO 723's post-FF sample (§ 6).
- `docs/handoffs/724-step0-paste.md` saved and named for attachment before STEP 1's first paste-back (relay).
- Everything else stands as written: the probe's eight steps, `COALESCE(excluded.summary_text, reports.summary_text)`, the three comments, the two SKILL clauses, no prod write.

Go, on the condition in § 1: probe first in its blind state, `PRESERVES=no` pasted before the clause moves.
