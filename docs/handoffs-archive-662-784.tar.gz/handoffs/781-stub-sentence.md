# HO 781: past election day a stub page drops its sentence and keeps its provenance line, and the race page's news ages read the clock seam. With HO 780's FF readings

**Corey's ruling, 2026-10-12, verbatim** (answered by selection):
- the question: *"On Nov 4, an unrated race page whose ballot lists only the incumbent will show 'Decided · Nov 3, 2026' and 're-elected', but its sentence still says 'Incumbent running for re-election. No competitive rating yet.' What should that sentence say after election day?"*;
- the answer: *"Drop the sentence (Recommended)"*.

**Read:** past election day (`raceResultView`'s `passed`), a stub page shows no sentence, decided or not. That covers all three of its forms: *Incumbent running for re-election…*, the rating clause alone, and *Open seat. Candidate filings forthcoming.* Each goes stale on Nov 4. The provenance line stays. Extending it from the asked case to all three forms is my call.

**Why now.** It's the backlog line HO 780's go filed, *"The stub sentence after election day"*, dated before 2026-11-03.

**Scope, in:**
1. **§ 1,** the stub sentence (`feat`).
2. **§ 2,** the news ages' clock (`fix`). It's the low line HO 780's go filed, riding here because it's one line and this HO's legs need it.
3. **HO 780's FF go,** into this block.

**Out:**
- the stub test itself (`isStub`);
- the four pages of the line *"Four race pages trade the stub sentence for a roster of others…"* (HO 757), which is before election day and still Corey's;
- any prod write.

**How STEP 0 runs** (method.md, HO 768's rule): the claims are mine and are a check. The measurements are yours.

**Base:** `main` at HO 780's FF head, which is `36a4a30` plus its go's `docs` commit. HO number: after that FF the pointer is 780 and the highest HO in commit subjects is 780, so this is 781.

## STEP 0

| # | Claim | Fails if |
|---|---|---|
| 1 | `main` is HO 780's FF head, its Production smoke passed, and OPEN LOOPS holds the two lines HO 780's go filed: the stub sentence and the news ages' clock. | any |
| 2 | `stubSentence` has three forms (`lib/race-stub.ts:11-16`), and its one caller is `RaceHubBody` (`components/RaceHubBody.tsx:193`), inside the stub `<p>` that also carries the provenance line (`:186-199`). `isStub` is no rating, no chips, no roster rows and no runoffs (`:106-110`). | another caller |
| 3 | `raceResultView`'s `passed` is false before election day (`DORMANT`, `lib/race-result.ts:171`, `:182`) and true after it (`:204`). | |
| 4 | The race page's news clock is `Date.now()` (`app/race/[id]/page.tsx:33`), with `clockNowMs` already imported (`:5`). | |

**Measure**, on a fresh copy at today's clock: the stub pages, counted by form.

## § 1: the stub sentence (`feat`)

The stub `<p>` prints `stubSentence` only while `result.passed` is false. Past election day it holds the provenance line alone, and with neither, it doesn't render. Before election day nothing changes.

## § 2: the news ages' clock (`fix`)

`app/race/[id]/page.tsx:33` reads `clockNowMs()`, not `Date.now()`. On Production the two are the same. On a `file:` copy, `CBT_CLOCK_NOW` now sets the news ages too.

## The legs (`diag`)

Seed a fresh copy of prod by `SELECT` the way HO 780's legs did, and run each build's server per copy.

**Leg 0, today's clock:** every race page's `<main>` byte-identical to HEAD's, the stub sentences included. HEAD's news ages still run on `Date.now()`, so set them aside one last time, as HO 780's r3 did.

**Leg 1, the clock at Nov 4,** with marks planted:
- a decided stub page (its incumbent printed alone and marked): HEAD red, the sentence under *Decided · Nov 3, 2026*; the tree green, no sentence and the provenance line kept;
- an undecided stub page: no sentence on the tree, its *No call on Ballotpedia* line kept;
- an open-seat stub, if the census holds one: no sentence on the tree;
- the census: no stub page on the tree prints a sentence, and every other page's `<main>` equals HEAD's (news ages set aside).

**Leg 2, § 2:** on the tree at a set `CBT_CLOCK_NOW`, a news item's age reads against that clock, and two reads a minute apart in real time match. On HEAD the age reads against today.

**Captures,** retained: the decided stub page at 1440 and 430, and a reduced-motion pass at 1440.

## Docs

**roadmap:** the HO 781 block. It opens with **HO 780's FF go as taken** (your paste), then the ruling, STEP 0, § 1, § 2 and the legs.

**backlog:**
- **The stub-sentence line:** struck on the legs, with the ruling quoted.
- **The news-ages line:** struck on leg 2.
- Reconcile, with the control at 0.

## SKILL (`docs(skill)`, alone and last)

Add one sentence to the race page's result list (`:1973-1979`): past election day a stub page shows no sentence, only its provenance line (HO 781, Corey's ruling). Also rewrite to the tree any SKILL sentence the build makes false, and name each in the paste.

## Commits

On `781-review` from `main`, kinds unmixed:
- `feat`, § 1;
- `fix`, § 2;
- `diag`, the legs;
- `docs`;
- `docs(skill)`, alone and last.

Build, then the cheap gates, before every push.

## Paste back once, after the Preview and `narrow-preview`

- `ls-remote` with `781-review`'s SHA;
- STEP 0, with the count;
- legs 0 to 2, red and green, and the captures;
- the Preview, and `narrow-preview`;
- `--stat` per commit, `--numstat` for docs with every deletion explained, and the SKILL diff;
- the reconcile;
- a last cheap-gate run.

Build through to the review push without stopping. A failed claim HALTs; nothing else does.
