# HO 780: FF go. The runoff box stands, 21 PASS and 0 FAIL. A docs commit files two lines, then the FF and the deploy

## Rulings on the paste

I read `780-review` at `36a4a30`, all five commits:
- `2729b36`: `JUNGLE_JOIN` is shared, and a jungle seat with a `box` read joins `tx`, so it's planned as a top-two state is;
- `10ff9d1`: `resultFromRows` reads a jungle seat's box only once it's marked, and `decidedOn` names the runoff's date. `getRaceRoster`'s marks and `getElectionResults`' count take the same rule. Reaching those two was right: without them a decided page shows no *Elected*, and the band skips the seat;
- `3973c16`: the legs. r1's AZ-04 failure was the news ages' clock, not the build, and r3 stands;
- `561062a`: the Louisiana-box and Vercel lines struck, the general-runoff and flush lines filed, and the WATCH's reads. The reconcile reads 264/349 here too, control 0.

**SKILL is approved** (`36a4a30`): six places, each true of the tree.

**Your three notes:**
- **LA-05's RUNNING FOR SENATE and LA-03's LOST PRIMARY** are HO 779's rule reaching a seat that gains a box. Both are right.
- **LA-04's stub sentence isn't Louisiana's.** Every unrated race whose ballot prints only its incumbent keeps *Incumbent running for re-election. No competitive rating yet.* on Nov 4, under *Decided · Nov 3, 2026* and *re-elected*. The sentence is Corey's copy, so it's a line for him.
- **The news ages read `Date.now()`** (`app/race/[id]/page.tsx:33`), not `clockNowMs()`, so a leg at a set clock still sees today's ages. A low line.

## Before the FF, on `780-review`: one `docs(HO 780)` commit

**Two new lines** (OPEN LOOPS, newest-first):
- **The stub sentence after election day:**
  - what: a stub page (`lib/race-stub.ts`, `RaceHubBody`'s `isStub`) keeps its sentence past election day. An incumbent whom the ballot prints alone reads *Incumbent running for re-election. No competitive rating yet.* under *Decided · Nov 3, 2026* and *re-elected* (HO 780's LA-04, on both builds);
  - *Owner:* **Corey**, a copy call, then Code; dated before Tuesday 2026-11-03;
  - *Close:* Corey's ruling built, and read on a `file:` copy at Nov 4 on a decided stub page;
  - *Reads if never done:* on Nov 4 every decided stub page says its incumbent is running.
- **The news ages' clock:**
  - what: the race page takes its news ages from `Date.now()` (`app/race/[id]/page.tsx:33`), not `clockNowMs()`. So a leg at a set clock reads today's ages, and HO 780's r1 failed its control on AZ-04 when one crossed a day;
  - *Owner:* Code, low;
  - *Close:* the page's clock is `clockNowMs()`, and a byte-identical control needs no news ages set aside;
  - *Reads if never done:* every such control sets the news ages aside.

**The block ships true:** its *Five commits* line becomes six, and it gains the two lines.

**Reconcile,** the control at 0.

Build, then the cheap gates, before the push. Push with no force.

## FF

`780-review`'s head sits on `main` at `bae5790`: a fast-forward of 6 commits. No migration.

Re-run the build and the cheap gates immediately before the push, and name the reading. Then:
- `git push origin <780-review's head>:main`, no force;
- `git ls-remote --heads origin`;
- delete `780-review`, remote and local;
- forward local `main`;
- paste `git rev-parse main`.

If the classifier blocks the push, Corey runs the same command from your checkout.

## The deploy

Run `npm run verify:deploy` **in the foreground**, then read the Production build's cache line.

**`e2e-prod`:** read the run Vercel's Production record fires, or dispatch on `main` if none has started a few minutes after READY. Give the record's time against READY.

**No flush.** Before a Dec 12 box exists, nothing these reads return renders differently, and an older cached reading carries no `decidedOn`, which reads as election day.

Paste once, after `e2e-prod`. The next HO's roadmap block opens with this go as taken.
