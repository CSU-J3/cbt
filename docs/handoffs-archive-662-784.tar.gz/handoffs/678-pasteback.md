# HO 678 STEP 0 — inventory and exposure, FILLED. Post-HALT re-paste.

`vercel whoami` → **`csu-j3`** (exit 0), team `csu-j3s-projects`, project
`congressional_terminal`. Same binary in both shells
(`scoop\apps\nodejs\current\bin\vercel`, **53.4.0**), one shared config root.

Read-only. HEAD `4383651` = `origin/main`; tracked tree clean, 13 untracked design
files, unchanged. `env ls` run for Production, Preview and Development.

## The finding (unchanged)

**`CONGRESS_API_KEY` is in the production database in cleartext, 3 rows.**
`cron_runs.error_message` **and** `cron_runs.payload`, route `/api/sync`, at
2026-06-17T09:14:32Z, 2026-06-18T09:45:59Z and 2026-08-08T18:00:47Z — the live value,
matched in full. The 500 responses those rows record carried the key in their JSON body.

## Closure table — filled

Values never printed. Vercel reports every value as `Encrypted`; the age column is
Vercel's `created`. `A`–`G`: `0` = clean, measured.

| # | secret | consumers (first 3) | held (Vercel / local) | age evidence | A | B | C | D | E | G scope | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | **CONGRESS_API_KEY** | `lib/sync.ts:92`, `lib/summarize.ts:88`, `lib/bill-rosters-sync.ts:77` | Prod+Preview / `.env` | 120d (Vercel) | 0 | 0 | 0 | **3 prod DB rows, live value**; 7 live sources | 0 | **Preview too** | **ROTATE NOW** |
| 2 | **CRON_SECRET** | `app/api/cron/*/route.ts` (24 refs) | Prod+Preview / `.env` | 120d (Vercel) | 0 | 0 | 6 copies in `.claude/settings.local.json` | value passed as a literal in tool-call commands | 0 | **Preview too** | **ROTATE NOW** (ruling 2) |
| 3 | **TURSO_AUTH_TOKEN** | `lib/db.ts` (94 refs) | Prod+Preview / `.env` | 120d (Vercel); JWT `iat` 2026-05-02, **no `exp`** | 0 | 0 | 0 | none | 0 | **Preview too** | NO ACTION + **WATCH** (non-expiring) |
| 4 | **GEMINI_API_KEY** | `lib/summarize.ts` (7 refs) | Prod+Preview / `.env` | 120d (Vercel) | 0 | 0 | 0 | none | 0 | **Preview too** | NO ACTION |
| 5 | **FEC_API_KEY** | `lib/fec.ts:36` (2 refs) | **Prod only** / `.env` | 104d (Vercel) | 0 | 0 (value); `K0Ue` = YES, 5 tracked files | 0 | none | 0 | Prod only | NO ACTION (ruling 3) |
| 6 | **FMP_API_KEY** | `lib/markets.ts` (5 refs) | **Prod only** / `.env` | 82d (Vercel) | 0 | 0 | 0 | none | 0 | Prod only | NO ACTION |
| 7 | **FRED_API_KEY** | `lib/markets.ts:251` (1 ref) | **Prod only** / `.env` | 82d (Vercel) | 0 | 0 | 0 | none — error path key-stripped | 0 | Prod only | NO ACTION |
| 8 | **LDA_API_KEY** | `lib/lda-sync.ts` (3 refs) | Prod+Preview / `.env` | **31d** (Vercel) | 0 | 0 | 0 | none | 0 | **Preview too** | NO ACTION |
| 9 | **AUTH_SECRET** | `auth.ts` implicit | **Prod only** / not local | 68d (Vercel) | shape-only 0 | shape-only 0 | shape-only 0 | not traced | 0 | Prod only | NO ACTION * |
| 10 | **AUTH_GITHUB_ID** | `auth.ts` implicit | **Prod only** / not local | 68d (Vercel) | shape-only 0 | shape-only 0 | shape-only 0 | not traced | 0 | Prod only | NO ACTION * |
| 11 | **AUTH_GITHUB_SECRET** | `auth.ts` implicit | **Prod only** / not local | 68d (Vercel) | shape-only 0 | shape-only 0 | shape-only 0 | not traced | 0 | Prod only | NO ACTION * |

`*` Rows 9–11 are **NO ACTION on partial coverage**, and the asterisk is the point: the
values are not on this box, so the exact-match instruments could not run on them. They
were covered shape-wise only (JWT / `gh*_` / `AUTH_*=` assignment), which found nothing.
Absence of evidence, with an age cell well inside the window — not a clean bill.

**No new ROTATE row.** The two ROTATE NOW rows are rulings 1 and 2, both already made.
Every former OWNER-SLOT row resolved to NO ACTION once `env ls` supplied an age.

### Held vs consumed — the diff

**12 variables held in Vercel, all 12 consumed. No dead secrets.** The converse is clean
too: all 11 secret names plus `TURSO_DATABASE_URL` are present in Production, so the
HO 579–581 `LDA_API_KEY` failure mode is not recurring — LDA now sits in Production **and**
Preview at 31d, the youngest entry in the project.

**Development holds nothing** (`No Environment Variables found`). Local development runs
off `.env`, which is consistent with `.env.production.local` carrying blank app secrets.

`REVALIDATE_URL` is consumed by six scripts but is **not** held in Vercel — correct, it is
a local script target, not a deployed setting, and it is not a secret (see below).

### G — Preview scope, which is the live exposure surface

**Six** entries ship to **every preview build, including every review-ref push**:
`CONGRESS_API_KEY`, `GEMINI_API_KEY`, `TURSO_AUTH_TOKEN`, `CRON_SECRET`,
`TURSO_DATABASE_URL`, `LDA_API_KEY`. Both ROTATE NOW rows are in that set, so the rotation
must cover Preview as well as Production or the burned values stay live on previews.
The Auth.js trio is Production-only, confirming HO 581 from the other direction.

### Age — what the column actually measures

Vercel's `created` is **when the variable was added to the project**, not when the provider
issued the key. The five 120d entries coincide with the repo's first commit (2026-05-03),
so 120d is a **lower bound** on those keys' true age. One independent cross-check exists
and it agrees: `TURSO_AUTH_TOKEN`'s JWT carries `iat` 2026-05-02, i.e. 121 days — one day
either side of Vercel's 120d. Nothing estimated; the bound is named as a bound.

**Ruling 4 — first branch holds.** The maximum age in the filled table is **120 days**.
No cell is ≥ 12 months, so the threshold is struck, and the two api.data.gov keys take a
backlog calendar line instead (owner Corey, cadence annual).

### Configuration, listed not audited

- **`TURSO_DATABASE_URL`** — hostname, no credential. Held Prod+Preview, 120d. Present in
  full in tracked `SKILL.md`, `docs/backlog.md`, `docs/roadmap.md`; public repo, so the DB
  host/org name is disclosed. Harmless without the token.
- **`REVALIDATE_URL`** — **NOT a secret.** An `http://localhost:<port>/api/revalidate`
  loopback target; no query string, no credential parameter. Auth travels separately as
  `Authorization: Bearer ${CRON_SECRET}`. Resolves the handoff's open item 6.

### Diagnostic switches

**16** distinct, reported not audited: `SEED_*` ×10, `PROBE_SAMPLE`, `PHANTOM_GITCHECK`,
`PHANTOM_NAIVE`, `AUDIT_BASE_URL`, `AUDIT_ROUTE`, `GATE_BASE_URL`.

### Operator credentials (Corey's; named, not inspected)

| credential | state |
|---|---|
| Vercel CLI login | **present**, account `csu-j3`, `auth.json` 227 bytes (`token`, `userId`, `refreshToken`, `expiresAt`) |
| git push | Git Credential Manager (Windows credential store) |
| GitHub CLI | `CSU-J3`, `gho_*` in keyring, scopes incl. `repo`, `workflow`, `delete_repo` |
| Turso CLI | **not installed** — a Turso rotation must go through the web dashboard |

## Enumeration — pre-read corrected

- Consumed distinct **41**, not 35: **38** explicit `process.env.<NAME>` plus the 3
  implicit Auth.js reads. Zero bracket-notation reads.
- `.env` holds 10 names; `.env.example` holds 6 and is missing **7** —
  `FEC_API_KEY`, `LDA_API_KEY`, `FRED_API_KEY`, `AUTH_SECRET`, `AUTH_GITHUB_ID`,
  `AUTH_GITHUB_SECRET` **and `REVALIDATE_URL`** — one more than backlog `:37` records.
- `.env.production.local` premise **confirmed**: every app secret blank.

## Instruments

**A — history.** gitleaks **8.30.1**, `--log-opts=--all --redact`: **1128 commits, 0
findings**, re-run at paste time, same. Second instrument: exact-value + 8-char-prefix
search for all 10 held values over `git log --all -p` (**1141 commits, 321,623 lines,
24.0 MB**) and over the **134 reflog-only commits** `--all` never reaches (35,049 lines,
4.5 MB): **0 hits on any of the 8 secrets.** `git stash list` empty.

**The 13-commit gap is closed and the pre-read's explanation was wrong.** The hypothesis
was `package-lock.json`-only commits skipped by the path allowlist; measured, there are
**0** such commits. Real rule, established on purpose-built control repos: **gitleaks
counts a commit only if it has ≥1 added text line** — isolated 2-commit repos scanned 1
of 2 for empty, pure-deletion and rename-only, 2 of 2 for a normal add. CBT has 17
commits with 0 added lines; the **4** gitleaks counts anyway are exactly the 4 that also
contain a Modified file (`5bc03aa3`, `1c5869b7`, `bcc8ef92`, `8c85d6e0`) — a
removals-only modification still presents a post-image, a pure deletion does not.
**1141 − 13 = 1128, exact.** None of the 13 can carry a secret: a commit that adds no
line introduces nothing, and every deleted line was added by an earlier scanned commit.

**B — tracked tree at HEAD.** All **974** tracked files: **0 secret hits.** Working tree
verified clean for tracked paths, so disk = HEAD. **`K0Ue` = YES**, still the current
`FEC_API_KEY`'s first four characters, in **5** tracked files, not the 3 the pre-read
named: `docs/backlog.md:30`, `:603`, `docs/roadmap.md:281`,
`.claude/skills/cbt/SKILL.md:1678`, `:2274`. Origin visible in-repo: `lib/fec.ts` logs a
`maskApiKey` rendering keeping first and last 4 — the mask discloses 8 of 40.

**C — untracked and ignored.** 13 untracked-not-ignored: **0**. Ignored
`docs/handoffs/`, **1,536 files: 0** — no secret was ever pasted into a handoff. All
other ignored files, **648 / 184.5 MB**: one real hit — `CRON_SECRET` in cleartext **6
times** in `.claude/settings.local.json`. `git add --dry-run` confirms the file ignored
(authoritative, not `check-ignore`); `git log --all` shows **0** commits touching it.
Second hit was a **false positive**: `TURSO_AUTH_TOKEN`'s 8-char prefix in
`.env.production.local` is the generic `eyJ…` JWT header, shared with an expired
`VERCEL_OIDC_TOKEN`. **Prefix-8 is not a discriminator for JWT-shaped secrets.**

**D — emission paths.** **9** `throw new Error(\`fetch ${url}\`)` sites in `lib/`, of
which **7 carry a key-bearing URL**: `sync.ts:92`, `summarize.ts:88`,
`bill-rosters-sync.ts:77`, `nominations-sync.ts:125`, `votes-sync.ts:142`,
`amendments-sync.ts:140`, `amendment-votes-walk.ts:66`; plus **4** diagnostics (pre-read
named 3; add `scripts/diagnostic/sync-measure.ts:58`). Two pre-read items corrected,
both already safe: `summarize.ts:79` passes a keyless congress.gov payload URL, and
`markets.ts:251` is deliberately key-stripped (`keyLen` only); `senate-votes-sync.ts:140`
is keyless (senate.gov XML).

**The sink is the point.** Every such throw crosses `wrapCronRoute`
(`lib/cron-log.ts:158-186`), whose catch takes raw `err.message` into **both** the JSON
response body **and** `finishCronRun(...)` → `cron_runs.error_message`. On the *success*
path `chronicErr` persists the same key-bearing strings on a **200** run. Measured: **3
rows** hold the live key. A sweep of **348 text columns across all 58 tables** finds it
in `cron_runs` and **nowhere else**, and finds **no other secret in the database at
all**. Nothing renders the column — `getRecentCronRuns` and `getLatestCronRun` have
**zero callers**, `/api/health` only boolean-tests for `POLY-SHUTDOWN`. Durable storage,
not a public surface.

**E — client bundle.** Fresh `next build` (exit 0, under the pinned Next 15.5.15, taken
before the tree was dirtied). `.next/static`, 90 files / 2.1 MB: **0**. Entire `.next`,
331 files / 8.7 MB: **0**. Corroborated: **0** `NEXT_PUBLIC_` variables, and of **70**
`"use client"` files none reads a secret env var.

**F — age.** Filled from `vercel env ls` above, plus the `TURSO_AUTH_TOKEN` JWT decode
(`EdDSA`; claims `a, iat, id, rid`; `iat` 2026-05-02T18:00:20Z; **`exp` absent →
non-expiring**). No age estimated; no file mtime used.

**G — scope.** Filled above. Six entries reach Preview.

## Controls — every zero was fired against a control

| instrument | control | outcome |
|---|---|---|
| gitleaks ruleset | planted fake AWS key in throwaway repo | **fires** — a 0 means something |
| gitleaks commit accounting | 4 repos isolating commit shapes | rule established, gap closed exactly |
| targeted grep | synthetic bait, all 8 patterns | **caught a dead pattern in my own instrument** |
| targeted grep, negative | placeholder / `process.env` lines | 0, as required |
| value + file scanners | real value planted in buffer / file | detects, every run |
| DB probe | known-present value in `cron_runs` | 3 rows → returns non-zero |
| Vercel log text search | known-present string `bill-rosters` | **fails — zeros void** |
| redaction gate | append a real value to the paste | detects → gate can fail |

**The grep control earned its place.** The first run reported `hits=0` across all
history while firing only **7 of 8** patterns: `env-assign` — the one pattern that
catches a committed api.data.gov key, the exact shape gitleaks is blind to — matched
nothing on bait built to trip it. The heredoc had collapsed `\\` → `\`, so `"\s*"`
reached Node as literal `s*`. The regex still **compiled**; it meant something else.
Rewritten with regex **literals** (a lost backslash is then a syntax error) the control
went 8/8 and the corrected instrument found 2 hits in `c578e094`, the initial commit —
both documentation placeholders, neither matching a current value. **An uncontrolled
`hits=0` would have shipped as a clean history scan.**

**The Vercel runtime-log instrument does not work and its zeros are void.** The
`api_key` text query over 24h returned "No logs found", but its control — a search for
`bill-rosters`, logged on every tick — **times out** at 24h, 6h, and scoped to one
deployment. And `level=["warning"]` over 24h returns nothing while `statusCode=500` over
the same window returns a line labelled `[warn/serverless]`: a demonstrated false zero.
Structured counts do work: 2,449 events / 24h, 1 × 500, that 500 being
`/api/cron/bill-rosters` with `[db] timeout, retrying` — not a key-bearing fetch.
Retention is 1 day, so the three known emissions are outside it regardless. **Instrument
D's log half is UNAVAILABLE, not passed.** It changes no verdict; the database evidence
already decides row 1.

## Redaction gate

Run against this exact text: per secret, full value and 8-char prefix, plus a sha256
check, with a control proving the gate can fail.

**All 8 secrets: full=0, prefix8=0, hash=0.** `TURSO_DATABASE_URL`: 0/0.

It failed twice before passing on the first version of this document — catching
`REVALIDATE_URL`'s full value written verbatim into the classification note, and an
8-char JWT prefix in the prose about the header collision. Both redacted. `K0Ue` appears
as the one permitted fragment.

**STEP 0 closed.** Proceeding to STEP 1 per ruling: no new ROTATE row, ruling 4 first
branch holds.
