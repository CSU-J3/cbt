# HO 676 — the roster refresh sync: give `bill_cosponsors` and `bill_related_bills` a maintenance path

**Read this file in full before executing anything. Execute in order. HALT conditions are hard stops — report and wait, do not improvise past them. Four HALTs: the STEP 0 pricing table, the coverage-watermark ruling, the bounded-slice measurement, and the pre-land review ref. Nothing lands on `main` before the last is approved.**

Base: `main` at `7aecdcc` (HO 675 landed) or later. Clone fresh; verify HEAD before starting (`docs/method.md` § Session start). Number per method: max(roadmap pointer 675, highest commit-subject 675) + 1. Environment: code edit + `npm run build` then `npm run typecheck` (build first), plus **network access to the Congress.gov API** and **write access to the DB** for the bounded slice. **Bind check mandated on any local server start.** § Gates applies in full: this is write-heavy, so *a write instrument that does not read back is not an instrument*, and every zero is stated with a control that can produce a non-zero.

## The gap, dated and measured

HO 674 ingested both rosters. HO 675 surfaced them. **Neither shipped a refresh**, and `docs/backlog.md:80` was filed at the HO 675 close with the measurement rather than the argument:

- Backfill's last write: **2026-08-20T01:02:19.943Z**.
- **`119-s-5354`** — `cosponsor_count` 6, zero roster rows, upserted **2026-08-20T03:28:43Z**, *after* that write. A bill arrived with no roster on the first day.
- 5 bills carry `cosponsor_count > 0` with zero roster rows, of 13,929 carrying a count (corpus 17,728). **Four of the five are uncharacterised** — backfill miss or the same class as `119-s-5354`. Telling them apart is **this HO's first question**, and the entry says so deliberately rather than guessing.

`/api/sync` runs `0 */6` and adds bills. Nothing populates their rosters. Cosponsors also accrue to existing bills without moving `updateDate` (HO 674 measured 13.8% count drift, one-directional, stored always low), so existing rosters go stale as well as new ones arriving empty.

**The lesson the arc produced, and this HO is its consequence:** HO 674's close criterion — *readable from the local DB without a network call* — is true forever after a one-shot backfill. It could not have caught this. A criterion that cannot become false again does not close a living thing.

## Scope

In: a refresh path for both rosters — the trigger, the selection query, the fetch, the write, and its cron wiring. Plus a `revalidateTag("bill-rosters")` caller, since HO 675 shipped that tag with no writer.

**Out, named so it is not absorbed:**

- **`bills.cosponsor_count`.** It stays. This HO does not derive it from the roster, does not drop it, and does not reconcile the 13.78% disagreement the panel now shows. That is `:81`, and `:81`'s premise — *once the rosters exist, the roster is the better source* — becomes true only once this HO lands, which is the reason to keep them separate rather than the reason to merge them.
- Every component and every route. **No render surface changes.** The panel already reads whatever the tables hold.
- The backfill script's own resume defect except as it bears on the cron path (see STEP 0.3).
- `/api/sync`'s unconditional `bills` flush — ruled deliberate at HO 671 on the try/catch discriminator. **Do not re-derive it and do not "fix" the asymmetry.**
- The `docs/design/` tracking policy; the nine `if (await X.count())` e2e guards; the two `SponsorPhoto` implementations; `HeaderBar` `IN BETA` + clock; `--font-mono` → Plex Mono; the `/welcome` tape unification; `/api/version`'s `builtAt: null`. All filed, none due.

## STEP 0 — enumerate and price; HALT

**Controls first.** Table (candidate · verdict · evidence `file:line` · destination) covering at least:

### 0.1 Characterise the five

The entry deliberately left four uncharacterised. Do that first, because it decides whether this HO also needs a repair pass or only a forward path. For each of the five: `cosponsor_count`, roster rows, `updated_at`/upsert time against the backfill's last write, and whether the API returns a roster today. **Classify each as: arrived-after-backfill, backfill miss, or something else.** A backfill miss is a different bug from a missing cron and must not be absorbed into one fix.

### 0.2 The trigger

HO 674 STEP 0.4 worked it out: **active roster size against `cosponsor_count`**, where active means `sponsorship_withdrawn_date IS NULL` — the SKILL schema comment records why, since `pagination.count` excludes withdrawals while the list includes them. Re-derive it at HEAD and state:

- The exact selection query and its cost.
- **Re-measure the disagreement.** HO 674 read 1,915; the HO 675 close read 1,910 under the withdrawal filter. It moves, so cite nothing — measure it.
- What selects a bill with **zero** roster rows and `cosponsor_count` NULL, given HO 674 measured that NULL is the genuine no-cosponsors case for ~97% but not all (111 of 3,800 had one).
- **What selects for related bills**, which have no count column to disagree with. This is the harder half and the trigger above does not cover it. If the answer is a TTL or an `updated_at` sweep, price it.

### 0.3 The coverage watermark — HALT inside the HALT

HO 674 filed that resume coverage is row-presence, so a genuine empty roster is indistinguishable from an unprocessed bill, at a **~3,800-request tax per resumed run**. That defect sits **directly in this cron's path**: a tick that cannot tell "checked, empty" from "never checked" re-fetches thousands of bills every run.

Rule it in the table with a recommendation and its cost:

- a per-bill `rosters_checked_at` column, or
- a coverage table, or
- accept the tax with the arithmetic showing it fits the budget.

**Do not build before this is approved.** It is a schema decision if it goes the first way.

### 0.4 Cadence and budget

- The rate limit is **20,000/hr**, measured at HO 674 off a live `x-ratelimit-limit` header (SKILL `:46` corrected there). **Price the wall clock against measured throughput, not the ceiling** — HO 674 predicted 1.5h from the limit and took 4h at ~7,500/hr. That error is on the record precisely so it is not repeated.
- Requests per tick under the proposed trigger, at steady state and on the first tick after this lands (which carries the accumulated backlog).
- The proposed schedule, and what else fires in that slot. **Read `vercel.json`** — HO 672 chose 00:00Z for a measurement and found six crons in it.
- Where this runs: its own route, or inside an existing one. If inside `/api/sync`, say what happens to the sync's own budget and error surface.

### 0.5 The flush

`bill-rosters` has no caller. This HO gives it one. State: where `revalidateTag("bill-rosters")` fires, and **whether it is guarded on a write** — HO 671 ruled that an unconditional flush on a scheduled tick is a cost multiplier, not a safety margin, and measured 296 of 300 summarize ticks flushing having written nothing. A roster tick that changed nothing must not flush. Name the signal it guards on and confirm it cannot be truthy while nothing was written, the way HO 671 did for `stats.ok`.

### 0.6 Idempotency and partial writes

The write path must be idempotent per bill. Also: HO 671 filed that the summarize write pair is not atomic and its throw path skips the flush it needed. **Does this HO's write path have the same shape?** If two statements per bill are not wrapped, say so and state whether it matters here.

### 0.7 Out-of-scope confirmations

Confirm nothing under `components/` or `app/` renders differently, that `bills.cosponsor_count` is untouched, and that no existing cron's behaviour changes except by the addition.

**HALT.** Paste the table. If 0.1 shows a backfill miss, that is a second piece of work and the table says whether it rides here or files.

## STEP 1 — the chore commit (after approval)

`git checkout -b 676-review-local` first. One commit, one kind:

`chore(HO 676): refresh the bill rosters on a schedule`

The refresh is a **write instrument** and carries the standing treatment: a header naming exactly what it writes, and **read-only by default** where it is invocable by hand — `--check` reports what would be written, `--write` is required to mutate. The cron path is the exception and says so at the call site.

## STEP 2 — gates

- Build ✓ then typecheck ✓, **re-run immediately before the paste** (§ Gates: a gate binds to the state at the paste).
- `git show --stat` lists only approved files.
- Greps **classified, not counted**. `grep -c` counts lines, `git grep -c` counts files, and against minified or single-line inputs both answer a different question than a presence check asks — that has now cost two HOs in a row. Use `grep -o | sort | uniq -c` or state what the number means.

## STEP 3 — the bounded slice; HALT

**Do not run the first full tick.** Run the refresh over **30 bills**, chosen and named, including:

- `119-s-5354` — the dated case; it must gain a roster.
- A bill whose stored roster is **short** against its count (from the ~1,910), proving accrual is picked up.
- A bill with a **withdrawn** cosponsor (`119-hr-452`, 300 stored / 299 active), proving the trigger does not thrash on it every tick — **run it twice and show it selected zero times on the second pass.**
- A bill with a **genuinely empty** roster, proving the watermark works and it is not re-fetched.
- A bill with related bills, and one with none.

Report with read-back on every write: rows written per table, requests spent, wall clock, and the **idempotency proof** — same 30 twice, second run writes 0 and spends 0 for the unchanged, against a control showing the counter moves.

**Then the flush proof, both directions**, in the HO 671 form: a tick that wrote → the next panel open pays the roster read; a tick that wrote nothing → no flush, no cost. If the guard cannot be exercised in both directions honestly, say so and HALT rather than shipping a guard whose write path was never seen firing.

**HALT.** The first full tick is a separate authorisation.

## STEP 4 — docs commit (`docs: HO 676 — …`)

- **`docs/backlog.md`** — strike `:80` with all three legs of its close criterion answered: a bill introduced after the backfill reads a populated roster with nobody running a script, `revalidateTag("bill-rosters")` has a caller, and the disagreement re-measured and moved off its filed figure. **Name the bill at close; do not choose it in advance.** Amend `:81` in place to record that its premise now holds. Open anything 0.1 or 0.3 surfaced.
- **`docs/roadmap.md`** — one `Also (HO 676)` block, append-only: the trigger, the watermark ruling, the cadence and its arithmetic **against measured throughput**, the flush guard and its two-direction proof, and the five characterised.
- **`docs/method.md`** — **the parked § Gates clause lands here**, if it has not landed already. Verbatim as ruled at the HO 675 close: *a close criterion that cannot become false again does not close a living thing* — ask whether it would still read true if the system stopped being maintained tomorrow; if yes, it describes a state, not a capability. Both citations: `:83` closed on a criterion a one-shot backfill satisfies permanently, and `:81` was load-bearing on a refresh that did not exist. **It is a docs edit in the docs commit, not its own HO, and it is the ride-along that was ruled to wait for exactly this touch.**
- **`docs/oddities.md`** — only if something odd emerged; if nothing, say so in the block.

## STEP 5 — SKILL commit (`docs(skill): HO 676 — …`), self-mod guarded

Its own commit. Minimal edits, every hit classified LIVE-CLAIM vs RECORD first. Expect at minimum: the `bill-rosters` tag entry, which currently says the cron *does not exist yet* and that nothing calls the tag — **both halves are falsified by this HO** and must be rewritten together, not half-corrected. HO 674 and 675 both had to fix a clause that had been corrected by halves; do not make a third.

**No changelog append** unless client-island membership changed, which it does not here.

## HALT — the review ref

`git push origin HEAD:refs/heads/676-review`. Paste: table deltas, `git show --stat`, STEP 2/3 measurements, the backlog numstat with every deletion explained (a strike is an edit; `grep -c '^-[^-]'` is not a deletion count and § Gates carries the reproduction), and the docs + SKILL diffs.

**Deliver the SKILL diff with `--word-diff=plain`, verify it carries markers before offering it, write it to the gitignored artifacts directory, and tell Corey explicitly to attach it to the chat.** Writing the file is not delivering it.

Remote claims via `git ls-remote`. **The SKILL diff needs explicit approval.** After approval: fast-forward `main`, delete the ref, verify with `git ls-remote --heads origin`.

---

read and follow 676
