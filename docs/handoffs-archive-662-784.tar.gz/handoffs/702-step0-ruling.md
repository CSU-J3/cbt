# HO 702 — STEP 0 ruling (architect, 2026-09-07). Row 4's design is yours; build it with a counter, a control and a ratio first.

The HALT is right and the finding under it is better than the row asked for. The estimate's mechanism was mine and it was wrong in a way worth writing down: I estimated **post-load** mutation volume and forgot that an observer on `document` from the first script tick records the **parser** building the server's bytes — 99.4–99.98% of the records, matching the served opening-tag counts almost exactly, which is the proof. The parser and the fire overlap in time (DCL 280–758 ms against `fire-t` 190–1215 ms), so a cap would truncate mid-batch and *records before the fire* would mean *the parser*. Own that in the block as the architect's estimate, with the tag counts that falsified it.

## 1. Discriminate at record time — accepted, with three additions

Your discriminator is right in shape: while `document.readyState === "loading"`, the parser only ever **appends to the currently-open element** and never removes, so a record with `nextSibling !== null` or `removedNodes.length > 0` is not the parser. Build it, with:

- **A dropped counter, per phase.** An instrument that discards must say how much it discarded (the HO 687 `GUARD-SKIPPED` rule, one level down): `mut pre=N(kinds) parser-dropped=P rec=+a/-r post=N`. A reading with no `parser-dropped` figure is not a reading.
- **`characterData` during `loading` is counted separately, not assumed clean.** The parser extends a text node that straddles a chunk boundary, which is a `characterData` record; the app's text nodes are short, so it should be rare, and rare is a number, not a word. Keep them all, count them as their own kind, and let the ratio say.
- **After `DOMContentLoaded`, nothing is filtered.** Post-load volume is 4–94 records; the filter exists for one phase only, and the dump names the phase boundary time so a reader can see where the rule changed.

**Measure the ratio in one run before building the channel into the spec — yes, do it.** Quiet hits of `/`, `/changes`, `/members`, `/trends`, `/races`: raw versus filtered `pre`, per kind. Expected filtered `pre` on a quiet hit: `~0–50 (estimate; this run measures)`. **If any route reads more than 5,000 after the filter, HALT again** with the surviving record kinds and their targets; that is a second mutation source nobody has named, and it needs a look, not a second filter.

## 2. Two controls, because a filter that keeps nothing looks like a quiet page

- **The planted move.** In the amplifier worktree only, throwaway: an inline `<script>` early in `<body>` that, while `readyState === "loading"`, inserts one element **before an existing sibling** and removes one text node. The filtered `pre` must contain exactly those two records, with the correct kinds and targets, on every hit; the parser records around them must be in `parser-dropped`. Removed after, never committed. Without this, an empty `pre` on a fire is indistinguishable from a filter that eats everything.
- **The streaming inventory, which decides whether the hypothesis has a mechanism at all.** For every crawl route, the served SSR bytes: does the page carry Suspense boundary completion — `<template id="B:…">`, `$RC(` / `$RS(` inline scripts, `<!--$?-->` pending markers, `<div hidden id="S:…">` containers? Table by route: markers present or not, count, and whether the firing routes in this HO's set (`/trends`, `/races`, HO 700's `committee-detail`, `primaries`, `electoral`, `report-detail`, `dashboard-v2`) carry any. **If none of the firing routes completes a boundary after the initial flush, the streaming half of the hypothesis has no mechanism and the block says so**; the filtered `pre` on fires is then compared against quiet hits for anything else (a boot script, a font swap touching text, an extension-free Chromium has few candidates, and that is the point of listing them).

## 3. Per-crawl dump preservation — build it into the runner now

`playwright test` wipes `test-results/` at start, and M1's `/races` dump is gone. That is a recorded loss and the reason for a rule: **the runner copies every `*.json.gz` under `test-results/` to a per-crawl directory before the next crawl starts** (`docs/handoffs/702-artifacts/<arm>-<n>-<utcstamp>/`, gitignored), and prints the count copied. `pageerr-matrix-697.ts` gets the same three lines; back-to-back crawls without it are the HO 685 silently-missing-sample shape with a different cause.

## 4. Arm B narrows, and stays

The byte-offset mapping of the A2 stack to source `:7616–7622` is a real result: **`site=` is free from today's stack** for the one site proven by identifier match, and the other seven are shape-inferred and said so. Record the mapping table in the block. Arm B still buys the two fields nothing else can: the **fiber's type chain** (the component) and **`found=`**, the DOM node React was holding when it refused — which is the field a mutation log can never produce and the one that decides between *a node the parser put there* and *a node a script put there*. Keep the planted-mismatch control as specified; keep the worktree for it.

## 5. Small things, ruled

- The tree is not amplifying at these hours (0 · 1 against `main`'s 1 · 0, and HO 700's 1 · 1 against 0 · 2). Say *the tagged tree* in the block and the annotation, not *the amplifier*; the tag keeps its name because names are pointers. What it still buys is a second tree that fires in production mode locally, and the planted-mismatch control needs a worktree anyway.
- Foreign PID on `:3001` from 11:22, left alone: right. `AUTH_SECRET` absent from `.env`, servers restarted with a throwaway: right, and the block notes that a missing secret reddens the console gate on every spec, so the next runner checks for it before starting.
- **One shell still running** at the halt. Name it; kill by PID what is yours (the 696 §9 shape, third time).
- Keep the worktree and both builds until STEP 2 is done; tear down at the end as the handoff says.

## 6. Then

Ratio run → planted move → streaming inventory → Arm A into the spec with the counter → falsification (i)–(iii) plus the two controls → Arm B as written, planted mismatch first → SKILL alone → docs. HALT again only on §1's 5,000 or on Arm B's planted mismatch failing to name its own component.

read and follow 702 — STEP 0 ruled, discriminate at record time
