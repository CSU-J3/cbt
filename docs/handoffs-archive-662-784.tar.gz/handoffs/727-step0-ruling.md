# HO 727 — STEP 0 ruling and go

STEP 0 accepted. Seven rows read, three handoff errors corrected, two forced consequences correctly identified and flagged rather than absorbed. Proceed to STEP 1 on the **delete branch** (row 7 read no-op ×9). Rulings below, then the corrections to carry.

## The 204px move: proceed, and the close criterion is rewritten because yours was right

**Your flag is correct and the handoff's close criterion was wrong.** *"The CTA block's left edge measured unchanged"* is true only of the grid box, and the grid box's left edge was the flourish. Every element a reader can see — the stats strip, ENTER TERMINAL, LOGIN, both microcopy lines — moves **−203.8px at 2560** and **−203.9px at 1920** on the collapse. That is the change, and stating it as "unchanged" would have hidden it behind a true sentence about the wrong box.

**Proceed anyway, because there is no second option that does not invent something.** The three candidates:

- **Collapse (A)** — content anchors to `.right`'s own left edge, 1486.9 at 2560. Moves −203.8.
- **Empty track (B)** — moves −189.8 *and* leaves a dead `auto` track plus a phantom 14px gap. Strictly dominated by A: same visual move, worse geometry.
- **Hold the position (C)** — requires a replacement spacer, or right-pinning `.right`'s content. That is a new design element Corey did not ask for, introduced to preserve an offset that was never itself a ruled value: the stats sat at 1690.7 *because* a decoration occupied 189.8px to their left, not because 1690.7 was chosen.

A is therefore the non-inventing branch and is not a fork under `docs/method.md` § Roles. **It is a visible change on a ruled surface, so it is named in chat with its number and it is read at the capture review before the FF**, which is the natural place for the architect to call it back. If he does, C becomes a real fork with your readings already in hand.

**The close, restated so it can fail.** At 2560: `.stats`, `.btnPrimary` and `.micro1` all read left = **1486.9**, equal to `.right`'s left edge, and the grid's resolved `grid-template-columns` is two tracks with no zero-width leader. At 1920: all three at **1119.2**. At ≤1460: every x unchanged from the pre-state and the grid **25px shorter**. `documentElement.scrollWidth === clientWidth` at all seven widths, post-fix, as it read pre-fix. Reads if the work never happened: a 189.8px first track at 2560 and the three elements at 1690.7.

**One reading to add**, since the block moved 204px toward the lead: quote the right edge of `.lead` and the left edge of `.stats` at 2560 and 1920, before and after. They are in separate banner columns so grid construction forbids overlap, but the *optical* gap closes by 204px and nobody has looked at it. A number, not a judgement — file it in the roadmap block either way.

## Rulings on your flags

**Commit count — three, not four.** My error. `fix` · `docs(skill)` alone behind the self-mod guard · `docs`. Kinds pure.

**A (`:75-77`, the `.ctagrid` comment).** Approved as forced. Drop the clause *"and the flourish hangs in column 1 pointing across at ENTER TERMINAL"* and nothing else — the rest of that comment (*stats align to the primary button, each microcopy line sits under the button it describes*) survives the collapse intact, since stats spans 1/3 and `.btnPrimary` / `.micro1` share column 1. Confirm that in the diff rather than assuming it.

**B (`:304-305`, the HO 699 comment).** Approved, your wording, with one constraint: **do not restate the 1459 boundary as current.** That comment is a RECORD of a measurement taken when the boundary existed, and measurements are about the table they were taken on. Your clause — *"came from the 1460 collapse (the base layout since HO 727, when that block was deleted as a no-op)"* — reads correctly because it is past-tense about the origin and present-tense about the base. Land it as written. Do not touch the 1459–430 range language around it.

**The 560 `.stats` rule.** Approved. `grid-column:1` alone; the new base supplies `grid-row:1`, and adding a redundant declaration would be the drift this module's comments exist to prevent. Renumber the other four to 2–5 as specified, keeping `.btnPrimary`'s explicit rule (the 560 order interleaves `micro1` between the buttons and does not follow from base).

**`:122-124`, not `:121-124`.** Correction accepted; `:121` is a blank separator. Same for the 560 block at `:330-339`. Both are STEP 0 doing its job — carry your line numbers, not the handoff's, and re-derive at your HEAD.

**SKILL `:1858`.** Correctly excluded. `:1847` is the only edit.

**The gitignored row-3 hits.** None is a dependency; the `docs/design/scratch/` pair is below the citation gate's ignored directory by construction and the `.cache/ballotpedia` ♥ is candidate text. No HALT, no allowlist entry, nothing to file.

## Carry into STEP 3

The roadmap block records, beyond the standard: the −203.8 / −203.9 figure as the visible change with A/B/C priced as above; the 25px rise at ≤1460; row 7's nine-width no-op evidence as the warrant for deleting the 1460 block rather than editing it; and the lead-to-stats gap reading. Open loops **260 live / 263 struck at open** — your count reconciles against HO 726's stated close, so use yours.

Captures per the handoff, before-set already taken: `/welcome` at 2560, 1440, 430, 390 plus reduced-motion, full page and CTA crop, rects beside each. Narrow gate both widths. `check:design-citations` → `OK` from a fresh clone of the review ref. `welcome-formats-mock.html` byte-identical, proven by `git status`.

Go.
