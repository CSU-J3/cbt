# HO 724 — STEP 0 paste, re-delivered as a file (relay swallowed the front of the chat paste)

STEP 0 done; HALTed there. Nothing was created, edited or committed in the repo; the only files were two repo-ignored scratch probes, one already deleted. Six of eight rows read exactly as predicted. Row 7 found two machine behaviours the probe must handle, and there is a fourth place that states what a NULL summary means.

## STEP 0 table (read at `5dcdf9e`)

| # | expected | read | verdict |
|---|---|---|---|
| 1 | `main` at the HO 723 tip alone; clean; 723/723 → 724 | `ls-remote`: `5dcdf9e4a669fa952dcf47827c3a901b0566b4c6 refs/heads/main` only; porcelain clean; pointer "Also notes now run through HO 723", highest HO in commit subjects 723 → **724**; Windows box (`yellocake`) | as expected |
| 2 | quotes as in ground truth | `report-generation.ts:1749-1751` ("Re-running the CLI for the same week overwrites rather than erroring"); `:1763-1767` ("NULL here is a real state (the grounding gate or the sentence cap refused the generation), not 'not yet populated'"); `:1782` `summary_text = excluded.summary_text`; `:1793` `report.summaryText ?? null`; `:1736-1745` (8 fields, no summary). `route.ts:76` `let summaryText: string \| null = null`; `:95-105` carries `summaryText`. `generate-report.ts:24-33` (8 fields). Backfill `:47` `WHERE summary_text IS NULL`, `:73` `UPDATE reports SET summary_text = ? WHERE slug = ?`. `migrate.ts:90-97` (6 columns), `:1670-1672` (three INTEGER `ensureColumn`), `:1673-1680` ("NULL means 'no summary for this week' … never 'not yet backfilled'"). `queries.ts:1217-1222` (the `IS NOT NULL` subqueries). `db.ts:63-70` (lazy `getDb()` reading env on first call). SKILL `:1146` "**A refusal stores NOTHING and is not retried here** — …"; `:1814` "Manual recovery: `npm run report` (prior week) or `npm run report YYYY-MM-DD` (specific week start)."; `:1690` "The summary is a SEPARATE row lookup from `latest`, and that is load-bearing". `@libsql/client` `^0.14.0`, installed 0.14.0. `report-generation.ts` imports nothing from `next/*` (only a comment at `:1715` names `next/cache`). Backlog close quoted verbatim, but the line is now **`:17`** (HO 723 inserted its OPEN LOOPS line at `:14`) | as expected; `:1782` is not yet `COALESCE` |
| 3 | `:1782` alone; that plus backfill `:73` | `git grep -n "excluded.summary_text"` → `lib/report-generation.ts:1782` (plus the backlog line's prose); `git grep -n "summary_text = "` → `:1782` and `scripts/backfill-week-summaries.ts:73` (plus the same prose) | one clause to change |
| 4 | build 0 · typecheck 0 | `BUILD EXIT=0` · `TYPECHECK EXIT=0` | as expected |
| 5 | `2026-08-31` = 124; `2026-09-07` present; four older rows | prod host `cbt-csu-j3.aws-us-west-2.turso.io`, SELECT only: `2026-09-07` n=**200** created 2026-09-14T09:30:23 · `2026-08-31` n=**124** created 2026-09-07T09:30:19 · `2026-08-24` n=171 created 2026-08-31T09:30:30 · `2026-08-17` n=116 created 2026-08-24T09:30:28 · `2026-08-10` n=238 created 2026-08-17T09:30:42 · `2026-08-03` n=**NULL** created 2026-08-10T09:30:32 | as expected; the control later reads repeat |
| 6 | the 09-14 and 09-07 ticks, `{"chars":n}` matching row 5 | `2026-09-14T09:30:04.561Z success 19432ms summary={"chars":200} error=null` · `2026-09-07T09:30:04.216Z success 15043ms summary={"chars":124} error=null` · `2026-08-31T09:30:20.272Z success 10595ms summary=null error=null` | matches row 5; `chronicErr` → `cron_runs.error_message` confirmed at `lib/cron-log.ts:76` (`finishCronRun`) |
| 7 | `c = 1`; file created and removed; number first | **The prescribed `tsx -e` form printed nothing and exited 0.** Re-run from a scratch file: `c = 1`, `file created: true`, then **`EPERM`** on `rmSync` right after `db.close()` | **two findings (1, 2)** |
| 8 | the CLI binds `null` at `:1793` | `generate-report.ts:24-33` passes no `summaryText` → `report.summaryText ?? null` binds NULL | as read |

## Findings

1. **A multi-line `npx tsx -e '<newline>…'` script executes nothing on this box and exits 0.** Bisected in Git Bash:
   - `npx tsx -e 'console.log("sync-line")'` prints.
   - A one-line async IIFE prints.
   - A one-line `import("./lib/db").then(...)` prints `db function`.
   - The same code with the script beginning on a new line prints **nothing, not even a leading `console.log("start")`**, and a `process.on("exit")` handler in it never fires.

   The script is not run at all. The likely mechanism is `npx` resolving through `npx.cmd`/`cmd.exe`, which cuts an argument at the first newline, but it is **unconfirmed**. The probe is a file, so STEP 1 is not exposed.
2. **An `@libsql/client` 0.14 `file:` database cannot be deleted immediately after `db.close()` on Windows (`EPERM`).**
   - A fresh process deletes a leftover file fine.
   - `rmSync` while open: EPERM. Right after `close()` (`closed=true`): EPERM. After 200ms: EPERM.
   - A retry loop polling every 25ms released after **154ms, 161ms and 289ms** over three runs.

   Proposed: step 8 deletes with a bounded retry and prints whether the file went; step 2's stale-file delete stays as is. Otherwise step 8 throws after `PRESERVES=` and the exit code stops meaning legs B, C and D.
3. **A fourth place states the old NULL/refusal semantics:** `app/api/cron/weekly-report/route.ts:70-75`, "A REFUSAL STORES NOTHING AND IS NOT RETRIED HERE … The week simply has no summary, and the dashboard falls back to the last week that does". It goes false the same way SKILL `:1146` does. Proposed: a one-clause amendment in the `fix` commit, a forced consequence. SKILL `:1690` ("the newest report may have no summary…") stays true.
4. **`cron_runs` cannot discriminate refused from never-attempted for rows before HO 689.** The 08-31 tick predates `4d4f478` (feat(HO 689), 2026-09-03) and carries neither `summary` nor `chronicErr`. The `2026-08-03` NULL and the `2026-08-24` 171 (a backfill, since its `created_at` is the 08-31 tick's) are not readable off `cron_runs`. Proposed: the rewritten comments date the discriminator from the 2026-09-07 tick.
5. **Deviation named:** row 7 ran from a scratch file instead of `-e`, because of finding 1.

## HO 723 post-FF sample (owed)

Production `34896943834` on `5dcdf9e`: completed, `success`, smoke job success; 37 route lines, all 75 `pageErr=` readings 0. It is a `deployment_status` sample, not a daily. Preview `34896934850`: narrow-preview success, `smoke` skipped.
