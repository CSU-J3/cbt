# HO 701 — README refresh: the public doc catches up to the repo it describes

Docs kind, one commit (plus the roadmap block), SKILL untouched expected, no code. Corey flagged the README; the architect audit at `15cde5e` found its core self-description stale in three eras at once — the auth arc (HO 355/361), the Pro cron migration (HO 474/475), and the surface growth since (lobbying, news-as-route, electoral consolidation, amendments/nominations, patterns, watchlist, trades).

**Numbering, stated so it is not read as drift:** the roadmap pointer and highest commit subject both read **699** at authoring, so the method arithmetic yields 700 — but **HO 700 (fire-time snapshot) is authored and in flight against the same base**, so this HO takes **701**. If the pointer reads 700 at your session open, the arithmetic agrees; if it still reads 699, this paragraph is the named deviation. The two HOs touch disjoint files (700: `e2e/smoke.spec.ts`, a diagnostic, SKILL; 701: `README.md`, roadmap) — either order lands cleanly under the concurrent-sessions rules (method § Session start).

**The principle applied (non-fork architectural call, method § Roles):** volatile enumerations pointerize — env keys point at `.env.example`, schedules at `vercel.json`, scripts at `package.json` — and prose keeps only the stable shape plus the handful of cadences that characterize the system. The old Deployment section rotted precisely where it enumerated: it still names three GitHub-Actions workflow files that do not exist.

## Ground truth at authoring (fresh clone at `15cde5e`, 2026-09-07)

Every claim below was read, not recalled. Re-derive line numbers at your HEAD; anchors are as-of this SHA.

- `README.md` is 148 lines; last substantive touches `90dc6ad` (HO 696, design bullet) and `98e929a`/`7dce645` (HO 662). The stale prose predates all three.
- **Auth exists:** `package.json:73` `next-auth ^5.0.0-beta.31`; `app/page.tsx:69–74` bounces an anonymous, no-`ct_seen` visitor to `/welcome`; `components/LandingCTAs.tsx:54` `signIn("github", { callbackUrl: "/" })`. README line 9–10 says "Single user, no auth."
- **Cron topology is native Vercel end-to-end:** `vercel.json` carries `"regions": ["pdx1"]` and **18 cron entries** — `/api/sync` `0 */6`, summarize `*/10`, news `*/30`, markets `0 */4` + `?source=fmp` `0,30 13-21 * * 1-5`, kalshi `15 */2`, lda `0 8`, lda-rollup `0 22`, amendments `0 7`, nominations `0 9`, bill-rosters `40 */3`, committees `0 */12`, primaries `0 0,12`, race-challengers `30 12`, sync-votes `0 10`, rating-history `0 15`, sync-race-ratings `0 11 * * 3`, weekly-report `30 9 * * 1`. README lines 82–93 describe a Hobby daily chain plus `markets-tick.yml` / `markets-daily.yml` / `kalshi-tick.yml`.
- **`.github/workflows/` holds exactly:** `ci.yml`, `design-citations.yml`, `e2e-prod.yml`. None of the three files README names exist.
- **Deploys are git-integration, not CLI:** method § Environment ("a review ref yields a Preview"; `e2e-prod.yml` arms on `deployment_status`, Production only); `scripts/verify-deploy.ts` confirms the served SHA. README line 79 says "Deployed via `vercel --prod`."
- **`/api/health`** exists (`app/api/health`, the HO 477 fleet watchdog).
- **Surfaces:** `ls app` → amendments, bill, bills, changes, committee, committees, dashboard-v2, electoral, hearings, lobbying, members, news, nominations, patterns, president, primaries, race, races, reports, search, stale, trades, trends, vote, watchlist, welcome. The nav (`components/HeaderBar.tsx` + `MobileNavDrawer.tsx`, bare-substring href grep) carries: `/amendments /bills /electoral /hearings /lobbying /members /nominations /patterns /reports /watchlist`. README's "What's in it" lists nine surfaces and frames Races as "(`/races`, `/primaries`)"; the nav points at `/electoral` (`app/electoral/page.tsx:1` — "consolidated Electoral surface (HO 333, moved from /races)").
- **News is its own route:** `app/bills/page.tsx:64` — "NEWS is its own route now (`/news`)". README line 21-ish still describes it as a BILLS | NEWS toggle on the bills feed.
- **Trades:** `lib/trades-ingest.ts:1–4` — FMP disclosure pages per chamber, matched to `members`, written to `stock_trades`.
- **Env keys:** `.env.example` is **13 lines** with inline comments per key (the original six + `FEC_API_KEY`, `FRED_API_KEY`, `LDA_API_KEY`, `AUTH_SECRET`, `AUTH_GITHUB_ID`, `AUTH_GITHUB_SECRET`, `REVALIDATE_URL`). README lists six. The "(free, 5,000 req/hr)" figure on line 50 conflicts with the measured shared 60/hr standard tier (backlog, FEC entry).
- **Models:** `lib/summarize.ts:12` and `lib/classify-ceremonial.ts:3` both `"gemini-2.5-flash"` — README's Gemini claim is current; keep it.
- **Handoffs directory truth:** `.gitignore:79` ignores `docs/handoffs/`, **but `git ls-files docs/handoffs | wc -l` = 386** — the early files predate the ignore and ship with every clone. The archive `docs/handoffs-archive-362-661.tar.gz` is on disk, 829,609 bytes, `tar -tzf | wc -l` = **267** (README's count is right). README lines 108–110 claim the directory is local-only and "a clone does not carry them" — false for 386 files.
- **Corpus:** README says "~15k+"; backlog recorded 16,623 `bills` rows in July. `~N (estimate; STEP 0 measures)`.
- **Acknowledgment gaps:** `scripts/sync-ideology.ts` / `sync-career-votes.ts` / `sync-polarization-history.ts` (Voteview); `scripts/sync-crosswalk.ts` + `lib/committees-sync.ts` (congress-legislators); `lib/lda-sync.ts:33` `BASE = "https://lda.gov/api/v1"`. None appear in Data & acknowledgments.

## STEP 0 — enumerate, then proceed (HALT only where marked)

| # | check | expected / action |
|---|---|---|
| 1 | Re-derive the pointer and HO number | 700 landed → pointer 700, this is 701; 700 unlanded → the numbering paragraph above is the record, proceed |
| 2 | Every Ground-truth cite above, at your HEAD | matches; **any divergence is flag-don't-absorb** — report, propose, don't smooth |
| 3 | `SELECT COUNT(*) FROM bills` (one-off tsx read, real creds, read-only) | lands in the README as `~Nk` rounded down to the nearest 500 |
| 4 | Max tracked handoff number: `git ls-files docs/handoffs \| grep -oE '[0-9]+' \|` numeric sort tail | expected < 362; the README bullet lands the measured boundary ("through NNN") |
| 5 | Verify the four architect-drafted surface clauses marked ◆ in the replacement text against each page's own header/H1: `/patterns`, `/trends`, `/watchlist` (auth-gated?), `/lobbying` phrasing | amend the clause to match the page, name the delta in the paste; do not land an unverified claim |
| 6 | Bare-substring grep `docs/backlog.md` for an existing README-refresh loop | annotate it closed-by-701 if found; expected none |
| 7 | SKILL exposure | expected **0 touches**; a README pass states nothing SKILL owns |

## STEP 1 — the replacement README (commit 1, `docs(HO 701)`)

Land the following as the new `README.md` body for the sections named; sections not shown (title line, intro ¶1–2, CCBT, License, the Windows Git Bash note, Running-locally steps 1/3/5/6) are **unchanged**. Every factual clause below is covered by the Ground-truth section; the two slots in ⟨angle brackets⟩ come from STEP 0 rows 3–4; the four ◆ clauses are verified per row 5.

**Intro, last sentence (replaces "Single user, no auth, deployed as a personal project."):**

> Deployed as a personal project. A GitHub sign-in (Auth.js) exists but gates nothing — first-touch anonymous visitors land on `/welcome` and get the full product as a demo; ◆signing in adds a personal watchlist.

**What's in it (full replacement of the bullet list):**

> - **Dashboard (`/`)** — the answer surface. A week summary, a stage funnel, the topic mix, top movers and stalls, a competitive-races strip, an "on the hill" hearings band, and a live markets tape.
> - **Bills feed (`/bills`)** — every current-Congress bill, filterable by topic and stage, searchable, ceremonial noise filtered out, click-to-expand rows with the Gemini summary and full action history.
> - **News (`/news`)** — press coverage from Politico, The Hill, and Roll Call, LLM-matched to specific bills with source and signal filters; feeds the dashboard's breaking-news block and the media-attention badges on feed rows.
> - **Members (`/members`)** — a merged members + committees two-pane browser: sponsor depth, voting records, caucus badges, and Palestine-scorecard grades.
> - **Electoral (`/electoral`)** — the consolidated electoral surface: the competitive US map with a primary-calendar timeline band, race ratings, live primary results, district maps, FEC fundraising, and prediction-market odds (Kalshi + Polymarket). `/races` and `/primaries` survive as deep links under it.
> - **Lobbying (`/lobbying`)** — ◆the LDA filings feed: searchable, volume-sorted, linked to the bills the filings name.
> - **Amendments (`/amendments`) and Nominations (`/nominations`)** — floor amendments and nominations, synced daily along the bill spine.
> - **Hearings (`/hearings`)** — upcoming committee hearings, in list and calendar views.
> - **Patterns (`/patterns`)** — ◆cross-corpus analytics; `/trends` carries the long-run time-series charts.
> - **Trades (`/trades`)** — congressional stock-trade disclosures (FMP), matched to members.
> - **Watchlist (`/watchlist`)** — ◆pin bills to a personal list (the one surface that uses the sign-in).
> - **Weekly reports (`/reports`)** — generated snapshots that package an answer to the framing question on a weekly cadence.
> - **Markets tape** — equities, commodities, rates, and prediction markets, carried as legislative-context signal rather than as a finance feature.
> - **Search (`/search`)** — full-text search across bills, members, and reports.
>
> Smaller cuts hang off the same spine: `/president` (bills at the desk), `/changes` (the stage-change feed), `/stale` (momentum gone quiet).

**Stack (first line only; the maps/XML/reports sentence is unchanged):**

> Next.js 15 (App Router) · TypeScript · Tailwind v4 · Turso (libSQL) · `@google/genai` (Gemini 2.5 Flash) · Auth.js (`next-auth` v5) · Vercel hosting + Cron. Playwright drives the CI smoke crawls.

**Running locally, step 2 (replaces the six-key list):**

> 2. `cp .env.example .env`. Five keys boot the core: `CONGRESS_API_KEY` (request at https://api.data.gov/signup, free), `GEMINI_API_KEY` (https://aistudio.google.com/apikey), `TURSO_DATABASE_URL` + `TURSO_AUTH_TOKEN` (`turso db create cbt`, then `turso db tokens create cbt`), and `CRON_SECRET` (any 32-byte hex string). The rest are per-surface and documented inline in `.env.example` — `FMP_API_KEY`/`FRED_API_KEY` for the markets tape and trades, `FEC_API_KEY` for fundraising, `LDA_API_KEY` for lobbying, the Auth.js trio for sign-in, `REVALIDATE_URL` for backfill cache flushes. Everything renders with whatever data is present.

**Running locally, step 4, one figure:** "the live corpus is ~15k+" → "the live corpus is ~⟨row 3⟩ and fills in over subsequent incremental runs."

**Running locally, scripts paragraph:** unchanged except append `sync:lda` to the parenthetical examples.

**Deployment (full replacement of the section body):**

> Deploys ride the Vercel Git integration: a push to `main` builds Production (functions pinned to `pdx1`), a review ref builds a Preview. `npm run verify:deploy` confirms the served SHA after a ship. Cron auth is a `Bearer ${CRON_SECRET}` header on every tick, and `/api/health` watches the fleet.
>
> The schedule is native Vercel Cron end-to-end — `vercel.json` carries all 18 entries and is the authority. The shape: `/api/sync` every 6 hours, summarize every 10 minutes, news every 30, markets every 4 hours plus half-hourly FMP ticks through US market hours, Kalshi odds every 2 hours, daily passes for LDA, amendments, nominations, votes, and bill rosters, and two weeklies — race-ratings (Wed) and the weekly report (Mon 09:30 UTC).
>
> GitHub Actions carries CI, not data: `ci.yml` (typecheck + build), `e2e-prod.yml` (the scheduled and post-deploy production smoke crawl), and `design-citations.yml`.

**Project structure — three bullets change, the rest stand:**

> - `app/` — App Router pages (dashboard, bills, news, members, electoral, lobbying, amendments, nominations, hearings, patterns, trades, watchlist, reports, search, …) and the `app/api/**` routes, including the `/api/cron/*` tick handlers.
> - `docs/handoffs/` — the chronological handoff prompts that drove each step of development. The early files (through ⟨row 4⟩, 386 tracked files) predate the ignore and ship with the repo; handoffs 362–661 are tracked as one gzip (`docs/handoffs-archive-362-661.tar.gz`, 267 files — `tar -xzf` it to read); everything after 661 is repo-ignored and local-only (Tailwind build-input parity).
> - *(delete the now-redundant separate archive bullet at old lines 111–112 — it is folded into the line above)*

**Data & acknowledgments — three additions, one amendment:**

> - **Lobbying** — the [LDA API](https://lda.gov) (Lobbying Disclosure Act filings).
> - **Ideology & vote history** — [Voteview](https://voteview.com) (DW-NOMINATE).
> - **Member metadata** — the [@unitedstates congress-legislators](https://github.com/unitedstates/congress-legislators) dataset.
>
> Amend the FMP line: "(equity indices)" → "(equity indices + congressional trade disclosures)".

## Gates

- **Retired-token sweep, bare substrings, expected 0 each:** `markets-tick.yml` · `kalshi-tick.yml` · `markets-daily.yml` · `Hobby` · `Single user` · `vercel --prod` · `5,000 req/hr` · `a clone does not carry them`. **Control, expected ≥ 1 on the same instrument:** `check:design-citations` and `Bearer`. A sweep whose control reads 0 is broken, not green.
- **Claims table in the paste:** every factual clause that landed, with its `file:line` evidence at your HEAD — the STEP 0 table re-run as executed, ◆ rows showing what the page actually said.
- `npm run check:design-citations` → OK. `typecheck` and `build` run as the standing pair (they cannot fail on a `.md` edit; the sweep and the table are the discriminating gates here, named as such).
- Re-run the sweep immediately before the paste, not before the commit (method § Gates, binds-at-the-paste).

## Commit, docs, close

One commit, `docs(HO 701)`: `README.md` + the roadmap `Also (HO 701)` block + pointer (+ the backlog annotation only if STEP 0 row 6 found a line). Explicit pathspec staging. SKILL 0 touches (row 7); no oddity expected — the 386-tracked-files state is history, and the defect was the README describing it wrongly, which this HO closes.

Review ref `701-review`, `git ls-remote`, architect read (the full README diff is the substance — Corey rules on any clause he wants different at this read), FF, ref deleted, `verify:deploy` held on 5 consecutive reads.

read and follow 701
