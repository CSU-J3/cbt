# HO 720 — the `/` week-summary row: right-pinned by ruling, priced into the residue register, and the site identity re-baselined by a terminal crawl at `1cc99b8`

The line this HO closes is `docs/backlog.md:552` (FIT & FINISH, filed HO 719): `/` reads **M1b 1** on `div.week-sentences-row`, interior gap **995px** at 2560, and the permanent-residue register's closing identity (iv) carries no `/` term. Its close is *either a fix under the C1 rules, or a priced register line with the site total restated*.

**The disposition is decided by the ruling record, and STEP 0 confirms it rather than re-asks it.** The gap is the report link pinned to the row's right edge (`app/globals.css:3301` `margin-left: auto`, and the toggle's `flex: 1 1 auto` at `:3260`). That pin is not the build's choice: `docs/design/mock-690-chrome.html:312` says in its own prose *"it moves off the band and onto the summary row, right-pinned; it stays visible when the text is collapsed"*, and Corey ruled § 04 verbatim *"4. yes to the new one"* (2026-09-03; roadmap HO 690 block, SKILL `:1690`). Under `docs/method.md` § Roles a setting Corey selected in a ruled mock resolves the fork inside it, so un-pinning the link is against the ruled mock, exactly (iii)'s shape at HO 718. **The row therefore joins the residue register as accepted C1 residue with its price**, and the alternatives are measured, not argued, so that reopening is a priced decision (the HO 690 1px-escape precedent: filed, applied only under a re-ruling). No letter is asked. If Corey volunteers one at the HALT, the branch at the end applies.

**Two commits by default, kinds pure:** `docs` · `docs(skill)` alone. No product code. Read-only on the DB; the crawl reads prod Turso through a local production build, which is the audit's own target rule.

## Ground truth (read at `1cc99b8`; re-derive every `:N` by content)

- `components/WeekSentences.tsx` (101 lines): `:62-95` the row — `<div className="week-sentences-row">` holding the `<button className="week-sentences-toggle">` (label + stale marker + chevron) and the `<Link className="week-sentences-report">` as siblings; `:19-24` the header comment states the pin (*"the link pinned right with `margin-left: auto`. A click on the link navigates; a click anywhere else on the row toggles"*) — the whole-row hit target is a stated property, and it is part of the price.
- `app/globals.css:3248-3253` `.week-sentences-row` (`display: flex; align-items: baseline; flex-wrap: wrap; gap`); `:3256-3272` `.week-sentences-toggle` with `flex: 1 1 auto` at `:3260` and `min-width: 0` (HO 682); `:3300-3309` `.week-sentences-report` with `margin-left: auto` at `:3301`, `white-space: nowrap`; `:3337-3345` `.week-sentences-text` capped `max-width: 88ch` (C8). The comment at `:3243-3247` records the pin and why the row wraps.
- `docs/design/mock-690-chrome.html:150-161` § 04's CSS (`.ws-head{display:flex;…width:100%}`, `.ws-report{margin-left:auto;…}`), `:308-345` the section, `:312` the *right-pinned* prose, `:182` the ruling caption (*section 04 "4. yes to the new one"*).
- `docs/backlog.md:552` the filed line (reading, `m1.rows` path `main.home-main.dash-page > div.dash-left > section.week-sentences > div.week-sentences-row`, M1b 995 interior · 0 trailing · width 1348 · introduced by `730fe99`); `:341` the residue register; `:353` (ii) the non-px-constant form; `:355` (iv) *9 + 2 + 3 + 1 = 15*, read at the HO 634 crawl; `:356` (v) a line prices the row's worst gap; `:359` (viii) struck at HO 719 with its close note; `:318` the exemption registry, (9) at `:335`.
- `.claude/skills/cbt/SKILL.md:1989` C1 (*no far-right anchors in a row*); `:1690` the HO 690 week-summary passage (siblings-not-nested, the CSS-keyed collapse) — it does not yet say the link is right-pinned by ruling or that the row is registered residue; `:2011` accepted residue is cited, never subtracted, and a line joins with px, class and price, the site total restated.
- `scripts/diagnostic/layout-audit-606.ts:1446` prints `page loads planned: routes×2 + narrow subset`; 27 routes since HO 718; legs A/B/C read **22 of 22** at HO 719's close. The last terminal crawl the register cites is `62c25e4` (`:341`), restated at HO 633 and HO 634; nothing since has restated the site figure, and the audit has since gained M1c.
- Estimates, not readings: the row's gap at 1440 is **~350px** and at 1100 **~200px**; variant A (packed left) reads the gap under threshold at every width and shrinks the button to its content (~250px from ~1,200); variant B (row capped at 88ch) reads **~300px** at 2560 — over threshold — and is a cap, not a fix; the full crawl is **~54 wide loads + the narrow subset**, ten to fifteen minutes.

## STEP 0 — enumerate and measure, then HALT

| # | check | expected | if the work never happened, this reads |
|---|---|---|---|
| 1 | `git ls-remote --heads origin`; `git status --porcelain`; pointer and highest HO; machine | `main` at `1cc99b8` alone; clean; 719 / 719 → **720** | anything else stops here |
| 2 | quote `WeekSentences.tsx:19-24`, `globals.css:3260`, `:3301`, `:3337-3345`; mock `:312`, `:182`; backlog `:552`, `:355`, `:356`; SKILL `:1690`, `:1989`, `:2011` | as in ground truth; **`:312` says right-pinned** | a mock that does not say right-pinned reopens the disposition and the HALT says so |
| 3 | `npm run build` · `npm run typecheck` | 0 · 0 | not this HO's to fix |
| 4 | legs A/B/C at HEAD | 22 of 22, `FALSIFICATION: PASS` | a red leg means no crawl (`:39-48`) |
| 5 | `--route home` at 2560, hit 2: the row's `m1.rows` entry | M1b, interior **995**, trailing 0, width **1348**; M1 1 · M1x 0 · M1c 0 | the pre-state; a route that already reads 0 means the geometry moved and there is nothing to register |
| 6 | the row's geometry, read in the page, at **2560 · 1440 · 1100**: row width, button `clientWidth` (the hit target), button ink right edge, link left edge, the gap between them, and whether the row wrapped | three readings; the 2560 gap reproduces row 5's 995 | this is the register line's px column and its width dependence |
| 7 | **variant A, applied in-page and re-read** (`.week-sentences-toggle { flex: 0 1 auto }` + `.week-sentences-report { margin-left: 0 }`) at 2560 and 1440: gap, trailing gap, button `clientWidth`, and where the link lands relative to the chevron | gap under threshold at both; hit target collapses to the label's width | the price of the un-pin, measured: a whole-row click target becomes a text-width one |
| 8 | **variant B, applied and re-read** (`.week-sentences-row { max-width: 88ch }`) at 2560 and 1440: gap and button `clientWidth` | gap ~300 at 2560 (estimate), still over threshold | a cap that cannot reach the threshold is recorded as such, not proposed |
| 9 | **the terminal crawl** — the full `layout-audit-606.ts` run against the local production build, legs first, quoting the `page loads planned` line; per-route M1a · M1b · M1 · M1x · M1c; site totals; every `m1.rows` entry over threshold with its route and class | site M1 = the register's terms + `/` 1, M1x per the registry, **M1c 2**; `electoral-2028` M1 0; nothing else over threshold | **any other over-threshold row not in the register is its own finding**: listed at the HALT with route, class and px, and filed in STEP 2 as its own FIT & FINISH line, never fixed here |
| 10 | (iv) re-derived from row 9: the per-route terms of the identity | `/members` · `/vote` · `/lobbying` · `/trades` terms at their current readings, plus `/` 1 | a term that moved since HO 634 is stated as moved, with both numbers |

Keep the crawl's JSON and console output under `docs/handoffs/720-artifacts/` (repo-ignored). HALT here with the ten rows. The go arrives as a file.

## STEP 1 — docs (commit `docs(HO 720)`; `docs/backlog.md`, `docs/roadmap.md`, `docs/oddities.md` if anything surprised)

- **Register line (x)** in the permanent-residue register, on the admission standard as amended: class `div.week-sentences-row` on `/`; px **the worst gap at 2560 from row 6** with the 1440 and 1100 readings beside it (the (ii) form — the gap is width-dependent, so the line carries the curve, not a constant); **the price**: variant A's numbers (gap, and the hit target's shrink from row 7), variant B's numbers (row 8, and that it cannot reach the threshold), and the ruling that makes the pin a setting rather than a default (mock `:312`, *"4. yes to the new one"*, quoted with provenance). *Leaves this register* under a re-ruling of § 04 or a redesign of the row, and says so.
- **(iv′)** appended after (v) — never edited into (iv): the identity restated from row 9 at `1cc99b8`, term by term, **cited not subtracted**, in the form *site M1 = named residue + M1x + M1c, nothing unexplained*; any term that moved since HO 634 named with both readings; any new finding from row 9 listed as *filed, not registered*.
- **`:552` strikes** on the register line, row 5 quoted as the pre-state.
- Any row-9 finding: its own FIT & FINISH line, owner Code, with route · class · px · the crawl SHA, and the same two-way close the `:552` line carried.
- **Roadmap:** one `Also (HO 720)` block, pointer 719 → 720: the rulings cited, the three geometry readings, both variants' prices, the crawl's totals and the restated identity.

## STEP 2 — SKILL, alone (commit `docs(skill)`; one edit)

`:1690`, the HO 690 week-summary passage, gains one clause after *never nested*: the link is **right-pinned by the § 04 ruling**, the 2560 gap it leaves is **accepted C1 residue on the permanent-residue register (line (x)), priced**, and un-pinning it is a re-ruling of § 04, not a fix. Read the clause against the tree before it lands.

## The branch that is not the default

If Corey's word arrives at the HALT re-ruling the pin, STEP 1 becomes `fix(HO 720)` landing variant A (the two declarations, `WeekSentences.tsx:19-24` and `globals.css:3243-3247` comments rewritten to the new placement, the mock left as the record of what was ruled and superseded), gated by `--route home` **M1 0** against row 5's 1, the DOM floor, and captures at **1440 / 2560 / 430** plus a reduced-motion pass (render-touching: the link moves). The register line is not written; `:552` strikes on the fix; the roadmap block records the re-ruling verbatim with provenance and SKILL `:1690` says the pin was ruled at HO 690 and re-ruled at HO 720. The crawl and (iv′) happen either way.

## Gates

Legs 22 of 22 before the crawl, and the `page loads planned` line quoted. Build then typecheck, exit 0, re-run before the paste. Every number in the register line and (iv′) traceable to a row of the closure table. `git diff --numstat` on `docs/backlog.md` with each deletion explained (expect the rewritten `:552`; a register line and (iv′) are additions). Bind evidence for the local server. Remote claims via `git ls-remote`.

## Review ref, then FF

Review branch from the start; push the ref; the SKILL diff approved alone; `HEAD:main` no force; `git ls-remote --heads origin`; delete the ref; local `main` fast-forwarded and `git rev-parse main` pasted; `npm run verify:deploy` for the tip. A docs-only FF still deploys, so the Production run that follows is a deployment_status sample, named as such and not counted toward the `backlog:51` week.
