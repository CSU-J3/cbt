# HO 729 — `method.md` § Handoff discipline gains the rule the last four STEP 0s kept proving

One bullet, one file, one commit. The existing ground-truth rule catches a mechanism **recalled**; it does not catch one **read incompletely**, and that gap has now been demonstrated four times running by the same author in four consecutive handoffs. Each quoted a real `file:line` and inferred past what the line says.

**The four, so the bullet rests on a record rather than on a mood:**

1. **HO 727** — the off-token `font-family`'s provenance was given as *arrived with the HO 697–699 font work*, inferred from knowing those HOs touched the file. The pickaxe reads `b5a9455` alone, and that commit carries the claim at `:6` and its counterexample at `:92`. Corrected at STEP 0.
2. **HO 728, the premise** — `trailingGapPx` is written at `scripts/diagnostic/layout-audit-606.ts:722` and consumed by nothing. The definition was read and quoted correctly; no grep was run for its readers, and a gate was proposed on a number the instrument never scores. Corrected at STEP 0.
3. **HO 728, the ruling** — a grep for `GAP_THRESHOLD_PX` returned six filter sites. Eleven apply the threshold, because the value reaches browser scope as `t.gapThreshold` (`:353`, and `:364` says so in words). The conclusion survived; the count did not. Corrected at the FF paste.
4. **HO 728, the correction to the correction** — the architect instructed that the roadmap block record the CTA void as *mostly HO 670's*. Code declined: `b5a9455` was never measured and HO 697–699 changed the page in between. An unmeasured claim was being corrected with another unmeasured claim, and flag-don't-absorb is what stopped it.

The fourth is why this is a `method.md` bullet and not a note in an HO block. Three of these were caught because Code read the tree; the fourth was caught because Code refused an instruction. The rule should be written where both readers look.

**One commit, `docs`.** **No SKILL mirror** — § Doc authority's *cross-reference rather than restate* governs, and two copies of this rule would drift exactly as it warns. Nothing opens or closes in the backlog.

**The close:** the bullet is in § Handoff discipline, immediately after the ground-truth bullet, and every `file:line` inside it resolves at the tip. **What it reads if the work never happened:** § Handoff discipline ends at the `docs/handoffs/` is repo-ignored bullet with nothing between it and the ground-truth one.

## Ground truth (read at `3099234`, `main`; re-derive every `:N` by content)

- `docs/method.md` § Handoff discipline runs `:45-79`. The ground-truth bullet is the one opening *"A ground-truth paragraph quotes what was read at the stated SHA and marks everything else as an estimate"*, and it already carries the HO 690–694 record and the HO 695/696 verbatim-text clause. The new bullet goes **directly after it**, before the `docs/handoffs/` is repo-ignored bullet.
- `:89`, in § Executing a handoff: *"Bare-substring greps — never prefix-sweep, never quote-anchor."* **This is a different rule** — it governs a grep's *form*. The new bullet governs whether the right thing was grepped at all, and must say so rather than read as a restatement.
- § Doc authority and conventions: *"Cross-reference rather than restate. Two copies of a rule drift, and nothing in the toolchain reports it when they do."* This is the authority for no SKILL mirror.
- **Pointer arithmetic**: roadmap pointer 728, highest HO in commit subjects 728 → **this is 729**. Open loops at the HO 728 close: **260 live / 263 struck**.

## STEP 0: verify the bullet's own citations, then HALT

The bullet is text this handoff asks to land verbatim, so STEP 0's job is the one `method.md` § Handoff discipline names for that case: read every factual clause against the tree before it lands.

| # | check | expected | if it fails |
|---|---|---|---|
| 1 | `git ls-remote --heads origin`; `git status --porcelain`; pointer and highest HO | `main` alone at `3099234`; clean; 728 / 728 → **729** | a second head means an FF is pending |
| 2 | Quote § Handoff discipline's ground-truth bullet and the bullet after it; quote `:89`; quote § Doc authority's cross-reference bullet | as in ground truth | a bullet already covering this makes the addition a restatement — **HALT and say so** |
| 3 | **Every citation inside the proposed bullet, re-derived:** `layout-audit-606.ts:722` writes `trailingGapPx`; no filter reads it; `:353` passes the threshold as `t.gapThreshold`; `grep -c GAP_THRESHOLD_PX` against the count of sites that actually apply it; `git log -S"Segoe UI Symbol" -- app/welcome/landing.module.css` → `b5a9455` and `6bd6749`; `b5a9455` carries `:6` and `:92` | the figures as stated below | **any figure that does not re-derive is corrected in the bullet before it lands, not footnoted** |
| 4 | `grep -n "gapThreshold\|GAP_THRESHOLD_PX" scripts/diagnostic/layout-audit-606.ts`, and of those, how many apply the threshold to an interior gap | the eleven-vs-six split as you read it at the HO 728 paste | a different split means the bullet's worked example is restated with your number |

HALT with the four rows. The go arrives as a file.

## STEP 1: the bullet (commit `docs(HO 729)`; two paths)

`docs/method.md`, § Handoff discipline, immediately after the ground-truth bullet. Land this, with any figure row 3 or 4 corrected:

> - **A citation proves the line was read, not that the conclusion drawn from it holds.** The rule above catches a mechanism *recalled*; it does not catch one *read incompletely*, and four consecutive handoffs were corrected at STEP 0 for exactly that — HO 727's font-stack provenance and HO 728's three. Each quoted a real `file:line` and inferred past it. **Trace a quantity to its consumers before a gate leans on it:** `trailingGapPx` is written at `scripts/diagnostic/layout-audit-606.ts:722` and read by nothing, which HO 728 learned only after proposing a close on it. **Grep the value, not the identifier:** the same file's threshold travels into browser scope as `t.gapThreshold` (`:353`), so a grep for `GAP_THRESHOLD_PX` reads six sites where eleven apply it — a different failure from § Executing a handoff's bare-substring rule, which governs a grep's *form* rather than whether the right thing was grepped. **And a correction is ground truth too:** HO 728's block does not call the CTA void "mostly HO 670's", because `b5a9455` was never measured — the architect's own correction was an unmeasured claim, and Code declined to land it.

`docs/roadmap.md` — one `Also (HO 729)` block, pointer 728 → 729: the four instances with their SHAs, why the existing ground-truth bullet did not catch them (all four cited correctly), the placement decision and the no-SKILL-mirror reasoning with § Doc authority cited, and the fourth instance named as the reason this is a method rule rather than an HO note.

No backlog entry, no oddities entry. Reconcile open loops at open and close; **260 / 263** at open.

## Gates

`check:design-citations` → `OK` from a fresh clone of the review ref; it has no path filter and is the one gate a docs-only change actually exercises. **Build and typecheck are not run**, because nothing outside `docs/` is touched — state that in the paste rather than omitting it, and name the last SHA they were green on. `ci.yml`'s `paths-ignore` skips `docs/**` and `**/*.md`, so expect no `ci` run on the push and say so rather than reporting a missing check as a failure. Explicit path staging. No server, no DB, no captures — nothing renders.

## Review ref, then FF

Review branch from the start; push the ref; `HEAD:main` no force; `git ls-remote`; delete the ref; local `main` forwarded with `git rev-parse main` pasted. **No `verify:deploy` and no Production `e2e-prod` read** — a docs-only commit changes no served bytes, and claiming a deploy confirmation for it would be a green that cannot fail. Say that in the paste instead of running them.

---

read and follow 729
