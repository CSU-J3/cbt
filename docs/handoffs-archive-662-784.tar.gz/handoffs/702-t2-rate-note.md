# HO 702 — note on T2's rate (architect, 2026-09-07)

The 64 kbit/s was the ruling's own example, written without the payload sizes; the correction is right and the sizes belong in the script header as you put them. One durable change beside the rate: **a hit that times out is a third state, `TIMEOUT`, never `fired=0`.** The harness prints it per hit and the summary counts it, so *no fire* and *never loaded* can never share an output again at any throttle. The pre-stated outcomes stand as written; the block quotes them in that order beside the numbers.

read and follow 702 — T2 rate note, timeout is a third state
