# HO 771: the ratings sync reads daily, so a stalled origin costs a day, not a week; HO 744's second connection gets its answer

HO 770 made each run's ratings one fetch of Sabato's page. On 10-10 that page's origin gave no answer from 05:16 to 05:20Z, then answered in 245 ms. The 8s cap turns a stall at 11:00Z into a loud `error`, which is right. But on a weekly cron, one stall means a week without ratings, and the next try is seven days off.

The raters don't keep to Wednesdays. Sabato changed ratings on 09-29 (a Tuesday) and 10-08 (a Thursday); Cook's pages were dated Monday 10-06 and Friday 10-09; IE's file Thursday 10-01. A daily read:
- costs a stall one day;
- puts a move on MOVED the day after it's published instead of up to a week later;
- is still one GET a day against Sabato.

The MOVED guard's 8 days stays. It was a weekly cadence plus a day, and with a daily sync it still reads a missed week as not fresh, while an ordinary day passes easily.

**How STEP 0 runs** (method.md, HO 768's rule): the claims are mine and are a check, with no HALT unless one fails.

**Base:** `main` at `12f4228` after the FF go. HO number: the pointer is 770 and the highest HO in commit subjects is 770, so this is 771.

## STEP 0

| # | Claim at `12f4228` | Fails if |
|---|---|---|
| 1 | `vercel.json` schedules `/api/sync-race-ratings` at `0 11 * * 3`, and `/api/cron/rating-history` at `0 15 * * *` | |
| 2 | `lib/cron-health.ts:92` reads `{ path: "/api/sync-race-ratings", schedule: "0 11 * * 3", maxStaleMs: 9 * DAY, windowOnly: true }, // weekly (Wed)`, and the daily routes beside it carry `maxStaleMs: 26 * HOUR` with no `windowOnly` | |
| 3 | The schedule is written in four more places:<br>• the route's header (`app/api/sync-race-ratings/route.ts:2` *weekly*, `:7` *weekly (Sabato updates mid-week)*);<br>• `lib/move-freshness.ts:6` (`` `0 11 * * 3` ``) and `:21-22` (*a weekly cadence plus a day*);<br>• the README's schedule paragraph (*two weeklies — race-ratings (Wed) and the weekly report (Mon 09:30 UTC)*);<br>• SKILL's cron entry opening (*11:00 UTC **Wednesdays only** (`0 11 * * 3`)*).<br>`docs/method.md:464` also names a `0 11 * * 3` route, as a historical example of a cron date written from memory; it stays as it is | the schedule appears anywhere else, as a cron string or in words |

## The build

### 1. Daily (feat)

- **`vercel.json`:** the route's schedule becomes `0 11 * * *`.
- **`lib/cron-health.ts`:** the line becomes, verbatim:

```text
  { path: "/api/sync-race-ratings", schedule: "0 11 * * *", maxStaleMs: 26 * HOUR }, // daily (HO 771; weekly Wed before)
```

- **The route's header:** *weekly* becomes *daily since HO 771*, and the cadence sentence gives the reason: a stall at 11:00Z costs a day, and the raters publish on any weekday.
- **`lib/move-freshness.ts`:** `` `0 11 * * 3` `` becomes `` `0 11 * * *` (daily since HO 771) ``. The bound's sentence gains: *kept at 8 when the sync went daily (HO 771), so a missed week still reads not fresh.* `MOVE_FRESH_DAYS` itself doesn't change.

## Legs

`scripts/diagnostic/ratings-daily-771.ts`:
- **The registry and the schedule agree:**
  - `vercel.json`'s schedule for the route equals `CRON_ROUTES`'s, both `0 11 * * *`;
  - the red: `12f4228`'s pair, `0 11 * * 3` in both, fails the assertion that the schedule is daily.
- **`computeCronHealth` on planted `cron_runs`:**
  - a route `success` 25 hours old reads healthy;
  - the red: one 27 hours old reads stale;
  - the control: `/api/cron/weekly-report` keeps its 9-day window, so a success 8 days old reads healthy.

The first scheduled daily run after this HO's FF is the deployed reading. It closes the ratings WATCH (see Docs).

## Docs

**roadmap:** the HO 771 block. It opens with HO 769 and 770's FF readings as taken:
- the gates and the FF;
- `verify:deploy`, and the Production build's cache line;
- `e2e-prod`;
- Sabato's origin check, the POST, its `cron_runs` row and the read-back;
- the flush;
- the prod reading.

Then this HO.

**backlog:** the ratings WATCH's *dated* field becomes *the first `0 11 * * *` run after HO 771's FF*. Its close is unchanged. Record the FF go's POST in it as the deployed path's first read of Sabato. Reconcile, control 0.

**oddities:** the HO 744 entry *Two TCP connections for one hung fetch when a signal is attached — unexplained* gains a paragraph after its last, verbatim:

```text
**Explained at HO 770.** Leg c1 re-aimed the hang at Sabato's page and logged what each socket carried. The one GET went out on the first connection. The second opened at the abort, 8.02s later, and carried no bytes: the client dialed a replacement when the abort tore the first one down. Leg c3, where nothing aborts, shows one connection. So the second socket is the client's redial on abort, not a second request, and c1 now counts requests rather than sockets.
```

**README:** replace, verbatim.

OLD:

```text
amendments, nominations, and votes, and two weeklies — race-ratings (Wed) and the
weekly report (Mon 09:30 UTC).
```

NEW:

```text
amendments, nominations, votes, and race ratings, and one weekly, the weekly report
(Mon 09:30 UTC).
```

**SKILL**, in its own `docs(skill)` commit, last. Quote the diff in the paste for approval.

```text
OLD: - `/api/sync-race-ratings` — 11:00 UTC **Wednesdays only** (`0 11 * * 3`) — House
NEW: - `/api/sync-race-ratings` — 11:00 UTC **daily** (`0 11 * * *`; Wednesdays only until HO 771, which made it daily so a stalled origin costs a day, not a week) — House
```

## Commits

On `771-review`, kinds unmixed:
- `feat` for § 1;
- `diag`;
- `docs`;
- `docs(skill)`, alone and last.

## Paste back once, for the FF go and HO 771

- **The FF go:**
  - the gates and the push;
  - `ls-remote` and `rev-parse`;
  - `verify:deploy` and the build's cache line;
  - `e2e-prod`;
  - the origin check, the POST, its `cron_runs` row and the read-back;
  - the flush;
  - the prod reading.
- **HO 771:**
  - `ls-remote` with `771-review`'s SHA;
  - the Preview's cache line and `narrow-preview`;
  - STEP 0;
  - the legs;
  - `--stat` per commit, and `--numstat` for docs with every deletion explained;
  - the reconcile;
  - a last cheap-gate run.
