# HO 763: a written runoff draws its block. The runoff read is keyed on the seat, not on a `race_id` the sync never wrote, so the 30 ingested rounds render where the 3 seeded ones already do

`docs/backlog.md` OPEN LOOPS, *A runoff row the sync writes carries no `race_id`, so its race page draws no runoff block…* (HO 761), ruled 2026-09-30: a written runoff draws its block, this HO, with captures. After HO 762's repair, prod holds 33 decided runoff rounds and draws 3.

## Ground truth (read at `99f16a1`; re-derive every `:N` by content)

- `getRunoffsForRace` (`lib/queries.ts:1676-1687`) reads `WHERE p.race_id = ? AND p.election_round = 'runoff'`. No first round carries a `race_id`; the seeded specials and seeded runoffs do (`senate-SC-2026-special-R` carries `S-SC-2026`). The sync's runoff write leaves `race_id` NULL by design (`lib/primaries-sync.ts:644-648`).
- The harvest already joins `primaries` to `races` by state, chamber and `CAST(district AS INTEGER)` rather than `race_id` (`lib/harvest-challengers.ts`, HO 741); a Senate special collapses onto the regular race id (`S-SC-2026`), which the seat key reproduces and the race_id column also records.
- `RaceRunoffs` renders one block per round, *Won*/*Lost* since HO 761, PENDING for an undecided one; `RaceHubBody.tsx:100-110` uses `runoffs.length` to decide the stub. 33 rounds over how many races, and which are undecided, STEP 0 reads.
- `app/race/[id]/page.tsx:67` fetches runoffs with the rest of the page.

## STEP 0

1. HO number from the tree: `main` at `99f16a1`, pointer 762, so 763. Otherwise stop.
2. Re-read every cited `:N` by content. Flag a drift.
3. Measure, prod, SELECTs only: runoff rounds by race (keyed on state, chamber, district), the races that would gain a block and how many blocks each, any race with two runoff rounds of the same party, any round whose seat key reaches no 2026 race, and the three capture races (TX-18, a race with two blocks if one exists, one with a seeded block, S-GA).
4. Carry HO 762's FF-go readings (`docs/handoffs/762-artifacts/carry-to-next-ho.md`) into this HO's roadmap block.
5. Proceed without a halt.

## The build

1. `getRunoffsForRace` keys on the seat: the race's state, chamber and district (a Senate race by state and chamber), `election_round = 'runoff'`, ordered by party then date. The `race_id` column stays as it is, read by nothing here. A round whose seat key reaches no race is listed in the cron payload once per primaries tick, so a stray never disappears silently.
2. `RaceRunoffs` is unchanged in markup; a race with two rounds renders two blocks as the component already allows.
3. Nothing else changes. The stub rule (`runoffs.length`) follows the new read, so a race that went to a runoff stops being a stub, which is right.

## Legs, on a `file:` copy, render-touching, each red first

1. The read: TX-18 returns its D round; S-SC returns the special's round and not the June primary's; S-GA returns the seeded round as before; a race with no round returns none. Red: TX-18 returns nothing.
2. The count: exactly STEP 0's races gain exactly STEP 0's blocks, and every race that drew a block before still draws it.
3. Strays: a round whose seat key reaches no race (planted) is named in the payload and drawn nowhere.
4. Captures from local production builds at 1440, 2560 and reduced motion: TX-18, the two-block race if one exists, S-GA, against HEAD's before. The stub check: a race whose only roster is the runoff no longer prints the stub.

## Commits and docs

- `fix(HO 763)`: the read and the payload line.
- `diag(HO 763)`: the legs driver.
- `docs(skill)`, its own commit, approval requested: the runoff read keyed on the seat, `race_id` unread by the page, the stray list.
- `docs(HO 763)`: strike the race_id line on the legs; annotate the SC runoff line (HO 600/601) with the row now on prod and drawn, and strike it if that is its close; the roadmap block, pointer 762 → 763, carrying HO 762's readings. Reconcile OPEN LOOPS at open and close, control at 0.
- Review ref `763-review`. The FF is held for the SKILL approval, the captures and review.

## The prod reading (in the FF go)

After the FF and the next `races` flush: `/race/TX-18-2026`, `/race/S-SC-2026` and `/race/S-GA-2026` with their blocks, and the count of race pages drawing a block against STEP 0's.

## Paste back

- STEP 0's table;
- the four legs and the captures;
- the SKILL diff, for approval;
- `git show --stat` per commit, `--numstat` for the docs commits, the reconcile, the `763-review` SHA from `git ls-remote`, and a last cheap-gate run.
