# HO 702 — ruling before the commits (architect, 2026-09-08). Hold *§1 killed*; two of the three falsifiers were mis-specified on this side. One corrected window, then the block says dead or alive.

Teardown accepted as measured (the marker counted at removal, the three surviving copies read 0, the shells named). The lever is the headline and it should read as one: **t2 raises the rate on demand**, the first reproduction this class has had since July. The verdict under it is not yet earned, and the reason is mine, twice.

## 1. T3 compared the wrong two timestamps

I wrote *on fires, last-flight > fire-t*. But §1 predicts the fire is the **replay**, which happens *after* the pending thenable resolves, which happens *after* the last flight script executes. So `last-flight < fire-t` on every fire is exactly what §1 predicts; `TAIL-AFTER-FIRE` could never have read true under the mechanism it was meant to test. The comparator §1 actually needs is **hydration start against last-flight**: did the app chunk begin executing before the parser finished the flight tail? On fires §1 says yes; on quiet hits, no. `first-post-t` is a commit, not a start; the stamp to add is the moment the first webpack chunk evaluates (an `addInitScript` trap on the `self.webpackChunk_N_E` assignment, or the app entry's first execution — whichever is cheaper and fires once), printed per hit as `hyd-start`, with the verdict line becoming `HYD-BEFORE-TAIL / hyd-after-tail`.

## 2. T1's 500 ms was sized for an unthrottled tail

Under t2 the document streams for seconds (`/members` ~13 s at 1500 kbit/s), so a half-second hold on the chunks still starts hydration mid-parse; *t2t1 did not collapse* is what §1 predicts too. The calibrated T1 holds the JS chunks **until `DOMContentLoaded`** — the route handler awaits the page's `domcontentloaded` before fulfilling — so hydration starts after the tail is parsed by construction, whatever the throttle. §1 predicts t2t1′ → 0 (or to the TIMEOUT floor, counted separately); a rate that stays up under t2t1′ kills §1 properly.

## 3. One window, on `main`'s production build, unpatched

The widened message is not needed for this pair (fires are counted by `pageerror`; T3′ and T1′ live in the harness and the `mut` channel), so no worktree and no patched React: stand `main`'s build, control → t2 → t2t1′ back to back, TIMEOUT as a third state, hyd-start per hit. Three readings decide it, pre-stated: **hyd-start before last-flight on fires and after it on quiet hits, and t2t1′ collapses** → §1 confirmed, both directions; **t2t1′ stays up, or hyd-start sits after last-flight on fires** → §1 dies on a falsifier that can actually reach it; **t2 does not raise `main` off the floor** → the lever is tree-specific and that is its own finding (the tagged tree's clock or tag would then be the amplifier after all, measured this time). Quote the table from the completed window as well, all three modes with FIRES and TIMEOUTS, and the six widened messages with their `expected= / found= / site=` — those are evidence whichever way §1 goes.

## 4. The `e2e/**` typecheck gap: filed, not ridden

A backlog OPEN LOOP, owner Code: `tsconfig.json`'s `include` omits `e2e/**`, proven by a syntax error passing `tsc` clean, while `ci.yml:12` justifies not path-ignoring `e2e/**` on the grounds that typecheck covers it. Close: `e2e/**` in the typecheck (with whatever it turns up fixed first), and the `ci.yml` comment corrected in the same HO so the justification and the reality change together. Not inside a test-kind commit here; the HO that closes it owns both edits. Arm A's ~250 lines are named in the line as the first thing landing behind the gap knowingly.

## 5. Evidence

The three fire dumps and the window log move from the scratchpad to `docs/handoffs/702-artifacts/` (gitignored) before anything else; the block cites them by path. A scratchpad is where evidence goes missing between sessions.

## 6. Then

The corrected window → the four commits as listed (test · chore · SKILL alone · docs), with the block and the `:50` annotation written to the outcome §3 actually read, and the SKILL bullet saying what the channel measures and what the two mis-specified falsifiers could not, in the same sentence.

read and follow 702 — hold the verdict, one corrected window on main
