# HO 778: Nov 4's two routes. `/api/cron/primaries` takes a state and reads it live, so Louisiana can be read on demand, and `/api/cron/general-ballot` runs one at a time. With HO 777's FF readings, and Corey's two tag rulings filed

**Corey's rulings, 2026-10-11, verbatim** (two questions after HO 777's review, answered by selection):
- what a called race's page should say of an incumbent off its ballot: *"Keep the tag; Senate and district runs show their result (Recommended)"*;
- what an incumbent marked as leaving to run for another office should show: *"RUNNING FOR GOVERNOR (Recommended)"*.

**They're filed here and built in the HO after this one,** not here as HO 777's go said: they touch every surface that prints the tag and need a curated list, and the routes shouldn't wait on either. This HO changes no page.

**Why now.** HO 777 filed two lines dated before 2026-11-03: nothing can read Louisiana's six House contests on demand, and the ballot route has no lock. Both are steps in Nov 4's procedure.

**Scope, in:**
1. **§ 1,** a target for `/api/cron/primaries` (the Louisiana line).
2. **§ 2,** the ballot route's lock (the lock line).
3. **HO 777's FF go,** into this block.
4. **The docs:** the WATCH (HO 758) line's (a) and (c), the lock line struck on leg K, and Corey's rulings filed.

**Out:**
- building the rulings;
- `isSettled`, which keeps freezing a contest on its first winner mark;
- every other OPEN LOOPS line;
- captures, since nothing renders differently;
- any prod write. The target's first prod read is the FF go's, after review.

**How STEP 0 runs** (method.md, HO 768's rule): the claims are mine and are a check.

**Base:** `main` at HO 777's FF head. That FF adds `diag` and `docs` only, so every code anchor below reads the same at `e15daca` and at the head. HO number: after the FF the pointer is 777 and the highest HO in commit subjects is 777, so this is 778.

## STEP 0

| # | Claim | Fails if |
|---|---|---|
| 1 | `main` is HO 777's FF head, its Production `e2e-prod` smoke passed, `777-review` is gone, and OPEN LOOPS holds the lock line HO 777's go filed. | any of the four |
| 2 | `/api/cron/primaries` takes no target. One handler serves GET and POST and runs `runPrimariesCronTick(t0)` inside `wrapCronRoute("/api/cron/primaries", …)` (`app/api/cron/primaries/route.ts:1-8`, `:43`, `:49`). `maxDuration` is 60 (`:22`, `vercel.json:13-14`). | |
| 3 | The tick runs the dated priority pass before it reads the cursor (`lib/primaries-sync.ts:2498`), then a House slice through `syncHouseDistricts(slice, "cron-slice", { deadlineMs, onProgress })` (`:2575`), committing the cursor per district. | |
| 4 | `syncHouseDistricts` takes `deadlineMs` and `onProgress` only (`:1583-1584`). It calls `scrapeHouseCandidates(d.state, slug, d.district)` with no options (`:1724`), then sleeps 1s (`:1725`). `scrapeHouseCandidates` reads `.cache/ballotpedia` first unless `bypassCache` is set (`lib/primary-candidates-scrape.ts:293`, `:585`), and `.cache/` is gitignored (`.gitignore:37`), so a deployment has no cache and reads live. | a deployment can carry the cache |
| 5 | Louisiana: six districts (`lib/primaries-sync.ts:96`), a jungle on 2026-11-03 with a 2026-12-12 runoff (`:204`), one `open` contest per district (`:161`, `:1810`) with id `house-LA-0N-2026-open` (`:1830`), behind the House pass's `isSettled` guard (`:1842`, defined at `:662`). | |
| 6 | The harvest publishes LA's jungle seats from `primary_candidates` (`lib/harvest-challengers.ts:209-233`), and `/api/cron/race-challengers` expires `races` unconditionally (`app/api/cron/race-challengers/route.ts:53`). | |
| 7 | The ballot route has no lock. `runGeneralBallot` reads its queue once, at the start (`lib/general-ballot.ts:764`, `:790`), and nothing in the route, `generalBallotTick` (`:902`) or `wrapCronRoute` (`lib/cron-log.ts:142`) checks for a run in flight. `wrapCronRoute` reaps `running` rows older than 5 minutes (`:26`, `:149`) before it inserts its own (`:152`). | |
| 8 | HO 747's saved pages (`docs/handoffs/747-artifacts/pages/`) hold LA-01 to LA-06 at the URL the House pass fetches (`houseDistrictUrl`, `lib/primary-candidates-scrape.ts:162`, which the ballot reader also fetches, `lib/general-ballot.ts:412`). | a page is missing |

## § 1: `/api/cron/primaries?state=XX` (`feat`)

An authorized GET or POST naming a `state` reads every House district of that state live, now.
- **The districts** come from the House list (`HOUSE_DISTRICTS_BY_REGION`). A `state` that names no House state, or one with more than `CRON_HOUSE_SLICE` (12) districts, is refused with 400 before any run row, so a call stays inside the 50s deadline. Louisiana has six.
- **The read** goes through `syncHouseDistricts`, with a new `bypassCache` option it hands to `scrapeHouseCandidates`, the same 1s pacing and the same per-district writes, and `deadlineMs` from the route's start.
- **Nothing else runs:** no cursor read or write, no priority pass, no calendar.
- **The run row** is `wrapCronRoute`'s, under `/api/cron/primaries?state=XX`, so the watchdog's `/api/cron/primaries` keeps reading only the scheduled tick.
- **The payload:** `unit: "house-target"`, the state, the House block the cursor tick reports (attempted, parsedOk, totalCandidates, matchedIncumbents, rosterDeletesRefused, settledSkipped, runoffs), budgetStopped, fetchFailures, perUnitMs and runoffStrays.

With no `state`, the route runs the cursor tick exactly as today.

**Leg L, on a `file:` copy, with HO 747's saved pages standing in for Ballotpedia** the way HO 761 did it: a `--require` preload in the server answers every `ballotpedia.org` request from the saved pages, refuses every other host, and logs each request. Put the copy's cursor on a House unit whose slice holds no LA district.
- **Red, HEAD's build:** `POST ?state=LA` runs the cursor tick: the run row is under `/api/cron/primaries`, the payload's unit isn't `house-target`, and the cursor moves.
- **Green, the tree's build:**
  - the run row under `/api/cron/primaries?state=LA`;
  - unit `house-target`, attempted 6, parsedOk 6;
  - the six `house-LA-0N-2026-open` rows hold the saved pages' rosters, `jungle`, 2026-11-03 and 2026-12-12;
  - the cursor and every other row unchanged, by a whole-table diff outside the six ids;
  - every request answered by the preload.
- **Refusals:** `?state=CA` and `?state=ZZ` answer 400 and write no run row.
- **Control:** no `state` runs the cursor tick on the tree's build.

## § 2: the ballot route runs one at a time (`feat`)

A `general-ballot` run that finds another `general-ballot` row still `running`, started inside the route's 300s ceiling, returns without reading. Its row closes `success`, and its payload says it yielded and names that run. Its own row doesn't count, and an older open row doesn't block. If two calls start together and each sees the other, the later id yields.

Where the check lives is your call, as long as leg K reaches it in process with a counting IO. In `generalBallotTick`, handed its run id by the route through `wrapCronRoute` (an optional argument the other routes ignore), is the obvious place.

**Leg K, on a `file:` copy, through the tick's own seam** (`generalBallotTick(db, io, expire)`) with an IO that counts requests:
- **Red, HEAD:** a planted `running` row started 10s ago, and the run reads (requests > 0).
- **Green, the tree:** the same plant, and the run yields: 0 requests, and the payload names the planted id.
- **Controls:** a plant started 400s ago, and the run reads; no plant, and the run reads.

## Docs

**roadmap:** the HO 778 block. It opens with **HO 777's FF go as taken** (your paste), then Corey's rulings, STEP 0, § 1, § 2 and the legs.

**backlog:**
- **The WATCH (HO 758) line:**
  - (a): the lock now stops a second call while one runs (HO 778), and the 10s pause stays as a margin. Replace the clause saying the route has no lock.
  - (c): an authorized `POST /api/cron/primaries?state=LA` after the 12:00Z tick and the last ballot call, clear of :15-:35 of an even UTC hour, with its `cron_runs` row read before (b). Keep its `isSettled` sentence. It stays blocked until the FF go's prod read closes the Louisiana line.
- **The lock line:** struck on leg K, with the prod reading owed in the FF go.
- **The Louisiana line:** unchanged. The FF go's one prod read closes it.
- **A new line, Corey's rulings,** after the WATCH, verbatim (if you file it after 2026-10-12, use that day):

```text
- **The incumbent tag after a race is called, and an incumbent running for governor: Corey's two rulings, for the HO that builds them (HO 777's review).** opened 2026-10-12; *Owner:* Code, medium; **dated: before Tuesday 2026-11-03** (`date -u -d 2026-11-03 +%A`). **Ruled 2026-10-11, verbatim,** answering the architect's two questions by selection: *"Keep the tag; Senate and district runs show their result (Recommended)"*, for what a called race's page says of an incumbent off its ballot; and *"RUNNING FOR GOVERNOR (Recommended)"*, for what an incumbent marked as leaving to run for another office shows. **Read (anchors at `e15daca`):** (1) a called race keeps HO 759's tag where HO 758's *not on the ballot* replaces it today (`components/RaceHubBody.tsx:171-178`), and a `senate` or `moved` tag turns to its own race's result in the words `/electoral`'s member rows already use (`components/RaceOpenRow.tsx:271-275`: elected to the Senate, lost the Senate race, in the Senate runoff; elected in, lost in, in the … runoff); the reason tags stand. (2) S-AL's Tommy Tuberville, Alabama's Republican nominee for governor, reads RUNNING FOR GOVERNOR where the curated flag prints RETIRING (`lib/incumbent-tag.ts:8`). The ballots CBT reads hold no governor race, so who is running is curated, with a source for each. *Close:* both on every surface that prints the tag, read on a `file:` copy with the clock at today and at Nov 4. *Reads if never done:* on Nov 4 a called race's page says *not on the ballot* of an incumbent who lost a primary or ran for the Senate, and S-AL calls Tuberville RETIRING.
```

- Reconcile, with the control at 0.

## SKILL (`docs(skill)`, alone and last)

Append one sentence to each of two bullets in § Cron topology. Land them verbatim unless the build differs, and say where.

At the end of the `/api/cron/primaries` bullet (`:1243`):

```text
**HO 778, a named state on demand:** an authorized call with `?state=XX` reads that state's House districts live (`bypassCache`, the pass's 1s pacing) if it has at most `CRON_HOUSE_SLICE` districts, reads no cursor and runs no priority pass, and logs under `/api/cron/primaries?state=XX`, apart from the tick the watchdog reads. Nothing schedules it; it's for a results night, when a state's contests can't wait for the cursor (Louisiana's Nov 3 jungle).
```

At the end of the `/api/cron/general-ballot` bullet (`:1253`):

```text
**HO 778, one run at a time:** a run that finds another `general-ballot` row still `running`, started inside the 300s ceiling, returns without reading and names that run in its payload, so a manual call beside a tick can't read the same races twice.
```

## Commits

On `778-review` from `main`, kinds unmixed:
- `feat`, § 1;
- `feat`, § 2;
- `diag`, legs L and K;
- `docs`;
- `docs(skill)`, alone and last.

Build, then the cheap gates, before every push.

## Paste back once, after the Preview and `narrow-preview`

- `ls-remote` with `778-review`'s SHA;
- STEP 0;
- legs L and K, red and green, with the preload's request log;
- the Preview, and `narrow-preview`;
- `--stat` per commit, `--numstat` for docs with every deletion explained, and the SKILL diff;
- the reconcile;
- a last cheap-gate run.

Build through to the review push without stopping. A failed claim HALTs; nothing else does.
