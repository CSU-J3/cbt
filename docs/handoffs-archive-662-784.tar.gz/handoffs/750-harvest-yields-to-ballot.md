# HO 750: the harvest yields to the ballot. Rosters come from `general_ballot` where it has a box, the incumbent is told apart by identity, and the race page stops asserting a run it hasn't read

The second half of the wire HO 749 started. `general_ballot` holds every 2026 race's November ballot on a daily pass, and nothing reads it. This HO makes the challenger harvest publish from it, which closes:

- *The challenger harvest publishes a primary result as a general-election roster, and the two diverge whenever an advancer or nominee leaves the ballot after the primary (HO 741)*, owner Code, high. HO 747 measured 40 published names off the ballot (36 runoff losers, 4 withdrawn) and about 60 major-party candidates on the ballot and unpublished.
- *The harvest's incumbent exclusion trusts a bioguide the ingest assigns by surname…* (HO 747): a namesake dropped (S-AK's second Dan Sullivan, IL-04's Patty Garcia), an incumbent published as her own challenger (CA-14, S-SC).
- *The incumbents the reader cannot tie by identity are underlined on their own ballot with a NULL bioguide…* (HO 749), high, which gates this HO: 42 stored incumbents whose title is stale or missing.

It also removes one false sentence: the race page's stub tells every unrated seat with an incumbent and no roster that the incumbent is running for re-election, and nothing checks (`components/RaceHubBody.tsx:88-92`, `:160-163`).

**Scope, fixed by ruling.** The roster this HO publishes is the field the harvest publishes today, corrected by the ballot: in party-primary states, the Democratic and Republican candidates on the ballot; in top-two and top-four states, every candidate on the ballot. Whether race pages list third parties and independents is Corey's call and is filed as his line below; nothing here decides it. Write-ins are never published. Curated rosters are untouched. Louisiana and any race without a READ box keep today's primary-sourced derivation with HO 748's clauses. Results stay out (the election-night line).

## Ground truth (read at `ebe8813`; re-derive every `:N` by content)

- `lib/harvest-challengers.ts`: `HARVEST_SOURCE = 'harvest:primary_winner'` (`:54`); `HARVEST_FROM_WHERE` (`:80-96`) with the HO 748 clauses (`:88`, `:90`) and the NOT EXISTS guard for curated rows (`:91-95`); `harvestChallengers` (`:97`) runs a DELETE of the sentinel rows (`:108-111`) and then an INSERT…SELECT (`:172-181`) as two `execute` calls, which is why the health line calls the pair not atomic. Sentinel readers outside the module: `scripts/backfill-race-challengers.ts:17,43` (a count) and a comment in `lib/pac-target-status.ts:56`.
- `lib/pac-target-status.ts:50-64`: the PAC-target rungs treat primary contest evidence as authoritative over the roster, because the roster was copied from it. Once the roster comes from the ballot, that order is backwards for a runoff loser. Not this HO's fix; it's filed below.
- `lib/race-matchup.ts:70-79`: the render-side exclusion compares `bioguide_id` in JavaScript; a row with NULL passes it.
- `lib/general-ballot.ts`: the columns (`:631-645`, `on_ballot` and `withdrawn` independent, `primary_marked`, `bioguide_id` by identity only); `titleKey` (`:114`); `loadIdentity` (`:519`); `generalBallotTick` (`:868`), which expires no cache tag. `general_ballot_reads.status` says `box`, `no_box` or `ambiguous`, NULL until read.
- `app/api/cron/race-challengers/route.ts:49` expires the `races` tag after the harvest; `lib/cache/expire-tag.ts:39` is the helper.
- The stub: `isStub` is true when the race has no rating, no rating chips, no roster rows and no runoffs (`RaceHubBody.tsx:88-92`); with an incumbent it prints *Incumbent running for re-election. No competitive rating yet.* (`:160-163`).
- SKILL quotes the harvest at `:1293` (the challenger entry, with the HO 748 predicate) and `:1926` (the pinned card's roster bullet), and its `/api/cron/general-ballot` entry (`:1205`) says nothing reads the tables.
- HO 747's numbers, which STEP 0 replaces with the ballot's: 463 boxes, 1,341 ballot rows, 82 write-ins; 40 published rows off the ballot; on the ballot and unpublished, 43 Republicans and 31 Democrats (13 of them write-ins), 469 in no primary on the page; 42 stored incumbents underlined with no identity tie; 3 more races underline another district's incumbent; 5 people printed and withdrawn (fusion lines: `on_ballot` is what says they run).

## STEP 0

1. HO number from the tree. This file assumes `main` at `ebe8813` (HO 749 landed), so this is 750. If the tree says otherwise, stop.
2. The gate: *WATCH (HO 749) · the general-ballot reader's first full pass…* must be read and struck on `main`, or at least read, with every difference from the census named. If it isn't, stop and say so.
3. Re-read every cited `:N` by content. Flag a drift.
4. Measure, prod, SELECTs only:
   - `general_ballot_reads` by `status`; races with `box`, `no_box`, `ambiguous`, never read;
   - the two capture pages: an unrated House seat whose stored incumbent is on its own ballot and has no roster rows today, and one whose incumbent is on no ballot with no roster rows (both render the stub today);
   - the 42 stored incumbents with no identity tie, and for each the underlined row's surname against `members.last_name`, so the fallback's reach is known before the change;
   - the race systems: races with a `primaries` row of `top_two` or `top_four`;
   - the curated races (rows whose `source_url` isn't a sentinel) and, for each, its curated nominated names against the ballot's in-scope names, so the divergence report has a prediction.
5. Predict the whole-table change on today's data as classes with counts (runoff losers removed, withdrawn removed and re-added as `withdrew`, major-party candidates added, namesakes now published, incumbents no longer published as challengers, fusion parties corrected, bioguides moved to identity). The prediction is a reading, not the close; the legs hold the change to it.
6. Halt if any row the change would add carries a bioguide whose member isn't that candidate. Otherwise proceed.

## The build

1. The incumbent rule, one pure function, two callers (the harvest and the page). Given a race's ballot rows and its stored incumbent: the incumbent's row is the one whose `bioguide_id` equals the stored bioguide (identity); failing that, the one row with `incumbent_marked = 1`, `bioguide_id` NULL, and a surname equal to the stored incumbent's `members.last_name` after the same normalization the census used (underline and surname); failing both, the incumbent is on no row. A namesake isn't underlined, so it never matches the second test; an underlined row tied by identity to a different member (a moved incumbent) never matches either. The function returns which route matched, so both callers can report it.
2. The harvest. For every race whose `general_ballot_reads.status` is `box` and which carries no curated row, the roster comes from `general_ballot`:
   - candidates: `on_ballot = 1`, `write_in = 0`, less the incumbent's row; in a top-two or top-four state every one of them, otherwise those whose `party` is `D` or `R`;
   - statuses: `advanced` in top-two and top-four states; otherwise `won_primary` when `primary_marked = 1` and `nominee` when it isn't (a convention, a replacement, a canceled primary);
   - `withdrew`: a person with `primary_marked = 1`, `on_ballot = 0` and `withdrawn = 1`, so an advancer who left the ballot is shown leaving it rather than vanishing (S-AK's Leslie); a runoff loser has none of these and is simply not published;
   - `bioguide_id` and `party` from the ballot row; the sentinel `harvest:general_ballot`.
   Every other race without a curated row keeps today's INSERT…SELECT, restricted to races without a `box` read, under `harvest:primary_winner`. The DELETE clears both sentinels, the NOT EXISTS guard treats both as harvested, and the DELETE and both INSERTs run in one `db.batch`, which retires the "not atomic" note. Update the two sentinel readers. The payload gains: rows by sentinel, the incumbent route counts (identity, underline-and-surname, none), and the curated races whose curated nominated set differs from the ballot's in-scope set, named.
3. The page. The stub prints *Incumbent running for re-election.* only when the rule from step 1 finds the incumbent on the race's ballot; when the race has a `box` read and the incumbent is on no row, or when it has no `box` read, the sentence is *No competitive rating yet.* alone. It says nothing new about why: what a card says for a moved, retiring or Senate-running incumbent is *A race card names a stored incumbent who is not on that seat's 2026 ballot…* (HO 747), Corey's. The lookup goes through `unstable_cache` under a `general-ballot` tag, and `generalBallotTick` expires that tag once per tick that wrote. It does not expire `races`.

## Legs, on a `file:` copy seeded from prod after the full pass, seen red before green

Seed the HO 746 way: only the tables touched (`races`, `primaries`, `primary_candidates`, `race_candidates`, `race_ratings`, `general_ballot`, `general_ballot_reads`, `member_ids`, `members`), the URL built as `file:${abs}` by construction, perturbations refusing any other scheme.

1. The whole table. Harvest the copy with today's code and with the change; diff the sentinel rows by race and name; put every difference in one of STEP 0's classes, with the count per class beside the prediction. A difference in no class is a stop. Named rows the diff must show: TX-18 without Al Green and TX-33 without Julie Johnson; S-AK with Leslie at `withdrew`, Heikes at `advanced`, the second Dan Sullivan at `advanced` with NULL, and the senator on no row; IL-04 with Patty Garcia at NULL; CA-14 without Wahab and S-SC without Darline Graham; FL-20 with Wasserman Schultz at `W000797`; Utah's convention nominees and NC-11's Balkcom at `nominee`; New York fusion rows at `D` or `R`; DE-AL and S-DE published; Hawaii's nonpartisan candidates not published; Louisiana and FL-10 unchanged; curated races unchanged, with S-GA in the divergence report.
2. The census re-read. Run HO 747's census in its saved-pages mode against the copy after the change: published rows off the ballot 0; Democratic and Republican ballot rows unpublished 0; published rows that are the stored incumbent 0; marked primary winners dropped for carrying the incumbent's bioguide 0. The residual it must name and count: non-major candidates in party-primary states and write-ins, which are unpublished by ruling. Red: the same re-read against today's harvest on the copy reproduces HO 747's 40, its 43 and 31, and its 2 and 2.
3. The incumbent rule, four ways: an identity match (FL-20); an underline-and-surname match on one of the 42 (name it); the namesake guard (S-AK's second Dan Sullivan, not underlined, published); a moved incumbent underlined in another district (one of the 3), published there with their bioguide. The perturbation: set that one-of-the-42 row's `incumbent_marked` to 0 on the copy, and the incumbent is published as their own challenger. The rule depends on the underline, and the leg shows it.
4. Atomicity. Force the second INSERT to throw after the DELETE: the old rows are all still there.
5. The stub. Through the page's own lookup on the copy: the on-ballot capture race reads true, the off-ballot one false, a no-box race null; the sentence follows.
6. The tag. Through the route wrapper with a shim: a tick that wrote expires `general-ballot` once; a tick that wrote nothing expires nothing.

## Render gates

The stub is render-touching. Captures of both capture pages from the review ref's Preview at 1440, 2560 and reduced-motion, before and after, with the rendered stub text beside each. `npm run check:design-citations` and the cheap gates.

## The prod reading, after the FF (in the FF go, not here)

One authorized POST of `/api/cron/race-challengers` right after the FF, so the ballot-sourced rosters land without waiting for 12:30Z; its `cron_runs` payload; the census re-read against prod with the same four zeros and the named residual; `/race/S-AK-2026`, `/race/TX-18-2026`, `/race/FL-20-2026` and the two capture pages as rendered.

## Commits and docs

- `feat(HO 750)`: the rule, the harvest, the sentinel readers, the tick's tag.
- `fix(HO 750)`: the stub sentence and its lookup.
- `diag(HO 750)`: the legs driver.
- `docs(skill)`, its own commit, approval requested in the paste-back: the challenger entry (`:1293`) describes the ballot-sourced roster, its scope by ruling, the statuses, the incumbent rule, the two sentinels and the fallback; the pinned card's roster bullet (`:1926`) follows; the `/api/cron/general-ballot` entry (`:1205`) says who reads the tables and that the tick expires `general-ballot`.
- `docs(HO 750)`:
  - strike the HO 741 harvest line and the identity line on leg 2's zeros, with the prod re-read's numbers in the close notes once they're in;
  - strike the stale-title gate line: the rule closes what it warned of. File its data residual: `member_ids.ballotpedia_title` stale for 32 sitting members and missing for 9, low, owner Code, closed when every stored incumbent on their own ballot ties by identity;
  - file the ingest residual from the identity line: `primary_candidates.bioguide_id` is still assigned by surname (`buildSenateMatcher`, the House matcher), the "incumbents not found" review list loses García to it, and SKILL:2784's gate sentence is false; owner Code, medium;
  - file Corey's line: whether race pages list third parties and independents (30.7% of 1,341 ballot rows print neither D nor R; median box 2, max 10; write-ins 82); owner Corey;
  - file the PAC-target authority line: `lib/pac-target-status.ts` consults primary contest evidence before a roster that is now ballot-sourced; owner Code, medium; and correct its `:56` comment in `feat(HO 750)` if it becomes false;
  - file the curated line: S-GA's curated roster still carries Dooley, a runoff loser, and the harvest never touches curated rows; owner Corey (the seed's role) then Code;
  - annotate *A race card names a stored incumbent who is not on that seat's 2026 ballot…* (HO 747): the fact is now computed and the false sentence is gone, the copy is still Corey's; annotate the Delaware line: S-DE's Republican nominee now publishes from the ballot, and the 2026-10-12 read is about `primary_candidates` alone;
  - the roadmap block, pointer 749 → 750. Reconcile OPEN LOOPS at open and close, control at 0.
- Review ref `750-review`. The FF is held for the SKILL approval, the captures and review.

## Paste back

- STEP 0's readings, the prediction, and the WATCH's reading it stands on;
- the six legs, red and green, with leg 1's class table and leg 2's four zeros and residual;
- the captures and the rendered stub text;
- the SKILL diff, for approval;
- `git show --stat` per commit, and `--numstat` for the docs commits (the deletions column, not a grep);
- the reconcile;
- the review ref's SHA from `git ls-remote`;
- a last cheap-gate run immediately before the paste, with the reading named.
