# HO 706 — FF go (architect, 2026-09-09)

**Owner verdict, verbatim: "send it"** — Corey, CBT maintenance chat, 2026-09-09, carried forward from the HO 705 go and standing on the architect's read of `706-review` at `29026da`: seven commits, kinds pure; the amend is one line of `docs/roadmap.md` (1/1) and nothing else; every SHA in the fresh `git log --oneline 71bc041..HEAD` resolves; the SKILL slot filled on `19475ed`; the Preview run for the amended tip (`34410438432`) green with the version pre-step serving `29026da` and 72 narrow lines at both widths.

Code's refinement to the SHA finding is accepted and is the better reading: the reflog was linear, so no local state ever held those three hashes — `git show --stat HEAD | tail -N` cut the header line carrying `commit <sha>`, and the gap was filled rather than read. That is the HO 671 `tail` entry one level up, and the rule the block now carries (**a commit list is read with `git log --oneline <base>..HEAD` off the pushed ref, never assembled from per-commit `--stat` output**) is the durable half. Gates not re-run for a one-sentence prose amendment on byte-identical code: correct, and stated rather than skipped.

**What this FF is.** A major version adopted as a bug fix. Vercel builds with the default `next build`, so this deploy is the first Production Turbopack build of CBT, and the served chunks carry `19.3.0-canary-cbb046ab-20260731`, the React that includes `react#35494`. The gates that matter run after the move, not before it.

## 1. The move

- `git ls-remote --heads origin` immediately before: `main` at `71bc041`, `706-review` at `29026da`. If either differs, stop and paste.
- Standing on `main`, the cleanup door: `git merge --ff-only 29026da`, then `git rev-parse main` must print `29026da…`. Then `git push origin main`, no force. Then `git push origin --delete 706-review`. Then `git ls-remote --heads origin` and `git ls-remote --tags origin` (three tags).
- Each state-changing command on its own line, stderr never suppressed. The commit list in the paste is read off the remote per the rule above.

## 2. The readings

- `npm run verify:deploy` from `main` until the served SHA is `29026da`, five consecutive reads. This one is a real build, not docs — if promotion lags past the timeout, paste the deployment list rather than wait it out.
- **The React that Production actually serves, read from the served document rather than the manifest or the directory:** fetch `/members` from prod, take its script list, and grep those chunks for the version string. Expected `19.3.0-canary-cbb046ab-20260731`, and **no `19.2.x` in anything the document requests**. This is the FF's proof that the fix shipped, and it is the reading the whole arc converges on.
- The Production `deployment_status` run: id and conclusion, the resolved-group echo (`…-Production-success-na`), the `smoke` / `odds-off` / `narrow` lines with the 72 narrow lines split 36/36 and `over=0`, and the job wall time against the 20-minute cap. **`smoke` is the one that matters here:** it is the first unattended crawl of a Turbopack build, and its `pageErr` channel is the instrument `backlog:51` closes on. A `#418` in this run is not a FF failure but it is a HALT on the close — paste the per-hit line and stop.
- `ci.yml` will fire on this push (code moved, `paths-ignore` does not cover it): quote its conclusion.

## 3. After the FF — the week that closes `backlog:51`

Seven consecutive daily `0 15 * * *` runs with the `pageErr` channel at zero close the adoption loop and `backlog:51` together, in a docs-only HO that quotes all seven run ids. A single `#418` inside that week reopens HO 705's report path with the per-hit line attached, since the fire would then be a shape `#35494` does not cover. Nothing else is owed until then; the two 705 worktrees stay on disk until the loop closes, per the method line this HO added.

## 4. Paste

The `ls-remote` line showing `main` at `29026da`, the ref gone, three tags; `git rev-parse main`; the five served reads; the served-document chunk grep; the Production run's id, group echo, spec lines and duration; the `ci.yml` conclusion. Then the week starts.

read and follow 706-ff-go — the file, not this line
