# HO 768: FF go. The ref read clean, SKILL approved, FF to `140aa77`, flush the tracker's tag, read prod, then straight into HO 769

## Rulings on the paste-back

I read all thirteen commits on `768-review` at `140aa77`. Each does what the handoff and the STEP 0 ruling asked:
- the MAP strip as `withoutCalledOdds`, and `nowMs` threaded to every client market check;
- the band's rule on `.battlefield`;
- the readout's states;
- the Tooltip on `lib/in-sight.ts`;
- the guard as ruled, with the earliest leg-ok run after P;
- the tracker's sync, pools key and tag.

I rebuilt the SKILL from the handoff's ten edits and the ruling's edit 3 and compared it with yours. It's identical except for the parenthetical you corrected.

- **SKILL `140aa77`: approved**, with edit 3's parenthetical as you landed it. The facts in mine were wrong: #18881 was HO 742's prove-out, #18897 HO 743's first departure run, 67 minutes apart across midnight UTC. Nothing below moves its sha.
- **method.md `91e6185`:** verbatim, as approved in the handoff.
- **Leg D's split is accepted.** With the pointer held still, Chromium closes a hovered panel once its trigger scrolls away, so focus carrying the 120px follow and hover the 5px one is the reading that can fail.
- **The two unmatched House rows and the ratings widget's 404 are HO 769's** (`docs/handoffs/769-ratings-source.md`). The second failure at the same fetch makes it a source question now, not something to wait out until 10-14.

## FF

`768-review` is at `140aa77` and `main` at `8752512`, so this is a fast-forward of 13 commits. No migration.

Re-run the cheap gates immediately before the push and name the reading. Then:

`git push origin 140aa77c0d6f878a077dab3e8f7a9394a01cb95c:main`, no force · `git ls-remote --heads origin` · delete `768-review` · forward local `main` and `git branch -d 768-review-local` · paste `git rev-parse main`.

If the classifier blocks the push, Corey runs the same command from your checkout.

Then run `npm run verify:deploy` **in the foreground**, then read the Production `e2e-prod` run and its smoke.

## The flush

Once Production serves `140aa77`, send one `POST /api/revalidate?tag=palestine` with `$CRON_SECRET` by env name, and paste its response.

## The prod reading

Page reads only, on Production, at 1440 and 430, `reducedMotion: "reduce"`, each one captured:
- `/electoral`, NH SEN open: two chips, Shaheen's on SEAT HELD BY and Pappas's on his member row; his card reads *#184 of 212 House Democrats*, as of Oct 2026. GA SEN open: Ossoff's chip and card as before.
- `/members/<Pappas's id>`: the Scorecard tab with 64 votes, *Rank #184 of 212*, and its link opening the tracker's House tab (`#gid=1984730710`).
- `/` at 430 with the Races tab open: the band's ELECTION DAY line alone. At 1440: its axis.
- `/electoral` in LIST with the calendar open and two dates locked: the readout names their states.
- `/electoral`'s MOVED: the 17 rows of 09-30. The dashboard's S-AK card: no MOVED.

If anything reads off, stop and paste. Otherwise **don't paste here**. Go straight into HO 769; this FF's readings are the first thing its block carries.
