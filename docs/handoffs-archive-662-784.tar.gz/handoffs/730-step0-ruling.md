# HO 730 — STEP 0 ruling: **(a)**, and row 3 was the wrong question

STEP 0 accepted. Six rows read, the bind evidence is there, `/hearings` reproduced at both widths, nothing unnamed in the consumer census, clean narrow baseline. **Go from STEP 1.**

The arithmetic checks against the readings, which is worth saying because it means the mechanism in the handoff is confirmed rather than merely consistent. At 1440: `1424 − 6 + 8 = 1426`, `1426 + 340 = 1766 > 1432`, flip to `16 + 6 − 8 − 340 = −326`, clamp to **8**. At 2560 the same line reads **8**. On `/` at 2560: `710 − 6 + 8 = 712`, `712 + 340 = 1052 < 2552`, fits — and your reading is `L712`. Three placements predicted to the pixel from `HearingDetailCard.tsx:71-73`.

## STEP 3 does not land. Take (a).

**The trigger is not merely unfired on `/` — the condition it was written for is absent there.** STEP 3 exists for a card with no side available. On `/` the right-hand placement fits at both widths, so the card is exactly where the design puts it. There is no failure to repair.

What row 3 measured is a floating card overlaying neighbouring content, which is the definition of a floating card. At 1440 the neighbour is the MOVERS feed; nobody would file that. At 2560 the neighbour happens to be the same schedule's second column. **Identical code, identical geometry, different content beside it** — so (b)'s rule would fire at one width and not the other on an unchanged tree, keyed to what sits next to the card rather than to anything wrong with the card. That is a rule whose verdict moves when the dashboard's column count changes, and it would have to be re-ruled every time the layout does.

And it buys nothing at 2560 even if adopted. The card is 517px tall (`T573 B1090`) against a row at `T573`; placing it below that row covers the rows beneath it in its own column instead. The overlap survives the fix with different rows underneath it. **(b) is a re-ruling of whether the dashboard schedule keeps a floating card at all, not a placement tweak** — which is Corey's fork, not mine and not this HO's.

So: no `fix` commit, no change to `HearingDetailCard.tsx`, and the observation goes to `docs/backlog.md` **WATCH**. Land it close to this text, with your own rects substituted if any re-read differs:

> - **The dashboard hearings card overlays its neighbour, and at 2560 the neighbour is the schedule's own second column (measured HO 730).** *Owner:* Corey, **gated** — an observation with a fork attached, not queued work. `HearingDetailCard` places itself right of its anchor and only flips when that overflows (`components/HearingDetailCard.tsx:71-73`). On `/` the right placement fits at every width read, so the HO 730 `/hearings` defect (flip → clamp → the card lands on its own anchor) **cannot occur here**: measured at `8712236`, local production build, @1440 row `L25 T574 R779 B599` / card `L781 T482 R1121 B892`, own-row overlap **0**, other schedule rows **0**; @2560 row `L25 T573 R710 B602` / card `L712 T573 R1052 B1090`, own-row overlap **0**, **12 right-column rows covered (120,360px²)**. At 1440 the same placement covers the MOVERS feed instead, which is ordinary popover behaviour and is not counted. **A below-the-anchor rule was specified and declined at the HO 730 STEP 0 ruling**: the card is 517px tall against a row at `T573`, so below-placement covers the rows under it in its own column — the same overlap with different rows — and a "covers any other row in this list" trigger would fire at 2560 and not at 1440 on an unchanged tree, keyed to what content sits beside the card rather than to a geometric failure. **The real question is whether a height-pinned glance panel should carry a floating card at all**, now that `/hearings` expands in flow and this is the component's only consumer. *Promote:* on Corey's word that the dashboard schedule converts too — which retires `HearingDetailCard`, its `.hcal-card*` CSS and `liveStatus`'s export site with it — or on a third surface adopting the card, at which point the placement is no longer one page's problem. *Reads if never done:* these rects, and one component with one consumer.

Open loops therefore reconcile **260 live / 263 struck at open, 261 / 263 at close**.

## The defect was mine, and it is a different shape from the four in `method.md`

**Row 3 asked "does the dashboard reproduce?" without defining the referent**, so a true reading and a false gate came back in the same cell. The condition STEP 3 was actually gated on is *does the flip-and-clamp path execute on `/`* — answerable in two lines of arithmetic off `:71-73` and a row's right edge, needing no server and no screenshots. I specified a check that cannot discriminate the condition it gates, then hung a commit on it.

Record it in the roadmap block as HO 730's own instance, and **name why it is not one of the four** in § Handoff discipline's new bullet: those quoted a line correctly and inferred past it. This one cited correctly, measured correctly, and asked a question whose two answers both fail to settle the gate. If that is a new shape it is a candidate for its own bullet in a later HO — **do not widen `method.md` inside this one**, and do not let the roadmap block claim it as an instance of the existing rule.

Correct one more thing in the block while you are there: the handoff's STEP 0 row 2 expected the clamp *"at 2560"*. The mechanism it stated in the same file — a full-width row leaves no side at any width — predicts both, and both read `left=8`. **The narrower expectation was the handoff's, not the mechanism's.**

## The three other deviations

**1. The diagnostic is committed, first, as its own `chore`.** `scripts/diagnostic/card-overlap-730.ts` produced the rects the roadmap block cites and is the instrument that re-reads them; the HO 724 precedent is a probe committed in a `chore` ahead of the change it measured, run blind. `scripts/` is in the root tsconfig `include`, so `tsc --noEmit` and the Vercel production build both type-check it — it ships clean or not at all.

**It must open entries by CLICK on both routes, and this is not cosmetic.** `/hearings` loses its hover path at STEP 2. An instrument that opens by hover would read `.hearing-panel 0` on the changed route and render a successful conversion as a failure — the § Gates class where an instrument goes on answering a different question after the thing under it moved. Click works on both sides of the change (`HearingsCalendar.tsx:141` today, unchanged by STEP 2), so the same invocation reads the same question before and after. Say in the paste which one it uses.

**2. Captures go to `docs/handoffs/730-artifacts/`** (repo-ignored; the `723-artifacts` precedent). Keep the four you have, add the post-STEP-2 pair, and **name each file in the paste beside the number read off it** — a capture nobody reads a figure from is decoration.

**3. The `sha:"unknown"` version stamp is accepted and is not this HO's freshness evidence.** The discriminator is the one in the handoff: with an entry open, `/hearings` reads `.hcal-card` **0** and `.hearing-panel` **1**, `/` reads `.hcal-card` **1**. Two routes, one selector, opposite directions, and the `/` half is the control — a zero on both is a stale build, not a conversion.

## Amended plan

Four commits, kinds unmixed, in this order:

1. `chore(HO 730)` — `scripts/diagnostic/card-overlap-730.ts`, with its blind readings in the message.
2. `refactor(HO 730)` — STEP 1 as written. DOM-identical proof on `/committee/hlig00` and one `/bill/[id]`.
3. `feat(HO 730)` — STEP 2 as written. Report the `.hearing-panel--agenda` padding you actually shipped, not the estimate.
4. `docs(skill)` — STEP 4 as written, its own review ref, its own approval. Unaffected by this ruling.
5. `docs(HO 730)` — roadmap block + the WATCH line + the reconcile. The block carries: the flip arithmetic and the three predicted-to-the-pixel placements, why `/hearings` has no side at any width, why STEP 3 did not land, the row-3 defect named as its own shape, and the shipped padding.

Gates unchanged except that `HearingDetailCard.tsx` is now untouched, so say so rather than omitting it — a component in the blast radius that nobody edited is a fact the paste should carry. Narrow gate at 390 and 430 with an entry **open**, against your clean baseline, plus the review ref's `narrow-preview` reading before the FF. Re-run the cheap gates immediately before the paste.

---

read `730-step0-ruling`, then continue 730 from STEP 1
