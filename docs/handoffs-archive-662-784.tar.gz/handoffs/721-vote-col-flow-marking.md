# HO 721 — `/vote`'s position lists carry `data-col-flow`: registry entry (10), the leak line's first catch cleared, and residue term (2) leaves the register by reading

The line this HO closes is `docs/backlog.md:14` (OPEN LOOPS, filed HO 720): HO 720's terminal crawl at `1cc99b8` printed **`M1c leak: unmarked col-flow: 2 (vote ul.columns-[240px] · vote ul.columns-[240px])`**, and those two rows are permanent-residue register term (2), `/vote` 2, at 149 / 149px (132 at HO 634). The register's own text already says the gap is *"the ragged fill of the final column"* (`:344`), and the component comment at `components/VotePositionList.tsx:80-92` says the same in more words. The instrument HO 719 built has named a registered residue as column flow, which is the one thing it was built to say. The close, as filed: *the marking HO in registry entry (9)'s form, after which `/vote` leaves the residue register on its reading (M1 0 · M1c 2)*.

**Three commits, kinds pure:** `feat` (the attribute and leg B's second live anchor, one commit so leg B is green at its own build — the HO 719 order left `df4bf2b` red on its own leg, and this avoids that) · `docs` · `docs(skill)` alone. No CSS change. Read-only on the DB.

**What this HO is not:** a re-tune of the column width. HO 617 ruled 240px the elbow and filed the residual decomposed; nothing here moves it. The curve is re-read because a licence carries its own measurement, not because a new width is on the table.

## Design, so STEP 0 has something to check the tree against

Same three properties as (9), applied to a second site: `data-col-flow` on the container (`VotePositionList.tsx:93`, the `<ul className="columns-[240px] gap-x-4 px-[14px] py-2">`, one per rendered position group); exemption only where the marking and the computed multi-column style agree; the container leaves M1, its `<li>` rows do not. On this page the rows are two-child `li`s (`:39-46`, a `Link` and a `span`) around 240px wide, so by the audit's own rules none is a candidate (under M1a's three-child rule and M1b's 600px floor). The units say so: **N containers / N position groups / M member rows, 0 of them scored candidates**, the (9) discipline in the other direction — the licence claims what was measured and nothing wider.

**N is not assumed to be 2.** The leak line counted candidates over threshold, not `ul`s rendered; a small position group still renders a full-width `ul` and would compute multi-column. STEP 0 counts the `ul`s on the audit's vote (`senate-119-2-207`, `layout-audit-606.ts:125`). If N ≠ 2 the `:14` close criterion is corrected at STEP 0 to *M1 0 · M1c N*, and the HALT says so.

## Ground truth (read at `a396c6f`; re-derive every `:N` by content)

- `components/VotePositionList.tsx` (~105 lines): `:25-48` `MemberItem`, a two-child `li` (`Link` + party/state `span`), or a one-child muted `li` for an unmatched bioguide; `:70-100` the per-group `<section>` → `<h2>` → `<ul className="columns-[240px] gap-x-4 px-[14px] py-2">` at `:93`; `:77-92` the HO 617 comment with the applied width curve *(260,24) 196 · (240,16) 160 · (228,12) 132 · (220,12) 132 · (200,12) 1192* and the plateau explanation. `columns-[240px]` is Tailwind's arbitrary `columns: 240px` (so computed `columnWidth 240px`, `columnCount auto`); `gap-x-4` is `column-gap: 1rem` (16px). Only site of `columns-[` in `components/` and `app/`.
- `scripts/diagnostic/layout-audit-606.ts`: `:125` `const VOTE = process.env.SEED_VOTE ?? "senate-119-2-207"`; `:209` `{ slug: "vote", path: \`/vote/${VOTE}\` }`; the `data-col-flow` classification after the viz exemption (`:469-476` → the block HO 719 added), `colFlowMarkedKeys` in the `m1` summary, the M1c legend line, the two leak lines in the totals; leg B's live half for `/electoral?cycle=2028` (the HO 719 addition, asserting key identity and a self-consistent count, plus *rows inside stay scored*).
- `docs/backlog.md:14` the line this HO closes; `:323` the registry heading *nine marked elements (eight `data-viz-row`, one `data-col-flow`…)*; `:336` entry (9), the form entry (10) follows; `:342` the residue register; `:344` term (2) with the HO 617 curve; `:358` (iv′) — *12 = 4 + 2 + 1 + 1 + 2 + 2 · M1x 306 · M1c 2*, read at `1cc99b8`; `:362` (ix).
- `.claude/skills/cbt/SKILL.md:1699` the `/vote/[id]` roll-call page passage (HO 540) — it carries no clause about the position lists' columns or the marking; `:2000-2011` the C1 exemption rule with HO 719's column-flow paragraph; `:2009` *nine markings (eight `data-viz-row`, one `data-col-flow`)*; `:2013` accepted residue is cited, never subtracted.
- `docs/oddities.md`, HO 719's entry: React renders a bare `data-col-flow` as `data-col-flow="true"`, 21 characters per site; a served-HTML check must match `="true"` or the attribute name alone.
- Nothing in `components/`, `app/`, `lib/` has changed since `1cc99b8` (`a396c6f` is two docs commits on top of it), so (iv′) is still the reading of the shipped product and (iv″) can be derived from it plus this route's re-read, named as a derivation and not a crawl.
- Estimates, not readings: N is **2**; columns rendered at 2560 **~9** per `ul` (2526px over a 240px + 16px pitch), at 1440 **~5**; the worst rag re-reads near **149**; a `--route vote` run is ~4 loads.

## STEP 0 — enumerate, HALT

| # | check | expected | if the work never happened, this reads |
|---|---|---|---|
| 1 | `git ls-remote --heads origin`; `git status --porcelain`; pointer and highest HO; machine | `main` at `a396c6f` alone; clean; 720 / 720 → **721** | anything else stops here |
| 2 | quote `VotePositionList.tsx:93`, `:39-46`, `:77-92`; audit `:125`, `:209`, the col-flow block and leg B's electoral half; backlog `:14`, `:323`, `:344`, `:358`; SKILL `:1699`, `:2009` | as in ground truth | a `:1699` that already names the columns changes STEP 3's second edit |
| 3 | `npm run build` · `npm run typecheck` | 0 · 0 | not this HO's to fix |
| 4 | legs A/B/C at HEAD | leg C **22 of 22**; leg B green on `/` and `/electoral?cycle=2028` | a red leg means no reads |
| 5 | `--route vote` at HEAD, 2560, hit 2: the route line, both `m1.rows` entries, `colFlowUnmarked` keys | **M1 2 · M1b 2 · M1c 0**, `ul.columns-[240px]` × 2 at ~149px, `unmarked col-flow 2` | **the pre-state and the control**; a route already reading 0 means the geometry moved |
| 6 | **N**: `document.querySelectorAll("section > ul.columns-\\[240px\\]").length` on the served vote page, and each `ul`'s `clientWidth`, `childElementCount`, computed `columnWidth` / `columnCount` / `columnGap`, rendered columns (distinct `li` left edges, ±2px) | N = 2 (estimate); `240px` · `auto` · `16px`; widths ≥ 600 | **N ≠ 2 corrects the `:14` close to M1c N** — say so at the HALT; a `columnWidth` reading `auto` means property 2 cannot fire and stops the HO |
| 7 | one `li`'s candidacy: `kids.length`, `siblings`, width | 2 · ≥3 · ~240 | confirms *0 of them scored candidates*; a three-child `li` changes the units |
| 8 | `--route electoral-2028` and `--route home` at HEAD | **M1 0 · M1c 2**; home **M1b 1 · M1c 0**, the (iv′) readings | the two bridge controls STEP 1 must reproduce unchanged |

HALT here with the eight rows. The go arrives as a file.

## STEP 1 — the marking and leg B (commit `feat(HO 721)`; two paths, staged by name)

1. `VotePositionList.tsx:93` becomes `<ul className="columns-[240px] gap-x-4 px-[14px] py-2" data-col-flow>`, with a two-line comment appended to the HO 617 block naming the licence (the gap is the column gutter and the final column's rag, C8's remedy; the container counts on M1c, never M1; the `li` rows are not candidates and would stay scored if they were) and pointing at registry entry (10). Nothing else in the file moves.
2. Leg B gains a second live anchor, `/vote/${VOTE}` at 2560, hit 2: every `colFlowMarkedKey` is `ul.columns-[240px]`; the marked count equals the count of `section > ul` position lists on the served page (self-consistent, so a vote with three or four positions does not break it); 0 containers scored as M1; *rows inside stay scored: 0 candidate(s)* printed as the reading, with the electoral half's *3 candidate(s), worst 9px* beside it as the contrast. Leg C is untouched (22 stays 22).
3. Local production build of this commit, then the readings:
   - `--route vote`: **M1 0 · M1b 0 · M1c N · unmarked 0 · dormant 0**; quote each container record (columns, gutter px, width, worst gap, child rows, child candidates 0).
   - **The curve, applied in the page and re-read, never modelled** (SKILL `:2002`): at **2560 · 1920 · 1440**, per `ul`: width, rendered columns, computed gutter, every adjacent-column rag, the worst interior gap the audit would have scored. Then at 2560 only, inject `columns: 220px` and `260px` and re-read the same numbers — the HO 617 curve's two neighbours, re-measured on today's list so entry (10) carries a reading and not a citation. Whether the plateau still reads 132 or has moved with the 149 is reported, not explained.
   - Bridge controls: `--route electoral-2028` **M1 0 · M1c 2** and `--route home` **M1b 1 · M1c 0**, identical to row 8.
   - Legs A/B/C: leg C 22 of 22, leg B green on all three anchors, `FALSIFICATION: PASS`.
   - **DOM floor** (HO 718 STEP 2 form, `reducedMotion: "reduce"`, `<script>` stripped): base vs branch on `/vote/senate-119-2-207` — innerText **+0/−0**; outerHTML longer by exactly **N × 21** characters, every one of them a `data-col-flow="true"` (the HO 719 oddity: match `="true"`, not `=""`). Captures at 1440 / 2560 / 430 kept, not asserted identical.
   - `npm run check:odds-sites` exit 0, count unchanged; `npm run check:design-citations` OK.

## STEP 2 — docs (commit `docs(HO 721)`; `docs/backlog.md`, `docs/roadmap.md`, `docs/oddities.md` if anything surprised)

- **`:14` strikes** on the reading, row 5 quoted as the pre-state, and the leak line's zero beside it: the instrument's first catch, cleared by the marking it asked for.
- **Registry entry (10)**, (9)'s form: `VotePositionList`'s `ul.columns-[240px]` × N on `/vote/[id]`, marking `data-col-flow`, kind **flow**, units *N containers / N position groups / M member rows, 0 of them scored candidates* (two-child `li`s under both rules), the computed style read at STEP 0 row 6, the applied curve at three widths plus the two injected widths, the leak lines' zero. The heading at `:323` goes to **ten (eight `data-viz-row`, two `data-col-flow`)**.
- **Residue term (2) leaves by reading** — its close note appended, the line kept and cited (`:2013`): *LEFT HO 721: `/vote` re-reads M1 0 · M1c N; the plateau residual was column flow, and the instrument that could say so arrived at HO 719.* The HO 617 curve stays in the line as history.
- **(iv″)** appended after (iv′), never edited into it: **derived from (iv′) at `1cc99b8` plus this route's re-read, not a crawl** — say so in the first sentence. *Site M1 10 = 4 (`/members`) + 0 (`/vote`, left, M1c N) + 1 (`/lobbying`) + 1 (`/trades`) + 2 (line (ix)) + 2 (`/welcome`, filed, not registered) · M1x 306 · M1c 2 + N.* Every other term is carried forward from (iv′) unchanged because no product path changed between the two SHAs, and that sentence is in the entry.
- **Roadmap:** one `Also (HO 721)` block, pointer 720 → 721: the readings, the curve, (iv″), and the sentence that this is the first residue term the M1c instrument moved off the register.

## STEP 3 — SKILL, alone (commit `docs(skill)`; two edits)

1. `:2009` — *nine markings (eight `data-viz-row`, one `data-col-flow`)* → **ten (eight `data-viz-row`, two `data-col-flow`)**.
2. `:1699` — one clause inside the `/vote/[id]` passage: the position lists are CSS multi-column (`columns-[240px]`, HO 617's elbow) and carry `data-col-flow` for the layout audit (M1c, registry (10)); the gap between columns is C8's remedy and not a C1 defect. Forced consequence of STEP 1, named as such. Read against the tree before it lands.

## Gates

Build then typecheck, exit 0, re-run before the paste. Leg C 22 of 22 and leg B green on all three live anchors. `--route vote` **M1 0 · M1c N** against row 5's **M1 2**. Both bridge controls identical to row 8. The curve at three widths plus two injected widths. DOM floor +0/−0 with the N × 21 delta. Both checks exit 0. Bind evidence for every local server. On the ref: the Preview `narrow-preview` run, quoting the `vote` route at 430 and 390 if the narrow spec crawls it, and saying so if it does not. The Production smoke and OFF-pass readings on the shipped bytes are owed after the FF, as always.

## Review ref, then FF

Review branch from the start; push the ref; the SKILL diff approved alone; `HEAD:main` no force; `git ls-remote --heads origin`; delete the ref; local `main` fast-forwarded and `git rev-parse main` pasted; `npm run verify:deploy` for the tip. Paste-back per method § Executing a handoff: the closure table as executed, `git show --stat` per commit, gate outputs with bind evidence, `git diff --numstat` on `docs/backlog.md` with every deletion explained (expect the rewritten `:14`, `:323` and `:344` lines), every remote claim via `ls-remote`. One swallowed block re-delivers as a gitignored file, never a second paste.
