# HO 718 — FF go (architect, 2026-09-12). Go, after one amend to the tip: the M1 reading is ruled, and the ruling ships in the block.

Clean build. Every served reading matches its STEP 0 row, the three byte-identical claims carry two controls each, the odds gate grew 11 → 12 with its entry proven load-bearing, and the CI width reading is in hand before the FF (`34731472843`, 74 passed, `electoral-2028` over=0 at both widths). Every departure from the handoff's letter is accepted; two of them were the handoff being wrong, and the block owns both.

## 1. M1 = 2 is the instrument, not the build. Ruled (i), landed as its own HO; this one ships with the residue cited.

The handoff's expected 0 assumed the layout audit reads column flow. It does not: the two M1b hits at 2560 are `.so-group-names`, CSS multi-column name lists whose rag is the column gutter, which is the C8 remedy being read as a C1 gap. Nothing is pinned right. (ii) is a per-host tune that cannot reach 0; (iii) is against the ruled mock. **(i) stands**, in the registry's grammar: the audit learns column flow and counts such containers on their own line, **M1c**, with an explicit marking on the container and a curve beside it, the way `data-viz-row` earned M1x. That is an instrument HO with a SKILL amendment to the exemption rule, not a ride-along on this ref.

**Residue nets nothing.** Amend the tip so the block and the backlog carry: *M1 on `/electoral?cycle=2028` at 2560 reads **2**, both M1b on `.so-group-names`, 200–209px, class column-flow; the handoff's expected 0 was the architect's, and wrong about what the instrument can see. Site figure not re-measured here.* The OPEN LOOPS entry Code filed becomes two: the register line under the exemption-registry entry (px, class, the price of (ii) and (iii), and that the site total awaits a full run), and the M1c instrument HO, owner Code, with this ruling quoted.

## 2. The falsification the handoff wrote was a tautology, and Code's two legs replace it

Removing `odds-only` cannot move the ON control; the handoff asked for a control that could only pass. The two legs Code ran are the right pair, and the block states them as the record: `odds-only` removed → the OFF pass fails at both widths; `data-market` removed → the new ON control fails while the OFF pass goes vacuously green, the exact case the control exists to catch. If the block does not already say the handoff's version could not fire, one sentence in the amend.

## 3. Departures accepted, with two named edges

- `tbd` kept in the type for commit 3 alone; removed with its last reader in commit 4. Right.
- Sort and grouping in the component; the query returns rows. As specified.
- `won_t run` via `_`; `" appointed"` with a leading space so *disappointed* cannot match. **Edge, named untested in SKILL's miss sentence:** a title that *begins* with *Appointed* has no leading space and misses.
- COUNT rows as a stacked grid. The handoff's `inline-grid` would have put every row on one line; mine.
- The two wrap defects squashed pre-push: tag and mark as one inline-block, no `nowrap`. The 430/390 CI reading covers it.
- SKILL `:323` and the *script constant* paragraph, false since HO 712, corrected as a flagged ride-along. Good.
- Ledger counted by the file's convention: 255 / 254 → 260 / 254.

## 4. RUNNING (D / E): the mock's silence is the setting

Corey's word covers this too. The ruled mock carried no RUNNING qualifier, so **E is the shipped state** and the D/E line stays filed as a register with owner Corey, not an ask. It is read the day he says otherwise. The Thune annotation on `:100` stands.

## 5. Mechanics

1. Amend the tip `docs` commit (`ca83e06`) with § 1 and, if needed, § 2. Nothing else moves.
2. `npm run typecheck`, `npm run check:design-citations`, `npm run check:odds-sites` at the new tip; the paste carries these readings, not the `75bb7fd` ones.
3. `git push --force-with-lease origin HEAD:refs/heads/718-review`; `git ls-remote --heads origin` is the claim.
4. `git push origin HEAD:main`, no force. `git ls-remote` again.
5. Post-FF, as owed: `verify:deploy` matching the tip on five consecutive reads; the served `/electoral?cycle=2028` reading quoted against rows 2–5 once more; the Production `odds-off` run's result on the new route, with its run id.

read and follow 718-ff-go — the file, not this line
