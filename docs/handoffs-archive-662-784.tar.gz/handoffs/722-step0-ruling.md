# HO 722 — STEP 0 ruling (architect, 2026-09-13). Ten rows accepted, disposition holds, four corrections taken, no SKILL. Go, docs-only.

The reading that decides is row 2 plus row 3: format 1 draws both spacers (rail `:341`, bottom `:421`, inside the F1 span `:336-424`) and `b5a9455` is the only commit that has ever touched them, so the pin and the ruling are the same event. Register line (x), the (1) form with (ix)'s reasoning. No letter was volunteered, so the branch at the end does not apply.

## The four corrections — all mine, all taken

1. **Mock ranges.** `:470-505` is format 2 and format 3, not 1; F1's rail is `:338-343`. Line (x) cites F1's own spacers at `:341` and `:421`, and the mock at 621 lines. The bottom-right text differing (*Synced 8:30 AM MT · next 2:30 PM* in the mock, LAST SYNC shipped) is noted in one clause: the text is HO 670's build reading, the pin is the mock's.
2. **Roadmap.** *Format 1 ruled* at `:871`, the 2026-08-17 sentence at `:853`. Cite both.
3. **No wrap at 700.** The rail reads **146px at 700**, still a scored candidate (over 120 and over the 600 floor), so line (x)'s curve says the rail is residue at every desktop width the audit reads and stays one at 700; the bottom drops under threshold between 1100 and 700 (343 → 39) without wrapping, growing to 59px tall instead. Unlike (ix), this curve is monotonic, and the line says so because (ix) was not.
4. **Variant A reads 50 / 32, not 12 / 16.** The spacer stays a flex item at `flex:0` and keeps contributing a gap; the 26px in the rail's 50 is unbroken-down and stays that way, since both readings are under threshold and the price is the idioms, not the pixels. Line (x) records 50 / 32 with the clock and LAST SYNC landing positions from row 8.

## Line (x), as it should read

`/welcome` 2 — `…__rail` **1857 / 1303 / 866 / 526 / 146** and `…__bottom` **1593 / 1093 / 683 / 343 / 39** at 2560 / 1920 / 1440 / 1100 / 700, monotonic, neither bar wrapping; mechanism `.spacer{flex:1}` (`landing.module.css:31`), one rule, two sites (`page.tsx:260`, `:426`); ruled in format 1 of `welcome-formats-mock.html` (`:45`, `:159`, F1 `:341`, `:421`), *format 1 ruled* (roadmap `:871`), Corey 2026-08-17 (`:853`), born in `b5a9455`; price: variant A 50 / 32 with the two idioms gone (brand-left / clock-right, sources-left / stamp-right), variant B not applicable on a full-bleed page (row 9, board 853×3, `max-width: none`). Leaves the register under a re-ruling of format 1's rail or bottom, or a redesign of the page.

## (iv‴)

As the handoff wrote it, derived from (iv″) plus row 6 and row 10, not a crawl: **10 = 4 + 0 + 1 + 1 + 2 + 2 · M1x 306 · M1c 5**, and the sentence that every term is now a register line — nothing filed-not-registered, nothing unexplained — for the first time since HO 619.

## SKILL

None. Your reading of the HO 721 standard is right, and the optional cross-reference is declined.

Go: STEP 1, one `docs` commit, review ref, FF.
