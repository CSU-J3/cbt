# HO 698 — the `/welcome` @430 red: read it on Ubuntu before anyone reverts or accepts (architect, 2026-09-07)

Ship state is right and the paste is right: `main = c837f4e`, served on five reads, the font gate passed once it was read from the RSC payload rather than grepped for `<link>`, and the deploy-blocking crawl went red on `/welcome` @430 at 445/430 on Ubuntu while the same bytes read 430/430 on Windows. That is HO 694's rule with the sign flipped: the host that was clean is the box, the host that reads the defect is CI. Neither of the three options offered is taken tonight, because all three decide before the 15px has been seen.

**Own the part that is the architect's.** The FF go accepted *narrow 36 passed* on the Windows box as the gate. The handoff's own Gates section said the 430 reading that counts is CI's and a local green is a prediction of it; the FF go then treated the prediction as the reading, because no CI reading was possible before FF. That is the process gap named in §4, and it sat on this side of the relay as much as yours.

## 1. What is known, and the one hypothesis worth testing first

Regression, not pre-existing: 90dc6ad read 430/430 four hours earlier on the same route and width. Host-dependent on identical served bytes **and an identical, self-hosted face**, which is the interesting part: after 697 both hosts should render Plex Mono, so a metric difference between them can only come from the window **before** the face is applied. `next/font` ships a size-adjusted `IBM Plex Mono Fallback` built on a `local()` face the box has (`Courier New`) and the Ubuntu runner does not; where the local face is missing the adjusted fallback falls to whatever `monospace` resolves to, at metrics tuned for a different face. If the narrow reading is taken before `document.fonts.ready`, Ubuntu measures that fallback and Windows measures Courier New. **Hypothesis, stated as one:** the 15px is a font-load-window reading, and the rail (the only unclipped `/welcome` element whose width is a function of mono text at 430) is the element. The diagnostic below either confirms it or names something else.

## 2. The instrument: one dispatched crawl from a diagnostic branch

`e2e-prod.yml` has `workflow_dispatch`, and `actions/checkout` runs the spec from the dispatched ref against prod. So an Ubuntu reading of prod with a better diagnostic costs one branch and one dispatch, touches nothing on `main`, and needs no deploy.

Branch `698-narrow-diag` off `c837f4e`. In the narrow spec's failure path (or a sibling spec run only when the route fails):
- every element whose document-coordinate `right` exceeds the viewport, with tag, classes, `right`, computed `font-family` and `font-size`, and **whether any ancestor between it and the root clips** (`overflow-x` other than `visible`), so the marquee spans that blinded the current dump are labelled as clipped rather than listed as suspects;
- `document.fonts.status` and `document.fonts.check('12px "IBM Plex Mono"')` **at the moment the failing width is read**;
- a second `scrollWidth` read after `await document.fonts.ready`.

Dispatch once. Three readings decide it: if the first width is 445 with `check` false and the second is 430 with `check` true, §1 holds; if the second read is still 445, the element the unclipped list names is a real layout defect under Plex Mono; if the run passes, the red is time-dependent and is said so.

## 3. Ruling by reading

- **Load-window reading (445 → 430 at `fonts.ready`):** two fixes, both land. The rail becomes metric-independent at 430 (HO 694's rule: no assumption about glyph width can push it past the viewport, whatever face is applied), because a phone on a slow connection lives in that window too and the gate's zero should mean *no horizontal scroll*, not *none once the font arrives*. And the narrow spec records `fonts.status` beside every width it reports, so the next host-dependent red carries its own explanation. Whether the spec should also *wait* for `fonts.ready` before measuring is a gate change and its own decision; the handoff for it states what its zero would stop meaning.
- **Real overflow under Plex Mono:** the named element is fixed metric-independently, same rule, as the `fix(HO 698)` commit.
- **Neither, or the dispatch cannot run:** revert `999c304` alone — the font is the only commit that moves metrics everywhere, and the tag and the `WelcomeClock` fix stay — with the diagnostic dump attached to `backlog:137`'s reopened entry. A revert is not a diagnosis, and the block says so.

In every branch the fix is verified by a **Production** `e2e-prod` run on the new `main`, quoted, because that is the only place this gate reads. The next scheduled daily stays red until then; it is a red with a named cause and a ruling in flight, and the block records the hours.

## 4. The process gap, filed rather than argued

The one deploy-blocking gate in the repo cannot run on a review ref: `deployment_status` is gated to Production, a ref push yields a Preview, so every pre-FF run was skipped and the first Production run is by definition after `main` moved. Two remedy candidates for 699, neither built tonight: a `workflow_dispatch` input that points the crawl at a Preview URL (works only if Vercel deployment protection admits the runner), or a pre-FF `narrow` run on the Ubuntu runner against a local production build of the review ref in `ci.yml` (no prod needed; the host is the point). Filed as a backlog OPEN LOOP, owner Code, with this red as its first instance; SKILL's *the 430 reading that counts is CI's* gains the clause that no such reading exists before FF until one of those lands, so the next FF go asks for what can actually be had.

## 5. Docs

This HO's block: the red with both hosts' readings and the four-hour baseline, the dispatch and its three readings, the ruling taken, the process gap, the architect's sentence from the head of this file. `backlog:137` annotated (struck entries take annotations; nothing is un-struck unless §3's third branch fires). `backlog:50` unchanged. Oddities: one entry if §1 holds — *the self-hosted face made the hosts agree only after load; the fallback is still the host's* — because it generalises to every `next/font` face in the app.

read and follow 698 — read the 15px on Ubuntu first
