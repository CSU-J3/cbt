# HO 713 — the Absence Watch band renders nothing while twelve members qualify: bisect the function, name the cause, then fix it — and decide whether "nobody" may ever render as nothing

Code kind, diagnostic-first. Surfaced in HO 712's FF paste as a reading that could not be taken: `/` carries zero `abw-*` elements, no `<dt>`, no band header, while the code's own Phase-A query run against production returns eleven House members and one senator who missed every one of the last eight roll calls (Donalds, Dunn, Garamendi, Kaptur, McCaul, McConnell among them), all `is_current = 1`, none delegates, all above `PARTICIPATION_FLOOR`, surviving a population of 530. The band was empty before HO 712 as well: the HO 712 DOM diff for `/` read **1984 → 1984, +0 / −0** against a baseline built at `ad63b85`. A live home-surface reading is silently absent. Its own STEP 0, not a ride-along.

## Ground truth at authoring (`main` at `bc77e3b`, 2026-09-11; re-derive at STEP 0)

- **Number.** Pointer 712, highest HO in commit subjects 712 → 713.
- **The read path.** `app/page.tsx:40` `force-dynamic`; `:128` `getAbsenceWatch()` in the home `Promise.all`; `:162` `<AbsenceWatchBand members={absent} nowMs={nowMs} />`. `components/AbsenceWatchBand.tsx:111` `if (members.length === 0) return null` — the C4 good-news state renders nothing at all.
- **The function and its cache.** `lib/queries.ts:5339` `queryAbsenceWatch()`: population with the delegate carve in SQL and `PARTICIPATION_FLOOR` (`:5352`, `:5355`); the last-*N* roll calls `SELECT id, vote_date FROM votes … ORDER BY vote_date DESC, id DESC LIMIT ?` (`:5385-5388`); Phase A, the population filter, Phase B, then per-member card assembly whose failures log `[absence-watch] card assembly failed for <id>` (`:5562`) — read at STEP 0 whether a failed card is dropped or the whole array is. `:5572` `unstable_cache(queryAbsenceWatch, ["getAbsenceWatch"], { revalidate: 3600, tags: ["votes"] })`; `:5583` `getAbsenceWatch()` is the degradation guard **outside** the cache boundary (HO 598), returning `[]` and logging `[absence-watch] read failed` on a throw.
- **Who flushes `votes`.** `app/api/sync-votes/route.ts:74` `if (house || senate) expireTag("votes")`; `app/api/cron/amendments/route.ts:84` and `:107` on changed Senate materialisation or walk links. TTL one hour otherwise.
- **What is already known, from the 712 paste.** No `[absence-watch] read failed` line in production runtime logs over a window in which the log path is proven readable (156 entries for `/`). **The HO 712 DOM baseline and branch were local `next start` builds with cold `.next/cache` directories, reading the production database directly, and both rendered `/` with no band.** If that reading holds, the Vercel Data Cache is not the cause: a cold local cache that recomputes `queryAbsenceWatch` against prod and still yields nothing is a function-level or data-level cause, not a stale entry. This is the first thing STEP 0 confirms, because it decides which half of the table matters.
- **Absence Watch rules of record.** SKILL § Absence Watch (the C-rules, the Phase A window of 8, Phase B's 120-roll walk, `not_voting`-only extension, the dated copy). Read the section before bisecting; a member the rules exclude on purpose is not a defect, and the paste's twelve came from Phase A alone.

## STEP 0 — bisect, then HALT

Every reading is the function's own code path, never a paraphrase (HO 711's lesson, fresh). Raw output under `docs/handoffs/713-artifacts/`; exit codes printed; a control beside every zero.

| # | check | expected / what a zero means |
|---|---|---|
| 1 | confirm the cache exclusion: build `main` locally, cold `.next/cache`, `next start`, `curl /` → count `abw-` occurrences; and call `queryAbsenceWatch()` **directly** from a scratch script against prod (dotenv, `getDb`), uncached, printing `length` | served 0 and direct 0 → the function; served 0 and direct 12 → plumbing between the function and the band (cache, guard, prop); direct throws → the guard is hiding it and the prod-log claim needs re-reading |
| 2 | bisect inside the function: export (or copy verbatim into the scratch) each stage and print its count — population · last-8 rolls with their dates and chamber split · Phase A survivors · after the population filter · after Phase B with each member's rating · after card assembly, with any `card assembly failed` output | the stage where 12 becomes 0, named with the predicate that did it |
| 3 | the last-8 window's shape: the eight `votes` rows by chamber and `vote_date` — is the window per chamber or across both? If across both and one chamber has not voted, the other chamber's members "miss" rolls they never had | the SKILL rule versus the code, quoted |
| 4 | the twelve, per member: `member_votes` rows for the last 8 rolls of their chamber (position per roll); `is_current`; `next_election_year`; the HO 711 resync's departed list checked against them | Phase A counted a missing row or a `not_voting` row; which |
| 5 | production runtime logs for `[absence-watch] card assembly failed` and for the read-failed line, same window as the 712 paste's 156-entry control | present → row 2's stage; absent with the control present → the function returns `[]` cleanly |
| 6 | when did the band last render on production? `git log -S'abw-' --oneline` is not it; the answer is the earliest deploy whose served `/` lacks `abw-` — read the Vercel deployment list and `curl` two or three historical preview URLs for `abw-` (they serve their own build against the live DB) | a date bracket for when it went dark, or "cannot be bracketed" said plainly |
| 7 | flush and re-read, only after rows 1–2: `POST /api/revalidate?tag=votes` with `$CRON_SECRET`, then `curl /` | changes nothing if row 1 excluded the cache; if it changes something, row 1 was wrong and says so |
| 8 | SKILL exposure: `grep -n "Absence Watch\|C4\|good-news\|abw-\|getAbsenceWatch" .claude/skills/cbt/SKILL.md` | the entries the fix and the ruling below will amend |

**HALT** with the stage and predicate named, the twelve classified, and the proposed fix in one paragraph. The fix is not pre-specified here because the cause is not known here; a handoff that names a mechanism from memory is the thing STEP 0 exists to catch.

## The ruling requested from Corey, at the HALT

**May the good-news state render nothing?** This incident is the argument that it may not: an empty band and a broken band are byte-identical, so a home surface went dark for an unknown period and nothing — no gate, no log, no reader — could tell. The architect recommends the two-zeros rule applied to the render: when `getAbsenceWatch()` returns `[]`, the band renders **one dated line** — *No member has missed the last 8 roll calls · through <date of the 8th-most-recent roll call>* — in `--text-dim`, no cards, no header treatment. The date comes from the same `votes` read the function already makes, so the copy is dated from data, never from the clock (HO 712's rule). The alternative is keeping C4 as null and adding an instrument instead (a smoke assertion that `/` carries either `abw-` cards or the dated line — which is the same rule arriving as a test). **Options: *dated line* · *keep null, add the gate* · *both*.** Recommended: *both*.

## STEP 1 — build (after the HALT clears)

- **Commit 1 — `fix(HO 713): <the cause, named>`** — the function-level or plumbing fix from STEP 0, with a control that reproduces the dark state on a fixture before the fix and shows the band after it.
- **Commit 2 — `feat(HO 713): the band's empty state is a dated line`** (if ruled) — `AbsenceWatchBand.tsx:111` replaced by the one-line render; the date threaded from the function's roll-call read (a new field on the return, or a `through` prop from the page); captures at 1440 / 430 in both states via fixture props; `.abw-empty` additive CSS.
- **Commit 3 — `test(HO 713): the home band is never silent`** (if ruled) — `e2e/smoke.spec.ts` or the fit-finish set: `/` must carry either `.abw-card` or `.abw-empty`; a zero on both fails the run. This is a gate that can fail, proven by a fixture render with the band removed.
- **`docs(skill)`** — Absence Watch section: the cause and its rule; C4 rewritten to the dated-line form if ruled; the two-zeros sentence.
- **`docs`** — backlog: new WATCH if the cause is periodic; strike nothing unless STEP 0 closes an existing line. Oddities: *a home surface dark for an unknown period because its good-news state and its broken state render identically*, with the date bracket from row 6 or the statement that none could be established. Roadmap block.

## STEP 2 — proof

Build then typecheck. The direct `queryAbsenceWatch()` call returns the twelve (or the rule-correct subset, with the rule quoted for each exclusion). Served `/` after FF carries `abw-` cards with the MIA and AT RISK counts matching the direct call. The empty state proven from a fixture, never by emptying prod: the band with `members=[]` renders the dated line, and the smoke assertion fails on a fixture page carrying neither. DOM diff on `/` against `bc77e3b` reads **+N / −0** where N is the band's element count, and nothing else moves. Captures at 1440 / 430 / reduced-motion for the band in both states.

## STEP 3 onward

Review ref `713-review`, `git ls-remote --heads origin`, the Preview `narrow-preview` reading, paste, hold for the go.

## Paste-back

The STEP 0 table with the bisection's per-stage counts and the twelve classified; the date bracket or its absence; per-commit `--stat`; the fixture proofs for both the fix and the empty state; the gate failing on the fixture and passing on the tree; captures; SKILL and docs diffs with numstats; `git ls-remote --heads origin`.

read and follow 713
