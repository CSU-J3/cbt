# HO 697 — approved · FF go

Read on the ref at `c837f4e`: `63249f4` tag · `bdab54f` fix · `999c304` font · `1b54f1d` probes (four scripts and nothing else) · `45e8737` SKILL alone · `c837f4e` docs. The eleven blob hashes match the previous tip exactly, so no code moved while the history did; every touched blob is LF; ancestry is a clean FF from `90dc6ad`; both tags sit on the remote. **The SKILL slot closes on the read of `45e8737`:** the layered clause is gone, the `CyclingTimestamp` sentence describes the shipped tree, and the tag, mono and `/welcome` paragraphs read as approved. The block opens on what shipped and names the hold in the same sentence; the three contradicting sentences are gone (the one remaining *three render sites* in SKILL is the hearings helper at `:1676`, untouched and unrelated).

## Execute

1. Re-verify immediately before the push: `git ls-remote --heads --tags origin` still reads `main = 90dc6ad`, ref tip `c837f4e`, both tags in place. Drift is a HALT.
2. Fast-forward `main` → `c837f4e` with `git push origin HEAD:main`, no force. Confirm with `git ls-remote`. Delete `refs/heads/697-review`; the two tags stay.
3. `verify:deploy` on five consecutive reads. Then the prod font gate: one `<link rel="preload" as="font">` per Plex Mono weight in the served `/bills` HTML (four expected, the sans preloads as the control), and `document.fonts.check('12px "IBM Plex Mono"')` true after `document.fonts.ready`, host named.
4. Quote the `design citations` run on the `main` push and the `ci.yml` run, id and conclusion.
5. Quote the next `e2e-prod` smoke result when it lands, fires and routes, as the first reading of the post-ship instrument named in the block.

## Paste-back

The `ls-remote` line showing `main = c837f4e`, the ref gone and the tags present; the served SHA; the preload count and the `fonts.check` reading with the host; the two run ids; the smoke result when it arrives. Nothing else.

read and follow 697 — FF go
