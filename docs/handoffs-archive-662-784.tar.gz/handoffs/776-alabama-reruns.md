# HO 776: Alabama's four rerun districts. AL-01, 02, 06 and 07 store their August 11 special primaries, the contests that chose their nominees, and the voided May round is recorded in oddities. With HO 775's FF readings

**Corey's ruling, 2026-10-11 about 4:50 PM MT:** asked what Code should do next, he picked *Alabama's primaries* (store the Aug. 11 special primaries for AL-01, 02, 06 and 07 from the saved pages, with the voided May round marked) over *Done for today*.

**Scope, in:**
1. The backlog line *Four Alabama districts voided their May 19 primaries and held special primaries on August 11…* (HO 773).
2. A new line for the defect behind it: the House sync puts a page's special and regular boxes for one party into one roster. Filed, not fixed.
3. HO 775's FF go, into this block.
4. AL-01's reading, at this HO's STEP 0 or its FF go, whichever first falls after 2026-10-12 02:22Z, with HO 774's three reads. If neither does, it carries.

**Out:** the House sync's merge itself, and every other OPEN LOOPS line.

**How STEP 0 runs** (method.md, HO 768's rule): the claims are mine and are a check. The readings carry their own HALTs, listed below them.

**Base:** `main` at `e76610e`. HO number: the pointer is 775 and the highest HO in commit subjects is 775, so this is 776.

## The design: replace the voided round, and record it in oddities

Every reader that shows a House primary reads the base row, `house-{ST}-{DD}-2026-{party}`:
- `getPrimaryForRace` reads only base rows for a House member, since it skips `-special-` ids (`lib/queries.ts:1652`);
- the calendar groups every first-round row by date (`getPrimaryCalendar`, `:1732`), base rows among them.

So the base row takes the contest that chose the nominee: August 11's date, runoff date and roster. A `-special-` row beside it would never reach the member's primary, and a voided row kept in the store would need every reader taught to skip it. So the May round leaves the store, and an oddities entry records it, each district's May marks taken from W1's backup. That's where the voided round is marked.

The sync can't put the May round back. Each rewritten row is dated 2026-08-11, which is before today and past the 30-day settle window, so `isSettled` freezes its date and roster (`lib/primaries-sync.ts:1842`) whether or not it carries a mark.

## STEP 0

| # | Claim at `e76610e` | Fails if |
|---|---|---|
| 1 | `lib/primaries-sync.ts:1873` builds a House contest's roster with `result.candidates.filter((c) => c.contest === contest)`, so a page's special and regular boxes for one party land in one base row. `parseCandidatesPage` keeps the boxes apart: its dedup key carries specialness (`lib/primary-candidates-scrape.ts:430-439`), and each runoff round (`ScrapedRunoff`, `:92`) carries its date and specialness. | |
| 2 | The House per-contest write checks `isSettled` before it writes a row's date or roster (`lib/primaries-sync.ts:1842`). | the date is written outside the check |
| 3 | `getPrimaryForRace` skips `-special-` ids for a House member (`lib/queries.ts:1652`), and `getPrimaryCalendar` (`:1732`) groups `election_round = 'primary'` rows by date. | another House-primary reader that doesn't read the base row |
| 4 | `SAVED_PAGES_DIR` is `docs/handoffs/747-artifacts/pages` (`lib/primary-identity-repair.ts:42`). `createRunoffWriter` (`lib/primaries-sync.ts:985`) is exported. | |
| 5 | SKILL's runoff section ends with the paragraph that begins *Seed → page (HO 761).* (`:2607`), which occurs once. | |

**The readings**, by SELECT and from the saved pages only. Nothing fetches Ballotpedia.
- **R1, the store:** every `primaries` row whose id begins `house-AL-01-2026`, `house-AL-02-2026`, `house-AL-06-2026` or `house-AL-07-2026`, runoff rows included, each with its candidates (name, party, status, `vote_pct`, `bioguide_id`, `person_key`, `updated_at`). Say which round each roster holds: May's, August's, or both.
- **R2, the pages,** through `parseCandidatesPage`, for each of the four:
  - the note about the voided round, and its dates;
  - per party, the regular box and the special box (names, marks, shares, person keys);
  - every runoff round (date, specialness, marks).
- **R3, the ballots:** each race's `general_ballot_reads.status`, its printed rows, and the four races' incumbent qualifier readings.
- **R4, the class:** HO 747's saved House pages that carry a special primary box, listed. That sizes the new line.

**HALT** with the readings if:
- a page lacks the note, or names a date other than August 11;
- a party has no special primary box, or more than one;
- a party's decided nominee isn't printed on its race's general ballot, by `person_key` or exact name. The decided nominee is the special box's one mark, or its special runoff round's one mark;
- a race's ballot isn't read (`status` other than `box`), so the check above can't run;
- a stored runoff row is neither dated 2026-06-16 (the voided round's) nor matched by a special runoff round.

## The build

### § 1, the repair (`fix`)

`scripts/repair-al-special-primaries-776.ts`. It reads only the saved pages and is dry by default.
- **`--plan-out <file>`** prints and saves the plan:
  - for each base row `house-AL-{01,02,06,07}-2026-{D,R}`: `primary_date` 2026-08-11, `runoff_date` (the party's special runoff round's date, or NULL), its other columns unchanged, and the roster, which is the special box's rows: name, party, incumbent, `status` from the mark, `vote_pct`, `person_key`, and `bioguide_id` NULL;
  - each special runoff round, as its `-runoff` row, the way `writeRunoffRounds` writes one (`createRunoffWriter`);
  - each stored runoff row dated 2026-06-16, as a delete.
- **`--write --plan <file>`:**
  - first saves every row the plan touches, with its candidates, to `<dir>/before.json`;
  - then writes exactly the plan in one batch: each base row's two dates and `updated_at`, its candidates deleted and the plan's inserted, the runoff rows, and the deletes with their candidates;
  - refuses a plan whose rows have changed since it was read, by `updated_at`.
- **Its header says why:** Alabama voided four districts' May 19 primaries, and the Aug 11 special primaries chose their nominees. The sync can't tell a rerun from an additional contest, and the settled freeze keeps the write.

## The writes, after § 1, before the review push

**W1:**
- the dry run, `--plan-out`. The plan holds exactly the eight base rows, plus a `-runoff` row for each special runoff round R2 found and a delete for each stored runoff row dated 2026-06-16. Anything else, **HALT**.
- `--write --plan`. Read back the eight rows and their rosters.

**W2:** `npm run repair:primary-identity -- --saved-only`, dry first.
- Its bioguide changes must be NULL → member, on rows W1 wrote. Anything else, **HALT** with the list.
- Then `--write`.

**The flush:** `POST /api/revalidate?tag=races`, with `$CRON_SECRET` by env name.

**The readback:**
- `getPrimaryCalendar`'s SQL for 2026-05-19 and 2026-08-11: AL on both;
- the four races' incumbent qualifier readings, against R3's. Expected unchanged, unless an incumbent lost an August 11 primary. Say which.

## Docs

**roadmap:** the HO 776 block. It opens with **HO 775's FF go as taken** (your paste):
- the SKILL replacement at `:2589`, and the architect's ruling on its parenthetical: approved with your wording, since `MemberHeader` kept its own copy until HO 509 (`8538660`), and with your backticks;
- the FF and its build and gates;
- `verify:deploy` and the Production build's cache line;
- `e2e-prod` #38181099884;
- leg A on Production;
- no flush;
- AL-01 skipped at 22:28:51Z.

Then Corey's ruling, the design, STEP 0 and the readings, § 1, W1, W2, the flush and the readback.

**backlog:**
- **The Alabama line,** struck, with a close note naming the eight rows rewritten to August 11, any runoff rows, W2's ties, and the oddities entry.
- **A new line, the merge,** with:
  - what it does: `lib/primaries-sync.ts:1873` filters a House page's boxes by party alone, so a special box and a regular one share the base row;
  - R4's count;
  - why the four are safe now: their rows are settled;
  - *Close:* the House path routes a special box the way the Senate router does, or the class is ruled;
  - *Reads if never done:* the next House page that carries both boxes for one party merges them.
- **Moore's line,** struck on AL-01's reading if you took it.
- Reconcile, with the control at 0.

**oddities:** a new entry. Its heading and first paragraph are verbatim, and then come the four districts' voided May marks, from `before.json`:

```text
## Alabama voided four districts' May 19 primaries, and the store keeps only the reruns (HO 776, Oct 2026)

AL-01, AL-02, AL-06 and AL-07's Ballotpedia pages each say: "The winners of the special primary on August 11, 2026, advanced to the general election on November 3, 2026. The winners of the primaries originally scheduled for May 19, 2026, did not advance as those results were voided." Every reader of a House primary reads one base row per district and party, so since HO 776 that row holds August 11's contest, and the May round is recorded here, not in the store.
```

**SKILL**, in its own `docs(skill)` commit, last. After the paragraph at `:2607`, add a paragraph with a blank line before it, verbatim:

```text
**A voided round is replaced, not kept (HO 776).** When a state voids a primary and reruns it, the base row (`house-{ST}-{DD}-2026-{party}`) takes the rerun's date, runoff date and roster. `getPrimaryForRace` reads only base rows for a House member (it skips `-special-` ids), and a voided row kept beside the rerun would need every reader taught to skip it, so the voided round goes to `docs/oddities.md`. Alabama's AL-01, 02, 06 and 07 are the case: their May 19 results were voided, and the August 11 special primaries chose the nominees (`scripts/repair-al-special-primaries-776.ts`, from HO 747's saved pages). The House cursor can't make this call, since it puts a page's special and regular boxes for one party into one roster (`lib/primaries-sync.ts:1873`, filed), so a repair makes it once and the settled freeze keeps it.
```

## Commits

On `776-review` from `main`, kinds unmixed:
- `fix` § 1;
- `docs`;
- `docs(skill)`, alone and last.

W1 and W2 are this HO's prod writes, and the flush. Nothing else writes. No migration. Build, then the cheap gates, before every push.

## Paste back once, after the Preview and `narrow-preview`

- `ls-remote` with `776-review`'s SHA;
- STEP 0, R1 to R4, and AL-01's reading if taken;
- W1's plan and readback, W2, the flush and the readback;
- the Preview, and `narrow-preview` against #38181030823: equal cell for cell, or each difference traced to the write;
- `--stat` per commit, and `--numstat` for docs with every deletion explained;
- the SKILL diff;
- the reconcile;
- a last cheap-gate run.

Build through to the review push without stopping, unless a HALT says otherwise.
