# HO 730 — SKILL diff approved; one line to add, then FF

## SKILL `15de2f7` — **approved**

Read at the ref, not from the report. Fetched `730-review` (`693bd57`, ancestry from `8712236`, `main` unmoved), ran `git diff 15de2f7~1 15de2f7` in full, and swept the whole file for residual claims. Two lines changed, both correct:

- **`/hearings`** — the mechanism, the SSR-DOM clause with **by click** carried into it, the card's removal with the HO 611 cause named, the pointer's move to `a.hearing-panel-link` with the *select it by section* caveat (both the Recorded-votes and Committee links carry that class — the caveat is right and I hadn't asked for it), and the grid→agenda correction. HO 717's `n = 0 → no link` reading survives, correctly tagged as HO 717's.
- **`/committee/[systemCode]`** — the `Chamber` key documented once, on the surface where the redundancy lands, with the reason. Cross-reference rather than restate is the right call; `/hearings` correctly does not repeat it.

Swept for stale survivors: every `HearingDetailCard` and `hcal-card` mention in the file is inside the rewritten `/hearings` entry and describes `/` only. Nothing else in SKILL claims the card is on this route.

One nit, **not a change request**: `Entry`'s HO 611 comment still ends *"same handlers, same detail card — only the internal layout changed,"* which is a true statement about HO 611 and false about the tip. Your HO 730 note sits directly beneath it, so a reader gets both. Leave it.

## Own the two that are mine

**`HearingDetailCard.tsx` is not untouched — my ruling was wrong.** STEP 1 changes it by design: its `locationText` copy becomes an import and its inline vote predicate becomes `hasRecordedVotes`. I wrote "untouched" while specifying the edit two steps earlier in the same document. The accurate form is the one your commit message already uses — **no placement change**. Flag-don't-absorb caught it; nothing to fix.

**"Four commits" over a list of five** is a miscount in the ruling file, not an instruction. Five is right.

The other three deviations are accepted as handled: the ruling file landing untracked at `.claude/` and moved to `docs/handoffs/`, SKILL naming no home for the three helpers so there was nothing to fold, and the diagnostic growing past its STEP 0 shape. **The `MSYS_NO_PATHCONV` guard is the best thing in this HO** — a route selector that matched nothing, printed nothing and exited 0 is § Gates' own subject, and it was caught by a control rather than by luck. It reads as a candidate for an `oddities.md` field note whenever something next touches that file; not now.

## One line before the FF

`components/HearingsCalendar.tsx:31` imports `liveStatus` from `@/components/HearingDetailCard` — **a route that deliberately stopped rendering the card still depends on its module.** `liveStatus` is a pure function of `CommitteeMeeting` and `LIVE_WINDOW_MS`, which `lib/hearings.ts:101` already owns, three lines from `watchState`; STEP 1 moved three helpers there for this exact reason and this one was not in the list. Three import sites, no behaviour.

**Do not move it now** — that is a sixth code commit and a full re-gate for a symbol relocation. **File it**, because the ledger's own header says nothing is tracked only in chat, and the WATCH line's promote clause only covers it if Corey ever converts the dashboard.

The `docs(HO 730)` commit is the tip and a roadmap block is a workspace until its FF lands (§ Doc authority), so amend it rather than adding a sixth:

> - **`liveStatus` still lives in `HearingDetailCard`, which `/hearings` no longer renders (found HO 730, 2026-09-16).** opened 2026-09-16; *Owner:* Code, low. `components/HearingsCalendar.tsx:31` imports it from `@/components/HearingDetailCard` after HO 730 removed the card from that route, so the agenda keeps a module dependency on a component it deliberately stopped rendering. It is a pure function over `CommitteeMeeting` and `LIVE_WINDOW_MS`, which `lib/hearings.ts:101` already exports three lines from `watchState` — the home HO 730's `refactor` gave `WATCH_LABEL` and `locationText` and did not give this. Three call sites (`HearingsCalendar`, `HearingsDaySchedule`, `HearingDetailCard` itself). **Too small for its own commit and deliberately not taken at HO 730's FF**, which would have meant a sixth code commit and a re-gate for a symbol move. *Close:* `liveStatus` and `LiveStatus` move to `lib/hearings.ts` on the next commit that touches that file, with the three imports repointed; or it is struck here with a reason. *Reads if never done:* `import { liveStatus } from "@/components/HearingDetailCard"` in a file that renders no card.

Update the block's reconcile to **262 live / 263 struck at close** and its backlog figure to **4+/0−** (two lines, two separators) so the block ships true rather than being corrected afterwards. `--force-with-lease` on the ref only.

**The SKILL approval is unaffected by the amend** — `15de2f7` sits below the tip and its sha does not move. Do not re-request approval for it.

**And do not re-run the CI width reading.** `e2e-prod` run `35171017144` read `15de2f7`'s Preview at 430/430 and 390/390 `over=0`; a docs-only amend changes no served bytes, so that run remains the reading of this code. If Vercel builds a fresh Preview off the amended tip and `narrow-preview` fires again, fine — report it. If it does not fire, say so rather than reporting a missing check as a failure (the HO 729 form).

## FF go

After the amend and the re-push of the ref:

`git push origin HEAD:main`, no force · `git ls-remote --heads origin` · delete the ref · forward local `main` and paste `git rev-parse main`. Then the Production `e2e-prod` read and `verify:deploy` — this one changes served bytes, so both are real and both are owed.

Paste back the amended block and backlog diff, the `--numstat` (deletions column, not a grep), the two remote claims via `ls-remote`, and a last re-run of the cheap gates immediately before the paste with the reading named.

---

read `730-ff-go`, then amend, re-push the ref, and FF
