# HO 719 — STEP 0 ruling (architect, 2026-09-13). All eight rows accepted, five flags ruled, two amendments, one finding filed. Go.

Good STEP 0. Row 5 is the control the whole HO stands on and it read exactly as `(viii)` recorded it (200 / 209px, width 1251, four columns at 16 / 333 / 650 / 966). Row 7 settles that property 2 can fire (`columnWidth "272px"`, `columnCount "auto"`), and row 8 is the reason property 3 is `matches` and not `closest`, now measured rather than argued: the qualified rows are M1a candidates in their own right at 9px. None of the five flags is a fork; all are ruled here. Nothing waits on Corey.

## 1. Stale backlog anchors — accepted, no action

`:117 → :118` and `:114 → :115` are the HO 718 close-out insert at `:14`. Every `:N` in STEP 3 re-derives by content, which is the rule already; the commit message names the corrected numbers as HO 718's did.

## 2. `docs/backlog.md:322` "seven marked elements" — accepted as a named ride-along in STEP 3

The registry heading is where (9) lands, and the count it carries is already false by one. Correct it to the count as it stands after (9): eight `data-viz-row` markings and one `data-col-flow`. Same shape as SKILL `:2007` in STEP 4; the two counts move together in the same HO so they cannot drift apart again. Name it in the paste as a ride-along.

## 3. Leg C "unchanged" — ruled: verdicts unchanged, v4-D's readings printed side by side; and the fixture gains a FOURTH assertion

Your reading of v4 (4) is right: M3 samples every repeated-sibling group with ≥2 element children, so the new rows enter its page-wide mean and the reading moves while the verdict (`mean > 0 · ≥ 4 groups`) holds. "Unchanged" means the 18 verdicts unchanged, with v4-D's before/after pair printed beside each other. The other 17 are regex-scoped to their own `legc-*` class and CAL M1x counts only `[data-viz-row]`, as you say.

**The fourth assertion is the one that tests property 3 instead of asserting it.** On the live page the inner rows are candidates but sit at 9px, so `matches` and `closest` read identically there — a `closest()` implementation would pass all three cases as written. Add, inside `legc-colflow-pos`, three rows of class `legc-colflow-innerrow` (three spans each, `display: flex; justify-content: space-between`, so each row's interior gap inside its ~288px column is ~150–170px, over threshold). Expected: **the container reads M1c 1 · scored 0, AND the three inner rows read M1a 3**, over threshold, inside the exempt container. A `closest()` exemption reads M1a 0 here and fails. Keep the other ten rows at two children so the case's remaining geometry is unchanged.

Leg C therefore reads **18 + 4 = 22** at STEP 1's close, not 21; STEP 1.2's blind-state run still reads the positive container as M1b 1 (the instrument blind), and the inner rows as M1a 3 both before and after (the control that survives the change).

## 4. Row 8 scope — accepted; the units say it

Property 3 stands. The (9) units and each M1c container record read: **34 name rows, 3 of them scored candidates** (the qualified rows; the 31 two-child rows at 301px fall under both M1a's three-child rule and M1b's 600px floor and were never scored). The licence then claims exactly what was measured. The fixture assertion in § 3 is where the property earns its keep.

## 5. Row 7 on the local build — accepted, no prod read

The audit's own target rule (`layout-audit-606.ts:32-35`) is a local production build, never prod — BotID withholds a C1 row from headless Chrome — so a prod read of a computed style would be a reading of a page the instrument never measures. Same source at `64c5dbb`, same CSS chunk. Declined as written, for that reason.

## 6. Caught in relay, filed not left in chat: `/` reads M1b 1 and the residue register carries no `/` term

Row 6: `home` at `64c5dbb` reads **M1b 1, `div.week-sentences-row`, 995px** interior gap at 2560. The residue register's closing identity (iv) is **9 + 2 + 3 + 1 = 15** with no `/` entry, and the last restatement predates the week-summary row (HO 689/690). So this is either an unpriced C1 defect or an unregistered residue, and today nothing on the record says which. **Not this HO's to fix.** STEP 3 files it as its own FIT & FINISH line, owner Code, its own HO: the reading quoted (route, class, px, viewport, SHA), the observation that (iv) does not carry it, `git log -S week-sentences-row -- app components` to name the introducing commit, and a close that is either a fix under the C1 rules or a priced register line with the site total restated. The bridge control in STEP 1.4 must still reproduce it unchanged — it is part of the pre-state.

## Amendments to the handoff, collected

- Leg C count: **22** at close (18 + the three cases + the inner-row assertion).
- `legc-colflow-pos` carries three `legc-colflow-innerrow` rows; the fourth assertion is stated in § 3.
- STEP 3 gains: the `:322` heading correction (ride-along, named) and the `/` M1b filing (§ 6).
- Units for (9) and the container records: *34 name rows, 3 of them scored candidates*.
- Anchors as you re-derived them (`:469-476`, after `:476`; `:1015-1033`; `:1546-1553`) stand; the handoff's are superseded by content.

Everything else in the handoff stands as written. Go: STEP 1 from the fixture, blind-state run second.
