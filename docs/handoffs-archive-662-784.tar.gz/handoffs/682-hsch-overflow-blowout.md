# HO 682 — the day schedule blows out on one long title

Code kind. **Time-sensitive evidence:** the exhibit is live on the dashboard today (Wed Sep 2) and leaves the shown day at midnight. STEP 0's reproduction and STEP 2's RED leg run first, before anything else in the session beyond the open protocol.

## Premise

Today's schedule (16 scheduled) carries a markup whose published Congress.gov title is the full semicolon-joined ten-measure list ("H.R. 642 (Rep. Steube), 'Myakka Wild and Scenic River Act of 2025'; H.R. 5478 (Rep. LaMalfa), …"). On the live `/` HEARINGS tab at wide viewport, that one row paints unclipped across the page, the whole `.hsch-wrap` inflates, and column B of the two-column split — NOW marker, the 2:00p birthright-citizenship hearing — lands roughly a thousand pixels to the right of the MOVERS panel. The document scrolls horizontally. Screenshot on file in chat.

The ellipsis kit exists and is defeated: `.hsch-title` carries `overflow: hidden; text-overflow: ellipsis; white-space: nowrap; min-width: 0` (`app/globals.css:8860-8867`). The two column divs it lives under are **unclassed** `<div>`s (`components/HearingsDaySchedule.tsx:287-289`) sitting as grid items in `grid-template-columns: 1fr 1fr` (`app/globals.css:8815-8825`, breakpoint ≥1700px). Grid items default to `min-width: auto`, so the expected mechanism is the track sizing to the nowrap title's single-line min-content instead of compressing it — **expected, not established.** The mechanism is a claim; STEP 0 measures it before anything is edited.

Not in scope: the title data. The string is what the API published; `cleanMeetingTitle` (`HearingsDaySchedule.tsx:69`) is doing its job, and the `+N →` chip already carries the measure count. No fork here — the stylesheet already states the ellipsis intent; this restores it.

## Ground truth at authoring

- Remote `main` `5bdbe9e` (HO 681 docs), pointer 681, number `max(681, 681) + 1 = 682`. Re-derive at session open.
- Two-column split engages at `rows.length >= 6` (`SPLIT_MIN_ROWS`, `:53`) and ≥1700px. Today has 16 rows, so both conditions hold on the live exhibit.
- The week ribbon's day cells (`:232` region) may keep the exhibit reachable after today if a shown-day selection exists; verify rather than assume. If the row is unreachable when you run, the fixture path in STEP 2 replaces the live RED leg and says so.
- HO 681's lesson rides: both proof legs run against fresh builds, never a warm dev cache — the 681 RED leg first passed stale.

## STEP 0 — reproduce, enumerate, HALT

Reproduce first, on today's data, local build: `/` at ≥1700px CSS width, HEARINGS tab, confirm `document.documentElement.scrollWidth > clientWidth` and note the reading. Then the table: candidate · verdict · evidence `file:line` · destination. Nothing edited before the HALT.

| # | candidate | expected at HEAD |
|---|---|---|
| 1 | the unclassed column divs | `components/HearingsDaySchedule.tsx:287-289`; also the per-row `<div key={m.eventId}>` wrappers at `:206` region, same default |
| 2 | the track rule | `app/globals.css:8815-8825` (`1fr 1fr` ≥1700px) |
| 3 | the title kit, present and defeated | `app/globals.css:8860-8867` |
| 4 | **the failing joint(s), by bisection at the repro** | with the blowout live, add `min-width: 0` in DevTools level by level — column divs first, then the row wrapper, then `.hsch` (`:8722`), then the HEARINGS tab container and the dashboard column above it — and record the level(s) at which `scrollWidth` snaps back to `clientWidth`. That measurement, not the premise, decides where the committed rule lands |
| 5 | why the **page** scrolls instead of the panel clipping | name the ancestor that propagates intrinsic width to the document scroller; if the fix at row 4 already closes it, record that; if a second constraint is needed on an ancestor, it lands in the same commit with its own evidence line |
| 6 | siblings sharing the pattern | other `1fr`-tracked lists on `/` with unclassed children over nowrap descendants; enumerate by grep + eyeball, fix only `hsch` here, FILE the rest if any exist |
| 7 | `/hearings` | whether its week/calendar surface renders these rows or only shares `.hsch-cell` (`globals.css:9049-9054` says cells); if rows render there too, the fix must cover it and the captures include it |
| 8 | e2e home | `e2e/fit-finish.spec.ts` is the only spec touching HEARINGS; no `scrollWidth` assertion exists anywhere in `e2e/` today — the invariant is new, state where it joins |
| 9 | SKILL | whether the hsch layout has a passage; the candidate rule to record — children of `1fr` tracks that contain nowrap text carry an explicit `min-width: 0` — is a SKILL edit needing its own approval if row 6 shows the pattern is repo-wide |

**HALT. Corey rules on the table.**

## STEP 1 — implement (one code commit)

1. The constraint at the level(s) row 4 measured — expected shape `.hsch-wrap > div { min-width: 0; }` plus, only if measured necessary, the row-wrapper or one named ancestor. Nothing speculative: every committed line has a row-4 reading behind it.
2. The invariant, durable and data-independent: in `fit-finish.spec.ts`, on `/` at 1440 and 2560, both tab states (HEARINGS and RACES), assert `document.documentElement.scrollWidth <= document.documentElement.clientWidth`. This is the class-catcher: it holds after today's row rotates out and fires on the next long-title day anywhere on the page.

`npm run typecheck` and `npm run build` clean before anything else.

## STEP 2 — proof

- **RED/GREEN on the live exhibit, today:** the new assertion red at `5bdbe9e`, green on the change, both against fresh builds (two worktrees, the HO 679/681 way), both readings quoted with the actual `scrollWidth`/`clientWidth` numbers. If the exhibit has rotated out by run time and no day selection reaches it, substitute a deterministic fixture: a local, uncommitted edit injecting a ≥1,200-char title into one row, RED/GREEN against that, revert, `git status --short` clean apart from the pre-existing design mocks — and say which path was taken.
- **Captures, mandatory, perishable:** `/` HEARINGS tab at 1440 and 2560 plus reduced-motion, taken while the long-title row is on the shown day, showing both columns inside the panel, the long row ellipsized, NOW marker and the 2:00p row seated in column B. If row 7 put `/hearings` in scope, same set there.
- The strip stays untouched: one `FED CUT SEP` per copy in the 2560 capture, order SHUTDOWN · FED CUT · RECESSION (HO 681's live read must still hold).

## STEP 3 — docs (and SKILL if row 9 says so)

Backlog: FILED lines for anything row 6 surfaced. Oddities: one entry — the mandated 1440/2560 captures passed at HO 610/670 because the defect is data-dependent; a capture is about the data on the table that day, and the durable form of the gate is the invariant, not the screenshot. Roadmap `Also (HO 682)`, pointer to 682. SKILL commit alone before docs if approved at row 9.

## STEP 4 — review ref, FF, ship

Push to `refs/heads/682-review`, `git ls-remote` confirm, paste the sha and `git log --oneline 5bdbe9e..HEAD` (code, then SKILL if any, then docs). Local `main` stays at `5bdbe9e` until approval. On approval: fast-forward, delete the ref, `npm run verify:deploy`, served SHA, and one last live read: `/` HEARINGS at wide viewport, no horizontal scrollbar, column B seated beside column A.

## Paste-back

STEP 0: the repro reading and the table at the HALT. After STEP 2: the two e2e readings with numbers, which RED path was taken, the capture set. After STEP 4: the ls-remote line and the served SHA.

read and follow 682
