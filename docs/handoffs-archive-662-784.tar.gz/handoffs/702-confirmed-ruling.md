# HO 702 — the confirmed branch, ruled for the commits (architect, 2026-09-08)

Accepted as measured, in the words the data supports: **hydration starting before the flight tail is necessary, not sufficient.** 47 hyd-after-tail hits across control and t2t1′ with zero fires; 10 of 10 fires HYD-BEFORE-TAIL; removing the condition by construction (t2t1′, HYD-BEFORE-TAIL 0/36) removed every fire; and the lever raised `main` itself from 0 to 10 of 36, so the reproduction is the app's, not the tagged tree's. The mechanism as you state it is the one the block carries, with `layout-router.js:276`, site `7622`, the `<header>` ↔ `header-titlebar` seam and the absent root boundary named, and the necessary-not-sufficient sentence beside it so nobody reads *window* as *cause of every fire*.

## 1. What the four commits say

- **test:** Arm A as built (filter, `parser-dropped`, partitions, landmarks, `last-flight`, `first-post-t`, `hyd-start`, `TIMEOUT` as a state) plus `preserve-dumps` and its `globalSetup`. The spec header states the channel's contract and its budget in one paragraph.
- **chore:** the patch script, guarded and marker-verified, header carrying the slot defect and the managed-path trap as the two things the next diagnostic patch checks first.
- **SKILL, alone:** the `mut` channel and what it measures; the mechanism with its five cites, stated as confirmed by intervention on 2026-09-08 with the window's figures; **the lever** — `t2` (document throttled to 1500 kbit/s with JS cached) reproduces the class on demand, and `t2t1′` (chunks held to `DOMContentLoaded`) is its off switch — because that pair is now the gate for any fix; the necessary-not-sufficient sentence; and one sentence that two falsifiers were mis-specified and inverted the verdict when corrected, so the next reader trusts the comparator and not the first table.
- **docs:** the block carries **both windows**, the mis-specified one and the corrected one, with the two mis-specifications named as the architect's and the numbers that inverted them; `backlog:50` gains *a named node, a named site and a named mechanism, confirmed by intervention (window 00:42–00:53Z, 2026-09-08)* and stays **live**: the close is cause plus green, and the fix is HO 704; the `e2e/**` typecheck OPEN LOOP per §4 of the previous ruling; oddities gets one entry for the template-literal backtick and the filtered pipe, the fourth instrument that could not fail this HO, with the constraint comment quoted. Evidence paths cited.

## 2. HO 704's gate, fixed now so the fix is written to it

Candidate (a), one line: an explicit `<Suspense>` around `{children}` in the root layout, so a suspension at the page segment has a boundary that resets the hydration cursor on retry — the path React takes for dehydrated boundaries and the one the root lacks. Its gate is the pair this window produced: **control → t2 → t2t1′ on the fixed build, t2 must read 0 (TIMEOUTS counted separately) where it read 10 of 36 without the fix, in one continuous window against an unfixed control in the same window.** Then the daily prod crawl's fire rate over the following week. The fallback (a′), if the boundary alone does not zero t2, is a Suspense boundary at the layout-router seam itself, which is Next's to place; that is where candidate (b), the minimal reproduction and the upstream report, starts. Read the React 19.2 and Next 15.5 changelogs before writing (b); a fix already shipped is a version bump, not a report.

## 3. Then

The four commits, `702-review`, architect read, SKILL slot, FF. The one shell is the server; it goes with the last crawl.

read and follow 702 — confirmed, commit it
