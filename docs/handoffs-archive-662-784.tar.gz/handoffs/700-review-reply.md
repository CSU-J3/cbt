# HO 700 — review reply. Rebase first: `main` moved under the ref. Then land it; both dead arms are the finding.

Read on the ref at `df325e6`: three commits, kinds pure, every blob LF, the probe as the record of a measured negative, one SKILL bullet, the block, the oddity, two backlog annotations. **The premise this side handed you was wrong and the arm measured it wrong in one run:** React 19 dispatches the recoverable-hydration `ErrorEvent` at detection, before the recovery commit, so the fire-time DOM is the SSR DOM by construction. Owned. Your refusal to make the commit was per the handoff and right; the `fireCaught` / `fireCount` / `fire-t` metadata that separated *correct listener, pre-recovery DOM* from *broken listener* is the reason the arm was abandoned for the right reason, and the oddity that records that trap is the most useful sentence in the HO.

## 1. `main` is at `f14707f`, not `15cde5e`

`git ls-remote` reads `refs/heads/main = f14707f` — `docs(HO 701): the README catches up to the repo`, landed 2026-09-07 12:57 −0600, while HO 700 was running. The ref is based on `15cde5e`, so it is **not** a clean FF; both sides touch `docs/roadmap.md` and `docs/backlog.md`. Rebase the three commits onto `f14707f`. Roadmap: HO 700's block **appends after HO 701's**, the pointer stays at 701 (it names the highest HO landed, and 700 is now inside it), and 700's block gains one sentence saying it landed after 701 and why (the instrument arms ran across the day). Backlog: the two annotations re-apply mechanically. `--force-with-lease`, `git ls-remote --heads`. The SKILL blob must come through the rebase unchanged: quote `git rev-parse <new tip>:.claude/skills/cbt/SKILL.md` against `08bfecc`'s.

## 2. Two corrections to the record before it lands

- **CRLF is not the blob norm.** The paste says *"CRLF-in-blob is this repo's norm: roadmap.md 1423/1423 and smoke.spec.ts 676/676 at origin/main."* Byte-counted off the blobs, not the working copy: `docs/roadmap.md`, `e2e/smoke.spec.ts`, `docs/backlog.md`, `docs/oddities.md` and SKILL all carry **0 carriage returns** on `main` and on the ref; `git ls-files --eol` reads `i/lf` for every one. What is CRLF is the **working copy**, because `core.autocrlf=true` converts on checkout — the HO 695 oddity says exactly this. The 708/708 flip was an editor writing one ending into a file checked out with the other, and the byte-level redo was the right repair. The claim did not reach the docs; it stays out of them.
- **"two years of prod fires"** (the oddity's first paragraph) is **six weeks**: the entry opened 2026-07-29 at the first observed run. Fix in place.

## 3. Approved as read

The probe, tracked, with the dev-mode reading in its header. The SKILL bullet: both narrowings marked measured-dead so neither is re-attempted from reasoning. The oddity, with §2's fix. The `:50` annotation (open, cause unnamed, two routes closed by measurement) and the `:27` filing (the marquee, not the tape, is what fails hover on a localhost target). The block's conclusion that the next capture must be event-driven, not time-tuned.

## 4. For the record, not for this HO: what the readings say about the next instrument

Put together, the six fires say more than either arm alone. The fire-time DOM is element-identical to SSR; the settled DOM on the tapeless amplifier routes is SSR plus the clock's two spans and the announcer, every one of them effect-driven. So **the recovery render produced the server's structure.** The node React refused to match was in the *first* client render and nowhere else; it never touched the DOM, and no snapshot at any offset can show it. Two things follow, and they are the shape of the next HO if Corey wants one:

- **A `MutationObserver` from `addInitScript`, all node types, every record timestamped**, aligned against `fire-t` after settle. The recovery commit's records are the part Code already wanted event-driven. The part nobody has looked at is **the records before the fire**: a DOM the browser or a streaming script changed *under* hydration (Next's boundary-completion scripts move content into place; an extra text or comment node is invisible to an element-token LCS, and `+0/-0` cannot rule it out) is the one mechanism that fits a structural `HTML` mismatch, a recovery render identical to SSR, hit-2 dominance (cached data changes chunk timing) and a rate that moves by the hour. Stated as a hypothesis with a named instrument, not as a lead.
- **Production React with its message widened, locally.** Development mode does not fire; production mode cannot name the node. The third option is production timing with a patched `react-dom` in the amplifier worktree only: at the `#418` throw site, append the fiber's type name and parent chain and the `nodeName` / snippet of the hydratable instance it failed to match. Never committed to dependencies, never on the crawl; a diagnostic build for a diagnostic tree. One fire names the component and the node in the same line.

## 5. Then

Rebase, force-with-lease, `git ls-remote --heads`. Paste: the three new SHAs with `--stat`, the SKILL blob hash matching `08bfecc`'s, the `design citations` run on the new tip, the two §2 fixes in the diff. FF go follows the read of the rebased docs diff.

read and follow 700 — review reply, rebase onto 701 and fix two lines
