# HO 711 — the race-row set equals the seat set: at-large ids, the phantom retraction, and an audit that reads on every backfill

Code kind: one data-layer extension, one curated one-shot correction, one standing instrument. Closes backlog :79 (`backfill:races` mints and never retracts) and :80 (at-large seats have no race row), the two build-shaped loops HO 710 opened on the electoral spine, and amends the HO 710 SKILL clauses that the closure makes false. Corey's brief: *"lets finish up electoral."* Session open reconciles the ledger first: backlog :29 (HO 333 stranded components + owed eyeball) shows both halves **DONE** in its own text and still sits in OPEN LOOPS; strike it to DONE and count it.

**One ruling is requested and one is not.** Not requested: the at-large id token. `lib/kalshi.ts:59-62` `houseRace` already emits `{ST}-AL-2026` for an at-large ticker, `components/RaceHeader.tsx:10` already renders `district === 0` as *At-Large Congressional District*, and `lib/primaries-sync.ts:57` stores at-large as `district: 0`. The format is the one the existing writers chose: **id `{ST}-AL-{YYYY}`, `races.district = 0`**, and the single rule that joins them lives in `lib/race-id.ts`. Requested, one word from Corey, and it rides only if the word is *apply*: backlog :35 (the `/members` HOUSE bucket counts delegates, 437 current against 435 voting) — the fix is the same territorial carve this HO gives a name to, so it is cheapest here, and it is Corey's call by the ledger's own text (*decide: voting-only, or leave it*).

## Ground truth at authoring (`main` at `e714a53`, 2026-09-10; re-derive at STEP 0)

- **Number.** Pointer 710, highest HO in commit subjects 710 → 711. HO 712 (the 120th-Congress rollover) is authored alongside and does not depend on this one.
- **The id format, three sites plus one that already disagrees.** `lib/race-id.ts:17-24` returns `null` for `chamber='house'` with `district == null`; `scripts/backfill-races.ts:33-37` translates it and `:55` excludes those members (`AND (m.chamber = 'senate' OR m.district IS NOT NULL)`); `getSeatOutlook`'s derived-id `CASE` in `lib/queries.ts` (the HO 710 block, `ELSE NULL` for a null district). `lib/kalshi.ts:59-62` is the fourth writer and the only one that already produces an at-large id: `dd = ddRaw === "AL" ? "AL" : pad2(...)` → `${st}-${dd}-2026`. Whether any such row exists in `kalshi_odds` is a measurement (STEP 0 row 5).
- **At-large population.** HO 710 STEP 0 row 4: `members` at `chamber='house' AND is_current=1` reads 433 = 421 numbered + **6 at-large** (AK, DE, ND, SD, VT, WY; `district IS NULL`) + 6 territorial (`district IS NULL`, `state IN ('DC','AS','GU','MP','PR','VI')`). Montana stores 1 and 2. Every one of the six has `next_election_year = 2026`, so the extension mints six `{ST}-AL-2026` rows.
- **Consumers of `races.district` and of the seat id shape.** `lib/harvest-challengers.ts:49` joins `CAST(p.district AS INTEGER) = r.district` — with `races.district = 0` and primaries at `0`, the at-large join works with no change. `lib/district-geo.ts:28-29` carries `cd "00" = at-large` and `seatId: {ST}-{DD}-{cycle}; null for at-large`, `:55` `atLarge: boolean`, `:112-114` a numeric-only regex on `seatId` — the geometry side needs one bridge (`cd "00"` ↔ `{ST}-AL-{cycle}`), enumerated at STEP 0 row 7. `components/RaceHeader.tsx:6-23` already has the `district === 0` branches (long and compact). `lib/format.ts:148-150` documents *District 0 is rendered as "At-Large" by the caller*.
- **The outlook's footnote gate is about to become wrong.** `components/SeatOutlookList.tsx` renders the at-large clause when a House row has `district == null`; after this HO those rows have a `raceId`, so the gate must read `raceId == null` (and today evaluates to nothing either way, since House rows are 0 until the 120th).
- **SKILL clauses this HO makes false.** Race IDs paragraph: *Members with `chamber='house'` and `district IS NULL` are excluded from the backfill so the id can never be malformed* and *the six at-large voting seats … have no race row anywhere in the app*; the Seat outlook sub-section's House paragraph (*At-large seats render `{ST}-AL` with a null `raceId`, and the footnote discloses …*); `backfill:races` entry (*Expected ~435 House + ~33 Senate*; the new *mints and never retracts* sentence gains the audit line); the `/race/[id]` pages entry's *ID format* sentence. STEP 0 row 9 enumerates the exact lines.
- **The phantoms, read 2026-09-10 (HO 710 STEP 0 row 2 and its 2030 control).** Cycle 2028: 38 rows; `S-FL-2028` and `S-OH-2028` carry Rubio and Vance (`is_current = 0`; the seats' current holders Moody and Husted carry `next_election_year = 2026` from `data/senate-special-elections.json`); `S-MN`, `S-MS`, `S-NE`, `S-NJ` at 2028 have no Class 3 member behind them at all. Cycle 2030: 36 rows; `S-AK`, `S-OR`, `S-SC` have no Class 1 member behind them. Nine rows, two kinds.
- **The precedent for deleting a race row.** HO 412 `a3a2a18` §2 deleted `S-CA-2026` and `S-NY-2026` after enumerating dependents across seven tables (all 0) and establishing the backfill could not recreate them. Read the commit for the table list rather than this sentence; any `race_id` column added to `scripts/migrate.ts` since then joins the list.
- **The standing guard.** `scripts/diagnostic/senator-year-audit-410.ts` prints SECTION 1 impossible values, SECTION 2 class cross-check, SECTION 4 `is_current` reconciliation (the SECTION 3 population is referenced from the backfill comment; confirm whether it prints). Race-row integrity has no section anywhere; `backfill:races` prints `Inserted/updated (rowsAffected): N` and nothing about what it left behind.
- **The territorial carve exists as an inline literal at four sites in `lib/queries.ts`** (`:2892` the outlook, `:5121`, `:5322`, `:6823`) and in three diagnostics. No constant. This HO introduces one and uses it at the sites it touches; the four existing literals stay byte-identical (their routes are not this HO's) and the fold is filed.
- **Backlog :35** reads *house bucket 449 total / 437 current*; the readout is on `/members`. Owner Corey; the word decides.

## The rule, pre-stated

- **One function owns the at-large mapping.** `raceIdFromMember` gains the carve: House + `district == null` + state not territorial → the at-large seat, id `{ST}-AL-{YYYY}`; House + `district == null` + territorial → `null` (a delegate has no race). A new exported `districtToken(d: number | null)` (`0` or `null` → `"AL"`, else `pad2`) and `TERRITORIAL_STATES` in `lib/states.ts` are the two names every other site reads. The backfill SQL and the outlook `CASE` translate the same rule and say so; the keep-in-sync note stays at **three** SQL/TS copies and now also names `lib/kalshi.ts` as the writer whose token the rule adopted.
- **`races.district` is `0` for at-large**, so `RaceHeader`, `harvest-challengers` and `primaries` need no change, and `raceLabelCompact` reads *AK At-Large* for free. `members.district` stays `NULL` (Congress.gov's shape); the `0` is derived at the race row, stated in the schema comment.
- **Phantoms have two kinds and two dispositions.** *Wrong-cycle*: a Senate row at cycle *c* in a state with no `is_current = 1` member of `senateClassForCycle(c)` → **delete** (7 rows). *Departed incumbent*: a row whose `incumbent_bioguide_id` is `is_current = 0` — if a current member maps to the same id, the backfill heals it on its next run (run it first, then measure); if the seat's current holder maps to a different cycle (FL/OH 2028), **delete**, because `backfill:races` recreates the row correctly once the holder's year rolls; if no current member holds the seat at all (a House vacancy at 2026), **set `incumbent_bioguide_id = NULL`**, which is the schema's own vacancy semantics and what `/race/[id]`'s placeholder already renders. Every row is listed with its disposition at STEP 0 before anything is deleted, and dependents are enumerated per row.
- **Retraction stays manual; silence ends.** `backfill:races` gains a read-only audit at the end of every run — `phantoms: wrong-cycle N [ids] · departed-incumbent N [ids]` — and `senator-year-audit-410.ts` gains SECTION 5 with the same two predicates and the same output shape, one implementation imported by both. A routine script that deletes rows is a hazard; a routine script that says what it left behind is an instrument.
- **Close criteria, restated from the two backlog lines so this HO can strike them.** :80 — `raceIdFromMember` returns `{ST}-AL-{YYYY}` for the six and `null` for delegates; six rows exist with the sitting incumbent and `district = 0`; `/race/AK-AL-2026` renders *Alaska At-Large Congressional District* with Begich as incumbent; the member-hub NEXT ELECTION chip on an at-large member is a link. :79 — the SECTION 5 audit reads **0 / 0** at 2028 and 2030 after the pass, having read **7 / 2** before it (the 2026 departed-incumbent count is a reading, not a criterion, and is quoted).

## STEP 0 — enumerate, then HALT

Raw output to `docs/handoffs/711-artifacts/`; exit codes printed; nothing `tail`ed.

| # | check | expected | reads if the work never happens |
|---|---|---|---|
| 1 | `git checkout main && git pull`; pointer and highest HO; OPEN LOOPS count; **strike :29 to DONE** (both halves read DONE in its own text) and recount | pointer 710 → 711; the strike is one line moved, counted | :29 keeps sitting live with a DONE body |
| 2 | at-large roster: `SELECT bioguide_id, name, state, district, next_election_year FROM members WHERE chamber='house' AND is_current=1 AND district IS NULL ORDER BY state` | 12 rows: 6 at-large (AK, DE, ND, SD, VT, WY) + 6 territorial, all at 2026 | the same; this is the mint list and the carve list |
| 3 | `SELECT id FROM races WHERE id LIKE '%-AL-%' OR (chamber='house' AND district = 0)` | **0** rows | a non-zero means someone minted at-large rows by another route |
| 4 | run `npm run backfill:races` (its designed heal), then the departed-incumbent predicate: `SELECT r.id, r.cycle, r.incumbent_bioguide_id, m.name, m.is_current, m.next_election_year FROM races r JOIN members m ON m.bioguide_id = r.incumbent_bioguide_id WHERE m.is_current = 0 ORDER BY r.cycle, r.id` | FL/OH at 2028 plus the 2026 House vacancies; each row classified *heals / delete / NULL* per the rule | the same list; the pass is what changes it |
| 5 | wrong-cycle predicate: for each `S-*` row, `senateClassForCycle(cycle)` against `members` in that state at `is_current=1` | exactly `S-MN/MS/NE/NJ-2028` and `S-AK/OR/SC-2030` — **7** | 7 |
| 6 | `SELECT race_id, COUNT(*) FROM kalshi_odds WHERE race_id LIKE '%-AL-%' GROUP BY race_id` and the same on `polymarket_odds` | a reading; if rows exist they are loose links this HO closes | the loose links stay loose |
| 7 | dependents per row for every *delete* candidate from rows 4–5: the HO 412 §2 table list read off `a3a2a18`, plus `grep -n race_id scripts/migrate.ts` for columns added since | all 0, or a per-row list that changes the disposition | a dependent silently orphaned |
| 8 | geometry bridge: `grep -n "seatId\|atLarge\|\"00\"" lib/district-geo.ts lib/cartogram-data.ts components/RaceDistrictModal.tsx` | the one place `seatId` is built from `cd`, and whether the modal's pick chips key on it | the at-large state outline stays unclickable to its race |
| 9 | SKILL exposure: `grep -n "district IS NULL\|no race row anywhere\|At-large seats render\|Expected ~435 House\|never retracts\|<STATE>-<DD>-<YYYY>\|update \*\*all three\*\*" .claude/skills/cbt/SKILL.md` | the lines listed under ground truth; quote each | a clause left contradicting the tree |
| 10 | `senator-year-audit-410.ts`: does a SECTION 3 print? what does the script's header say it guards? | the section list, so SECTION 5 slots in without renumbering | — |
| 11 | territorial literals: `grep -rn "'DC','AS','GU','MP','PR','VI'" lib app components scripts` | four in `queries.ts`, three in diagnostics | the count the fold line is filed at |
| 12 | `/members` readout, only if Corey's word is *apply*: where the HOUSE bucket is computed and what it reads served today | the query and 437 | 437 |

**HALT.** Rows 4 and 5 as a closure table — every row with id, incumbent, disposition and dependents — for Corey's eye before a single DELETE. The at-large token is not on the table. Corey's one word on :35 arrives with the go.

## STEP 1 — build

Review branch `711-review-local`. Kinds pure; explicit pathspecs.

**Commit 1 — `feat(HO 711): at-large race ids — one rule, three translations`**
- `lib/states.ts`: `export const TERRITORIAL_STATES = ["DC","AS","GU","MP","PR","VI"] as const` and `sqlList(TERRITORIAL_STATES)` (or an equivalent quoted-literal helper) for the SQL sites.
- `lib/race-id.ts`: `districtToken`, the carve, the at-large arm; the header comment names the four sites and the Kalshi token; `MemberLite` unchanged.
- `scripts/backfill-races.ts`: the id `CASE` gains `WHEN m.chamber='house' AND m.district IS NULL AND m.state NOT IN (…) THEN m.state || '-AL-' || m.next_election_year`; the `district` column expression writes `0` for that arm; the WHERE keeps delegates out via the carve instead of `district IS NOT NULL`. Comment states the `0` is derived.
- `lib/queries.ts` `getSeatOutlook`: the `CASE` gains the same arm; `raceId` therefore non-null for the six.
- `components/SeatOutlookList.tsx`: footnote gate `raceId == null`; label unchanged (`{ST}-AL` already).
- Geometry bridge per row 8, smallest change that makes the at-large outline resolve to `{ST}-AL-{cycle}`; if row 8 shows it is more than a mapping function, it is filed instead and said so.

**Commit 2 — `feat(HO 711): the phantom audit, printed by backfill:races and by the standing guard`**
- `lib/race-row-audit.ts` (new): `auditRaceRows(db)` → `{ wrongCycle: [...], departedIncumbent: [...] }` using `senateClassForCycle`; one implementation.
- `scripts/backfill-races.ts`: after the insert, print the audit line.
- `scripts/diagnostic/senator-year-audit-410.ts`: SECTION 5 · RACE-ROW INTEGRITY printing the same.

**Commit 3 — `fix(HO 711): retract seven wrong-cycle rows, drop two orphaned 2028 rows, null departed incumbents on vacancies`** — a one-shot script under `scripts/oneshot/` (or the repo's existing home for HO 412's shape), each DELETE / UPDATE by explicit id list from the HALT table, dependents re-checked immediately before each, `rowsAffected` read back per statement, then the audit run: **0 / 0 at 2028 and 2030.** The script is committed as the record of what was done, with the HALT table in its header.

**Commit 4 (only on *apply*) — `fix(HO 711): /members HOUSE bucket counts voting seats`** — the carve on the bucket query, the readout's label made honest (`HOUSE 435`-shaped, but the number is the reading), captures at 1440/430.

**Commit 5 — `test(HO 711): race-id at-large cases`** if a unit harness exists for `lib/`; otherwise the fixture assertions live in the STEP 2 scratch and the commit is skipped and said so.

## STEP 2 — proof

- Build then typecheck, exit codes. `check:design-citations` OK. `check:odds-sites` before/after (no market render changes; both readings pasted).
- **`raceIdFromMember` table**, from a scratch: `{house, AK, null, 2026}` → `AK-AL-2026`; `{house, DC, null, 2026}` → `null`; `{house, MT, 2, 2026}` → `MT-02-2026`; `{senate, FL, null, 2026}` → `S-FL-2026`; `{house, AK, 0, 2026}` → `AK-AL-2026` (the 0 path). And `tickerToRaceId("HOUSEAKAL-26")` → `AK-AL-2026` equals the new rule's output — the two writers agree, measured.
- **Prod, in order:** `npm run backfill:races` → `Inserted/updated` and the six new ids read back with `incumbent_bioguide_id`, `district = 0`, `cycle = 2026`; `races` count before/after (**+6 exactly**, after the pass's −9 is accounted separately); the one-shot pass with its per-statement read-backs; the audit line **0 / 0** at 2028 and 2030; the 2026 departed-incumbent reading after. `POST /api/revalidate?tag=races` with `$CRON_SECRET`.
- **Served after FF (in the FF go):** `/race/AK-AL-2026` renders the at-large title and Begich; `/members/<Begich bioguide>` NEXT ELECTION chip is a link to it; `/electoral?cycle=2028` unchanged (34 rows, 3 tags — the six are 2026 seats); `/electoral` 2026 unchanged in DOM (the six have no rating row, so the rated set is untouched: **186 → 186**, measured); the audit line in the backfill output.
- **Falsification:** the audit is run once against a scratch copy of the predicate with one id from the delete list re-inserted in a fixture table (not prod), reading **1**, so the 0 is a 0 of an instrument that fires.
- Captures at 1440 / 430 for `/race/AK-AL-2026` and the member hub chip; reduced-motion not implicated (no motion). If commit 4 rides: `/members` at 1440 / 430.

## STEP 3 — SKILL (own commit)

Race IDs paragraph rewritten to the rule (at-large arm, `districtToken`, `TERRITORIAL_STATES`, `district = 0` derived, Kalshi as the token's origin, delegates `null`, four sites named); the Seat outlook House paragraph amended (the six now carry a `raceId`; the footnote clause is gated on `raceId == null` and is expected never to render on a voting seat); `backfill:races` entry: expected rows **441 House + ~34 Senate**, the audit line as the run's last output, *mints and never retracts* kept with *and now says so every run*; `/race/[id]` pages entry's ID format sentence; a one-line note under the standing guard for SECTION 5. Numstat with every deletion quoted beside its replacement.

## STEP 4 — docs

Backlog: strike :79 and :80 with their readings; strike :29 at session open; if *apply*, strike :35; new line: *territorial carve is an inline literal at four `lib/queries.ts` sites; fold to `TERRITORIAL_STATES` on the next touch of each* (reads 4 today). Oddities: one entry — *the phantoms had two kinds and one predicate would have deleted a vacancy*, if that is what STEP 0 shows; skip if not. Roadmap `Also (HO 711)` block with the readings, the six ids, the nine dispositions, the audit's before/after, and the pointer.

## STEP 5 — review ref, FF

Push `HEAD:refs/heads/711-review`; `git ls-remote --heads origin`; Preview `narrow-preview` reading; paste; hold for the FF go.

## Paste-back

The STEP 0 table with the closure table for rows 4–5; per-commit `--stat`; the `raceIdFromMember` and ticker agreement table; gate outputs; the prod sequence with every read-back and the audit's 7 / 2 → 0 / 0; the falsification reading; captures; the SKILL and docs diffs with numstats; `git ls-remote --heads origin`.

read and follow 711
