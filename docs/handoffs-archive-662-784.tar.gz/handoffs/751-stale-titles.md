# HO 751: the stale titles. Resolve every stored incumbent's Ballotpedia title from the ballot and the redirect, store it where the crosswalk can't clobber it, and let identity tie the 42

`docs/backlog.md` OPEN LOOPS, *`member_ids.ballotpedia_title` is stale for 32 sitting members and missing for 9 printed on their own ballot, so their ballot rows carry no bioguide (HO 750, from the stale-title line)*, owner Code, medium, ruled the next HO. HO 750's incumbent rule reaches all 42 by underline and surname, so nothing is published wrongly; what stays is data. Its product effect is three moved incumbents: Casar (TX-35, printed in TX-37), Moore (UT-01, printed in UT-02) and Kennedy (UT-03, printed in UT-04) publish with no bioguide and no member link, and the on-another-ballot fact can't see them.

**This HO repairs data once, with every tie printed for a human to read before it's written.** No runtime heuristic is added: the reader keeps tying by identity only, and the harvest payload's `incumbentRoutes["underline-surname"]` stays the standing alarm for the next stale title.

## Ground truth (read at `d2a9929`; re-derive every `:N` by content)

- `member_ids.ballotpedia_title` (`scripts/migrate.ts:590`) is written by `scripts/sync-crosswalk.ts` from congress-legislators' `id.ballotpedia`, and its upsert overwrites the column on every run (`:94-103`, `ballotpedia_title = excluded.ballotpedia_title`). `sync:crosswalk` is manual (`package.json:27`; no cron). A repaired title written into that column lasts until someone runs it.
- The reader's identity map is `loadIdentity` (`lib/general-ballot.ts:523-526`): every non-empty `ballotpedia_title`, keyed by `titleKey` (`:118`), the same key a ballot row's href produces.
- The rule is `lib/ballot-incumbent.ts`: identity decisive; failing it, the one printed, underlined, bioguide-less row whose name ends in the stored surname. The harvest counts routes over every race (`incumbentRoutes`, `lib/harvest-challengers.ts:97`, `:242`). At the post-FF POST of HO 750 (#20597): identity 321, underline-surname 41, none 94.
- The 42 at HO 749 and 750: 32 stale titles (S-AK's senator, stored *Daniel S. Sullivan*, printed under `Daniel_S._Sullivan_(United_States_Senator_from_Alaska)`), 9 with no title (CA-14 and S-SC among them), and WA-09's *D. Adam Smith* (stored *Adam Smith*). 14 stored 2026 incumbents have no title at all: the 9, the three moved, and GA-13's Blair and TX-08's Luttrell, who are printed on no 2026 ballot and are outside the close.
- The tied row already holds the answer. For each of the 42, the row the underline-and-surname route picked has a `person_key`, which is the member's current Ballotpedia page key. For the three moved, the underlined, untied row in the district they moved to holds it. No fetch is needed to learn a key; the fetch is for confirming it.
- The CLI `npm run sync:general-ballot -- --race <id> --write` re-reads one race at the reader's pacing (`scripts/sync-general-ballot.ts:14-16`); rows are replaced whole, so a new identity map shows in `general_ballot.bioguide_id` on the next read of the race.

## STEP 0

1. HO number from the tree. This file assumes `main` at `d2a9929`, so this is 751. Otherwise stop.
2. Re-read the cited `:N` by content. Flag a drift.
3. Measure, prod, SELECTs only, and print as one table: every stored 2026 incumbent whose title is stale or missing, with the member, the stored title, the race they're printed in, the route that found them (or, for the three moved, the untied underlined row in the district they moved to), that row's `person_key`, and the key decoded to a title. Expect 42 plus 3. For the three moved, name the candidate member by surname among the state's sitting House members with no title, and require the match to be unique.
4. A dry `sync:crosswalk`-style read of upstream, no write: for the 45, does congress-legislators carry a different title today? Report per member. Upstream is a second source, not the store.
5. Proceed without a halt unless a key can't be decoded or the moved three don't match uniquely.

## The build

1. Three columns on `member_ids` (`scripts/migrate.ts`, the house pattern): `ballotpedia_title_resolved TEXT`, `ballotpedia_title_resolved_at TEXT`, `ballotpedia_title_resolved_from TEXT`. The crosswalk never writes them, and its upsert is left alone.
2. `loadIdentity` keys `COALESCE(ballotpedia_title_resolved, ballotpedia_title)`, so a resolved title wins and an unresolved member is unchanged.
3. `scripts/repair-ballotpedia-titles.ts`, `npm run repair:ballotpedia-titles`, dry by default and `--write` to write. For each of the 45 it builds the learned title from the tied row's key, then confirms it:
   - a stale title (34: the 32, WA-09 and any STEP 0 adds): one GET of the stale title's page at the reader's pacing and user agent, one attempt, following the redirect, and the landing page's key must equal the learned key. That is the redirect-resolution the ruling named, used as confirmation rather than as the source;
   - a missing title (the 9 and the three moved): the learned key's decoded title must carry the member's surname tokens and at least one first-name token, after `normName`;
   - every confirmation is printed as a row: member, stored title, learned title, the confirming signal, and the verdict. `--write` writes the three columns for confirmed members only, with `resolved_from` naming the signal (`redirect` or `ballot`). Unconfirmed members print with the reason and are written nowhere.
4. After the write, the affected races are re-read and the harvest is rerun once, so the repair reaches the pages the same day: `sync:general-ballot -- --race <id> --write` for every race in STEP 0's table (about 45 requests at 6s), then one authorized POST of `/api/cron/race-challengers`. These are prod writes through the two shipped paths; the FF go names them.

## Legs, on a `file:` copy seeded from prod (`member_ids`, `members`, `races`, `general_ballot`, `general_ballot_reads`, `race_candidates`, `primaries`, `primary_candidates`), the URL built as `file:${abs}` by construction, seen red first

1. Confirmation, both signals: on HO 747's saved pages, the learned key for S-AK's senator equals the redirect landing key (the fetch may be served by a shim that replays the recorded redirect, once the real one has been recorded in STEP 0's dry run); a control stale title (`Nobody Here (Nowhere)`) resolves to no page and is flagged, not written. For a missing title (CA-14), the token check passes; a control with the surname swapped fails.
2. The map prefers resolved: set one member's resolved title on the copy, rebuild the identity map, re-run `pageResult` on that race's saved page, and the row now carries the bioguide, with the harvest's route for that race moving from `underline-surname` to `identity`.
3. The crosswalk can't clobber: run the crosswalk's upsert on the copy with the old upstream title and the resolved columns are untouched.
4. The whole effect: with all confirmed titles resolved on the copy, re-run `pageResult` over the 45 races' saved pages and the harvest plan: `underline-surname` reads 0 over every race, and TX-37, UT-02 and UT-04 publish Casar, Moore and Kennedy with their bioguides. Red: the same plan on the unrepaired copy reads 41 and NULL for the three.
5. Dry means dry: the script's default run writes nothing (a content hash of `member_ids` before and after).

## Commits and docs

- `feat(HO 751)`: the columns, `loadIdentity`, the script and its npm line.
- `diag(HO 751)`: the legs driver.
- `docs(skill)`, its own commit, approval requested: `member_ids` gains the three columns and the rule that the crosswalk never writes them; the general-ballot entry's identity sentence names the `COALESCE`; the npm line for the repair; the harvest entry names `incumbentRoutes["underline-surname"]` as the standing alarm.
- `docs(HO 751)`: strike the stale-title line on leg 4, with the post-FF reading owed in the FF go; annotate *A race card names a stored incumbent who is not on that seat's 2026 ballot…* (HO 747): the on-another-ballot fact now sees the three; the roadmap block, pointer 750 → 751, carrying HO 750's post-FF reading (`docs/handoffs/750-artifacts/post-ff-reading.md`) as HO 749's block carried HO 748's. Reconcile OPEN LOOPS at open and close, control at 0.
- Review ref `751-review`. The FF is held for the SKILL approval and review.

## Gates

The cheap gates. No render code changes, so no captures; the pages that change (TX-37, UT-02, UT-04) change by data, and the FF go reads them.

## Paste back

- STEP 0's table and the upstream reading;
- the confirmation table from the dry run, every one of the 45 with its verdict;
- the five legs, red and green;
- the SKILL diff, for approval;
- `git show --stat` per commit, `--numstat` for the docs commits, the reconcile, the `751-review` SHA from `git ls-remote`, and a last cheap-gate run.
