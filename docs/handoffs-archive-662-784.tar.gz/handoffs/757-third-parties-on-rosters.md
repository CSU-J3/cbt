# HO 757: third parties and independents on race rosters, ruled C. Majors as today, then "also on the ballot", three shown before the fold

`docs/backlog.md` OPEN LOOPS, the third-parties line filed at HO 750, owner Corey. Ruled 2026-09-29 on `mock-third-parties.html`, verbatim: *"C"*, with the mock's default fold, three others shown before *"+N more on the ballot"*. HO 747's census priced it: 340 third-party and independent candidates in party-primary states (218 independents, 90 Libertarians, 32 Greens), 43 New York and Oregon fusion lines, median ballot 2, max 10, 82 write-ins never shown.

**Scope.** Party-primary races only. Top-two and top-four states already publish their whole field as `advanced` and render it as one list; curated races are untouched; write-ins and withdrawn-only rows are never published; the incumbent rule is unchanged. The race page's roster is the only surface that changes. Every other reader of `race_candidates` keeps seeing the field it sees today.

## Ground truth (read at `0ad8aea`; re-derive every `:N` by content)

- The harvest's ballot plan (`lib/harvest-challengers.ts`, HO 750) publishes `on_ballot = 1, write_in = 0` rows less the incumbent, restricted in party states to `party IN ('D','R')`, with statuses `won_primary`/`nominee`, under `harvest:general_ballot`. `general_ballot` carries `printed_party` whole (fusion lines included) and `party` as a letter.
- The status vocabulary: `won_primary`, `nominee`, `advanced` (nominated); `running`, `declared`; `withdrew`. Its readers: `components/RaceCandidates.tsx:14-33` (labels), `lib/queries.ts:1929-1932` and `:2001-2004` (ranking), `lib/race-matchup.ts:56` (`NOMINATED`), `lib/pac-target-status.ts:103-104`.
- `partyColor` lives in components (`BillExpandPanel.tsx:144`, `PatternDrilldownPanel.tsx:10`) and `RaceCandidates.tsx` uses one; `party` today is `D`, `R` or `I`.
- The roster: `RaceCandidates.tsx` renders one `<ul>`, party letter (`w-6`), name (a member link when `bioguide_id`), status label, `withdrew` dimmed; the header reads *Candidates (N)*.
- The mock, `docs/handoffs/mock-third-parties.html` once Corey drops it there: majors as today; then a second block *Also on the ballot*, letter · name · *On ballot*, three rows, then *+N more on the ballot*; fusion lines shown after the name as *· D / Working Families*; the header count is the whole ballot less write-ins and the incumbent.

## STEP 0

1. HO number from the tree: `main` at `0ad8aea`, pointer 756, so 757. Otherwise stop.
2. Re-read every cited `:N` by content. Flag a drift.
3. Measure, prod, SELECTs only: non-major `on_ballot = 1, write_in = 0` rows in party-primary races that are not the incumbent and not write-ins, by printed party; the three capture races (a median party race with one other, the race with the most others, a New York fusion race); every reader of `race_candidates.status` and `.party` (grep), each classified as roster or not.
4. Carry HO 756's post-FF POST and its two `:05` tick readings into this HO's roadmap block.
5. Proceed without a halt.

## The build

1. Status `on_ballot`, label *On ballot*: added to the vocabulary for a non-major candidate on a party-state general ballot. Not nominated: `NOMINATED`, `ROSTER_NOMINATED` and the ranking CASEs leave it out, so the matchup, the PAC-target rungs and every non-roster reader ignore it; the roster ranks it after the majors and before `withdrew`.
2. The harvest: in party-primary races the plan also publishes non-major on-ballot rows less the incumbent, status `on_ballot`, `party` from the printed party (Libertarian `L`, Green `G`, Independent, No party or Unaffiliated `I`, anything else `O`), name as printed. Fusion lines: a row whose `printed_party` carries more than one line keeps it whole in a new nullable `race_candidates.printed_party` column, for majors too.
3. `RaceCandidates.tsx`: majors as today; then, when any `on_ballot` rows exist, an *Also on the ballot* block of the first three by name, and a native `<details>` whose summary reads *+N more on the ballot* for the rest. Fusion lines render after the name as *· printed party*. The header count is the whole roster. `partyColor` gains `L`, `G` and `O` in the independent purple.
4. Nothing else renders `on_ballot` rows; STEP 0's reader list is the check.

## Legs, on a `file:` copy, each red first

1. The plan on the copy: the expected count of `on_ballot` rows from STEP 0, by printed party; none in top-two or top-four states, none curated, no write-ins, no withdrawn-only, the incumbent still excluded. Red: today's plan publishes none.
2. Readers: the matchup and the PAC-target rungs read the same on the copy before and after; the roster's ranking places `on_ballot` after the majors.
3. Fusion: a New York race's majors carry their printed lines.
4. Render: the three capture races from the review ref's Preview at 1440, 2560 and reduced motion, before and after; the `<details>` opens.

## Commits and docs

- `feat(HO 757)`: the vocabulary, the harvest plan, the column and migration, the readers' guards.
- `fix(HO 757)`: `RaceCandidates.tsx` and `partyColor`.
- `diag(HO 757)`: the legs driver.
- `docs(skill)`, its own commit, approval requested: the roster entry (scope by ruling, `on_ballot`, the fold, fusion lines), the status vocabulary, the party letters, `printed_party`.
- `docs(HO 757)`: strike the third-parties line with the ruling verbatim; the roadmap block, pointer 756 → 757, carrying HO 756's readings. Reconcile OPEN LOOPS at open and close, control at 0.
- Review ref `757-review`. Migrate before the review push (a page reads the new column; method.md § Environment). The FF is held for the SKILL approval, the captures and review.

## The prod reading (in the FF go)

After the FF: one authorized POST of `/api/cron/race-challengers`, its payload with the `on_ballot` count, and the three capture pages on Production.

## Paste back

- STEP 0's readings and the reader list;
- the four legs with the nine captures;
- the SKILL diff, for approval;
- `git show --stat` per commit, `--numstat` for the docs commits, the reconcile, the `757-review` SHA from `git ls-remote`, and a last cheap-gate run.
