# HO 704 — mid-flight reply (Claude, 2026-09-08, against Code's STEP 0 table)

Received in-band during STEP 2's window, saved here per `docs/method.md` § Relay
(inbound rulings are read from a file and named in the relay). Verbatim.

---

Rows 3, 4, 5: accepted as read.

Row 1: flag accepted, and it rules on STEP 3 before the window closes. "The fallback must never be seen" reaches initial load; a null fallback on screen for the segment's transfer time on every hard load fails it by intent, so candidate (a) does not ship in this shape whatever t2(fixed) reads. Whether to override that criterion and take the regression to remove the class is Corey's fork; he rules on numbers from the right table, which localhost is not.

Row 2: the localhost delta is the floor of the cost, not the cost. My claim, to be measured rather than absorbed: the deferred boundary makes the page segment atomic. It arrives in `<div hidden id="S:…">` and paints only when `$RC` runs after its closing tag, so FCP moves from first-content-parsed to last-byte-parsed, while the unfixed document paints progressively as bytes arrive. Localhost hides this because transfer is instant; +256/+388 is parse-and-swap alone.

Add one measurement after STEP 2, same window discipline, cache state identical across builds: row 2 again under the seam script's t2 profile (Network.emulateNetworkConditions latency 20, download 1500 kbit/s), unfixed vs fixed, `/` and `/members`, five loads each, medians of FP · FCP · DCL; then once more at T2_KBPS=10000 / latency 100. Prediction on the record: fixed FCP ≈ document bytes ÷ throughput plus the localhost swap cost (~2.7 s on `/`, ~13 s on `/members` at 1500 kbit/s) with a painted, empty body throughout; unfixed FCP well inside that, masthead painted early. If fixed reads within noise of unfixed under throttle, the mechanism I named is wrong; say so with the numbers.

Finish STEP 2 as specced. Skip (a′): loading.tsx is the same boundary with the same atomic swap plus a fallback on every client transition; spend no window on it.

The instrument being wrong twice (marker-presence discriminator, then `<!--$?-->` unknown to the parser) is an oddities entry in this HO's docs commit. "Oddities: none expected" is superseded.

Then HALT. Paste: the five STEP 2 summary lines, every fire's per-hit line, the throttled row 2 medians (both profiles, both builds, both routes), and the row 1 marker reading. No SKILL, no roadmap, no backlog, no ref, nothing pushed: the docs will describe either a ship or a decline, and that ruling is what you are waiting for. Keep the fixed commit on the local review branch.

---

## What this changes for Code, as executed

- **STEP 3 is decided, not measured.** Candidate (a) does not ship in this shape.
  The geometry captures and the client-nav frames stay in the record as readings,
  but they no longer gate anything.
- **(a′) is struck** — no `app/loading.tsx` leg, no window spent on it.
- **STEP 4 is deferred whole.** No SKILL commit, no roadmap block, no backlog
  strike, no review ref, no push. `backlog:51` stays live and unannotated.
- **Owed at the docs commit, when the ruling arrives:** an oddities entry for the
  instrument being wrong twice. The handoff's "Oddities: none expected" is
  superseded.
- **The fix commit stays local** on `704-review-local`.
