# HO 668 — excise the dead `.pdc*` block + the two adjacent scrubber orphans (backlog :424, SIZED at HO 603, never fixed), gated on byte-identical `/electoral`

**Read this file in full before executing anything. Execute in order. HALT conditions are hard stops — report and wait, do not improvise past them. Two HALTs: the STEP 0 closure table, and the pre-land review ref. Nothing lands on `main` before the second is approved.**

Base: `main` at `52145c1` or later. Clone fresh; verify HEAD before starting (concurrent-session rules per `docs/method.md` § Session start). Number derived per method: max(roadmap pointer 667, highest commit-subject HO 667) + 1. Environment: one CSS edit + `npm run build` then `npm run typecheck` (build first — HO 665 oddity), plus **two** local `npm run start` renders of `/electoral` (pre and post, for the gate; `.env` `TURSO_DATABASE_URL`/`TURSO_AUTH_TOKEN`). Either machine; no WSL/Docker. Bind check mandated on both starts (HO 664 → 665 procedure).

## Context (why now)

Backlog `:424` is a **HO 570 C1-class** entry: live CSS with no consumer, sized at HO 603 (106 lines / 16 selectors, plus two adjacent HO 333 orphans) and deliberately not folded into that HO. It has been named out-of-scope in HO 664, 665, 666 and 667 in turn. It is a pure CSS excision with a gate the entry already specifies — the byte-identical `/electoral` rendered-markup diff (the HO 603 gate shape). No shared component, no `lib/`, no SKILL claim outside a possible comment. This is the smallest HO in the queue and the cleanest to land while the isSettled cluster waits on the Aug 20 settle window.

**The entry's own warning is the reason it gets a STEP 0 at all:** during the HO 603 sizing, a quote-anchored grep produced a **false positive** — `.rdm-action--disabled` read dead but is LIVE at `RaceDistrictModal.tsx:272` as the second class in `className="rdm-action rdm-action--disabled"`. And `.rdm-*` has 26 selectors of which 24 are live, so a prefix sweep would delete the live race-district modal. **Per-selector, plain-substring, controls first — never prefix.** That trap re-runs here as a *demonstrated* control (STEP 0 item 3), not just a warning.

## Recon at `52145c1` (STEP 0 re-derives all of it)

- The block sits at **`app/globals.css:8075–8215`** (moved from the entry's `:7869–7974` by the HO 664/666 excisions above it — 141 lines now, because the entry's 106 counted `.pdc*` alone): the section-comment header `:8075` ("/primaries modal: scrubber + two-column card (HO 226)"), **`.prim-scrubber`** `:8076–8100`, **`.rdm-scrubrow`** `:8101–8104`, the descendant **`.rdm-scrubrow .prim-scrubber`** `:8105–8108`, the `PrimaryDistrictCard` comment `:8109`, and the **`.pdc*` family** `:8110–8215` (`.pdc` `.pdc-head` `.pdc-cols` + `[data-cols="1"]` `.pdc-col` `.pdc-col-head` `.pdc-col-body` `.pdc-barwrap` `.pdc-sched` `.pdc-roster` `.pdc-cand` `.pdc-cand-name` `.pdc-cand-party` `.pdc-cand-inc` `.pdc-col-spacer` `.pdc-col-footer` + `[data-state="runoff"]` + `[data-state="decided"]` `.pdc-empty`). The next live rule (`hearing row`, HO 264) starts at `:8216`. **Contiguous, nothing live interleaved** — re-verify by listing every selector between the two comment headers.
- Bare-substring TSX/TS counts at `52145c1` over `app/ components/ lib/`: `pdc` **0**, `prim-scrubber` **0**, `rdm-scrubrow` **0**. Their old components (`PrimaryDistrictCard`, `PrimaryScrubber`, `PrimaryDistrictModal`, `PrimariesMap`) are all absent from `components/` (603 / 333). Positive controls at `52145c1`: `rdm-action` tsx 4 / css 5, `rdm-title` tsx 1 / css 1, `races-panel-body` tsx 3 / css 1, `rdm-action--disabled` tsx **1** (`RaceDistrictModal.tsx:272`).
- **The entry's "NOT dead, do not touch" clause is itself moot** — it guarded `.dash-prim-grid` / `.dash-prim-card` as live in `DashboardPrimaries`, but **HO 657 retired the whole `.dash-prim-*` block** (`globals.css:4496` records it: "HO 657 RETIRED the .dash-prim-* block (18 selectors…"), and `components/DashboardPrimaries*` is absent. So there is nothing there to protect; the clause is a RECORD of a hazard that no longer exists. Say so in the close note (an entry premise verified stale rather than inherited).
- One code comment names a dead component in this family and stays as RECORD: `components/RaceDistrictModal.tsx:222` ("in PrimaryDistrictModal (different fill); not extracted here"). Not this HO's.
- SKILL: **no `.pdc` / `prim-scrubber` / `rdm-scrubrow` mention** at `52145c1` (`:1765` and `:1772` mention `/primaries` history only). Expected outcome: **no SKILL commit** — if a fresh grep agrees, STEP 5 is skipped and the roadmap block says so. Nothing here is a client island; no `:2087` append.
- `app/electoral/page.tsx` is `force-dynamic` — the gate must account for that (below).

## STEP 0 — enumerate; closure table; HALT

Line numbers are as of `52145c1` — re-derive (HO 652). **Controls first** (HO 664–667: nine instrument failures, zero code failures). Produce the closure table (candidate · verdict · evidence `file:line` · destination) covering at least:

1. **The block, selector by selector.** List every selector between the `:8075` header and the `:8216` header with its **bare-substring** TSX/TS count over `app/ components/ lib/` (`*.ts` `*.tsx`). Expected: every one reads 0. Any nonzero is a keep, and the table says which.
2. **Positive controls, run BEFORE the zeros are read:** `rdm-action` >0, `rdm-title` >0, and one live selector from the hearing-row block that follows (`:8216+`) >0. Paste the counts.
3. **The demonstrated false-positive control (the entry's warning, re-run):** show that a quote-anchored grep `"rdm-action--disabled"` reads **0** while the bare-substring grep reads **1** at `RaceDistrictModal.tsx:272`. This proves the instrument you're about to trust the zeros from is the bare-substring one, and that the anchored form lies. One line each in the table.
4. **Prefix-danger census, for the record:** `grep -c "^\.rdm-" app/globals.css` and the live count of those — expected 26 / 24 as the entry states, or the current numbers. Not acted on; recorded so the "never prefix" rule carries evidence.
5. **`.dash-prim-*` moot check:** `grep -rn "dash-prim" app components lib` = 0 and `globals.css:4496` names HO 657 — the entry's guard clause is stale; verdict RECORD in the close note.
6. **Comment edits the excision forces:** the two comment headers inside the block die with it (`:8075`, `:8109`); confirm nothing *outside* the block references the dying section by name (grep `HO 226` and `PrimaryDistrictCard` in `globals.css` and classify each hit — the ones outside the block are RECORD and stay).
7. **SKILL fresh grep** for `pdc`, `prim-scrubber`, `rdm-scrubrow`, `PrimaryDistrictCard`, `PrimaryScrubber` — expected only `/primaries` history at `:1765`/`:1772`, no live claim → **no STEP 5**. If a live claim appears, it's a table row and STEP 5 exists.
8. **e2e / scripts** grep for the same set — expected 0.
9. **Out of scope, named:** every other selector in `globals.css`; the `.rdm-*` family (all 26); the `RaceDistrictModal.tsx:222` comment; the bare-tape entry (`:422`, its own HO); the isSettled cluster; the HO 661 settle-window WATCHes; the HO 667 post-deploy sync WATCH (read it if a tick has landed, but it's not this HO's to close unless the observation is in hand — then it's a one-line docs rider, say so).

**HALT.** Paste the table. A nonzero on any block selector, a failed control, or a live SKILL claim changes the verdict and the table says so.

## STEP 1 — the pre-render (BEFORE the edit)

The gate needs a pre-change `/electoral` render from the same machine and DB. On the fresh clone at `52145c1`, **before touching CSS**:

1. `npm run build`; `npm run start -p 31xx`, PID captured, **bind verified**.
2. `curl -s -H "Cookie: ct_seen=1" http://localhost:<port>/electoral > /tmp/electoral-pre.html`; note the byte count and the HTTP code (200).
3. Kill by PID, port-scoped.

Keep `/tmp/electoral-pre.html`. (If a build was already done for STEP 0, reuse it — the point is that the pre-render is from an unmodified tree.)

## STEP 2 — the chore commit (after the table is approved)

`git checkout -b 668-review-local` first. One commit, one kind:

`chore(HO 668): excise the dead .pdc* block and the two adjacent scrubber orphans`

Expected shape: `app/globals.css` −141 (or the re-derived count), the two internal comment headers gone with the rules, nothing else. If the section header at `:8075` is shared with anything live, edit rather than delete — but at `52145c1` it heads only the dying block.

## STEP 3 — gates

- `npm run build` then `npm run typecheck`, both green.
- **Source greps** (bare-substring, controls first): the controls from STEP 0 item 2 still >0; every excised selector 0 in TSX (unchanged from STEP 0 — this proves the excision touched nothing rendered).
- **Built-CSS check** (`.next/static/css/*.css` post-build): every excised selector reads **0**; controls `rdm-action` >0, `rdm-action--disabled` >0 (the trap selector, live in the served bundle), and the hearing-row control >0.
- **The byte-identical `/electoral` gate:**
  1. `npm run start -p 31xx` on the post-chore build, PID captured, **bind verified**.
  2. `curl -s -H "Cookie: ct_seen=1" http://localhost:<port>/electoral > /tmp/electoral-post.html`; 200.
  3. Normalize both files identically: strip `<script …>…</script>` blocks and the hashed stylesheet `<link … href="/_next/static/css/…css">` tags (the HO 603 shape). Then `cmp /tmp/electoral-pre.norm.html /tmp/electoral-post.norm.html`.
  4. **Identical → gate green**, paste the byte counts and the `cmp` result.
  5. **Not identical → do NOT reinterpret.** `diff` the normalized files and classify every hunk: **(a)** a data delta from `force-dynamic` (a count, a clock, a "days until", a Kalshi price that moved between the two renders — name the field) is acceptable **only if the surrounding markup is byte-identical**; **(b)** any markup delta (a class attribute, an element, an order) is a **HALT** — CSS excision cannot change markup, so a markup delta means the pre-render or the tree isn't what you think. If (a) hunks exist, re-run the pair back-to-back once (pre-server on a stash of the tree, or accept the named field) and report both readings; the gate closes on "byte-identical modulo N named dynamic fields", stated as such.
  6. Kill by PID, port-scoped.

## STEP 4 — docs commit (`docs: HO 668 — …`)

4.1 **`docs/backlog.md`** — strike `:424` with the close note: excised at <chore SHA> (`globals.css` −N lines: `.pdc*` 16 selectors + `.prim-scrubber` + `.rdm-scrubrow` + its descendant, the two internal comment headers), the per-selector census with its controls (name the counts), **the demonstrated false-positive control** (anchored 0 vs bare 1 on `rdm-action--disabled`), the prefix-danger census (26 / 24 or current), **the entry's `.dash-prim-*` guard clause found moot** (retired at HO 657 — a stale premise verified rather than inherited), the built-CSS readings, and the `/electoral` gate result stated exactly (byte-identical, or byte-identical modulo the named dynamic fields). SKILL: state that no SKILL edit was needed and why (no live claim named the block). Strike = `~~…~~` + close note; do not delete the line.

4.2 **`docs/roadmap.md`** — one `Also (HO 668)` block, append-only, pointer 668: the smallest HO of the run and why it still got a STEP 0 (the entry's own trap, re-run as a control), the numbers, the moot guard clause, the gate design and result, no SKILL commit and no oddities entry (or the entry if one earned it). If the HO 667 sync WATCH tick has landed and you read it, one clause here and a docs rider on the WATCH entry — otherwise leave it.

4.3 **`docs/oddities.md`** — only if something odd emerged.

## STEP 5 — SKILL commit — expected NOT to exist

Only if STEP 0 item 7 found a live claim. Otherwise skip, and the roadmap block says "no SKILL commit — no live claim named the block."

## HALT — the review ref; nothing lands before approval

Push `git push origin HEAD:refs/heads/668-review`. Paste back: the executed table deltas, `git show --stat` of the two (or three) commits, STEP 3 outputs **including both bind checks, the built-CSS counts, and the `cmp`/`diff` result with byte counts**, the backlog numstat with every deletion explained (one in-place strike expected; `grep -c '^-[^-]'` is not a deletion count — HO 643), and the docs diff. `git ls-remote` for remote claims. One swallow → gitignored file. If a SKILL commit exists it needs its own explicit approval. After approval: `git push origin HEAD:main` (no force), delete the ref, `git ls-remote --heads origin`.

## Verification gates (in the paste)

- STEP 3 green; tree clean after the commits.
- Backlog numstat explained; the struck line survives inside `~~…~~`.
- Anchored greps: `grep -cE '^\*\*Also \(HO 668' docs/roadmap.md` = 1; `grep -c "\.pdc\|prim-scrubber\|rdm-scrubrow" app/globals.css` = 0; `grep -c "rdm-action--disabled" app/globals.css` >0 (the trap selector survives); `grep -n "DEAD CSS left by the HO 603 sweep" docs/backlog.md` shows the line struck, not gone.
- Push only after re-checking HEAD ancestry.

## Out of scope — named so it isn't absorbed

- **Every `.rdm-*` selector** — 26 of them, 24 live, the entry's own trap. Only `.rdm-scrubrow` (and its descendant rule) goes, by name.
- The bare `<MarketsTape />` branch (`:422`) — shared live component, its own roster gate, its own HO.
- The isSettled cluster (`:78`/`:85`/`:87` — Aug 20 / Sep 3 first), the M3 re-arm, the `CRON_ROUTES` string, the news-cron and masthead-readout comment-only entries filed at 667.
- `RaceDistrictModal.tsx:222` and all `docs/` prose.
- The method.md dual-write rule — still unruled, still not written here.
