# HO 673 — the sponsor portrait always on in `BillExpandPanel`, the hover card retired, and the ruled cosponsor + related-bills ingestion filed as one data domain

**Read this file in full before executing anything. Execute in order. HALT conditions are hard stops — report and wait, do not improvise past them. Three HALTs: the STEP 0 closure table, an empty pre-render inside STEP 1, and the pre-land review ref. Nothing lands on `main` before the third is approved.**

Base: `main` at **`dc10f72`** or later. Clone fresh; verify HEAD via `git ls-remote --heads origin` before starting (`docs/method.md` § Session start).

**This handoff was first authored as 671 against `4ae76a8` and was wrong.** A parallel track had already landed HO 670 (`4d34e5c`, `/welcome` rebuilt as the board) and HO 671 (`dc10f72`, the `bills` flush made conditional on a write), and **HO 672 is in flight right now** (prod measurement of that guard, the `tsconfig` `include` exposure, the `method.md` gate entry — STEP 1 and STEP 2 both already ruled). The method derivation of max(roadmap pointer 671, highest commit-subject 671) + 1 yields **672, which is taken**, so this is **673**. If 672 has landed by the time you start, re-derive and say so; the number still holds.

**Every line reference below was re-derived at `dc10f72`, not inherited.** HO 670 touched only `app/welcome/*`, `components/LandingCTAs.tsx` and the new `components/WelcomeClock.tsx`; HO 671 touched one cron route. Neither went near this HO's files, so the recon survived the renumber intact — but re-derive anyway at your HEAD (HO 652).

Environment: code edit + `npm run build` then `npm run typecheck` (build first — the HO 665 stale-`.next/types` oddity), plus **two** local `npm run start` renders of `/` (pre and post), the HO 627 click gate, the layout audit on `--route home`, and **the visual capture gate below**. Either machine; no WSL/Docker. **Bind check mandated on both starts** (HO 664 → 665 procedure).

## The visual capture gate — mandatory, and it is new

HO 670 shipped **three render defects that passed every green gate**: a ~300px dead zone under each panel, an empty ODDS third, and the reduced-motion mask erasing the first row. Greps and 200s cannot see a layout. HO 672 is writing this into `docs/method.md` as a standing entry; this HO does not wait for it.

**A visual check with no capture is not a check.** Every render-touching step here requires screenshots at a named viewport set — **1440 and 2560 minimum** — plus a **separate `prefers-reduced-motion: reduce` capture**, which is a different layout and not merely a dimmer one. The captures are retained and referenced in the paste. "I looked at it" is not a reading.

Two instrument rules from HO 671, same origin: **never `tail` a command whose failure mode is a stack trace** (the informative line is the first one), and **a write instrument that does not read back is not an instrument.**

## The ruling this HO executes, and the half it deliberately does not

Corey ruled in chat on **2026-08-17/18**, against `docs/design/mock-673-sponsor-cosponsor.html` (delivered separately — see STEP 0 item 0):

1. **The sponsor's photo shows on the panel rather than on hover.** It already exists and is already fetched; it is gated behind `.bxp-sponsor:hover .v2f-sc-card` and therefore never visible on a glance.
2. **Cosponsors are listed as faces, party-split, six total**, with unused party shares redistributed, the total always printed above the groups, each group header carrying its own count, and **names revealed on hover**.
3. **The sponsor's portrait is the largest** (80×94, the size the hover card already uses); cosponsor faces 32×38.
4. **The stage bar is unchanged.** Confirmed explicitly after the mock omitted it: `BillStageBar` renders above `.bxp-body` and every edit here is inside `.bxp-metabox`, the right column of that grid.
5. **Related bills are wanted on the panel too** — also not built here, and filed *with* the cosponsor roster in one entry, deliberately (STEP 4.1).

**Only ruling 1 ships. Ruling 2 must not be part-built.** The cosponsor roster **does not exist in the database**. `bills.cosponsor_count` is an INTEGER column (`scripts/migrate.ts:1389`) populated from `json_extract(raw_json, '$.cosponsors.count')`; `lib/sync.ts:41` types the API's `cosponsors` as `{ count?: number }` because the bill detail endpoint returns a count and a URL and never a list; there is no `bill_cosponsors` table among the ~50 in `migrate.ts`. A party split additionally needs a **party per cosponsor**, which resolves through the existing `members` join at no new column but has no rows to resolve.

There is nothing to render, and **rendering placeholders would be inventing data on a surface whose job is to report it.** Shipping the roster's CSS ahead of its consumer is worse: live selectors with no renderer is exactly the `.pdc*` class HO 668 spent a handoff excising, and HO 664 established that a comment is not a caller. **No `.bxp-cos*` selector, no roster markup, no stub faces.**

## Context (why the sponsor half is worth its own commit)

The photo is threaded onto `FeedBill` as `sponsor_depiction_url` (HO 192, widened by HO 300's `SPONSOR_ENRICH_SELECT`) and rendered by `SponsorPhoto` at 80×94 inside `.v2f-sc-card`, which is `display:none` until hover. Every byte already crosses the wire on every dashboard feed row; the only thing missing is that anyone can see it. This HO spends no new read and adds no new query.

It also **retires the hover card rather than keeping it**, and that is the load-bearing call. Once the portrait, the name, the party bracket and the state/chamber line are all on screen, `.v2f-sc-card` holds **no field that is not already visible** — a hover that reveals what is already rendered. Keeping it leaves a second copy of four values that can drift from the first.

## Recon at `dc10f72` (STEP 0 re-derives all of it)

- **`components/BillExpandPanel.tsx`** — `partyColor` `:136`, `initials` `:143`, `SponsorPhoto` `:152–178`, `SponsorMeta` `:183–243`. The metabox's SPONSOR row is `:515–522`; the COSPONSORS row is `:524–551` and is **untouched** (including `cosponsorSegments` `:408` and the HO 371 `/stale` momentum arm).
- **`SponsorMeta`'s shape today:** `.bxp-sponsor` wraps the name anchor (`.bxp-sponsor-name`, `href=/members/{bioguideId}`, `stopPropagation` on click), the `.bxp-sponsor-bracket`, then `.v2f-sc-card` carrying `SponsorPhoto` + `.v2f-sc-info` (`-name`, `-party`, `-meta`). `cardMeta` (`:199–204`) computes `"{State} · {Senate|House}"` — **it survives as the always-on meta line**, so nothing computed here is lost.
- **`.v2f-sc-*` has exactly ONE consumer and it is this file.** Bare-substring `v2f-sc-` over `app/ components/` returns seven TSX hits, all in `BillExpandPanel.tsx` (`:164`, `:172`, `:224`, `:230`, `:231`, `:233`, `:237`). **`components/SponsorHoverName.tsx` is a different component using a different family** (`.sponsor-hover*`) and is **out of scope entirely** — it renders on `/bills`' `BillRow`, has never rendered in the dashboard feed column (the HO 610 correction), and the HO 507 shared-component rule keeps it out. Verify the split before believing it; the two families are one word apart, which is the HO 666 name-collision hazard.
- **CSS in play.** `app/globals.css:4092–4144` — `.v2f-sc-card`, `-photo`, `-photo--fb`, `-info`, `-name`, `-party`, `-meta`. `:4411–4430` — `.bxp-sponsor`, `-name`, `-name:hover`, `-bracket`, and the reveal pair `.bxp-sponsor:hover .v2f-sc-card` / `:focus-within`. **Two comment sites become LIVE-CLAIMs at the edit:** `:4148–4150` and `:4410`, both asserting the card is live and naming the reveal rule. A third, `:4493`, is the HO 610 overflow reasoning — classify it; if the card goes, that paragraph describes a hazard that no longer exists and is a RECORD, not a deletion.
- **Where the photo column reaches, and the sharpest expected finding.** `SPONSOR_ENRICH_SELECT` (`lib/queries.ts:89–95`) is interpolated at exactly **three** sites — `:707` (`getNewBillsThisWeek`), `:6255` (`getCandidateBills`), `:6897` (`getStageChanges`) — and `getCandidateBills` carries its own inline copy at `:6067`/`:6176`. HO 300's header claims the enrichment went to `getStageChanges` / `getStaleBills` / `getNewBillsThisWeek`. **Confirm `getStaleBills` against the tree rather than the comment.** If it lacks the column, TOP STALLS rows render the **initials tile**, not a photo — a correct degrade, not a bug, but a visible per-tab difference that must be named in the close note. `rowToFeedBill` `:7322–7325` is undefined-safe, so the degrade is already built.
- **The always-on portrait is NOT a link, and that is an architectural call taken without asking** (method.md § Roles). The name beside it already navigates to `/members/{bioguideId}`; giving the portrait its own `href` puts **two click targets on one destination inside a row whose whole surface expands**, the HO 627 defect in miniature. The portrait keeps `alt=""` and stays out of the accessible name, exactly as inside the card today. **The click gate's target census is therefore unchanged** — a prediction the gate tests, not an assumption it inherits.
- **`SponsorPhoto` is reused, not rewritten.** Its `useState` error fallback, `loading="lazy"` and initials tile are the shipped degrade path and stay. Only its class names and mount point move.
- **Height is the real risk and it is not a design question.** The SPONSOR `.bxp-mrow` goes from one line of text to a ~94px portrait, so the metabox grows by roughly that on every open panel. Under `@container bxp (max-width:520px)` (`globals.css:4216`) the metabox stacks *below* the summary, so the whole panel gets taller under a feed row. Measure it; report the number; do not tune it away.
- **Two prior SKILL rulings bear on STEP 4.1 and must be cited there rather than re-derived.** `.claude/skills/cbt/SKILL.md:1978` — "Similar/related bills stay **dropped** (only regex `cluster_id`, not real topical similarity)". And `:1982` — "Cosponsor party split deliberately not surfaced … **Cosponsor-list ingestion is a future handoff**" (HO 148 Phase 1). Both sit inside the `BillExpandedPanel` block HO 666 deleted, so **classify each as RECORD-about-a-dead-component or as a live product ruling the current panel still honours** — the live panel has neither block, so the substance survives its component. Neither is edited here.
- **Instruments that must run:** `scripts/diagnostic/feed-click-gate-627.ts` (WIDTHS 1440 / 2560, `:31–34`) and the layout audit on `--route home` at 2560. **Instruments that must NOT run:** `/api/sync` locally, ever.

## STEP 0 — enumerate; closure table; HALT

Re-derive every line number at your HEAD. **Controls first, before any zero is trusted** (HO 664–669: thirteen instrument failures against zero code failures, then three HO 670 render defects that passed every green gate). Bare-substring form. Table = candidate · verdict · evidence `file:line` · destination. Cover at least:

0. **BOTH mocks' arrival, verified before either is trusted.** Delivered out of band and saved into the tree by Corey. Confirm each before reading a pixel off it — a mismatch or an absence on either is a HALT, not a shrug:
   - `docs/design/mock-673-sponsor-cosponsor.html` — md5 **`6a8a20112cff924ff564b0b714d300c6`**, 24352 bytes.
   - `docs/design/mock-673-related-bills.html` — md5 **`3a1ea93ea37f4e1e7e02d1cbad112629`**, 22990 bytes.
1. **`.v2f-sc-*` sole-consumer proof.** Positive control first: `sponsor-hover-avatar` must read >0 in `components/SponsorHoverName.tsx` on the same invocation. Then bare-substring `v2f-sc-` across `app/ components/ lib/ scripts/ e2e/`: expected 7 TSX hits, all in `BillExpandPanel.tsx`, plus the CSS block. **Any hit outside that file changes the verdict from excision to keep.**
2. **Per-selector CSS census, bare-substring, controls first.** Each of `.v2f-sc-card`, `-photo`, `-photo--fb`, `-info`, `-name`, `-party`, `-meta` and each of `.bxp-sponsor`, `-name`, `-bracket`: consumer count now and after. Positive controls that must read >0 first: `bxp-mrow`, `bxp-mlabel`. **`-photo--fb` is a modifier on `-photo`** — a bare-substring count of `v2f-sc-photo` includes it, so enumerate separately or the count lies.
3. **The new selectors, named before they are written.** Recommended: reuse the `.bxp-sponsor` family — `.bxp-sponsor` becomes the flex container (it is `position:relative` today only to anchor the absolute card), plus `.bxp-sponsor-photo`, `.bxp-sponsor-info`, `.bxp-sponsor-meta`. Confirm no existing selector carries those names and that the bare-substring `bxp-sponsor` grep still discriminates after the additions.
4. **`getStaleBills` and the photo column.** Every query interpolating `SPONSOR_ENRICH_SELECT` or an inline equivalent, `file:line`, and per dashboard tab (MOVERS / TOP STALLS / NEW THIS WEEK) whether a photo or an initials tile renders. **Do not fix a gap found here** — widening a query is not this commit's kind.
5. **Comment reconciles.** `globals.css:4148–4150` EDIT (LIVE-CLAIM). `:4410` EDIT. `:4493` classify with the reason. `BillExpandPanel.tsx:133` section header EDIT. Anything a fresh grep adds.
6. **Click-target census, as a prediction.** Every `<a>` inside the panel today, and the statement that the count is **unchanged** after. Written down *before* the gate runs, or the gate proves nothing.
7. **SKILL fresh greps** — `v2f-sc`, `bxp-sponsor`, `hover card`, `SponsorPhoto`, `SponsorMeta`, `sponsor photo`. Classify LIVE-CLAIM vs RECORD/HISTORY. **The `:2085` changelog append is expected YES** — `BillExpandPanel` is `"use client"` (`:1`) and this changes what the island renders, the inverse of HO 665/669 and the same call as HO 666. State the criterion as applied. Note `:2085` is where HO 670 recorded `WelcomeClock`; the append goes at the same site.
8. **The two prior rulings, located and classified but NOT edited** — `related bills`, `cluster_id`, `Cosponsor-list ingestion`, `cosponsor party split`. Report each hit's line and classification. They feed STEP 4.1's citations.
9. **Out of scope, named so it isn't absorbed:** `components/SponsorHoverName.tsx` and every `.sponsor-hover*` selector; the COSPONSORS `.bxp-mrow` and `cosponsorSegments`; `BillStageBar`; `lib/queries.ts` in every respect; `app/members/*`; `/bills` beyond what the shared panel gives it free; **and everything HO 672 is holding — `tsconfig.json`, `docs/method.md`, `app/api/cron/summarize/route.ts`.**

**HALT.** Paste the table back. Any reading other than expected changes that row's verdict. Do not force it.

## STEP 1 — the pre-render and pre-capture (BEFORE the edit)

1. `npm run build`; `npm run start -p 31xx`, PID captured; **verify the started PID owns the port** (`lsof -i :<port>` or `ss -ltnp`) before any curl is trusted.
2. `curl -s -H "Cookie: ct_seen=1" http://localhost:<port>/ > /tmp/sp-pre.html`; record HTTP code, byte count, and **the served stylesheet hash** from the `<link … href="/_next/static/css/…css">` tag — the STEP 3 freshness discriminator (HO 668: a failed kill let the pre-change server answer and nearly produced a pass measured against itself).
3. Discriminating counts: `grep -c 'v2f-sc-card' /tmp/sp-pre.html` (expected >0 — the cards render hidden, they are in the HTML) and `grep -c 'v2f-sc-photo'`. **HALT if either reads 0** — no panel rendered, and two absent things compare equal.
4. **Baseline captures** with a panel open: 1440, 2560, and 2560 under `prefers-reduced-motion: reduce`. Retained.
5. Click gate against this server; record the pass line. Layout audit `--route home` at 2560; record M1 / M1x / M2 / M3 / M4-true verbatim as the baseline — **do not inherit a prior figure**, and note that the layout audit's M3 is a different instrument from the race-detector M3 named in recent roadmap blocks.
6. Kill by PID, port-scoped.

## STEP 2 — the chore commit (after the table is approved)

`git checkout -b 673-review-local` first (`main` stays at `origin/main` until approval). One commit, one kind:

`chore(HO 673): the sponsor portrait renders on the panel, not on hover`

Expected shape: `components/BillExpandPanel.tsx` — `SponsorMeta` rewritten so the row is portrait-left / name-bracket-meta-right, `SponsorPhoto` reused with new class names, the `.v2f-sc-card` subtree gone, the `:133` header rewritten to record the retirement. `app/globals.css` — the `.v2f-sc-*` block excised, the two reveal rules gone, the new `.bxp-sponsor-*` rules added, comment sites reconciled. **Two files.** No query change, no COSPONSORS edit, no roster CSS.

Sizes come from the mock and are not re-tuned by eye: portrait **80×94**, `border-radius: 3px`, `object-fit: cover`; container `display:flex; gap:11px; align-items:flex-start`; info column `gap:3px`; meta line at `--fs-10` in `--text-dim`. The party bracket keeps its existing token treatment (HO 610 — the bracket carries party and nothing else; this HO introduces no second party-coloured element).

## STEP 3 — gates

- `npm run build` then `npm run typecheck`, both green, build first; report both readings if typecheck ran early and went red.
- **Source greps, controls first:** `v2f-sc-` 0 across `app/ components/ lib/ scripts/ e2e/` (RECORD comments reported as "0 live, N RECORD" — never gutted to satisfy a substring count); controls `sponsor-hover-avatar` >0, `bxp-mrow` >0.
- **Built-CSS check:** `v2f-sc-card` 0 in `.next/static/css/*.css`; controls `bxp-mrow` and `bxp-sponsor` >0. Read the CSS, not the HTML (HO 212).
- **Render gate with a real discriminator:** start (bind verified), confirm the served stylesheet hash **differs** from STEP 1's — a match means measuring the old server against itself, HALT. Then `curl` to `/tmp/sp-post.html`, 200; `grep -c 'v2f-sc-card'` = **0**; `grep -c 'bxp-sponsor-photo'` **>0**, stated against the number of open panels. Assert an `<img>` with a `congress.gov` `src` inside a `.bxp-sponsor` — **a class-name check would pass on a build that renders the initials tile for everyone.**
- **Visual captures, same three states as STEP 1**, with a panel open, retained and referenced in the paste. This is the gate HO 670 did not have.
- **Click gate re-run whole** at both widths from a genuinely scrolled feed. Expected: the same pass count as STEP 1, **because the portrait is not a target**. A changed count is a HALT.
- **Layout audit** `--route home` at 2560, falsification PASS required, reported against STEP 1's own baseline. **An 80px image beside a text column is exactly the shape M1 scores**, so a nonzero M1a/M1b is a real finding to diagnose, not absorb.
- **Panel height at both container states:** metabox `getBoundingClientRect().height` before and after, at 2560 (wide) and 1440 (stacked under `@container bxp (max-width:520px)`). Four numbers. A recorded cost, not a gate.
- Kill by PID, port-scoped.

## STEP 4 — docs commit (`docs: HO 673 — …`)

4.1 **`docs/backlog.md`** —

- **New QUEUED entry — the per-bill sub-resource ingestion: cosponsor roster AND related bills, filed as ONE entry.** One entry on purpose, and the reason is its most important line: **the expensive half is the loop over the corpus, not either endpoint.** Both are per-bill sub-resources under the same base, both need the same backfill-scope ruling, the same refresh cadence and the same rate budget, and a single pass can fetch both while it has the bill in hand. Two HOs would double the API budget and the backfill wall-clock for nothing. Whoever picks it up may still *ship* two commits; they must not *sweep* twice.

  **Cosponsors — the ruled design, in full.** Corey ruled 2026-08-17: format C, **six faces total** split across the parties present with unused shares redistributed (so the block is always exactly `min(6, cosponsors)` faces and the panel height is stable), total printed above the groups, each group header carrying its own count, `+N` per group, faces 32×38, **names on hover**, empty groups dropped entirely per C4. Blocker as measured: only `bills.cosponsor_count` exists (`migrate.ts:1389`, from `$.cosponsors.count`); the detail endpoint returns a count and a URL; no `bill_cosponsors` table. Needs: the table, a sync path against `/bill/{congress}/{type}/{number}/cosponsors`, a withdrawn-cosponsor flag or the roster will not reconcile against the stored count, and **a ruled destination for a bioguide that does not resolve to a `members` row** — it has no party group to sit in while the header count still includes it. Left unruled: order within a group (default proposed: cosponsorship date, earliest first) and whether the party-coloured face edge earns an exception to the HO 610 token rule. Cite `docs/design/mock-673-sponsor-cosponsor.html` as the ruling's record, and **cite SKILL `:1982`'s own "Cosponsor-list ingestion is a future handoff"** — this filing continues that, it does not discover it.

  **Related bills — the ruled design, in full.** Corey ruled **R2** on 2026-08-18 against `docs/design/mock-673-related-bills.html`, which is committed at STEP 4.2 as its record. The identical or companion bill is **promoted out of the list** into its own bordered line above it, labelled by chamber and relationship (`Senate companion · identical`) and carrying **that bill's own introduced date and stage** — the one related bill whose status is worth knowing without a second click. The remainder falls under an `Also related · N` label as a flat list, each row `[id] [title] [relationship]`, capped with `+N more`. R1, one flat list with no promotion, was the alternative and was **not** taken; the reason is that "does this House bill have a Senate twin" is the question the corpus cannot answer today and everything else in the list is context for it. **Conditional per C4:** no companion → no bordered block and no `Also related` label, just the list; no relations at all → the same `NO RELATED BILLS` empty state its three neighbours use. Nothing is reserved to report an absence. **Left unruled deliberately, and the ingestion HO must not pick them itself:** the cap on the `Also related` list (drawn at 3 + `+N`, not measured) and the ordering within it — both want the real distribution of `$.relatedBills.count` across the corpus first, which is the probe below. **And the cheap half worth probing first:** `lib/sync.ts:254` stores the whole detail object as `raw_json` (`JSON.stringify(detail)`), and the Congress.gov bill detail is expected to carry `relatedBills` as a `{count, url}` pair beside the `cosponsors` one the sync already reads. **Probe it (`json_extract(raw_json, '$.relatedBills.count')` over the live corpus) before planning around it** — if it is there, the count is one SQL `UPDATE` and zero API calls, the `scripts/backfill-cosponsors.ts` move exactly. The *list* is the same blocker and rides the same sweep. **What makes it worth building is the relationship TYPE**, not a similarity score: Congress.gov types each edge (identical bill, companion measure, procedurally-related) and records who identified it, answering "does this House bill have a Senate twin" — a question the corpus cannot answer today. **The prior ruling is answered, not overridden:** SKILL `:1978` dropped related bills because CBT had only regex `cluster_id` and not real topical similarity, correct on its premise and not reaching this — `cluster_id` is a filler classifier (CRA disapproval, facility naming, awareness designation) and **is not to be reached for here**; the upstream relation is curated data that ruling never had. **Dedup is a named requirement, not polish:** `BillExpandPanel.tsx:335` already filters the markup agenda against the current bill inside the HEARING block, so a RELATED BILLS block repeating those rows double-reports one bill in one panel. Placement follows the existing `.bxp-relblock` pattern in the left column (HEARING / RELATED NEWS / ODDS), always-on with an empty state.

- **A second QUEUED entry only if STEP 0 item 4 found it:** `getStaleBills` missing the sponsor enrichment, with the per-tab consequence named.
- Strike = `~~…~~` + a one-line close note. **Do not delete any struck text.**

4.2 **Both mocks committed here as the rulings' records**, unedited, at the md5s verified in item 0: `docs/design/mock-673-sponsor-cosponsor.html` (the panel, sponsor portrait and the party-split cosponsor block) and `docs/design/mock-673-related-bills.html` (R2, with the no-companion, empty and double-reported states). Each carries a stand-in disclosure in its own header prose; leave it. **Two files, because two designs were ruled** — the entry cites one per half, and a single merged mock would leave the ingestion HO unable to point at either cleanly.

4.3 **`docs/roadmap.md`** — one `Also (HO 673)` block, append-only, pointer advanced to 673: the ruling and who made it; what shipped and what deliberately did not, with the reason stated as the `.pdc*` precedent rather than as caution; the hover card's retirement argued on field duplication; the not-a-link call and the unchanged click-target census; the `getStaleBills` reading and its per-tab consequence; the four height numbers; the audit reading against its own baseline; the `:2085` append with its criterion; **the single-entry filing of both sub-resources with the shared-sweep argument as the reason**, including that SKILL `:1978`'s related-bills drop was answered on its premise rather than overridden; and **the renumber from 671 with its cause** — a stale clone, a parallel track already three HOs ahead, and project knowledge that carried the truth from the first message. That last part is the one a future session most needs.

4.4 **`docs/oddities.md`** — only if something odd emerged. Nothing odd → no entry, and say so in the roadmap block (HO 659/660 form).

## STEP 5 — SKILL commit (`docs(skill): HO 673 — …`), self-mod guarded

Its own commit, never riding another doc. **Minimal edits** per the approved table: every LIVE-CLAIM describing the sponsor card as a hover affordance, plus the **`:2085` client-island changelog append** — `BillExpandPanel` is a client island and what it renders changed, the HO 666 criterion, not the HO 665/669 one. Cite the pair so the ruling reads as applied rather than habitual. Nothing else.

## HALT — the review ref; nothing lands before approval

`git push origin HEAD:refs/heads/673-review` (amend via `--force-with-lease` on the ref only; `main` only ever fast-forwards). Paste back: executed table deltas, `git show --stat` of all three commits, STEP 3 outputs **including both bind checks, the stylesheet-hash discriminator, both click-gate pass lines, the audit line against its own baseline, the four height numbers and the visual captures**, the backlog numstat with every deletion explained, and the docs + SKILL diffs.

**Deliver the SKILL diff as a gitignored file AND tell Corey explicitly that he must attach it to the chat** — it has now sat unread on the Windows box for two consecutive HOs, three rounds each. Writing the file is not delivering it.

Remote claims via `git ls-remote`, never `rev-parse origin/*`. One swallowed block → re-deliver as a gitignored file, never a second paste. **The SKILL diff needs explicit approval** — the self-mod guard is satisfied by reading, not by summarising. After approval: fast-forward `main` (`git push origin HEAD:main`, no `--force`), delete the ref, verify with `git ls-remote --heads origin`.

## Verification gates (run before the HALT; outputs in the paste)

- STEP 3 all green; working tree clean after the three commits.
- **Backlog numstat:** `git diff --numstat <docs-commit>~1 <docs-commit> -- docs/backlog.md` — insertions only expected; a deletion is a finding explained line by line. `grep -c '^-[^-]'` is NOT a deletion count (HO 643).
- **Anchored greps** (HO 637): `grep -cE '^\*\*Also \(HO 673' docs/roadmap.md` = 1; `grep -rn "v2f-sc-" app components lib scripts e2e` = 0 live; `md5sum docs/design/mock-673-*.html` matches **both** figures in item 0.
- Push only after re-checking HEAD ancestry (`git ls-remote --heads origin`).

## Out of scope — named so it isn't absorbed

- **`components/SponsorHoverName.tsx` and every `.sponsor-hover*` selector** — a different component, different family, different surface. One word apart from this HO's target.
- **The COSPONSORS `.bxp-mrow`, `cosponsorSegments` and the HO 371 `/stale` momentum arm.** The roster is filed, not built.
- **Related bills in every form** — no `relatedBills` probe, no block, no `.bxp-relblock` addition, no `cluster_id` anything. Filed in STEP 4.1, built nowhere. The `raw_json` probe named there belongs to the ingestion HO.
- **`BillStageBar` and everything above `.bxp-body`** — Corey confirmed it stays; it is not in this diff, and `git show --stat` proving that is the claim.
- **`lib/queries.ts` entirely.** No new column, no widened `SELECT` — including whatever item 4 finds.
- **Everything HO 672 is holding right now:** `tsconfig.json`, `docs/method.md`, `app/api/cron/summarize/route.ts`. It is mid-flight; do not touch its territory even to tidy.
- **HO 670's landed work and its three filed follow-ons** — `app/welcome/*`, `WelcomeClock`, the `HeaderBar` `IN BETA` + clock, the `--font-mono` → Plex Mono swap, the `/welcome` tape unification with `components/MarketsTape`.
- The `showMeta` QUEUED entry from HO 669; the `BillRowList` compact passthrough; the M3 re-arm (post-Sep-15).
