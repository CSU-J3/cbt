# HO 722 — the `/welcome` rail and bottom bars: right-pinned by the HO 670 ruling, priced into the residue register as one route line, and the identity restated with every term registered

The line this HO closes is `docs/backlog.md:558` (FIT & FINISH, filed HO 720): `welcome` reads **M1b 2** at 2560 — `div.landing-module__…__rail` interior **1857px** and `div.landing-module__…__bottom` interior **1593px**, both trailing 0, both 2560 wide — and (iv′)/(iv″) carry them as *filed, not registered*. The line's own first reading decides: *the ruling record*. It has been read for this handoff and it is not ambiguous.

**The pin is Corey's setting, twice.** Both bars are built on one rule, `.spacer{flex:1}` (`app/welcome/landing.module.css:31`), placed between the brand/tag and the clock in the rail (`app/welcome/page.tsx:255-266`) and between the sources line and LAST SYNC in the bottom bar (`:417-429`). The signed-off mock `docs/design/welcome-formats-mock.html` draws exactly that in the format that was ruled: `.rail .spacer{flex:1}` at `:45` and `.f1 .bottom .spacer{flex:1}` at `:159`, and the roadmap's HO 670 block records *"three formats, format 1 ruled"*, Corey ruling the redesign on **2026-08-17** against a mock *"iterated to sign-off"*. The bars were born with that ruling: `git log -S spacer -- app/welcome` returns one commit, `b5a9455` (HO 670, 2026-08-18, *rebuild /welcome as the board layout*). Under `docs/method.md` § Roles the setting resolves the fork, so a C1 fix here is against the ruled mock, the (ix) shape. **Disposition: residue by ruling, priced, one route line carrying both classes** (the `/members` (1) form, one route term with its classes itemised), and the identity restated so that for the first time since HO 634 every term is a register line and none is *filed*.

**One commit by default, `docs`.** No product code, no CSS. SKILL is not touched unless STEP 0 finds a sentence that becomes false or misleading once the line lands; `:1847` describes the rail without claiming anything about its packing, so by the standard HO 721 set (a forced consequence is a clause whose absence leaves SKILL false) there is nothing forced. Read-only on the DB. If Corey volunteers a re-ruling at the HALT, the branch at the end applies instead.

## Ground truth (read at `1813c9e`; re-derive every `:N` by content)

- `app/welcome/landing.module.css` (350 lines): `:22-24` `.page` is `display:flex; flex-direction:column; min-height:100vh`; `:27-28` `.rail{display:flex;align-items:center;gap:12px;flex-wrap:wrap;padding:14px 28px;…}`; `:31` `.spacer{flex:1}`; `:39` the HO 697 note that the rail is *a ruled surface (HO 670)*; `:258-259` `.bottom{display:flex;align-items:center;gap:16px;padding:14px 28px;margin-top:auto;border-top:…}` with the comment above it (`:253-257`) explaining `margin-top:auto` anchors the bar under the board's slack. No `justify-content` and no `margin-left:auto` anywhere in the file; the pin is the spacer.
- `app/welcome/page.tsx` (433 lines): `:255-266` the rail — `.brand` (*Congressional Terminal:\>*) · `.beta-tag` · `<span className={styles.spacer} />` · `WelcomeClock`; `:417-429` the bottom — `.foot` (congress label · sources · *synced 4× daily*) · spacer · `.foot` (LAST SYNC + stamp).
- `docs/design/welcome-formats-mock.html` (622 lines): `:43-45` the rail CSS with the spacer; `:134-159` FORMAT 1 (`.f1 .top`, `.f1 .board`, `.f1 .bottom` + `.f1 .bottom .spacer{flex:1}`); the F1 markup carries `<span class="spacer">` in its rail (`:470-505`) and its bottom (`:415-421`) — STEP 0 confirms those line ranges sit inside the F1 section, not F2/F3.
- `docs/roadmap.md:853` the HO 670 block: *Corey ruled the redesign in chat on 2026-08-17 against an interactive mock iterated to sign-off*; *three formats, format 1 ruled*; the new shape *top rail (the Congressional Terminal prompt · [ IN BETA ] · a ticking clock) · … · bottom rail*.
- `docs/backlog.md:558` the filed line; `:344` the residue register; `:345` (1) `/members` — the one-route-many-classes form; `:356` (ii) the non-px-constant form; `:359` (v) a line prices the worst gap; `:361` (iv″) — **10 = 4 + 0 + 1 + 1 + 2 + 2 (`/welcome`, filed, not registered) · M1x 306 · M1c 5**, derived at `c18a3b4`; `:365` (ix), the by-ruling form to copy.
- `.claude/skills/cbt/SKILL.md:1847` the `/welcome` passage (no masthead of its own, the tag and clock ride its own top rail, the clock page-local); `:1989` C1; `:2013` accepted residue is cited, never subtracted.
- `scripts/diagnostic/layout-audit-606.ts`: `welcome` is a crawled route; `--route welcome` is ~4 loads. Leg C 22 of 22 and leg B green on three anchors at HO 721's close.
- Estimates, not readings: the rail gap at 1920 **~1,220px**, 1440 **~740px**, 1100 **~400px**; the bottom similar less ~260; both bars wrap below **~700px** (the rail is `flex-wrap: wrap`, the bottom is not — the bottom may overflow or shrink rather than wrap, which STEP 0 reads); packed left (variant A) reads the rail gap **12px** and the bottom **16px**, the row gaps; no cap variant exists on this page because it is full-bleed by format (the board is three full-width columns), so variant B is *not applicable*, recorded as such.

## STEP 0 — enumerate and measure, then HALT

| # | check | expected | if the work never happened, this reads |
|---|---|---|---|
| 1 | `git ls-remote --heads origin`; `git status --porcelain`; pointer and highest HO; machine | `main` at `1813c9e` alone (HO 721 landed); clean; 721 / 721 → **722** | `main` still at `a396c6f` means HO 721's FF is pending and this HO waits behind it |
| 2 | quote `landing.module.css:27-28`, `:31`, `:258-259`; `page.tsx:255-266`, `:417-429`; mock `:45`, `:159`, and the F1 section bounds that contain `:415-421` and `:470-505`; roadmap `:853`'s *format 1 ruled* and *2026-08-17* sentences; backlog `:558`, `:361`, `:365`; SKILL `:1847` | as in ground truth; **the mock's F1 draws both spacers** | a mock whose F1 does not carry the spacers reopens the disposition and the HALT says so |
| 3 | `git log --format='%h %ad %s' --date=short -S spacer -- app/welcome` | `b5a9455` alone | a second commit means the pin postdates the ruling and the HALT says so |
| 4 | `npm run build` · `npm run typecheck` | 0 · 0 | not this HO's to fix |
| 5 | legs A/B/C at HEAD | leg C 22 of 22, leg B green on `/`, `/electoral?cycle=2028`, `/vote` | a red leg means no reads |
| 6 | `--route welcome` at 2560, hit 2: the route line and both `m1.rows` entries | **M1 2 · M1b 2 · M1c 0**, rail 1857 / bottom 1593, trailing 0, width 2560 | **the pre-state and the control**; a route already reading 0 means the geometry moved |
| 7 | the bars' geometry in the page at **2560 · 1920 · 1440 · 1100 · 700**: bar width, left group's ink right edge, right group's left edge, the gap, and whether the bar wrapped (rail) or shrank/overflowed (bottom) | five readings each; 2560 reproduces row 6 | the register line's px column and its width dependence, including where the rail stops being one line |
| 8 | **variant A, applied in-page and re-read** (`.spacer{flex:0}` on both bars) at 2560 and 1440: gap, and where the clock and LAST SYNC land | rail 12px, bottom 16px; both right groups sit beside the left groups | the price of the un-pin: the masthead idiom (brand left, clock right) and the footer idiom (sources left, stamp right) both go, and the board's frame loses its two anchors |
| 9 | variant B: is there a narrower column to cap the bars to? Read the board's width and the banner's grid at 2560 | full-bleed, no cap target | recorded as *not applicable*, not proposed |
| 10 | bridge controls: `--route home`, `--route vote` | M1b 1 · M1c 0 · M1c 3 respectively, the (iv″) readings | nothing else moved |

HALT here with the ten rows. The go arrives as a file.

## STEP 1 — docs (commit `docs(HO 722)`; `docs/backlog.md`, `docs/roadmap.md`, `docs/oddities.md` if anything surprised)

- **Register line (x)**, one route term, two classes, the (1) form with (ix)'s by-ruling reasoning: **`/welcome` 2** — `div.landing-module__…__rail` and `…__bottom`, each with its 2560 gap and the row-7 curve beside it (the (ii) form, since the gap is width-dependent and the rail wraps), the mechanism named once (`.spacer{flex:1}`, `landing.module.css:31`), the ruling quoted with provenance (mock `:45`, `:159`, F1; roadmap `:853`, *format 1 ruled*, 2026-08-17; introducing commit `b5a9455`), and **the price**: variant A's readings from row 8 and what the un-pin costs (the two idioms), variant B recorded as not applicable from row 9. *Leaves this register* under a re-ruling of format 1's rail or bottom, or a redesign of the page, and says so.
- **(iv‴)** appended after (iv″), never edited into it, **derived from (iv″) at `c18a3b4` plus this route's re-read, not a crawl**, and saying so in its first sentence: **Site M1 10 = 4 (`/members`) + 0 (`/vote`, M1c 3) + 1 (`/lobbying`) + 1 (`/trades`) + 2 (line (ix)) + 2 (line (x)) · M1x 306 · M1c 5.** Then the sentence that is the point of the HO: **every term is a register line; nothing is filed-not-registered and nothing is unexplained** — the first time the identity has closed that way since it was written at HO 619.
- **`:558` strikes** on line (x), row 6 quoted as the pre-state, and the *three readings* sentence resolved: (1) decided, (2) not reached, (3) confirmed.
- **Roadmap:** one `Also (HO 722)` block, pointer 721 → 722: the rulings cited, the five-width curve for both bars, the price, (iv‴), and the closed-identity sentence.

## SKILL — none by default

`:1847` stays as it is unless STEP 0 row 2 finds a sentence that the register line makes false or misleading. If Code judges a one-clause cross-reference (*both bars are right-pinned by the format-1 ruling; register line (x)*) worth having so the next reader does not re-file the gap, it lands as its own `docs(skill)` commit **named as a widening, not a forced consequence**, and the SKILL diff is approved alone as always.

## The branch that is not the default

If Corey's word arrives at the HALT re-ruling either bar, STEP 1 becomes `fix(HO 722)` landing variant A on that bar (the spacer's `flex`, the `:39` and `:253-257` comments rewritten, the mock kept as the record of what was ruled and superseded), gated by `--route welcome` reading M1 for that bar at 0 against row 6, the DOM floor, captures at **1440 / 2560 / 430** plus a reduced-motion pass (render-touching: a clock or a stamp moves), and the ref's `narrow-preview` reading for `welcome` at 430 and 390. The register line prices only the bar that stays pinned, or is not written if both move; (iv‴) restates either way.

## Gates

Legs green at HEAD before any read. Build then typecheck, exit 0, re-run before the paste. Every number in line (x) and (iv‴) traceable to a closure-table row. `git diff --numstat` on `docs/backlog.md` with each deletion explained (expect the rewritten `:558`; (x) and (iv‴) are additions). Bind evidence for the local server. Remote claims via `git ls-remote`.

## Review ref, then FF

Review branch from the start; push the ref; `HEAD:main` no force; `git ls-remote --heads origin`; delete the ref; local `main` fast-forwarded and `git rev-parse main` pasted; `npm run verify:deploy` for the tip. A docs-only FF still deploys, so the Production run that follows is a deployment_status sample, named as such and not counted toward the `backlog:51` week. Paste-back per method § Executing a handoff.
