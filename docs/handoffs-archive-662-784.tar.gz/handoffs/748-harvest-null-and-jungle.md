# HO 748: two dated fixes in the harvest, the NULL comparison that hides FL-20's nominee and Louisiana's `jungle` rows before 2026-11-04

Two `docs/backlog.md` OPEN LOOPS lines filed at HO 747, both in `lib/harvest-challengers.ts`, both one clause each, both with a date:

- *A race that stores no incumbent drops from its roster every primary winner who carries a bioguide, because `<> NULL` is NULL (HO 747)*, owner Code, high. FL-20's Democratic nominee is missing from its roster, and the general is Tuesday 2026-11-03.
- *Louisiana's six House races are decided on 2026-11-03, and the harvest would publish their winners as `won_primary` (HO 747)*, owner Code, dated before the `0 0,12 * * *` tick of Wednesday 2026-11-04 12:00 UTC. Its close holds the rows out until *What a race page shows once its race is decided is unruled…* (HO 747) is ruled.

The architect sequenced this ahead of the ballot reader and the committees cursor probe: both fixes are small and certain and carry dates, and the reader is neither. **Out of scope:** the identity line (*The harvest's incumbent exclusion trusts a bioguide the ingest assigns by surname…*, HO 747). Namesakes and unlinked incumbents stay exactly as they are; this HO changes what happens when the race stores no incumbent, and nothing else about the exclusion.

## Ground truth (read at `38c49a6`; re-derive every `:N` by content)

- `lib/harvest-challengers.ts`
  - `HARVEST_FROM_WHERE` (`:76-88`) keeps a winner only if `( pc.bioguide_id IS NULL OR pc.bioguide_id <> r.incumbent_bioguide_id )` (`:83`). With `r.incumbent_bioguide_id` NULL and a non-NULL `pc.bioguide_id`, the `<>` is NULL, the `OR` is NULL, and the row fails.
  - Nothing in it filters `p.primary_type`. The INSERT's CASE (`:162-163`) sends every type but `top_four` and `top_two` to `won_primary`, `jungle` included. The comment at `:124-132` says `jungle` is "out of scope here", and that it doesn't reach the SELECT today (HO 736: jungle 0). Both hold only because Louisiana's six rows carry no winner yet.
  - The header comment says "a winner with a NULL bioguide is never the incumbent (HO 213 probe: zero incumbent winners lack a bioguide)" (`:71-72`). HO 747 measured two that do (CA-14, S-SC). That's the identity line's defect, but the sentence sits beside the clause this HO edits, so it gets corrected here.
  - It runs as `/api/cron/race-challengers` at `30 12 * * *` (`vercel.json:82-83`), as a DELETE of every sentinel row and then this INSERT, so a changed predicate re-flows on the next tick with no manual write (the comment at `:119-122`).
- `lib/race-matchup.ts:76`: the render-side exclusion compares in JavaScript and doesn't share the NULL defect. Nothing there changes.
- `scripts/diagnostic/roster-coverage-642.ts:221` copies the predicate, NULL drop included, so it can't count what the fix adds.
- `SKILL.md` quotes the predicate at `:1246` (the harvest entry, "exclude the seat incumbent (`pc.bioguide_id <> r.incumbent_bioguide_id`)"), and possibly again at `:1879`. After this HO, every quote of it is stale.
- SQLite's `IS NOT` is null-safe: `'X' IS NOT NULL` is true, `'X' IS NOT 'X'` is false, `NULL IS NOT NULL` is false.

## STEP 0

1. HO number from the tree. This file assumes `main` is at `38c49a6` (HO 747 landed), so the arithmetic reads 747 and this is 748. If the tree says 747 is next, HO 747 hasn't landed: stop and say so.
2. Re-read every cited `:N` at HEAD by content, the SKILL quotes included. Flag a drift; don't absorb it.
3. Predict the whole change's effect on today's data, from prod, SELECTs only:
   - every 2026 race with `incumbent_bioguide_id` NULL (HO 747 read FL-20 and TX-23), and for each, the winners `HARVEST_FROM_WHERE`'s join reaches with a non-NULL bioguide. Those are the rows the NULL fix adds. For each one, print the name, the bioguide, and the `members` name that bioguide belongs to;
   - `primaries` rows by `primary_type`, NULL included, and every `jungle` row with its winner count (HO 747 read six, 0 winners). The jungle skip should add and remove nothing today.
4. Halt if any added row's bioguide names someone other than the candidate. The fix would publish that person with a wrong member link, which is the identity line's defect arriving through this one. Otherwise proceed without a halt.

## The change

1. `:83` becomes `( pc.bioguide_id IS NULL OR pc.bioguide_id IS NOT r.incumbent_bioguide_id )`. The `IS NULL` arm stays, because `NULL IS NOT NULL` is false.
2. `HARVEST_FROM_WHERE` gains `AND p.primary_type IS NOT 'jungle'`, null-safe, so a NULL-typed primary stays in.
3. Comments, in the same code commit: `:71-72` records HO 747's two incumbents with no bioguide, pointing at the identity line by its opening words; the `jungle` note (`:124-132`) says the exclusion is now enforced in the WHERE rather than asserted, until the election-night line is ruled; and the clause at `:83` gets a line on why it's `IS NOT`.
4. `scripts/diagnostic/roster-coverage-642.ts:221` takes the same one-clause fix, in its own commit.

Nothing else changes: no other clause, no render code, no schema.

## Legs, on a `file:` copy, each seen red before green

Seed the copy from prod the way HO 746's legs seeded theirs: only the tables the harvest reads and writes (`races`, `primaries`, `primary_candidates`, `race_candidates`, `race_ratings`), the URL built as `file:${abs}` by construction, and every perturbation refusing a URL that isn't `file:` and printing the scheme it ran against. Run `harvestChallengers` itself, the function both callers share.

1. The NULL fix. On the unperturbed copy, FL-20's Democratic nominee is absent after a harvest on today's code (red) and present after the fix (green). The control: a race that does store an incumbent, whose own winner row carries that incumbent's bioguide, stays excluded both before and after (name the race). The fix must not start publishing incumbents.
2. The jungle skip. Mark one Louisiana `jungle` candidate `winner` on the copy. Today's code publishes them as `won_primary` (red); the fix publishes nothing for Louisiana (green). The control: a winner under a NULL-typed primary (name it) publishes before and after, so the null-safe `IS NOT` is seen keeping NULL.
3. The whole table. On the unperturbed copy, harvest once on today's code and once on the fix, and diff the sentinel rows. Expected: exactly the rows STEP 0 predicted, nothing else. Any other difference is a stop.

## SKILL, its own commit, approval requested in the paste-back

Every quote of the predicate (`:1246`, and `:1879` if it quotes it) moves to the null-safe form, with HO 748 and one clause on why the `<>` form was wrong. The harvest entry at `:1246` gains one sentence: `jungle` primaries are excluded until the election-night line is ruled, because an outright jungle winner is elected and no roster status says so.

## Commits and docs

- `fix(HO 748)`: `lib/harvest-challengers.ts`, the two clauses and the comments.
- `diag(HO 748)`: `roster-coverage-642.ts:221`; the legs driver, if it's a new file.
- `docs(skill)`, per the method's SKILL convention: the SKILL edits above, alone.
- `docs(HO 748)`: strike both lines on the legs, with the reading (leg results, the whole-table delta, the rows added) in each one-line close note, and the roadmap block, pointer 747 → 748. Reconcile OPEN LOOPS at open and close, control `^- \*\*~~` at 0 both times. Expected: 259 live / 299 struck / 558 at open, 257 / 301 / 558 at close.
- Review ref `748-review`. The FF is held for the SKILL approval and review.

## Gates

The cheap gates: `npm run typecheck`, `npm run check:odds-sites` and `npm run check:design-citations`. No render code changes, so no captures. After the FF (not in this HO), the first `30 12 * * *` tick reads FL-20's roster in prod.

## Paste back

- STEP 0's readings, with the predicted rows;
- the three legs, red and green, with their controls;
- the SKILL diff, for approval;
- `git show --stat` per commit, and `--numstat` for the docs commits (the deletions column, not a grep);
- the reconcile;
- the review ref's SHA from `git ls-remote`;
- a last cheap-gate run immediately before the paste, with the reading named.
