# HO 777: election-night rehearsal. Today's code on a fresh copy of prod, the clock at Nov 4 with marks planted, every surface that turns read against what it should say, and the Nov 4 procedure walked against today's setup. With HO 776's FF readings

**Corey's ruling, 2026-10-11 about 5:55 PM MT:** asked what Code should do next, he picked *Election-night rehearsal* over *Your stub-sentence call* and *Done for today*.

**Why now.** Results night is November 3-4. HO 758 and HO 767 tested the day after on copies seeded 09-29 and 10-08, and nine HOs have changed the surfaces and the data since. HO 773 also found Ballotpedia's wall on your box, and the WATCH's Nov 4 procedure runs two of its steps from that box.

**Scope, in:**
1. **Part A, the rendering:** every result shape HO 758 and HO 767 planted, plus the shapes added since, on today's build, each read as PASS or FAIL.
2. **Part B, the procedure:** the WATCH (HO 758) line's three steps, walked against today's setup, with two authorized cron calls.
3. **HO 776's FF go,** into this block.
4. **AL-01's reading,** at STEP 0 if that falls after 2026-10-12 02:22Z, with HO 774's three reads. If not, it carries.

**Out:** fixing what the rehearsal finds. Each finding is filed, and the next HO fixes it. Every other OPEN LOOPS line is out too.

**How STEP 0 runs** (method.md, HO 768's rule): the claims are mine and are a check.

**Base:** `main` at `e15daca`. HO number: the pointer is 776 and the highest HO in commit subjects is 776, so this is 777.

## STEP 0

| # | Claim at `e15daca` | Fails if |
|---|---|---|
| 1 | `lib/clock.ts` honours `CBT_CLOCK_NOW` only when `TURSO_DATABASE_URL` is a `file:` URL, and `daysToElection`, the band and the race page's decided state all read it. | |
| 2 | `scripts/diagnostic/election-night-legs-758.ts` and `scripts/diagnostic/electoral-legs-767.ts` seed whole tables from prod with a SELECT-only reader into `file:` copies, plant marks by hand, and start one local server per copy, its sentinel checked on `/api/health`. Their headers list the plants. | |
| 3 | `/api/cron/general-ballot` takes an authorized GET or POST (Bearer `CRON_SECRET`), and reads at most 40 races a call (`TICK_CAP`, `lib/general-ballot.ts:76`) within 240s (`:77`). Its `maxDuration` is 300 (`vercel.json`). | |
| 4 | `/api/cron/primaries` takes no target: each call walks the cursor's next slice (`app/api/cron/primaries/route.ts:1-8`). `scrapeHouseCandidates` reads the dev cache first unless `bypassCache` is set (`lib/primary-candidates-scrape.ts:585`). | a call can name a state |
| 5 | The WATCH (HO 758) line's procedure has three steps: (a) a manual `npm run sync:general-ballot -- --all --write`; (b) one POST of `/api/cron/race-challengers`; (c) Louisiana by `npm run sync:house-primaries -- --region=south`. | |

## Part A, the rendering (`diag`)

**The script:** `scripts/diagnostic/election-night-rehearsal-777.ts`, built from the two leg scripts. Copy what it needs, and import nothing from them.

**The seed:** one fresh seed from prod, SELECT only, the union of the two leg scripts' table lists, fingerprinted before and after. The copies are `file:` URLs under the gitignored scratch directory, their names ending `-777-rehearsal.db`.

**Three copies:**
- `today`: as seeded, with the clock unset, for the dormant check;
- `night`: marks planted (below), with the clock at 2026-11-04T15:00:00Z;
- `band`: the rated index's seats marked the way HO 758's band copy marked them, with the clock at Nov 4.

**The plants on `night`:**
- **Every shape HO 758 and HO 767 planted,** re-matched to today's printed rows. A shape whose rows no longer exist reads STALE, with what changed. Re-plant it on another race of the same shape if one exists.
- **A decided race's rater chips (HO 775):** on a re-elected race, the three chips are anchors to their chamber's pages inside the dimmed *final call ·* block.
- **GA-13 (HO 773):** its D nominee marked. Elected on that row, and record what the card reads for its incumbent, who lost the primary.
- **AL-01 and S-AL (HO 776):** Carl marked on AL-01, and Moore marked on S-AL. Expect Elected on Carl's row and R HOLD on `/electoral`. Record what AL-01's card and its open row say for Moore, and whether S-AL's row was tied to him at the seed.

**Today's build:** `next build`, cold, with one server per copy and each sentinel checked.

**The checks,** each a PASS or FAIL line with what it read:
- **Dormant, on `today`:** no race page, `/electoral` row or band shows a result, *final call*, Elected or RUNOFF.
- **Each race page, on `night`:**
  - the header (*Decided*, *Not yet called*, *Runoff Dec 12*);
  - the chips dimmed under *final call ·*;
  - Elected on the marked row;
  - the card's word;
  - the provenance line.
- **`/electoral`, on `night`, at 1440 and 430:**
  - each planted row's chip: `{P} HOLD`, `{P} GAIN`, `{P} WIN`, RUNOFF or NO CALL;
  - the column head *Result*;
  - a called seat's open row with no Kalshi line, and its MAP card likewise;
  - the calendar folded, *all voted*, with no NEXT.
- **The band, on `band`:** the RESULTS line's N and House totals equal a SELECT over the marks.
- **The reader** (HO 758's leg 9), on HO 747's saved pages:
  - a ranked-choice box marks only its *Won (N)* row;
  - a marked row reaches `general_ballot.marked` through the reader's own write path.

**Captures** at 1440 and 430: two decided race pages, the not-called one, `/electoral`'s LIST and the band.

**Safety, stated in the script's header:**
- prod is only read;
- the copies are `file:` URLs, and children get `TURSO_AUTH_TOKEN=""`;
- every printed line goes through `redactSecrets`.

## Part B, the procedure

Walk the WATCH's three steps.

**(a) The ballot sync.**
- It runs from your box, and Ballotpedia's wall has challenged that box since HO 773. Don't fetch Ballotpedia to show it again: cite HO 773's reading.
- The replacement is authorized POSTs of `/api/cron/general-ballot`, each a 40-race tick from pdx1.
- **Rehearse it once.** Make one authorized POST with `$CRON_SECRET` by env name. Keep it clear of the scheduled readers of Ballotpedia: outside :15-:35 of an even UTC hour (this route's tick) and outside 00:00-00:10 and 12:00-12:10 UTC (the primaries cron's).
- Read its `cron_runs` row (status, elapsed, races read) and the queue after it.
- From those, say how many calls the 470 races need on Nov 4, and how long they take back to back.

**(b) The harvest POST.** Rehearse it once: one authorized POST of `/api/cron/race-challengers`. Read its `cron_runs` row, and whether it expired `races`.

**(c) Louisiana.** Read this in code only:
- the CLI runs from your box, which is walled, and reads the dev cache first (claim 4);
- the primaries cron takes no target.

So on Nov 4 nothing can read Louisiana's six contests on demand. Name what it would take: a route that reads LA's six House contests when called, live, from pdx1. That's a finding, and it's filed.

**These two calls are this HO's only prod writes,** the same writes their scheduled ticks make. Nothing else writes.

## Docs

**roadmap:** the HO 777 block. It opens with **HO 776's FF go as taken** (your paste), including the go's slip: it named AL-02, 06 and 07 as uncontested, where the texts rightly say AL-01, 02 and 07, so nothing changed. Then Corey's ruling, STEP 0, Part A's checks and Part B's walk.

**backlog:**
- **The WATCH (HO 758) line:** its procedure rewritten from Part B:
  - (a) becomes the authorized cron POSTs, with the count and spacing Part B measured;
  - (b) stays as rehearsed;
  - (c) is marked blocked on the Louisiana line below until a fix lands.
- **A new line, Louisiana on Nov 4,** from Part B (c), *Owner:* Code, medium, dated before 2026-11-03.
- **A line for each Part A FAIL,** or one per shared cause, with the check that failed and what it read. A STALE shape needs no line.
- **Moore's line,** struck on AL-01's reading if you took it.
- Reconcile, with the control at 0.

No SKILL edit, unless a FAIL changes a convention. If one does, say which, and leave it for the fix.

## Commits

On `777-review` from `main`, kinds unmixed:
- `diag`, Part A's script;
- `docs`.

Build, then the cheap gates, before every push.

## Paste back once, after the Preview and `narrow-preview`

- `ls-remote` with `777-review`'s SHA;
- STEP 0, and AL-01's reading if taken;
- **Part A:** the seed's fingerprints, the plants (STALE and re-planted ones named), every check as PASS or FAIL with what it read, and the captures;
- **Part B:** the two calls' rows, the Nov 4 count and timing, and the Louisiana finding;
- the Preview, and `narrow-preview`;
- `--stat` per commit, and `--numstat` for docs with every deletion explained;
- the reconcile;
- a last cheap-gate run.

Build through to the review push without stopping. A FAIL is a finding, not a HALT.
