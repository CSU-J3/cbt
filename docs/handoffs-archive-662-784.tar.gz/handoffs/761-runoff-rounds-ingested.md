# HO 761: the runoff rounds Ballotpedia already prints are ingested, so a runoff loser reads LOST PRIMARY, a seeded runoff gets its winner, and the runoff block stops saying PENDING

Two OPEN LOOPS lines and one finding:

- *An incumbent who lost a runoff the `primaries` table doesn't hold reads NOT ON THE BALLOT, not LOST PRIMARY (HO 759)*, owner Code, low: TX-09's Al Green, TX-32's Julie Johnson, S-TX's John Cornyn.
- *The Aug 25 SC runoff has no row (HO 600/601)*, owner Code: a `-runoff` row exists for three Senate contests only (LA's two, GA's R), all hand-seeded, while 215 first rounds carry a `runoff_date`.
- HO 760's finding, filed here: `/race/S-GA-2026` still renders *Republican Runoff · 2026-06-16* with Collins and Dooley both PENDING, because the HO 174 seed row was never marked.

The page already prints the answer: a runoff box (`<h5>… primary runoff …`) sits in the same section the parser reads, and `parseCandidatesPage` drops it on purpose (`lib/primary-candidates-scrape.ts:361`). This HO keeps it, as a round of its own.

## Ground truth (read at `ead1020`; re-derive every `:N` by content)

- `parseCandidatesPage` keeps a box only if its `<h5>` says `primary` and not `runoff` (`:361`; the comment at `:338-339`). `parseVotebox` reads rows, `<u>` and the `winner` class. Runoff boxes carry the same markup.
- `primaries` keys a contest by `id` (`house-TX-18-2026-D`, `senate-GA-2026-R-runoff`), with `election_round` (`'primary'`/`'runoff'`), `primary_date`, `runoff_date`, `primary_type`. `primary_candidates` rows carry `status` `winner`/`running`. The three seeded runoff rows are `senate-LA-2026-{D,R}-runoff` and `senate-GA-2026-R-runoff` (HO 107/174 pattern, `seed:runoffs`).
- The calendar (`lib/primary-calendar-scrape.ts:34`, `:125-126`) carries each state's `runoffDate`; the sync writes it to the first round's `runoff_date` (`lib/primaries-sync.ts:370-382`).
- `isSettled` (`lib/primaries-sync.ts`, HO 661) refuses a rewrite of a past-dated round with no winner after 30 days. Texas's runoffs were 2026-05-26, Georgia's 06-16, so a runoff row inserted today with no winner would freeze at once; one inserted with its winners doesn't need a rewrite.
- `components/RaceRunoffs.tsx` renders `primaries` rows with `election_round = 'runoff'`: `running` as PENDING, `winner` as *Won*, and the comment at `:34-35` expects `'loser'`.
- `lib/incumbent-qualifier.ts:34-37` reads a runoff loser as `absent` because the table holds no runoff round to find them unmarked in.
- The dev cache (`.cache/ballotpedia`, HO 206) predates the primaries; any page read here is live, at the reader's pacing.

## STEP 0

1. HO number from the tree: `main` at `ead1020`, pointer 760, so 761. Otherwise stop.
2. Re-read every cited `:N` by content. Flag a drift.
3. Measure, prod, SELECTs only: first rounds with a `runoff_date`, by state; the three seeded runoff rows and their candidates; the incumbents HO 759 reads `absent` who were marked in a first round with a `runoff_date` (the three, and any others).
4. On HO 747's saved pages (no fetch): count runoff boxes by state and chamber, and print TX-18's and S-GA's as the parser would read them (rows, marks). That's the set the repair will fetch live.
5. Carry HO 760's FF-go readings into this HO's roadmap block.
6. Proceed without a halt.

## The build

1. `parseCandidatesPage` keeps a runoff box as a contest of its own: id `<first round id>-runoff`, `election_round = 'runoff'`, the party from the box, `primary_date` = the first round's `runoff_date` from the calendar (or the box's own date if it prints one; say which), `primary_type` = the first round's. Its rows and marks read exactly as a primary's. The dedup at `:305` keeps the two rounds apart.
2. The sync upserts runoff rows the same way it upserts first rounds, marks included in the same write, so `isSettled` never sees an unmarked past-dated runoff. A seeded runoff row (GA's) is updated by name, the way `reingest:primary-slate` does, and keeps its seed URL if the page gives none.
3. `RaceRunoffs.tsx`: a `running` row in a decided runoff (one with a winner) renders *Lost*, not PENDING; PENDING stays for an undecided one.
4. `lib/incumbent-qualifier.ts`: an incumbent unmarked in a decided runoff reads `lost_primary`; the `absent` comment at `:34-37` is corrected.
5. The repair, `npm run repair:runoffs`, dry by default, `--write` to write: fetch live, at the reader's 6s pacing and user agent, the pages of every first round with a `runoff_date` (STEP 0's count, about 215 units, about 22 minutes), and upsert their runoff rounds. Louisiana's Dec 12 is in the future and is left to its own line.

## Legs, on a `file:` copy with HO 747's saved pages, each red first

1. The parser: TX-18's page yields `house-TX-18-2026-D-runoff` with Green unmarked and the winner marked; S-GA's yields the seeded id with Collins marked and Dooley not. Red: today's parser yields neither.
2. The write: the GA seed row is updated in place (same id, marks landed); a Texas runoff arrives with its marks; `isSettled` blocks nothing on the first write; a second run changes nothing.
3. The qualifier: TX-09, TX-32 and S-TX read `lost_primary`. Red: `absent`.
4. The runoff block: S-GA renders Collins *Won* and Dooley *Lost*; an undecided seeded row (LA) still renders PENDING.
5. The repair's dry run writes nothing (content hash); its `--write` on the copy, from saved pages through a shim, yields STEP 0's count of runoff rounds, each with a winner.
6. Nothing else moves: the harvest's plan on the copy is identical before and after (the ballot governs the roster; `primary_marked` still reads the first round).

## Commits and docs

- `feat(HO 761)`: the parser, the sync, the repair.
- `fix(HO 761)`: `RaceRunoffs.tsx` and the qualifier.
- `diag(HO 761)`: the legs driver and shim.
- `docs(skill)`, its own commit, approval requested: runoff rounds as contests, the repair, `RaceRunoffs`' *Lost*, the qualifier's runoff reading, the seeded-runoff rows now maintained by the page.
- `docs(HO 761)`: strike the 759 runoff line on leg 3; annotate the SC runoff line with what the page says (did the Aug 11 field go to a runoff, and is its row now ingested); file and strike the S-GA runoff-block finding in one line; the roadmap block, pointer 760 → 761, carrying HO 760's readings. Reconcile OPEN LOOPS at open and close, control at 0.
- Review ref `761-review`. The FF is held for the SKILL approval, the captures (S-GA's runoff block before and after, 1440, 2560, reduced motion) and review.

## The prod reading (in the FF go)

After the FF: the repair's dry run pasted, then `--write` (runoff rounds written, winners per round); `/race/S-GA-2026`'s runoff block; `/race/TX-09-2026`, `/race/TX-32-2026` and `/race/S-TX-2026` reading LOST PRIMARY.

## Paste back

- STEP 0's readings and the saved-page runoff census;
- the six legs and the captures;
- the SKILL diff, for approval;
- `git show --stat` per commit, `--numstat` for the docs commits, the reconcile, the `761-review` SHA from `git ls-remote`, and a last cheap-gate run.
