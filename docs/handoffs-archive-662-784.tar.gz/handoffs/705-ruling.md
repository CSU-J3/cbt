# HO 705 — ruled: the fix is upstream and measured; CBT adopts Next 16 (architect, 2026-09-09)

**Owner verdict, verbatim: "A"** — Corey, CBT maintenance chat, 2026-09-09, against the architect's presentation of the fork after the STEP 1 window (A: adopt Next 16; B: stay on 15.5). Interpretation: Next 16.3.4 is the remedy for `backlog:51`; it is its own HO (706, authored with this file); nothing is filed upstream; candidate (b) is superseded, not failed.

**The gate, ruled by the architect as its author.** The `t2(15) ≥ 3` clause was a liveness check on the lever, and the re-arm leg was placed to prove the lever had not died mid-window. Leg 2 read 2, leg 5 read 6, the race sat at 35/36 on the Next 16 leg itself, and the zero on `t2(16)` is bracketed by live fires on the unfixed build before and after it in one sitting. The liveness the clause was for is met; the per-leg wording fails on a leg that fired. The headline uses window 2 alone; window 1's n15 cells are valid but pooling across windows is not the design and the block does not lean on it. Reading: **react#35494 cures CBT's fire.**

Docs only in CBT. No code changes. Both worktrees (`cbt-705-n15`, `cbt-705-n16`) stay on disk: the n15 worktree is HO 706's live-lever control and the n16 install is already paid for.

## 1. SKILL, alone

The `#418` bullet gains, provenance after each: (i) the React that runs is Next's vendored canary (`19.2.0-canary-0bdb9206-20250818` for 15.5.15; byte-identical hydration client through 15.5.25; `react-dom` in `package.json` is inert for the App Router, proven off the served document's request list and the app-build manifest, never a directory grep); (ii) the fix is react#35494, *"[Fiber] Correctly handle replaying when hydrating"*, merged 2026-01-13 (`c186624`, fixes #35210), never backported to 19.2, present in the `19.3.0-canary-cbb046ab-20260731` that Next 16.3.4 vendors; (iii) the reading: 2026-09-09 18:25–18:41Z, `seam-intervene-702.ts` unchanged, `t2(15)` 2 then 6 of 36 around `t2(16)` 0 of 36 with `HYD-BEFORE-TAIL` 35/36, both builds on webpack; (iv) the remedy is HO 706, adopt Next 16.3.4, on Corey's word; (v) the instrument dependency: the `hyd-start` trap is webpack-only (`self.webpackChunk_N_E`), and a Turbopack build is unreadable for this class until it is ported — window 1 read n/a ×36 on both Next 16 cells for exactly that reason. The HO 704 clause "versions pinned react-dom 19.2.5 / next 15.5.15" gains: *(the vendored canary is the React that ran; the anchors cited there are `node_modules/react-dom`'s, not the runtime file's, whose lines are `:2879` / `:11749` / `:7622`, the 704 handoff's originals — HO 705)*. One bullet, no other SKILL text.

## 2. Roadmap block (HO 705), pointer to 705

- The STEP 0 closure table as pasted, including the premises that did not survive it: the manifest as discriminator (the chunk directory does contain `19.2.5`, in the Pages-router `framework-*.js` the served document never requests); `react/react` after the org rename and the invalid `--state all`; row 5's second touch had no SKILL target; backlog (b) at `:53` and (C) at `:90`.
- Row 4 in full: react#35494 and #35210; the presence table; react/react#37551 (opened 2026-09-09, the residual `<head>` / HostSingleton case, confirmed by Code's run); vercel/next.js#43159 closed and locked 2026-04-01 with the maintainer's invitation quoted. The jsdom sweep: shapes A/D/F fire on CBT's canary and are clean on 19.3.0 and on 16.3.4's canary; shapes B and C, a function component suspending on `use()`, fire nowhere in jsdom; the browser window is the table that settled it.
- Window 1, void, kept at `705-artifacts/window-1-turbopack-unread.log`, and why: the trap's precondition was the bundler. The re-calibration (`--webpack` on the 16 build, instrument untouched, React unchanged, bundler removed as a confound), and the served-document proof of which React each build ran.
- Window 2, the table and all eight per-hit lines. The gate ruling above, verbatim. The verdict verbatim with provenance.
- The build-break list as Code wrote it, labelled STEP 0 of HO 706: one API, `revalidateTag` requiring a profile, 22 sites in 15 `app/api/**/route.ts`, zero in a page or component; Turbopack default; the `tsconfig.json` rewrite; `ignoreBuildErrors` as a measurement expedient; `.env.production.local` deleted in both worktrees.
- The three HO 703 lines it deferred: the `200 failed` grep pattern (an HTTP status beside a zero counter); the underscore-blind slug class; and the 703 FF go executed from its command line rather than its file, the HO 632 class, with the eight readings it skipped discharged in the correction paste.
- Contamination named: the `tsc` inventory overlapped leg 1 of window 1; it read 0 and stayed meaningful by the stated rule.
- **Notes now run through HO 705.**

## 3. Backlog

- `backlog:51` annotated, never struck. Headline gains: *upstream fix IDENTIFIED (react#35494) and MEASURED curing CBT under `t2` on Next 16.3.4 (HO 705); remedy HO 706 on Corey's "A"; close is 706 landed plus a week of dailies with the mutation channel at zero.*
- `backlog:53` (b) **struck with provenance:** superseded — the fix exists upstream, merged 2026-01-13, never backported to 19.2; measured in the browser on CBT's own document; no report filed and none owed; a backport request against the 19.2 line was considered and declined as low value (the line takes RSC security patches only; #37551 already covers the residual case), reopenable on Corey's word.
- **New OPEN LOOP: adopt Next 16.3.4 (HO 706).** *Owner:* Code, on Corey's "A". *STEP 0:* the break list above plus the instrument port. *Close:* `main` on 16.3.4 with Turbopack, the ported trap reading `HYD-BEFORE-TAIL` high and `t2` 0 of 36 on the shipped build against a live `t2(15)` control in the same sitting, then a week of dailies at zero. *What this reads if the work never happened:* the class stays live at its current rate and the seam instrument cannot read a Turbopack build.
- `backlog:90` (C) annotated: still QUEUED; re-evaluated after 706's week — if the class is gone, (C) closes as moot.
- Numstat deletions explained line by line.

## 4. Oddities, three entries

1. The React that runs is not the React in `package.json`: the App Router executes Next's vendored canary; two anchor sets in one arc pointed at two different files and the "correction" chose the wrong one. Discriminator: the served document's request list, or the app-build manifest — never a directory grep.
2. An instrument whose precondition is the bundler: the `hyd-start` trap on `self.webpackChunk_N_E` read n/a ×36 on a Turbopack build, so `FIRES=0` there would have been a gate that cannot fail. The fix was to restore the precondition (`--webpack`) rather than reinterpret the zero.
3. `.env.production.local` with all-empty keys shadows `.env` in production mode, silently; the stale-`.next` class one file over. Decide whether the main checkout's copy goes too, and say so in the block.

## 5. Gates, ref, paste

`typecheck` 0 · `build` 0 · `check:odds-sites` 0 · `check:design-citations` OK, run immediately before the paste. No code changes, nothing render-touching. Push `HEAD:refs/heads/705-review`; paste `git show --stat` per commit, the gate lines, the numstat with deletions explained, `git ls-remote --heads origin`. The SKILL diff and the block are read from the ref. Hold for the SKILL slot and the FF go — from a file, not a line.

read and follow 705 — ruled A, docs only
