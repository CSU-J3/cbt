# HO 683 — the overflow alarm: scheduled fire, GitHub ping, deploys untouched

Code kind. Resolves the HO 682 smoke fork by ruling: the **deploy-blocking form is struck, the alarm form is built**. The overflow check joins `smoke.spec.ts`'s existing crawl but is **armed only on scheduled and manual fires** — a `deployment_status` run never executes it, so a red deploy keeps meaning "your change broke it." When an armed run finds prod scrolling horizontally, a workflow step files a GitHub issue; that issue is the ping — Corey runs the GitHub app on his phone, and the forced-red gate below proves the ping lands there before anyone trusts it.

Why 1280 suffices: HO 682 measured the class as viewport-independent — the blowout fired identically 430 through 2560 — so the check rides the crawl's existing Desktop Chrome viewport with **zero new prod requests**.

## Ground truth at authoring

- Remote `main` `cdf4077` (HO 682c), pointer 682, number `max(682, 682) + 1 = 683`. Re-derive at session open.
- Workflow `.github/workflows/e2e-prod.yml`: triggers `deployment_status` + `schedule` cron `0 15 * * *` (15:00 UTC = 9:00 AM MT) + `workflow_dispatch` with **no inputs** (`:11-14`); concurrency `e2e-prod`, `cancel-in-progress: true` (`:18-20`); **no `permissions:` block anywhere** (grep 0), so the default token cannot create issues; crawl step runs `e2e/smoke.spec.ts` only, `--grep-invert "@nonci" --retries=2`; one post step, `Upload report on failure` → `playwright-report/`.
- Spec: per-route tests inside `test.describe("route crawl")` at `:137-141` over `ROUTES` (`:56`); viewport is `devices["Desktop Chrome"]` (1280) via `playwright.config.ts:30`; `BASE_URL` default prod (`:23-24`).
- `.gitignore:44-45` covers `test-results/` and `playwright-report/` — the overflow report file lives at `playwright-report/smoke-overflow.md`: wiped by the reporter at run start, written during the run, already swept up by the failure artifact step, never trackable.
- Known limit, named not fixed: the `e2e-prod` concurrency group is global with cancel-in-progress (backlog `:446`), so a deploy burst at 15:00 UTC can cancel the scheduled run, and a cancelled run files nothing — the alarm's worst case is a missed day. That closes when `:446` closes; it rides there.
- The proof dispatches below add two to three full prod crawls to the `:50` pageErr WATCH's fire count — bounded, named here so the next `:50` reader can subtract them.

## STEP 0 — enumerate, then HALT

Closure table: candidate · verdict · evidence `file:line` · destination. Nothing edited before the HALT.

| # | candidate | expected at HEAD |
|---|---|---|
| 1 | arming source | `github.event_name` values reaching the job: `deployment_status`, `schedule`, `workflow_dispatch` (`:11-14`, job `if` at `:24-30`); the gate env is set from `event_name == 'schedule' \|\| event_name == 'workflow_dispatch'` |
| 2 | permissions | confirm 0 `permissions:` blocks; the addition is top-level `contents: read` + `issues: write` — explicit read so nothing silently widens |
| 3 | where the check joins | the per-route test body at `:141` region; state where in the body the page is settled enough that `scrollWidth` is meaningful (after the route's existing waits, not before) |
| 4 | the report file path | `playwright-report/smoke-overflow.md` — confirm the reporter wipes the dir at run start (so a stale file cannot ping) and that parallel workers appending is safe at the config's worker count; if workers > 1 makes appends interleave, switch to per-route files `smoke-overflow-<slug>.md` and glob in the step |
| 5 | issue step mechanics | `gh` preinstalled on `ubuntu-latest`; `GH_TOKEN: ${{ github.token }}`; dedupe by title marker `[smoke-overflow]` via `gh issue list --state open --search`, comment if found else create — no label dependency, so nothing must pre-exist |
| 6 | the `:50` separation | a pageErr-only red writes no overflow file, so the issue step's condition is `always() && hashFiles('playwright-report/smoke-overflow.md') != ''` — file presence, never bare `failure()`; state that the two failure classes stay unentangled |
| 7 | forced-red path | `workflow_dispatch` gains input `force_overflow_red` (boolean, default false) → env `SMOKE_OVERFLOW_FORCE`; the spec writes one synthetic row (`FORCED-RED 1/0`) and fails one test, exercising writer → condition → issue end to end without prod being broken |
| 8 | both branches of the arming gate | the spec logs one line per run — `overflow gate: armed, N checks` / `overflow gate: unarmed, 0 checks` — so each branch is readable in run output; the unarmed evidence comes free from the FF's own `deployment_status` run |
| 9 | SKILL | whether the e2e/smoke passage exists and where the alarm paragraph lands; if yes, SKILL commit alone before docs |

**HALT. Corey rules on the table.**

## STEP 1 — implement (one code commit)

1. **Spec:** in the per-route test, when `SMOKE_OVERFLOW_GATE` is set: read `document.documentElement.scrollWidth/clientWidth` after the route's existing settle; on `over > 1` (M0's tolerance, same reason), append `| route | scrollWidth | clientWidth | over |` to the report file and fail the test with the numbers in the message. When `SMOKE_OVERFLOW_FORCE` is set: the synthetic row once, one failing assertion. Unarmed: no reads, and the gate line from row 8 either way.
2. **Workflow:** the `permissions` block; the dispatch input; the two envs on the crawl step; the issue step after the artifact upload — `if: always() && hashFiles(...) != ''`, body = the report file plus the run URL, title `[smoke-overflow] prod horizontal overflow`, dedupe per row 5.

`npm run typecheck` clean; the workflow validated with `gh workflow view` or actionlint if present, else by the first dispatch.

## STEP 2 — proof, in this order

1. **Armed green (baseline):** plain `workflow_dispatch`, no force — armed, all routes read, 0 over, no file, no issue. This is the first armed read of prod at 1280; if a route legitimately overflows today, that is a finding, not noise — HALT and report it.
2. **Forced red #1:** dispatch with `force_overflow_red` — run reds, issue created; paste the issue URL. **Corey's leg: confirm the ping arrived on the phone before anything else proceeds.** The alarm is not proven until the human end of it fires.
3. **Forced red #2:** dispatch again with force while the issue is open — the step **comments** on the existing issue, opens no second. Paste both (one issue, two events).
4. Close the issue. **Negative:** plain dispatch, no force — green, no file, issue count unchanged.
5. After the eventual FF, quote the first `deployment_status` run's `overflow gate: unarmed, 0 checks` line — the deploy-fire branch proven in the wild.

## STEP 3 — docs (and SKILL if row 9 says so)

One docs commit carrying the whole ledger close from today's session, each with its reading:

- **Strike the smoke-fork QUEUED line** quoting the ruling: blocking form struck, alarm form built (this HO), viewport-independence the reason 1280 suffices, the `:446` cancellation window and 24h worst-case latency named as accepted limits.
- **Strike `:71`** quoting the read: window **Last 6 hours, start ≈ 2026-09-02 13:34 UTC**, sorted by rows read, totals computed as avg × count because the view shows averages — committees rollup ~247k (30,900 × 8), market_ticks latest ~144k (2,220 × 65), HO 676 refresh scan ~107k (53,700 × 2), dashboard bills feed ~92k (7,630 × 12); every line attributable, no ghosts, no crawl residue, ~2.5M rows/day extrapolated matching Analytics. **The standing rule — nothing gets optimized off the current ledger — LIFTS with this strike.**
- **Annotate `:32`** (tape read burn): measured steady-state share ~570k rows/day (65 execs/6h × 2,220), second-largest total burner on the first clean ledger.
- **New FILED line:** the committees rollup (member_count + 30d recent_count subqueries) is the largest total burner on the first trustworthy ledger — first legitimate optimization candidate under the lifted rule; filed, not chased; any probe is its own HO.
- Roadmap `Also (HO 683)`, pointer to 683. `:427` untouched — this was the 6-hour window, not the 24-hour pair that WATCH needs. Oddities only if a control fails.

## STEP 4 — review ref, FF, ship

Push to `refs/heads/683-review`, `git ls-remote` confirm, paste the sha and `git log --oneline cdf4077..HEAD` (code, then SKILL if any, then docs). Local `main` stays at `cdf4077` until approval; the move follows the widened HO 655 rule, whichever door you're standing at. On approval: fast-forward, delete the ref, `npm run verify:deploy`, served SHA, then the STEP 2.5 unarmed-line quote from the FF's own deploy run.

## Paste-back

STEP 0 table at the HALT. After STEP 2: the five proof readings in order, the issue URL, and Corey's phone confirmation on the record. After STEP 4: the ls-remote line, the served SHA, the unarmed line.

read and follow 683
