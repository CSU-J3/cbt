# HO 775: each rater's name links to the rater's own ratings page, the attribution the Crystal Ball asks for. With HO 774's FF readings

**Corey's ruling, 2026-10-11 about 2:29 PM MT:** the Crystal Ball's About page says *"Crystal Ball content may be used by educators, press, and others with proper attribution"* (his screenshot), and our chips say only *Sabato*. Asked whether to link each rater's chip to its source page, he said yes.

**Scope, in:**
1. A link from each rater's name to that rater's own 2026 ratings page for the race's chamber, in two places: the chips on `/race/[id]` (`RatingChip`) and the three rater tiles in `/electoral`'s open row (`RaceOpenRow`).
2. The chip's title says where we read the row.
3. HO 774's FF go, into this block.
4. AL-01's reading, if this HO's STEP 0 or FF go falls after 2026-10-12 02:22Z.

**Out:**
- The compact spreads: `SpreadBar` names the raters only in its `title`, and `RaceCard` is itself a link, so neither can carry one.
- The district modal's text export.
- Every OPEN LOOPS line but Moore's.

**How STEP 0 runs** (method.md, HO 768's rule): the table is mine and is a check. Go on through the build, the legs, docs and the review push unless a claim fails.

**Base:** `main` at `ca11c35`. HO number: the pointer is 774 and the highest HO in commit subjects is 774, so this is 775.

## Why the rater's page, not `source_url`

Every stored rating row was written before HO 770, so its `source_url` is Ballotpedia's chamber page (`lib/race-ratings-sync.ts:363-367`), and no rater has written since 09-30. A link there would credit Ballotpedia, and attribution credits the rater. So the link goes to the rater's own page. `source_url` stays what it is, where we read the row, and the chip's title says so.

## STEP 0

| # | Claim at `ca11c35` | Fails if |
|---|---|---|
| 1 | `components/RatingChip.tsx:51-57` renders the rater's label as a `<span>` titled `RACE_RATING_SOURCES[rating.source]`, and `:40` titles the chip *Updated <ratingDate>*. Its one caller is `components/RaceHeader.tsx:88`, inside no link. | another caller, or a link around it |
| 2 | `components/RaceOpenRow.tsx:410-412` are three `Tile`s labeled `Cook`, `Sabato` and `Inside`. `Tile` (`:67`) renders `label` in `<span className="rl-tl">`. The open row renders at `components/RaceListView.tsx:291`, after the row's `role="button"` div (`:232`) closes, so no toggle wraps it. | the open row sits inside the toggle |
| 3 | `lib/enums.ts` imports nothing, and `RACE_RATING_SOURCES` is `:214-218`. | |
| 4 | `app/electoral/page.tsx:91` sends every cycle but 2026 to the seat outlook, so the list and its open row render only 2026. `RaceRating` carries `cycle` (`lib/queries.ts:2367`). | |
| 5 | SKILL `:2581` begins *Rendering: `/race/[id]` shows the full source-attributed chip(s)* and occurs once. | |

**The reading** (SELECT only): `SELECT source, source_url, COUNT(*), MAX(rating_date) FROM race_ratings WHERE cycle = 2026 GROUP BY 1, 2`. Expected: each rater's rows cite only Ballotpedia's two chamber pages, none dated after 2026-09-30. If a row cites anything else, list it. The title rule below holds either way.

**AL-01's reading:** take it at this HO's STEP 0 or its FF go, whichever first falls after 2026-10-12 02:22Z, with HO 774's three reads. If neither does, it carries to the next HO, and Moore's line stays open.

## The build

### § 1, the rater links (`feat`)

- **`lib/enums.ts`** gains `RACE_RATING_PAGES_2026`: each rater's own 2026 ratings page, by chamber. Type it like `RACE_RATING_SOURCES`, so the module still imports nothing. Its comment says it's the attribution link and not `source_url`, and that no code fetches these pages, since they're links a reader clicks.
  - **Cook:** `https://www.cookpolitical.com/ratings/house-race-ratings` and `https://www.cookpolitical.com/ratings/senate-race-ratings` (`docs/handoffs/71-race-ratings-cook.md:95-96`).
  - **Sabato:** `https://centerforpolitics.org/crystalball/2026-house/` and `https://centerforpolitics.org/crystalball/2026-senate/` (`docs/handoffs/88-race-ratings-pipeline.md:14-15`).
  - **Inside Elections:** `https://insideelections.com/ratings/house/` and `https://insideelections.com/ratings/senate/` (the Senate page's canonical URL, which I read 2026-10-11).
- **`RatingChip`** takes `chamber`, and `RaceHeader` passes `race.chamber`. When `rating.cycle` is 2026, the label is an `<a>` to the rater's page for that chamber, with `target="_blank"` and `rel="noopener noreferrer"`, titled with `RACE_RATING_SOURCES`' full name. Any other cycle keeps today's `<span>`.
- **The chip's title** keeps *Updated <date>*, and adds *, read from Ballotpedia* when `sourceUrl`'s host is `ballotpedia.org`.
- **`RaceOpenRow`'s three rater tiles:** the label's text sits in the same kind of anchor, inside the same `.rl-tl` span, to the 2026 page for `row.chamber`, titled with the full name.
- **The look doesn't change.** One class in `app/globals.css` (`.rater-link`, say) gives the anchor `color: inherit` and no underline, and underlines it on `:hover` and `:focus-visible`. The chip's anchor keeps the span's class and inline color. Nothing else moves, so `narrow-preview` should match `ca11c35`'s run cell for cell.

### § 2, leg A's script (`diag`)

`scripts/diagnostic/rater-links-775.ts <base URL>`. It reads only our own pages and never follows a rater link.
- **The races:** by SELECT, one 2026 House race and one 2026 Senate race that carry all three raters' rows and that `/electoral`'s default list shows. Name them.
- **`/race/<id>`, from the HTML:** the header holds three rater anchors, each with its chamber's page as `href`, `target="_blank"`, `rel="noopener noreferrer"` and the text `Cook`, `Sabato` and `Inside Elections`. Each chip's title ends *, read from Ballotpedia*.
- **`/electoral`, in Playwright:** open each race's row (`#row-<id>`). The three tiles' anchors carry the same `href`s, `target` and `rel`, with the text `Cook`, `Sabato` and `Inside`.

## Legs

**A, the links.**
- **The red:** the script against Production (`ca11c35`). There are no anchors, so every check fails.
- **The green:** the script against the review push's Preview, or against `next start` on the cold build if the Preview won't answer your box.
- **narrow-preview:** 82 of 82 cells equal `ca11c35`'s Preview run (#38170374526) in every field.

## Docs

**roadmap:** the HO 775 block. It opens with **HO 774's FF go as taken** (your paste):
- the FF and its build and gates;
- `verify:deploy`;
- the Production build's cache line;
- `e2e-prod` #38171809025, with `/search`'s line;
- no flush.

Then Corey's ruling with the About page's sentence, why the rater's page, STEP 0 and the reading, the build and leg A, and AL-01's reading if you took it.

**backlog:**
- **Moore's line,** struck on AL-01's reading if you took it, with the reading. Otherwise nothing changes.
- Reconcile, with the control at 0.

**SKILL**, in its own `docs(skill)` commit, last. After the paragraph at `:2581`, add a paragraph with a blank line before it, verbatim:

```text
**Each rater's name links to that rater's own ratings page for the race's chamber (HO 775).** `RACE_RATING_PAGES_2026` (`lib/enums.ts`) feeds the chips on `/race/[id]` and the three rater tiles in `/electoral`'s open row. That link is the attribution, and it never points at `source_url`, which says where we read the row: Ballotpedia's chamber page for every row written before HO 770, as the chip's title says. The label keeps its look and underlines on hover and focus. `SpreadBar` names the raters only in its `title`, and `RaceCard` is itself a link, so neither carries one. The Crystal Ball allows use with proper attribution (its About page). Another cycle's pages are another constant.
```

## Commits

On `775-review` from `main`, kinds unmixed:
- `feat` § 1;
- `diag` § 2;
- `docs`;
- `docs(skill)`, alone and last.

No migration, and no prod write. Build, then the cheap gates, before every push.

## Paste back once, after the Preview and `narrow-preview`

- `ls-remote` with `775-review`'s SHA;
- STEP 0, the reading, and AL-01's reading if taken;
- leg A's red and green;
- the Preview, and `narrow-preview` against #38170374526;
- `--stat` per commit, and `--numstat` for docs with every deletion explained;
- the SKILL diff;
- the reconcile;
- a last cheap-gate run.

Build through to the review push without stopping.
