# HO 703 — STEP 0 rulings (architect, 2026-09-08)

Arrived against the STEP 0 progress paste ("row 4 still in flight"). By the time
it landed, Code had already completed row 4, STEP 1, STEP 2 and pushed
`703-review` at `33412e0`. **The rulings therefore supersede parts of what was
built, and row 2 REVERSES a call Code made.** Saved per `docs/method.md` § Relay.
Verbatim.

---

Row 1: accepted, with the runner reading made a measurement rather than a proxy. The Preview job gets a pre-step before Playwright: `curl -fsS "$BASE_URL/api/version"` and require its `sha` to equal `github.event.deployment.sha`; anything else fails the job. What its zero means: an SSO wall, a 401, or a stale alias all hand the spec a page with no horizontal overflow, and `over=0` on the wrong page is green on nothing. Same class one level down, and a forced consequence rather than a widening: on a Preview the narrow spec runs with no smoke crawl beside it, and the auth vars are Production-scoped (the MissingSecret backlog entry), so a route that 500s on a Preview would also read `over=0`. The spec therefore asserts, per route, response status 200 and that `landed` is the route's own path or its documented redirect. Both controls stated in the job and spec headers with what their zero means.

Row 2: ruled. Key on `github.event.deployment.sha`, and the job summary names the SHA; that is the identifier the reviewer already holds from `ls-remote`, so nothing looks up a branch. But no job-level concurrency: `concurrency` at `:74–76` is workflow-level and governs the whole run, so a job-level group cannot protect the Preview job from a run-level cancel. Today a Preview-success deploy groups as `e2e-prod-deployment_status-Preview-success`, harmless while that class was fully skipped and HO 685's failure mode once it does work. The discriminator goes into the workflow key as a fourth component: `${{ github.event.deployment_status.environment == 'Preview' && github.event.deployment.sha || 'na' }}`. Production bursts still collapse ('na', the original purpose preserved); schedule and dispatch unchanged; Preview runs are per-SHA and never collapse, so `cancel-in-progress: true` stays and can only ever cancel a run of identical bytes, which the comment says. Update the `:34–67` comment and the echo at `:106–107` (the 685 rule: change both or neither; the echo verifies the expression and cannot catch a typo in the key). The behavioural half: the two Preview deploys STEP 1's falsification produces, planted then removed, must both run to completion if they overlap; if they don't overlap naturally, one trivial third push forces the overlap once. Quote all conclusions.

Rows 3 and 5: accepted; the malformed-value guard is the right shape.

Row 4: hold for the table; the HALT rule stands at more than three routes.

The three skipped-then-success runs from 704 today are `backlog:85`'s cleanest instance yet; the block cites them.

---

## What this changes, as executed

- **Row 2 REVERSES Code's shipped decision.** Code shipped *no job-level
  concurrency* and argued the HO 685 workflow-level key already both isolated
  Preview from Production and correctly collapsed a superseded Preview. The
  first half is right; **the second half is the defect** — that key makes two
  Preview runs of DIFFERENT SHAs share one group string, so they cancel each
  other, and a cancelled run files nothing and reads exactly like a quiet one.
  The fix is a **fourth component in the WORKFLOW-level key**, not a job-level
  group (which cannot protect against a run-level cancel at all).
- **Code's SKILL bullet, roadmap block and `backlog:85` strike all argue the
  overruled position** and are corrected in the amended commits.
- **Two new controls**, each with a stated zero: the `/api/version` SHA pre-step
  (job) and the per-route status-200 + landed-path assertion (spec).
- **Row 4 is answered:** 0 of 36 over at 390, under the HALT threshold.
