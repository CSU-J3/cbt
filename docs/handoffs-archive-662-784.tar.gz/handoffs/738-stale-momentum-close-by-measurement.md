# HO 738 — the stale momentum layer closes by measurement: the June mock was the ruling, HO 371 was the build, and only the record is missing

`docs/backlog.md:64` (*Stale momentum layer*, opened Jun 24, owner Corey/design) says the data is wired and *"what's missing is the row presentation … which needs a design pass."* Both halves of its own close criterion — *"an enriched-row design mock lands, turning this into a build handoff"* — happened in June and July and were never recorded against the line: `docs/design/stale-momentum-row.html` (mtime 2026-06-26, committed at HO 696 with the loose directory) drew the overlay and named a lean, and **HO 371 built that lean**. HO 696 annotated the line *"whether it is the ruled row presentation is unrecorded."* This HO records it. Docs and captures only; no code, no CSS, no query.

**The close, as filed:** the line struck on a reading of the live `/stale` row, the mock cited by explicit path with its `sha256`, form A named as what shipped with the HO 371 sites, and HO 618's later removal of the reserved slot carried as the one amendment since. **What it reads if the work never happened:** a design request open for three months against a page that has rendered the design for two of them, and a mock on disk that nothing says was ruled.

## Ground truth (read at `837c300`; re-derive every `:N` by content)

- **The line:** `docs/backlog.md:64` — the close criterion above; the HO 696 annotation; *"Back in the design chat's court."*
- **The mock:** `docs/design/stale-momentum-row.html`, `sha256 ac5062d54113a30ab03c3457c2c3e16e0661d969fc6c35bae0afd8894d92ddc7` at `837c300` (recompute and record; README rule 2). Its content: *MOMENTUM OVERLAY — annotates the stage-led sort, does not re-order it*; a cosponsor support figure (`+118`, *brighter = more backing*, `—` when not stored, a delta slot reserved for later); a **HEARD** badge (*got a committee hearing, then went silent · the hearing date shows in the expand*); collapsed rows on the June TOP STALLS chrome; an expanded HR 28 with the support bar living in the COSPONSORS row; and the fork **A · FIGURE — "my lean"** vs **B · FIGURE + BAR**, with *"either way the bar lives in one home, not both — in A it's reserved for the expand card."* Named outside the `mock-<HO>-<slug>` convention, so it is cited by **explicit path**, which the gate reads (README, *what it cannot see*).
- **The build, form A, all HO 371 by their own comments:**
  - `components/BillRow.tsx:44-55` `supportFigure` — banded on the live distribution (*n=515 non-null: p75=12, p90=32*), `high ≥ 30`, `mid ≥ 10`, `low`, `nul` renders `—` (not stored, not zero); `:145-148` the collapsed cluster before the age cell, `/stale`-only via `showMomentum`; `:258-275` the render: `.row-momentum` → `.row-support.{high|mid|low|nul}` and, **only when `bill.heard`**, `.row-hslot > .heard-badge`.
  - `components/BillRowList.tsx:43`, `:52-56`, `:90`, `:100` — `showMomentum` prop, default false, *"true only from the /stale page"*; `app/stale/page.tsx` passes it (confirm the line).
  - `lib/queries.ts:171-175` — `heard?: boolean`, *"HO 371: true when the bill has ≥1 committee_bills hearing row. Selected (via a correlated EXISTS) by `getStaleBills` ONLY"*; `cosponsor_count` via `SPONSOR_ENRICH_SELECT` (`:98`).
  - `components/BillExpandPanel.tsx:704-708` `cosponsorSegments` — *"HO 371: cosponsor support bar — 5 segments span 1–50 (segment width 10), the >50 tail caps at full. Mirrors the collapsed figure's magnitude read."*; `:284-286` the hearings block reads the HEARD story rather than *NO RELATED HEARINGS*; `:320` and `:722-730` the *"then silent"* line under a populated hearing block, `/stale` only.
  - `app/globals.css:2093-2110` `.feed-row .row-support` and its four bands; the `.heard-badge` / `.row-hslot` / `.row-momentum` rules (re-derive lines).
- **The one amendment since:** HO 618 (C4) removed the always-rendered 52px HEARD slot — *"a 52px RESERVED EMPTY box on 45 of /stale's 50 rows … opened a uniform 121px gap … Reserving it bought nothing"* (`BillRow.tsx:261-267`). The badge now renders only when it has content. The mock drew the slot reserved; the shipped form dropped the reservation on a measurement.
- **What the mock reserved and nothing built:** the cosponsor **delta** (`+118 ▲9`) — it needs cosponsor history, which no table stores; and SUPPORT as a `/stale` sub-sort, which the mock said would be the day form B earned its keep. Both are named in the strike as unbuilt by design, not as open loops — a new line opens only if Corey asks for them.
- **Roadmap:** there is no `Also (HO 371)` block to cite (confirm with `grep -n 'HO 371' docs/roadmap.md`); the HO 371 commits are the record — `git log --oneline --grep='HO 371'` on the full clone names them. Cite the `feat` by hash.
- Estimates: **~20 min** of Code time; captures **six**.

## STEP 0 — measure, then HALT

| # | check | expected | if the work never happened, this reads |
|---|---|---|---|
| 1 | remote / status / pointer / machine | `main` alone at `837c300`; clean; the number the tree gives (**738**, or the next if the horizon HO has landed — say which) | anything else stops here |
| 2 | OPEN LOOPS reconcile (HO 737 close read **251 / 282**) | as read | a carried count |
| 3 | quote `:64`'s close clause and the HO 696 annotation; `BillRow.tsx:44-55`, `:145-148`, `:258-275`; `BillRowList.tsx:52-56`; `queries.ts:171-175`; `BillExpandPanel.tsx:704-708`, `:320`, `:722-730`; the mock's fork captions verbatim | as in ground truth | a moved or struck line |
| 4 | `sha256sum docs/design/stale-momentum-row.html`; `git log --oneline --diff-filter=A -- docs/design/stale-momentum-row.html` (the committing HO); `git log --oneline --grep='HO 371'` | `ac5062d5…`; committed at the HO 696 commit; the HO 371 `feat` named by hash | a different sha means the file changed since `837c300` — say when |
| 5 | **exists before reads:** on the local production build of HEAD, `/stale` at 1440 — how many rows render, how many carry `.heard-badge`, and the four `.row-support` band classes present (count each) | ~50 rows, ~5 HEARD, all four bands represented (`nul` as `—`) | zero of any band or zero HEARD on a 50-row page is a data change since HO 371's *45 of 50* and is written, not smoothed |
| 6 | **reads:** one row of each band quoted (`+N` and its class), one HEARD row quoted; expand the HEARD row — the COSPONSORS bar segment count against `cosponsorSegments(count)`, and the *"then silent"* line's text | figure, class and bar agree with the count; the line reads *NO ACTION IN Nd* under a populated hearing block | disagreement between figure band and bar segments is a defect and files |
| 7 | the negative control: `/bills` at 1440 (same build) — `.row-momentum` count | **0** — the overlay is `/stale`-only by `showMomentum` | a nonzero here is a leak and files |
| 8 | captures into `docs/handoffs/738-artifacts/`: `/stale` collapsed at 1440 and 430 with a HEARD row in frame; the HEARD row expanded at 1440 showing the bar and the *then silent* line; `/bills` at 1440 as the control | six images, each waiting for `.row-support` (or its absence on `/bills`) and saying so | — |

**HALT with the eight rows.** The go arrives as a file.

## STEP 1 — `docs(HO 738)` only

- **`docs/backlog.md:64` struck** as *CLOSED HO 738 by measurement*: the mock cited by explicit path with its `sha256` and committing HO; **form A — "my lean" — is what shipped at HO 371** (the `feat` hash), with the four code sites; the bar lives in the expand card as the mock's A clause specified; HO 618 removed the reserved slot on its own measurement; the delta and the SUPPORT sub-sort named as reserved-and-unbuilt, opening no line; the row-5/6/7 readings as the after; **and the fact that the ruling was never recorded against this line until now — the artefact was the ruling, the build followed it, the ledger did not know.**
- **Roadmap:** one `Also (HO 738)` block, pointer 737 → 738, carrying the readings, the six captures by path, the `sha256`, and one paragraph naming the class: a line whose close criterion was met by a build in another HO and never struck — the third such this week (the `/members` overflow at HO 694 struck at 737; the `StagePillStrip` and news-cron comments' drift). Through the ref. **Oddities** only if something surprised. OPEN LOOPS reconciled (expected **250 / 283**).
- No SKILL: the `/stale` entry already describes the overlay as HO 371's (confirm by grep for `showMomentum` and `HEARD` in the entry; if the entry still calls the overlay pending, that sentence is a `docs(skill)` alone).

## Gates

`check:design-citations` (the strike and block cite the mock by explicit path — the gate must read it as resolved); numstat 1+/1− on `docs/backlog.md` with the one deletion explained; `ls-files --eol` on both docs; bind evidence for the local server; every DB command a `SELECT` (there should be none — the reads are of the served page). No build, no typecheck owed (no code), but say so rather than leave it unstated.

## Review ref, then FF

Review branch from the start; the block waits for the read. `HEAD:main` no force, `ls-remote`, delete the ref, `git rev-parse main`, `npm run verify:deploy`. The FF deploys a docs-only commit; name its Production sample and read it through the ledger as always.
