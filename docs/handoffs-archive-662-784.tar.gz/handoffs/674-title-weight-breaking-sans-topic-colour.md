# HO 674 — the feed title gains weight, the breaking headline gains the sans, and the topic codes get their colour back at 62%

**Read this file in full before executing anything. Execute in order. HALT conditions are hard stops — report and wait, do not improvise past them. FOUR HALTs: the STEP 0 closure table, an empty pre-render inside STEP 1, the LOOK-AND-RULE gate between the two chore commits, and the pre-land review ref. Nothing lands on `main` before the last is approved.**

Base: `main` at **`dc10f72`** or later — and in practice **behind HO 673** (the sponsor portrait), which should land first. Clone fresh; verify HEAD via `git ls-remote --heads origin` before starting.

**This handoff was first authored as 672 against `4ae76a8` and was wrong.** HO 670 (`4d34e5c`) and HO 671 (`dc10f72`) had already landed on a parallel track, and **HO 672 is in flight right now** (prod measurement of the flush guard, the `tsconfig` `include` exposure, the `method.md` gate entry — STEP 1 and STEP 2 both ruled). HO 673 is authored and pending. So this is **674**. Re-derive at your HEAD and say what you find; if 672 and 673 have both landed the derivation will agree with the number.

**Every line reference was re-derived at `dc10f72`.** HO 670 touched only `app/welcome/*`, `LandingCTAs.tsx` and `WelcomeClock.tsx`; HO 671 touched one cron route. Neither went near `app/globals.css`, `V2FeedList.tsx`, `TopicChips.tsx` or `BreakingRow.tsx`. **HO 673 does touch `app/globals.css`, in the `4092–4430` range only** — every line this HO works on sits *above* that, so 673 landing first shifts nothing here. Re-derive anyway (HO 652).

Environment: edit + `npm run build` then `npm run typecheck` (build first — the HO 665 stale-`.next/types` oddity), **three** local `npm run start` renders of `/` (baseline, post-A, post-B), the layout audit on `--route home` at 2560 **three times for the same reason**, the HO 627 click gate, and **the visual capture gate below**. **Bind check mandated on every start** (HO 664 → 665 procedure).

## The visual capture gate — mandatory, and it is new

HO 670 shipped **three render defects that passed every green gate**: a ~300px dead zone under each panel, an empty ODDS third, and the reduced-motion mask erasing the first row. Greps and 200s cannot see a layout. HO 672 is writing this into `docs/method.md`; this HO does not wait for it.

**A visual check with no capture is not a check.** Captures at **1440 and 2560**, plus a **separate `prefers-reduced-motion: reduce` capture** (a different layout, not a dimmer one), retained and referenced in the paste. This HO is entirely about how text looks; a green grep proves nothing here.

Two instrument rules from HO 671: **never `tail` a command whose failure mode is a stack trace**, and **a write instrument that does not read back is not an instrument.**

## The rulings this HO executes

Corey ruled in chat on **2026-08-18**, after looking at the live dashboard at ~2560 and testing a size bump by hand:

1. **The feed title does not stand out enough.** Ruled after the size hypothesis was tried and rejected by the owner — *"making it bigger really didn't help."*
2. **The breaking headlines read wrong** — reported as "it's like the glow", then as a font question.
3. **Topic codes get their colour back, matching BY TOPIC**, at **treatment B**: `color-mix(in srgb, {topicColor} 62%, var(--text-dim))`, not the raw bar hex. Ruled against `docs/design/mock-674-topic-colour.html`, which is committed at STEP 6 as its record. **Both surfaces** — the dashboard feed row and every `TopicChips` `plain` consumer.
4. **`--fs-14` is NOT to be touched** — a ruling, not an omission. See below.

## What this HO deliberately does not do, and why it is a decision

**The type ladder stays exactly as it is.** The size hypothesis was the obvious read and it is wrong twice over. `docs/backlog.md:285` (the deferred padding half of C2) carries a standing instruction in bold — the wide-width hierarchy compression is *"recorded in the `globals.css` ladder comment as bounded and real — do not re-file it as a bug."* And the ladder comment at `globals.css:130` argues the flat +1px step on precisely this property: 9px gains 33% by 2400 while 14px gains 21%, **"which is the right direction, because the small labels are the ones that are unreadable at 2560."** Steepening `--fs-14` would reverse an argued HO 604 decision, move 18 `globals.css` selectors plus ten `text-[length:var(--fs-14)]` TSX sites, and push on `/`'s hearings filter bar, which `:285` already records reflowing to a second row under the *current* ladder. **Weight is unruled ground and costs one declaration.** The ladder is not this HO's business and must not be edited even opportunistically.

## Context — the title has three de-emphasis levers stacked on it, from one HO, for the opposite complaint

`.v2f-title` (`globals.css:3912`) carries `font-weight: 400` **declared explicitly**, `color: var(--text-secondary)` **stepped down** from `--text-primary`, and `-webkit-font-smoothing: antialiased` — **the only occurrence of that property in the entire stylesheet**. All three are HO 642's, and its comment says why: it answered a complaint that titles read *too heavy* on Windows, where synthesized weight was the suspect. That fix was right for that complaint. What nobody revisited is that the title now has no emphasis channel left while everything beside it does — the id is `--accent-amber` at full saturation, the sponsor is a party colour, and after commit B the topic codes carry one too. Size is the title's only remaining channel and the ladder takes it away at wide widths by design.

**Plex Sans is loaded at 400/500/600** (`app/layout.tsx:26`, `weight: ["400","500","600"]`), so `font-weight: 500` on a `var(--sans)` element is a **real drawn face**. This is explicitly NOT the `roadmap.md:576` hazard — that is an unfamilied non-400 weight inheriting `--font-mono` and asking Consolas for a weight it does not ship, which the browser synthesizes into what reads as Comic Sans. `roadmap.md:576`'s own fix was `var(--sans)` at 500 for this exact reason. **Cite that entry; do not re-derive it.**

## The Plex Mono interaction — named because it could invalidate half of commit A

HO 670 filed a **`--font-mono` → Plex Mono swap** as a follow-on. It has not landed. If it lands *before* this HO, the mono stack changes face and the "breaking reads wrong" diagnosis partly moves — a real drawn Plex Mono is not JetBrains-or-Consolas-or-Menlo-by-fallback, and some of what reads as Comic Sans may be the current stack rather than monospace as such. **STEP 0 must check whether that swap has landed and say so.** If it has, capture breaking *before* deciding the sans carve-out is still the right fix, and be willing to report that half of commit A is no longer needed. That is a finding, not a failure.

## Recon at `dc10f72` (STEP 0 re-derives all of it)

- **`.v2f-title`** `globals.css:3912–3930`. The HO 642 comment at `:3916–3921` is **both RECORD (why 400 was chosen) and LIVE-CLAIM (it asserts "this was never bold")**. **Reconciled, not deleted** — the history is why the next reader will not undo this.
- **`.breaking-row-headline`** `globals.css:1014`: `--fs-14`, `--text-secondary`, **no `font-family`** → inherits `body`'s `--font-mono` (`:186–189`), **no `font-weight`** → 400, so nothing is being synthesized here. It is monospace prose at the same token size as a bill title. `components/BreakingRow.tsx:69` adds no weight class.
- **`.breaking-row-full`** `globals.css:1034` is the hover overrun overlay carrying the SAME text. Also `--fs-14`, also unfamilied → mono. **It must move with the headline or the hover shows one face over another.** They are one string rendered twice.
- **A pre-existing misalignment to MEASURE and FILE, not fix.** The overlay's `left: calc(5.8em + 10px)` resolves `em` against its own `--fs-14`, while the id column it aligns to (`.breaking-row-id`, `:1002`) is `flex: 0 0 5.8em` at **`--fs-13`**. Two `em` bases for the same 5.8 figure — at 2400 that is 5.8 × 17 = 98.6px against 5.8 × 16 = 92.8px. Confirm; if it holds it is a **QUEUED entry**, and it is **not** created by this HO.
- **The sans carve-out's recorded scope** is SKILL `:1863` — bill titles, the panel summary, the sponsor card's natural name, "for prose readability on the feed." Breaking headlines are the same kind of content and were never included. This HO extends it by one surface and **must edit that entry**.
- **Topic render, dashboard:** `components/V2FeedList.tsx:326` is ONE span joining every code with a space, inside `.v2f-topics-plain` (`globals.css:3871`), inheriting `.v2f-l2`'s `--text-dim`. `:48` imports **`topicLabel` only**; `topicColor` must be added.
- **Topic render, everywhere else:** `components/TopicChips.tsx:17` (`Chip`). Its `plain` branch passes `style={undefined}` and `.v2f-topic.v2f-topic--plain` (`globals.css:1958`) sets `color: inherit; border: 0`. **Both live consumers pass `plain`** — `BillRow.tsx:208` (which is `/bills`, `/watchlist`, `/changes`, `/stale`, `/members/[bioguideId]`) and `app/bill/[id]/page.tsx:464`. **Recommendation for the table to confirm: colour these too.** The same codes rendering coloured on `/` and dim on `/bills` is a divergence on identical content, and HO 632's metabox ruling went global on that reasoning.
- **The non-plain branch of `Chip` is ORPHANED** — colour + a 45%-alpha border, zero consumers. **FILE IT, DO NOT DELETE IT.** `docs/backlog.md:158` states the rule: dead-CSS removal is an orphan sweep and **orphan sweeps do not ride inside a behaviour commit**.
- **`TOPIC_COLORS`** `lib/topic-colors.ts:9` — the same map `TopicDistributionList` reads for the BY TOPIC bars, so chip and bar are one value by construction. `topicColor()` `:90` falls back to `other`.
- **M3 baseline is NOT inherited.** No figure for `/`'s layout-audit M3 is asserted here on purpose — the "M3" in recent roadmap blocks is the **race-detector** M3, a different instrument sharing a name, and confusing them is exactly the trap this note prevents. **STEP 1 measures it fresh.**

## STEP 0 — enumerate; closure table; HALT

Re-derive every line at your HEAD. **Controls first.** Bare-substring form. Table = candidate · verdict · evidence `file:line` · destination. Cover at least:

0. **The mock's arrival, verified before it is trusted.** `docs/design/mock-674-topic-colour.html` is delivered out of band and saved into the tree by Corey. Confirm **md5 `6a878a87862330b0d2402178ebf243b2`, 15290 bytes** before reading a value off it. A mismatch or an absence is a HALT, not a shrug. It is the record of the treatment-B ruling and the source of the 62% figure; **do not take that number from this handoff's prose if the file disagrees with it** — the mock is the ruling, this file is a description of it.
1. **`.v2f-title`'s three levers**, each with its current value and whether this HO moves it. Ruled: **weight 400 → 500 moves; colour and smoothing DO NOT move in commit A** — they are the next levers up, held back so STEP 3 can attribute the change to one variable. Say so in the table rather than leaving it implied.
2. **Every `--fs-14` consumer**, listed. Not because any moves — none do — but because the table is where "we chose not to" gets recorded against a hypothesis the owner tested by hand.
3. **`.breaking-row-headline` + `.breaking-row-full` as a PAIR.** Confirm both are unfamilied and both `--fs-14`. Changing one alone is a defect, not a partial fix.
4. **Has the `--font-mono` → Plex Mono swap landed?** Check `app/layout.tsx` and the `--font-mono` definition. Report yes/no and, if yes, what it means for commit A's second half.
5. **The 5.8em base mismatch** — measure at 2560, report both computed px values, verdict QUEUED.
6. **Topic-colour consumers.** `V2FeedList.tsx:326` and `TopicChips.tsx:17`. For each: what renders today, what renders after, and the **per-topic element count delta** — the M3 input, predicted before measured.
7. **The mix's home.** Ruled: the 62% ratio lives in **CSS, once**, not duplicated in TSX. TSX passes the raw colour as a custom property (`style={{ "--tc": topicColor(t) }}`); CSS computes `color: color-mix(in srgb, var(--tc) 62%, var(--text-dim))`. Confirm `--tc` collides with nothing.
8. **Border check.** After the change, `.v2f-topic--plain` must still compute `border-width: 0`. Colour goes on text and **nowhere near a border** — HO 609/614/618's rule is that a border survives only on an interactive affordance, and M3's predicate is width > 0.
9. **Orphan census, filed not swept:** `Chip`'s non-plain branch and its bordered `.v2f-topic` rules. Consumer counts with a positive control. Verdict FILE.
10. **SKILL fresh greps** — `sans carve`, `v2f-title`, `breaking-row`, `TopicChips`, `plain`, `topic colour`, `C3`. Classify LIVE-CLAIM vs RECORD. **`:1863` is an expected EDIT.** **The `:2085` changelog append is expected YES** — `V2FeedList` and `TopicChips` are client islands and what they render changes.
11. **Out of scope, named:** `--fs-9` … `--fs-14` and all three `@media` ladder blocks; `--text-primary` / `--text-secondary` token values; the smoothing declaration's location; `.hearing-title`'s unfamilied 500 (`globals.css:8158`); `--font-sans` vs `--sans`; `SponsorHoverName`; HO 673's territory (`BillExpandPanel`, `.v2f-sc-*`, `.bxp-sponsor*`); **and everything HO 672 is holding — `tsconfig.json`, `docs/method.md`, `app/api/cron/summarize/route.ts`.**

**HALT.** Paste the table. A reading that contradicts the recon changes that row's verdict. Do not force it.

## STEP 1 — baseline, BEFORE any edit

1. `npm run build`; `npm run start -p 31xx`, PID captured; **verify the started PID owns the port** before any curl is trusted.
2. `curl -s -H "Cookie: ct_seen=1" http://localhost:<port>/ > /tmp/t-base.html`; record HTTP code, byte count, and **the served stylesheet hash** — the freshness discriminator for STEPs 3 and 5 (HO 668's near-miss).
3. Discriminating counts: `grep -c 'v2f-topics-plain'` (expect >0) and `grep -c 'v2f-title'` (expect >0). **HALT if either reads 0.**
4. **Baseline captures:** 1440, 2560, 2560 under reduced motion. Include the BREAKING block and a scrolled feed in frame — these are the two surfaces being judged.
5. **Layout audit `--route home` at 2560. This reading is the baseline; nothing here may assert a prior M3 figure.** Record M1 / M1x / M2 / M3 / M4-true verbatim.
6. Click gate at both widths; record the pass line.
7. Kill by PID, port-scoped.

## STEP 2 — commit A, the type change

`git checkout -b 674-review-local` first. One commit, one kind:

`style(HO 674): the feed title carries weight, the breaking headline carries the sans`

`app/globals.css` only. `.v2f-title` gains `font-weight: 500` (400 → 500) with the HO 642 comment reconciled — keep its history, correct its claim, and state the loaded-Plex reasoning with the `roadmap.md:576` citation so the next reader does not undo this on the Comic Sans fear. `.breaking-row-headline` and `.breaking-row-full` **both** gain `font-family: var(--sans)`. Sizes, colours and the smoothing declaration untouched.

## STEP 3 — LOOK AND RULE. HALT.

Build, start (bind verified, stylesheet hash **differs** from STEP 1), render `/`. **Captures at all three states again**, framed identically to STEP 1's so they can be compared side by side rather than described. **Re-run the layout audit at 2560 and report the delta against STEP 1.** Then report, as measurements rather than impressions: the breaking headline's truncation point before and after (the sans has different advance widths, so the ellipsis moves and the overlay's overrun distance changes), and whether `.breaking-row-full` still aligns to the id column.

**Then stop and paste back for the owner's eye.** This is a perceptual ruling and there is no instrument for it — the whole reason the two commits are separated is so "did the weight fix it" has a one-variable answer. **Do not start commit B until Corey has looked.** If the weight is not enough, the next levers are identified and each is one declaration: step `.v2f-title` to `--text-primary` (reversing the other half of HO 642, whose own comment says contrast is the lever that moves), then drop the smoothing from that selector. **Those are a follow-up commit in this same HO if ruled, not a silent addition to commit A.**

## STEP 4 — commit B, the topic colour (only after STEP 3 is ruled)

`feat(HO 674): topic codes carry their topic colour at 62% toward the line`

`components/V2FeedList.tsx` — the joined string becomes one span per code, each with `style={{ "--tc": topicColor(t) }}`; `topicColor` added to the `:48` import. `components/TopicChips.tsx` — the `plain` branch passes the same custom property instead of `undefined`. `app/globals.css` — one rule computing the mix, and `.v2f-topic--plain` keeping `border: 0` with `color` now set rather than inherited.

**The ratio is 62% and it lives in exactly one CSS declaration.** If re-tuned later that must be a one-line edit, which is why it is not inlined per-topic in TSX.

## STEP 5 — gates

- `npm run build` then `npm run typecheck`, both green, build first.
- **Render gate with a real discriminator:** start (bind verified, stylesheet hash differs from STEP 3's), `curl` to `/tmp/t-post.html`, 200. Assert an inline `--tc` custom property is present on a topic code — **a class-name check would pass on a build that renders every code dim**, the exact failure mode this gate exists to catch.
- **Computed-colour check, not a source check.** In the browser, `getComputedStyle` on two codes of different topics: two different rgb values, neither equal to resolved `--text-dim`. Report both values.
- **Border check:** computed `border-width` on `.v2f-topic--plain` reads `0px`. Positive control: a known bordered element reads >0.
- **Captures, all three states, both surfaces**, retained.
- **Layout audit at 2560, third run.** M3 will move — the STEP 0 item 6 prediction is one own-style span per code where there was one inheriting span, so report **predicted vs measured** and reconcile any gap. **A moved M3 is a reported number, not a failure**; an unexplained one is a finding.
- **Click gate re-run whole** at both widths from a scrolled feed. Expected: unchanged — the codes are spans, not links, and no click target is added. A changed count is a HALT.
- Kill by PID, port-scoped.

## STEP 6 — docs commit (`docs: HO 674 — …`)

**`docs/backlog.md`** — three new QUEUED entries: (a) `Chip`'s orphaned non-plain branch and its bordered `.v2f-topic` rules, filed under the `:158` rule that orphan sweeps do not ride behaviour commits; (b) the `.breaking-row-full` 5.8em base mismatch with both measured px values; (c) `--font-sans` is Tailwind's default while the project's face lives on `--sans`, two tokens one hyphen apart, currently zero `font-sans` utility consumers — one line in the existing `@theme` block closes it and it can ride any future `globals.css` touch. **Do not delete any struck text.**

**`docs/design/mock-674-topic-colour.html`** — committed in this docs commit as the treatment-B ruling's record, unedited, at the md5 verified in item 0. It carries the alternative that was not taken (raw bar hex) alongside the ruled value, and the second-surface argument, so a future reader can see what was rejected rather than only what was chosen. Its own header prose notes that the nine topic labels are the confirmed set and the rest of `topicLabel()`'s vocabulary is not guessed at; leave that in.

**`docs/roadmap.md`** — one `Also (HO 674)` block, append-only, pointer to 674, recording: that the size hypothesis was **tested by the owner and rejected**, and that the ladder was left alone on `backlog.md:285`'s standing instruction plus the `globals.css:130` argument, so a future reader does not re-propose it; that the topic colour is a **reversal of C3 argued on the standing rule rather than an override of it** — the sponsor kept party colour through HO 609 because `V2FeedList.tsx:230` judged it the only thing carrying meaning, and topic colour passes the identical test since it is the same `topicColor()` value the BY TOPIC bar uses, one fact rendered twice (the HO 632 date-group precedent for how a reversal is recorded); the three audit readings with M3 predicted-vs-measured; the STEP 3 ruling in the owner's words; the Plex Mono finding from STEP 0 item 4; and **the renumber from 672 with its cause** — a stale clone against a parallel track already three HOs ahead.

**`docs/oddities.md`** — only if something odd emerged. Nothing odd → no entry, and say so in the roadmap block.

## STEP 7 — SKILL commit (`docs(skill): HO 674 — …`), self-mod guarded

Its own commit. **`:1863`'s sans carve-out gains the breaking headline** — the entry enumerates three surfaces and that list is now wrong. The `:2085` changelog append per the client-island criterion. Any LIVE-CLAIM the table caught describing topic codes as plain dim text. Nothing else.

## HALT — the review ref

`git push origin HEAD:refs/heads/674-review` (amend via `--force-with-lease` on the ref only; `main` only ever fast-forwards). Paste back: executed table deltas, `git show --stat` for every commit, all three audit readings side by side, both click-gate pass lines, the two computed topic colours, the truncation-point measurements, **every capture set**, the backlog numstat with each deletion explained, and the docs + SKILL diffs.

**Deliver the SKILL diff as a gitignored file AND tell Corey explicitly that he must attach it to the chat** — it has sat unread on the Windows box for two consecutive HOs, three rounds each. Writing the file is not delivering it.

Remote claims via `git ls-remote`, never `rev-parse origin/*`. **The SKILL diff needs explicit approval.** After approval: fast-forward `main`, delete the ref, verify with `git ls-remote --heads origin`.

## Verification gates

- STEP 5 all green; working tree clean after all commits.
- `git diff --numstat <docs-commit>~1 <docs-commit> -- docs/backlog.md` — insertions only expected; a deletion is a finding explained line by line. `grep -c '^-[^-]'` is NOT a deletion count (HO 643).
- Anchored: `grep -cE '^\*\*Also \(HO 674' docs/roadmap.md` = 1; `md5sum docs/design/mock-674-topic-colour.html` matches item 0; `git diff --stat` shows **zero** lines changed in the `--fs-` token block or the three `@media` ladder blocks.
- Push only after re-checking HEAD ancestry.

## Out of scope — named so it isn't absorbed

- **The type ladder, in every form.** `--fs-9`…`--fs-14`, the three `@media` blocks, the ~68 one-off sizes. The verification gate above proves the diff does not touch them.
- **`--text-primary` / `--text-secondary` token VALUES**, and the smoothing declaration's location. Candidate next levers named in STEP 3; neither moves without a ruling.
- **`.hearing-title`'s unfamilied `font-weight: 500`** (`globals.css:8158`) — the genuine `roadmap.md:576` synthesis shape, on the dashboard, shared by roughly forty selectors. Not this HO's kind; if the eye still catches Comic Sans after STEP 3, that is where to look and it wants its own sweep.
- **HO 673's territory** — `BillExpandPanel.tsx`, `.v2f-sc-*`, `.bxp-sponsor*`. If 673 has not landed, do not touch them; if it has, they are already settled.
- **Everything HO 672 is holding:** `tsconfig.json`, `docs/method.md`, `app/api/cron/summarize/route.ts`.
- **HO 670's filed follow-ons** — the `HeaderBar` `IN BETA` + clock, the `--font-mono` → Plex Mono swap (checked in STEP 0, never implemented here), the `/welcome` tape unification with `components/MarketsTape`.
- Deleting anything. Every orphan found here is FILED.
