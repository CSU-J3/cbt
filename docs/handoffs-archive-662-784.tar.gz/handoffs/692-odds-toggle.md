# HO 692 — ODDS ON / OFF: one reader preference, every prediction-market render site

Code kind. A reader can turn the prediction markets off, everywhere at once: the ODDS tape, the K/P line and diamonds on the race cards, the KALSHI lines on `/electoral`, the chamber-control cells, the ODDS block on the bill panel. **Ruled by Corey, 2026-09-03, verbatim:** *"yea that and everywhere else that those odds are being used, i.e. It needs to propagate throughout the application."* The control is `· ODDS ON` / `· ODDS OFF` on the masthead meta row of **both** headers, middot-joined after LOGIN (HO 610 packing; drawn in `mock-690-chrome.html` § 03).

**Mechanism, pinned architect-side:** this rides HO 690's `lib/prefs.ts` + pre-paint script with one new key, `odds` → localStorage `cbt:pref:odds`, html attribute `data-odds`, values `on | off`, default `on` (attribute absent). Every render site is gated by **CSS off that attribute** — a class on the element, one attribute rule — so there is no cookie, no `cookies()` read anywhere, no render-mode change on any route, no prop threaded through eight components, and no `router.refresh()`. The default browser reads byte-identically to today, which is also what the unattended crawl reads (it never sets the key), so the OFF path needs its own local captures and gets them below. **The data is still fetched** when hidden: the same posture as the tape hidden below 700px (SKILL, Mobile header — "purely visual"), and worth one sentence in SKILL so nobody later "optimises" the fetch away and breaks the ON path's freshness.

**The one place CSS cannot reach is market-derived TEXT**, and there are exactly two: the card's `leader` shape (`X† leads · Y` is a market claim) and its edge accent (the favoured line's party-coloured border). Both are handled without server knowledge: the accent moves to a CSS custom property so the attribute rule can blank it, and the `leader` line is **dual-rendered**, its `nolead` fallback in the markup behind an `odds-off-only` class. After HO 691 the `leader` shape fires only for a genuinely contested same-party field, so the fallback is rarely visible and always correct.

## Ground truth at authoring

- Clone at `930c37e` (HO 691 shipped 2026-09-04), pointer 691, number `max(691, 691) + 1 = 692`. Re-derive at session open. **Premise, verified at `930c37e`:** `lib/prefs.ts` exists with `PrefName = "weekSummary"` (`:34`), `PREFS` (`:51`), `writePref` (`:79`), `prefBootScript` (`:106`), and `app/layout.tsx:96` renders the boot script. Adding `odds` means widening the `PrefName` union as well as the table.
- **Render sites, enumerated from the tree (line numbers re-read at `930c37e`, after 690 and 691 both landed):**

| # | surface · file:line | what it is | hide by |
|---|---|---|---|
| 1 | `components/DashboardV2Header.tsx:167–177` (the `.dv2-tapes` block, now BELOW the nav since 690; `label="ODDS"` at `:175`) | the ODDS `<MarketsTape kind="signals" label="ODDS">` | wrap in `<div class="odds-only">`; MARKETS keeps its own border (`.dv2-tapes .markets-tape + .markets-tape` stops matching a visible pair — check the hairline) |
| 2 | `app/welcome/page.tsx:367` (the second `styles.taperow`; `ODDS_PAIRS` at `:68`, `oddsItems` at `:228`) | the landing's ODDS `taperow` | `odds-only` beside `styles.taperow`. Anonymous, pre-preference in practice, one attribute in cost; included so "everywhere" is literal |
| 3 | `components/RaceCard.tsx:80–133` (`KpLine`, root `.rc-kpline` at `:97`, css `:3919`) | the K/P favourite line, bottom-pinned | `odds-only`; the PAC glance line (`:494`) becomes the card footer, check its top spacing |
| 4 | `RaceCard.tsx:443–458` (`.sb-mkt-kals` `:443`, `.sb-mkt-poly` `:452`) | the `◇`/`◆` market diamonds on the spread bar | `odds-only` on both spans |
| 5 | `RaceCard.tsx:471–478` (`.rc-diverge` at `:473`) | `.rc-diverge` chip + its `<br />` | one `odds-only` span around both |
| 6 | `RaceCard.tsx:378–381, 408–411` (css `.rc-line--edge` `:3965`) | the market-favoured edge accent (inline `borderLeftColor`) | inline style sets `--rc-edge`; the class rule reads `border-left-color: var(--rc-edge, var(--border-strong))`; `html[data-odds="off"] .rc-line--edge { border-left-color: transparent }` — geometry untouched |
| 7 | `RaceCard.tsx:314–340` (`leader` branch; `.rc-dagger` at `:324`) | the `leader` shape: dagger + `leads · other` | dual render: existing markup `odds-only`; sibling `odds-off-only` carrying the `nolead` text for the same active set. **After 691 this branch fires only for a contested same-party field** (`general` at `lib/race-matchup.ts:219–235` takes every all-nominated seat); S-MI is `general` today and is NOT a test of this row — find a live `leader` seat or use the harness in `scripts/diagnostic/matchup-shapes-691.ts` |
| 8 | `components/CompetitiveRacesStrip.tsx:111` (css `.race-grid-foot` `:4040`) | `† presumptive …` footnote (absent on prod today — 691 — but the branch is live) | `odds-only` |
| 9 | `components/RacesHeroBand.tsx:52–67` (the two KALSHI cells at `:52` and `:61`; SEATS IN PLAY at `:69`; css `.races-hero-band` `:8053`, mobile block `:8126`) | the two KALSHI control cells | `odds-only` on both cells; `html[data-odds="off"] .races-hero-band { grid-template-columns: 1fr }` at both breakpoints so SEATS IN PLAY fills the band rather than sitting in one third of it |
| 10 | `components/RaceListView.tsx:184` (css `.race-list-diverge` `:5770`) | the `◆` divergence column | **`visibility: hidden`** via its own attribute rule, not `display:none` — the row grid has a fixed track and the column must keep its width |
| 11 | `RaceListView.tsx:324` | `· ◆ N markets disagree with raters` readout clause | one `odds-only` span around the separator and the clause |
| 12 | `components/race-cells.tsx:51–78` (`KalshiLine`; root class at `:68`; css `.racecard-kalshi` `:8140`) | the KALSHI line on `RaceMapCard:227`, `RaceDistrictCard:119`, `RaceListView:223` | `odds-only` on the root, three consumers covered at once |
| 13 | `components/RaceDistrictModal.tsx:38` | the export markdown's Kalshi line | skipped when `document.documentElement.dataset.odds === "off"` **at click time** (event handler, never render) |
| 14 | `components/BillExpandPanel.tsx:830–831` | the ODDS relblock (`NO PREDICTIONS MADE`) | `odds-only` on the block; seven routes covered by the shared panel |
| 15 | the tape hover box, the `SourceTag`s | inside sites 1/3 | nothing to do; confirm `grep -rn "<SourceTag" components app` returns only `KpLine` and `MarketsTapeClient` |

- **Two live facts carried from 691, neither self-clearing:** TX-23's PAC target is `unknown` because nothing in the repo scrapes a runoff round (3 runoff rows corpus-wide, all hand-seeded); and the `unknown` count is the 691 WATCH's signal (`npx tsx scripts/diagnostic/pac-target-status-691.ts` prints it). Not this HO's to fix; here so STEP 0 does not re-discover them.
- **Rider (one commit, its own `fix(HO 692)`), from 691's deploy finding:** the Data Cache survives deploys, so a `PacIeRow` cached by pre-691 code deserializes into the new type with `targetStatus === undefined`, which `CURRENT.has()` rejects — every target reads as past, the glance goes absent everywhere. 691 caught it only by flushing `races` after the deploy. Harden the reader: `isCurrent` (`components/PacSpendingLine.tsx:48`) treats a missing status as `unknown`, i.e. current, so a stale cache entry renders as the pre-691 line rather than as a wrongly-silenced one. One line, plus a sentence in SKILL's PAC section: *widening a cached row's shape needs either a post-deploy flush of its tag or a reader that defaults the new field.*
- **Not gated, deliberately:** rater pills, the spread bar's rater dots and band, the `Battlefield` axis (ratings, not markets), the MARKETS tape (indices, equities, FRED), the PAC line. If a reader sees any of these as "odds", that is a ruling for Corey, not a class to add.
- **Tests:** `e2e/smoke.spec.ts` / `fit-finish.spec.ts` locate `.markets-tape-item` and drive the tape hover; the crawl never sets localStorage, so the ON path is what CI measures. The doc-scroll invariant (1440/2560, both tab states) must hold in **both** states.

## STEP 0 — enumerate, then HALT

| # | candidate | expected |
|---|---|---|
| 1 | the premise | `lib/prefs.ts` at HEAD as anchored above; the layout script generated from its table; `data-week-summary` behaving on prod. Quote the table |
| 2 | the site table above, re-checked | every row's line numbers confirmed at HEAD (they were read at `930c37e`; flag any that moved); any site the grep finds that the table lacks (`grep -rni "kalshi\|polymarket\|SourceTag\|impliedPct\|favoriteLabel" components app --include=*.tsx`), each classified into the table or into "not gated" with a reason |
| 3 | per-site layout consequence | for each row: what the surrounding layout does when the element goes — measured by toggling the attribute in DevTools at 1440, one line each (the card footer, the hero band, the list row, the tape block) |
| 4 | specificity check | every gated element's own `display` rule and its specificity vs `html[data-odds="off"] .odds-only` (0,2,1); any inline `style={{display}}` or utility class that would win, named |
| 5 | the toggle's home | `DashboardV2Header.tsx:135–141` (the `.home-header-meta` `<p>` holding `AuthButton` at `:137`) and `HeaderBar.tsx:182–184` (`.header-titlebar-auth`); both middot-joined; the mobile (<700) masthead wrap checked |
| 6 | SKILL exposure | the Markets tape section (ODDS strip), the Race surface's HO 684 K/P clause, the `/electoral` hero-band sentence, the `/` entry, the bill-panel ODDS bullet, and the `lib/prefs.ts` sentence 690 wrote. Expected five one-sentence touches plus the fetched-while-hidden sentence |

**HALT.** Corey strikes or adds sites. The table is the substance.

## STEP 1 — build (one code commit)

- `lib/prefs.ts`: add the `odds` entry. The pre-paint script picks it up by construction (generated from the table); confirm the emitted script text carries both keys.
- `app/globals.css`, one block beside the 690 pref rules (`.week-sentences-row` at `:3069` is where they start): `.odds-off-only { display: none }` · `html[data-odds="off"] .odds-only { display: none }` · `html[data-odds="off"] .odds-off-only { display: inline }` · the three site-specific rules (rows 6, 9, 10).
- `components/OddsToggle.tsx` (client island): a `<button>` reading `· ODDS <span class="odds-only">ON</span><span class="odds-off-only">OFF</span>`, so the label is right at first paint with no state read at render; `aria-pressed` set post-mount via effect (the 690 aria rule); click → `writePref("odds", next)`. Styled as the masthead meta text (`--fs-11`, `--text-dim`, the state word `--text-muted` weight 600), hover amber like LOGIN. Mounted at both row-5 sites.
- Sites 1–14 as tabled. Row 7: `RaceCard` computes the `nolead` fallback text from the same `active` set `deriveMatchup` used (expose `active` on `Matchup`, or recompute via `activeChallengers`; do not duplicate the label logic — extract the `nolead` label into one function both branches call).
- **Grep before shipping** every new client island for a render-time `Date.now()` / `Math.random()` / `window.*` (SKILL, clock discipline). `OddsToggle` reads nothing at render.

`tsc` clean, build clean.

## STEP 2 — proof

1. **Both states, every surface, captures kept:** with the pref **unset** and with `cbt:pref:odds=off` (set via Playwright `addInitScript` before navigation, so it exists pre-paint exactly as a reader's would), at **1440 / 2560 / 430 + reduced-motion**: `/` (cards, footer geometry, tape block), `/electoral` MAP + pinned card, LIST + expand + readout, the district modal + its export text, `/bills` with a row expanded, `/race/S-MI-2026`, `/welcome`. The ON set must be **byte-identical to a pre-build capture of the same routes** (take those first, at HEAD before STEP 1); diff them.
2. **First-frame proof:** pref set, hard reload, screenshot at `domcontentloaded`: the ODDS tape and the K/P line absent in that frame. State the reading if the script were not wired: present. Control: unset → present.
3. **Toggle round trip on `/`:** click → attribute flips, every gated element gone with no navigation (assert the document did not reload: a marker set on `window` before the click survives it); click again → back; reload → state persisted.
4. **Doc-scroll invariant** in both states at 1440 and 2560, both tab states (`fit-finish.spec.ts` locally, plus a manual read of `scrollWidth/clientWidth` under `off`).
5. **Hydration:** the HO 590 harness on `/` and `/electoral`, both states; expected zero #418 in both.
6. **The crawl unchanged:** `npx playwright test e2e/smoke.spec.ts` against a local preview with no pref set: same pass set as before the build (the tape tests see the ON path).

## STEP 3 — SKILL (own commit, self-mod guard)

Row 6's touches, plus the standing sentence: *prediction-market renders are gated by `html[data-odds="off"]` via `.odds-only` / `.odds-off-only`; a new market render site takes the class; the data is fetched regardless; market-derived text that CSS cannot reshape is dual-rendered.* Diff gitignored, attach-to-chat instruction, approval before `main` moves.

## STEP 4 — docs (one commit)

Roadmap `Also (HO 692)` + pointer, carrying the ruling verbatim, the site count (gated vs deliberately not), the dual-render decision and why no cookie. Backlog: one **WATCH** — *a new market render site shipped without the class is invisible to every gate (the crawl runs ON); instrument = the row-2 grep re-run at each HO touching races or the tapes, zero meaning no ungated `kalshi|polymarket|SourceTag|impliedPct` site.* Oddities only if something surprises.

## STEP 5 — review ref, FF

`692-review`, ls-remote, architect review, SKILL slot, FF, ref deleted, `verify:deploy`, served SHA, and a prod capture of `/` in both states (BotID withholds the tape headless, so the OFF-state proof on prod is the K/P line and the diamonds; the tape half of the OFF proof is the local capture from STEP 2).

## Paste-back

STEP 0 table with rows 2–4 quoted (the HALT's substance). After STEP 2: the ON byte-diff result, the OFF capture set, the first-frame reading and control, the round-trip and hydration readings. SKILL diff attached. After FF: ls-remote, served SHA, prod captures.

read and follow 692
