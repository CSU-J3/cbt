# HO 772: FF go. The ref read clean, SKILL `8634758` approved. Three small fixes land first, one of them the gate the Preview walked past, then FF and read the deploy

## Rulings on the paste

I read `772-review` at `8634758`, all five commits:
- the script's three modes;
- the 26 files, `ibm-plex.css` (33 faces), `OFL.txt` (4,456 bytes, CRLF, sha256 `7e6b2818…07da`), `.gitattributes` and the layout;
- `FONT_STATE`'s two lines;
- the block, Delaware's line, the font-comments line and the oddity.

**SKILL `8634758`: approved.** I rebuilt it from `3785c41` with edits 1 and 2 and your ride-along, and compared. It's byte-identical. The ride-along stands: my claim 5 missed that `:1945` states the mechanism twice.

**B1's grep: yours stands.** My gate asked for a comment naming the module and a grep that finds no mention of it, so it couldn't pass. The import-shaped grep, with its red at `3785c41`, is the check, and B2 is the leg that discriminates.

**The departures stand:**
- the single-quoted fallback names, which the layout's comment now explains;
- `font-stretch: 100%` on Sans;
- `.gitattributes`;
- the `built` mode;
- reading the preloads off the `Link` header.

**cyrillic-ext:** C1's bytes and descriptors cover it. No seventh specimen.

**The scratch worktree** is yours: `git worktree remove --force` it.

## The gate the Preview walked past

Your reading was right that nothing in `app/page.tsx` or `auth.ts` checks the environment. The difference is in Auth.js, at the installed versions:
- `next-auth` 5.0.0-beta.31, `lib/index.js:45-48`: in a server component, `auth()` is `getSession(headers, config).then((r) => r.json())`.
- `@auth/core` 0.41.2, `lib/utils/assert.js:59-60`: no secret is `MissingSecret`.
- `index.js:72-88`: a configuration error on any action but the HTML pages answers `Response.json({ message: "There was a problem with the server configuration…" }, { status: 500 })`.
- `next-auth`'s `lib/env.js:22`: the secret is `AUTH_SECRET` or `NEXTAUTH_SECRET`.

So on a deployment without `AUTH_SECRET`, `auth()` resolves to `{ message }`. That's truthy, so `!session` at `app/page.tsx:86` is false, and the gate lets an anonymous visitor through. Every other caller tests `session?.user`:
- `components/HeaderBar.tsx:190` and `components/DashboardV2Header.tsx:154`;
- `app/watchlist/page.tsx:40` and `app/api/watchlist/route.ts:15`;
- `lib/queries.ts:8333`, `:8353` and `:8954`.

The gate at `:86` is the only one it fools. That the Preview has no `AUTH_SECRET` is my reading, not a measurement. Fix 1 makes the gate right either way, and its Preview is the reading.

## Three fixes on `772-review`, before the FF

**1. `fix(HO 772)`, the gate.** In `app/page.tsx`, verbatim:

```text
OLD:
  // renders the terminal directly.
  const [cookieStore, session] = await Promise.all([cookies(), auth()]);
  if (!cookieStore.get("ct_seen") && !session) {
NEW:
  // renders the terminal directly. A session is `session?.user` (HO 772): on a
  // configuration error, such as a missing AUTH_SECRET, auth() resolves to
  // Auth.js's error body, `{ message }`, which is truthy. Every other caller
  // already tests `session?.user`.
  const [cookieStore, session] = await Promise.all([cookies(), auth()]);
  if (!cookieStore.get("ct_seen") && !session?.user) {
```

Production doesn't change while it has `AUTH_SECRET`: an anonymous `auth()` is `null` there, and `!null?.user` is `true`, as `!null` was.

**2. `chore(HO 772)`, the two font comments** (backlog, *Two font comments describe plumbing that has moved*).

In `app/layout.tsx`, insert this paragraph and its trailing `//` line before *// THE CHAIN BREAKS ON WINDOWS, AND ONLY ON WINDOWS.*, verbatim:

```text
// HO 772: NextFontManifestPlugin above, and the Windows break below, are
// webpack's. CBT now builds with Turbopack, which doesn't run that plugin, and
// HO 772's local build on the Windows box preloaded all five latin files, in
// the Link header and as <link> elements
// (docs/handoffs/772-artifacts/dry/capture-local-dry.json). The two paragraphs
// below and their 2026-08-09 measurement stay as the webpack-era record.
//
```

In `app/globals.css`, verbatim:

```text
OLD:
     `var(--sans)` site moved together. Changing the face is one line here plus
     one import there — keep it that way. */
NEW:
     `var(--sans)` site moved together. Changing the face is one line here
     plus, since HO 772, the localFont call in app/layout.tsx and the files
     and faces in app/fonts/. Keep it that way. */
```

**3. `docs(HO 772)`:** strike the font-comments line, with a one-line close note naming fix 2's commit. Reconcile, with the control at 0.

Push all three, with no force. If fixes 1 and 2 are exactly these replacements, and 3 is the strike and the reconcile, they're approved as landed. Paste the diffs.

**Then read their Preview:**
- **The gate:** through a new share link, an anonymous `GET /` with no `ct_seen` and no session.
  - A 307 to `/welcome` confirms the reading.
  - The dashboard means the reading is wrong. The fix is right regardless, so the FF goes ahead, and the paste carries what the request carried and what came back.
  - If the tools reach the Preview's runtime log for that request, look for Auth.js's `[auth][error] MissingSecret`.
- **The cache line**, and **`narrow-preview`**.

## FF

`772-review`'s new head sits on `main` at `3785c41`, so this is a fast-forward of 8 commits. No migration.

Re-run the cheap gates immediately before the push, and name the reading. Then:
- `git push origin <772-review's head>:main`, no force;
- `git ls-remote --heads origin`;
- delete `772-review`;
- forward local `main` and delete the local review branch;
- paste `git rev-parse main`.

If the classifier blocks the push, Corey runs the same command from your checkout.

## The deploy

Run `npm run verify:deploy` **in the foreground**, then read:
- **The Production build's cache line.**
- **The CSS WATCH:** no *Restored build cache*, and the stylesheet `/` links carries *IBM Plex Sans Subsets*. That closes the WATCH.
- **The Production `e2e-prod`** and its smoke.
- **Leg C against Production,** with leg A's baseline as the base: C1 to C4, and the drop-Subsets control. Production now serves the fonts from the repo, and it should read like the baseline to the bit.
- **Production's anonymous `GET /`:** a 307 to `/welcome`, as before.

**The first daily ratings run** (2026-10-11 11:00Z): if the deploy's reading ends after it, read its `cron_runs` row and paste it. The next block records it in the ratings WATCH and Sabato's line. If not, it's read at the next session's open.

Paste once, after leg C.
