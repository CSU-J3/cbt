# HO 726 — FF go (architect, 2026-09-14). SKILL diff approved as pasted and as read off the ref; the readings carry the close; `HEAD:main`, then the two prod POSTs.

Read off `726-review` at `73dae1d`, `main` `0ede26a` its ancestor. The SKILL diff is the two ruled edits and nothing else: `:1710` and `:2168` each flip their *is NOT in* clause to *is in `ALLOWED_TAGS` since HO 726*, name the POST as the manual path, and leave every other clause in both paragraphs untouched (the `recordedVoteDocs` half, the degradation-guard half and the HO 714 tell all read byte-identical). **Approved alone.**

The readings are what the ruling asked for and they are read in the right order: the control GET at 0 rewrites before the POST, the POST's 200 with the debug line appearing at the Map's write, then the rewrite of an entry inside its TTL with its hash unchanged, and the `nonsense` 400 with the debug count flat at 2. `votes` rewriting 3 entries in 3.07s against its control's 0 in 0.05s is the pair doing its job. Every departure is accepted: naming both amendments-cron flushes in the comment is a correction to my text; `npm run sync:career-votes` is the script that exists; and declining the `:2168` ride-along for the House-links flush is right under the HO 657 ruling, since incomplete is not false.

## 1. One line to file before the FF, not a change to the code

`:2168`'s House-links omission is a true-but-incomplete sentence that two HOs have now read and left, which is how a sentence stays incomplete forever. Two other clauses are waiting on the same carrier from HO 724's FF: SKILL `:1813`'s *Re-running for the same week overwrites the prior row*, now true of nine columns and false of one, and `:1146`'s `payload.report.summary`, which is the handler's path and not the row's. All three are cheap, none is worth its own commit, and they currently live in three ruling files and this chat.

**Amend the tip `docs` commit (`73dae1d`) with one OPEN LOOPS line, owner Code, low:** *three SKILL sentences awaiting the next `docs(skill)` touch of their sections*: `:2168` (the amendments cron's House-links flush, `app/api/cron/amendments/route.ts:107`, missing from the automatic-paths list; HO 726), `:1813` (the reports-storage sentence, true of nine columns and false of `summary_text` since HO 724, whose exception sits two lines below it), and `:1146` (`payload.report.summary` is the handler payload; the `cron_runs` row nests it at `$.payload.report.summary`, HO 718's close-out read). Close: each lands on the next SKILL commit that touches its section, or is struck with a reason. Reads if never done: this line, and three sentences that are each individually too small to fix. Note in the same amend that this replaces the ruling-file-and-chat carriage HO 724's FF go named.

Then re-run `npm run build`, `npm run typecheck`, `npm run check:design-citations` at the new tip; the paste carries those readings, not `73dae1d`'s. `git push --force-with-lease origin HEAD:refs/heads/726-review`; `git ls-remote --heads origin` is the claim. Nothing else in the block or the tree moves.

## 2. Then the FF, and the prod half named for what it is

`git push origin HEAD:main`, no force; `git ls-remote --heads origin`; delete the ref; local `main` fast-forwarded and `git rev-parse main` pasted; `npm run verify:deploy` on five consecutive reads.

Then the two prod POSTs by env name (`$CRON_SECRET`, never a literal), expecting **200** each where they read 400 today, quoted as status and body only. The block already says that is an allowlist reading rather than a flush reading; the paste says it too, so the two do not drift.

And the Production `e2e-prod` run's id with its `pageErr=` readings, named as a `deployment_status` sample for the 09-17 ledger re-run. That re-run is the next thing on this project's calendar, with `S-DE-2026` closing tomorrow and the AK settle-window floors on the 18th.

Go.
