# HO 754: the meetings half. Read each chamber's whole list every tick and compare per event, so there is no watermark to pass anything, no page boundary to fall inside a tie, and a deleted event is marked rather than kept as scheduled

Three OPEN LOOPS lines, all measured by HO 752 (`scripts/diagnostic/committees-cursor-752.ts`, meetings mode):

- *The committees cron's bills cursor moves past a bill whose fetch or write failed…* (HO 744), its meetings half: the per-chamber watermark advances past a failed detail fetch and a null detail the same way the bills cursor did, and the Senate list carries 4 events whose stored row is older than the list's `updateDate`, a later update passed over. The bills half landed as HO 753.
- *The meetings list is walked by offset over an order that moves, so a tie at a page boundary repeats one event and skips another…* (HO 752), owner Code, medium.
- *19 stored `committee_meetings` rows are events Congress.gov has deleted, and the sync never deletes a row, so they stay `Scheduled`…* (HO 752), owner Code, low: 18 past, one future (event 338786, 2026-09-30), all 404 upstream.

The remedy is the bills remedy's twin: **the table is the state, not a watermark.** Each tick reads a chamber's whole list, deduplicated by event id, and refreshes exactly the events whose list `updateDate` is newer than the stored row's, or which have no row. A failed detail fetch leaves the row older, so it is retried next tick. A page boundary that shifts under the walk can only delay an event to the next tick, never lose it. A stored row the list no longer carries is marked absent, kept, and excluded from what renders. Whole lists are cheap here: 1,611 House and 1,128 Senate events at HO 752 is about 12 pages of 250 per tick.

## Ground truth (read at `0263059`; re-derive every `:N` by content)

- `lib/meetings-sync.ts`: `collectNewEvents` keeps `r.updateDate > watermark` and stops at the first event at or below it (`:97-127`), so an event whose update lands exactly on the watermark is never collected; the driver's `catch` counts, then `processed++` and `cursorEnd = item.updateDate` run either way (`:344-362`); a 200 with no `committeeMeeting` returns `null` (`:160`) and advances the cursor; `getJson` retries non-HTTP failures up to eight times (`:31-32`, `:52-66`); the watermark is `meeting_sync_state` (`:70-87`), shared with `scripts/sync-meetings.ts:20`; `upsertMeeting` stores the DETAIL's `updateDate` (`:275`) and is the only writer of `committee_meetings` (`:249`). The list is paged by offset over `updateDate DESC`.
- `app/api/cron/committees/route.ts`: meetings run after bills, from wherever the bills step stops to the 50s mark, with `perTickLimit: 300` (`:41`, `:86-89`). HO 752 read 29 of 43 success ticks hitting the bills deadline, so the meetings step often gets a few seconds.
- Schema (`scripts/migrate.ts`): `committee_meetings` `:715`, `meeting_sync_state` `:770`. `lib/cron-health.ts` registers `/api/cron/committees` (`:73`) and counts its routes in a comment that has drifted before.
- What renders: `getUpcomingMeetings` (`lib/queries.ts:9396`), `getRecentMeetings` (`:9430`), `getMeetingsByCommittee` (`:9453`), `getMeetingsForBill` (`:9479`) and `getWeeklyBandHearings` (`:7632`), consumed by `/hearings`, `/bill/[id]`, `/committee/[systemCode]`, `/members` and the welcome panels.
- The shim precedent for a detail failure is `scripts/diagnostic/senate-detail-fail-shim-746.cjs`; HO 753's shim serves recorded pages and fails on command.
- HO 752's evidence, on disk under `docs/handoffs/752-artifacts/`: the 4 older Senate events by id, the 19 deleted rows by id, the tied page boundaries it re-read, and 104 of 104 list-versus-detail `updateDate` agreements.

## STEP 0

1. HO number from the tree: `main` at `0263059`, pointer 753, so 754. Otherwise stop.
2. Re-read every cited `:N` by content. Flag a drift.
3. Carry HO 753's post-FF reading (the repair's run, the 752 instrument in both modes, the first two ticks' payloads) into this HO's roadmap block; if a tick reading isn't in yet, say where it's held.
4. Measure, prod, SELECTs and the two lists: rows per chamber; the 4 older and the 19 absent by id, re-derived; how many list events have no stored row today, and how many of those return a detail with no `committeeMeeting` (the null-detail class, which becomes this HO's give-up set); the number of list pages per chamber.
5. Proceed without a halt unless something above contradicts this file.

## The build

1. A route of its own: `/api/cron/committee-meetings`, `50 */12 * * *`, `maxDuration = 60`, a 50s budget, Bearer `CRON_SECRET`, `wrapCronRoute`, registered in `vercel.json` and `lib/cron-health.ts` (its count comment corrected). The committees route drops its meetings step and keeps its 45s bills budget as it is. `npm run sync:meetings` calls the same function.
2. The walk, per chamber: read the whole list in pages of 250 with an overlap of 25 and deduplicate by `eventId`. For each list event: no stored row, or a stored `update_date` older than the list's `updateDate`, fetch the detail and upsert; otherwise nothing. Order the refreshes oldest list `updateDate` first. Stop starting new events at the deadline; nothing else changes when it does.
3. Absent upstream: `committee_meetings` gains `absent_upstream_at TEXT`. A stored row the chamber's list no longer carries is stamped once, and a row that reappears is cleared. Nothing is deleted.
4. Failures: `committee_meeting_walk_state(event_id PRIMARY KEY, failures, last_attempt_at, last_error, gave_up_at_update TEXT)`. A failed detail, or a null detail, increments; success resets. At 5 the event is set aside and named in the payload's `gaveUp`, until its list `updateDate` moves past the one recorded at give-up.
5. `meeting_sync_state` is no longer read or written; it stays in place and is retired in SKILL.
6. What renders: every meeting query above gains `AND absent_upstream_at IS NULL`. The weekly band's count follows. No component or style changes.
7. The payload: pages read per chamber, list sizes, refreshed, unchanged, failed (ids, up to 20), `gaveUp`, absent stamped and cleared, and the stop reason.

## Legs, on a `file:` copy with a shim, through the real route wrappers, each red first

Seed the copy the HO 746 way (`committee_meetings`, `committee_meeting_bills`, `meeting_sync_state`, `cron_runs`, plus what the queries in item 6 join), URL built as `file:${abs}` by construction, perturbations refusing any other scheme. The shim serves recorded list pages and details and fails or reorders on command.

1. The whole list: 12 recorded pages read with the overlap, deduplicated; the shim moves one event across the page-1/page-2 boundary between the two reads. Red (today's `collectNewEvents`): the event is skipped or doubled. Green: it is refreshed exactly once, this tick or next.
2. Failure: the shim fails one event's detail. Red: the watermark passes it. Green: the row stays older, and the next tick refreshes it.
3. The 4 older Senate events, from their recorded list rows and details: refreshed on the first run.
4. Absent: the shim's list drops one stored event. Green: `absent_upstream_at` is stamped, the row is still there, and every query in item 6 stops returning it; the shim restores it and the stamp is cleared.
5. Give-up: an event whose detail is null five ticks running is named in `gaveUp` and skipped on the sixth; a list `updateDate` newer than the recorded one brings it back.
6. Deadline: the shim delays so the tick stops at 50s. Green: refreshed rows are complete, nothing else changed, and the `cron_runs` row is `success` with the stop reason.
7. The split: the committees route runs no meetings step; the new route runs nothing else; `lib/cron-health.ts` watches both.
8. The tie: HO 752's recorded tied boundary. Red: one event repeated and one skipped. Green: both stored once.

## Commits and docs

- `feat(HO 754)`: the route, the walk, the columns and state table, the query filters, the registrations, the CLI.
- `diag(HO 754)`: the legs driver and shim.
- `docs(skill)`, its own commit, approval requested: the new cron entry; the committees entry loses its meetings operation; `committee_meetings` gains `absent_upstream_at`, the state table is described, `meeting_sync_state` is retired; the meeting queries' absent filter.
- `docs(HO 754)`: strike the committees line (bills half on HO 753's prod reading, meetings half on this HO's legs, the prod reading owed in the FF go), the offset-paging line, and the 19-rows line (the decision: marked and hidden, never deleted); the page-1 line strikes on HO 753's prod reading if its 14 read 21 of 21; the roadmap block, pointer 753 → 754, carrying HO 753's readings. Reconcile OPEN LOOPS at open and close, control at 0.
- Review ref `754-review`. The FF is held for the SKILL approval and review.

## The prod reading (in the FF go, not here)

Migrate before the deploy. After the FF: one authorized POST of the new route, then the 752 instrument's meetings mode against prod (older 0, missing 0 with the null-detail set named, the 19 marked), then `/hearings` on Production without event 338786 and the weekly band's count beside its previous value, then the first two scheduled ticks' payloads.

## Gates

The cheap gates. No component or style changes, so no captures; the Production read of `/hearings` is the render reading.

## Paste back

- STEP 0's readings, including the null-detail count;
- the eight legs, red and green;
- the SKILL diff, for approval;
- `git show --stat` per commit, `--numstat` for the docs commits, the reconcile, the `754-review` SHA from `git ls-remote`, and a last cheap-gate run.
