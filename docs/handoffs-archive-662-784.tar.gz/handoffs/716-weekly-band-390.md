# HO 716 — the weekly band overflows 390 by three pixels in CI: a nowrap segment handed a wider string. Fix it so the next wider string cannot do it again.

Code kind, small, urgent: the deploy-blocking Production run on `main` (`e2e-prod.yml`, run `34660122285` on `489c414`) is red at 390 on `home`, the six `home-stage-*` variants and `dashboard-v2`, three attempts each, one offender every time: `a.weekly-band-id weekly-band-id--more right=393 w=15 ws=nowrap minw=auto` — `scroll=393/390 over=3`. 430 passed on the same run. HO 714's diff carries no `weekly-band` token, `components/WeeklyBand.tsx` last moved at `730fe99` (HO 690), and the served Absence Watch subtree is byte-identical across `9077492 → 489c414`; the offender is a member of the HO 682 latent register (`backlog:537`), a nowrap chip at `min-width: auto`, sound until the content beside it grows. This HO lands **before** HO 715 (docs-only, in flight), which rebases behind it.

## Ground truth at authoring (`main` at `489c414`, 2026-09-12; re-derive at STEP 0)

- **Number.** Pointer 714, highest HO in commit subjects 714; 715 is authored and in flight without a landed commit → this is 716 by the rule, and 715 keeps its number.
- **The markup.** `components/WeeklyBand.tsx:250-282`: inside one segment span, a `WeeklyBandMetricCard` (● *N* enacted ▲*d*) followed by `<span class="weekly-band-ids">` holding a `·`, the `enactedShown` `BillIdChip`s, and the `+{enactedMore}` `<Link class="weekly-band-id weekly-band-id--more">`. The number of chips and the `+N` string are **content**, set by the week's enacted bills.
- **The CSS.** `app/globals.css:3351` `.weekly-band { display: flex; flex-wrap: wrap; gap: var(--space-xs) 14px; font-size: var(--fs-11) }` — the outer band wraps its segments. `:3374` `.weekly-band-seg { white-space: nowrap }`. `:3394` `.weekly-band-ids { display: inline-flex; flex-wrap: wrap; gap: 0 var(--space-sm); margin-left: 4px }` — an inline-flex box whose chips can only wrap within the width the line gives it, and a nowrap ancestor gives it none. `:3401` `.weekly-band-id { white-space: nowrap }` (correct for a chip; a bill id must not break). `:3410` `.weekly-band-id--more`.
- **The mechanism, to be confirmed by measurement not asserted:** an inline-flex box inside a `white-space: nowrap` inline never gets a constrained available width, so its `flex-wrap: wrap` never fires; the whole segment runs as one unbreakable line and the last chip is the one that crosses the edge. Three pixels at IBM Plex Mono 11px on Ubuntu; clean on this Windows box, which is the HO 694 shape exactly (a width tuned to a font metric, green locally, red in CI, same SHA).
- **The flip.** HO 713's Production run at 23:06Z on `9077492` read `[narrow 390 home] scroll=390/390 over=0`; HO 714's at 00:03Z on `489c414` read `over=3`. The CSS is identical between the two SHAs at every `weekly-band` rule; the week's enacted set is not fixed at midnight UTC. The likeliest change is one more chip or a longer `+N`; STEP 0 reads it off the captured DOMs rather than reasoning about it.
- **The rule of record.** SKILL § narrow-viewport / HO 682: no `nowrap` at `min-width: auto` in a row that can grow; `min-width: 0` on the shrinking cell; the 430 (and 390) reading that counts is CI's. `e2e/narrow.spec.ts` names the offender and its box in the failure line, which is how this was found.

## STEP 0 — measure, then HALT (short)

| # | check | expected |
|---|---|---|
| 1 | the failed run's 24 offender lines, identical; the re-run of the failed jobs on `489c414` (queued at authoring): its verdict, pasted | red again → reproducible in CI; green → transient, and the fix still lands because a 3-px margin at CI metrics is not a margin |
| 2 | the weekly band subtree served at 23:06Z (HO 713 FF artifacts or the HO 714 STEP 2 capture) versus at 00:03Z (the HO 714 FF read) versus now: the `enactedShown` ids and the `+N` string in each | which string grew, quoted; if none did, say so and the mechanism sentence above is re-read |
| 3 | reproduce locally without CI's fonts: serve `/` at 390 with a **synthetic** enacted list one chip longer than today's (a fixture flag, never committed) and read `scrollWidth`; then two chips longer | the overflow appears at some length on this box too; that length is the control the fix must beat |
| 4 | `getComputedStyle` on the segment span, the ids box and the `+N` chip at 390 — `white-space`, `display`, `min-width`, the box widths — from the served page | the nowrap ancestor named by element |
| 5 | every other `.weekly-band-*` nowrap and every other `inline-flex` inside a nowrap ancestor in `globals.css` (`grep -n "nowrap" app/globals.css` within the band's block; `inline-flex` likewise) | the register of siblings, so the fix covers the pattern and not the instance |

**HALT** with rows 2–4 and the proposed rule, one paragraph. The fix's shape is pre-stated below; STEP 0 may replace it with a measured better one.

## The fix, pre-stated (overridable by the measurement)

- At **≤ 430** (the narrow breakpoint the gate reads; confirm the band's existing media query, if any, and reuse its edge), the enacted segment stops being one unbreakable line: `.weekly-band-seg { white-space: normal }` for the segment that carries `.weekly-band-ids`, with the metric card's own number/label spans keeping `nowrap` so "● 12 enacted ▲3" never breaks internally; and `.weekly-band-ids { display: flex; flex-basis: 100%; min-width: 0 }` so the chips take their own full-width wrapping row under the metric. Chips keep `nowrap` (a bill id does not break). **≥ 431 is byte-identical**: the rules live inside the media query and the desktop DOM does not change.
- If STEP 0 shows the outer `.weekly-band` already wraps the segment as a unit and the only defect is the ids box's available width, the smaller fix is preferred: `.weekly-band-ids { max-width: 100%; min-width: 0 }` plus `white-space: normal` on the carrying segment, at all widths, with the 1440 / 2560 captures proving nothing moved where it fits.
- Either way, the row's `min-width: 0` lands where HO 682 says it belongs, and the CSS comment names the run that found it.

## STEP 1 — build

- **Commit 1 — `fix(HO 716): the weekly band's id chips wrap at narrow widths instead of running off the edge`** — CSS only, additive under a media query or the two-rule form above; the comment cites `34660122285` and the HO 682 register line.
- **Commit 2 — `test(HO 716): a synthetic longer enacted list at 390 is the control`** — only if the fixture from row 3 can live as a committed test seam without touching the product path (a query param honoured only under `NODE_ENV !== "production"`, or a Playwright route interception that injects chips); if it cannot, the control lives in the STEP 2 scratch and the commit is skipped and said so.
- **`docs(skill)`** — the narrow-viewport section gains the instance and the rule's corollary: *an inline-flex inside a nowrap ancestor never wraps; the wrap has to be given a width to wrap in*. `docs`: `backlog:537` gains the entry as found-and-fixed; the roadmap block records the red run, the flip, the string that grew, the fix and the readings; oddities only if row 2 finds no grown string.

## STEP 2 — proof

- Build then typecheck; `check:design-citations`; `check:odds-sites` unchanged.
- **Local 390 and 430** on `home`, `dashboard-v2` and one `home-stage-*`: `scrollWidth === clientWidth`, named as predictions. **The control:** the synthetic list two chips longer than today's at 390 → `over=0` after the fix, `over>0` before it (both readings pasted; the before is what proves the control can fail).
- **Captures** at 1440 / 2560 / 430 / 390 of the band, before and after, plus reduced-motion; 1440 and 2560 diffed byte-for-byte if the media-query form is used.
- **DOM diff on `/` at 1440 against `489c414`: +0 / −0** — the fix is CSS.
- **The CI reading before FF:** the Preview `narrow-preview` run on the review ref at 390 and 430 on the eight routes that were red. This is the measurement; everything local is the prediction. If Preview is green and the re-run in row 1 was red, that is the strongest available evidence the fix reaches the environment that failed.

## STEP 3 onward

Review ref `716-review`; `git ls-remote --heads origin`; paste with the Preview reading; hold for the go. After FF, the Production run on the new `main` is the close: the eight routes green at 390, quoted.

## Paste-back

Rows 1–5 with the re-run verdict and the grown string; the control before/after; the captures and the 1440/2560 byte diffs; the `+0 / −0` DOM diff; per-commit `--stat`; the SKILL and docs diffs; the Preview `narrow-preview` lines for the eight routes; `git ls-remote --heads origin`.

read and follow 716
