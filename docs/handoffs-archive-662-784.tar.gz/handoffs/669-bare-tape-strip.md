# HO 669 — strip the bare `<MarketsTape />` branch + retire `lib/markets`'s `bareTape` tag (backlog `:422`, zero mounts since HO 608–610), carrying the HO 667 sync-WATCH read

**Read this file in full before executing anything. Execute in order. HALT conditions are hard stops — report and wait, do not improvise past them. Two HALTs: the STEP 0 closure table, and the pre-land review ref. Nothing lands on `main` before the second is approved. A third HALT sits inside STEP 1: an empty pre-render voids the gate.**

Base: `main` at `5549d94` or later. Clone fresh; verify HEAD before starting (concurrent-session rules per `docs/method.md` § Session start). Number derived per method: max(roadmap pointer 668, highest commit-subject HO 668) + 1. Environment: code edit + `npm run build` then `npm run typecheck` (build first — the HO 665 stale-`.next/types` oddity), plus **two** local `npm run start` renders of `/` (pre and post, for the roster gate), plus **one read-only `cron_runs` DB read** for the carried WATCH (`.env` `TURSO_DATABASE_URL`/`TURSO_AUTH_TOKEN` covers both). Either machine; no WSL/Docker. Bind check mandated on both starts (HO 664 → 665 procedure).

## The ruling this HO executes

Backlog `:422`'s close is two-branched: strip the branch behind its own gates, **or** record a keep reason so the branch stops reading as dead. Corey took the entry on **2026-08-17 for the STRIP branch** (the HO 667 form — a chat ruling recorded in the handoff that executes it). The keep branch is not the default, and the table may argue it only with evidence, not preference.

The strongest available evidence cuts toward the strip. The entry floats "the bare shape is wanted for a future non-dashboard mount" as the shape a keep reason would take — and the tree already answered it. **`/welcome` renders a non-dashboard tape and does not use this branch:** `app/welcome/page.tsx` carries its own `TAPE_SLOTS` (`:56–65`, eight hardcoded label→symbol pairs), its own `TapeItem` (`:103`) and its own `landing.module.css` `.tape`, imports nothing from `lib/markets`, and reads `getLatestMarketTicks` directly. The one surface that wanted a bare eight-symbol tape after HO 608–610 built its own rather than mounting this one.

## Context (why now)

The branch went unreachable at **HO 608–610**, when `HomeHeader` and `/dashboard-classic` were deleted — it was the bare tape's only mount. HO 665's prose sweep RECORD-phrased the SKILL claims above it (`:1999`/`:2002`/`:2006`) and measured the code underneath, which is where this entry came from: filed, deliberately not chased, because `MarketsTape` renders on `/` on every load and a shared component does not ride a prose sweep (HO 507). This is that HO.

Nothing here removes a per-render read and nothing here changes a pixel. The win is dead code and one retired data tag; say so plainly in the close note rather than dressing it up.

## Recon at `5549d94` (STEP 0 re-derives all of it)

- **Mount census.** Exactly two `<MarketsTape …>` render sites, both in `components/DashboardV2Header.tsx` (`:146` MARKETS, `:147–155` ODDS), both prop-driven with `symbols` (`MARKETS_TAPE` `:28–39`, eleven symbols; `ODDS_TAPE` `:46–55` + `ODDS_PAIRS` `:56–64`). `components/HomeHeader.tsx` is absent from the tree.
- **The dead path in `components/MarketsTape.tsx`** (106 lines): the `BARE_TAPE_EXCLUDED` comment + const `:20–31`; the ternary's third arm `:78–79`; the `placeholderSymbols` else-arm `:80–85`; and `symbols?: readonly string[]` `:50`, which becomes **required** once no arm survives without it. Neither live mount is affected — both already pass `symbols`.
- **The adjacent orphan, recommended into the same excision (the HO 664 §5 shape — presented, not assumed; the HALT rules).** `group?: MarketGroup` `:43` (destructured `:34`) has **zero callers**: no `<MarketsTape group=` anywhere in the tree. Its filter arm `:77` and its clause inside `:84` die by the same read as the bare arm. Taking it drops the entire `lib/markets` import at `:17` — `MARKET_SYMBOLS` is used **only** by the bare `placeholderSymbols` arm and `MarketGroup` **only** by that prop. Verify both before believing it. **The type survives and `lib/markets.ts`'s data field is untouched:** `MarketGroup` at `lib/markets.ts:86`, the `MarketSymbol.group` field at `:102`, and the tick row's `group` at `lib/queries.ts:48`/`:9290` are the data, not the prop.
- **`showMeta` — a finding, filed not chased.** Default `true` at `:35`, and neither live mount passes it, so `MarketsTapeClient`'s `showMeta === false` path is unreachable today. The client is the live island on `/` and runs past 1,000 lines; per HO 507 that is a **new QUEUED entry**, not this HO's edit. The prop and its default stay exactly as they are.
- **Header comment `:1–12` is a LIVE-CLAIM, not a RECORD.** It asserts that "both the dashboard (HomeHeader) and every inner page (HeaderBar) now mount a single no-group `<MarketsTape />`" and calls `group`/`showMeta` "retained for the grouped form but unused." The first half names two mounts that no longer exist; the second half is about to stop being true for `group`. Rewrite to record the strip. **Contrast `components/HeaderBar.tsx:157–165`, which already records the inner-page removal correctly** (HO 323/326, "The markets tape … were removed from inner pages") — that one is a RECORD and stays untouched.
- **`lib/markets.ts`, entry-owned scope.** `bareTape?: boolean` `:123` with its comment `:118–122`; **7** `bareTape: false` markers (`NVDA` `:137` · `AAPL` `:138` · `MSFT` `:139` · `GOOGL` `:140` · `LMT` `:141` · `FEDCUT-SEP` `:157` · `RECESSION` `:165` — re-derive the count, don't inherit it); three comment sites that explain the tag (`:133–136`, `:153–156`, `:159–164`) and two that explain the source-based half of the same exclusion (`:74–76`, `:167–170`). **`BARE_TAPE_EXCLUDED` is the field's only reader** — prove it with a control before deleting the field.
- **The scope exception, stated so it isn't mistaken for drift.** `lib/markets.ts` is a shared config module the sync pipeline reads, and HO 664–666's "shared file untouched" rule would keep it out. The entry names `bareTape` for reconcile-or-keep in its own close text, which is the **HO 667 `getDashboardLead` precedent**: an entry that owns a symbol inside a shared file may touch that symbol and nothing else. Touch `bareTape` and its comments; touch nothing else in that file.
- **CSS: expected zero.** Every `markets-tape*` selector is rendered by `MarketsTapeClient`, which this HO does not open. Verify, don't inherit — `app/globals.css` should not appear in `git show --stat` at all.
- **SKILL.** One LIVE-CLAIM: `:1997` — the HO 665 RECORD bullet ending "**the branch survives in code with zero mounts**", true today and false at the chore. `:1994` ("renders on **ONE** surface") stays true. `bareTape` / `BARE_TAPE_EXCLUDED` appear nowhere in SKILL (fresh grep). **No `:2087` append** — `MarketsTape.tsx` is a server component, `MarketsTapeClient` is the island and is untouched, so client-island membership does not change. That is HO 665's criterion applied, and it cuts the same way here as it did there (HO 666 was the inverse case; cite the pair).
- **Instruments that survive and must not be widened into:** `scripts/diagnostic/skill-phantoms-651.ts:332` carries `MarketsTape` in its `must` array — the **file** survives this HO, so the probe is unaffected; `e2e/fit-finish.spec.ts:201–247` exercises the tape hover on `/` locally against `.markets-tape-item` / `.markets-tape-detail--portal` — the two live mounts are unchanged, so record it unaffected and **do not run e2e**.

## STEP 0 — enumerate; closure table; HALT

Line numbers are as of `5549d94` — re-derive every one at your HEAD (HO 652). **Controls first, before any zero is trusted** (HO 664–668: ten instrument failures, zero code failures). Bare-substring form for class and symbol names (the HO 664 correction, demonstrated at HO 668). Produce the closure table (candidate · verdict · evidence `file:line` · destination) covering at least:

1. **Mount census, control first.** Positive control: `MarketsTapeClient` must read its real import + render sites (`MarketsTape.tsx:14`/`:87`) before any zero is trusted. Then across `app/ components/ lib/ e2e/ scripts/`: `<MarketsTape` = 2 render sites, both named; `MarketsTape group=` = 0; `MarketsTape showMeta=` = 0; a bare `<MarketsTape />` with no props = 0. Confirm `components/HomeHeader.tsx` is absent (`ls components/*Header*`).
2. **The dead path in `MarketsTape.tsx`,** line by line: the const and its comment, the ternary's third arm, the `placeholderSymbols` else-arm, and `symbols?` → required. State what the required-prop change forces at each of the two call sites (expected: nothing — both already pass `symbols`).
3. **The `group` recommendation.** Per-symbol survivor check in the HO 665 form for `MARKET_SYMBOLS` and `MarketGroup`: name every surviving consumer `file:line`, and state explicitly that the `lib/markets.ts` / `lib/queries.ts` sites are the **data field**, not the prop. If either symbol has a surviving consumer inside `MarketsTape.tsx` that the recon missed, the import does not drop and the table says so.
4. **`bareTape` sole-reader proof.** Grep `bareTape` across `app/ components/ lib/ scripts/ e2e/` and classify every hit as reader / marker / comment. Control: a `MarketSymbol` field that IS read elsewhere (`cadence`, `source`, or `format` — name it and its reader) must return >0 on the same invocation. Enumerate the 7 markers by symbol. Verdict per comment site: EDIT to RECORD, or dies with the tag.
5. **`showMeta`.** Verify the client's `showMeta === false` path is unreachable from both live mounts. Verdict: **FILE as a new QUEUED entry**, not chase. The prop stays.
6. **Comment reconciles.** `MarketsTape.tsx:1–12` EDIT (LIVE-CLAIM). `HeaderBar.tsx:157–165` RECORD, untouched. `lib/markets.ts:74–76` and `:167–170` EDIT to RECORD (they describe a bare tape that no longer has a mount). Anything the fresh grep adds.
7. **CSS, per-selector, bare-substring, controls first.** Positive control: `markets-tape-symbol` and `markets-tape-item` must read >0 in TSX before any zero is trusted. Expected outcome: **no selector loses its last consumer**, so `app/globals.css` is untouched. A selector that does go dead is a table row and changes the commit's shape.
8. **SKILL fresh greps** — `MarketsTape`, `bareTape`, `BARE_TAPE`, `bare tape`, `DualMarketsTape`. Classify each LIVE-CLAIM vs RECORD/HISTORY. Expected: `:1997` the sole edit; `:1994` untouched; `DualMarketsTape` is a known phantom name from the HO 651 census and belongs to that entry, **not this one**.
9. **e2e / scripts** — record `fit-finish.spec.ts:201–247` and `skill-phantoms-651.ts:332` as unaffected, with the reason. No e2e run.
10. **The carried WATCH read (read-only; the HO 668 rider rule).** Read `cron_runs` for `/api/sync` ticks whose `started_at` is after the HO 667 deploy promoted (`52145c1` or later — confirm with `npm run verify:deploy`). Paste route · started_at · total_ms · the payload's `timings` keys, for every post-deploy tick found. **Judge against the HO 668 rider's measured baseline, not the entry's HO 139 headline:** pre-deploy ticks ran **#10014 4,612ms / lead 2,148 · #9957 5,706 / 1,703 · #9898 6,270 / 2,098 · #9841 7,327 / 2,357**, so the yardstick is **~1.7–2.4s off a ~4.6–7.3s run**, not ~25s. Close criterion: no `lead` key in `timings`, no `[sync] lead:` line, total consistent with that yardstick. **If no post-deploy tick has landed, say so and the WATCH stays open** — do not force a close, and do not trigger `/api/sync` to manufacture one (it writes to the live DB and calls Gemini).
11. **Out-of-scope, named so it isn't absorbed:** `/welcome`'s own tape (`TAPE_SLOTS` / `TapeItem` / `landing.module.css`); `MarketsTapeClient.tsx` entirely; every other `MARKET_SYMBOLS` field and the sync pipeline that reads them; `app/globals.css`.

**HALT.** Paste the table back. If anything reads other than expected — a third mount, a `group=` caller, a second `bareTape` reader, a live `showMeta={false}`, a selector going dead, a SKILL claim beyond `:1997` — that row's verdict changes and the table says so; do not force it. If the table finds a genuine keep reason for the branch, that is the entry's other close: argue it with evidence and do not strip.

## STEP 1 — the pre-render (BEFORE the edit)

The gate needs a pre-change `/` render from the same machine and DB, on the unmodified tree.

1. `npm run build`; `npm run start -p 31xx`, PID captured; **verify the started PID owns the port** (`lsof -i :<port>` or `ss -ltnp`) before any curl is trusted.
2. `curl -s -H "Cookie: ct_seen=1" http://localhost:<port>/ > /tmp/tape-pre.html`; record the HTTP code (200) and byte count. Capture the served stylesheet hash from the `<link … href="/_next/static/css/…css">` tag — it is the STEP 3 freshness discriminator (the HO 668 lesson: a failed kill let the pre-change server survive and nearly produced a pass measured against itself).
3. Extract the ordered symbol sequence:
   `grep -o 'markets-tape-symbol">[^<]*<' /tmp/tape-pre.html | sed 's/.*">//; s/<$//' > /tmp/tape-pre.txt`
   Record `wc -l`. Also record the two pinned strip labels (`markets-tape-label` → `MARKETS`, `ODDS`).
4. **HALT if `/tmp/tape-pre.txt` is empty, or if it does not contain the discriminating cohort below.** Two empty lists compare equal and prove nothing; a void gate must stop the HO, not pass it. A local `/` with no tape usually means the markets cron is stale or the DB read threw (the component swallows and renders the no-data branch) — report it and wait.
5. Kill by PID, port-scoped; foreign PIDs left alone.

**The discriminating cohort** — the names `BARE_TAPE_EXCLUDED` actually computed, which are what would move first if the strip hit a live arm: the 7 `bareTape: false` symbols (`NVDA` `AAPL` `MSFT` `GOOGL` `LMT` `FEDCUT-SEP` `RECESSION`) plus the 4 `POLY-*` halves (render-skipped inside their pairs, so they are present in the roster and not in the extracted spans — state which of the eleven you expect to see and why).

## STEP 2 — the chore commit (after the table is approved)

`git checkout -b 669-review-local` first (`main` stays at `origin/main` until approval). One commit, one kind:

`chore(HO 669): strip the bare MarketsTape branch and retire lib/markets' bareTape tag`

Expected shape: `components/MarketsTape.tsx` −~30 with its header rewritten to record the strip; `lib/markets.ts` −~10 (the field, its comment, the 7 markers) with the two bare-tape comments reconciled to RECORD; the `group` prop per the approved table. Two files. Nothing else rides.

## STEP 3 — gates

- `npm run build` then `npm run typecheck`, both green — build first per the stale-`.next/types` oddity; if typecheck went red before the build, re-run after and report both readings.
- **Source greps, controls first:** `BARE_TAPE_EXCLUDED` 0 across `app/ components/ lib/ scripts/ e2e/`; `bareTape` 0 live (RECORD comments reported as "0 live, N RECORD" — the HO 664/665 form, not gutted to satisfy a substring count); `MarketsTape group=` 0; control `markets-tape-symbol` >0 in TSX.
- **The CSS claim is a negative, so prove it as one:** `git show --stat` for the chore commit lists exactly the approved files and **does not list `app/globals.css`**. Built-CSS control: `markets-tape-symbol` and `markets-tape-item` still >0 in `.next/static/css/*.css`.
- **The per-symbol roster gate** (the entry's own close criterion):
  1. `npm run start -p 31xx` on the post-chore build, PID captured, **bind verified**.
  2. Confirm the served stylesheet hash **differs** from STEP 1's, or otherwise prove the response came from the new build. A matching hash means you are measuring the old server against itself — HALT.
  3. `curl -s -H "Cookie: ct_seen=1" http://localhost:<port>/ > /tmp/tape-post.html`; 200; extract to `/tmp/tape-post.txt` with the identical command; `cmp /tmp/tape-pre.txt /tmp/tape-post.txt`.
  4. **Identical → gate green.** State it for what it is: **this gate passes by construction.** Both live mounts pass `symbols`, which short-circuits at `symbolSet` before any arm this HO touches, so the strip *cannot* change the render. The gate is a proof that the right arm was cut, not a discovery about the tape. Paste the line counts, the `cmp` result, and the cohort check.
  5. **Not identical → HALT.** A difference means the strip reached a live arm. Do not reinterpret, do not re-run hoping for a different answer; `diff` the two lists and report. (Tick *values* are not in the extracted sequence, so a moving price cannot produce a diff here; a symbol appearing or disappearing between renders is itself the finding.)
  6. Kill by PID, port-scoped.

## STEP 4 — docs commit (`docs: HO 669 — …`)

4.1 **`docs/backlog.md`** —
- **`:422`** — strike, with the close note: STRIP ruled by Corey 2026-08-17; stripped at `<chore SHA>`; the mount census re-verified at `<HEAD>` with its positive control named; what went (`BARE_TAPE_EXCLUDED`, the ternary's third arm, the `placeholderSymbols` else-arm, `symbols` now required, the `group` prop per the table, the whole `lib/markets` import if it dropped); `bareTape` retired with the 7 markers named and the sole-reader proof cited; the two bare-tape comments reconciled rather than orphaned; **the entry's floated keep reason answered on the record** — `/welcome` already renders a non-dashboard tape from its own hardcoded `TAPE_SLOTS` and never used this branch; the roster gate stated exactly (identical, **pass-by-construction**, with the freshness discriminator that makes it mean something); **`app/globals.css` untouched** and why; **no per-render read removed** — the win is dead code and one retired data tag, say it.
- **New QUEUED entry** — `MarketsTapeClient`'s `showMeta === false` path is unreachable: neither live mount passes the prop and the default is `true`. **Found by this HO, not created by it** (the inverse of HO 664's `BillRowList` filing — say which, the distinction is the point). Filed, not chased, per HO 507: the client is the live island on `/`. Close: strip the branch behind its own gates on the two live tapes, or record a keep reason.
- **The HO 667 sync WATCH** — on the STEP 0 item 10 reading: strike with the tick's timestamp and its before/after totals judged against the ~2s rider yardstick, **or** append a one-line rider recording that no post-deploy tick had landed at `<HEAD>` and leaving it open. Do not strike on an absent observation.
- Strike = `~~…~~` + a one-line close note, per ledger convention. **Do not delete the lines.**

4.2 **`docs/roadmap.md`** — one `Also (HO 669)` block, append-only, pointer advanced to 669: the ruling and who made it, the strip's numbers, the `group` adjacent-orphan disposition, the `lib/markets.ts` scope exception and why it's principled (the entry owns the symbol — the HO 667 precedent), the pass-by-construction gate and its discriminator, the `showMeta` filing, the WATCH disposition, the `:2087` non-append with its criterion, and the oddities disposition. No retro-edits to prior blocks.

4.3 **`docs/oddities.md`** — only if something odd emerged. Nothing odd → no entry, and say so in the roadmap block (the HO 659/660 form).

## STEP 5 — SKILL commit (`docs(skill): HO 669 — …`), self-mod guarded

Its own commit, never riding another doc. **Minimal edits** per the approved table:
- `:1997` — the HO 665 RECORD bullet's closing clause ("the branch survives in code with zero mounts") gains the strip: branch stripped at HO 669, `MarketsTape` now takes `symbols` unconditionally.
- Nothing else. `:1994` stays; the `/` entry stays flagged stale-as-enumeration (HO 646).
- **No `:2087` changelog append** — no client-island membership change. Cite HO 665 (same ruling) and HO 666 (the inverse) so the criterion reads as applied, not as a habit.

## HALT — the review ref; nothing lands before approval

Push the branch: `git push origin HEAD:refs/heads/669-review` (amend via `--force-with-lease` on the ref only; `main` only ever fast-forwards). Paste back: the executed table deltas, `git show --stat` of all three commits, the STEP 3 outputs **including both bind checks, the stylesheet-hash discriminator, the two extracted symbol lists' counts and the `cmp` result**, the STEP 0 item 10 `cron_runs` read, the backlog numstat with every deletion explained, and the docs + SKILL diffs. Remote claims via `git ls-remote`, never `rev-parse origin/*` (SKILL § Review-ref route). One swallowed block → re-deliver as a gitignored file, never a second paste (method.md § Relay). **The SKILL diff needs explicit approval** — the self-mod guard is satisfied by the ref, not bypassed by it. After approval: fast-forward `main` (`git push origin HEAD:main`, no `--force`), delete the ref, verify with `git ls-remote --heads origin`.

## Verification gates (run before the HALT; outputs in the paste)

- STEP 3 all green; working tree clean after the three commits.
- **Backlog numstat:** `git diff --numstat <docs-commit>~1 <docs-commit> -- docs/backlog.md` — every deletion explained line-by-line (one or two in-place strikes plus one insertion expected; the struck text must survive inside `~~…~~`). `grep -c '^-[^-]'` is NOT a deletion count (HO 643).
- **Anchored greps** (HO 637 rule): `grep -cE '^\*\*Also \(HO 669' docs/roadmap.md` = 1; `grep -rn "BARE_TAPE_EXCLUDED" app components lib scripts e2e` = 0; `grep -c "bareTape" lib/markets.ts` = 0 live (RECORD reported as such); `grep -n "the bare \`<MarketsTape />\` branch has ZERO mounts" docs/backlog.md` shows the line struck, not gone.
- Push only after re-checking HEAD ancestry (`git ls-remote --heads origin`), per method.md § Session start.

## Out of scope — named so it isn't absorbed

- **`components/MarketsTapeClient.tsx` entirely** — the live island; the `showMeta` path is filed, not chased.
- **`app/welcome/page.tsx`** and its own tape — independent implementation, no `lib/markets` import, cited here as evidence and touched not at all.
- **`lib/markets.ts` beyond `bareTape`** — every other `MarketSymbol` field, `MARKET_SYMBOLS` itself, and the whole sync/fetch path that reads them.
- `app/globals.css` and every `markets-tape*` selector.
- The SKILL-drift cluster from the HO 649/650/651 probes, including `DualMarketsTape` as a named phantom — its own entries, its own HO.
- The P3 HEARINGS↔RACES height jump and the P2 `/changes` latency — their own numbers.
- The `isSettled` cluster (`:78`/`:85`/`:87`), which wants the **Aug 20** settle window first; the ~Sep 1 per-query ledger glance; the M3 re-arm (post-Sep-15).
- The `CRON_ROUTES` stale schedule string (rides the next `lib/cron-health.ts` touch, per its own entry).
- The method.md dual-write rule — still unruled, still not written here.
