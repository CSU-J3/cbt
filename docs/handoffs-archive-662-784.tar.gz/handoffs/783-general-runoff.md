# HO 783: the general runoff box. The reader stores a race's *General runoff election* box, and its mark decides the seat on every reader: Georgia's Dec 1, and Louisiana's Dec 12 if it's labelled so. With HOs 781 and 782's FF readings

**Corey chose this HO next** (2026-10-13, from four: *"Georgia runoff reading (Recommended)"*), pulled from the backlog.

**The line** is the backlog's *"A General runoff election box is read nowhere…"* (HO 780, `docs/backlog.md:18`, dated before Tuesday 2026-12-01). This HO builds it and closes it on the legs.

**Why now.** In Georgia, a general-election candidate without a majority meets the runner-up in a Dec 1 runoff (Georgia's election calendar, <https://georgia.gov/node/34081>). Ballotpedia then marks both advancers in the Nov 3 general box and posts the Dec 1 contest as a *General runoff election* box. The reader takes that label as its `runoff` kind and stores nothing, and so does the scrape, so the race reads *Runoff* past Dec 1, until the cycle ends.

**Scope, in:**
1. **§ 1,** the reader stores the general runoff box, after one prod write: the migration, before the review push.
2. **§ 2,** the runoff's mark on every reader that reads a result.
3. **HOs 781 and 782's FF go,** into this block.
4. **The docs:** the line struck on the legs, a new line for `seed:ratings`, and the WATCH's reads.

**Out:**
- a primary runoff, which HO 761 already reads into `runoffs`;
- every other OPEN LOOPS line;
- any prod write but the migration.

**How STEP 0 runs** (method.md, HO 768's rule): the claims are mine and are a check. The measurements are yours.

**Base:** `main` at `4d73ca7`, HOs 781 and 782's FF head. HO number: the pointer is 782 and the highest HO in commit subjects is 782, so this is 783.

## STEP 0

| # | Claim | Fails if |
|---|---|---|
| 1 | `main` is `4d73ca7`, its Production smoke passed (#38467503450), and both Cook files answer 404 on `main`. | any |
| 2 | `boxKind` gives a primary runoff and a general runoff the same `runoff` kind (`lib/general-ballot.ts:175`). `PageModel` keeps `general`, `primaries` and `outsideGeneral` (`:146`, `:313`), `pageResult` reads `model.general` only (`:563-565`), and `writeRace` writes `general_ballot` and `general_ballot_reads` only (`:689`, `:710`). | |
| 3 | The scrape drops a general runoff box (`lib/primary-candidates-scrape.ts:379-384`). | |
| 4 | `resultFromRows` reads two or more marks in the general box as a runoff (`lib/race-result.ts:98` on). `raceResultView`'s runoff label names a date only from the jungle row (`:186`), and `decidedOn` is the jungle's runoff date only (`:130`, `:188-189`). | |
| 5 | Each reader of a result reads `general_ballot`'s marks only: `getRaceRoster` (`lib/queries.ts:2078-2091`), `getElectionResults` (`:2147-2164`), the qualifier's outcome (`lib/incumbent-qualifier.ts:144-148`), and `readRaceResults` (`lib/electoral-general.ts:634-672`), which hands its rows to `resultFromRows`. | another reader of marks |
| 6 | Georgia's general runoff is Tuesday 2026-12-01, 28 days after Nov 3 (the calendar above). | |

**Measure, in HO 747's saved pages:**
- every `<h5>` that says *runoff* and not *primary*: its label, its page, and whether it sits in or outside the 2026 section;
- whether such a box, or the section around it, prints its date.

## § 1: the reader (`feat`, after the migration)

**The table:** a new `general_runoff`, one row per person in a race's 2026 general runoff box: race, person key, name, party, bioguide by identity (as `general_ballot` takes it), `marked`, `on_ballot`, box prefix, read time, keyed on race and person. It goes in `scripts/migrate.ts`. **Run the migration on prod before the review push** (method.md, HO 754's rule): pages read the table, and the Preview reads prod.

**The read:** a box in the 2026 section whose `<h5>` says *general* and *runoff* and not *primary* is the race's general runoff box.
- Exactly one is stored on every READ, replaced per race in the same batch as the general box, whatever the general box's status, so a Louisiana seat with `no_box` keeps its runoff rows.
- Two or more store nothing, and the run's payload names the race.

## § 2: the readers (`feat`)

**A race with general runoff rows:**
- **one marked printed row decides it.** The header reads *Decided · Dec 1, 2026*, that row reads *Elected*, the incumbent's qualifier reads *re-elected* or *defeated* by their own runoff row, and the band counts the seat;
- **no mark keeps the runoff:** *Runoff Dec 1*, the general box's two marks still the advancers.

**The runoff's date:**
- Georgia's is 28 days after election day;
- Louisiana's is its jungle row's `runoff_date`, as HO 780 reads it;
- if STEP 0 finds the box printing its own date, prefer the box's.

A Georgia race whose general box reads two marks, with no runoff box yet, reads *Runoff Dec 1* rather than *Runoff*.

**The tag (HO 779):** a `senate` or `moved` tag whose race is decided in its runoff turns to ELECTED or LOST by their runoff row.

**Where it lives:** `resultFromRows` takes the runoff rows, so the race page and `/electoral` follow. `getRaceRoster`, `getElectionResults` and the qualifier's outcome take the same rule. Every other race reads as today.

## The legs (`diag`)

Seed a fresh copy of prod by `SELECT` the way HO 781's legs did, migrated by the real `scripts/migrate.ts`, and run each build's server per copy with `CBT_CLOCK_NOW`.

**Leg 0, the reader:** splice a general runoff box into two saved pages' 2026 sections. Use a real box's HTML if STEP 0 finds one, else the general box's own with its `<h5>` changed:
- S-GA, with the general box's two advancers marked and one runoff row marked: the run stores two runoff rows, one marked, and S-GA's general rows are unchanged;
- LA-01, with no general box: the read stays `no_box`, and the runoff rows are stored.

**Leg 1, Nov 5, the runoff pending** (S-GA's general box with two marks, no runoff rows):
- HEAD red: *Runoff*;
- the tree green: *Runoff Dec 1*;
- GA-10's tag reads IN THE SENATE RUNOFF on both.

**Leg 2, Dec 2, the runoff decided** (S-GA's runoff rows, one marked):
- HEAD red: *Runoff*, no *Elected*, GA-10's tag IN THE SENATE RUNOFF, `/electoral`'s chip RUNOFF, and the band leaving the seat open;
- the tree green: *Decided · Dec 1, 2026*, *Elected* on the marked row, GA-10's tag ELECTED TO THE SENATE or LOST THE SENATE RACE by the planted mark, the chip calling the seat, and the band counting it.

**Leg 3, Dec 13, Louisiana labelled *runoff*** (an LA seat with `no_box`, two jungle winners and runoff rows with one marked):
- HEAD red: *Runoff Dec 12*;
- the tree green: *Decided · Dec 12, 2026*, with *Elected* on the marked row.

**Leg 4, the control:** every other race page's `<main>` byte-identical to HEAD's at the Dec 2 clock, with no news ages set aside. Both builds carry HO 781's clock, so this is the news-ages line's *Close* read in practice.

**Captures,** retained: S-GA at Nov 5 and at Dec 2, at 1440 and 430, and a reduced-motion pass at 1440.

## Docs

**roadmap:** the HO 783 block. It opens with **HOs 781 and 782's FF go as taken** (your paste), then STEP 0, the migration, § 1, § 2 and the legs.

**backlog:**
- **The general-runoff line:** struck on the legs.
- **A new line, `seed:ratings`** (HO 782's note 5):
  - what: `npm run seed:ratings` upserts `data/race-ratings-*.json` into `race_ratings`. Run against a live database, it would write the January to May snapshots over the synced rows. The script's header (`:3-4`) and SKILL's `seed:ratings` bullet (`:1356`) still describe a quarterly refresh;
  - *Owner:* Code, low;
  - *Close:* the script refuses a database whose `race_ratings` isn't empty, and the two descriptions say first fill only;
  - *Reads if never done:* one run of a stale command undoes the sync.
- **The WATCH (HO 758) line:** its reads gain Georgia's: any race whose general box reads two marks on Nov 4 should read *Runoff Dec 1*.
- Reconcile, with the control at 0.

## SKILL (`docs(skill)`, alone and last)

Rewrite to the tree every SKILL sentence the build makes false, and name each in the paste. Add the general runoff where SKILL describes the reader's box kinds and the race page's result.

## Commits

On `783-review` from `main`, kinds unmixed:
- `feat`, the migration and § 1;
- `feat`, § 2;
- `diag`, the legs;
- `docs`;
- `docs(skill)`, alone and last.

The prod migration runs before the push. Build, then the cheap gates, before every push.

## Paste back once, after the Preview and `narrow-preview`

- `ls-remote` with `783-review`'s SHA;
- STEP 0, with the measurements;
- the prod migration: its command, its output, and `general_runoff`'s schema read back on prod;
- legs 0 to 4, red and green, and the captures;
- the Preview, and `narrow-preview` against #38465735737;
- `--stat` per commit, `--numstat` for docs with every deletion explained, and the SKILL diff;
- the reconcile;
- a last cheap-gate run.

Build through to the review push without stopping. A failed claim HALTs; nothing else does.
