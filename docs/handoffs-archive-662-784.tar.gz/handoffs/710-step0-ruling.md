# HO 710 — STEP 0 ruling (architect, 2026-09-10). Three defects, three dispositions; one amendment of my own; the HALT clears on Corey's word for rows 1, 2 and 8.

The table is good work. Rows 1, 3, 4, 5, 6, 7, 8 and 11 read as expected or better; row 2 read the thing the handoff was wrong about, and rows 4 and 10 caught two things I had not. Every re-derived anchor at `fdce76b` is accepted, including the two cosmetic drifts (`:2265`, and five queries in the `Promise.all` with `getChamberControl()` at `:29`). 708 and 709 having landed, the number is plain arithmetic and the "rebase behind 708" clause is moot; the block says pointer 709 → 710 and nothing about the reserved-number deviation, which never had to be exercised.

## 1. D1 — the rationale flips, the conclusion stands, and the mechanism is filed

Accepted in full. The handoff's sentence, *a races-first list would silently drop FL and OH*, was a mechanism named from memory and stated as fact; the estimate beside it (`~32`) was marked and STEP 0 replaced it, which is what the marking is for, but the reason was not marked and was wrong. Record it in the roadmap block as the architect's error, one sentence, with the reading that overturned it: **38 rows at cycle 2028, six with no Class 3 member behind them, two of them carrying men who left for the executive branch.**

The SKILL clause STEP 3 lands is rewritten to the true reason: **members-first because the Class 3 seat set is a fact of law (34), while `races` at a cycle is whatever `backfill:races` has minted and never retracted** — 38 today, six wrong, so a races-first list would render phantoms, not drop rows. The oddities note flips the same way: *a members-first list where a races-first one would have rendered six seats no Class 3 member holds, two for members no longer in the Senate*, plus the second clause as written (the option text named an instance the calendar had already resolved).

**New OPEN LOOP (STEP 4), owner Code, its own handoff:** `backfill:races` is `INSERT … ON CONFLICT DO UPDATE incumbent_bioguide_id`; it mints at whatever `next_election_year` a member carries on the day and never retracts a row when the year moves (HO 411's derive-from-class fix moved eighteen years and left the rows behind; HO 412 deleted the two 2026 phantoms it could see and no others). **Measured 2026-09-10: cycle 2028, 6 of 38 rows have no Class 3 sitting member (`S-FL`, `S-OH` on departed incumbents; `S-MN`, `S-MS`, `S-NE`, `S-NJ` on other classes); cycle 2030, 3 of 36 (`S-AK`, `S-OR`, `S-SC`).** Close criterion: a query joining each `S-*` row at cycle *c* to its incumbent and testing `is_current = 1 AND senate_class = senateClassForCycle(c)` reads **0 violations at 2028 and 2030**; it reads 6 and 3 today, so the instrument can fail. The retraction pass follows HO 412's shape (enumerate dependents first, delete with them, then prove `backfill:races` cannot recreate the rows). Not this HO: `getSeatOutlook` reads only `open_signal*` and `incumbent_running` off the derived-cycle row, never its incumbent, and the four other-class states cannot appear because no Class 3 member maps to them.

## 2. D2 — the at-large six come in, as `{ST}-AL`, with `raceId` null

Ruled, and it is not a fork: a 2028 seat list that omits Alaska, Delaware, North Dakota, South Dakota, Vermont and Wyoming is not a defensible product, so the only question was sequencing, and extending the race-id format now would reach the backfill SQL, the ratings seeds, the Kalshi ticker parse and the 2024-margin harvest. That is its own STEP 0. Overridable in a word.

- **Predicate:** drop `district IS NOT NULL`; keep the territorial carve. House rows are every sitting voting member.
- **Label:** `{ST}-AL` when `district IS NULL` (Cook and Ballotpedia's notation); `raceId` null; the `r` join simply finds nothing.
- **Disclosure, because two zeros must not render alike.** For an at-large seat, no tag means *no race record exists, so nothing could be recorded*, which is not the same fact as *no statement on file*. The footnote states it when at-large rows are present: *At-large seats (AK, DE, ND, SD, VT, WY) have no race record yet, so a tag cannot attach to them until the id gap closes.* It renders only when such rows exist, so the 2026 side and today's 2028 side are untouched. Dated by construction (it names a gap, and the gap has a backlog line).
- **Fixture:** a fifth row (`district: null`, `raceId: null`, `status: "none"`) proves the label and the no-tag branch at 1440.
- **Criterion rewrite, backlog (a):** *one row per sitting voting House member, at-large included, equal to the Clerk's sitting count on the date read — never a literal 435 (eight vacancies today).* Reads 0 today because no House member carries `next_election_year = 2028`; the zero is dated in the line.
- **New OPEN LOOP:** extend `raceIdFromMember` and the backfill to at-large seats so the six can carry `incumbent_running` and a rating row. Close: `S-…` unchanged, `{ST}-AL-{YYYY}` rows exist for the six with the sitting incumbent, and `getRacesIndex` renders a rated at-large seat; today the six have no race row anywhere, which the standing SKILL gap already says.
- **Copy:** the 2028 description reads *all House seats once the 120th Congress is seated*, not a number.

## 3. D3 — eight SKILL hits, all owed

- `:295` — the `CREATE TABLE races` block in the schema section gains the three columns with one-line semantics each. A schema listing that omits two of its `ensureColumn` additions is stale the day it ships.
- `:1213` and the Race IDs paragraph — *update both* → *update all three*, naming `getSeatOutlook`. **`lib/race-id.ts:6-8` is code and rides commit 2**, not the SKILL commit; same wording, so the three sites say the same thing.
- `:320` — one contrasting clause: the roster `status` field is written as given; `open_signal` is validated (`indicated` | `clear`, ISO date, `https://`) and an invalid entry is skipped with a count. Two rules, stated as two.
- `:1217`, `:1834`, `:1840`, `:2265` as the handoff had them.

Numstat on SKILL: deletions are the amended sentences only; quote each beside its replacement.

## 4. Amendment of my own — TBD outranks OPEN

The handoff pre-stated OPEN ▸ TBD ▸ LIKELY. Reversed: **TBD ▸ OPEN ▸ LIKELY ▸ none.** OPEN and LIKELY are facts about the current holder; TBD is a fact about the seat, that its 2028 holder is decided by a 2026 contest. If Moody announced tomorrow that she will not seek the seat in 2028, `OPEN` on the FL row would be true in the branch where she wins the special and false in the branch where she loses it, because the winner would be the 2028 incumbent and may run. A holder-level fact is subordinate to a seat whose holder is undecided. Zero live instances of the collision; the precedence is recorded with this reason in the SKILL sub-section and nothing else changes.

## 5. What Corey confirms

Rows 1, 2 and 8, in a word, here in chat. Row 2's confirmation is of the reading (38, six phantoms) and of proceeding members-first; the reason has already been corrected above. The word travels into the relay as a verbatim quotation with its provenance (SKILL, Owner verdicts). Nothing in STEP 1 starts before it arrives.

## 6. Then

STEP 1 as written, with: the predicate and label from § 2; the fixture's fifth row; commit 2 carrying the `lib/race-id.ts` comment; commit 3 carrying the footnote branch and the copy change; STEP 3 with the eight touches and the § 1 clause; STEP 4 with the two new OPEN LOOPS (§ 1, § 2) beside the four the handoff named, and the § 4 precedence in the SKILL text. OPEN LOOPS at open: **29 live / 41 struck**, reconciled again at close. Expected population at ship unchanged: OPEN 0 · LIKELY 1 · TBD 2 · 31 untagged · House 0.

read and follow 710-step0-ruling — the file, not this line
