# HO 727 — SKILL approved, one addendum before the FF

**I read the SKILL diff off the review ref rather than waiting for the attach.** `e2090d2` is on `727-review` at `8f0613b`, which is the review-ref route working as designed — no paste needed for anything already pushed. Use that for text delivery from here; the gitignored-file-plus-flag path is only for what never reaches a ref.

## SKILL diff: approved

`:1847`, 1+/1−. *three columns* → *two columns*, plus the clause naming the removed third and its flourish, HO 727, the architect's instruction, and the mock left intact as the ruling record. Accurate against the tree at `8f0613b`, verified independently rather than taken from your paste:

- `git grep -c flourish 8f0613b -- app/` → **0**; the glyph sweep over `app/` → **0**.
- `git diff --stat 72af9a5 8f0613b -- docs/design/` → **empty**. The mock is byte-identical.
- Base grid reads two tracks with `.stats` at 1/3, buttons at 1 and 2, microcopy at 1 and 2; the 1460 block is gone; the 560 block runs rows 2–5 with `.stats` taking row 1 from the base, exactly as ruled.
- CSS 17+/34−, page.tsx 0+/9−, 51 lines touched. Every deletion in your list matches the diff.

The `.ctagrid` comment's replacement — *"Two columns, one per button: HO 727 removed a third that held only the decorative line beside ENTER TERMINAL"* — is better than what STEP 1 asked for. It says why two, cites the HO, and clears the zero-tokens close without the comment going vague. Your catch on your own first draft is the flag-don't-absorb rule applied to yourself.

Your 25px correction stands and mine was wrong: bottom-aligned right column at 1440 means the slack opens above `.stats`, not below the block. Good that the roadmap carries the corrected form rather than my sentence.

## One addendum before the FF, then go

**The removal silently made two standing claims true that were false at `main`.** The flourish carried the module's only non-token `font-family` — `'Segoe UI Symbol','Apple Symbols','Noto Sans Symbols 2',serif` at `:126`. Readings:

- `72af9a5`: **7** `font-family` declarations in `landing.module.css`, **1 off-token**.
- `8f0613b`: **6**, **0 off-token**.

So the module's own header comment (*"Every font-family below is var(--font-mono) or var(--sans)"*) and SKILL `:1847`'s *"The type is token-consuming: `var(--font-mono)` / `var(--sans)` throughout"* were both **false at `main` and are true as of this commit**, by side effect rather than by intent.

**The finding is not the fix, it is the dead control.** `docs/backlog.md:180` records, at `4ae76a8`: *"all 10 of its `font-family` declarations were already on-token … with a control grep for a non-token declaration returning zero lines."* That control returned zero when it was run and would have returned **one** at `72af9a5` — the fallback stack arrived with the HO 697–699 font work, after the control, and nobody re-ran it. A control run once and never again is the same class as a gate that cannot fail: it certified a property that later went false with nothing watching. That is an **oddities** entry, not a backlog line, because there is nothing left to close.

**Land it by amending `8f0613b`** (`docs(HO 727)`, kind unchanged, no new commit), `--force-with-lease` on `727-review` only. The entry carries: the 7→6 and 1→0 readings with `:126` cited, both sentences named as false-at-`main`-true-now, `backlog:180`'s control quoted with the date it was taken, and the generalisation stated once. Add one clause to the roadmap block noting the same, so a reader of the block is not surprised by the oddities entry. `check:design-citations` re-runs on the push; build and typecheck need no re-run for a docs-only amend, and say so rather than claiming a run you did not make.

**Then fast-forward.** `HEAD:main` no force, `ls-remote`, delete the ref, local `main` forwarded with `git rev-parse main` pasted, `verify:deploy` on the tip, and the Production `e2e-prod` run read after — it structurally cannot run on the ref, so that reading always comes last. Your local narrow green at 430/390 is a prediction of CI's result and stays named as one until the Production run reports.

Approved. Go.
