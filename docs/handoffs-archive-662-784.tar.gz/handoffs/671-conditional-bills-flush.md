# HO 671 — make the `bills` flush conditional on a write: the `*/10` summarize tick, and `/api/sync` decided with it

**Read this file in full before executing anything. Execute in order. HALT conditions are hard stops — report and wait, do not improvise past them. Three HALTs: the STEP 0 closure table, the STEP 3 guard measurement, and the pre-land review ref. Nothing lands on `main` before the last is approved.**

Base: `main` at `4d34e5c` (HO 670 landed) or later. Clone fresh; verify HEAD before starting (`docs/method.md` § Session start). Number derived per method: max(roadmap pointer 670, highest commit-subject HO 670) + 1. Environment: code edit + `npm run build` then `npm run typecheck` (build first — the HO 665 stale-`.next/types` oddity), plus a local `npm run start` with **read-only** DB access for the tick-and-visit measurement. Either machine; no WSL/Docker. **Bind check mandated on every start** (HO 664 → 665 procedure).

## What HO 670 found, and why this is its own HO

`app/api/cron/summarize/route.ts:88` calls `revalidateTag("bills")` immediately after `runSummarize`, outside any condition, on a `*/10` schedule. HO 670 measured what that costs and how often it is pointless:

- **37 cache entries in `lib/queries.ts` carry the `bills` tag** — 27 tagged `["bills"]` alone, 10 in combination with `news-breaking` / `members` / `votes` / `committees`. The flush is site-wide, not per-route.
- **300 consecutive ticks, 2026-08-16T13:40Z → 2026-08-18T15:30Z:** 300 reached the flush, **4** summarized at least one bill, **296 (98.7%) summarized zero and flushed anyway**, 0 skipped on the lock, 0 unreadable payloads.
- That ratio is **HO 406 working, not failing** — the queue is drained, inflow is ~30 bills/day, a tick clears 100–120, so nearly every tick correctly finds nothing to do. The waste is the unconditional flush, not the schedule.
- **First visit after a `bills` flush costs ~89,090 `rows_read` on `/welcome`** (matching the sum of its eight bills-tagged entries, 88,987, to within 103 rows — that match is what identifies the mechanism rather than merely observing a number). A warm visit costs 0. `force-dynamic` disables the full-route cache, not the Data Cache.
- Cadence is **~148 flushes/day**: 144 from summarize (`*/10`) + 4 from `/api/sync` (`0 */6`).

The lever is the flush cadence, not any query or any page. HO 670 could not take it — a cron route is not `/welcome`, and a change that alters invalidation for 37 cache entries across every route needs its own gates. That is this HO.

**The fix is one line and the precedent is already in the file:** `stats.ok` is in scope at the call site, and the lock-overlap path already returns before the flush. A do-nothing tick not flushing is existing behaviour for one case, not a new principle.

## Scope

In scope: `app/api/cron/summarize/route.ts`, and `app/api/sync/route.ts` **only if** STEP 0 rules its flush the same question (see below). Nothing else.

**Out, and named so it is not absorbed:**

- `lib/queries.ts` — no tag is added, removed or renamed. This HO changes *when* a flush fires, never *what* it invalidates.
- `lib/summarize.ts` / `runSummarize` internals — the guard reads what the run already reports; it does not change what the run does.
- `vercel.json` schedules — the cadence stays; only the condition changes.
- Every consumer route, including `/welcome`. The relief is measured there because HO 670 priced it there, not because the page is touched.
- The three other HO 670 follow-ons (`HeaderBar` `IN BETA` + clock, `--font-mono` → Plex Mono, the method.md visual gate) — filed, none due here.

## The `/api/sync` question, ruled at STEP 0 not assumed

`/api/sync` fires `revalidateTag("bills")` unconditionally too, and `runSync` reports `upserted` / `seen`. Superficially it is the same defect at 4×/day instead of 144. **It is not obviously the same case**, and STEP 0 decides it on evidence:

- A sync tick that upserts nothing may still have changed something the bills tag governs — stage recomputation, a status flip, a backfill pass, a partial-failure path that wrote before it failed. Enumerate what `runSync` can write, and whether every write path is visible in what it returns.
- **If any write path is invisible in the return value, `/api/sync` keeps its unconditional flush** and the entry records why: 4 flushes/day is cheap insurance against a stale surface, where 144 is not.
- If every write path is reflected, guard it the same way.

Either verdict is acceptable. An unexamined "same fix, both files" is not.

## STEP 0 — enumerate; closure table; HALT

Line numbers below are as of the base SHA — re-derive at your HEAD (HO 652). **Controls first, before any zero is trusted** (the HO 664–670 rule: 13 instrument failures, 0 code failures, and then three render defects that passed every green gate). Closure table (candidate · verdict · evidence `file:line` · destination) covering at least:

1. **The call site.** `summarize/route.ts:88` re-derived. What is in scope at that point: the exact shape `runSummarize` returns, which field means "wrote", and whether it can be truthy while nothing was written (or falsy while something was). Read the function, do not infer from the payload logged in `cron_runs`.
2. **The lock-overlap precedent.** The early return that already skips the flush — quote it. Confirm it returns *before* `revalidateTag`, so the guard extends existing behaviour rather than inventing it.
3. **The 37 tagged entries, re-counted at HEAD.** 27 `["bills"]` + 10 in combination. Report the count with a control: name one entry that is NOT bills-tagged and show the grep excluding it. If the count moved since HO 670, say what changed.
4. **What else calls `revalidateTag("bills")`.** Full-tree grep, `app/ lib/ scripts/`. HO 670 named two call sites; confirm there are exactly two and no third path (a helper, a script, a webhook) fires it.
5. **`runSync`'s write paths** — the `/api/sync` ruling above, with the enumeration that produces it.
6. **The idle-tick evidence, re-measured at HEAD.** HO 670 read 300 ticks from `cron_runs`. Re-run over the current window and report the ratio. **The HO 669 envelope trap applies:** print the raw row (`{ok, elapsedMs, payload:{summarized,…}}`), and the control is that `wrote` reads non-zero — if every tick reads zero, the field is being misread, not the queue being empty.
7. **Staleness exposure.** With the guard in place, what is the longest a bills-tagged surface can serve stale data after a real write? Answer in terms of the guard (a writing tick still flushes) and the TTLs behind it (3600s for most, 86400s for four). If the answer is "unchanged, because a writing tick still flushes", say so and show why.
8. **The route's stale header comment** — it claims a "13:00 UTC daily" schedule against `vercel.json`'s `*/10`. It rides this touch; verdict and exact replacement text in the table.

**HALT.** Paste the table. If item 1 shows the return value cannot distinguish a write from a no-op, or item 5 shows sync's writes are invisible, that row's verdict changes and the table says so. Do not force the guard onto a signal that cannot carry it.

## STEP 1 — the chore commit (after the table is approved)

`git checkout -b 671-review-local` first; `main` stays at `origin/main` until approval. One commit, one kind:

`chore(HO 671): flush the bills tag only when a summarize tick wrote`

Expected shape: one guarded `revalidateTag` call, the corrected header comment, and — if STEP 0 ruled it in — the same guard in `/api/sync`. **The guard carries a comment naming the measurement that produced it** (296/300 idle, ~89,090 rows per flush, 37 tagged entries), so a future reader has to argue with the number rather than delete a line that looks redundant.

## STEP 2 — gates

- `npm run build` ✓ then `npm run typecheck` ✓ (build first; report both readings if typecheck ran early and went red).
- `git show --stat` lists **one or two files**, both cron routes, nothing else. No `lib/queries.ts`, no `vercel.json`, no component.
- Greps, controls first: `revalidateTag("bills")` call sites unchanged in *number* (the guard wraps, it does not delete — a count that dropped means the call was removed rather than conditioned); `grep -c '"bills"' lib/queries.ts` unchanged from the STEP 0 count.

## STEP 3 — the guard measurement; HALT

**This is the gate that decides whether the change works, and the instrument must be able to fail in both directions.** Bind check first: server on a private port (3100+), PID captured, verified as the port owner before any curl is trusted.

Four readings, each with the rows tap from HO 670 (`rows-tap-670.cjs` pattern) totalling `rows_read` per request:

| Reading | Expected | What a wrong answer means |
|---|---|---|
| A. Warm visit to `/welcome` | 0 | the tap is broken; nothing below is a reading |
| B. Idle tick (`summarized: 0`), then a visit | **0** | the guard did not take |
| C. Writing tick (`summarized ≥ 1`), then a visit | **~89,090** | the guard is over-tight and surfaces are serving stale summaries |
| D. Direct `revalidateTag("bills")` via the app's own route, then a visit | ~89,090 | the tap or the tag path is broken, not the guard |

B and C are the pair that matters, and **both must be taken** — B alone proves nothing, because a broken tap also reads 0. D is the positive control proving the flush path still works when it should.

Producing a writing tick on a drained queue is the hard part. Do not fake it by calling `revalidateTag` directly (that is reading D, not C). Options, in preference order: run the tick against a bill whose summary is absent or has been reset in a scratch row; or drive `runSummarize` with a forced input if the function admits one. **If C cannot be produced honestly, say so and HALT** — shipping a guard whose write path was never exercised is worse than not shipping it.

Then: `/welcome` 200 and `/` 200 as the controls proving no surface moved. Kill by PID, port-scoped, ports confirmed free.

**HALT.** Paste all four readings, the bind evidence, and how C was produced.

## STEP 4 — docs commit (`docs: HO 671 — …`)

4.1 **`docs/backlog.md`** — strike the summarize-flush entry opened at HO 670 (**never delete struck text**), with the close criterion answered by the STEP 3 readings. Amend the `/welcome` absolute-cost entry in place to record the new steady state rather than opening a second one. If `/api/sync` was ruled out of the guard, its entry gains that verdict and its reason.

4.2 **`docs/roadmap.md`** — one `Also (HO 671)` block, append-only, pointer 671: the measurement that motivated it, the guard, the four STEP 3 readings as arithmetic, the `/api/sync` verdict and the rule that produced it, and **the new steady-state cost for every bills-tagged surface**, not just `/welcome` — this is the number the entry exists for.

4.3 **`docs/oddities.md`** — only if something odd emerged. Nothing odd → no entry, and say so in the roadmap block (the HO 659/660 form).

## STEP 5 — SKILL commit (`docs(skill): HO 671 — …`), self-mod guarded

Its own commit, never riding another doc. Minimal edits per the approved STEP 0 classification. Expect: the cron/invalidation entry gains the guard and the rule behind it — **an unconditional flush on a scheduled tick is a cost multiplier, not a safety margin; flush on the write, not on the schedule** — plus the corrected `*/10` cadence wherever SKILL repeats the stale daily claim. The HO 670 `/welcome` entry's flush-cadence pointer is updated to the new steady state.

Classify every hit LIVE-CLAIM vs RECORD before editing. **No changelog append** unless client-island membership changed, which it does not here (HO 665 criterion, cutting as at HO 669 rather than at HO 666).

## HALT — the review ref

`git push origin HEAD:refs/heads/671-review` (amend via `--force-with-lease` on the ref only; `main` only ever fast-forwards). Paste: executed table deltas, `git show --stat` of all commits, the STEP 2/3 outputs including bind evidence and all four readings, the backlog numstat with **every deletion explained line by line** (a strike is an edit, not a deletion — `grep -c '^-[^-]'` is not a deletion count, HO 643), and the docs + SKILL diffs. **Deliver the SKILL diff as a gitignored file, not a paste, and remember Corey must attach it to chat for it to be read at all** (HO 670: it sat on the Windows box for three rounds). Remote claims via `git ls-remote`, never `rev-parse origin/*`. **The SKILL diff needs explicit approval** — the guard is satisfied by reading, not by summarising. After approval: fast-forward `main`, delete the ref, verify with `git ls-remote --heads origin`.

## Verification gates (run before the HALT; outputs in the paste)

- STEP 2/3 all green; working tree clean after the commits.
- `grep -cE '^\*\*Also \(HO 671' docs/roadmap.md` = 1.
- The struck HO 670 flush entry still present in full (strike, not delete): `grep -c "summarize" docs/backlog.md` unchanged or higher.
- `grep -rn 'revalidateTag("bills")' app lib scripts` — count matches STEP 0 item 4, and each hit is inside a condition or explained.
- Push only after re-checking HEAD ancestry (`git ls-remote --heads origin`).

---

read and follow 671
