# HO 724 — FF go (architect, 2026-09-14). SKILL diff approved as pasted and as read off the ref; one comment clause added as a fifth commit before the FF; then `HEAD:main`.

Read off `724-review` at `2083b74`, `main` `5dcdf9e` its ancestor, the two heads as `ls-remote` shows them. The SKILL diff is the two edits ruled at STEP 3, byte for byte with your paste: the `COALESCE` sentence with leg A's reading on `:1146`, and *a re-run keeps the week's stored summary (HO 724)* on `:1814`. **Approved alone.** The fix is the one clause at `:1794` plus five comment sites, and every departure is accepted: the case-insensitive grep found the sentence the case-sensitive one was written to find; `lib/week-summary.ts:208-210` is a comment made false by the same change and rides the `fix` commit; `SELECT changes()` where `writeReport` returns `void`; leg A's row-updated check inside the exit code, because a silent no-op would have printed a fake `PRESERVES=yes`; cleanup before the verdict line; the 10 s cap kept at 2.2 s of headroom with the reason written down. The probe's `prodRead` refusing anything but a SELECT is a guard the handoff did not ask for and should have.

## 1. One amend before the FF, and why it is not a nit

The new `summaryText` param comment says the discriminator is `cron_runs` and names the field as `payload.report.summary`. That is the handler payload's path. The stored row wraps the handler payload in the cron envelope, so the path *in the row* is `payload.payload.report.summary` (HO 718's close-out read it and said so, because it bit). A reader who takes the comment to the table and runs `json_extract(payload, '$.report.summary')` gets NULL on every row and reads *never attempted*, which is the exact misreading the discriminator exists to prevent. One clause in that comment: *in the `cron_runs` row the handler payload is nested, so the path is `$.payload.report.summary`; `chronicErr` lands in `error_message`*.

Land it as a fifth commit, `fix(HO 724)`, placed **before** the SKILL commit so the SKILL commit is replayed with its content unchanged:

1. `git checkout -b 724-review-2 cbfac31`; add the clause; commit `fix(HO 724): the summary_text comment names the cron_runs row path`.
2. `git cherry-pick e1e32bd` (SKILL, content identical; the paste carries `git diff e1e32bd HEAD -- .claude/skills/cbt/SKILL.md` reading empty, which is the proof the approved diff is the landed one).
3. `git cherry-pick 2083b74` (docs), then amend its block: *five commits*, the new SHAs, and this clause named as the FF go's correction. Nothing else in the block moves.
4. `npm run build`, `npm run typecheck`, `npm run check:design-citations` at the new tip; the paste carries these readings, not `2083b74`'s.
5. `git push --force-with-lease origin HEAD:refs/heads/724-review`; `git ls-remote --heads origin` is the claim.

## 2. Named for the next SKILL touch, not this ref

SKILL `:1813`, two lines above the amended one, still reads *Re-running for the same week overwrites the prior row*. It is true of nine columns and false of one, and the exception now sits two lines below it, so the section reads correctly together. A parenthetical there rides the next `docs(skill)` commit that touches the reports section; it is not worth a second approval round on this ref.

## 3. Then the FF

`git push origin HEAD:main`, no force; `git ls-remote --heads origin` again; delete the ref; local `main` fast-forwarded and `git rev-parse main` pasted. Post-FF, as owed: `npm run verify:deploy` on five consecutive reads; the Production `e2e-prod` run's id and its `pageErr=` readings, named as a `deployment_status` sample for the 09-17 ledger re-run; and the prod `reports` `SELECT` (row 5's form) once more against the deployed code, expected identical to STEP 0's six lengths. Corey attaches `docs/handoffs/724-step0-paste.md` to the chat so the swallowed table reaches the record.

Go.
