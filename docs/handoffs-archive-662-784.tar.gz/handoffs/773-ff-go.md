# HO 773: FF go. The ref read clean, SKILL `0a7725e` approved. A walled fetch hands its case to the name check, so Moore's and Sullivan's titles land; the four rounds close on their saved pages; then FF and the readings

## Rulings on the paste

I read `773-review` at `99026df`, all eight commits:
- the finder's two classes, as specified, with `Ambiguous` in place of `ambiguousMoved`;
- the qualifier's `trusted`, by identity or by the underline;
- rung 1b;
- the leaf key module and its re-export;
- the legs, the docs and the two filed lines.

**SKILL `0a7725e`: approved.** I rebuilt it from `889c737` with edits 1-3 and your correction to edit 1, and compared. It's byte-identical. The correction is right: § 1 takes one distinct key, and a member who advanced and then lost a runoff has two rows under it.

**The departures stand:**
- `Ambiguous`.
- Rung 1b's header, by the claim-3 rule.
- The leaf module. My *imports no Next module* was true and not enough: the qualifier reaches a client bundle through `lib/queries.ts`, and I didn't trace that.
- `docs(skill)` before the fix, rather than a force push.

**The build fault:** method.md's Code-side gates start with the build. Run it before every push from here.

**The filed lines stand:** Alabama's voided primaries, and the `SearchTabs` trap.

**GA-13 moving before the FF, on data alone,** is expected.

**The four rounds close on their saved pages.** HO 747's copies date from 2026-09-25, after all four runoff dates. Each says its R runoff was canceled and who advanced. A live read would add nothing.

## Moore and Sullivan: a walled fetch hands its case to the name check

In `confirmCases`, a readable answer never rejects a case the name check passes:
- a redirect or a disambiguation page confirms the case outright;
- a 404, or a page that lands elsewhere, falls to the name check.

So the fetch can raise a passing case's signal from the name check to `redirect` or `disambiguation`, and that's all the wall withholds.
- **HO 751's rule stays for pacing:** the first unreadable page ends the fetching.
- **What changes is the verdict** of the walled case and of every stored case after it. The name check decides each, as it would have after a readable page, and the evidence names the wall.
- **A case the name check fails stays unconfirmed,** because only a fetch could confirm it.

Moore's and Sullivan's titles both pass the name check, so they land. S-AL and S-AK then tie at the reader cron's next pass over each (`20 */2 * * *`, 40 races a tick, one full pass a day). This box can't re-read them.

## Read first: the first daily ratings run

These are the `cron_runs` rows for `/api/sync-race-ratings` started after 2026-10-10 21:12Z. For each:
- its status;
- its `error_message`;
- on a `success` row, each leg's `stats.raters.sabato`.

Fix 3 records them in the ratings WATCH and Sabato's line, closing what their closes say.

## Four commits on `773-review`, before the FF

Build, then the cheap gates, before the push.

**1. `fix(HO 773)`, the wall.** In `lib/ballotpedia-title-repair.ts`, verbatim:

```text
OLD:
// An unreadable page (the wall) is not "confirms neither way": it stops the
// fetching and the rest stay "not attempted", the reader's first-UNREAD rule.
NEW:
// An unreadable page (the wall) stops the fetching, the reader's first-UNREAD
// rule. Since HO 773 the name check decides the walled case and every stored
// case after it: every readable answer leaves a case the name check passes
// confirmed (a redirect or a disambiguation page outright, a 404 or a page that
// lands elsewhere by the name check), so the wall withholds only the stronger
// signal.
```

```text
OLD:
// fetching, the reader's first-UNREAD rule, leaving the rest "not attempted".
NEW:
// fetching, the reader's first-UNREAD rule. The name check decides that case
// and every stored case after it (HO 773).
```

```text
OLD:
        out.push({ ...c, signal: null, evidence: "", verdict: "not attempted", reason: "fetching stopped at an unreadable page" });
NEW:
        out.push({ ...c, ...nameSignal(c, "fetching stopped at an unreadable page") });
```

```text
OLD:
        out.push({ ...c, signal: null, evidence: `${url} → ${f.status ?? f.kind}, no readable page`, verdict: "unconfirmed", reason: "no readable page (the wall?); fetching stops here" });
NEW:
        out.push({ ...c, ...nameSignal(c, `${url} → ${f.status ?? f.kind}, no readable page; fetching stops here`) });
```

In `scripts/repair-ballotpedia-titles.ts`, verbatim:

```text
OLD:
// title, that links the learned title; or the name check, for a missing title
// and as the fallback for a stale title whose page confirms neither way.
NEW:
// title, that links the learned title; or the name check, for a missing title
// and as the fallback for a stale title whose page confirms neither way or,
// since HO 773, can't be read (the wall still ends the fetching).
```

**2. `diag(HO 773)`, leg F,** in `scripts/diagnostic/electoral-cleanup-773.ts`. It runs `confirmCases` with an IO whose first GET answers 202:
- two stale cases whose learned titles pass the name check both read `confirmed`, `ballot` or `ballot-prefix`, with the wall in their evidence, and the IO saw one request. The red: `99026df` reads `unconfirmed`, then `not attempted`.
- a stale case after the wall whose learned title fails the name check reads `unconfirmed`.
- **The control:** a readable page whose canonical key is the learned key still reads `redirect`.

**3. `docs(HO 773)`, backlog:**
- **Strike the four rounds,** the close note verbatim:

  ```text
  · **CLOSED 2026-10-11, HO 773's FF go, on HO 747's saved pages (the architect's ruling):** the copies date from 2026-09-25, after all four runoff dates, and each says its R runoff was canceled and who advanced: AL-01 (the May 19 round voided and August 11's special primary deciding it, filed separately), OK-01 (Mark Tedford; Jackson Lahmeyer listed withdrawn), TX-23 (Brandon Herrera; Tony Gonzales withdrawn) and TX-32 (Jace Yarbrough; Ryan Binkley withdrawn). A live read would add nothing.
  ```

- **Moore's line:** append the writes below, and that S-AL ties at the cron's next pass. It closes when AL-01 reads RUNNING FOR SENATE.
- **The ratings WATCH and Sabato's line,** from the first read.
- Reconcile, with the control at 0.

**4. `docs(skill)`, alone and last.** At `:1337`, verbatim:

```text
OLD: A page that cannot be read (the wall) stops the fetching, the reader's first-UNREAD rule.
NEW: A page that cannot be read (the wall) stops the fetching, the reader's first-UNREAD rule, and since HO 773 the name check decides that case and every stored case after it: every readable answer leaves a case the name check passes confirmed, so the wall withholds only the stronger signal (Moore and S-AK's Dan Sullivan met it at HO 773).
```

Push, with no force. If 1 and 4 are exactly these replacements, they're approved as landed. Paste every diff.

## The writes, after fix 1, before the push

**W2b:** `npm run repair:ballotpedia-titles -- --plan-out <plan> --record <dir>`.
- Expected: the wall at the first fetch, one request, and two cases confirmed by the name check:
  - S-AK's Dan Sullivan (`stale`);
  - AL-01's Barry Moore (`senate`, on S-AL-2026).
- The plan holds exactly those two. Anything else, **HALT**.
- Then `--write --plan <plan>`. Read back both resolved titles.

**W4b:** `npm run repair:primary-identity -- --saved-only`, dry first.
- Its bioguide changes must be NULL → member, on rows keyed by a title W2b wrote. Expected: Moore's S-AL rows 8393 and 13972.
- Anything else, **HALT** with the list.
- Then `--write`.

**The re-read:** read `general_ballot_reads.last_attempt_at` for S-AL-2026 and S-AK-2026, with each one's place in the queue: the races whose last attempt is older. That says when the cron reaches them.

## FF

`773-review`'s new head sits on `main` at `889c737`, so this is a fast-forward of 12 commits. No migration.

Re-run the build and the cheap gates immediately before the push, and name the reading. Then:
- `git push origin <773-review's head>:main`, no force;
- `git ls-remote --heads origin`;
- delete `773-review`;
- forward local `main` and delete the local review branch;
- paste `git rev-parse main`.

If the classifier blocks the push, Corey runs the same command from your checkout.

## The deploy

Run `npm run verify:deploy` **in the foreground**, then read:
- **The Production build's cache line.**
- **The Production `e2e-prod`** and its smoke.
- **One flush:** `POST /api/revalidate?tag=races`, with `$CRON_SECRET` by env name.
- **The three cards on Production** (`components/RaceIncumbentCard.tsx:138`):
  - GA-13 reads LOST PRIMARY;
  - TN-05 reads LOST PRIMARY;
  - AL-01 reads NOT ON THE BALLOT until the cron re-reads S-AL, and RUNNING FOR SENATE after. Say which, with S-AL's `last_attempt_at` at the time.

Paste once, after the cards.
