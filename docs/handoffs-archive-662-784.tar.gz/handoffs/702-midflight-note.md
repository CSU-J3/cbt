# HO 702 — mid-flight note (architect, 2026-09-07). Arm A is a clean negative on both limbs; one field to add before Arm B's crawl; what to read in `found=`.

Accepted as measured: nothing mutates the DOM under hydration on a firing route (`pre=0` on `/president`; the one record on `/primaries` is the parser extending the flight-data script's text node, which quiet hits carry too), every route has only resolved `<!--$-->` markers except `/welcome`, which does not fire, and (i)–(iii) hold with the channel demonstrably live on 72 hits. Both limbs of the hypothesis are closed by measurement. The block says so in those terms and the `:50` annotation gains the sentence.

## 1. The two numbers standing next to each other are the lead

`fire-t=273 · dcl=276` and `fire-t=264 · dcl=235`. Both fires land within ±40 ms of `DOMContentLoaded`, and the `/primaries` parser record at `t=210` says the parser was still writing the trailing RSC `<script>` chunks when hydration ran. Whether that is the class or a coincidence is a distribution question, and the channel already has one half of it. **Add `first-post-t` to every hit**: the timestamp of the first React-attributable mutation after `DOMContentLoaded` on a quiet hit (the announcer insertion is the reliable one), so the paste can put two distributions beside each other — `fire-t − dcl` on fires against `first-post-t − dcl` on quiet hits of the same routes. If fires cluster at the parser's tail and quiet hits commit later, that is a measured statement about *when* the class occurs, which no one has had. If they overlap, it is not. One field, one line in the summary, no new hypothesis written down until the numbers are.

## 2. The recovery batch, read with the site

Removing the whole `<head>` contents, the hidden boundary container and `div.flex` and re-inserting them is a **root-level** re-render, and the fired site (`:7616–7622`, the identifier-proven one) sets `rootOrSingletonContext = false` in the same expression as the claim that failed. So the refused claim is at or one level inside the first non-singleton host element, in the leniency boundary React 19 draws around `<body>`. That is where `found=` matters most: **if it names a `<script>`, `<template>` or `<div hidden>` sitting where React expected app markup, the class is the parser's tail meeting hydration at the root**, and §1's distributions are its timing signature; if it names app markup, the class is somewhere no one has looked.

## 3. Arm B, unchanged, one addition to the record

The planted mismatch must name `Ho702Plant`, the span and its site before any natural fire's message is read; the natural messages are then quoted in full, `fiber=` chain and `found=` included, one per fire. Add to each: the `first-post-t` and `dcl` of that hit, so every named fire carries its own timing.

## 4. Housekeeping

Four shells running: name them at the next halt and kill by PID what is yours when the crawls end. Worktree and builds stay until the patched read is done, then go, `node_modules` with them.

read and follow 702 — mid-flight note, one field and the found= reading
