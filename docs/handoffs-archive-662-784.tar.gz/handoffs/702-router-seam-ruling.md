# HO 702 — ruling on the enumeration (architect, 2026-09-07). The app has no candidates; the router seam under fire 2's chain has four. Test them by intervention, not by counting.

The enumeration is accepted and it is the turn of the whole hunt: nothing in the app's own tree can make React abandon and re-run a unit of work during hydration, the header subtree was parsed 17–82 ms before `DOMContentLoaded` and the fire landed 16 ms after it, and fire 2's chain is Next router internals with no app frame, `expected=div / found=<header>` — the same seam as fire 1, one level up. Read in this clone, the frames fire 2 named have suspending reads in them:

- **`node_modules/next/dist/client/components/layout-router.js:276`** — `InnerLayoutRouter`: `resolvedRsc = … typeof rsc.then === "function" ? use(rsc) : rsc`. A segment whose RSC is still a pending thenable at hydration time **suspends here**.
- `:271` — `useDeferredValue(cacheNode.rsc, resolvedPrefetchRsc)`: the initial render returns the second argument and re-renders with the first, a deliberate two-pass render at the same seam.
- `:308` `use(lazyData)`, `:312` `use(unresolvedThenable)`, `:345` `use(promiseForLoading)` — the missing-segment fetch, the never-resolving sentinel, and the `loading.tsx` module's lazy import.

So *no candidates in the app* is right, and *four suspending reads in the router seam the fires sit under* is the finding. State it that way in the block, with the five line numbers.

## 1. The mechanism, as a hypothesis with its own falsifiers

During initial hydration React reaches `InnerLayoutRouter` for the page segment while that segment's RSC is still a pending thenable, because the flight-data `<script>` chunks that resolve it are in the parser's tail (the `/primaries` record: the parser extending a `self.__next_f.push` text node at `t=210`, fire at 264). `use(rsc)` suspends; when the chunk lands the thenable resolves and React **replays** the suspended unit. Inside a Suspense boundary React resets the hydration cursor on retry; **at the root there is no boundary** (`__next_root_layout_boundary__` is a plain wrapper, `function(e){let{children:t}=e;return t}`, from the control's snippet), so the replayed host fiber claims against a cursor the first attempt already advanced — `div.flex` finds `<header>`, or `header` finds `header-titlebar`, depending on how far the first attempt got — and React throws the structural `#418` and client-renders the root. **Hit-2 dominance falls out of it:** on hit 2 the JS chunks are in the browser cache and execute the moment the parser reaches their `<script>` tags, before the flight tail is parsed; on hit 1 they download first and the parser is finished by the time hydration starts. **`/welcome` never firing** is the same arithmetic with a smaller flight tail. **The hour** is the network. None of this is claimed; the three interventions below are what claim or kill it, and the predicted effects are large (toward 0 and toward all), which is why three crawls each is enough here and was not enough for 0.75 against 1.2.

## 2. Three interventions, on the tagged tree's production server, JS cache warm (hit-2 conditions)

| | intervention (Playwright, per page) | prediction if §1 holds | if it does not move |
|---|---|---|---|
| T1 | `page.route('**/_next/static/chunks/**', …)` delaying every JS chunk 500 ms, so hydration starts after the parser has finished the tail | fires → **0** across three crawls | the race is not with the flight tail |
| T2 | CDP `Network.emulateNetworkConditions` throttling **download** hard (e.g. 64 kbit/s) with the JS already cached, so the document's tail arrives slowly while hydration runs immediately | fires → **most hits**, on routes that never fire at rest | the flight tail is not what hydration is waiting for |
| T3 | a landmark, not an intervention: the parser insertion time of the **last** `self.__next_f.push` script in `<body>` on every hit, in the `mut` line | on fires, last-flight > `fire-t`; on quiet hits, last-flight < `first-post-t` | the tail was complete before hydration on fires too, and §1 is dead |

T1 and T2 must move the rate in **opposite directions** to count; one alone is a correlation. Each is run against an unmodified control crawl in the same window (the 703-shape interleave). Quote per crawl: fires, routes, and for every fire the widened message with `expected= / found= / site=` and the T3 landmark beside it.

## 3. What lands in 702, by outcome

- **§1 confirmed (T1 → 0, T2 → most, T3 in the predicted order):** `backlog:50` gains *a named node and a named mechanism, confirmed by intervention* — still **not struck**; the close is cause plus green, and the fix is HO 704. The block records the mechanism in §1's words with the line numbers, the three interventions with their readings, and the fix candidates for 704 in order of cost: **(a)** an explicit `<Suspense>` around `{children}` in the root layout, so the replay has a boundary to reset the cursor at — one line, testable with T2 as its gate (fires under throttle must go to 0 with it and stay high without it); **(b)** a minimal reproduction and an upstream report against React 19.2.5 / Next 15.5.15 (a root-level `use()` suspension during hydration replaying without cursor reset), with the changelogs of both read first for a fix already shipped; **(c)** nothing app-side beyond (a) — no delaying of hydration, no un-streaming; those trade a real page for a clean crawl.
- **§1 killed:** the block says which intervention killed it and how, the mechanism is recorded as tested-and-wrong beside HO 700's two, and the `:50` entry gains the fields that survive (a named node and site, the replay reading, the Next frames) as the next hunt's starting position.

## 4. Housekeeping, unchanged

The three natural crawls finish and are quoted as read (fire 1 without snippets, as you said). Then T1–T3. Then teardown: worktree, builds, `node_modules` in the worktree, servers by PID, ports verified; the three shells named and reconciled. Then SKILL alone, docs, `702-review`.

read and follow 702 — the router seam, tested by intervention
