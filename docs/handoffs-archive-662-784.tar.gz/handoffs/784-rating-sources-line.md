# HO 784: the ratings sources line, as set on mock-784 v3. Every ratings surface names its three raters, links each one, and says how old its ratings are; and `seed:ratings` refuses a table that has rows

**Corey's ruling, verbatim: *"this works send it"*, on `mock-784-sources-line-v3.html` as it opens.** The line as set: ELECTORAL foot · RACE chips · WELCOME foot · FRESH via · LAYOUT line · CASE chrome · COOK on · EMBER #d2500e. The bar's SABATO FEED buttons preview a future state and are not a ruling. The trail, verbatim:
1. *"prob should have like a drop down on the dashboard that list these upfront?"* I answered: a static line, not a dropdown, since a dropdown hides what he wants upfront.
2. On v1, he set FOOT, UNDER CHIPS, FOOT, AS OF + VIA, ONE LINE, CHROME, SHOWN, and said: *"from its own page cant be the wording. make this more noticeable, maybe make the text a dark orange that we have not used yet"*.
3. On v2: *"no just this text as of 2026-09-30 · via Ballotpedia. keep the ratting site name with the same color associated with it"*.
4. On v3: *"this works send it"*.

**The mock.** `docs/design/mock-784-sources-line-v3.html`, sha256 `47fd497ac03c5471db12676a47c18472a978d0b0e014ff705a8e922520d22135`, 29,176 bytes. **Corey drops it there before STEP 0.** It was drawn as "mock-783" before HO 783 went to the general runoff box, so it was renamed and its title bar's number changed, nothing else. The old name was never cited in the repo, so nothing dangles (docs/design README rule 2).

**Riding along: the `seed:ratings` guard** (backlog `:15`, HO 782's note 5), which this HO closes.

**Base:** `main` at `372c433`, HO 783's head. The pointer and the highest HO in commit subjects both read 783, so this is 784. **STEP 0 is a check** (method.md, HO 768's rule): go on through the build, legs, docs and the review push unless a claim fails.

## What the line says

Per rater, in the fixed order COOK · INSIDE ELECTIONS · SABATO:
- **The name.** `sourceLabel` (`components/RatingChip.tsx:36-45`, today unexported), linked exactly as the chip links it (`:73-83`):
  - to `RACE_RATING_PAGES_2026[source][chamber]` (`lib/enums.ts:224-237`);
  - class `rater-link`, colour `--text-muted`, new tab;
  - the full `RACE_RATING_SOURCES` name (`lib/enums.ts:214-218`) as its title.

  Where the chamber has no page, it's a plain span, as the chip does.
- **Then, in the new token:** `· AS OF <date>`, then `· VIA BALLOTPEDIA` or `· DIRECT` when the via is known.

**AS OF is `MAX(rating_date)` over the rater's cycle-2026 rows.**
- `rating_date` is the reader's own stamp: Ballotpedia's widget caption date, else the scrape date; for Sabato, the race's newest change (`lib/race-ratings-sync.ts:358-367`, written at `:386`).
- The sync writes a rating only when it changes (`:349-352`). So this is the newest rating date, not the last read, and for a live feed with no changes it understates. Nothing records a rater's last successful read, so that's filed (Docs), not fixed.

**VIA comes from the `source_url` of the rater's most recently updated row:**
- host `ballotpedia.org` → VIA BALLOTPEDIA (the chip's own test, `RatingChip.tsx:27-34`);
- equal to a direct reader's `sourceUrl` → DIRECT. Today that's `SABATO_CHANGES_URL` only (`lib/race-ratings-scrape.ts:375`, the one `sourceUrl:` at `:704`); keep the set beside it so the next direct reader adds its URL there;
- anything else → no via clause.

Matching the rater's own domain can't stand for DIRECT. The seed wrote each rater's own chamber page as `source_url` (each file's `source_url_base`; `scripts/seed-race-ratings.ts:131`) on rows that came from Wikipedia.

**The token:** `--rating-freshness: #d2500e`.
- Contrast is 4.70:1 on `--bg-panel` and 4.51:1 on `--bg-base`, both AA at 12px. The mock's "4.8" was the architect's, rounded wrong.
- `#d2500e`, `#ea580c` and `#c2410c` are used nowhere in `app components lib`. The nearest orange in use is `#b45309`, primaries' upcoming dates (`components/ElectoralBoard.tsx:154`, `components/PrimaryTimeline.tsx:35`), a yellower and darker one.

## STEP 0

| # | Claim at `372c433` | Fails if |
|---|---|---|
| 1 | `main` is `372c433`. HO 783 is on it, and its FF paste recorded Production smoke green. | 783 not verified live |
| 2 | `sha256sum docs/design/mock-784-sources-line-v3.html` reads the hash above, 29,176 bytes. | absent or different |
| 3 | The mechanics above hold:<br>• the `race_ratings` DDL (SKILL `:368-378`);<br>• the unchanged-skip (`lib/race-ratings-sync.ts:349-352`);<br>• the upsert writing `rating_date` (`:386`) and the reader's `sourceUrl` (`:387`);<br>• `SABATO_CHANGES_URL` (`lib/race-ratings-scrape.ts:375`) as the only `sourceUrl:` value (`:704`);<br>• the seed writing each file's own URLs (`scripts/seed-race-ratings.ts:131`). | any differs |
| 4 | **Prod read, read-only:** per source, the row count, `MAX(rating_date)` for cycle 2026, and the host of the newest row's `source_url` (by `updated_at`).<br>Estimates: all three sources present; each `MAX` ~`2026-09-30`, possibly earlier, since the stamp sits on the last *changed* row; each newest host `ballotpedia.org`. STEP 0 measures all of it, and the paste quotes the line's expected text from this read. | a source absent (report it, go on) |
| 5 | The surfaces:<br>• `components/RaceListView.tsx` is client (`:1`), with `tab` at `:314`. `measure()` at `:355-365` sizes the box from the window's bottom (`:360-362`). `.rl-main` / `.rl-box` are at `:500-510`, the aside at `:561`.<br>• `/electoral` passes it at `app/electoral/page.tsx:172-184`.<br>• `RaceHeader`'s chip strip is `components/RaceHeader.tsx:68-92`. It's rendered only by `components/RaceHubBody.tsx:119`, from `app/race/[id]/page.tsx:112-124`, whose `Promise.all` is `:70-95`.<br>• The welcome foot is `app/welcome/page.tsx:408-420`. Its classes are in `app/welcome/landing.module.css`: `.foot` (fs-10, `--text-dim`), `.footK` (`--text-muted`), `.sep` (`--border-strong`).<br>• Under 900px the box is off (`app/globals.css:6194-6199`). | any differs |
| 6 | `getRaceRatings` (`lib/queries.ts:2425-2445`) is `unstable_cache` with revalidate 86400 and tag `race-ratings`, and nothing in `app/api` or `lib` calls `revalidateTag("race-ratings")`. Its comment at `:2425-2427` still says the seed refreshes quarterly. | |
| 7 | The seed has no row-count check (`main`, `scripts/seed-race-ratings.ts:81-89`); its header (`:1-6`) still calls itself the quarterly refresh; SKILL `:1376` and `:2968` describe it. | |
| 8 | `e2e/smoke.spec.ts` has the `targeted interactions` describe at `:898`. | |

## § 1, the data and the component

- **`lib/queries.ts`**, beside `getRaceRatings`, in the same `unstable_cache` shape (`["getRaterFreshness"]`, 86400, tag `race-ratings`):

```sql
SELECT r.source,
       MAX(r.rating_date) AS as_of,
       (SELECT n.source_url FROM race_ratings n
         WHERE n.source = r.source AND n.cycle = 2026
         ORDER BY n.updated_at DESC LIMIT 1) AS newest_url
  FROM race_ratings r
 WHERE r.cycle = 2026
 GROUP BY r.source
```

  It returns `RaterFreshness = Partial<Record<RatingSource, { asOf: string | null; via: "ballotpedia" | "direct" | null }>>`. A rater with no rows is absent, and the line still names and links it, without a freshness clause.
  - Correct the comment at `:2425-2427`: the sync writes daily, nothing revalidates this tag, so a read lags a sync by up to a day.
- **`components/RatingSourcesLine.tsx`**, presentational, with no hooks and no server-only imports, since a client component renders it.
  - Props: `freshness`, `chamber`, an optional `sources` (default all three, kept in the fixed order), and `className`.
  - It renders `<p data-rating-sources>` at `--fs-12`, uppercase, tracking 0.5px:
    - the label `Ratings` in `--text-dim`;
    - per rater, a `·` in `--text-dim` (`aria-hidden`), then `<span data-rater={source}>` holding the name link and `<span data-rater-freshness>` in `var(--rating-freshness)`;
    - each date `whitespace-nowrap`, so the line wraps at 430px without breaking a date.
  - Export `sourceLabel` from `RatingChip.tsx` for it.
- **`app/globals.css`**, `:root`, after `:16`, on one line:

```css
  --rating-freshness: #d2500e; /* HO 784: a rater's as-of and via on the ratings sources line, nothing else (HO 610 rule); docs/design/mock-784-sources-line-v3.html */
```

## § 2, `/electoral`: FOOT

- `app/electoral/page.tsx` reads `getRaterFreshness()` and passes it as a new `freshness` prop.
- In `RaceListView`, inside `.rl-main`, right after `.rl-box`: a footer `div.rl-sources` (`ref` `footRef`) holding `<RatingSourcesLine freshness={freshness} chamber={tab} />`. Its links follow the tab.
- It continues the box: same border, no top border, radius `0 0 3px 3px`, `--bg-base`, padding `8px 12px`. The box's bottom corners go square while it's there.
- **`measure()` changes, and this is the architect's call, not the mock's.** The box fills to the window's bottom, so a footer just appended would sit below the fold on the House tab: the "out of sight on a tall list" the mock's FOOT note warned of, against v2's *"make this more noticeable"*.
  - The box's height subtracts the footer's `offsetHeight`.
  - RACE NEWS's `newsH` runs to the footer's bottom, so the two columns still share one bottom edge.
  - Under 900px nothing changes: the box is off, and the footer follows the list.

## § 3, `/race/[id]`: UNDER CHIPS

- The page adds `getRaterFreshness()` to its `Promise.all` and passes it to `RaceHubBody`, which hands it to `RaceHeader` as an optional `freshness` prop.
- In `RaceHeader`, inside the `ratings.length > 0` branch, after the strip's `div`: `<RatingSourcesLine className="mt-2" freshness={freshness} chamber={race.chamber} sources={…} />`. `sources` holds the raters in this race's strip, in the line's order.
- It's outside the strip's `div`, so it doesn't take the decided state's 0.55 opacity.

## § 4, `/welcome`: FOOT

- `page.tsx` reads `getRaterFreshness()`. The foot gains three things after `FEC`, before `synced 4× daily`, in its own register (fs-10, mixed case, `.sep` dots):
  - `Cook · Inside Elections · Sabato`, each in `.footK` and linked to that rater's **House** page. The board mixes chambers, so House is the architect's pick;
  - `ratings as of <date>` in `var(--rating-freshness)`;
  - no via, as in the mock.
- When the three dates differ, it reads `ratings as of <oldest> to <newest>`; when none has a date, the phrase drops.

## § 5, the seed guard (`fix`)

- In `main()`, before reading the seed files, count `race_ratings` rows. With rows and no `--force` in `argv`, print the message below, set `process.exitCode = 1`, and return without a write:

```text
race_ratings has N rows; seed:ratings is a first fill for an empty table and would write its snapshots over the synced ratings. Re-run with --force to do it anyway.
```

- In the header, the sentence beginning *Idempotent* (`:3-4`) becomes: *A first fill for an empty table: it refuses a table that has rows unless run with `--force` (HO 784), because its upsert would write the snapshots over the synced ratings.*

## Legs

Each one is failable. They run on local builds of HEAD and the tree, as HO 781's did.

**A, the prod read.** STEP 0's claim 4 is A's red half: what the line must print.

**B, the smoke test** (red on HEAD, green on the tree). A new test in `targeted interactions`, *the ratings sources line names, links and dates the raters*:
- `/electoral`:
  - `[data-rating-sources]` is visible under `.rl-box`, with three `[data-rater]` in order;
  - the hrefs equal `RACE_RATING_PAGES_2026[s].senate`, and after the HOUSE tab, `.house`;
  - each `[data-rater-freshness]` matches `/as of \d{4}-\d{2}-\d{2}( · via ballotpedia| · direct)?/i` and agrees with A.
- `/race/S-AK-2026`: the line's raters equal the strip's.
- `/welcome`: the foot links the three House pages and matches `/ratings as of \d{4}-\d{2}-\d{2}/`.

**C, the box fit** (tree). At 1440×900 and 2560×1440, on `/electoral`'s HOUSE tab:
- `document.scrollingElement.scrollHeight - innerHeight` reads 0. Without the subtraction it reads the footer's height.
- The footer lies wholly inside the viewport.
- At 2560 its bottom equals RACE NEWS's bottom ±1px.

HEAD reads 0 too, with no footer: the control.

**D, the colours** (tree). Computed `color`:
- `[data-rater-freshness]` reads `rgb(210, 80, 14)`;
- every rater name reads `rgb(148, 163, 184)`, as the chip's does.

Contrast against each one's computed background is ≥ 4.5, computed in the leg.

**E, the seed** (a scratch copy of the database, never prod).
- HEAD's script writes: `updated_at` moves on seeded ids, the red.
- The tree's exits 1 with the message, and a dump of the table hashes the same before and after.
- The tree's with `--force` writes, which proves the flag.

**F, captures** (render-touching, so mandatory):
- `/electoral` on Senate and House, `/race/S-AK-2026` and `/welcome`, at 1440 and 2560;
- the same set with reduced motion;
- CI's narrow-preview green with every cell equal to the base's, plus a 430 capture of `/electoral` and `/race/S-AK-2026` from that run.

**Gates:** typecheck, the cold build, and the cheap gates. `check:design-citations` must count the new citation as resolving.

## Docs

The roadmap and backlog are public: Corey's words go in verbatim, as above, and nothing else is quoted.

**roadmap:** the HO 784 block:
- the ruling trail verbatim and the mock's sha256;
- the definitions of AS OF and VIA, and why matching the domain can't mean DIRECT;
- the token and its measured contrast;
- the `measure()` call and its reason;
- the guard;
- legs A to F.

**backlog:**
- **Strike `:15`** in place, closed by HO 784.
- **New line:** **The sources line's AS OF is a rater's newest rating date, not its last read (HO 784).** opened on the day it lands; *Owner:* Code, low.
  - The sync writes only changes (`lib/race-ratings-sync.ts:349-352`), and nothing records a successful read. So a live feed with no recent changes reads old, and the `race-ratings` cache (a day, revalidated by nothing) can lag a sync by a day more.
  - *Close:* a per-rater last-read stamp exists and the line reads it, or Corey rules that the newest rating date is the meaning.
  - *Reads if never done:* the day Sabato's reader gets through, its line can say a date weeks old while it reads daily.
- Reconcile, with the control at 0.

**SKILL**, in its own `docs(skill)` commit, last:
- the palette block gains `--rating-freshness`;
- the ratings section gains a bullet for the sources line: its three surfaces, AS OF and VIA as defined here, the direct-URL set, the footer's place in `measure()`;
- `:1376` and `:2968` say the seed refuses a table with rows unless run with `--force`.

## Commits

On `784-review` from `372c433`, kinds unmixed:
- `feat(HO 784)`: §§ 1–4, with the smoke test;
- `fix(HO 784)`: § 5;
- `diag(HO 784)`: the leg instruments;
- `docs(HO 784)`: roadmap and backlog;
- `docs(skill)`: alone and last.

Build, then the cheap gates, before the push. No migration, no prod write.

## Paste back

- `ls-remote` with `784-review`'s SHA;
- STEP 0;
- legs A to F, red and green, with the captures listed;
- `--stat` per commit, `--numstat` for docs with every deletion explained, and the SKILL diff;
- the reconcile;
- a last cheap-gate run;
- the secret audit.

Build through to the review push without stopping. A failed claim HALTs; nothing else does.
