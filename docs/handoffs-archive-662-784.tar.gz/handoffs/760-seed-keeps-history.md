# HO 760: the seed keeps history, the ballot decides the field, ruled C. Curated races publish from the ballot like every other race, and a curated row survives only as `withdrew`

`docs/backlog.md` OPEN LOOPS, the S-GA line filed at HO 750 (*S-GA's curated roster still carries Dooley, a runoff loser, and the harvest never touches curated rows…*), owner Corey for the seed's role. Ruled 2026-09-30 in chat, verbatim: *"C"*: the ballot decides the field, the seed keeps history.

## Ground truth (read at `2bce248`; re-derive every `:N` by content)

- `data/races-seed.json` carries five 2026 rosters: S-GA (Carter `withdrew`, Collins `running`, Dooley `running`), S-ME (Jackson `nominee`, Platner and Mills `withdrew`), NJ-07 (Bennett `won_primary`, Roth, Shah and Varela `withdrew`), PA-10 (Stelson `won_primary`), AK-AL (Hill, Hafner, McDermott `advanced`, Williams `withdrew`). `seed:races` upserts candidates on `(race_id, name)` with a page URL in `source_url` and never deletes (HO 171/174/182, HO 741).
- The harvest (`lib/harvest-challengers.ts`, HO 750/757) skips any race with a non-sentinel row (the NOT EXISTS guard) and clears only sentinel rows. HO 750's payload names the curated races whose curated nominated set differs from the ballot's: S-GA only (Dooley).
- The ballot for the five, per HO 747 and the reader: S-GA's box carries Collins (R) and the Democratic nominee, not Dooley; S-ME's carries Collins (R, the incumbent) and Jackson; NJ-07's and PA-10's carry their majors; AK-AL's matches the seed's four, Williams in the withdrawn block.
- The `withdrew` status renders dimmed at the end of the roster (`components/RaceCandidates.tsx`); HO 750 publishes it for a primary-marked person in the withdrawn block, which S-ME's Mills and Platner and NJ-07's three are not (primary-stage withdrawals, before any box).

## STEP 0

1. HO number from the tree: `main` at `2bce248`, pointer 759, so 760. Otherwise stop.
2. Re-read every cited `:N` by content. Flag a drift.
3. Measure, prod, SELECTs only: the five races' current `race_candidates` rows by source and status; the ballot rows the harvest's plan would publish for each; the curated rows that are `withdrew`; the curated rows that are not (these are the rows the ruling retires: S-GA's Collins and Dooley, S-ME's Jackson, NJ-07's Bennett, PA-10's Stelson, AK-AL's three). Predict the whole-table delta.
4. Carry HO 759's Production reading and the HO 744 WATCH tick (#21278) into this HO's roadmap block.
5. Proceed without a halt.

## The build

1. The harvest: the NOT EXISTS guard goes. Every race with a `box` read publishes from the ballot; the DELETE before the plan clears the sentinel rows and, from now on, every curated row whose status is not `withdrew`. A curated `withdrew` row stays as it is, source URL and all. The payload replaces the curated-divergence list with `curatedHistoryKept` (rows) and `curatedRetired` (rows, named on the first run).
2. `seed:races`: a candidate entry with a status other than `withdrew` is no longer written to `race_candidates`; the script prints it as retired by HO 760. The seed file keeps its entries as the record of what was curated, with a comment naming the rule.
3. The reader's `withdrew` rule (HO 750) is unchanged.

## Legs, on a `file:` copy, each red first

1. S-GA: Dooley gone, Collins from the ballot at `nominee`, Carter's `withdrew` row kept. Red: today Dooley is `running`.
2. S-ME: Jackson from the ballot, Mills and Platner kept as `withdrew`, Collins excluded as the incumbent.
3. NJ-07, PA-10, AK-AL: the majors from the ballot with the same names, the `withdrew` rows kept, AK-AL's four unchanged in content.
4. The whole table: exactly STEP 0's predicted delta, nothing else. Every non-curated race identical to today.
5. `seed:races` on the copy: a non-`withdrew` entry writes nothing and is printed as retired; a `withdrew` entry writes as before.
6. Idempotence: a second harvest on the copy changes nothing.

## Commits and docs

- `feat(HO 760)`: the harvest and the seed script.
- `chore(HO 760)`: the seed file's comment.
- `diag(HO 760)`: the legs driver.
- `docs(skill)`, its own commit, approval requested: the harvest entry (curated races publish from the ballot; a curated row survives as `withdrew`), the seed's role, the payload's two new fields.
- `docs(HO 760)`: strike the S-GA line with the ruling verbatim; the roadmap block, pointer 759 → 760, carrying HO 759's Production reading and the ratings tick; strike the HO 744 WATCH line on that tick. Reconcile OPEN LOOPS at open and close, control at 0.
- Review ref `760-review`. The FF is held for the SKILL approval and review. No render code changes, so no captures; the Production pages are the reading.

## The prod reading (in the FF go)

After the FF: one authorized POST of `/api/cron/race-challengers`, its payload's `curatedRetired` (the eight named rows) and `curatedHistoryKept` (six), then `/race/S-GA-2026` and `/race/S-ME-2026` on Production.

## Paste back

- STEP 0's readings and the predicted delta;
- the six legs;
- the SKILL diff, for approval;
- `git show --stat` per commit, `--numstat` for the docs commits, the reconcile, the `760-review` SHA from `git ls-remote`, and a last cheap-gate run.
