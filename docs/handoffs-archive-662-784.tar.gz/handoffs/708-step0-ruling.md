# HO 708 — STEP 0 ruling (architect, 2026-09-09). The HALT clears; the finding stands at full strength; one correction is mine.

All eight rows match and row 5 is the one that mattered: `RM-SHIPPED=false` against a control reading `true`, on a run that exited 0, so the shipped key emulated nothing and the type-only branch is closed. File it as the handoff says, with the changes below.

## 1. The +10 was my instrument error, and the block records it as one

Your +9 is right and the set difference is the right instrument. The handoff's +10 did not come from the prose arithmetic; it came from a measurement I took wrongly. I ran `tsc --noEmit -p … --listFiles 2>&1` and counted with `grep -c .`, and on probe (ii) that stream carries **1,307 file lines plus the TS2353 diagnostic**, so the count read 1,308 and the delta read +10. The baseline had no diagnostic, so its count was honest; the probe's was not. A line count over a stream that merges two kinds of line is not a file count, and the failure is invisible exactly when the probe finds something, which is the case the count exists for.

Record it in the block in one sentence with the mechanism, attributed to the architect's sandbox reading, and record the delta as **+9** with the nine files named. It goes nowhere else: STEP 0 caught it, which is STEP 0's job.

## 2. (B′) stands, on `:2511` and not on row 3

Your precision is accepted and the block states it the way you did: row 3 was named as the reading that could overturn (B′) and it did not fire, so (B′) rests on SKILL `:2511`'s coupling fact alone (the root program is the Vercel build's type-check input, so shape (A) makes a crawl-spec typo a Production build failure). No letter arrived with the paste; the call remains the architect's and is overridable until HO 709 opens.

## 3. STEP 1 — `docs(HO 708)`: backlog, oddities, roadmap

- **`:14`, annotated in place, never struck.** Content as the handoff lists, with these figures as measured on the box: one error, `bundler-captures-706.spec.ts(67,9) TS2353`, runtime meaning `RM-SHIPPED=false` / `RM-CONTEXT=true`; seven of eight `e2e/*.ts` outside the program, `routes.ts` in by import from `seam-intervene-702.ts:49` and `mono-weights-697.ts:40`; `playwright.config.ts` and `next.config.ts` named into the class, both clean; the scratch clause corrected as *wrong when filed* against `.gitignore:47-55`, `tsconfig.json:51` and the scratch README (HO 672); (B′) as the fix shape for HO 709 with its basis; 709 eligible inside the week because `smoke.spec.ts` reads clean and is not touched; and the re-take of the 706 `1440-reduced` third against `cbt-705-n15` / `cbt-705-n16`, whose window closes when `backlog:51` closes on the week — 709 takes it or declines it in writing. Original body contained verbatim; prove containment.
- **Oddities, one dated HO-tagged note**, the row 5 finding in the handoff's wording: an instrument that names a property it does not measure. The type-only conditional is discharged.
- **Roadmap `Also (HO 708)` block:** the eight rows with the box's readings beside the architect's; the row 2 error verbatim; the row 5 pair; the nine-file set difference and the +10 correction from § 1; the seven-of-eight fact; the scratch correction; the SKILL list drift; the (B′) paragraph from § 2. OPEN LOOPS reconciled **247 live / 245 struck at open, unchanged at close** — no strikes, no additions. Pointer to 708.

## 4. `docs(method)` — the twelfth instance, landed verbatim after STEP 0 reads it against the tree

In § Gates, the bold header sentence changes in two places: **"Eleven instances."** becomes **"Twelve instances."**, and before its closing colon, after *"and one is an instrument that does not exist"*, insert: *"; and one is an instrument whose label asserts a condition its configuration never set, so every one of its passes was the first config's pass under a second name"* — re-derive the exact existing wording at your HEAD before editing it.

Append this bullet after the HO 685 bullet, before **What the gate requires**:

> - **HO 708 — a capture named `-reduced` whose context never set `prefers-reduced-motion` is a 1440 capture with a longer filename.** HO 706's capture gate ran three viewport configs and its third set `reducedMotion` in `test.use()`. That key is `BrowserContextOptions`, not `TestOptions`; Playwright's runner registers an unknown `use()` key as a fixture nothing consumes and loads the spec without a word, so 36 captures per role carried the tag and emulated nothing, and the comparison they passed was the 1440 comparison run twice. Measured at HO 708: the shipped form reads `matchMedia('(prefers-reduced-motion: reduce)').matches` **false** in the page, the documented form (`contextOptions.reducedMotion`) reads **true**, and `tsc` names the key as `TS2353` in under a second — from a file `npm run typecheck` had never read (`backlog:14`), which is why the fastest instrument in the repo was the one not pointed at it. Two rules: **an emulation is proven by reading the media query back inside the page, never by the option meant to set it**; and **a file outside the type checker's program carries instruments whose green is unverified, however many times they have run.**

Numstat on method: **1** deletion (the header sentence rewritten in place), the bullet pure append.

## 5. `docs(skill)` — alone, one line

`:2577` gains `e2e/bundler-captures-706.spec.ts` and `e2e/preserve-dumps.ts` in the list, and the parenthetical records the second drift in its own voice: *corrected at HO 708 rather than extended — two short again within eight HOs, `preserve-dumps.ts` from HO 702 and `bundler-captures-706.spec.ts` from HO 706*. The line is already moving, so its existing typo (*"a list this is read"*) may be fixed in the same rewrite. Nothing else in SKILL. Numstat **1/1**.

## 6. Commits, gates, paste

Three commits on `708-review`, kinds pure, in this order: `docs(HO 708)` · `docs(method)` · `docs(skill)`. The four regression gates immediately before the paste (`typecheck` 0 · `build` 0 · `check:odds-sites` 0 · `check:design-citations` OK), named as regression gates on a docs-only tree. Paste: `git show --stat` per commit, the backlog numstat with its one deletion explained by containment, the method and SKILL diffs in full, `git ls-remote --heads origin` with `708-review` at its SHA and `main` still at `61eab63`. Then hold for the FF go, which arrives as a file once the ref is read here.

read and follow 708-step0-ruling — the file, not this line
