# HO 673 — the bill panel: sponsor portrait always-on, cosponsor faces party-split, related bills format R2

**Read this file in full before executing anything. Execute in order. HALT conditions are hard stops — report and wait, do not improvise past them. Three HALTs: the mock reconciliation, the STEP 0 closure table, and the pre-land review ref. Nothing lands on `main` before the last is approved.**

Base: `main` at `ff535c8` or later. Clone fresh; verify HEAD before starting (`docs/method.md` § Session start). Number per method: max(roadmap pointer, highest commit-subject) + 1. Environment: code edit + `npm run build` then `npm run typecheck` (build first), plus local `npm run start` renders **with visual captures** — see the gate note below. **Bind check mandated on every start.**

## This is the first render-touching HO since § Gates was written, and that is not incidental

`docs/method.md` § Gates landed at HO 672 with a reopening criterion in its own text: *if the step is written and the next render-touching HO's paste carries no capture, the step is decoration and the entry reopens.* **This is that HO.** The visual requirements below are not boilerplate lifted from the section — they are the section being tested, and a paste without captures reopens a backlog entry closed three days ago.

Read § Gates before STEP 0 and follow it as written: named viewport set, a **separate** `prefers-reduced-motion` capture because it is a different layout and not a dimmer one, captures retained in the paste, and every instrument's zero stated with a control that can produce a non-zero.

## The ruling this HO executes

Corey ruled this design against three HTML mocks. The decisions, as ruled:

**Sponsor**
- The sponsor portrait is **always on** — not hover-revealed, not conditional on viewport.
- **80 × 94** at the base size.

**Cosponsors**
- **Six** face slots total.
- Slots are **party-split**: apportioned by the actual party breakdown of the cosponsor set, not fixed 3/3.
- **Unused shares redistribute** — if one party's share rounds to fewer faces than it is allotted, the remainder goes to the other rather than leaving an empty slot.
- **Names on hover.**

**Stage bar** — unchanged. Do not touch it. It is named here only so that "while I was in the file" cannot happen.

**Related bills — format R2**
- The **companion bill is promoted** into its own bordered line **above** the rest of the related list.
- The remaining related bills render below it in the existing treatment.

## STEP 0.0 — the mocks, and a HALT you may hit immediately

The ruling record is three files in `docs/design/`:

- `mock-673-sponsor-cosponsor.html`
- `mock-673-related-bills.html`
- `mock-674-topic-colour.html` — **HO 674's**, not this HO's. Named so it is not absorbed.

**They are untracked.** Method says clone fresh, so a fresh clone will not have them — this is the `docs/design/` dangling-instrument problem, filed at the HO 672 close, arriving on the very next HO. Do not fix the directory here; the filed entry owns that.

For this HO only, and on the HO 670 precedent (`landing.html` and `welcome-formats-mock.html` were committed mid-HO because that HO depended on them):

1. If the two `mock-673-*` files are present on the working box, **checksum both** and paste the sums. They are committed in this HO's docs commit as its ruling record.
2. If they are absent from the box you are working on, **HALT** and ask Corey to place them. Do not proceed from the prose spec above — it is my summary of his ruling, not the ruling.

**The mock wins on visual detail. This HO wins on scope.** If a mock shows something not listed above — a spacing change, a colour, a hover treatment — it is in scope only if it is inside the sponsor block, the cosponsor row, or the related-bills list. Anything outside those three is a finding, filed, not built.

**HALT** after the reconciliation: name every discrepancy between this HO's prose and the mocks, and which one you are following for each.

## STEP 0 — enumerate; closure table; HALT

Line numbers re-derived at your HEAD (HO 652). **Controls first.** Table (candidate · verdict · evidence `file:line` · destination) covering at least:

1. **The components.** Which file renders the sponsor block, which renders the cosponsor set, which renders related bills. Are they one component or three? Is any of them the bill *row* rather than the bill *panel*?
2. **Mount census for each — the HO 507 gate.** For every component you would edit: how many render sites, and which routes. **A component with more than one site, or one site outside the bill panel, is a shared surface** and either the change is scoped behind a prop or the component is out and a finding is filed. Paste the census; a bare "it's only used here" is not one.
3. **Portrait provenance.** Where a member portrait comes from — bioguide ID, a stored URL, a proxy route, `next/image` or a bare `<img>`. **Two things must be answered with evidence:** what renders when a portrait is missing, and whether always-on portraits introduce layout shift that the current hover-reveal did not. A fixed 80 × 94 box with a reserved area answers the second; confirm rather than assume.
4. **Cosponsor data shape.** Does the query behind the cosponsor set return **party per cosponsor**, and a **total count**? The party-split apportionment is impossible without the first and misleading without the second. If either is absent, that is a query change and it is a STEP 0 finding, not something to write inline.
5. **The apportionment rule, stated as arithmetic before it is coded.** Six slots, party counts `(d, r, other)`. Write the rule out — including what happens at `d=0`, at `other>0`, at fewer than six cosponsors total, and at exactly six. **Name the tie-break.** This is the one piece of real logic in the HO and it should be ruled on paper first.
6. **Related bills: is "companion" a distinguishable relationship in the data**, or is it inferred? If Congress.gov's relationship type is stored, name the field and the value. If it is inferred from bill number and chamber, say so — an inferred companion promoted into a bordered line is a stronger claim than the data supports, and the entry should know which it is.
7. **Read budget.** Do always-on portraits or the party split add any query or any per-row read? If the cosponsor party data is already in the payload, say so with the field. If not, price it the way HO 670 priced `/welcome`.
8. **Out of scope, named:** the stage bar; `mock-674-topic-colour.html` and anything it implies; the `docs/design/` tracking policy; every other route.

**HALT.** Paste the table. A verdict that changed from this HO's expectation is a good outcome, not a problem — say which and why.

## STEP 1 — the chore commit

`git checkout -b 673-review-local` first. One commit, one kind:

`chore(HO 673): sponsor portrait always-on, cosponsor party split, related bills R2`

## STEP 2 — gates

- `npm run build` ✓ then `npm run typecheck` ✓, in that order, **re-run immediately before the paste** — § Gates, *a gate binds to the state at the paste, not to the state when it ran.*
- `git show --stat` lists only the approved files.
- Greps with controls, per § Gates.

## STEP 3 — runtime and **captures**; HALT

Bind check first: private port, PID captured, verified as the port owner before any curl.

Content assertions are necessary and **not sufficient** — HO 670 shipped three render defects past a full set of green greps and 200s. Required:

1. **Captures at a named viewport set**, chosen and stated before running, wide through narrow.
2. **A separate `prefers-reduced-motion` capture.**
3. **A bill with zero cosponsors**, one with **fewer than six**, and one with **many** — the apportionment's edge cases are visual, and a screenshot of the six-cosponsor happy path proves the least interesting case.
4. **A bill whose sponsor portrait is missing**, if one exists — the fallback is the thing most likely to be wrong and least likely to be looked at. If no such bill exists in the corpus, say how you established that.
5. **A bill with a companion and one without**, for R2.
6. Console clean; no horizontal overflow; the stage bar visually unchanged against a before capture.

**HALT.** Paste the captures and the readings.

## STEP 4 — docs commit (`docs: HO 673 — …`)

- **`docs/design/`** — commit `mock-673-sponsor-cosponsor.html` and `mock-673-related-bills.html` with their checksums recorded in the roadmap block. **These two only.** The other thirteen untracked files are the filed entry's business.
- **`docs/backlog.md`** — any STEP 0 finding, each with a close criterion that can fail.
- **`docs/roadmap.md`** — one `Also (HO 673)` block, append-only: the ruling and who made it, the apportionment rule as arithmetic, the companion-relationship provenance (stored vs inferred), and the captures taken.
- **`docs/oddities.md`** — only if something odd emerged; if nothing, say so in the block.

## STEP 5 — SKILL commit (`docs(skill): HO 673 — …`), self-mod guarded

Its own commit. Minimal edits per the approved classification. Classify every hit LIVE-CLAIM vs RECORD first. **No changelog append** unless client-island membership changed — if hover names require a client boundary that did not exist, it did, and the HO 665 criterion applies.

## HALT — the review ref

`git push origin HEAD:refs/heads/673-review`. Paste: table deltas, `git show --stat`, STEP 2/3 outputs **including the captures**, the backlog numstat with every deletion explained (a strike is an edit; `grep -c '^-[^-]'` is not a deletion count — and § Gates now carries the reproduction), and the docs + SKILL diffs.

**Deliver the SKILL diff with `--word-diff=plain`, never `--word-diff=color`** (HO 672: a colour-only export is indistinguishable from an empty one), check it carries markers before offering it, write it to the gitignored artifacts directory, **and tell Corey explicitly to attach it to the chat.** Writing the file is not delivering it.

Remote claims via `git ls-remote`. **The SKILL diff needs explicit approval.** After approval: fast-forward `main`, delete the ref, verify with `git ls-remote --heads origin`.

## Out of scope — named so it is not absorbed

- The stage bar.
- `mock-674-topic-colour.html` and HO 674's feed-row work entirely.
- The `docs/design/` tracking policy — filed, its own HO. Committing this HO's two mocks is the HO 670 precedent, not the start of that fix.
- The non-atomic summarize write pair; `HeaderBar` `IN BETA` + clock; `--font-mono` → Plex Mono; the `/welcome` tape unification; `/api/version`'s `builtAt: null`. All filed, none due here.

---

read and follow 673
