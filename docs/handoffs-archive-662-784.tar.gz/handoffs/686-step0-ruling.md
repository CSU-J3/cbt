# HO 686 — STEP 0 ruling

Verdict table accepted as read: three HEALED, AZ-03 UNHEALED with no recovery available, zero recovery owed, STEP 1 skips. All three deviations endorsed — the two purpose-built instruments were the right call (the 661 script is set-level and could never answer rows 2–3), the wrong-table premise was mine (`race_candidates` for `primary_candidates` — capability intact, ordinary handoff error, no ledger entry needed beyond the strike's premise-corrections line), and the verdict vocabulary needed the third value you gave it.

**The judgement call — ruled as you proposed:** the off-by-one is a **filing error, not a code defect**. The predicate behaved exactly as designed at its first live window crossing; the filed dates were hand arithmetic (`+30`) beside a strict-inequality predicate that first flips at `+31`. The oddity carries the general lesson, which is the "measurement is about the table it was taken on" family wearing dates: **a deadline filed against a predicate must be derived by running the predicate, never by arithmetic beside it.** Note in the same entry that the error was benign twice over — the three not-yet-expired rows were already frozen on the decided term, and the late AZ read lost nothing because the sync had re-visited inside the window anyway.

**One amendment — the commit shape.** "Docs-only" would either mix kinds or strand the instruments. `settle-window-686.ts` and `settle-upstream-686.ts` are tracked code; they get their **own small code commit** (read-only diagnostics, the `settle-predicate-661.ts` precedent), then the docs commit. Two commits, kinds pure.

**Docs commit contents, with placements:**

- **Strike** the settle-windows entry with the four verdicts and dates, the off-by-one correction, and one precise sentence so nobody re-opens it tomorrow: the three 09-04 floors are moot because all three rows are frozen on the *decided* term — the read is complete and final today, a day before their expiry term could bite.
- **Successor entry** for the next windows: `house-AK-00-2026-open` + `senate-AK-2026-open`, scored + uncalled, in-window now — with floors **derived by the new instrument**, not arithmetic, stated in the entry as such.
- **AZ-03 rider**, trigger-gated: settled-unhealed by expiry, upstream genuinely carries no winner for that one contest (control-validated), both recovery scripts structurally no-op on it, severity bounded — unrated, so no downstream consumer reaches it. *Promote:* if AZ-03-2026 ever acquires a rating or enters the races index, the missing winner becomes visible and the row needs a hand decision.
- **Class-4 finding** (78 newly-expiry-settled, 75 pageless): place as a rider on the existing roster-coverage-debt family if the classes match on inspection; its own line only if they don't.
- **ME-D/R long-expired residuals:** rider on their existing scored-uncalled family line.
- **Roadmap** `Also (HO 686)`, pointer → 686: four verdicts one line each, the predicate's first live crossing behaving as designed, the filing-error correction, and the honest premise-corrections sentence.

Then STEP 4 as written: review ref, ls-remote, architect review, FF on approval.

Proceed: STEP 3 with the amended shape.
