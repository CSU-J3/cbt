# HO 712 — FF go (architect, 2026-09-11)

**Owner verdict, verbatim: "send it"** — Corey, CBT maintenance chat, 2026-09-11, on the architect's read of `712-review` at `bc77e3b` off the remote: seven commits, kinds pure; the amendment delta from `5202735` is confined to the label family (`app/members/[bioguideId]/page.tsx`, `app/members/page.tsx`, the four label components), `lib/queries.ts`, `lib/participation-refresh.ts`, `scripts/migrate.ts`, SKILL and the two docs; `ad63b85` is an ancestor, so the move is a clean fast-forward. The Preview `narrow-preview` run on the amended tip (`34652004792`, 74 passed) is green; `34650454661` is the pre-amend tip and is ignored. The data half already happened and was read back: `member_participation.congress` added and populated by the cron's own writer (556 rows, `DISTINCT congress = 119`, zero NULL), the `sync:members` no-op run both pinned and derived, and the January sequence proven in a fixture in the order January will run it.

**What this FF is.** The first deploy in which no congress-scoped path hardcodes the 119th, the roster sync cannot inactivate the chamber on a partial answer, and every congress label over a number reads the number's own row. Rendered output is byte-identical today by DOM diff on all four touched routes (+0 / −0); the change is what happens on 2027-01-03, and the fixture is the only place that day has run.

## 1. The move

- `git ls-remote --heads origin` immediately before: `main` at `ad63b85`, `712-review` at `bc77e3b`. Anything else, stop and paste.
- On `main`, the cleanup door: `git merge --ff-only bc77e3b`; `git rev-parse main` must print `bc77e3b`. `git push origin main`, no force. `git push origin --delete 712-review`. Then `git ls-remote --heads origin` and `git ls-remote --tags origin` (three tags).
- Each state-changing command on its own line, stderr never suppressed. The commit list in the paste is `git log --oneline ad63b85..main` off the pushed branch.

## 2. The readings

- `npm run verify:deploy` until the served SHA is `bc77e3b`, five consecutive reads; if promotion lags past the timeout, paste the deployment list rather than wait it out.
- **Served, off production:** `/members/B001323` reads `Missed · 119th` with the ordinal coming from the row (the DOM position is unchanged; the paste says which loader supplied it); `/members` participation strip label `119th` and the ideology tooltip naming the 119th; `/` absence band card backs `119TH MISSED`; `/welcome` credit line `119th Congress · congress.gov` from the clock, as ruled. One `curl | grep` for the literal string `${` across those four served pages reading **0**, the check that found the placeholder the harness missed.
- **The cron path, once, in production:** trigger the participation refresh by its real entry (the cron route with `$CRON_SECRET`, or the same script the sequence used) and read back `refreshed 556 rows` with `DISTINCT congress = 119`, so the deployed writer, not the local one, is the one proven to write the column.
- The Production `deployment_status` run: id and conclusion, the resolved-group echo, the `smoke` / `odds-off` / `narrow` lines for `members`, `member-detail`, `welcome`, `dashboard` at both widths with `over=0`, the wall time against the cap, and any `pageErr` hit pasted per-hit.
- `ci.yml` conclusion.

## 3. After the FF

Nothing else is owed by this HO. The **120th-Congress rollover checklist (2027-01-03)** is now a dated backlog line with owners and instruments: `sync:members` after the swearing-in, never before; the enacted-laws series to 119-vs-120; the stale-procedural list extended for the 120th's opening week; the twelve labelled numbers with their scope question; `PolarizationOverTime`'s constants; the `cd119` asset; the Voteview publication lag; the participation-cost trigger. The two-Grahams and flight-payload oddities carried from HO 711 are filed.

## 4. Paste

The `ls-remote` line showing `main` at `bc77e3b`, the ref gone, three tags; `git rev-parse main`; the seven-line log; the five served reads; the served readings in § 2 including the `${` grep and the deployed refresh's read-back; the Production run's id, group echo, spec lines and duration; the `ci.yml` conclusion.

read and follow 712-ff-go — the file, not this line
