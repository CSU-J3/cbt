# HO 771: resume. The daily cadence ships anyway, your claim-3 calls stand, and the fetch records what a refusal looked like

## Why it ships now

Your reading changes my earlier call:
- **The route is already red.** A daily run adds no new red, only more `error` rows.
- **Sabato's posture moves.** The same agent got a 200 at 00:55Z and at 05:30Z on 10-10, and a challenge at 17:53Z. A daily read gives each day a chance, and it costs Sabato one GET a day.
- **The sources reopen on someone else's schedule.** IE, Sabato and Cook could each say yes on any day. The next morning's run then picks it up, not the next Wednesday's.

So HO 771 goes on now, and HO 770's FF go is done as it stands. There's no manual POST: the daily cron is the reading from here.

**Nothing more is fetched from centerforpolitics.org from your box.** The legs use saved pages and local servers.

## Claim 3

The ruling's three changes stand. Your calls stand too.

**Change:**
- `app/api/cron/summarize/route.ts:12`;
- `lib/move-freshness.ts:29`, where *for a week* becomes *for a day*;
- backlog `:71` and `:473`, each with your clause.

**Stay:**
- backlog `:75`;
- the route header's `:32`, `:38` and `:40`;
- `lib/race-ratings-scrape.ts:226`;
- `lib/cron-health.ts:41` and `:44`;
- SKILL `:1240`'s *for two Wednesdays*;
- the tracked old handoffs.

## § 2, new: what a refusal looked like (fix)

On a non-2xx answer, `fetchSource` throws with the status alone. That's why pdx1's 403 can't say whether it was a challenge or a block.

On a non-2xx it now reads the body inside the same 8s budget, and puts the refusal's shape into the thrown message:
- the status;
- `cf-mitigated`, `server` and `cf-ray`, when present;
- the body's size;
- an HTML `<title>`, up to 80 characters.

For example: *-> 403 (cf-mitigated challenge, server cloudflare, cf-ray a487939fd8215380-SEA, 5,572 bytes, "Just a moment...")*.

The rules around it:
- **Nothing private goes in.** The message still goes through `fetchError`, so it's redacted, and no request header is included.
- **A body that doesn't arrive in time** still throws, with the status and the headers it has.
- **Our own timeout is unchanged:** status 0.

**The legs**, in `scripts/diagnostic/ratings-daily-771.ts`:
- a local server answering 403 with a challenge-shaped page and those headers: the thrown message carries every field;
- a local 404 with none of them reads as before, plus its size;
- the control: a silent host still throws status 0 at 8s.

**Commits:** § 2 is its own `fix` commit, after § 1's `feat`.

## Docs additions

**backlog:**
- **A new line, Sabato.** Cloudflare challenges the honest agent from both networks:
  - this box at 17:53Z and 18:09Z on 2026-10-10, Cloudflare's managed challenge (`cf-ray` `a4877b7b8b0659d4-DEN` and `a487939fd8215380-DEN`);
  - pdx1 at 18:33:31Z (#23996, 403), its shape unrecorded until § 2.
  - *Owner:* Corey, who asks the Center for Politics to allow the agent. The reader is built and wired, so nothing is owed by Code. *Close:* the first scheduled run reading `success` with `stats.raters.sabato` ok in both legs. *Reads if never done:* Sabato's rows hold Ballotpedia's 09-30 reading through Election Day.
- **The ratings WATCH** records #23996 as the deployed path's first read of Sabato: refused, 403, nothing written. Its dated field moves to the first `0 11 * * *` run, as HO 771 has it.

**roadmap:** the HO 771 block opens with HO 770's FF go as taken, both pastes: the FF, `verify:deploy`, `e2e-prod`, the MOVED baseline, the three challenges, #23996, the read-back, the flush, and the tracker and health reading.

Everything else in HO 771 stands. Build through to the review push without stopping, then send one paste, as HO 771's list has it, with § 2's legs added.
