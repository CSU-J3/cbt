# HO 731 — STEP 0 ruling and the go

**Branch A stands. Proceed.** SEVEN REACHED on 2026-09-16, both controls FIRE at 2 and 10 hits, 36 ZERO and 0 FIRE across 80 in-window rows, exit 0, and the 09-17 daily plus 28 Production samples all ZERO, so C is correctly ruled out on the reading rather than on the absence of one. The two independent classifications — `head_branch` on all 44 SKIPPED rows, and `cat-file` plus the genuine absence of `e2e/routes.ts` at `a504c10` / `1fee081` — are both reads the instrument cannot make about itself, which is the right instinct: the ledger's Preview label is derived from its own verdict and proves nothing about the environment.

## Four corrections accepted, three of them mine

1. **STEP 2's HALT rule is mis-scoped.** Scope it to `chamber = 'house'`. A NULL district on a Senate row is the schema working (`scripts/migrate.ts:457`, TEXT nullable); halting on it would have been a gate firing on its own target.
2. **The worktree quantity is wrong, and your replacement is right.** The block records the recipe, not the SHAs: `git worktree add --detach <path> 97223d0`, that commit's own `package.json` at `next: ^15.5.15`, `npm install`, `next build --webpack`. Record beside it what `--force` discards — n16's uncommitted `typescript: { ignoreBuildErrors: true }` in `next.config.ts`, self-labelled throwaway — so the removal names its own cost. Nothing unshipped is lost; the 706 bump is on `main`.
3. **`method.md:464` carries three false clauses and gets rewritten in this HO's `docs` commit.** Both worktrees sit at `97223d0`, an ancestor of `main`, so *"neither an ancestor of anything that ships"* is false; the two SHAs are one SHA; and the lever is not runnable without dependencies. The bundler half of that bullet (Turbopack default, `--webpack` as the instrument fallback, preconditions not surviving a toolchain change) is true and stays. The worktree half becomes the recipe plus one clause saying the pair was removed at HO 731 and why they were kept until then.
4. **My row-8 clause was wrong as written.** *"A `FROZEN NOW true` today means the floor is not tomorrow"* conflated the two terms; it should have read *"true with the **expired** term true."* Same class as the anchor drift you re-derived: I cited spans (`:66`, `:303-307`) around greps instead of the single lines I had actually read. Use your numbers.

## Q1 — yes, STEP 1 runs tomorrow, for a different reason than it was written for

It no longer catches a flip; the flip happened by the decided term between `:554`'s 2026-09-03 snapshot and the 09-15/09-16 writes. What it still buys is the one thing `:554` exists to enforce: that the expiry date is a reading rather than arithmetic. Landing a rewrite that *predicts* tomorrow's expiry, in a line whose whole point is that floors are derived by running the instrument, would repeat the error the line was written to prevent. So the HO holds overnight and lands once.

It is still a check that can fail, which is why it is worth a command: the expired term reads false tomorrow (floor derivation or clock wrong), or the decided term reads false (a re-check unmarked them, which would be a finding about the recovery, not about the floor). Print both terms per row, not the composite.

**One addition, because "a recovery ran inside the window" is currently an inference from `updated_at`.** Read which path ran: `SELECT started_at, status, elapsed_ms, payload FROM cron_runs WHERE route = '/api/cron/primaries' AND started_at >= '2026-09-14' ORDER BY started_at` (`scripts/migrate.ts:501-510`; the route is registered daily at `0 12 * * *`, `lib/cron-health.ts:70`). If the scheduled cron healed both rows, that is the better fact and it belongs in the block: the HO 661 re-check window did exactly what it was built to do, with days of margin, and the expiry term was never reached.

**Before the FF, one cheap freshness check, not a re-harvest.** The 09-18 daily lands during this sitting. Convention 1 says a conclusion is not a reading, so check it the only way that counts: `npx tsx scripts/diagnostic/pageerr-ledger-723.ts --since 2026-09-18T00:00:00Z --control 33794231177 --out docs/handoffs/731-artifacts-2`. One run, about a minute. If it reads ZERO, the block says so and the strike lands current. If it reads FIRE, **branch C applies and nothing strikes** — the same rule that already covers the post-FF Production sample. Do not re-harvest the full window; the criterion is the named seven and they are read.

## Q2 — yes, the reshaped question, and the anomaly is the read

Confirmed: STEP 2 now asks *is the DB's four-winner state a faithful read of the page, and why is the House marked set not the top four by share.* Same instrument, same `chore`, per-chamber controls unchanged (`senate-RI-2026-D` / `-R` via one `scrapeSenateCandidates("RI","Rhode_Island")` is the right pick).

**The discriminator, because "the page marks four" and "the parser marks four" are currently the same output.** `isWinner` is `/class="results_row[^"]*\bwinner\b/` against the row's own markup (`lib/primary-candidates-scrape.ts:212`). So for the AK House page only: keep the fetched HTML in `docs/handoffs/731-artifacts/`, and print per candidate row the raw `class="results_row…"` value plus any annotation text inside the row. That is a read of the same bytes the parser sees, with no second parser and no new claim.

**The hypothesis to test, stated as one so it is not read back as a finding:** Alaska replaces a top-four advancer who withdraws with the next finisher, and the marked set `{1, 2, 4, 5}` with Schultz (8.1%) unmarked is exactly what that produces. If the page carries a withdrawal marker on Schultz's row, the parse is faithful, the recovery worked, and there is no defect anywhere.

Filing rules, by what the read finds:

- **Page marks four, Schultz's row carries a withdrawal/replacement annotation.** No line about correctness. One WATCH line instead, owner Code: *the marked set is not top-N by share, by design, and no future instrument may assert that invariant* — this is the "count invariant blind to its own source" shape in advance, and it is worth a line precisely because the next reader will find `{1,2,4,5}` and assume a parse bug.
- **Page marks four with no annotation distinguishing Schultz.** The anomaly is upstream and unfixable by us: WATCH, owner Code, with the URL, both sets, and the note that our stored state mirrors the page faithfully.
- **Page and DB disagree in any direction.** That is ours: OPEN LOOPS, owner Code, with the upstream URL, the marked set upstream against the stored set, and `backfill:primary-results` / `reingest:primary-slate` named as the recovery.

**Two vocabulary facts to carry into the block, already read here so you do not re-derive them.** `primary_candidates.status` is written binary — `c.isWinner ? "winner" : "running"` at `lib/primaries-sync.ts:723`, `:995`, `:1433` — so in a top-four contest `winner` means *advanced*, and a candidate who withdrew is indistinguishable from one still running. The consumer that matters reads it correctly: `lib/harvest-challengers.ts:50` joins on `pc.status = 'winner'`, and in AK all four advancers really are on the November ballot, so four rows is the right answer there. The display side is a register question, not a build: `components/RaceRunoffs.tsx:38` renders `status === "winner"` as *"Won"*, which is true of an advancer only by courtesy. File that one as a register line for Corey, no recommendation attached, in the HO 718 form.

## What `:554`'s rewrite says now

Its prediction is falsified and the rewrite says so in those words rather than quietly re-scoping. Top-four RCV is **not** structurally unmarkable: Ballotpedia marks every advancer with the same per-row winner class, so the class HO 661 built the expiry term for turns out to heal itself. Carry: the re-derived floor (2026-09-18, by simulation, both rows); frozen by the **decided** term one day early; four winners each, `updated_at` 09-15 and 09-16; the shares that moved since 09-03 (Begich 46.1→44.6, Peltola 48.1→49.5, Sullivan 42.7→41.4); which path wrote them, from the `cron_runs` read; and the upstream verdict with its control. Then the successor from `settle-predicate-661.ts` class 1 (`:117`) as the handoff already specifies.

Repair the fragment while rewriting — the *"…owed anything. the decided-or-expired predicate…"* splice — and do not carry the superseded four 2026-08/09 rows forward as though they were current; they are in the struck predecessor above the line.

## Also on disk, and not this HO's job

`cbt-631-render` (`24cb7cd`) and `cbt-706` (`29026da`, branch `706-review`) are named nowhere, and `ls-remote` shows `main` as the sole remote head, so `706-review` is a local leftover from that FF. One OPEN LOOPS line, owner Code, low: both paths and SHAs, closed when each is either named in `method.md` § Environment with why it is kept or removed. Remove neither here — a worktree this HO did not reason about is not one to delete on the way past.

## Gates, unchanged plus

Everything in the handoff's Gates section still applies. Additions: the pre-FF single-daily ledger run pasted with its verdict; both settle-window terms printed per row on the STEP 1 read; the AK House page's raw row classes pasted beside the parsed output; the `cron_runs` rows; and `git worktree list` before and after the removal, with `git worktree prune` between the two reads. The no-args run of the extended upstream instrument stays the default-path control.

## Scope guard

Nothing else gets added on the way through. The four-winner render register line is filed, not fixed. The status vocabulary is filed, not widened. `harvest-challengers` is read, not touched. If the AK House page turns out to be a genuine upstream inconsistency, it is a WATCH line and not the start of a recovery arc in this HO.
