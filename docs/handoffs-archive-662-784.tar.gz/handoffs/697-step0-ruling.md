# HO 697 — STEP 0 ruling (architect, 2026-09-05). Row 1 waits on one word from Corey; everything else proceeds.

Rows 2–6 stand as measured. All three corrections to the handoff are accepted; two change the build and one is recorded as the architect's error.

## 1. Placement — Corey's word, with a recommendation

The captures are in the Code session and not in this file, so the ruling is framed here and given there. **What the default produced, from your reading:** the tag sits at **11px on `/`** (the mast line, beside sync · auth · clock) and at **16px on inner pages** (the title row, beside SIGN IN · ODDS), because the two mastheads put their auth cluster on different rows. A status tag that changes size by half between routes reads as two different elements. **The move that gives one size everywhere:** on inner pages the tag leads the `LAST SYNC` subhead (`[ IN BETA ] · LAST SYNC 9:14 PM ET · SAT 05 SEP 2026 · 7:32:10 PM MT`), the 11px rung, the same line the clock already joined. The dashboard stays as built. **Architect's recommendation: the move.** Corey's word is one of *"as built"* or *"sync line"*; absent a word, as built ships, per the handoff's pre-ruling. Either way the ruling is quoted in the block with its provenance (this chat, against the four captures).

## 2. `/welcome` keeps 13px — restore it, no word needed

The 670 ruling fixed the rail's look, and a shared class must not restyle a ruled surface as a side effect; the flag was right. Keep `.beta-tag` size-agnostic and give the rail its rung back in the module: `.rail :global(.beta-tag) { font-size: var(--fs-13); padding: 5px 0 }`, the RECORD comment rewritten to say the size lives on the rail, not the class. Re-capture `/welcome` at 1440 and 430 after; the tag must read 13px and the rail's height must match the before capture. Corey can still say *"12"* if he prefers the smaller tag; it is his page, but the default is the ruled one.

## 3. Rows 2 and 3 — accepted, with the specimen on the record

Row 2's inert verdict is good because it carried a control (`fonts.check` true) and a second instrument (advance width) beside the pixel diff. Record the specimen string in the block, so *inert* reads as *inert for these glyphs*: the alternates a stylistic set could target are exactly the ones you rendered (`a g l 0 O 1 I` and the digits). C2 drops the declaration and the commit says why. Row 3: load all four weights; 273 elements at 700 across six routes is small and real, and synthesised bold on `/bills` is not a rounding.

## 4. Row 4 — one reading is missing

`/` 430/430 and `/bills` 430/430 are the readings the row asked for. **`/members 1440/1440` is not**: the row named `/members` at **430**, the roster route HO 694 fixed at that width and the one whose `LAST SYNC` line is most likely to be tight. Take it. If it reads clean, no prop; if it overflows, the conditional fires and `dateClassName` is built as specified.

## 5. Correction 3 — accepted

Neither existing reduced-motion block is a chrome block; a block beside `@keyframes betafade` is the file's own pattern. Named rather than silently joined is right.

## 6. What is tracked

Two probes tracked because findings rest on them is right, and the rule reaches two more: **the capture driver** (the four captures are gate evidence, and the block will cite them) and **the row-4 overflow reader** (a negative finding decided not to build a prop). If the driver is `chrome-shots-690.ts` with new routes, extend that file rather than copying it; if it is new, it is `chrome-shots-697.ts`, tracked. `scratch/` keeps only what produced no recorded number.

## 7. Then

On Corey's word: C1 (with §2 and, if ruled, the sync-line move) → C2 → the probes → SKILL alone (five touches, `:1931` included) → docs → `697-review`. The block records the placement ruling as a quotation, the `/welcome` restore, the row-4 `/members` reading, and the third render site.

read and follow 697 — STEP 0 ruled; row 1 on Corey's word
