# HO 696 — STEP 0 ruling (architect, 2026-09-05)

Both tables stand. All three findings against the handoff are accepted; one changes SKILL text, one adds a sentence to the method commit, none changes the build. One new row is added before STEP 1, and one backlog line is annotated because the table surfaced it.

## 1. Table A — 12 COMMIT, 1 SCRATCH

As proposed. `floor-votes-section(1).html` rests on the handoff's pre-ruling (a differing `(N)` duplicate goes to `scratch/` unless Corey names it the ruled version); the evidence you read (no provenance header, no HO title, 44 lines shorter) says it is the earlier iteration, and nothing tracked cites it. **Absent a word from Corey, SCRATCH.** His word can move it to DELETE; the evidence supports that too. After-figure on the working tree: **32 tracked · 0 untracked · 1 ignored** (32 · 0 · 0 on DELETE). Record blob hashes in the block via `git cat-file -p HEAD:<path> | sha256sum`; where a blob hash differs from Table A's disk hash, say *line endings normalized on commit* rather than leaving two hashes to disagree in silence.

## 2. Table B — six findings, your counts

Six predicted, six found. Your figures replace the handoff's: **21 prefixed targets, 18 resolve, 3 dangle, 1 malformed; 7 bare mock-N, 5 resolve, 2 dangle.** The block carries yours; the handoff's 20/17 was a regex that refused `/` in the tail and is recorded as the estimate it was.

## 3. Finding 1 — accepted, and it is the architect's error

Replace the STEP 6 bullet's opening with your wording, verbatim: *"`design-citations.yml` (HO 696) is the third workflow, and the only one that runs on push and PR with no path filter."* The handoff's ground truth listed `e2e-prod.yml` two bullets above the sentence that said "second"; the failure was not a recall but a composition, which is why the reading rule did not catch it. Record it in the block as the **seventh consecutive HO corrected at STEP 0** (690–696), second consecutive of this exact class after 695 F1. **The method commit gains one sentence, marked as a widening so Corey can strike it**, appended to the ground-truth bullet in § Handoff discipline:

> The same holds for every factual clause in text a handoff asks to land verbatim: STEP 0 reads it against the tree before it lands (HO 695 and HO 696 each shipped a SKILL sentence that named a repo state the repo contradicted).

## 4. Finding 2 — accepted

One clause at `:2570` changes, one is verified unchanged. Nothing owed.

## 5. Finding 3 — accepted

Covered in §2.

## 6. New STEP 0 row — is `mock-591-conventions.html` the C1–C8 dictionary?

Not a guess; a read. `layout-conventions-arc.md:31` describes the missing artifact as *"the defect/fixed dictionary, for routes that look nothing like the dashboard"*; the HO 604 block says a copy survived only in the design chat; SKILL `:1946` calls it not yet landed. A 36 KB file named for HO 591, the conventions' origin, dated 08-06 inside the 603–604 sweep, is the `welcome-670.html` shape: the handoff expected one name and the file carries another. **Open it; paste `<title>` and the section headings.** If it enumerates C1–C8 with defect/fixed pairs, it is that artifact and three things move: SKILL `:1946` is corrected in the SKILL commit (the visual dictionary is `docs/design/mock-591-conventions.html`, landed HO 696 at the name it carried on disk; the 604 expectation recorded as a name mismatch), `layout-conventions-arc.md:31` gets a one-line pointer correction with provenance (a plan-of-record doc, not the roadmap), and the `layout-conventions-c1-c8.html` allowlist entry is **not seeded**, because no prefixed citation of that name would remain (roadmap `:425` is bare and outside the grammar). The seed set is then two; `never-landed` stays in the vocabulary as the reason a future unlanded artifact would take; STEP 5's falsification (ii) reads *exactly the allowlisted set*. If it is not the dictionary, everything as written.

## 7. The convention is older than the handoff said

Table A shows `mock-507`, `mock-509`, `mock-510`, `mock-591` on disk, so the `mock-<HO>-<slug>.html` name has been in use since HO 507 and was first *committed* at 629. The README and the block say that; the handoff's "since 629" is corrected. G2 therefore reaches further back than stated, which is the good direction.

## 8. `backlog:45`, the stale momentum layer — annotate, do not close

Its close is *an enriched-row design mock lands*, and `stale-momentum-row.html` (2026-06-26, two days after the entry opened) has been sitting untracked since. Committing it does not close the entry: whether it is the ruled row presentation is unrecorded. One annotation line, dated, naming the file and that the ruling is unrecorded; the entry stays in the design chat's court. Filed here because it was caught in relay.

## 9. Three shells still running at the HALT

Name them and kill by PID what is yours before STEP 1 (SKILL, "Process cleanup"; method § Gates, HO 672: a process that is supposed to have stopped is verified stopped). If they are the sha256 loops, say so.

## 10. Everything else as written

The scanner is written first and read against the base tree as the control; the two plants are described in words in every tracked file; the counts are taken on the working tree, not in a clone; the `.gitignore` check is `git add --dry-run`.

Proceed to STEP 1 on this ruling.

read and follow 696 — STEP 0 ruled, proceed
