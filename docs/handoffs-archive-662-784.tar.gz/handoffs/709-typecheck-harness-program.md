# HO 709 — `backlog:14` closes: the harness gets its own type-check program, and the 706 capture spec proves its emulation

HO 708 measured the gap; this HO closes it under shape (B′) and takes the reading 706 never took. Five commits, kinds pure: `fix` (code) · `ci` (one comment) · `docs` · `docs(skill)`, with the reduced-motion re-take run between the code and the docs so the block can carry its result. `main` is at `918b52b` and this is 709 (pointer 708, highest HO in subjects 708); re-derive both.

**Why it runs inside the `#418` week.** `e2e-prod.yml:246` runs `npx playwright test e2e/smoke.spec.ts e2e/odds-off.spec.ts e2e/narrow.spec.ts --grep-invert "@nonci"`. The only `e2e/` file this HO touches is `bundler-captures-706.spec.ts`, which that line never names and which is tagged `@nonci` besides; `smoke.spec.ts` read clean at HO 708 and is not opened. The one workflow edit is a comment in `ci.yml`, whose runs the count does not read. Quote `:246` verbatim at STEP 0 so the block can say this from the file rather than from this paragraph.

## Ground truth (read at `918b52b`; re-derive every `:N` by content)

- `tsconfig.json:36-48` `include` (`next-env.d.ts`, `app/**`, `components/**`, `lib/**`, `scripts/**/*.ts`, `types/**/*.d.ts`, `auth.ts`, `.next/types/**/*.ts`, `.next/dev/types/**/*.ts`); `:49-52` `exclude` (`node_modules`, `scripts/diagnostic/scratch`); `compilerOptions.incremental: true`. `.gitignore:9` lists `tsconfig.tsbuildinfo` and nothing else of that shape, which is why the new config sets `incremental: false`.
- `package.json:59` `"typecheck": "tsc --noEmit"`. `ci.yml:55-56` runs `npm run typecheck`, so chaining the second program into that script covers CI **with no workflow step edit**. `ci.yml:11-13` is the comment HO 708 quoted; it is wrong for `e2e/**` today and becomes true as written once it names the second program.
- `e2e/bundler-captures-706.spec.ts` is 88 lines. `:56-60` `VIEWS` (`1440`, `2560`, `1440-reduced`; the third `reduced: true`); `:65-68` `test.use({ viewport, reducedMotion })`; `:71-84` the test body (`addCookies`, `goto`, `waitForLoadState`, 1,200 ms settle, `toHaveScreenshot` with `animations: "disabled"`, `maxDiffPixelRatio: 0.002`). `:51-54` `CAPTURE_FROM` (`:3000`), `CAPTURE_AGAINST` (`:3007`), `CAPTURE_ROLE`. Its header (`:20-35`) is the flush rule: both servers, every tag the routes read, before any pixel; and HTML diff before PNG on any failure. Snapshots are ignored at `.gitignore:85`.
- `next.config.ts` (28 lines, three redirects) compiled clean inside the root program at HO 708 probe (ii); `playwright.config.ts` compiled clean inside the e2e probe.
- HO 708 probe (i) reads: with `e2e/**` + `playwright.config.ts` as a program under the root `compilerOptions`, exactly one error, `bundler-captures-706.spec.ts(67,9) TS2353`. That error is this HO's built-in control: the new gate must go red on it before the fix and green after.
- `docs/method.md:436` keeps `cbt-705-n15` (next 15.5.15, webpack) and `cbt-705-n16` until `backlog:51` closes on its week; both detached. Their builds, ports and the 706 flush-tag list are in the HO 706 block and `docs/handoffs/706-artifacts/` if it exists on the box; STEP 0 row 5 reads what is actually there.
- SKILL `:2511` (*"`scripts/**` is in `tsconfig`, so a throwaway probe that doesn't typecheck fails the Vercel build"*) and `:2584` (*"CI is typecheck + `check:odds-sites` + build"*) are the two lines this HO extends. `:2577`'s harness list does not change: `tsconfig.e2e.json` sits at the root and is outside that line's `git ls-files e2e playwright.config.ts` check, which is why it is named in the CI bullet instead.
- Estimate, not a reading: the re-take is 36 captures per role plus flushes and two server starts, on the order of twenty minutes; 706's self-control measured live-data drift at 1 in 108, so one or two failures that pass back-to-back are the expected texture, not a finding.

## STEP 0 — enumerate, HALT

| # | check | expected | if the work never happened, this reads |
|---|---|---|---|
| 1 | `git ls-remote --heads origin`; `git status --porcelain`; pointer and highest HO | `main` at `918b52b`, no other heads; tree clean; 708 / 708 → 709 | anything else stops here |
| 2 | quote `e2e-prod.yml:246`, `ci.yml:11-13`, `ci.yml:55-56`, `package.json:59`, `tsconfig.json:36-52`, `.gitignore:9`, `bundler-captures-706.spec.ts:65-68` | as in ground truth | a `:246` that names the capture spec, or a CI step that runs `tsc` directly instead of `npm run typecheck`, changes the plan and is pasted before anything moves |
| 3 | baseline `npm run typecheck` exit and count; root `--listFiles` counts for `e2e[\\/]smoke.spec.ts`, `[\\/]next.config.ts` | exit 0 · 0 · **0** · **0** | this is the pre-state, and a match here is the defect still present, not progress; a non-zero baseline means a stale `.next/types`, so `npm run build` then re-take, and never delete `.next/` in the shared checkout |
| 4 | `npx playwright test --list e2e/bundler-captures-706.spec.ts`, exit and test count | exit 0 · 108 | the spec still loads with the bad key; that is HO 708's finding restated, and 108 is the number STEP 1 must reproduce after the edit |
| 5 | worktrees: `git worktree list`; for each of `cbt-705-n15`, `cbt-705-n16`: `.next/BUILD_ID` present, `node -e "console.log(require('./node_modules/next/package.json').version)"`, and whether `node_modules` is intact; locate the 706 flush-tag list (block or artifacts) and quote it | both present, built, `15.5.x` and `16.x`, tag list found | a missing build is a rebuild inside that worktree (`npm ci && npm run build` there, its own lockfile); a missing worktree is a decline of the re-take, written up at STEP 3 with this row as the reason, and the rest of the HO proceeds |
| 6 | `npx playwright --version`; chromium present (`npx playwright install --dry-run chromium` or the equivalent listing) | 1.61.1 · installed | a browser install is a one-time cost and is pasted as such |

HALT here with the six rows. The go arrives as a file.

## STEP 1 — the code (commit `fix(HO 709)`; four paths, staged by name)

In this order, because the middle step is the control.

1. **Create `tsconfig.e2e.json`** at the repo root:
   ```json
   {
     "extends": "./tsconfig.json",
     "compilerOptions": { "incremental": false },
     "include": ["e2e/**/*.ts", "playwright.config.ts"],
     "exclude": ["node_modules"]
   }
   ```
   `include` in a child config replaces the parent's, so this program is the harness and its imports, nothing else. `incremental: false` because the inherited `true` would write `tsconfig.e2e.tsbuildinfo` beside it, which `.gitignore:9` does not cover.
2. **`package.json` scripts:** `"typecheck": "tsc --noEmit && npm run typecheck:e2e"` and a new `"typecheck:e2e": "tsc --noEmit -p tsconfig.e2e.json"`, placed beside `typecheck`. Two scripts so the harness can be checked alone; one entry point so the pre-push habit and `ci.yml:56` change nothing.
3. **`tsconfig.json` `include`** gains `"next.config.ts"` after `"auth.ts"`. This is the one root-program change: +1 clean file to what `next build` type-checks, per HO 708 probe (ii).
4. **Run `npm run typecheck` now, before touching the spec.** Expected: the root program passes and the second program **fails with exit non-zero on `bundler-captures-706.spec.ts(67,9) TS2353`**. Paste it. This is the gate proving it can fail, on the real error rather than a bait, and it is the only moment that reading is available.
5. **`e2e/bundler-captures-706.spec.ts`:**
   - `:67` becomes `contextOptions: { reducedMotion: v.reduced ? "reduce" : "no-preference" },` (the `viewport` line stays).
   - Inside the test body, immediately after the `waitForLoadState` line and before the settle, the in-page proof the method's twelfth instance requires:
     ```ts
     // HO 709 — an emulation is proven by reading the media query back inside the
     // page, never by the option meant to set it (method § Gates, HO 708 instance).
     const rm = await page.evaluate(() => matchMedia("(prefers-reduced-motion: reduce)").matches);
     console.log(`RM=${rm} expected=${v.reduced} ${r.slug} @${v.tag}`);
     expect(rm, `reduced-motion emulation @${v.tag}`).toBe(v.reduced);
     ```
   - Header: one short paragraph after the `@nonci` note, dated, saying the `1440-reduced` config emulated nothing from HO 706 until HO 709 (`reducedMotion` is a `BrowserContextOptions` key, so it travels under `contextOptions`), and that every capture now asserts the emulation it claims. Comment only; no other line of the file moves.
6. **Run `npm run typecheck` again:** exit 0, both programs. Then the two coverage reads that strike `:14`: `npx tsc --noEmit -p tsconfig.e2e.json --listFiles | grep -c 'e2e[\\/]smoke.spec.ts'` → **1**; `npx tsc --noEmit --listFiles | grep -c '[\\/]next.config.ts'` → **1**; and the root program's `smoke.spec.ts` count still **0**, which under (B′) is by design and is stated as such, not as a gap. Exit code of the `tsc` printed before each pipe.
7. **`npx playwright test --list e2e/bundler-captures-706.spec.ts`:** exit 0, **108** tests, same as row 4.

Commit: `git add tsconfig.e2e.json tsconfig.json package.json e2e/bundler-captures-706.spec.ts`, message `fix(HO 709): typecheck reads the harness through its own program; the capture spec proves its emulation`. Body names the control reading from step 4. Nothing else in the tree.

## STEP 2 — the comment (commit `ci(HO 709)`; one path)

`ci.yml:11-13` rewritten so the justification and the reality change together: `scripts/**` covered by `tsconfig.json` (what broke at `3ed533c`); `e2e/**` and `playwright.config.ts` covered by `tsconfig.e2e.json` through the same `npm run typecheck` since HO 709 (the program that had never read the file where `reducedMotion` sat for two HOs, HO 708); `.github/**` unchanged. Keep every changed line a `#` line at the existing indentation. Prove it before committing: `git diff -U0 .github/workflows/ci.yml | grep -E '^[+-][^+-]'` must show only lines whose second character is `#` (or leading spaces then `#`). A comment-only diff cannot change parsing, and that grep is the evidence, not the intention. Commit `ci(HO 709): the paths-ignore comment names both type-check programs`.

`ci.yml` fires on `push: branches: [main]`, so its first run with the two-program `typecheck` is a post-FF reading; note it as owed.

## STEP 3 — the re-take (no commit; the result goes in the block)

The `1440-reduced` third of the 706 captures, taken for real, against the two worktrees, before they go on the week.

1. Servers as HO 706 ran them: n15 on `:3000`, n16 on `:3007`, production servers from their own builds. Read the exact start commands from the 706 block or artifacts rather than from memory.
2. **Flush both**, every tag in the 706 list, and print each `POST /api/revalidate?tag=…` response for both servers. The spec header's rule is not optional and the block quotes it as followed.
3. **Control first, one route, the unreduced tag:** `CAPTURE_ROLE=compare npx playwright test e2e/bundler-captures-706.spec.ts --grep "search @1440$"` → its `RM=false expected=false` line. The instrument must be able to read `false` on the config that means `false`, or the 36 `true`s that follow are unproven.
4. **Baseline from n15:** `CAPTURE_ROLE=baseline npx playwright test e2e/bundler-captures-706.spec.ts --grep "@1440-reduced" --update-snapshots` → 36 written, and `grep -c 'RM=true expected=true' <log>` → **36**.
5. **Compare against n16:** `CAPTURE_ROLE=compare npx playwright test e2e/bundler-captures-706.spec.ts --grep "@1440-reduced"` → N passed / M failed, exit code first, and again `RM=true expected=true` **36**.
6. Any failure: re-run that test back-to-back; if it passes, it is live drift and is listed as such. If it fails twice, **diff the served HTML from both servers before the PNG**, as the header says, and paste the HTML verdict. A same-HTML pixel difference that survives the re-run is a reduced-motion render difference between the two bundlers, and it is **filed as a new backlog entry, not fixed here**.
7. Logs and the comparator's report to `docs/handoffs/709-artifacts/`; snapshots stay where `.gitignore:85` keeps them.

If row 5 declined the re-take, this step is one paragraph in the block naming the missing worktree or build and the fact that the window closes with `:51`; nothing else changes.

## STEP 4 — docs (commit `docs(HO 709)`; `docs/backlog.md`, `docs/roadmap.md`, `docs/oddities.md`)

- **`:14` struck, body inside the strike**, with the readings that strike it: `typecheck` exit 0 across both programs; the STEP 1 step 4 red as the control; `smoke.spec.ts` **1** in the e2e program; `next.config.ts` **1** in the root; root `smoke.spec.ts` **0** by design (B′); `ci.yml` comment corrected in `ci(HO 709)`; the 706 `1440-reduced` third re-taken (or declined) with its numbers. Prove the strike contains the original by comparison. **No other backlog line moves** unless STEP 3 step 6 filed a regression, which is an addition and is counted.
- **Oddities, one dated HO-tagged field note** from the 708 FF paste, attributed to it: the `0 15 * * *` daily on `e2e-prod.yml` has been delivered by GitHub between 17:11Z and 19:01Z on each of the last seven scheduled runs (ids and times as Code listed them), so a daily that has not appeared at 16Z is not missing, and the count is read against delivery, not against the cron string.
- **Roadmap `Also (HO 709)` block:** the STEP 0 rows; the control red and the green after; the two coverage reads; (B′) landed as ruled and why (`:2511`); the `next.config.ts` inclusion; the `ci.yml` diff proven comment-only; STEP 3's numbers with the `RM=` counts and the `@1440$` control, drift handling, and the HTML verdicts if any; what this finally says about 706's conclusion; OPEN LOOPS reconciled from **247 live / 245 struck** at open to the close figures (expected 246 / 246, one strike, no additions, unless step 6 filed). **Notes now run through HO 709.**

## STEP 5 — SKILL, alone (commit `docs(skill)`; two lines)

- `:2511` gains one sentence after the existing one: `e2e/**` and `playwright.config.ts` are deliberately **not** in the root program (HO 709, `tsconfig.e2e.json`), so a harness typo reds `npm run typecheck` and CI but never the Production build.
- `:2584` (*"CI is typecheck + `check:odds-sites` + build"*) gains: `typecheck` is two programs since HO 709, `tsconfig.json` for the app, `scripts/**` and `next.config.ts`, and `tsconfig.e2e.json` for `e2e/**` and `playwright.config.ts`, chained in the one script so `ci.yml:56` did not change.

Nothing else in SKILL; `:2577` stays as HO 708 left it.

## Gates

`typecheck` **0** (both programs; quote each `tsc` exit) · `build` **0** · `check:odds-sites` **0** · `check:design-citations` **OK**, run immediately before the paste. No app render change, so the 1440/2560 app captures are not owed and their absence is stated; the render work here is STEP 3 itself, and its captures and report are the evidence. Numstat: `tsconfig.json` +1/0 · `package.json` +2/−1 · `tsconfig.e2e.json` new · spec roughly +12/−1 (the `:67` rewrite plus additions; every deletion explained) · `ci.yml` comment lines only · backlog 1/1 (+ any filing) · roadmap and oddities pure append · SKILL 2/2.

## Review ref, then FF

`709-review`, five commits in the order above (`fix` · `ci` · `docs` · `docs(skill)`), kinds pure. Paste: `git show --stat` per commit; the STEP 1 step 4 red verbatim; the coverage reads with their exit codes; the `ci.yml` comment-only grep; STEP 3's counts and any HTML verdicts; the four gates; `git ls-remote --heads origin` with `main` still at `918b52b`. Then hold for the FF go, which arrives as a file. After the FF, `ci.yml` fires (workflows are not under `paths-ignore`, and code moved): its id and conclusion are the first CI reading of the two-program `typecheck`; the Production `deployment_status` smoke run is the extra sample outside the seven, as before; and day one's daily, once GitHub delivers it, is quoted on its own.

read and follow 709
