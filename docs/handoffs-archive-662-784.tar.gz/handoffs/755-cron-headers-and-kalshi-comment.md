# HO 755: two comment-only closes. The kalshi comment says what the code does, and every cron header names the trigger `vercel.json` actually has

Two `docs/backlog.md` OPEN LOOPS lines, both filed from HO 744, both closed by comments alone:

- *The kalshi cron's comment says a failed chamber-control read leaves the prior blob in place, and the code overwrites that chamber with `null`…* (HO 744), low. Ruled 2026-09-25, branch (1): the comment changes and the code doesn't. Its close is checked by reading, not by grep.
- *The kalshi and committees cron route headers describe triggers and schedules that `vercel.json` has since replaced…* (HO 744), low. Its close is two greps: the stale phrases read 0 lines across `app` and `lib`, and each of the five files names `vercel.json`. HO 754 already rewrote the committees header (`app/api/cron/committees/route.ts:20`); the other four stand as the line read them.

No behaviour changes. No SKILL change unless STEP 0 finds SKILL carrying the same stale phrases, in which case that edit is its own `docs(skill)` commit with approval requested.

## Ground truth (read at `6302325`; re-derive every `:N` by content)

- The stale headers today, by the line's own grep: `app/api/cron/kalshi/route.ts:4-5` (a GitHub Actions workflow that was deleted at `945486f`, and "Hobby caps cron at daily"), `app/api/cron/markets/route.ts:6-7` (the same, and "once daily"), `lib/kalshi.ts:8`, and, named by the line but outside its instrument, `scripts/migrate.ts:290` and `:516`, `app/api/cron/markets/route.ts:112-114` (present tense for a run that now fires six times a day) and `app/api/cron/lda/route.ts:18-19` (a slot called clear of neighbours it now shares). `app/api/cron/news/route.ts` no longer matches the grep after HO 754's rewrite; STEP 0 confirms.
- The schedules to name are in `vercel.json`: kalshi `15 */2 * * *`, markets `0 */4 * * *` and `?source=fmp` on its market-hours cadence, news `*/30 * * * *`, committees `0 */12 * * *`, committee-meetings `50 */12 * * *`, lda at its own entry. Read them from the file, not from here.
- The kalshi comment is `app/api/cron/kalshi/route.ts:72-74`; the code it describes is `lib/kalshi.ts` (`.catch(() => null)` per chamber, `null` for fewer than two priced outcomes) and the route's unconditional upsert. The band renders a dash for a null chamber (`components/RacesHeroBand.tsx`), beside the House `LIVE` pill.
- The measurement the kalshi line names and never ran: a `SELECT COUNT(*)` over `cron_runs` for `/api/cron/kalshi` success rows whose payload carries a JSON null on either chamber. It is a reading for the roadmap block, not part of the close.

## STEP 0

1. HO number from the tree: `main` at `6302325`, pointer 754, so 755. Otherwise stop.
2. Carry HO 754's post-FF reading and the four tick readings (committees at 00:00Z and 12:00Z, committee-meetings at 00:50Z and 12:50Z on 2026-09-29) into this HO's roadmap block. If a tick isn't in yet, say where it's held.
3. Run the line's two greps as the red: paste both readings at HEAD.
4. Grep SKILL for the same phrases. Paste the reading; a hit means a `docs(skill)` commit of its own.
5. Run the kalshi measurement, read-only, and paste the count with the total of success rows.
6. Proceed without a halt.

## The change, comments only

1. Each of the four remaining files names `vercel.json` as its trigger and states its current schedule from that file, and says which other entries share its minute where the old text claimed a clear slot. The workflow names, "Hobby", "once daily" and "not Vercel cron" go. `markets/route.ts:112-114` moves to what the two entries do now; `:109-111` stays as history. `scripts/migrate.ts:290` and `:516` and `lda/route.ts:18-19` are corrected in the same commit; they're the same class, and the line names them.
2. `app/api/cron/kalshi/route.ts:72-74` says what the code does: a failed or unpriced read writes `null` for that chamber, the row's `updated_at` advances, the other chamber updates on its own, and the band shows a dash for the null one. One sentence says the choice was ruled at HO 747 (branch (1)) and why: the band carries no timestamp, so a kept value would read as live.

## The close, read at the ref

- The two greps from the line, green: 0 lines, and all five files listed. A control: a planted stale phrase in a scratch copy reads 1.
- The kalshi comment is checked by reading: the architect reads it at the ref, and the paste-back quotes it whole.

## Commits and docs

- `chore(HO 755)`: the comments.
- `docs(skill)` only if STEP 0 item 4 found a hit; own commit, approval requested.
- `docs(HO 755)`: strike both lines with the readings in their close notes; the roadmap block, pointer 754 → 755, carrying HO 754's readings, the four ticks and the kalshi count. Reconcile OPEN LOOPS at open and close, control at 0: 261 live / 310 struck / 571 at `6302325`, 259 / 312 / 571 at close.
- Review ref `755-review`. The FF is held for review. Nothing served changes, so no captures and no post-FF run.

## Gates

The cheap gates. Paste `git show --stat` per commit, the docs numstat, the reconcile, the `755-review` SHA from `git ls-remote`, and a last cheap-gate run.
