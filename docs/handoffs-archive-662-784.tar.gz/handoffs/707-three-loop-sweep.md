# HO 707 — three loops the Next 16 bump made cheap

Three independent loops, one small HO, no product change. Two of them close by **reading** rather than by work; the third is a four-line CI edit that has been a countdown since July. Deliberately sized to run alongside the `#418` daily count without touching the crawl.

**Why now.** `backlog:81` said in its own disposition that it *"rides a Next 16 HO; it does not drive one."* HO 706 landed Next 16.3.4, so it rides this one. `backlog:82` is a local-runtime mismatch whose declared ranges just changed under it. `backlog:55` is unrelated to the bump but touches the same four workflow files as `:82`'s possible fix and has the worst failure mode of the three: an unexplained CI red on an unchanged tree.

**Nothing here is allowed to disturb the count.** `backlog:51` closes on seven consecutive `0 15 * * *` runs with `pageErr` at zero. A workflow edit that changes what the daily *runs* would reset that count; a version bump of the actions that carry it does not, but the STEP 3 ruling below says what to do if the first daily after this lands is red for an infrastructure reason.

## Ground truth (fresh clone at `29026da`, 2026-09-09; re-derive at STEP 0 regardless)

- Pointer 706, highest HO in subjects 706; this is 707. `main` is Next 16.3.4 on Turbopack, Production serving `19.3.0-canary-cbb046ab-20260731`.
- **`package.json` has no `engines` field.** `:82`'s "the engine ranges the tree declares" therefore means the *transitive* ranges npm reads from dependencies, not a first-party declaration. That distinction is the whole of STEP 2 and the entry never made it.
- Action versions, all four workflow files: `actions/checkout@v4` at `ci.yml:43`, `e2e-prod.yml:159`, `e2e-prod.yml:380`, `design-citations.yml:38`; `actions/setup-node@v4` at `ci.yml:46`, `e2e-prod.yml:162`, `e2e-prod.yml:385`, `design-citations.yml:41`; `actions/upload-artifact@v4` at `e2e-prod.yml:248`, `:278`, `:435`. Node pinned `'20'` at `ci.yml:49`, `e2e-prod.yml:165`, `e2e-prod.yml:388`, `design-citations.yml:43`.
- The three entries at their current lines: `:55` (actions v5), `:81` (postcss), `:82` (Node v25). Locate by content at HEAD.
- `e2e-prod.yml:380–385` is HO 703's `narrow-preview` job; it is the newest of the three checkout sites and the one whose green a review ref depends on.

## STEP 0 — enumerate, no HALT rows

| # | check | expected |
|---|---|---|
| 1 | **the postcss reading, taken twice:** `npm audit` and `npm audit --omit=dev` on a clean `npm ci` at HEAD, full output, plus `npm ls postcss` for the resolved nested versions | `:81`'s advisory range ran through `16.3.0-preview.10`; at 16.3.4 it should be absent. **Quote the advisory count and the resolved `postcss` versions**, not "audit is clean" — an audit that reports nothing and an audit that fails to run read alike |
| 2 | **what the tree actually declares:** `node -v`; `npm ls --all --json` reduced to every `engines.node` range in the dependency graph, with the narrowest ones named; and `next`'s own (`>=20.9.0` at 16.3.4, was `^18.18.0 \|\| ^19.8.0 \|\| >=20.0.0` at 15.5.15) | the list, and whether v25.5.0 now satisfies every one of them. If some package still excludes v25, name it — that is the entry's real subject |
| 3 | v5 release notes for `checkout` and `setup-node`, and whether `upload-artifact@v4` carries the same deprecation | the breaking changes, if any, in one line each; `upload-artifact` decided on evidence rather than swept in for symmetry |
| 4 | is the Node-20 annotation still on runs? Read the most recent `ci.yml`, `e2e-prod.yml` and `design-citations.yml` runs for it | present or gone; either way it is a reading, and `:55`'s "countdown" claim is re-dated by it |
| 5 | SKILL exposure | likely one touch under *Continuous integration* if the action versions are named there; grep before assuming. `:82`'s outcome may want the "no `engines` field" fact recorded where a reader meets it |

## STEP 1 — the actions bump (commit 1, `ci(HO 707)`)

All four workflow files, `checkout@v4` → `@v5` and `setup-node@v4` → `@v5` at the eight sites above; `upload-artifact` only if row 3 says so, in the same commit, and if not, say why in the block. Node pins stay `'20'` — the runner's Node and the app toolchain are different things and `:55` says so explicitly; changing both at once would make a red unattributable.

**Falsification is not available here** (there is no way to make a v5 action fail on demand), so the evidence is coverage instead: every one of the four workflows must be *seen green after the bump*, and the three that fire on a push do so on this HO's own ref. `e2e-prod.yml`'s `narrow-preview` fires on the ref's Preview deployment. `e2e-prod.yml`'s `smoke` job cannot run pre-FF (HO 698's structural gap), so its first v5 reading is the Production run after the FF, and that is stated as owed rather than assumed green.

## STEP 2 — the two readings (commit 2, `docs(HO 707)`, with STEP 3)

No code. `:81` and `:82` close, or don't, on rows 1 and 2:

- **`:81`** — struck with provenance if the advisory is absent at 16.3.4, quoting the audit output and the resolved `postcss` versions, and naming HO 706 as what cleared it. If it survives, annotate with what the range now says and leave it open; do not force a strike to match the entry's own prediction.
- **`:82`** — the entry conflates two things and STEP 0 row 2 separates them. If every transitive range admits v25.5.0, the mismatch is gone and the entry is struck citing the reading. If something still excludes v25, the entry stays open with that package named, and the *second* half of its close criterion ("record the deviation where a reader meets it") is satisfied by one line in SKILL's environment section plus the fact that `package.json` declares no `engines` at all — which is why nothing in the tree was ever going to warn about this.

## STEP 3 — the ruling that protects the count

The `#418` daily count is running. **If the first `0 15 * * *` after this FF fails for an infrastructure reason** — a v5 action behaving differently, a runner change — that run is **not** a `pageErr` reading and does not reset the count; it is a `:55` regression and it reverts. Record which run ids the count comprises in the closing HO, and if any of them is an infrastructure red, re-run it by dispatch and quote both. A `pageErr` fire is a different thing entirely and reopens HO 705's report path as already ruled.

## STEP 4 — SKILL (alone, if row 5 found a target), docs

Docs: roadmap block with rows 1–5, the audit output, the engine-range list, the eight edited sites, the four workflows seen green (with the `smoke` job's reading named as owed post-FF), the three entries' dispositions, and the STEP 3 ruling. Pointer to 707. Backlog per STEP 2; `:55` struck only once all four workflows have been seen green on v5, which for `smoke` means after the FF — so if this HO closes before that run, `:55` is annotated *bumped, awaiting the first Production reading* and struck by whichever HO quotes it.

## Gates

`typecheck` 0 · `build` 0 · `check:odds-sites` 0 · `check:design-citations` OK. No render-touching change, so no captures. YAML parses (`actionlint` if available, otherwise the workflows' own runs are the parse gate). The audit and engine readings quoted directly, each with its own command in the same breath.

## Review ref, FF

`707-review`: three of four workflows read it directly, which is more pre-FF CI coverage than most HOs get. Architect read, SKILL slot if there is one, FF from a file, `verify:deploy` five reads, then the Production run quoted for the `smoke` job's first v5 reading.

read and follow 707
