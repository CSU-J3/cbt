# HO 746: the Senate vote sync skips what it has, not what's below its high-water mark

`docs/backlog.md` OPEN LOOPS, *The Senate vote sync strands a roll call that fails before its `votes` row is written as soon as a later roll in the same session is written (HO 744)*, owner Code, medium. HO 745 measured it: **zero stranded in either session of the 119th, across 128 ticks and 12 timeouts.** The mechanism is real and unfired. Corey ruled to build the remedy now, while the `file:` copy and the probe are warm.

**The change is one skip rule.** `runSenateVotesSync` reads `MAX(roll_call)` once per session and skips every menu roll at or below it (`lib/senate-votes-sync.ts:420`, `:432`). A roll that fails before its `votes` row is written is only counted (`:445`, `:465`), and once a later roll lands, the watermark hides it forever. After this HO the loop skips a menu roll only if that exact roll is stored. Anything on the menu with no row is fetched, every tick: a failed roll is retried the next day, and any gap that ever appears is filled. A permanent 404 costs one GET per run, which the line already accepted.

**Non-fork.** The line names two candidate remedies. Skip-against-the-stored-set is the one that fills gaps; stop-at-first-failure stalls a session behind a permanent 404 and fills nothing. This HO builds the first.

## Ground truth (read at `ddddc80`; re-derive every `:N` by content)

- `lib/senate-votes-sync.ts`
  - The file header at `:15-17` describes the current rule: "Watermark: MAX(roll_call) … strictly greater than what we have". It is a claim and changes with the code.
  - `SenateVotesSyncStats` at `:92-101`: `sessionsSeen`, `votesSeen`, `votesInserted`, `votesSkipped`, `votesFailed`, `memberRowsInserted`, `memberVotesHealed`, `memberVotesHealPending`.
  - `getMaxRollCall` at `:204-216`, called once per session at `:420`; the log line at `:421-423` prints `watermark roll_call=`.
  - The loop at `:428`: `rollInt <= 0` skipped at `:431`, `rollInt <= lastNum` counted as skipped at `:432-434`.
  - `detailUrl` at `:111`. `fetchXml` retries 502/503 up to three times (`:134`) and throws on any other non-ok status on the first response (`:140`). A 500 therefore fails a roll on the first try.
  - The failed id reaches only the runtime log (`failed ${id}` in the `catch`).
- `lib/votes-sync.ts:265`: the House watermark is `MAX(vote_date)`, a different mechanism. **Unchanged by this HO.**
- `app/api/sync-votes/route.ts` runs `runVotesSync` then `runSenateVotesSync` and flushes `votes`. Unchanged.
- `.claude/skills/cbt/SKILL.md:1137`: "both syncs are watermark-incremental, so a tick that runs long simply resumes next day." Half of this sentence changes.
- `scripts/diagnostic/senate-roll-gaps-745.ts` is the reader for every leg below: it classifies menu rolls with no stored row as never reached, stranded or pending, with the menu as the authority.
- Schedule: `/api/sync-votes` at `0 10 * * *` (`vercel.json:66-67`).
- Counts are not given here. HO 745 read 119/1 at 659/659 and 119/2 at 240 stored of 241 following `cron_runs` #19487; the store has moved since. STEP 0 measures.

## STEP 0

1. **HO number** from the tree: `max(roadmap pointer, highest HO in commit subjects) + 1`. At `ddddc80` both read 745, so 746. The tree wins if it disagrees.
2. **Citations** re-read at HEAD by content. Drift is flagged, not absorbed.
3. **The House predicate.** Read `lib/votes-sync.ts:265` and the comparison the House loop applies to `MAX(vote_date)`. If the House can strand a vote the same way (a failed vote whose date is at or below the watermark after a later vote is written), **flag it in the paste-back for a line. Do not fix it here.**
4. **Baseline.** Make a `file:` copy of prod the way HO 744 and 745 made theirs. The sync's writes need `members` (the senator resolver), `bills` (the `bill_id` FK), `votes` and `member_votes`. Run the 745 probe against it: record stranded, pending and the per-session MAX. That's the baseline every leg reads against.
5. **Proceed** without a halt unless something above contradicts this file.

## STEP 1: `diag(HO 746)`, the legs, committed before the feat so they can run red on the old code

`scripts/diagnostic/senate-watermark-legs-746.ts` plus a preload shim `senate-detail-fail-shim-746.cjs`.

- The driver spawns `scripts/sync-senate-votes.ts` against the copy with the env pointed at it. **It refuses any database URL that isn't `file:`** and prints the scheme it ran against, the HO 745 guard.
- The shim, loaded through `NODE_OPTIONS --require`, patches `globalThis.fetch` so the detail URL of one roll (`FAIL_ROLL`, padded the way `:436` pads it) answers HTTP 500. Nothing else is touched. 500 fails on the first response (`:140`), so the roll is counted failed, not retried.
- Every run records the tree's SHA and whether it was dirty, the run's stats line, and the 745 probe's reading of the copy afterward.

**Run 0, harness control.** Unmodified code, unmodified copy, no shim. Expected: `inserted` equals the baseline's pending count, `failed 0`, `skipped` equals the stored count per session. If this doesn't hold, the harness is wrong: stop.

**Setup.** In session 119/2 of the copy, pick N = MAX − 2 and delete every roll at or above N, `member_votes` first (`scripts/migrate.ts:403`). The copy's MAX is now N − 1, so N and everything above it are pending, not stranded.

**Run 1, the strand.** Old code, shim failing roll N. Expected: roll N counted failed, every roll above N written, MAX now above N. The probe reads stranded `[N]`.

**Run 2a, red.** Old code, no shim. Expected: N is counted as skipped, and the probe still reads stranded `[N]`. This is the line's *reads if never done*, seen once.

Then STEP 2, then:

**Run 2b, green.** New code, no shim. Expected: N inserted, `votesFilled 1`, `failed 0`, and the probe reads stranded 0 with the gap query at 0.

**Run 3, idempotence.** New code again. Expected: `inserted 0`, `votesFilled 0`, `skipped` equal to the stored count.

## STEP 2: `feat(HO 746)`, one function and one rule

In `lib/senate-votes-sync.ts`:

- Replace `getMaxRollCall` with a read of the session's stored roll set: `SELECT roll_call FROM votes WHERE chamber = 'senate' AND congress = ? AND session = ?`, returned as a `Set<number>`, with its max kept for the log.
- The skip at `:432` becomes membership: a menu roll is skipped only if the set has it. The `rollInt <= 0` skip stays.
- Add `votesFilled: number` to `SenateVotesSyncStats`: menu rolls **below** the session's stored max that had no row and were written this run. It reads 0 on every normal tick and makes a gap fill visible in `cron_runs` without the logs.
- The session log line names what the run will attempt: `stored=K max=M missing=(menu − K)`. The done line and the completion line carry `filled=`.
- The file header at `:15-17` says the new rule. Every claim in it is read against the code before it lands.

Nothing else moves: the detail fetch, the upsert, the heal pass and the route are untouched.

## STEP 3: `docs(skill)` alone, then `docs(HO 746)` after the first tick

**SKILL `:1137`**, its own commit, approval requested in the paste-back. The sentence splits by chamber and says only what each does: the House resumes on `MAX(vote_date)` (`lib/votes-sync.ts:265`, unchanged); the Senate, since HO 746, skips against the session's stored roll set, so a tick that runs long resumes next day and a roll that fails is retried the next tick rather than stranded (HO 745 measured 0 stranded before the change). Write the words from what STEP 0 read, not from this paragraph.

**The docs close waits one tick.** After the FF, the first scheduled `/api/sync-votes` run under the new code is the prod reading. Compute its date from `0 10 * * *` with `date -u -d`, never from memory. Read its `cron_runs` row: Senate `inserted` equal to the rolls pending at that moment, `filled 0`, `failed 0`, `skipped` equal to the stored count. Then run the 745 probe against prod: stranded 0 in every session.

Then `docs(HO 746)` on its own short ref:
- strike the line on both halves of its close: (a) the leg, runs 1 → 2a → 2b, with N and the probe's readings; (b) the prod probe after the tick, and the tick's row;
- the roadmap block;
- reconcile OPEN LOOPS at open and close, control `^- \*\*~~` 0. One strike, no new lines unless STEP 0's House read earns one.

## Gates and FF

Review ref `746-review` from the start; SKILL approved alone. `npm run build`, `npm run typecheck`, `check:odds-sites`, `check:design-citations`. No render change, so no captures are owed; the Preview's e2e reading runs on the ref as usual and is reported as it comes. FF on review: `HEAD:main` no force → `ls-remote` → delete the ref → `verify:deploy` → the Production `e2e-prod` read. No manual `POST /api/sync-votes`: the tick is the reading.

## Paste back

- STEP 0: the HO number, citation drift, the House predicate reading, the copy baseline;
- runs 0, 1, 2a, 2b and 3, each with the tree's SHA, its stats line and the probe's reading;
- the feat diff and the SKILL diff;
- `--numstat` (deletions column, not a grep);
- the gates and the review ref's sha from `ls-remote`;
- after the FF: the tick's `cron_runs` row and the prod probe reading, then the docs ref.
