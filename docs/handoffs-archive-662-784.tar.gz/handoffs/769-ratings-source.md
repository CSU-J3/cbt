# HO 769: the ratings widget answers 404; probe the source and rewire if the table is still reachable, and match the tracker's last two House rows

Race ratings on `/electoral` haven't moved since 09-30. #23114 (10-07) and the manual #23765 (10-09) both found the widget's URL on Ballotpedia's pages and got 404 fetching it, on both chambers. A second failure at the same fetch is a source change, not noise, so this doesn't wait for the 10-14 WATCH.

**How STEP 0 runs** (method.md, HO 768's rule): the claims below are mine, read at `140aa77`, and are a check. **The probe is scope I couldn't enumerate, so it keeps its HALT**, with one stated way through. My shell can't reach Ballotpedia, and the text view I can fetch shows no ratings section on the Senate page. It does show a *Pre-election analysis* tab described as *Outside race ratings and district analysis*, and the widget URL itself won't fetch for me at all.

Base `main` at `140aa77` after HO 768's FF. HO number: pointer 768, highest HO in commit subjects 768, so 769.

## Scope

In:
- the WATCH *the ratings sync's widget fetch answers 404 for both chambers*;
- the two unmatched rows on *The Palestine Tracker syncs by hand…*;
- HO 768's FF readings, which open this block.

Out: everything else.

## STEP 0

| # | Claim at `140aa77` | Fails if |
|---|---|---|
| 1 | `scrapeRatings(chamber)` (`lib/race-ratings-scrape.ts:620-627`) fetches the chamber's Ballotpedia page (`:105-107`) and finds exactly one `data-url` holding `race-ratings-full-table` and `office_type=<Chamber>` (`discoverWidgetUrl`, `:431-445`). It fetches that URL with a browser `User-Agent` and `Accept: text/html` (`fetchHtml`, `:300-319`; `USER_AGENT`, `:125-126`), 8s per fetch (`:298`). The table is picked by its header, with floors of House 435 − 5 and Senate 35 − 0 (`:223-224`) | |
| 2 | #23114 and #23765 failed at that widget fetch, 404 on both chambers, after discovery found the URL; the last run whose legs scraped rows is #21278 (09-30) | discovery itself failed |
| 3 | `matchHouse` (`scripts/sync-palestine.ts:247-258`) keeps a CD's members whose folded last name, or name, matches the sheet's. At AZ-07 two match *Grijalva* (Raúl G000551, Adelita G000606); at the tracker's GA-07 none matches *McBath* | |

**The probe** (read-only; nothing writes):
- **P1, the pages.** On each chamber's page: every `data-url`; every link or tab whose text or `href` names ratings or *Pre-election analysis*; and the HTML around the old widget div.
- **P2, the widget fetched three ways.** As the scrape does; with `Referer: <the page>` added; with `Accept: */*`. Give the status and body size of each.
- **P3, the page in Playwright** (Chromium), to network idle. List every response whose body carries a table with *Cook* in its header: its URL, method and status, the request headers that differ from the scrape's (`Referer`, `Origin`, `Accept`, cookies), and the table's header and row count. If the page has a *Pre-election analysis* tab or link, open it and do the same.

**Go on without stopping** if one request meets all three:
- the scrape can make it as a plain server-side fetch: a URL plus at most `Referer`, `Origin` or `Accept`, with no cookies, no tokens, and nothing a script builds;
- it returns a table whose header carries the district or state and *Cook Political Report*, *Inside Elections* and *Sabato's Crystal Ball*;
- it meets the scrape's own floors for both chambers.

**HALT** with P1-P3 otherwise. If it HALTs because the table now sits behind something the scrape can't make, the next question is which source replaces it, and I'll rule that with your census in hand.

Also in STEP 0, no HALT: the tracker's dry run against prod under § 2's matcher. Expected: House 212 matched, 0 unmatched.

## The build

### 1. The ratings source (fix)
- `lib/race-ratings-scrape.ts` makes the request P3 found. Discovery stays by substring: on the page if the page still carries the URL; otherwise where P1 found it, still exactly one or a throw. Any added header goes on the widget fetch only. Columns picked by header, the four throws, the floors and the 8s cap all stay.
- The file's header comment gains an HO 769 paragraph: what changed between 09-30 and 10-07, what P2 and P3 read, and what the scrape sends now.
- If a SKILL sentence names the old fetch (the cron entry at `:1238`, or the Ballotpedia entry under External data sources), a `docs(skill)` commit corrects it. Quote it in the paste for approval.

### 2. The tracker's last two House rows (fix)
- `matchHouse`: when two or more members at the CD match the surname, keep those whose folded name holds the sheet's folded first name. If exactly one remains, that's the match.
- When none at the CD matches, look among the state's House members. Exactly one surname match is the match, printed as *matched by state: the tracker's CD {X}, members' {ST-DD}*.
- Anything else stays unmatched, as now.
- **Write to prod before the review push**, on HO 768's four gates: both headers pass; House graded ≥ 200; House unmatched ≤ 3; Senate unmatched ≤ 1 and nobody matched twice. Expect House 212 matched.

## Legs

`scripts/diagnostic/ratings-source-769.ts`. Every leg has a red or a control.
- **A:** the scrape, read-only against the live source, both chambers:
  - it parses at the floors, finds the three raters by header, and reads DDHQ and ignores it;
  - red: `140aa77`'s scrape against the same source fails as P2 found;
  - control: a planted 404 from a local server still throws `fetchError` naming the URL.
- **B:** the sync on a `file:` copy seeded from prod by `SELECT`, writing only to the copy:
  - both legs `ok`, scraping House 435 and Senate 35;
  - the `race_ratings` rows that changed since 09-30, counted by chamber;
  - prod's fingerprint the same before and after.
- **C:** the tracker:
  - dry run on prod and `--write` on a copy, 212 House matched;
  - Adelita Grijalva → G000606, Lucy McBath → her own row (by state);
  - control: a planted row whose CD and surname no member holds stays unmatched.

## Docs

- **roadmap:** the HO 769 block, opening with HO 768's FF readings: rev-parse, `ls-remote`, `verify:deploy`, `e2e-prod`, the flush's response and the prod reading.
- **backlog:**
  - The ratings WATCH gets what P1-P3 read and what the fix sends. It isn't struck: its close is the 10-14 scheduled run, since a manual run proves the route, never the schedule (HO 504).
  - The tracker line's unmatched sentence is rewritten whole: none left, or which and why.
  - Reconcile, control 0.
- **oddities:** if the source moved somewhere worth knowing (a header gate, a new tab), an entry.
- **SKILL:** only if a sentence names the old fetch (§ 1).

## Commits

On `769-review` from the start, kinds unmixed:
- `fix` for § 1 and `fix` for § 2;
- `diag`;
- `docs`;
- `docs(skill)` alone, and last, if there is one.

## Paste back once, covering HO 768's FF too

- HO 768:
  - rev-parse and `ls-remote`;
  - `verify:deploy`;
  - `e2e-prod` and its smoke;
  - the flush's response;
  - the prod reading.
- HO 769:
  - `ls-remote` with the review SHA;
  - the Preview's `narrow-preview`;
  - STEP 0: claims, P1-P3 and the decision, the tracker's dry run;
  - the legs;
  - the tracker write's output;
  - `--stat` per commit, `--numstat` for docs with every deletion explained;
  - the reconcile;
  - a last cheap-gate run.

The FF go then carries the FF, `verify:deploy`, `e2e-prod`, one `POST /api/sync-race-ratings` on Production (expect `success` with both legs at the floors; its moves will read not fresh under HO 768's guard, nine-plus days back to 09-30, which is the guard working), one `POST /api/revalidate?tag=palestine`, and the prod reading.
