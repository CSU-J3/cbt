# HO 768: finish the electoral overhaul. Six of HO 767's follow-ups built and closed in one pass; STEP 0 checks the architect's table and HALTs only on a failure; one paste-back, at the review ref

**Ruling, verbatim (Corey, 2026-10-08, 8:26 PM MT):** *"we need to do start to finish this overhaul. pls stop stopping and waiting."*

What it changes in this handoff:
- **STEP 0 is a check, not a HALT.** I enumerated at `8752512` from the clone; § STEP 0 is the closure table. Re-derive each claim at your HEAD and go on. A failed claim, or a measurement outside its stated bound, HALTs; nothing else does. method.md takes this as a rule (§ Docs).
- **No stop between STEP 0 and the review ref.** Build, legs, the tracker's write, docs and SKILL all land, then one paste-back.
- **The calendar-lock fork is ruled here, as a non-fork call** (method.md § Roles): both directions are a readout detail on a calendar whose primaries are over, and the product doesn't differ. The readout names the stacked states. Corey can overrule; nothing waits on him.

## Scope

In, six OPEN LOOPS lines by title, and two carried items:
1. *A called seat's odds still show on the MAP's cards and in the district export*: the MAP half of R6, and `kalshiActive` on the page's clock.
2. *The dashboard's band runs its featured labels and tier counts together at phone width.*
3. *`/electoral`'s calendar locks paint the MAP only, and LIST opens by default.*
4. *The Tooltip primitive's panel neither follows nor closes on a scroll.*
5. *MOVED counts a rater's first run after a gap as fresh moves.*
6. *The Palestine Tracker's House tab is unread.*
7. From `docs/handoffs/767-artifacts/carry-to-next-ho.md`: HO 767's FF readings and its two close rulings into this block, and the oddities entry *The election clock counts UTC days*, filed as drafted.
8. method.md: the STEP 0 rule above.

Out: the 2028 data-side WATCH (nothing publishes 2028 yet), HO 758's Nov-4 WATCH (dated 2026-11-04; it gains one reading below), and every other OPEN LOOPS line.

Base `main` at `8752512`. HO number: pointer 767, highest HO in commit subjects 767, so 768.

## STEP 0: the table, checked

A line number that drifted is re-derived, not a failure. Anything the table didn't anticipate: take the reading closest to this handoff's intent, build on, and flag it in the paste. Stop only where a claim or a bound fails.

| # | Claim at `8752512` | Fails if |
|---|---|---|
| 1 | `app/electoral/page.tsx:125` builds `rows` before `:130` builds the cartogram from `races`; a row's `result.called` (`lib/electoral-rows.ts:64`) marks a called seat | the order differs, or `called` is gone |
| 2 | The MAP has three market sites, all reading `contest.kalshiOdds` from `buildRacesCartogram` (`lib/cartogram-data.ts:142`): `KalshiLine` in `RaceMapCard.tsx:236` and `RaceDistrictCard.tsx:120`, and `buildReport` in `RaceDistrictModal.tsx:31-49`, which prints the market on `c.kalshiOdds && !oddsOff` with no close check | a fourth site |
| 3 | `kalshiActive` (`lib/race-colors.ts:77-83`) compares `Date.now()`. Its client callers on `/electoral`: `KalshiLine` (`components/race-cells.tsx:58`; rendered by RaceMapCard, RaceDistrictCard and `RaceOpenRow.tsx:457`) and `kalshiDivergesFromConsensus` (`lib/race-colors.ts:109`; called at `RaceListView.tsx:228` and `:439`). Its server callers (RaceCard, `lib/race-matchup.ts:133`) render once | another client caller |
| 4 | `/electoral`'s phone rule is `.electoral-band .ctl, .electoral-band .ctl-legend` under 700px (`app/globals.css:9371-9385`); `.battlefield` renders from `components/Battlefield.tsx` alone; featured labels sit `FEATURED_MIN_GAP` = 9 (percent) apart (`Battlefield.tsx:106`) | |
| 5 | The calendar readout prints `— {highlightedStates.size} states · {lockedContests} contests` (`components/ElectoralBoard.tsx:208`), under the hint at `:197` | |
| 6 | The Tooltip places its panel once per open, in a layout effect on `[open, preferBelow]` (`components/Tooltip.tsx:191-215`), with no scroll or resize listener; GradeCard's `chipVisible` (`components/GradeCard.tsx:125-135`) is the in-sight rule | |
| 7 | `getRecentRaceMoves` (`lib/queries.ts:2467-2510`) returns each race's newest post-baseline move with no freshness test; its consumers are `/electoral` (`page.tsx:120`) and `CompetitiveRacesBlock.tsx:94` | another consumer |
| 8 | `/api/sync-race-ratings` records payload `{ chambers: { house, senate: { ok, stats } } }` since HO 744 (`route.ts:97`) and `{ stats }` before it (`0fda431`); `stats.scraped` is in both; a leg failure throws, so the run is `error`; `/api/cron/rating-history` is its own route (`route.ts:34`); schedules `0 11 * * 3` and `0 15 * * *` (`vercel.json`); nothing deletes from `cron_runs` | a shape differs |
| 9 | `scripts/sync-palestine.ts` reads the Senate tab alone, writes row by row with no dry run, matches a surname inside `members.name` with state and `chamber = 'senate'` (`:112-123`), and stores any non-empty grade | |
| 10 | `readPalestinePools` counts `palestine_scorecard` rows by `members.chamber` (`lib/electoral-general.ts:562`). Six cached readers read the table: getPalestineScorecard (`lib/queries.ts:1487`), getBallotMemberFacts (`:2227`), getPalestinePools (`:2246`), getAbsenceWatch (`:6129`), getMembersRanked (`:7503`), getCommitteeRoster (`:7655`). None carries a `palestine` tag, and `/api/revalidate`'s `ALLOWED_TAGS` has none (`route.ts:21-53`) | a seventh reader |
| 11 | `dashboard_state (key, value, updated_at)` exists (`scripts/migrate.ts:83-87`); `members.district` is INTEGER; `districtToken` reads null or 0 as `AL` (`lib/race-id.ts:42-45`) | |

Three measurements, each with its bound. Prod by `SELECT` only; the sheet by its public export.
- **M1, the MOVED guard on prod's own history.** Apply § 5's rule to every post-baseline `rating_history` row since 2026-09-01 and tabulate by `observed_at` and chamber: fresh or not. Expected: the 09-21 House batch (47) and the 09-24 Senate batch (7) not fresh; 09-23 (8) and 09-30 (17) fresh; anything since, fresh. **HALT** if any of those four reads the other way, with the `cron_runs` rows behind it.
- **M2, the tracker's two tabs.** Read each header and count its rows. As read on 2026-10-07 and 10-08: the Senate tab (`gid=1260635943`) has col 1 beginning `Grade`, `First Name` and `Last Name` at cols 3-4, the state at col 5, and 47 graded rows. The House tab has col 1 `Grade (based on USCPR metric)`, col 2 `Rank`, cols 3-4 the names, col 5 `CD`, cols 6-8 the three scores, col 9 `2026 endorsements`, vote columns from col 10 to the first empty header cell (col 74, so 64), then `Total Pro-Israel $$$ …`. It has 214 member rows, 212 graded (A5 B5 C23 D61 F118) and two `N/A` (Wahab CA-14, Blair GA-13). **HALT** if a House header check fails. Counts that moved are reported, not a HALT. Senate labels that differ from the expectation become the check, flagged, since the sync has always parsed that tab by position.
- **M3, the House tab's id.** Open `${PALESTINE_TRACKER_SHEET}/edit` in Playwright, read the first tab's gid off the URL once it settles, and confirm `export?format=csv&gid=<it>` serves the House header. If it can't be read, the sync uses the bare export, which serves the first tab, and the House link keeps `/edit`. Flag it; no HALT.

## The build

### 1. A called seat's odds on the MAP, and the page's clock (fix)
- `app/electoral/page.tsx`: once `rows` exist, build the cartogram from `races` with `kalshiOdds: null` on every seat whose row is `result.called`. Before election day nothing is called and `races` passes through as is.
- `kalshiActive(odds, nowMs = Date.now())`; `kalshiDivergesFromConsensus` takes and passes an optional `nowMs`; `KalshiLine` takes an optional `nowMs` prop.
- The page's `nowMs` (already the clock of the ages and the windows, HO 490) threads through `ElectoralBoard` → `CartogramShell` → `RaceMapCard`, and `ElectoralBoard` → `RaceDistrictModal` → `RaceDistrictCard`. `buildReport(c, nowMs)` prints the market only when `kalshiActive(c.kalshiOdds, nowMs)` and odds are on. `RaceListView` passes its own `nowMs` at `:228`, `:439` and into the open row's `KalshiLine`. Server components keep the default.
- No new market site, so `check:odds-sites` passes with the allowlist as is.

### 2. The band at phone width, on both pages (fix)
- The rule moves onto the band: under 700px `.battlefield .ctl` and `.battlefield .ctl-legend` hide, and `.battlefield` takes `padding-bottom: 10px`. The `.electoral-band`-scoped rule and its comment go. At 430 the dashboard then reads its ELECTION DAY line alone (RESULTS after election day), as `/electoral` has since `8483000`.
- The new comment says why 700: labels 9% of the axis apart, ~36px wide at that size, clear from about 500px of track, and 700 is the band's own breakpoint, as `.races-hero-band`'s.

### 3. The calendar readout names its states (feat)
- `ElectoralBoard.tsx:208` prints `— {the locked dates' states, A to Z, space-separated} · {lockedContests} contests`. The hint stays, and in LIST it's now true. MAP's amber paint is unchanged.

### 4. The Tooltip follows a scroll (fix)
- `lib/in-sight.ts` exports `inSight(el)`: GradeCard's `chipVisible` body moved out whole (the window's bounds, then a `[data-scroll-box]`'s rect below its `[data-sticky-heads]`). GradeCard calls it.
- `components/Tooltip.tsx`: the placement in the layout effect becomes a `place()` callback. While open, a capture-phase `scroll` listener on `document` and a `resize` listener on `window` call it, and it closes the panel when `inSight(trigger)` is false. Nothing else changes: the 400ms delay, focus, Escape, `pointer-events: none`, `role="tooltip"`.

### 5. The MOVED guard (feat)
- `lib/move-freshness.ts`, pure: `MOVE_FRESH_DAYS = 8` and `isFreshMove(observedAt, chamber, syncRuns, historyRuns, horizons)`. A move logged on day T for chamber C is fresh when both hold:
  - a `/api/cron/rating-history` run with status `success` started in `[T − 8d, T)`, so T's log isn't a catch-up after a history gap;
  - S, the latest `/api/sync-race-ratings` run started before the end of day T with C's leg ok, exists, and so does S', the latest leg-ok run before S, with S − S' ≤ 8 days.
- A leg is ok on a `success` run whose payload has `chambers.<C>.ok` true and `chambers.<C>.stats.scraped > 0`, or, for the House on a pre-HO 744 run, `stats.scraped > 0`. A run that isn't `success` counts for neither leg, so one leg's failure can hide the other's moves for a week. That's the conservative side; the code names it.
- A move older than either route's first `cron_runs` row passes: the guard has nothing to read.
- `lib/queries.ts`: the read moves into a pure `readRecentRaceMoves(db, raceIds)` beside the other pure readers, and `getRecentRaceMoves` wraps it with the same key and tags. One `db.batch` covers four reads:
  - every post-baseline move for the ids, newest first per race, not `rn = 1`;
  - the sync route's runs (`started_at`, `status`, `payload`);
  - the history route's `success` runs;
  - each route's first `started_at`.

  Per race, take the newest move that passes; if none passes, there's no entry. `RaceMove` keeps its shape, and `/electoral`'s 14-day window (`MOVED_DAYS`, `lib/electoral-rows.ts:32`) stays.

### 6. The Palestine Tracker's House tab (feat)
- `lib/palestine-config.ts`: `PALESTINE_TRACKER_HOUSE_GID` (M3), and `palestineTrackerHref` sends a House member to `/edit#gid=<it>`.
- `scripts/sync-palestine.ts`, rewritten around its parser:
  - Dry by default; `--write` writes. Both tabs every run.
  - M2's header checks run first; a failure throws before any write. The House votes are col 10 to the first empty header cell; the Senate's stay at indices 8-30.
  - One `SELECT` loads the members (`bioguide_id, name, last_name, state, district, chamber`). The Senate matches as today, in memory. The House matches `CD` to `state` and `districtToken(district)` among `chamber = 'house'`. Then the sheet's last name must equal the member's `last_name` or appear in `name`, case- and accent-insensitive. Exactly one candidate passes, or the row is unmatched and logged with the reason.
  - Only A to F is stored; `N/A` and blanks are skipped and counted.
  - The dry run prints per tab: the header check; rows; graded by letter; matched; unmatched graded rows by name, CD and reason; skipped rows; changed grade, rank or score on stored rows, old → new; and the pool it would write.
  - `--write`: one `db.batch` of upserts per tab, then `dashboard_state` key `palestine_tracker_pools` with value `{"senate":{"graded":N,"read":"<iso>"},"house":{"graded":N,"read":"<iso>"}}`. Its last line names the flush it needs: `POST /api/revalidate?tag=palestine`.
- `readPalestinePools` takes each chamber's `graded` from that key as the pool when present, and the table count when not. `syncedAt` stays `MAX(synced_at)`.
- The `palestine` tag goes on the six readers of claim 10. `/api/revalidate` allows it, with a comment saying it's the manual path after a `--write`.
- **The write to prod comes before the review push**, on the HO 754 precedent: the Preview reads prod's database, so the review sees the House grades only if they're there. Dry-run against prod first (`SELECT` only). Write only if all four hold:
  - both headers pass;
  - House graded ≥ 200;
  - House unmatched graded ≤ 3, each with its reason;
  - Senate unmatched graded ≤ 1, with its reason, and no member matches twice.

  Otherwise **HALT** with the dry run. Then run `npm run sync:palestine -- --write` against prod once and paste its output. The flush waits for the FF, since `main` doesn't allow the tag yet. Until then the readers age out within an hour to a day, and the deployed code already renders House grades (GRADE 3).

## Tests and legs

- `test`: one hard assertion in `e2e/fit-finish.spec.ts`. On `/` at 430 with the Races tab open, the band's `.ctl` is hidden and its `.ctl-eday` visible; at 1440 `.ctl` is visible (the control).
- `diag`: `scripts/diagnostic/electoral-legs-768.ts`, built on the 767 driver's seed and copies (import what's exported, copy what isn't, and say which). Each leg has a red on HEAD (`8752512`) or a control.
  - **A**, on the marks copy at `CBT_CLOCK_NOW` 2026-11-04T15:00Z: on MAP, pin a state with a called seat that has a market. The card has no `.racecard-kalshi` on the called seat and one on an uncalled seat with a market (the control). The district export, its Blob intercepted as `odds-toggle-692` does, has no market line for the called seat and one for the control. Red: HEAD prints both. On the today copy, every MAP card with a market keeps it. `kalshiActive` on a `closeTime` one second either side of a fixed `nowMs`.
  - **B**: on `/` at 430 with the Races tab open, `.ctl` and `.ctl-legend` are hidden and the ELECTION DAY line shows. Red: HEAD shows them, overlapping. At 1440 nothing changes (control). `/electoral` at 430 and 1440 reads as at `8752512`. Report the featured labels' overlap on `/` with the Races tab open at 701, 768, 1100 and 1440; a reading over 0px is filed, not fixed.
  - **C**: in LIST, open the calendar and click two bars. The readout names the union of those dates' states as the dated list prints them, and the contests sum. MAP paints the same states amber (control). Red: HEAD prints *N states*.
  - **D**: on `/bills` at 1440, hover a `.tooltip-term` past 400ms. After a 120px scroll the panel's top moves with the trigger to within 2px; red: HEAD leaves it where it was. Once the trigger is scrolled out of sight the panel is gone. The delay and Escape work as before. Re-run leg 4 (g) of the 767 driver for the grade card on the shared helper.
  - **E**: `isFreshMove` against planted runs:
    - weekly runs: fresh;
    - a 20-day gap, then a batch: not fresh;
    - a first Senate leg: not fresh;
    - a 10-day history gap: not fresh;
    - an `error` run as the only one before: not fresh;
    - a move before the horizon: fresh.

    Then M1 again through the built reader against prod. `/electoral`'s MOVED rows on the today copy, before and after: the guard explains any row that changes.
  - **F**, on a copy with `--write` run against it:
    - Pappas's member row on NH SEN carries a chip, and its card reads *of {House graded} House Democrats*.
    - A House Democrat's member page shows the Scorecard tab with 64 votes and *Rank #N of {House graded}*.
    - A House Republican has no chip (control).
    - Shaheen's chip reads as before, refreshed (control).
  - **The 767 driver's legs 1-7, re-run** as the regression read. One expectation moves with this HO: R1's *one chip on NH SEN* is two now, Shaheen's and Pappas's. Update that check in the same `diag` commit and name it in the paste.
- **The layout audit** at load on `/electoral` and `?cycle=2028`, against register line (xi) and (iv⁗). House rows gain chips, so a change is priced or fixed.

## Docs

- **roadmap**, the HO 768 block: the ruling verbatim; HO 767's FF readings and its two close rulings, from the carry file; STEP 0's results with M1-M3; the build; the legs; the write's output; and anything flagged.
- **backlog**:
  - Strike the six lines, each with a one-line close note on its evidence: the leg, or for the House tab the write plus `getPalestinePools().house` read on the review build.
  - HO 758's Nov-4 WATCH, rewritten whole: after *a called seat with no Kalshi line in its open row*, add *and none on its MAP card*.
  - File one line: *The Palestine Tracker syncs by hand, so its rows age unseen: the Senate tab's 47 were last read 2026-05-20, until HO 768's write.* Owner Code, low. Close on a scheduled sync carrying the header checks. Reads if never done: `MAX(synced_at)` ages past 30 days.
  - OPEN LOOPS 68 → 63 live, reconciled, control 0.
- **oddities**: *The election clock counts UTC days*, as the carry file drafts it, with its ruling.
- **method.md**, its own `docs` commit, verbatim:
  - After § Handoff discipline's *Enumerate-first* bullet, insert:

    ```
    - **When the handoff carries the architect's closure table, STEP 0 is a check, not
      a HALT** (Corey, HO 768, verbatim: *"pls stop stopping and waiting"*). The
      architect enumerates from the clone at the base SHA and states each claim with
      its `file:line`, and each measurement with its bound. Code re-derives them at
      its HEAD and goes on through the build, legs, docs and review push unless one
      fails; a failed claim, or a reading outside its bound, HALTs as before. Scope
      the architect could not enumerate keeps the HALT.
    ```
  - In § Executing's first bullet (the old text wraps across two lines in the file):

    ```text
    OLD: STEP 0 closure table, then HALT — nothing executes before the table is read (§ Handoff discipline).
    NEW: STEP 0 closure table, then HALT — nothing executes before the table is read — unless the handoff carries the architect's table, which STEP 0 checks and HALTs on only when a claim fails (§ Handoff discipline).
    ```
- **SKILL**, its own `docs(skill)` commit, last. Ten edits, each verbatim. Every OLD string occurs once at `8752512`, and STEP 0 reads each NEW string's facts against the tree before it lands. An AFTER edit appends its text, leading space included, directly after the anchor.

  1.

  ```text
  OLD: and under 700px its axis and legend give way to the ELECTION DAY line alone (`.electoral-band`, `app/globals.css`; at 430 the six labels ran into one another. The dashboard's own band, behind its Races tab, still does at that width; the scope guard left it)
  NEW: and under 700px its axis and legend give way to the ELECTION DAY line alone, here and on the dashboard alike (`.battlefield`'s phone rule, `app/globals.css`, HO 768: at 430 the six labels ran into one another, and `/electoral`'s `.electoral-band` stopgap retired with the fix)
  ```

  2.

  ```text
  AFTER: Runoffs stay out, as `getPrimaryCalendar` reads first rounds.
  NEW:  A locked date names its states in the readout (*{dates} — {states} · {N} contests*), so the locks read in LIST too, where the map they paint is one toggle away (HO 768).
  ```

  3.

  ```text
  OLD: and a long window would print those as recent; the guard that would hold this by itself is filed.
  NEW: and a long window would print those as recent. **Since HO 768 a guard holds it by itself** (`lib/move-freshness.ts`, inside `getRecentRaceMoves`, so the dashboard's MOVED reads it too): a move counts only when its chamber's ratings leg succeeded twice within 8 days, the run behind the move and the one before it (a `success` row in `cron_runs` whose leg scraped rows), and the rating-history tick succeeded in the 8 days before the move was logged. A race whose newest move fails shows its newest move that passes, and a move older than either route's first `cron_runs` row passes, with nothing to read.
  ```

  4.

  ```text
  OLD: **A called seat's odds hide on the result, never on a market's close** (`kalshiActive` compares `Date.now()`); the MAP's cards keep theirs (filed).
  NEW: **A called seat's odds hide on the result, never on a market's close**: on the rows and the open row by `result.called`, and on the MAP's pinned card, district card and export because the page strips a called seat's market from the map's contests (HO 768). `kalshiActive` takes the page's `nowMs` on every client site, so a market closing between the server render and hydration can't flip a node (the HO 490 class).
  ```

  5.

  ```text
  OLD: Its rank is out of the table's pool for the member's chamber (`getPalestinePools`); the three typed *of 47* read that count.
  NEW: Its rank is out of the tracker's pool for the member's chamber (`getPalestinePools`): the graded rows the sync last read off that tab (`dashboard_state` `palestine_tracker_pools`), not the rows it matched, so a member the matcher misses never shrinks the denominator. The three typed *of 47* read that count.
  ```

  6.

  ```text
  OLD: The tracker's address is one constant (`lib/palestine-config.ts`), which the card, the member page and the sync's export read.
  NEW: The tracker's address and its two tab ids are constants (`lib/palestine-config.ts`), which the card, the member page and the sync read. **Both tabs sync by hand** (`npm run sync:palestine`, dry by default, `--write` to write; HO 768): the Senate tab matched by surname and state, the House tab by its `CD` and surname, A to F only. A write is followed by one `POST /api/revalidate?tag=palestine`, the tag every reader of `palestine_scorecard` carries.
  ```

  7.

  ```text
  OLD: Hover AND focus both open; Escape closes.
  NEW: Hover AND focus both open; Escape closes. While open the panel follows its trigger on scroll and resize and closes once the trigger is out of sight (HO 768; `lib/in-sight.ts`, the grade card's rule, shared).
  ```

  8.

  ```text
  OLD: That is right for a coded term's name, and the Tooltip is untouched.
  NEW: That is right for a coded term's name, and HO 768 left it so.
  ```

  9.

  ```text
  OLD: The Tooltip's own scroll behaviour is a backlog line: its panel neither follows nor closes on a scroll, which holds by code (`components/Tooltip.tsx` places it once per open). The touch half first filed with it was read at HO 767 and didn't reproduce, so the line carries it as a sentence of record only.
  NEW: Since HO 768 the Tooltip follows a scroll and closes out of sight by the card's own rule; the touch claim filed beside that defect at HO 767 didn't reproduce and was struck with it.
  ```

  10.

  ```text
  AFTER: markers carry `data-seat={raceId}` for the HO 260 cross-highlight.
  NEW:  Under 700px its axis and legend hide and the ELECTION DAY line, or HO 758's RESULTS line, stands alone, on the dashboard and `/electoral` alike (HO 768: at 430 the featured labels, `FEATURED_MIN_GAP` 9% of the axis apart, ran into one another).
  ```

  If M3 reads no gid, edit 6 says *its Senate tab's id* in place of *its two tab ids*, and the paste says so.

## Commits

On `768-review` from the start. Kinds unmixed:
- `fix` 1, `fix` 2, `feat` 3, `fix` 4, `feat` 5 and `feat` 6;
- `chore` for anything comment-only;
- `test`, then `diag`;
- `docs` for the block, backlog and oddities;
- `docs` for method.md;
- `docs(skill)` alone, and last.

After the push, new commits only: no amends, no force. If the classifier blocks a push, Corey runs it from your checkout.

## Paste back, once

- `git ls-remote --heads origin` with the review ref's SHA;
- the Preview's `narrow-preview` on that SHA;
- STEP 0: every claim passed or failed, and M1-M3 with their readings;
- the tracker's dry run and its write, both outputs;
- every leg, pass/fail with counts, and the audit;
- `git show --stat` per commit, and `--numstat` for the docs commits with every deletion explained;
- the reconcile;
- a last cheap-gate run right before the paste.

The FF go follows my read of the ref. It will carry the FF, `verify:deploy` in the foreground, the Production `e2e-prod`, one `POST /api/revalidate?tag=palestine` with `$CRON_SECRET` by env name, and the prod reading.
