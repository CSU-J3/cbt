# HO 782: Cook's two seed snapshots leave the public repo before Corey answers Cook, and SKILL stops calling the seed files the source of truth

**Corey's ruling, 2026-10-13 (answered by selection).** Cook replied on 10-12 to the 10-09 API request: access needs a subscription, at a level set by the use case, plus a signed licensing agreement; and it asked three things: how the Ballotpedia pull worked and what changed, who has access to the site and how it works, and whether others could replicate it. Asked whether the two Cook snapshot files in the public repo come out before he replies, Corey chose *Remove them before I reply*. His other two rulings (keep Cook's frozen 09-30 column up and offer to take it down; ask the price before deciding) live in the email, not in code.

**Why.** `github.com/CSU-J3/cbt` is public and MIT, and `data/race-ratings-cook-2026.json` (35 Senate rows, a Jan 12 Wikipedia snapshot with the Apr 13 updates applied) and `data/race-ratings-cook-house-2026.json` (62 House rows, May 19) are Cook's ratings in it. Nothing reads them but `scripts/seed-race-ratings.ts`, a first fill for an empty database. While a license is being negotiated, the honest state of the repo is code only, and the reply will say the files are gone, so this lands first.

**Scope, in:**
1. § 1, the two files and one line in the seed script's header (`chore`).
2. Docs: the roadmap block, the Cook backlog line, a new backlog line for the other four seed files, and SKILL's two stale sentences.

**Out:**
- Inside Elections' and Sabato's four seed files. They get a backlog line and go when those raters answer, or when Corey says.
- Git history. The files stay in it, as every deleted file does. No rewrite.
- The database. Prod's `race_ratings` rows, the seed-origin ones included, don't move.
- `scripts/seed-race-ratings.ts`'s code, and `package.json`'s `seed:ratings`.
- Every UI file. No prod write.

**How STEP 0 runs** (method.md, HO 768's rule): the claims are mine, read at `bae5790`, and are a check. Go on through the build, docs and the review push unless one fails.

**Base:** `781-review`'s head, so `782-review` branches from there and one FF takes both. If 781 has already been fast-forwarded when you read this, base on `main` at its head instead. HO number: with 780 and 781 ahead of this one, the pointer and the highest HO in commit subjects are both 781, so this is 782.

## STEP 0

| # | Claim at `bae5790` | Fails if |
|---|---|---|
| 1 | `git ls-files data` lists six `race-ratings-*.json` files: Cook, Inside Elections and Sabato, one Senate and one House file each. The Cook pair holds 35 and 62 rows. | a seventh file, or another count |
| 2 | `scripts/seed-race-ratings.ts` is the only code that reads them: `DATA_DIR` and `SEED_PATTERN` (`:53-54`), `readdirSync(DATA_DIR).filter(…)` (`:64-65`), and the warning when nothing matches (`:84-85`). `grep -rn race-ratings-cook` over `app lib components scripts e2e` returns nothing. | another reader |
| 3 | SKILL names the Cook file once, in the `race_ratings` schema comment (`:365-366`), and calls the seed files the source of truth once (`:2946`, beginning *Race ratings are hand-seeded.*). `:1355` (`npm run seed:ratings`) names no file and stays. | a second occurrence of either |
| 4 | README names neither file, and its credits line (`:157-159`) already says Cook's and Inside Elections' ratings are as Ballotpedia last carried them on 2026-09-30. | |

SKILL line numbers are at `bae5790`; 780's and 781's `docs(skill)` commits may move them. The OLD text is the anchor, and it must occur exactly once.

## § 1, the files (`chore`)

- `git rm data/race-ratings-cook-2026.json data/race-ratings-cook-house-2026.json`. Explicit paths, nothing else staged.
- `scripts/seed-race-ratings.ts`, header comment: after its line 4 (*quarterly refresh workflow.*), one new line inside the same comment block, verbatim:

```text
// Cook's two files left the repo in HO 782 (SKILL, race_ratings); a fresh
// database holds no Cook rows until Cook is wired.
```

  Nothing else in the file changes.

## Leg

No runtime changes, so one reading and the cheap gates.

**A, the tree.**
- The red: on the base, `git ls-files data | grep -c race-ratings` reads 6.
- The green: on `782-review`, it reads 4, none of them Cook's; and `git grep -l race-ratings-cook` lists only `docs/roadmap.md`, `docs/backlog.md`, `scripts/seed-race-ratings.ts` and `.claude/skills/cbt/SKILL.md`, each naming the files as removed.
- Typecheck and build pass unchanged, since nothing imports the files.

## Docs

The roadmap and backlog are public. Paraphrase Cook's reply; no names, no quoted text.

**roadmap:** the HO 782 block: Cook's reply as the first paragraph above has it, the ruling and its three parts, the why, § 1, leg A, and what stays (the four other seed files, the history, the database).

**backlog:**
- **The Cook line** (`:16`) gains, in order: Cook's 10-12 reply, as above; the 10-13 rulings; *the two seed files removed, HO 782*; and *Corey replies after this FF; the site keeps Cook's 09-30 column, credited and linked, and the reply offers to take it down.* Owner stays Corey.
- **New line:** **Inside Elections' and Sabato's four seed snapshots are still in the public repo (HO 782).** opened 2026-10-13; *Owner:* **Corey**. Early-2026 snapshots, read by nothing but `npm run seed:ratings`. Cook's two left under HO 782; these go when Inside Elections and the Crystal Ball answer the 10-13 emails, or sooner if Corey says. *Close:* the files leave, or a rater's answer makes keeping them fine.
- Reconcile, with the control at 0.

**SKILL**, in its own `docs(skill)` commit, last. Two replacements, verbatim.

(1) The schema comment, at `:365-366`:

```text
OLD: -- "competitive" filter. Seeded by `npm run seed:ratings` from
     -- data/race-ratings-cook-2026.json; refresh quarterly.
NEW: -- "competitive" filter. Rows are written by the ratings sync
     -- (lib/race-ratings-sync.ts). `npm run seed:ratings` is a first fill from
     -- data/race-ratings-*.json; Cook's two files left the repo in HO 782.
```

(2) The whole bullet at `:2946`, which begins `- **Race ratings are hand-seeded.**` and ends `don't hand-write a rating from memory.`:

```text
NEW: - **Race ratings are synced, not hand-seeded (HO 88, HO 770).** `race_ratings` is written by the ratings sync (`lib/race-ratings-sync.ts`), one reader per rater since HO 770. The `data/race-ratings-*.json` files are early-2026 snapshots that `npm run seed:ratings` applies as a first fill to an empty database, and nothing reads them after that. Their `race_id`s are the races table's `S-<STATE>-<YYYY>` / `<STATE>-<DD>-<YYYY>` ids, with Senate specials collapsed onto the regular-cycle id because the races table keys Senate seats by `next_election_year` alone. Cook's two files left the repo in HO 782, while Cook's API license is negotiated, so a fresh database holds no Cook rows until Cook is wired; Inside Elections' and Sabato's four stay until those raters answer (backlog). **Source recall is not a substitute for sourced data here**: a rating is read from the rater, never written from memory.
```

The dropped clause about Wikipedia-pulled ids being find-replaced is the deleted Senate file's own history; its `note` field carried it, and the file is gone.

## Commits

On `782-review` from `781-review`'s head (or `main`, per Base), kinds unmixed:
- `chore(HO 782)`: § 1;
- `docs(HO 782)`: roadmap and backlog;
- `docs(skill)`: alone and last.

Build, then the cheap gates, before the push. No migration, no prod write.

## Paste back once, for 781 and 782 together

781's list, then:
- `ls-remote` with `782-review`'s SHA;
- STEP 0;
- leg A, red and green;
- `--stat` per commit, `--numstat` for docs with every deletion explained, and the SKILL diff;
- the reconcile;
- a last cheap-gate run.

Build through to the review push without stopping. A failed claim HALTs; nothing else does.
