# HO 695 — method.md: four rules HOs 690–694 produced, and the Code protocol comes home

Docs kind. No code, no SKILL. Two docs commits: `docs(method HO 695)` carrying `docs/method.md` alone, so the review reads one diff, then `docs(HO 695)` for the roadmap block and the backlog reconciliation. Corey's go: *"send it"* (2026-09-05), against the shape stated in chat: three rules from the session plus the standing Code instruction block, which was always a paste artifact whose long-term home was this file. A fourth rule (host dependence) is added because 694's CI catch produced it after that shape was stated; it is listed so the widening is visible, not absorbed.

**Why these four and no others.** Each is a rule that, had it existed in writing, would have prevented a failure that actually happened this week, and none is already in method.md or SKILL (cross-reference where SKILL carries a neighbour). The rest of the session's lessons are already recorded where they belong (the 692 gate rule and its limit in SKILL; the 694 container derivation in its CSS comment and SKILL).

## Ground truth at authoring (`692904f`, HO 694 shipped 2026-09-04)

- Clone at `692904f`, pointer 694, number `max(694, 694) + 1 = 695`. Re-derive at session open.
- `docs/method.md` is 363 lines; sections at `:12` Roles · `:23` Session start · `:39` Handoff discipline · `:60` Gates (the eleven-instance preamble `:62–77`, the instance bullets `:79–181`, the rule bullets `:182–288`) · `:289` Relay · `:302` Doc authority and conventions (the roadmap bullet `:307–310`) · `:319` Product scope · `:333` Environment (`:338` the Windows box, `:342` the MacBook) · `:355` Memory hygiene. It is edited in place; it is not append-only.
- The standing Code block is a chat-side `.md` artifact (`cbt-code-standing-instructions.md`, 46 lines), pasted at Code's session start, whose own header says method.md wins where they disagree. Its sections: Session open · Before executing anything · When the handoff is wrong · Gates · Commits · Paste back. Several of its lines restate SKILL rules (review-ref route, kinds-pure commits, self-mod guard, `--force-with-lease` on the ref) and become cross-references; the rest are Code-side discipline method.md does not yet state.
- **The evidence for each rule, so the roadmap block can cite it:** roadmap-block mutability — HO 694's own block amended twice on the review ref before FF, and the 690 precedent of correcting a landed block in the commit message rather than the text. Ground-truth quotation — STEP 0 corrected the architect's ground truth in five consecutive HOs: 690 (three figures, marked as estimates and measured), 691 (a `loser` status the schema comment never had; an incumbent clause the live data broke; coverage figures two months stale), 692 (a wrong mechanism, "fixed track" for grid auto-placement), 694 (two of five SKILL-exposure rows citing entries SKILL never had). Comment assertions — 694's roster header paragraph, the one unmeasured claim in a change that measured everything else, and the one wrong one; neither gate could see it. Host dependence — 694's first CI run red on `/lobbying` at 430 by 7px twenty minutes after a by-hand prod run read it clean on the same SHA (Windows vs Ubuntu font metrics moving a flex line break), fixed with a metric-independent rule.

## STEP 0 — enumerate, then proceed (no HALT expected)

| # | candidate | expected |
|---|---|---|
| 1 | method.md at HEAD | sections and line ranges as cited; confirm nothing already states any of the four rules (grep `mutable`, `quote`, `comment`, `font`, `Ubuntu`) |
| 2 | the standing block, line by line | each of its ~24 rule lines classified: **restates SKILL** (→ cross-reference by section name) · **restates method.md** (→ drop) · **new** (→ lands verbatim or tightened, in the section named in STEP 1) · **obsolete** (→ dropped, with the reason — check `build then typecheck` ordering and the `lsof`/`ss` bind check against current practice) |
| 3 | backlog | any entry for the standing block's migration, or for the method.md pointer to it; the OPEN LOOPS reconciliation at open |
| 4 | SKILL neighbours | the section names the cross-references will cite exist at HEAD: "Review-ref route", "Owner verdicts in a relay", "Pre-flight verification", "Process cleanup", "Clock discipline" |

## STEP 1 — `docs/method.md` (commit 1, alone)

Land these; wording is the deliverable, so keep it unless it is wrong against the tree. House style: bold lead, provenance **after** the sentence, never inside it (the HO 690 splice rule).

**§ Doc authority — replace the roadmap bullet (`:307–310`) with:**

> - **`docs/roadmap.md`** — append-only narrative. One new `Also (HO N)` block per handoff, pointer advanced. **A block is mutable until its FF lands; once on `main` it is history.** On the review ref the block is a workspace: amend it so it ships true (a "six commits" clause that is already false is worse than an amended block). After FF, a correction goes into the next HO's block or the commit message, never into the landed text; a supersession marker on a prior block's pointer is the one permitted touch (HO 615). Ruled at HO 694, where the block was amended twice before FF and the 690 correction had gone into a commit message.

**§ Handoff discipline — add after "Probe before build":**

> - **A ground-truth paragraph quotes what was read at the stated SHA and marks everything else as an estimate.** A status domain, a column shape, a SKILL entry or a CSS mechanism is read — the schema comment, the `CREATE TABLE`, the SKILL heading, the computed style — and cited by `file:line`; it is never recalled. A figure the architect cannot measure is written as `~N (estimate; STEP 0 measures)`, and STEP 0's job is to replace it. Five consecutive handoffs had their ground truth corrected at STEP 0 (HO 690–694); the corrections that were not estimates were all of this kind — a `loser` status the schema never had (691), a SKILL clause that did not exist (694), a mechanism named from memory (692). The loop caught every one, which is what STEP 0 is for; the rule exists so it has less to catch.

**§ Gates — add to the rule bullets, after "Any convenient check: name the authoritative one":**

> - **An assertion in a comment is covered by no instrument.** A comment records a measurement — what was read, where, when, the number — or says in so many words that it is reasoning. HO 694's roster-header paragraph was the only unmeasured claim in a change that measured everything else, and the only wrong one: five children auto-flowed a cell early, RATE sat over ENACT, and neither the 430 gate (misalignment does not overflow) nor the ON baseline (the cell was not in its set) could see it. Measure it, or cut the claim back to the measured half and say which you did.

**§ Environment — add after the MacBook bullet:**

> - **CI runs on Ubuntu; the Windows box and the MacBook do not.** Font metrics differ per host, so anything that depends on where text breaks — a flex line, a `nowrap` label, a wrapping breadcrumb — can read clean locally and fail in CI on the same SHA (HO 694: `/lobbying` at 430 over by 7px in CI twenty minutes after a by-hand prod run read 430/430). Prefer rules whose outcome does not depend on metrics (`flex-basis: 100%` over a tuned cap; `break-word` over a fixed width), and treat the CI reading as the reading for any width gate — a green local run is a prediction of it, not a substitute.

**New section — `## Executing a handoff (Code)`, placed after § Handoff discipline and before § Gates.** The standing block comes home here. Fold its lines by the row-2 classification: cross-reference the SKILL restatements in one bullet (*review branch from the start, kinds never mixed, the SKILL diff approved alone, `--force-with-lease` on the ref only, `HEAD:main` with no force, then `git ls-remote` — SKILL, "Review-ref route"*); drop what method.md already says (clone fresh, ls-remote, ledger reconciliation — § Session start); land the new lines, tightened, under four sub-bullets:

> - **Before executing:** STEP 0 closure table, then HALT — nothing executes before the table is read (§ Handoff discipline). Re-derive every line number at your HEAD; a handoff's anchors are as-of its base SHA and any edit above them invalidates them. Controls before zeros: a positive control reads > 0 on the same invocation before any zero is trusted. Bare-substring greps — never prefix-sweep, never quote-anchor.
> - **When the handoff is wrong:** flag, don't absorb. A forced consequence of an approved change is not a widening; say which it is. A gate that is internally inconsistent, or a discriminator that cannot fire on this change, is a defect in the handoff — report it and propose the replacement; never gut a RECORD comment or contort the tree to satisfy a literal check. Don't assert what you haven't measured. Findings caught in relay are filed (backlog or oddities), never left in chat.
> - **Gates, Code-side:** build, then typecheck (a stale `.next/types` reads as a code failure otherwise). Bind check before any curl is trusted — the socket mapped to your PID, kill by PID and port-scoped, foreign PIDs left alone (SKILL, "Process cleanup"). A freshness discriminator derives from something this change alters or from the transport — a token the change removes plus a control token that survives. Real ids only in probes. Never trigger `/api/sync` locally.
> - **Paste-back:** table deltas as executed · `git show --stat` per commit · gate outputs including the bind evidence · the backlog numstat with every deletion explained · the docs and SKILL diffs · every remote claim via `git ls-remote`. Never delete struck text; strike is `~~…~~` plus a one-line close note. The numstat deletions column is the authority; `grep -c '^-[^-]'` is not a deletion count. One swallowed block re-delivers as a gitignored file, never a second paste (§ Relay).

Where a row-2 verdict says a line is obsolete, it is dropped and the roadmap block names it. The section's first line states the contract the artifact's header stated: *the repo is ground truth; this section is what Code reads at session start instead of a pasted block.*

## STEP 2 — read it back

`git diff --numstat` on method.md (expected on the order of +60 / −4: one bullet replaced, three added, one section). Every replaced line verified to retain its prior content (the roadmap bullet keeps the HO 615 marker sentence). Read each cross-reference's target heading in SKILL at HEAD (row 4). Read the new section top to bottom once as Code would at session start: nothing in it should send the reader to a chat artifact.

## STEP 3 — docs (commit 2)

Roadmap `Also (HO 695)` + pointer, citing the evidence paragraph above per rule and the row-2 classification (how many lines came home, how many became cross-references, how many dropped and why). Backlog: strike or annotate any migration entry with provenance; OPEN LOOPS reconciled. Oddities: nothing, unless STEP 0 surprises.

## STEP 4 — review ref, FF

`695-review`, ls-remote, architect review of both commits (method.md is the substance), FF, ref deleted. No deploy verification is owed — nothing served changes; say so rather than skipping it silently.

## After FF (chat-side, for Corey and memory)

The paste-at-session-start artifact retires. What Code gets at session start becomes two lines: *clone fresh; read `docs/method.md` — § Executing a handoff is yours.* Memory's "standing Claude Code instruction block … long-term home is docs/method.md" entry is then true and can shorten to the pointer.

## Paste-back

STEP 0 table with the row-2 classification in full. The method.md numstat and the replaced-line check. The roadmap block. After FF: ls-remote.

read and follow 695
