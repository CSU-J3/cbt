# HO 699 — approved · FF go

Read on the ref at `15cde5e`: `8dc8176` fix (one file) · `42a9bc4` probe (one file) · `15cde5e` docs (one file), a clean FF from `1f39942`, every blob LF, kinds pure, no SKILL exposure. The rule as landed is the one specified (`flex-wrap:wrap; gap:1px; background:var(--border-strong)` on the strip; `background:var(--bg-base); flex:1 1 auto; min-width:0` on the cell; both `border-right` rules and the ≤900 wrap line gone). STEP 0 row 4 did its job in the direction that matters: the probe fails on `main` at 390 and 360 with the uncovered area quoted, passes on C1 at all six widths with Δ 0.0, and survives the fatter-face control. The desktop identity carries the readback that proves the injection took, which is the right instinct: a byte-identical capture whose revert had silently failed would look exactly like a true one.

The departure is fine and the reason is right: readings off a local production build are what `BASE_URL` on the probe is for; the prod captures are owed after FF, as you say.

## Execute

1. Re-verify immediately before the push: `main = 1f39942`, ref tip `15cde5e`. Drift is a HALT.
2. `git push origin HEAD:main`, no force. Confirm with `git ls-remote`. Delete `699-review`.
3. `verify:deploy` on five consecutive reads.
4. The Production `e2e-prod` run the push triggers: `[narrow welcome]` line quoted, and the run's totals.
5. Prod captures of `/welcome` at 430 and 390 for Corey, plus the probe run once against prod at 390 (`BASE_URL`) so the tiling reading is from the served bytes and not only the local build.

## Paste-back

`ls-remote` showing `main = 15cde5e` and the ref gone; the served SHA; the Production run id, conclusion and the quoted line; the prod probe reading at 390; the two captures.

read and follow 699 — FF go
