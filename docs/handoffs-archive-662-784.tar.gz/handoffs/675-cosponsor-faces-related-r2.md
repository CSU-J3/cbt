# HO 675 — the bill panel's roster half: related bills R2 with cross-chamber identicals promoted, and cosponsor faces party-split

**Read this file in full before executing anything. Execute in order. HALT conditions are hard stops — report and wait, do not improvise past them. Three HALTs: the STEP 0 closure table, the STEP 3 captures, and the pre-land review ref. Nothing lands on `main` before the last is approved.**

Base: `main` at `1304155` (HO 674 landed) or later. Clone fresh; verify HEAD before starting (`docs/method.md` § Session start). Number per method: max(roadmap pointer 674, highest commit-subject 674) + 1. Environment: code edit + `npm run build` then `npm run typecheck` (build first), plus local `npm run start` renders **with captures**. **Bind check mandated on every start.**

**`docs/method.md` § Gates applies in full.** This is render-touching work, so the capture requirements are not optional and a paste without them reopens a closed entry. HO 673 was the section's first outing and the section's own subject turned up inside the captures it demanded — an unloaded `<img>` over a dark panel background is pixel-identical to a deliberate tile. Expect that class of thing again.

## What this HO finishes

HO 673 ruled three designs against mocks and shipped one. HO 674 ingested the data the other two were blocked on: `bill_cosponsors` 168,610 rows / 14,033 bills, `bill_related_bills` 10,254 relationship rows / 6,768 bills, cosponsor rows resolving to a member at **100.00%** and related rows to a bill at **99.20%**. This HO renders both.

**Ruling records:** `docs/design/mock-673-sponsor-cosponsor.html` and `docs/design/mock-673-related-bills.html`, committed at HO 673. **The mocks win on visual detail; this HO wins on scope.** Anything a mock shows outside the cosponsor row or the related-bills list is a finding, filed, not built.

## The related-bills ruling, as decided by Corey

HO 674 measured that **there is no `Companion` relationship type.** The design said "companion promoted into a bordered line above the rest"; the data says `Identical bill`. Corey ruled on 2026-08-19:

1. **Promote cross-chamber identicals only.** A companion is the other chamber's twin — it tells you the bill has a parallel track. Same-chamber identicals are duplicate filings or reintroductions: a different and less interesting fact. They stay in the regular list below, **not dropped**.
2. **Match `identical` case-insensitively, never by equality.** `Identical Bill (Became Law)` (24 rows) differs from `Identical bill` by a capital B and an appended clause; `= 'Identical bill'` drops it silently. Those 24 are arguably the most interesting rows in the set — the twin became law and this bill did not — and the promoted line should say so where it applies.
3. **The promoted element is a bordered block of one to n, not "the companion".** 69 bills carry more than one identical, so a singular referent does not exist for them. Promoting all cross-chamber matches keeps the visual idea without forcing a pick.

**STEP 0 must answer, because the ruling assumed it:** how many of the 69 multi-identical bills have more than one *cross-chamber* identical, as opposed to a mix of one cross-chamber and one same-chamber? If the answer is small, the block is usually one row and the design is unchanged. If it is large, say so — that is a finding for Corey, not a decision to make in the diff.

## The cosponsor ruling, unchanged from HO 673

- **Six** face slots total.
- **Party-split** by the actual party breakdown of the cosponsor set, not fixed 3/3.
- **Unused shares redistribute** — a party whose share rounds below its allotment gives the remainder to the other rather than leaving a slot empty.
- **Names on hover.**

**Withdrawn cosponsors are excluded from the faces and from the count the split is computed on.** HO 674 stored them deliberately (`sponsorship_withdrawn_date` nullable, 77 rows corpus-wide) precisely so this decision could be made rather than inherited. A withdrawn cosponsor is not a cosponsor; if the panel ever needs to show them it is a later ruling.

## STEP 0 — enumerate; closure table; HALT

Line numbers re-derived at HEAD (HO 652). **Controls first.** Table (candidate · verdict · evidence `file:line` · destination) covering at least:

1. **The query surface.** HO 674 shipped **no query** and deferred the cache-tag pricing to this HO. Name the query or queries these two lists need, where they live, and their tag. **Price them**: rows read per panel open, against the panel's current cost. HO 671/672 measured a `bills`-tagged entry at ~89,090 rows per flush at ~7.3 flushes/day — if these lists join a `bills`-tagged query, say what that does to the number. If they belong on the existing lazy `GET /api/bill/[id]/panel` fetch rather than the row payload, that is likely the cheaper answer; rule it with evidence.
2. **Where the panel gets its data today.** The HO 673 work established the panel renders on **seven routes** via `BillRowList` and `V2FeedList`. Does the roster ride the row payload (paid on every row, everywhere) or the lazy panel fetch (paid on open)? **This is the single biggest cost decision in the HO** and it is a STEP 0 ruling, not a STEP 1 convenience.
3. **The apportionment rule, written as arithmetic before it is coded.** Six slots, party counts `(d, r, other)` over the **non-withdrawn** set. State the rule, then state what it returns at: `d=0`; `other>0`; fewer than six cosponsors; exactly six; a party at exactly half. **Name the tie-break.** This is the only real logic in the HO and it is ruled on paper first.
4. **Portrait provenance for cosponsors.** Faces need images. HO 673 established two `SponsorPhoto` implementations with different hosts (`components/SponsorPhoto.tsx` builds from bioguide ID; `BillExpandPanel.tsx:152` uses stored `depiction_url`). **Which does this HO use, and does `members.depiction_url` cover the cosponsor population?** HO 673 measured 551 of 553 members carry one — confirm that holds across the cosponsor set specifically, and name the fallback.
5. **Layout shift.** HO 673 measured the metabox growing +76px, contained. Six faces plus a promoted related block will grow it further. **Predict the delta before capturing it**, then show it.
6. **The `identical` predicate itself.** Write it out. Show it matching all six relationship types correctly — the four common and the two tail values — with a control proving it rejects `Related bill` and `Procedurally related`.
7. **Cross-chamber derivation.** How chamber is determined from a bill id, and what happens on an id that does not parse. The 82 unresolved related ids (0.8%) are already filed; state what the UI does with a promoted row whose target is not in `bills`.
8. **Out of scope, named:** `bills.cosponsor_count` and its 13.8% drift — filed, and this HO must not "fix" it by quietly rendering the roster size in the count row; the stage bar; the nine `if (await X.count())` e2e guards; `docs/design/` policy; `HeaderBar`/`--font-mono`/tape unification; the `builtAt: null` filing.

**HALT.** Paste the table. A changed verdict is a good outcome.

## STEP 1 — the chore commit

`git checkout -b 675-review-local` first. One commit, one kind:

`chore(HO 675): cosponsor faces party-split, related bills R2`

**Shared surface, deliberate.** The panel is on seven routes and the change lands on all of them unscoped, per the HO 673 ruling — two behaviours for one panel is worse than one behaviour everywhere. The consequence is paid in captures, not in a prop.

## STEP 2 — gates

- `npm run build` ✓ then `npm run typecheck` ✓, **re-run immediately before the paste** (§ Gates: a gate binds to the state at the paste).
- `git show --stat` lists only approved files.
- **Built-CSS check, both halves** — new selectors read non-zero, any dropped selectors read 0, each against a live control. HO 673 established the symmetric form; do not ship only the excision half.
- Greps **classified, not counted**. HO 673's `git grep -c … | wc -l` counted files and discarded counts. State what each number means.

## STEP 3 — runtime and captures; HALT

Bind check first. Content assertions are necessary and **not sufficient**.

Captures at a named viewport set plus a separate `prefers-reduced-motion` pass, across the seven-route census, and specifically:

- **Cosponsors:** zero; one; fewer than six; exactly six; many; **a bill with a withdrawn cosponsor** (`119-hr-452`, measured at HO 674 — 300 stored, 299 active, 1 withdrawn) proving the withdrawn face is absent and the split is computed on 299; a bill whose cosponsor set is **single-party**, which is where redistribution actually fires.
- **Related:** a bill with a cross-chamber identical; one with a **same-chamber** identical (proving it stays below rather than being promoted or dropped); one of the **69 multi-identical** bills; one carrying an `Identical Bill (Became Law)` row; one with related bills but **no** identical; one with none at all; and one whose promoted target is among the **82 unresolved ids** if such a bill exists — if not, say how you established that.
- **A missing cosponsor portrait**, found by probe rather than by browsing. HO 673's fallback was 2 bills in 17,722 and would have been unfindable otherwise.
- Console clean; no horizontal overflow; the stage bar and the sponsor block unchanged against before captures.

**HALT.** Paste captures and readings.

## STEP 4 — docs commit (`docs: HO 675 — …`)

- **`docs/backlog.md`** — strike the ruling-2 and ruling-3 entries with their close criteria shown. Open anything STEP 0 surfaced. If the multi-cross-chamber count from STEP 0 is large enough to make the block routinely multi-row, that is an entry addressed to Corey, not a silent design drift.
- **`docs/roadmap.md`** — one `Also (HO 675)` block, append-only: the apportionment rule as arithmetic, the `identical` predicate and why equality was rejected, the cross-chamber decision and its measured fraction, the query/cache-tag ruling from STEP 0.1 with its cost, and the captures.
- **`docs/oddities.md`** — only if something odd emerged; if nothing, say so in the block.

## STEP 5 — SKILL commit (`docs(skill): HO 675 — …`), self-mod guarded

Its own commit. Minimal edits, every hit classified LIVE-CLAIM vs RECORD first. Expect:

- **`:1975`'s cosponsor clause** — HO 674 deliberately left it saying *stored but UI still count-only*. This HO falsifies the second half; rewrite both halves together or it will read as a partial correction of a partial correction.
- **The schema entry HO 674 deliberately omitted** for `bill_cosponsors` and `bill_related_bills` is now owed. HO 657's rule was that an under-reporting enumeration does not earn a ride-along; **this is the HO that first reads these tables from a surface**, so the entry lands here. That was stated on the record at HO 674 and this HO is the promise coming due.
- A changelog append **only if** client-island membership changed — hover names may require a boundary that does not exist today. If it did, it did; the HO 665 criterion decides.

## HALT — the review ref

`git push origin HEAD:refs/heads/675-review`. Paste: table deltas, `git show --stat`, STEP 2/3 outputs **including captures**, the backlog numstat with every deletion explained (a strike is an edit), and the docs + SKILL diffs.

**Deliver the SKILL diff with `--word-diff=plain`, verify it carries markers before offering it, write it to the gitignored artifacts directory, and tell Corey explicitly to attach it to the chat.** Writing the file is not delivering it.

Remote claims via `git ls-remote`. **The SKILL diff needs explicit approval.** After approval: fast-forward `main`, delete the ref, verify with `git ls-remote --heads origin`.

---

read and follow 675
