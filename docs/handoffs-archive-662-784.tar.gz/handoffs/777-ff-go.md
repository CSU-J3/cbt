# HO 777: FF go. The rehearsal stands, 247 PASS and 0 FAIL. AL-01's reading and a lock line land first, then FF and the deploy

## Rulings on the paste

I read `777-review` at `e04d68d`, both commits:
- the rehearsal script: prod read through a SELECT-only guard (`:129`), copies refused unless `file:` (`:164-176`), nothing imported from the two leg scripts;
- the block, the WATCH (HO 758) line's rewritten procedure, and the Louisiana line. The reconcile reads 264/343 to 265/343 here too, control 0.

**Part A stands:** 247 PASS, 0 FAIL, 1 N/A.
- **The N/A is right.** `/electoral` lists the rated index, and AL-01 has no rating, so there's no row to read R HOLD on. No line.
- **S-ME's STALE needs nothing.** Since HO 760 only a curated `withdrew` row survives (`lib/queries.ts:2073-2076`), so no race has the shape to re-plant.

**Part B stands.**
- **Reading `cron_runs` before anything else after the 60s drop was right,** and the WATCH now says so.
- **The missing lock gets its own line** (below). The WATCH's 10s pause works around it on Nov 4; a lock makes the pause a margin, not the only guard.

**Two calls are Corey's, not this go's:** the decided race's incumbent card, which shows *not on the ballot* where HO 759's tag was (`components/RaceHubBody.tsx:171-178`), and S-AL's RETIRING for Tommy Tuberville, Alabama's Republican nominee for governor. The next HO carries his answers with the Louisiana fix and the lock.

## Before the FF, on `777-review`: one `docs(HO 777)` commit

**AL-01's reading.** It doesn't wait for 02:22Z: Part B's call re-read S-AL at 00:37:13Z, and its Moore row carries `M001212`. HO 774's three reads:
- S-AL-2026's `last_attempt_at` and the `bioguide_id` on Moore's row;
- leg D of `scripts/diagnostic/electoral-cleanup-773.ts`, re-run;
- the tag on `/race/AL-01-2026` on Production.

Expected: `M001212`, 4 of 4, and RUNNING FOR SENATE. Moore's line closes on the tag, so the tie and the tag strike it. All three reads go in the block as read. Anything off is a finding for the next HO, not a HALT, and an off tag leaves the line open.

**A new line, the lock:**
- what: `/api/cron/general-ballot` has no lock. `runGeneralBallot` reads its queue once, at the start (`selectQueue`, `lib/general-ballot.ts:764`, called at `:790`), and nothing in the route, `generalBallotTick` or `wrapCronRoute` checks for a run in flight, so two runs started together read the same races at twice the rate;
- why now: Nov 4's twelve calls run beside the scheduled `20 */2 * * *` ticks, and HO 777's 60s client drop is how a re-send happens;
- *Owner:* Code, medium; dated before Tuesday 2026-11-03, as the Louisiana line is;
- *Close:* a call that finds a `general-ballot` row still `running` in `cron_runs`, started inside the route's 300s ceiling, returns without reading and says so in its payload, and an older open row doesn't block it; proved on a `file:` copy with a planted open row;
- *Reads if never done:* an overlap reads the same pages twice and halves the spacing HO 747 measured Ballotpedia's wall against.

**The block ships true** (method.md, § Doc authority and conventions). Amend HO 777's block for this commit:
- its *Two commits* line becomes three;
- its *Moore's line is unchanged* and *AL-01 carries* bullets become the reading;
- its backlog bullets gain the lock line;
- its reconcile reads the close after this commit, the control at 0.

Build, then the cheap gates, before the push. Push with no force.

## FF

`777-review`'s head will sit on `main` at `e15daca`, a fast-forward of 3 commits. No migration.

Re-run the build and the cheap gates immediately before the push, and name the reading. Then:
- `git push origin <777-review's head>:main`, no force;
- `git ls-remote --heads origin`;
- delete `777-review`, remote and local;
- forward local `main`;
- paste `git rev-parse main`.

If the classifier blocks the push, Corey runs the same command from your checkout.

## The deploy

Run `npm run verify:deploy` **in the foreground**, then read:
- the Production build's cache line;
- the Production `e2e-prod` and its smoke.

No flush: the FF changes no data, and Part B's two calls expired what they wrote (`general-ballot` when #24309 closed, `races` at 00:40:50Z).

Paste once, after `e2e-prod`. The next HO's roadmap block opens with this go as taken.
