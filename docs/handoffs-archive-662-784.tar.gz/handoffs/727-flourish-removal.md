# HO 727 — the `/welcome` flourish is removed, and the CTA grid loses the column that existed only to hold it

Corey's instruction, verbatim: *"lets remove this fromthe landing page"*, against a screenshot of the amber Lenny-face line `(☞ ͡° ͜ʖ ͡°)☞ 𝓖𝓸 𝓯𝓲𝓷𝓭 &apos;𝓮𝓶! ♥♥`. One element, one site: `app/welcome/page.tsx:311-313`.

**This is an un-ruling, not a cleanup, and the handoff says so rather than deleting quietly.** The flourish is drawn in format 1 of `docs/design/welcome-formats-mock.html` (`:369`, `:486`, `:518`), the mock Corey ruled on 2026-08-17 (`docs/roadmap.md:853`, `:871`), and HO 722 established the standing reading for exactly this shape: *a setting selected in a ruled mock resolves the fork inside it* (`docs/method.md` § Roles). The architect is now reversing one such setting, which is his to reverse. The consequence for Code is procedural: **the mock is NOT edited.** It is a ruling record and stays byte-identical; the supersession is recorded in the roadmap, where HO 670's `landing.html` supersession note already sets the precedent.

**The deletion is one span; the layout consequence is a forced one and larger than the span.** `.ctagrid` is `grid-template-columns:auto auto auto` (`landing.module.css:78`) and **column 1 has exactly one occupant at every breakpoint — the flourish**. Base: flourish col 1, stats col 2/4, buttons cols 2/3, microcopy cols 2/3. An emptied `auto` track sizes to 0 but its `column-gap:14px` survives, so the prediction is that the whole CTA block insets right by 14px against the banner's right column. **That is a prediction, not a reading** — STEP 0 measures it (`docs/method.md` § Handoff discipline: a figure the architect cannot measure is written as an estimate and STEP 0 replaces it). If it measures 0, the collapse below is unnecessary and Code says so.

**The `@media (max-width:1460px)` block is predicted to become a no-op, and that is the interesting part.** Its seven rules exist to collapse three columns to two and drop the flourish to its own row (`:265-275`). With the flourish gone, its row/column assignments minus the flourish line are *identical* to a two-column base. If STEP 0 confirms that, the block is dead and deleting it is a forced consequence of the approved change, not a widening — flag it as such if the reading disagrees.

**Four commits, kinds pure:** `fix` (the span + the module) · `docs(skill)` alone behind the self-mod guard (one sentence goes false) · `docs`. No data touched, no query, no route, no client island. Render-touching, so captures are mandatory (§ Gates below).

**The close, as filed:** no `flourish` token anywhere under `app/`, the CTA block's left edge measured unchanged against the pre-state, and `/welcome` clean on the narrow gate at both widths. **What it reads if the work never happened:** `app/welcome/page.tsx:312` still carries the U+1D4D0 run, and `grep -rn flourish app` returns three hits.

## Ground truth (read at `72af9a5`, `main`; re-derive every `:N` by content)

- **`app/welcome/page.tsx:306-313`** — a five-line comment block (the U+1D4D0 / U+0361 fallback rationale, ending *"Decorative — the microcopy under the button carries the meaning — hence aria-hidden rather than a screen reader spelling it out codepoint by codepoint"*) followed by `<span className={styles.flourish} aria-hidden="true">` and the glyph run. **`aria-hidden="true"` is the a11y clearance**: nothing assistive reads it today, so removal is not an accessibility regression and needs no replacement text. The microcopy at `:321-326` is untouched.
- **`app/welcome/landing.module.css`**, the grid and its occupants: `.ctagrid` `:78`; `.stats` `:113` (`grid-row:1;grid-column:2/4`); `.flourish` `:125-127` with a three-line declared-fallback comment at `:121-124`; `.btnPrimary` `:134` (row 2 col 2); `.btnSecondary` `:137` (row 2 col 3); `.micro1` `:141` (row 3 col 2); `.micro2` `:142` (row 3 col 3). **Column 1 appears nowhere but `.flourish`.**
- **Responsive**: `:265-275` the 1460 block (comment + seven rules, `.flourish` at `:269`); `:331-338` the 560 block (`.flourish{grid-column:1}` at `:332`, the rest rows 3–6 in one column). There is no `.flourish` rule in the 1180 or 900 blocks, and none under `prefers-reduced-motion`.
- **`landing.module.css:11-13`** — the header comment naming **four** deliberate off-ladder literals: the 68px headline, the 24px stat numerals, the 16px lead, *and the flourish's 15px*. The count goes to three.
- **`.claude/skills/cbt/SKILL.md:1847`** — the `/welcome` entry's structure sentence: *"banner (68px headline + lead + **one CTA grid whose three columns** give the stats, buttons and microcopy shared edges)"*. Goes false on the collapse. This is the only SKILL clause that names the column count; `grep -n "three columns" .claude/skills/cbt/SKILL.md` at STEP 0 confirms or widens.
- **No test, gate or script references the flourish.** `grep -rn "flourish\|Go find\|𝓖𝓸\|☞" e2e scripts .github docs/method.md` → zero hits at this SHA. `/welcome` is in `e2e/routes.ts:44` and carries its own ODDS assertion at `fit-finish.spec.ts:584-624`, neither of which touches the CTA grid.
- **The design-citation gate is not at risk.** `welcome-formats-mock.html` is cited by `page.tsx:22` and `landing.module.css:3` (file-header citations that survive this change) and by `docs/roadmap.md:871`, `docs/backlog.md:152/180/370/563`, `SKILL:1847`. `ORPHAN` in `scripts/check-design-citations.ts:205` is a class over **allowlist entries**, not over mocks, so an un-cited mock is not a red — and the mock stays cited regardless.
- **Pointer arithmetic**: roadmap pointer 726 (`docs/roadmap.md:2231`), highest HO in commit subjects 726 → **this is 727**. Open loops at the HO 726 close: **260 live / 263 struck**.
- Estimates, not readings: the 14px inset; the 1460 block's redundancy; `npm run build` ~2 minutes.

## STEP 0: enumerate and measure, then HALT

| # | check | expected | if the work never happened, this reads |
|---|---|---|---|
| 1 | `git ls-remote --heads origin`; `git status --porcelain`; pointer and highest HO | `main` alone at `72af9a5`; clean; 726 / 726 → **727** | a second head means an earlier FF is pending and this waits behind it |
| 2 | Quote `page.tsx:306-313`; the seven `.ctagrid` occupant rules; `:265-275`; `:331-338`; the header comment's four-literal sentence; SKILL `:1847`'s structure clause | as in ground truth | a second occupant of column 1, or a `.flourish` rule in a block not named above, widens the change and is named |
| 3 | Bare-substring sweep, whole tree: `grep -rn "flourish" .` and `grep -rn "𝓖𝓸\|☞\|♥" .` excluding `node_modules` | hits only in `app/welcome/{page.tsx,landing.module.css}`, `docs/design/welcome-formats-mock.html`, `docs/handoffs/352-…md:80` (an unrelated prose use of the word) | any hit in `e2e/`, `scripts/`, `.github/` is a dependency this handoff did not know about — **HALT** |
| 4 | `npm run build` · `npm run typecheck` | 0 · 0 | not this HO's to fix |
| 5 | **The pre-state geometry.** Local production server bound by PID; at **2560, 1920, 1440, 1100, 560, 430, 390**, read on `/welcome`: `.ctagrid` bounding rect, its computed `grid-template-columns` (resolved px per track), and the left edge of `.stats`, `.btnPrimary` and `.micro1` | a resolved first track > 0 at 2560/1920 (the flourish's width), 0-or-absent at ≤1460 where it spans | this is the pre-state; every post-fix number is read against it |
| 6 | **The prediction, measured not assumed.** Same seven widths with the span removed in the browser only (`document.querySelector('[class*=flourish]').remove()`, no file edited): re-read the same rects | the CTA block's left edge moves **+14px** at 2560/1920 and **0** at ≤1460 | **a 0 at 2560 means the collapse in STEP 1 is unnecessary** — report the reading and propose dropping it |
| 7 | **The 1460 block's redundancy, measured.** With the span removed in-browser, additionally set `.ctagrid{grid-template-columns:auto auto}` and the six renumbered assignments from STEP 1, then compare every rect at 1460-δ and 1460+δ | the two sides agree on every rect, i.e. the block is a no-op under the new base | a disagreement means the block still does work and is **kept**, with the difference named |

HALT here with the seven rows. The go arrives as a file.

## STEP 1: the removal and the collapse (commit `fix(HO 727)`; two paths)

`app/welcome/page.tsx` — delete `:306-313` entire: the five-line comment and the span. Nothing replaces it; the comment's own words are the warrant (*"the microcopy under the button carries the meaning"*), and the microcopy is unchanged.

`app/welcome/landing.module.css`, conditional on rows 6 and 7:

1. Delete `.flourish` `:125-127` **and** its `:121-124` declared-fallback comment. The comment exists only to explain that rule; leaving it is the dangling-RECORD shape the method warns about.
2. Base grid → two columns, with one line of comment saying **why** it is two and pointing at this HO: `.ctagrid{grid-template-columns:auto auto;…}`; `.stats{grid-row:1;grid-column:1/3;…}`; `.btnPrimary{grid-row:2;grid-column:1;…}`; `.btnSecondary{grid-row:2;grid-column:2}`; `.micro1{grid-row:3;grid-column:1}`; `.micro2{grid-row:3;grid-column:2}`. Everything else in those rules (the stats' `margin-bottom:22px`, the button colours, the microcopy's `margin-top:11px`) is carried unchanged.
3. `@media (max-width:1460px)` — delete the block **and its comment** if row 7 read no-op. The comment (*"the three CTA columns stop fitting beside a 68px headline"*) describes a collapse that no longer has anything to collapse, so it goes with the rules rather than standing as a false explanation. If row 7 disagreed, keep the block minus its `.flourish` line and renumber rows down by one; say which branch was taken.
4. `@media (max-width:560px)` — delete `.flourish{grid-column:1}` at `:332` and renumber: `.stats` row 1, `.btnPrimary` row 2, `.micro1` row 3, `.btnSecondary` row 4, `.micro2` row 5, each keeping its own declarations. The single-column rule, the `margin-top:14px` on the secondary and the `white-space:normal` line are untouched.
5. Header comment `:11-13` — **four** literals becomes **three**, and the flourish clause is removed rather than struck (a CSS header comment is not a ledger; the strike lives in the roadmap).

**Do not touch `docs/design/welcome-formats-mock.html`.** Byte-identical at the close; `git status` proves it.

## STEP 2: SKILL, alone (commit `docs(skill)`; one edit, read against the tree first)

`:1847`, the `/welcome` structure sentence: *one CTA grid whose three columns give the stats, buttons and microcopy shared edges* → *one CTA grid whose **two** columns give the stats, buttons and microcopy shared edges*, plus a short clause recording that **a third column and the amber flourish it held were removed at HO 727 on the architect's instruction, reversing that setting of the ruled format-1 mock**. Read the sentence against the tree before landing it (§ Handoff discipline — HO 695 and HO 696 each proposed a SKILL sentence the repo contradicted). Nothing else in SKILL names the column count; row 2's grep is the proof.

## STEP 3: docs (commit `docs(HO 727)`)

- `docs/roadmap.md` — one `Also (HO 727)` block, pointer 726 → 727: the instruction as given, the un-ruling framed as one (mock ruled 2026-08-17, one setting reversed, the record left intact), rows 5–7's readings as the evidence that the column collapse is forced rather than chosen, which branch of STEP 1 item 3 was taken, and the capture set.
- `docs/backlog.md` — no entry opens or closes here unless STEP 0 turned something up; reconcile open loops at open and close and state both counts (**260 / 263** at open).
- `docs/oddities.md` — only if something surprised: a resolved track width that contradicts the gap prediction, a capture diff outside the CTA block, a `.flourish` reference in a file the row 3 sweep should have caught.

## Gates

Build then typecheck, exit 0, re-run immediately before the paste. **Visual captures are mandatory and non-negotiable on this one** (ways-of-working: HO 670 shipped three render defects that passed every green gate without them) — `/welcome` before and after at **2560, 1440, 430 and 390**, plus a **reduced-motion** pass, with the CTA block's rects quoted alongside each so the captures have numbers under them. The narrow gate at both widths (`NARROW_WIDTHS` default `430,390`) must read clean on `/welcome`; a local green is a prediction of CI's result and is named as one. `npm run check:design-citations` → `OK` from a **fresh clone of the review ref**, not this working tree. Explicit path staging only. No `/api/sync`. No DB write.

## Review ref, then FF

Review branch from the start; push the ref; the SKILL diff delivered as a gitignored file **with an explicit flag to attach it to chat** (they have sat unread when not flagged) and approved alone; `HEAD:main` no force; `git ls-remote --heads origin`; delete the ref; local `main` fast-forwarded and `git rev-parse main` pasted; `npm run verify:deploy` for the tip; the Production `e2e-prod` run read after the FF, since it structurally cannot run on a review ref. Paste-back per `docs/method.md` § Executing a handoff, including the numstat with every deletion explained.

---

read and follow 727
