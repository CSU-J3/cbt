# HO 766: two low lines. The two House select bodies the YAML files under `HS…` land under Congress.gov's `hl…` codes, and every comment that calls a sub-daily cron daily says what `vercel.json` says

Two `docs/backlog.md` OPEN LOOPS lines, both owner Code, low:

- *The members step names four committee codes unknown on every tick: two House select bodies the YAML files under `HS…` that Congress.gov keys `hl…`, whose rosters are never stored, and two Senate subcommittees Congress.gov doesn't list (HO 756)*. `HSZS` → `hlzs00` (the China select committee, 24 members in the YAML) and `HSQJ` → `hlqj00` (the January 6 select subcommittee, 7), both present in `committees` with 0 `committee_members` rows; `SSCM39` and `SSJU27` have empty YAML rosters and are absent upstream, so nothing is lost there.
- *Comments across `app`, `lib` and `scripts` still call sub-daily crons daily, and one ties the weekly report's UTC math to a 09:00 tick (HO 755)*. The line's own census: 20 lines over 10 files at `6302325`, named in it, plus the `lib/fec.ts` sub-class describing a daily run no cron triggers.

Also carried: HO 765's FF-go reading (`docs/handoffs/765-artifacts/carry-to-next-ho.md`, with the 22:15Z PAC re-read once it's in).

## Ground truth (read at `5b03c9d`; re-derive every `:N` by content)

- `lib/committees-sync.ts`: `thomasToSystemCode` lowercases a YAML thomas id and appends `00` for a full committee; the members step collects `unknownCommittees` for codes not in `committees` and reports them in `chronicErr` (HO 756's reading: the same four every tick). The YAML's select bodies carry `HS` prefixes where Congress.gov uses `hl` for House select committees.
- The daily-comment sites are the line's list; STEP 0 re-greps so none is missed and none already fixed is touched. The schedules to state are in `vercel.json`: `/api/sync` `0 */6`, summarize `*/10`, committees `5 */6` (HO 756), primaries `0 0,12`, weekly-report `30 9 * * 1`, `/api/sync-race-ratings` `0 11 * * 3`.
- `lib/summarize-runner.ts:32` ties a 24h defer to a daily cadence that is now `*/10`; whether 24h is still intended is the line's open question, and this HO states the fact without changing the value.
- `lib/fec.ts:65`, `:312` describe a daily `sync:fec` run; `package.json` has the script and `vercel.json` no cron for it.

## STEP 0

1. HO number from the tree: `main` at `5b03c9d`, pointer 765, so 766. Otherwise stop.
2. Re-read every cited `:N` by content. Flag a drift.
3. Measure: the newest committees tick's `unknownCommittees`; `committee_members` rows for `hlzs00` and `hlqj00` (expected 0); the YAML rosters' sizes for `HSZS` and `HSQJ`; whether any other `HS…` code in the YAML maps to an `hl…` code in `committees` (the rule's reach), and whether any `HS…` code collides with an existing `hs…` code if the rule were general.
4. Re-grep the daily-comment census at HEAD and print it beside the line's list.
5. Carry HO 765's reading into this HO's roadmap block.
6. Proceed without a halt.

## The build

1. The members step: a code the YAML keys `HS…` that is absent from `committees` is retried as `hl` + the rest, lower-cased with the `00` suffix; a hit maps, a miss stays unknown. If STEP 0 finds the rule reaches only the two, a two-entry override table with a comment is acceptable instead; say which was built and why. `unknownCommittees` then names only `sscm39` and `ssju27`, and the `chronicErr` line says they are absent upstream rather than unknown.
2. The comments: every site in the line's list and STEP 0's re-grep states the schedule `vercel.json` has, in the same words the headers HO 755 rewrote use; the weekly report's UTC note names `30 9 * * 1`; `summarize-runner.ts:32` states the `*/10` cadence and that the 24h value is a choice, not a cadence match; `lib/fec.ts` says the run is manual. Comments only.

## Legs, on a `file:` copy, each red first

1. The mapping: with the YAML's `HSZS` and `HSQJ` rosters, the members step writes 24 and 7 `committee_members` rows under `hlzs00` and `hlqj00`, and `unknownCommittees` reads the two Senate codes only. Red: 0 rows and four unknowns.
2. The guard: a planted `HSXX` with no `hlxx00` in `committees` stays unknown; an existing `hs…` code is untouched by the rule.
3. The comments: the line's grep (its own daily-phrase pattern) over `app`, `lib` and `scripts` reads 0 lines at the ref, beside a control that plants one and reads 1.

## Commits and docs

- `fix(HO 766)`: the members step.
- `chore(HO 766)`: the comments.
- `diag(HO 766)`: the legs driver.
- `docs(skill)`, its own commit, approval requested: the committees entry's members step (the `HS`/`hl` rule, the two Senate codes named as absent upstream).
- `docs(HO 766)`: strike both lines on the legs; the roadmap block, pointer 765 → 766, carrying HO 765's reading. Reconcile OPEN LOOPS at open and close, control at 0.
- Review ref `766-review`. The FF is held for the SKILL approval and review. No render change; no captures.

## The prod reading (in the FF go)

After the FF: the first committees tick at `:05`, its `chronicErr` naming only the two Senate codes, and `committee_members` rows for `hlzs00` and `hlqj00` (24 and 7).

## Paste back

- STEP 0's readings and the re-grep;
- the three legs;
- the SKILL diff, for approval;
- `git show --stat` per commit, `--numstat` for the docs commits, the reconcile, the `766-review` SHA from `git ls-remote`, and a last cheap-gate run.
