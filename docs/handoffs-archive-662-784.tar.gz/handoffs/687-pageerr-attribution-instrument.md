# HO 687 — evidence at fire time: the #418 attribution instrument

Code kind. The `:50` arc (HO 572 → 574 → 589 → 590 → 591 → 592 → 593 → 656 §D) has ruled out six hypotheses, fixed two real latent bugs that C5 proved were never the prod mechanism, and established that the prod message can **never** identify a component — the minified `#418 … args[]=HTML` string is byte-identical for every structural mismatch anywhere in the app. What it has never had is **evidence captured at the moment of a fire**. `smoke.spec.ts:189-190` records `err.message` and nothing else: across 42+ fires, `err.stack` has never been recorded, the served HTML never retained, the hydrated DOM never snapshotted. This HO builds that capture, validates it on a known positive, arms it on every future crawl, and runs a bounded burst to catch a live one.

**Scope discipline, stated first:** this HO closes on **attribution evidence** — a captured fire with its mismatch located — not on a named cause (which may need analysis of the capture) and never on a fix (a successor HO, once the cause is named). The entry's close criterion is unchanged. No allowlisting, ever; the gate semantics of the crawl are untouched.

## The three evidence channels, in strength order

**C — the differential capture (the build).** A React hydration mismatch means the served HTML and the client render disagreed; the two artifacts that prove *where* are both in the crawler's hands and both discarded today. Retain the main-document response body per navigation (`page.on("response")`, main frame, document type — the *actual served bytes*, not a re-fetch, which on a fresh-per-request route would be a different render). On `pageerror` matching `#418`: dump the retained SSR HTML, `page.content()` (the post-fallback DOM), `err.stack`, route/slug, hit number, attempt number, and timestamp to a per-fire artifact. React's mismatch fallback re-renders the affected subtree client-side, so the SSR↔DOM structural diff localizes the node — **no sourcemaps, no DEV mode, no component names needed**.

**A — the stack channel (free rider).** `err.stack` costs one property read and has never been tried. Minified frames alone may identify nothing, but they're evidence, and they become symbolicable if sourcemaps are ever served. Whether to flip `productionBrowserSourceMaps` (default off today; the repo is public, so served maps leak nothing) is a **HALT decision, not a default** — it changes deploy behavior and bundle serving, and the diff channel doesn't need it.

**B — the DEV naming leg (local, parallel, optional).** `scripts/diagnostic/hydration-clock-harness-590.ts` already proves DEV React names the component in-message via describeDiff. A bounded local DEV soak over the firing set (prod Turso data, `next dev`, N loads per route) is the one path where a fire self-names. Prior targeted retries got 0/37; a full-set soak is a different denominator. Code sizes N; it never rides `e2e-prod.yml`.

## Ground truth at authoring

- Clone at `a504c10`, pointer 686, number `max(686, 686) + 1 = 687`. Re-derive at session open.
- Collector: `e2e/smoke.spec.ts:161` (shape), `:171`, `:189-190` (message-only push), `:236` (mark), `:276-284` (per-route split + the log lines the counting convention depends on), `:290-297` (the report artifact). `e2e/console-noise.ts` is gate-critical and is **not touched**.
- The entry's standing constraints, inherited whole: conclusions under-report (count from per-route `pageErr=` lines, never run conclusions); a cancelled crawl is a **missing sample**, not a zero; every crawl this HO adds is named into the denominator; absence of fires is not evidence of anything.
- Firing set for the catalog and soak: `home`, the six `home-stage-*`, `dashboard-v2`, `bills`, `stale`, `committees-redirect`, `member-detail`, and `/president` (tapeless, stays named — the HO 574 scoping guard).
- Workflow touch: artifact upload for fire dumps means an `e2e-prod.yml` edit. The HO 685 concurrency block is **not touched**; the edit is steps-only, short artifact retention (14d), upload-on-fire only (no artifact on clean runs).

## STEP 0 — enumerate, then HALT

| # | candidate | expected |
|---|---|---|
| 1 | ledger extension | harvest every `e2e-prod` run since 656 §D's last read (2026-08-12) through today from Actions logs: per-run flaky/passed, per-route `pageErr=` lines verbatim, fires/day series extended; cancelled runs counted as missing samples per the HO 685 note. This is the WATCH's denominator brought current before anything new is added |
| 2 | collector capabilities confirmed | the `:189-190` message-only push, no response retention, no stack — cited at HEAD, so the instrument's novelty claim is grounded |
| 3 | noise floor | one clean load per firing-set route: SSR-vs-settled-DOM structural diff size, and a catalog of the legitimate deltas (clock spans, client-only mounts). If the floor is intractable on any route, say so per route — the instrument's readout is only as good as this catalog |
| 4 | stack + sourcemap status | does prod serve `.map` for the main chunks (probe, don't assume); what a raw `err.stack` for a manufactured #418 looks like against the served bundle. The sourcemap flip is proposed or declined **here**, with the reading attached |
| 5 | retention mechanics | where per-fire dumps land locally and in CI (artifact name scheme, size bound per dump, the upload-on-fire-only conditional), and confirmation the report artifact path (`:290-297`) is extended, not forked |
| 6 | burst budget | proposed N dispatches with the arithmetic: HO 683's observed 3/5/0/1 on four crawls says N=4 catches ≥1 fire with good odds; 4 × 74 = 296 documents against `:448`, named. What a zero-fire burst means is written before it runs: **instrument armed on dailies, attribution pending — not absence** |
| 7 | DEV soak sizing | leg B's N per route and wall-clock bound, or a reasoned decline for this HO |
| 8 | SKILL placement | the crawl-contract passage (`:2539-2543` region) gains the capture sentence; self-mod guard, own commit |

**HALT. Rulings owed on: the sourcemap flip (row 4), the burst size (row 6), and the soak go/no-go (row 7).**

## STEP 1 — build (one code commit)

The differential collector per channel C, the stack push, the artifact plumbing, the workflow steps-only edit. `tsc` clean. The known-positive comes next, not in prod: **STEP 2.1 gates STEP 2.2.**

## STEP 2 — validate, then hunt

1. **Known positive, locally, against a prod build:** introduce a deliberate nondeterministic render on a scratch branch's local production build, crawl it with the new collector, and show the fire dump localizing the planted node. The instrument is not trusted until this reads correctly. A known negative (clean route, no dump) alongside it.
2. **The burst:** N dispatches per row 6's ruling, spaced as HO 683's were. Every fire's dump pulled and read; the SSR↔DOM diff quoted per fire with the localized region named. Per-run denominators recorded into the entry's convention.
3. **Zero-fire path, pre-stated:** the instrument ships armed either way; the dailies become the collection surface, and the entry converts to its armed-capture state rather than closing.
4. **Leg B soak** if ruled go: results reported with the same honesty — a DEV fire that names a component is a lead, not a prod attribution, until a prod dump shows the same region.

## STEP 3 — SKILL (own commit, self-mod guard)

Row 8's sentence. Diff delivered gitignored with the attach instruction; `main` holds until approved.

## STEP 4 — docs (one commit)

- **The `:50` entry updated in place, not struck:** the ledger extension (row 1), the instrument's arrival with what it captures, the burst readings with any localized fires, and the honest state line — attributed-evidence-in-hand, or armed-and-waiting. The close criterion sentence stays verbatim.
- **Roadmap** `Also (HO 687)`, pointer → 687. **Oddities:** only if a capture surprises (e.g., the diff names a region no hypothesis covered). The gap-state partial discharge held from HO 686 does **not** ride here — this HO touches e2e, not primaries; it stays held.

## STEP 5 — review ref, FF

Standard route: `refs/heads/687-review`, ls-remote, architect review, SKILL approval slot, FF, ref deleted, `verify:deploy` (the workflow edit deploys nothing but rides the SHA), served SHA pasted. Post-FF, the next daily runs with capture live — its per-route lines and any dump join the trailing paste alongside the HO 685 daily line if that's still pending.

## Paste-back

STEP 0 table at the HALT (rows 1, 3, 4 quoted). After STEP 2: the known-positive dump, per-burst-run lines, any fire dumps with their diffs. SKILL diff attached for approval. After FF: ls-remote, served SHA, first armed daily's reading.
