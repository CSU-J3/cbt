# HO 770: STEP 0 ruling. Inside Elections is blocked, so Sabato's rating-changes page is the first rater wired; IE and Cook wait on their answers

## The ruling

**M1's HALT was the rule working.** Cloudflare answers the honest agent with its block page, not a challenge:
- the House and Senate pages: 403, 5,851 bytes;
- both export files: 403, 5,490 bytes;
- Ray IDs `a4819fc728037b15`, `a481a1d06efde65b`, `a481a1f02f9ee775` and `a481a20fdbca987c`.

The agent stays as it is.
- **IE goes unwired.** Corey writes to IE with the Ray IDs.
- **No Vercel probe.** If pdx1 got through today, that would be Cloudflare's scoring, not IE's permission, and the next tightening would turn it into a weekly `error`.

**M4 found the one rater that publishes its ratings as text:** Sabato's `/crystalball/2026-rating-changes/`.
- It's a set of dated tables of old → new ratings, as of Oct. 8: House 33 tables and 136 rows, Senate 20 tables and 26 rows.
- `robots.txt` bars only search URLs, and the terms are silent.
- The ratings pages publish the ratings as images.

A change log is enough here, because the store already holds a base: Ballotpedia's reading of 09-30. Each race's newest change is Sabato's current rating for it, and a race with no change keeps the row it has.

**Your M4 deviation is accepted.** Terms that exist only as unlinked footer text couldn't have been read before the page.

## What changes in HO 770

Everything not named here stands as written, including § 2 (the guard per rater) and leg D.

### Scope

In: as written.

Out:
- Cook, entirely. Corey requested API access on 10-09, and Cook's page promises a reply within one business day.
- IE's reader. It's unbuilt, because there's no file to build it against.
- Governors, the cadence and every UI file.

### STEP 0, again

- **Claims.** Claims 2-5 held. Check claim 1 once `769-review` exists. Claims 6-8 wait for IE. Keep M1's evidence and block pages where they are.
- **S1, the page.**
  - Read the saved `/crystalball/2026-rating-changes/`, re-fetched once with § 1's agent if the saved copy predates today.
  - Give each table's chamber (House, Senate or Governor), its date and its header row, with the heading and date text they come from.
  - For every House and Senate row, give its id token and its old and new labels.
  - Give the full vocabulary, and list every row that doesn't fit.
  - If Sabato's host blocks § 1's agent, HALT with the status and the body's size.
- **S2, the store against the page.** On prod, by `SELECT`, for each race with a change row, put the stored `sabato` row beside that race's chain of changes. Classify each race as one of:
  - **current:** the stored label is the newest change's new label;
  - **behind:** the stored label equals an earlier value in the chain;
  - **new pair:** there's no stored row and the newest label is competitive;
  - **departure:** the newest label is Safe and a row exists;
  - **conflict:** a row exists and its label appears nowhere in the chain.

  List every race that isn't current.

**Go on without stopping** if all three hold:
- every table is assigned a chamber and a date;
- each chamber has at most 2 unparsed rows, each one listed;
- S2 has at most 3 conflicts per chamber, each one listed.

**HALT** with S1 and S2 otherwise.

### § 1, the reader (replaces *The IE reader*; the rest of § 1 stands)

- **`WIRED`** is `{ house: ["sabato"], senate: ["sabato"] }`. Its comment says why IE and Cook aren't wired (IE's Cloudflare block, Cook's terms) and what each one waits on.
- **The fetch:** the page is `https://centerforpolitics.org/crystalball/2026-rating-changes/`, fetched with § 1's agent, `Accept: text/html` and the 8s cap.
  - It's fetched **once per run** and shared by both chambers. A hang therefore fails both legs inside the cap.
  - Each chamber parses on its own, so a parse failure fails only its own leg.
- **`parseSabatoChanges(html, chamber)`**, exported and pure:
  - **Chamber:** a table belongs to House, Senate or Governor by the heading S1 found. Governor tables are skipped. A table with no chamber throws.
  - **Date:** a table's date comes from the text S1 found with it, in the forms the page uses ("Oct. 8, 2026", say). A table with no date throws.
  - **Columns:** the old and new columns are found by their header text, never by position (HO 742).
  - **House ids:** a row's district token `ST-N` (or `ST-AL`) mints `{ST}-{NN|AL}-2026`.
  - **Senate ids:** a row mints `S-{ST}-2026` from the one state it names.
  - **Unparsed rows:** a row that mints nothing, or mints two ids, is unparsed.
  - **Vocabulary:** Sabato's words map to the normalized labels: *Leans* → `Lean`, *Toss-up* → `Toss Up`, and `Safe D` and `Safe R` locked. Anything else is counted and never written.
  - **Floors:** House 100 rows and Senate 20 (136 and 26 today; a change log only grows), with at most 2 unparsed rows per chamber.
  - **Duplicates:** a race changed twice on one date throws, naming it.
  - **Output:** per race, the newest change by date is the current rating. A competitive rating goes to `ratings`, a Safe one to `locked`. `asOfDate` is that change's date, and `source_url` is the page.
- **The chain check runs in the sync's leg,** because it needs the store.
  - A race whose stored row appears nowhere in its chain is a conflict. It's not written; it's counted in `stats.raters.sabato.conflicts` with its id, and warned.
  - Everything else writes under § 1's predicates as written. A race with no stored row and a competitive newest label is a new pair, inserted.
- **`stats.raters.sabato`** also carries `pageAsOf`, the newest table date.

### Legs (A, B and C replaced; D stands)

**A, the shape,** on the saved page:
- both chambers parse at the floors, and their id sets don't intersect;
- each of these mangles fires its throw:
  - a table's heading removed;
  - a table's date removed;
  - three House rows with their tokens removed (the floor);
  - every label unknown;
  - the same race twice on one date;
- with the old and new headers swapped, the labels follow the headers, and the test asserts the swap;
- one row with its token removed is unparsed, counted and listed;
- the controls as written.

**B, the sync,** as written, plus:
- each S2 class's count matches S2;
- conflicts stay unwritten;
- the `cook` and `inside_elections` fingerprints are the same before and after.

**C, the hang and the split.** The 744 shim now targets the page fetch:
- **c1:** the page hangs. Both legs fail inside the cap, the run records `error`, health reads red, and elapsed is near 8s.
- **c2:** the shim serves the saved page with the Senate tables' heading removed. The House writes land, and the run records `error` naming senate.
- **c3, the control:** the cap removed. It times out near 55s, health reads healthy, and nothing is written.

### Docs (replaces those sections)

**roadmap:** as written, with M1 (Ray IDs), M4, S1 and S2 in the census.

**backlog:**
- **The ratings WATCH:** rewritten, not struck.
  - It says Sabato is wired from its rating-changes page, and that IE's and Cook's rows hold their 09-30 values.
  - *Close:* the first scheduled run after the FF reads `success` with both Sabato legs `ok`.
- **Cook:** as written, plus: *access requested 2026-10-09 through Cook's form; Cook's page promised a reply within one business day.*
- **New line, IE.** Cloudflare blocks the honest agent (a 403 block page on 2026-10-10, the four Ray IDs).
  - *Owner:* Corey, who asks IE to allow the agent. Then Code wires the reader as HO 770 first specified it: the export discovered from the page, and claim 7's vocabulary.
  - *Reads if never done:* IE's chips hold their 09-30 ratings, though IE's file was already dated 10-01.
- No Sabato line; it's wired.
- Reconcile, control 0.

**oddities:** the Wikipedia entry as written, then this one, verbatim:

```text
## Inside Elections publishes its ratings under Export → API, and Cloudflare won't serve them to a fetcher that says what it is (HO 770, Oct 2026)

IE's ratings pages render their tables client-side from a JSON file linked under *Export → API*, and IE's `robots.txt` disallows only `/wp-admin/`. Asked by `CBT-ratings-sync/1.0 (+https://github.com/CSU-J3/cbt)` on 2026-10-10 between 00:49 and 00:51Z, both pages and both files answered 403 with Cloudflare's block page, not a challenge (Ray IDs a4819fc728037b15, a481a1d06efde65b, a481a1f02f9ee775, a481a20fdbca987c). A general-purpose web reader had read the same file hours earlier. A link labeled API is the publisher's invitation; the bot rules in front of it are the host's, and the two can disagree. The fix is asking IE, never changing the agent string.
```

**README:** the NEW text becomes:

```text
- **Race ratings** — [Sabato's Crystal Ball](https://centerforpolitics.org/crystalball/), read from its
  published rating changes. Cook Political Report and Inside Elections ratings are as
  [Ballotpedia](https://ballotpedia.org) last carried them, on 2026-09-30.
- **Candidates** — [Ballotpedia](https://ballotpedia.org).
```

**SKILL:** edits 1-3 are replaced, verbatim below. Edit 4 stands as written. The OLD strings are unchanged.

Edit 1, NEW:

```text
NEW: - **Ballotpedia** scraping — primaries (HO 91-96, 120), race ratings from HO 71 until HO 770 (see Sabato's Crystal Ball, below), and since HO 749 **the general-election box**.
```

Edit 2, NEW:

```text
NEW: - **Sabato's Crystal Ball** (`https://centerforpolitics.org/crystalball/2026-rating-changes/`; public, no auth; `robots.txt` bars only search URLs; the footer names terms but links none) — Sabato's race ratings since HO 770, both chambers, read in `lib/race-ratings-scrape.ts`. The ratings pages (`/crystalball/2026-house/`, `/2026-senate/`) publish the ratings as map images; this page is where they exist as text: dated tables of changes, old → new, for the House, the Senate and governors (governors are skipped). A change log is enough because the store already holds a base, Ballotpedia's reading of 2026-09-30: each race's newest change is its current rating, and a race with no change keeps its row.
- **Race-ratings sources weighed and not used (HO 769-770).** Ballotpedia's widget now answers only a POST carrying a signed per-page token (`wgBPWDeferToken`), and replaying it is ruled out. Ballotpedia's data API (`api4.ballotpedia.org`, keyed) carries no ratings. Wikipedia's ratings tables lag the raters: on 2026-10-09 the House table's Cook, IE and Sabato columns were dated Aug. 25, 20 and 26, and 19 of 28 sampled Cook cells differed from Cook's own page. Inside Elections publishes a JSON export under its ratings pages' *Export → API* (`…/wp-content/themes/inside-elections/cache/ratings_latest_{house|senate}_year=2026_district=all_clean.json?v=<stamp>`), but Cloudflare answers a non-browser agent with its block page (403, 2026-10-10), so IE's reader waits on IE. Anyone can read Cook's site, but its Terms & Conditions bar "any robot, spider, or other automatic device, process, or means to access the Website for any purpose", so no code fetches it. Cook's API (`/api/race/{house|senate}`, HTTP Basic with an account, at most one call a day) is by request; access was asked for on 2026-10-09.
- **House Clerk + Senate eFD** (planned)
```

Edit 3, NEW:

```text
NEW: - `/api/sync-race-ratings` — 11:00 UTC **Wednesdays only** (`0 11 * * 3`) — House **and Senate** race ratings, **one reader per rater since HO 770**. `WIRED` (`lib/race-ratings-scrape.ts`) names the raters each chamber reads. Today that is Sabato's Crystal Ball alone, from its rating-changes page (see External data sources). Cook's and Inside Elections' rows stand as Ballotpedia last wrote them on 2026-09-30: no upserts, no departures, and their `rating_date` shows their age. The page is fetched once per run and parsed per chamber, so a hang fails both legs inside the 8s cap while a parse failure fails only its own. Each race's newest change is its current rating, and a race with no change keeps its row. A stored row whose label appears nowhere in its race's chain of changes is a conflict: it is counted in `stats.raters.sabato.conflicts` and not written. A leg writes every rater that read, each row citing its own rater's page as `source_url` and its own change's date as `rating_date`. It then fails if any wired rater didn't read, so the run still records `error`. The payload carries `stats.raters.<source>` for each rater that read, and the MOVED guard reads it (see the MOVED entry). The floors are House 100 rows and Senate 20, with at most 2 unparsed rows per chamber, because a change log only grows. A race changed twice on one date throws. The user agent is `CBT-ratings-sync/1.0 (+https://github.com/CSU-J3/cbt)`, not a browser's. **Everything below is the Ballotpedia era, HO 742-769. It stays because what it learned carries over unchanged: throws that carry their census, absolute floors per chamber, a chamber passed and never inferred, departures on evidence and never on absence, legs that can't discard each other's writes, and the 8s cap.** **THE TRANSPORT WAS A WIDGET, NOT THE WIKI PAGE.**
```

### Paste-back and the FF go

These stand as written, with S1 and S2 in place of M1-M3. The FF go's POST is the deployed path's first read of Sabato's page. Its moves read not fresh, since Sabato's last read before it is #21278 on 09-30.
