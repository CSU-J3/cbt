# HO 723 — STEP 0 ruling (architect, 2026-09-14). Eight rows accepted, all seven corrections taken, one more of mine added that would have read the first six runs of the window as gaps. Go.

Good STEP 0. Row 4 found the FF instant the handoff could only bracket, row 5 read five post-FF dailies with no gap, row 6 proved the control live before any zero was believed, and row 7 read the instrument's first ZERO by hand so STEP 1 has a number to reproduce. Every correction below is accepted; two are corrections to my ground truth and one to my design, and the block owns all three. Nothing here is a fork for Corey.

## 1. Row 4, the FF instant: `--since 2026-09-09T23:40:51Z`

`34417992312`, the Production `deployment_status` run on `29026da` at 2026-09-09T23:40:51Z, is the deploy of the 706 tip and therefore the FF instant for every reading here; `--since` takes it exactly, so that run is the first sample. The commit-time reading is corrected: 21:14:15Z was the author date, 22:05:09Z the committer date, and the Preview at 22:05:48Z was the review-ref push. Daily #1 stays 2026-09-10's (`34512726049`, 18:10Z); the seventh is 2026-09-16's.

## 2. Correction 1 accepted: `[a-z0-9_-]+`, and the self-test proves the class against the list

`home-stage-other_chamber` is a route the handoff's own pattern could not see, and every complete run would have read 36/37 and PARTIAL: five gaps manufactured by a character class. Both patterns become `[a-z0-9_-]+`. The self-test gains two assertions, in this order: every `ROUTES` slug matches the slug pattern in full (`^…$`), so a future slug cannot bring this back silently; and a verbatim `[home-stage-other_chamber] hit1=…` line copied from the 09-14 daily's log parses as one route line. Content first, class second.

## 3. Mine: the completeness floor is the run's own list, never HEAD's

`ROUTES` went **36 → 37 inside the window**: `6471b02` (`test(HO 710): electoral-2028 in the crawl list`, 2026-09-10 23:04Z). So the 09-10 daily at 18:10Z, and every Production run from `34417992312` through HO 709's FF, crawled **36 routes and printed 73 readings**. Under the handoff's HEAD floor of 37 / 75 each of them reads PARTIAL, and the week's first daily is a gap that never happened. The 722 block's 75 was true of one run, and I wrote it as the floor.

Ruled: the floor is read per run from the run's own bytes. `git show <headSha>:e2e/routes.ts` written to `scripts/diagnostic/scratch/routes-<sha7>.ts` (repo-ignored, no imports in that file) and dynamic-imported, `ROUTES.length` cached per SHA; the expected readings column is `2 × floor + 1`. If the blob cannot be read the verdict is **`NO-FLOOR`**, never a guessed number. The self-test asserts that this path at HEAD equals the direct `ROUTES.length` import (37), so the two ways of reading the list cannot disagree without the run saying so. The table gains a `floor` column and prints `headSha` beside it; STEP 2 spot-checks that the 09-10 daily's `headSha` predates `6471b02` and that its row reads **36 / 36, 73 readings, ZERO**.

## 4. Correction 3 accepted, with the separator named

The detail field is captured from `pageErr#N=[` up to the next `  |  ` (two spaces, pipe, two spaces: `msgs.join("  |  ")` at `smoke.spec.ts:799`) or end of line, the trailing `]` stripped, the messages split on ` ¦ `, and each message classified against `PAGEERR_MARK` on its own. Cross-check per hit: the message count equals that hit's `pageErr=N` on the route line; a disagreement prints `COUNT-MISMATCH` on the row and is a finding. The `[stage-click]` line is exempt (no detail to count).

## 5. Correction 4 accepted: three counts, and which one is HO 687's

Per run: **fire-lines** (route lines whose detail carries at least one `#418` message: HO 687's unit, kept so the new ledger reads against the old one), **fire-hits** (per-hit matches, your `-o` count), **fire-messages** (messages matching, summed). The table's headline column is fire-hits; the other two print beside it. The control reads **2 / 2 / 2**. The week's criterion is all three at zero, which is one reading, since none can be nonzero alone.

## 6. Correction 5: the misnomer is HO 706's, and it resolves by citation

You are right that `mut kept=7(insert:6,text:1)` on a quiet hit means "mutation channel at zero" can never be read literally. The phrase was mine, in the HO 706 block and `:96`, and what it reached for is the one thing on the `mut` line that *is* absent on a quiet hit: `fire-t`. `smoke.spec.ts:213` sets `__mut.fireT` only on a message matching `/418/`, and `:343-345` prints `fire-t=` on the `mut` line only when it was set. So `:96`'s clause reads **no `fire-t=` on any `mut` line**, which is the same event as a `#418` `pageErr`, seen from inside the page instead of from Playwright's listener. Two consequences. The instrument counts `fire-t=` occurrences on route lines as a third print of the event and cross-checks it against fire-hits (`MUT-MISMATCH` on disagreement, a finding, not fatal: an error thrown before the init script installs would show here). And the `:96` annotation says in one sentence that *mutation channel at zero* reads as *no `fire-t=` on any `mut` line*, citing `:213`, so the phrase is superseded where it stands and `:96`'s close and `:60`'s are one reading. Not rewritten; annotated, the line's own convention.

## 7. Estimates replaced, and one of them changes the close read's timing

- Logs are **79–111 KB**, not 1–3 MB.
- Delivery lag over the five post-FF dailies is **2h41m–4h44m** (18:10Z · 18:12Z · 17:41Z · 17:57Z · 19:44Z against the 15:00Z slot), and 3h20m on 09-09. `backlog:59`'s ~85 min was two July samples. The 09-16 daily may therefore deliver near 20:00Z, and the close read stays *on or after 2026-09-17*. `:59` is struck history and is not touched; the reading goes in the block and in one oddity, because a number this handoff cited as ground truth was stale by a factor of three and the close read's date rests on it.

## 8. Flag 7, and the shared-tree read

The handoff landed in `docs/design/`, a tracked directory with its own naming rule, instead of the ignored `docs/handoffs/`. It is untracked, so it is `mv` (never `git mv`) to `docs/handoffs/`; this ruling lives there too; STEP 1's first porcelain reads clean and the paste names the move. Reading STEP 0 off the shared tree at the SHA `ls-remote` names is accepted; the review branch from the start is the rule that matters, and it is yours.

## 9. Rows 6 and 8, one date to carry

`33794231177` is the control, 2 fires with `pageerr-dumps` present; its artifact expires **2026-09-17T19:07:32Z**, so at the close read the artifact half of the control is likely gone and the log half carries it, which the 09-17 re-run states rather than discovers. The 09-03 daily `33790157186` (8 fire-lines, HO 687) is the second control candidate; run it as a second `--control` row if the cost is a minute, and print both.

## Amendments to the handoff, collected

- `--since 2026-09-09T23:40:51Z` (§ 1); `--control 33794231177`, optionally also `33790157186` (§ 9).
- Slug pattern `[a-z0-9_-]+` in both regexes; two self-test assertions (§ 2).
- Per-run floor from `git show <headSha>:e2e/routes.ts`, `NO-FLOOR` verdict, the HEAD-equality self-test, `floor` and `headSha` columns, readings expected `2 × floor + 1`; the 09-10 daily spot-checked at 36 / 36 / 73 (§ 3).
- Detail capture to the `  |  ` separator, split on ` ¦ `, per-message classification, `COUNT-MISMATCH` (§ 4).
- Three fire counts, fire-hits headline, control 2 / 2 / 2 (§ 5).
- `fire-t=` counted and cross-checked (`MUT-MISMATCH`); the `:96` annotation's one sentence (§ 6).
- Estimates replaced; the lag reading in the block and one oddity (§ 7).
- The handoff file moved to `docs/handoffs/` by `mv` (§ 8).
- Everything else in the handoff stands as written, including the verdict vocabulary, the exit codes, the `schedule`-only tally, and the three-outcome close read dated 2026-09-17.

Go: self-test, then the control, then the harvest.
