# HO 725 — the layout audit's burn ledger counts every server load it makes: the constant `+ 2` goes, `openMeasured` and the narrow ladder count their own gotos, and a `--route` run reads `12 = legs 10 + crawl 2`

The line this HO closes is `docs/backlog.md:16` (OPEN LOOPS, found HO 721, owner Code, low), its close verbatim: *"the ledger counts the legs' `openMeasured` hits rather than a constant, read back as `2 + 10 = 12` on a `--route` run."* Its *reads if never done* is `page loads (actual): 4` on a `--route` run.

**One commit, `chore(HO 725)`** (the file is a diagnostic instrument; HO 700/702/704 landed theirs as `chore`), plus `docs`. Read-only on the DB, as the audit always is: it reads prod Turso through a local production build (`:32-35`, the audit's own target rule). No product code, no CSS, no SKILL by default.

**The close, as filed:** `--route vote` prints a ledger whose total is the sum of its named parts, `12 = legs 10 (A 4 · B 6) + crawl 2 + narrow 0`, against the pre-state's `4`. **What it reads if the work never happened:** `page loads (actual): 4   (incl. the 2-hit falsification leg)` on that same run, a label that was already short by 6 before HO 721 added the leg it was short by 8 after.

## The design, so STEP 0 can check it against the tree

Three server-load sites and one that is not. `openMeasured` at `:1475-1494` runs `hits` gotos against `BASE_URL` (`:1482`); it is called by leg A (`:1536`, two routes × 2), leg B (`:1597`, `:1628`, `:1663`, three anchors × 2) and the crawl (`:1742`, 2 per route). The narrow ladder has its own goto at `:1845` (one per route × width). `openFixture` (`:1507-1510`) loads `layout-legc.html` over `file://` and touches no server, so it is not a page load in the ledger's sense and stays uncounted, said in a comment. Today `pageLoads` is declared at `:1738`, after the legs have run, and incremented by the crawl (`+= 2` on success, `+= 1` on a throw, a guess) and the ladder (`+= 1`); the ledger adds `2` for a falsification leg HO 606 had and HO 615, 719 and 721 outgrew.

Ruled:

1. The goto counts itself. A counter object declared before `openMeasured` (`legs`, `crawl`, `narrow`, one integer each, plus a `phase` the caller sets) is incremented **before** each `page.goto` at `:1482` and `:1845`, so a goto that times out still counts as the request it made. The crawl's `pageLoads += 2` / `+= 1` and the ladder's `+= 1` go; the throw branch stops guessing.
2. The ledger prints the sum and its parts, `page loads (actual): 12 = legs 10 (A 4 · B 6) + crawl 2 + narrow 0`, and beside the legs figure its **defined** count, `LEG_A.length × 2 + 3 × 2`, from the leg definitions rather than the gotos: `legs 10 (counted) / 10 (defined)`. The two derive from different things (runtime events, static definitions), so a disagreement is a leg that loaded more or fewer pages than its definition says, and the line prints `LEG-COUNT-MISMATCH` when they differ. It is a cross-check, not a tautology, and it says which half it buys.
3. The planned line takes the actual line's shape: `:1446` gains the legs term first, `page loads planned: 10 (falsification legs) + N (wide, 2 hits each) + narrow = total`, so planned and actual are read against each other.
4. The header comment's measurement list (`:7-12`) and the `BURN LEDGER` comment name the change in the HO 617/619 form: what is counted, what is not (the fixture), and why the constant was wrong.

## Ground truth (read at `1a08921`; re-derive every `:N` by content)

- `scripts/diagnostic/layout-audit-606.ts` (2,0xx lines): `:248-262` `LEG_A`, **2** entries (`/trades`, `/lobbying`); `:1430` `startedAt`; `:1446-1447` the planned line; `:1475-1494` `openMeasured`; `:1482` its goto; `:1507-1510` `openFixture` over `FIXTURE_URL` (`:155-157`, `pathToFileURL`); `:1536` leg A's call; `:1597`, `:1628`, `:1663` leg B's three calls, `hits` 2 each; `:1738` `let pageLoads = 0`; `:1742-1743` the crawl's call and `+= 2`; `:1756` the throw branch's `+= 1`; `:1845-1849` the ladder's goto and `+= 1`; `:1892` `elapsedS`; `:1995-1999` the `BURN LEDGER` block, `:1998` the line that closes this HO.
- `docs/backlog.md:16` the filed line; the HO 721 block (`docs/roadmap.md:1993`) records the 4-for-12 reading at `c18a3b4`.
- Legs A/B/C read **22 of 22** and leg B green on three anchors at HO 722's STEP 0 (`FALSIFICATION: PASS`); nothing since touched the audit.
- Estimates, not readings: a `--route vote` run is **~14 loads and ~2 minutes** (10 legs, 2 crawl, 0 narrow, plus the fixture); the full crawl's planned total after the change is **10 + 54 + 18 = 82** (27 routes × 2, six subset routes × three widths; STEP 0 reads `ROUTES.length` and `SUBSET_SLUGS.size` rather than trusting this).

## STEP 0: enumerate and measure, then HALT

| # | check | expected | if the work never happened, this reads |
|---|---|---|---|
| 1 | `git ls-remote --heads origin`; `git status --porcelain`; pointer and highest HO; machine | `main` at `1a08921` alone; clean; 724 / 724 → **725** | anything else stops here |
| 2 | quote `:1446-1447`, `:1475-1494`, `:1507-1510`, `:1738`, `:1742-1743`, `:1756`, `:1845-1849`, `:1995-1999`; `LEG_A.length`; `ROUTES.length`; `SUBSET_SLUGS.size`; `NARROW_WIDTHS.length` | as in ground truth; 2 · 27 · 6 · 3 | a fourth `page.goto` site is a fourth counting site, flagged |
| 3 | `npm run build` · `npm run typecheck` | 0 · 0 | not this HO's to fix |
| 4 | **the pre-state:** `--route vote` against a local production build bound by PID, full output kept; legs A/B/C green; the `BURN LEDGER` block quoted | `FALSIFICATION: PASS`, leg C 22 of 22; `page loads (actual): 4   (incl. the 2-hit falsification leg)` | the number this HO changes; a red leg means no reads (`:39-48`) |
| 5 | count the gotos the same run actually made, independently of the script: Playwright's `request` events on the context for the top document, or the local server's access log if one is kept | **12** server loads (`/trades` ×2, `/lobbying` ×2, `/` ×2, `/electoral?cycle=2028` ×2, `/vote/…` ×2, `/vote/…` ×2 for the crawl) and one `file://` | this is the reading the new ledger must equal; if the independent count is not 12 the design's arithmetic is wrong, not the ledger's |

HALT here with the five rows. The go arrives as a file.

## STEP 1: the change (commit `chore(HO 725)`; one path)

The four ruled points above. Then, from a local production build of this commit:

- `--route vote`: legs green, `page loads (actual): 12 = legs 10 (A 4 · B 6) + crawl 2 + narrow 0`, `legs 10 (counted) / 10 (defined)`, no mismatch; the planned line reads `10 (falsification legs) + 2 (wide, 2 hits each) + 0 (narrow subset) = 12`. Row 5's independent count beside it.
- A control that can disagree: run once with `LEG_A` temporarily filtered to one entry in a scratch copy, or with one leg-B anchor's `hits` set to 1 in that copy, and read `LEG-COUNT-MISMATCH` fire with both numbers printed; then discard the copy. The paste carries the line. A cross-check that has never disagreed is not yet known to be able to.
- `--route home` (bridge control): M1a · M1b · M1x · M1c · M2 identical to HO 722's (iv‴) reading for `/` (`M1b 1 · M1c 0`); the ledger reads `12 = legs 10 + crawl 2 + narrow 0` too, since `--route` skips the ladder.
- The full crawl is **not** run here: its ledger reads on the next terminal crawl, and the block says so.

`scripts/**` is in the root `tsc` program, so `npm run typecheck` reads it.

## STEP 2: docs (commit `docs(HO 725)`; `docs/backlog.md`, `docs/roadmap.md`)

- `:16` strikes with its close note: the pre-state `4`, the reading `12 = legs 10 (A 4 · B 6) + crawl 2 + narrow 0`, row 5's independent count, the mismatch control's line, and that the full crawl's ledger is unread until the next terminal crawl.
- The roadmap gains one `Also (HO 725)` block, pointer 724 → 725. The `HO 723`-era rule applies: findings caught in relay are filed; if row 2 finds a fourth goto site or row 5 disagrees with 12, the block names it.
- No oddities unless something surprised. No SKILL: SKILL does not describe the ledger's line (`grep -n "page loads" .claude/skills/cbt/SKILL.md` reads 0 at `1a08921`; STEP 0 re-reads it).

## Gates

Build then typecheck, exit 0, re-run before the paste. Legs green at both reads. The pre-state `4` and the post-state `12` on the same route, with row 5's independent count. The mismatch control printed. Bind evidence for the local server (`next start -p 3000`, PID). `git diff --numstat` on `docs/backlog.md` with the one deletion explained. Remote claims via `git ls-remote`.

## Review ref, then FF

Review branch from the start; push the ref; `HEAD:main` no force; `git ls-remote --heads origin`; delete the ref; local `main` fast-forwarded and `git rev-parse main` pasted; `npm run verify:deploy` for the tip. A chore-plus-docs FF still deploys, so the Production `e2e-prod` run that follows is a `deployment_status` sample for the 09-17 ledger re-run, named as such. Paste-back per method § Executing a handoff.
