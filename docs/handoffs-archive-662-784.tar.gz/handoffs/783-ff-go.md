# HO 783: FF go. The general runoff stands, 22 PASS and 0 FAIL. The migration is already on prod, so it's the FF, the deploy, and the first tick read

## Rulings on the paste

I read `783-review` at `372c433`, all five commits:
- `a2c97d5`: `general_runoff` in `scripts/migrate.ts`, read back on prod with 11 columns and 0 rows before the push. `general-runoff` is a box kind of its own, `runoffResult` stores exactly one box per race in the same batch as the general box, whatever its status, and two store nothing and are named in the payload;
- `a86a287`: `resultFromRows` takes the runoff rows. One marked printed row decides on `runoffOn`, which is the box's printed date, else Louisiana's jungle date, else Georgia's 28 days. No mark keeps the runoff. `getRaceRoster`, `getElectionResults` and the qualifier's outcome take the same rule;
- `aaf4393`: the legs, leg 0 on S-GA's own 2022 runoff box;
- `914a226`: the general-runoff line struck, the `seed:ratings` line filed, and the WATCH's Georgia read. The reconcile reads 265/352 here too, control 0.

**SKILL is approved** (`372c433`): ten places, each true of the tree.

**Your notes:**
- **1, `incumbent_marked` and `box_date`:** right. The incumbent rule needs the first, and STEP 0 found the second.
- **2, the optional runoff in a write:** right.
- **4, the untested LOST path:** it's the elected branch's `else`, and the race page's *defeated* was read on Ossoff. It stands.
- **5, no flush:** agreed.

**Claim 5's two other readers of the mark reach no page.** `classifyTarget` keeps a printed target `active` past election day whatever the marks (`lib/pac-target-status.ts`), and the string the marks feed is discarded. `electoral-general.ts:182` selects `marked` unused.

**One edge, accepted:** a *Special general runoff election* box inside a 2026 section would also read as the race's runoff. STEP 0 found no runoff box in any 2026 section, and the specials' boxes all sit outside it.

**`narrow-preview`'s baseline is now #38492077977.** The `ids` field drifts with the week's enacted bills, which is data, not code.

## FF

`783-review`'s head sits on `main` at `4d73ca7`: a fast-forward of 5 commits. The migration is already on prod.

Re-run the build and the cheap gates immediately before the push, and name the reading. Then:
- `git push origin <783-review's head>:main`, no force;
- `git ls-remote --heads origin`;
- delete `783-review`, remote and local;
- forward local `main`;
- paste `git rev-parse main`.

If the classifier blocks the push, Corey runs the same command from your checkout.

## The deploy

Run `npm run verify:deploy` **in the foreground**, then read the Production build's cache line.

**`e2e-prod`:** read the run Vercel's Production record fires, or dispatch on `main` if none has started a few minutes after READY. Give the record's time against READY.

**No flush,** per your note 5.

**The first tick on prod:** the first `20 */2` general-ballot tick after the deploy, if it closes before you paste. Expected: `success`, reading, `runoffBoxes=0` and `runoffAmbiguous=0`, and `general_runoff` still holding 0 rows. If it hasn't closed, the next HO's STEP 0 reads it.

Paste once, after `e2e-prod`. The next HO's roadmap block opens with this go as taken.
