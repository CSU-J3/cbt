# HO 780: Louisiana's runoff box. Once Ballotpedia posts a seat's Dec 12 contest as a General election box, its candidates publish as Advanced and the page keeps Runoff Dec 12 until that box carries a mark. With HO 779's FF readings

**Corey chose this HO next** (2026-10-12, from four: *"Louisiana runoff pages (Recommended)"*).

**The line** is the backlog's *"Once Ballotpedia posts Louisiana's Dec-12 runoff as a General election box…"* (HO 758's review). This HO builds it and closes it on the legs.

**Why now.** Under Act 7 of 2026, a Louisiana House seat's Nov 3 contest is an open primary: a majority elects, otherwise the top two meet in a Dec 12 open general. Ballotpedia prints the Nov 3 contest as a *Nonpartisan primary* box, so the Dec 12 contest should arrive as a *General election* box, days after Nov 3. Today's code would then flip that seat to `box`: its D and R rows publish as `won_primary`, the others as `on_ballot`, and the page drops *Runoff Dec 12* for *Not yet called*. That premise is inferred, not measured: no such box exists yet.

**Scope, in:**
1. **§ 1,** the roster: a jungle seat with a `box` read is planned as the top-two states are planned.
2. **§ 2,** the result: a jungle seat's box decides only once it carries a mark, and a runoff it decides reads its own date.
3. **HO 779's FF go,** into this block, and the Vercel line struck with its two times.
4. **The docs:** the line struck on the legs, two new lines, and the WATCH's reads.

**Out:**
- a *General runoff election* box, which the reader reads as `runoff` and so stores nowhere. That's Georgia's label for its general runoff, and Louisiana's if Ballotpedia labels Dec 12 that way. This HO files it as a line, without building it;
- every other OPEN LOOPS line;
- any prod write.

**How STEP 0 runs** (method.md, HO 768's rule): the claims are mine and are a check. The measurements are yours.

**Base:** `main` at `bae5790`, HO 779's FF head. HO number: the pointer is 779 and the highest HO in commit subjects is 779, so this is 780.

## STEP 0

| # | Claim | Fails if |
|---|---|---|
| 1 | `main` is `bae5790`, its Production smoke passed (#38333516212), and after the `races` flush Production read 8 PASS and 0 FAIL. | any |
| 2 | `planBallotRoster` publishes `advanced` only in a top-two or top-four state (`lib/harvest-challengers.ts:356`, `:370`). Elsewhere a D or R row is `won_primary` when `primary_marked`, else `nominee`, and every other printed row is `on_ballot` (`:376` on). | |
| 3 | The jungle rule leaves out every race with a `box` read (`JUNGLE_FROM_WHERE`, `:223-232`). | |
| 4 | The reader's general box is one whose `<h5>` says *general election* and neither *primary* nor *runoff* (`lib/general-ballot.ts:163`). A *Nonpartisan primary* box is `primary-kept`, contest `open` (`:166-174`), and a *runoff* label is `runoff` (`:175`). `primary_marked` is a kept primary's winner mark (`:567`, `:598`). | |
| 5 | `resultFromRows` reads the box first whenever the read is `box` (`lib/race-result.ts:88-117`), and the jungle only otherwise (`:118` on). `raceResultView`'s decided header names election day (`:170`), and its runoff label names the jungle row's `runoff_date` (`:169`). `/electoral`'s `readRaceResults` hands the rated seats to the same function, jungle rows included (`lib/electoral-general.ts:624-680`). | |

**Measure:**
- LA's six: their read status, their jungle rows' winners today, and which are rated;
- in HO 747's saved LA pages, the `<h5>` labels of every box, past cycles' included, as the record of how Ballotpedia names Louisiana's contests.

## § 1: the roster (`feat`)

A race with a `jungle` primary of the cycle (`JUNGLE_FROM_WHERE`'s join) and a `box` read is planned as the top-two states are: every printed row that isn't a write-in, less the incumbent's, publishes as `advanced`. The Dec 12 box holds the two advancers, whatever their parties. Every other race plans as today.

## § 2: the result (`feat`)

A jungle seat with a `box` read:
- **while its box carries no mark,** reads its jungle box as it does today with no box: two winners are *Runoff Dec 12*, one is *Decided · Nov 3, 2026*, none is *Not yet called*. The incumbent's qualifier follows the same reading;
- **once its box carries a mark,** reads the box. Where the jungle marked two, the decided header names the runoff date, *Decided · Dec 12, 2026*.

Every other race reads as today. One function serves the race page and `/electoral`, so both follow.

## The legs (`diag`)

Seed a fresh copy of prod by `SELECT` the way HO 779's legs did. On it, plant the jungle marks and a Dec 12 box by rows (`general_ballot_reads` `box`, and `general_ballot` rows with `primary_marked` 1), then run each build's harvest and server per copy with `CBT_CLOCK_NOW`.

**Leg 0, the reader:** splice a *General election* box, copied from another saved page's general box and carrying the two advancers, into LA-01's saved page, with its jungle box's two rows marked. Run `pageResult` on it: status `box`, two rows, both `primary_marked` 1.

**Leg 1, a runoff, the box unmarked** (the clock at Nov 5):
- HEAD red: *Won primary* on the D and R rows, *Not yet called*;
- the tree green: both *Advanced*, *Runoff Dec 12*;
- the harvest's `race_candidates` equal to HEAD's outside the planted seat, by a whole-table diff.

**Leg 2, the runoff decided** (one box row marked, the clock at Dec 13):
- HEAD red: *Decided · Nov 3, 2026*;
- the tree green: *Decided · Dec 12, 2026*, with *Elected* on the marked row.

**Leg 3, an outright winner with an unmarked box** (one jungle winner; the box prints them):
- HEAD red: *Not yet called*;
- the tree green: *Decided · Nov 3, 2026*.

**Leg 4, the control:** every other race page's `<main>` byte-identical to HEAD's at the Nov 5 clock. If a planted seat is rated, its `/electoral` row reads RUNOFF on the tree in leg 1.

**Captures,** retained: the planted pages in legs 1 to 3, at 1440 and 430, and a reduced-motion pass at 1440.

## Docs

**roadmap:** the HO 780 block. It opens with **HO 779's FF go as taken** (your paste), then STEP 0, § 1, § 2 and the legs.

**backlog:**
- **The Louisiana-box line:** struck on the legs, its premise named as inferred.
- **The Vercel line:** struck with HO 779's FF go reading. Both records came at most 1s after READY: the Preview's at 21:41:00Z (READY 21:40:59.955Z) and Production's at 01:43:50Z (READY 01:43:49.957Z).
- **A new line, the general runoff:**
  - what: a *General runoff election* box is the reader's `runoff` kind (`lib/general-ballot.ts:175`), and the scraper drops it too (`lib/primary-candidates-scrape.ts:379-384`), so a general runoff's result is read nowhere. The race's general box keeps its two marks and reads *Runoff* past the runoff's date. Georgia's is Dec 1, and Louisiana's Dec 12 joins it if Ballotpedia labels it so;
  - read in code, not measured;
  - *Owner:* Code, medium, dated before Tuesday 2026-12-01;
  - *Close:* a runoff box's mark reaches the race page, proved on a `file:` copy with a planted box;
  - *Reads if never done:* a seat decided in a general runoff reads *Runoff* until the cycle ends.
- **A new line, the flush:**
  - what: whether Vercel's data cache serves a cached read's old value across a deploy is unread. HO 779's FF go flushed `races` before reading anything, so the flush's premise went unchecked;
  - *Owner:* Code, low;
  - *Close:* the next FF go that changes a cached read's shape reads one page between READY and its flush, and names what it served.
- **The WATCH (HO 758) line:** its reads gain the first Louisiana seat whose read turns `box` after Nov 3. Its page should read *Runoff Dec 12* with two *Advanced*.
- Reconcile, with the control at 0.

## SKILL (`docs(skill)`, alone and last)

Rewrite to the tree every SKILL sentence the build makes false, and name each in the paste. I expect three:
- HO 750's roster rule, where `advanced` is the top-two and top-four states' alone;
- HO 758's jungle rule, which said a box race leaves it;
- `:1974`, *Decided · Nov 3, 2026* for every decided race.

## Commits

On `780-review` from `main`, kinds unmixed:
- `feat`, § 1;
- `feat`, § 2;
- `diag`, the legs;
- `docs`;
- `docs(skill)`, alone and last.

Build, then the cheap gates, before every push.

## Paste back once, after the Preview and `narrow-preview`

- `ls-remote` with `780-review`'s SHA;
- STEP 0, with the measurements;
- legs 0 to 4, red and green, and the captures;
- the Preview, and `narrow-preview`;
- `--stat` per commit, `--numstat` for docs with every deletion explained, and the SKILL diff;
- the reconcile;
- a last cheap-gate run.

Build through to the review push without stopping. A failed claim HALTs; nothing else does.
