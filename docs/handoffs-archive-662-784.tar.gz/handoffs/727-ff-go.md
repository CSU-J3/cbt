# HO 727 — correction accepted, two fixes in one amend, then FF

**Your correction is right and my premise was an inference dressed as a reading.** I had the HO 697–699 font work in view and concluded the stack arrived with it. I never ran the pickaxe. That is the exact failure `docs/method.md` § Handoff discipline names — a mechanism named from memory rather than quoted at a SHA — and it is worse here than in a handoff, because it was headed into `oddities.md`, which is where future readers go *for* provenance.

**Verified independently at my end, not taken from your paste** (history unshallowed; the earlier depth-1 clone is why I could not have run this before):

- `git log --all -S"Segoe UI Symbol" -- app/welcome/landing.module.css` → **`b5a9455` alone**. `6bd6749` is absent only because there is no remote-tracking ref for `727-review` here, not because the pickaxe disagrees.
- `git show b5a9455:app/welcome/landing.module.css` carries *"Every font-family below is var(--font-mono) or var(--sans)"* at **`:6`** and the Segoe stack at **`:92`**. One commit, the claim and its counterexample. That single read is stronger evidence than the pickaxe and is the one I would lead the entry with.
- `git show 4ae76a8:app/welcome/landing.module.css` opens *"HO 361 — landing page, ported from the approved mock docs/design/landing.html"* and reads **10 declarations, 0 off-token** — precisely what `backlog:180` records, on the file HO 670 then threw away.

So the sentences were false from the moment they were written, and the lesson is yours, not mine: **a control certifies the file it ran on, and replacing the file retires the control.** That is a better finding than "nobody re-ran it" — it is unfalsifiable-by-re-running, which is the property that makes it worth an oddities entry at all. The HO 677 link is the right one.

## Two fixes, one amend

**1. Scope the pickaxe claim.** *"exactly two commits"* is true for `-- app/welcome/landing.module.css` and **false unscoped**: over the whole tree the same pickaxe also returns `b284a42`, because `docs/design/welcome-formats-mock.html:82` carries the same stack for its `body.flourish-fallback` rule. A reader who runs the command as the entry states it gets three and concludes the entry is wrong. Add the path scope to the command as written, and one clause naming the mock hit as the third and why it is not the module. An oddities entry that cannot survive its own command being re-run is the shape this entry is about.

**2. Amend the subject.** *"Kind unchanged"* meant the commit **kind** — `docs`, not `docs(skill)` or `fix` — not the subject line. My wording was loose and you read it conservatively, which was the right call on an ambiguous instruction. But `git log --oneline` is permanent and it is what the next HO's *highest HO in commit subjects* arithmetic reads, so a subject naming one of two oddities entries is a small false record for free. Rewrite it to name both.

Fold both into one amend on the ref, `--force-with-lease=727-review:faebb72`, kind still `docs`. `check:design-citations` re-runs on the push (no path filter); build and typecheck stay un-run and are named as un-run, as you did.

## Then FF, exactly as you laid it out

`HEAD:main` no force → `ls-remote` → delete the ref → forward local `main` and paste `git rev-parse main` → `verify:deploy` on the tip → read the Production `e2e-prod` run. The local narrow green at 430/390 stays a prediction until that run reports, and the paste says so in those words.

The 204px move goes to `main` unreviewed by the architect on the rendered page — that is the call I made at STEP 0 and it stands, with the after-captures in `727-artifacts/` as the record if it comes back.

Go.
