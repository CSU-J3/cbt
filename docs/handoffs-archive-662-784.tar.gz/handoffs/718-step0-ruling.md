# HO 718 — STEP 0 ruling (architect, 2026-09-12). Six flags accepted, one commit added, the v1 mock is the one blocker, and the NEWS letter is Corey's. Nothing in STEP 1 starts before his word.

Good STEP 0. Rows 1–4 read as the ground truth predicted, which is the first time in this arc a row-2 population did (710's was inverted at STEP 0; 711's predicate was wrong). Row 5 is the one that earned its place: the handoff's term list would have shipped three false positives among the first five items of the panel it was meant to make honest, and the tightened list you read is the fix. Every flag below is accepted; two of them (F1, F5) are corrections to earlier HOs and are recorded as such.

## 1. Row 12 — the HALT blocker is a file drop, not a decision

The v1 mock (`mock-718-electoral-info-layout-v1.html`, sha256 `8c520225…a036`, 17,632 bytes) is the ruled-against state: the four head treatments and the duplicate-fact readout the roadmap block cites. It was delivered beside the handoff and did not reach `docs/design/`. **Corey drops it there; row 12 is re-read and the hash quoted. Commit 1 waits on it.** The v8 match stands as read.

## 2. Row 5 — the reading, and the recommendation the letter rides on

- **(a) unfiltered** would open the 2028 page on seven items about Fetterman's party switch, then Paul, Boozman and Thune. Complete, and none of it about a 2028 seat except by implication. That is the member hub's panel wearing a different label.
- **(b) as written** returned seven items, two of them electoral. The handoff's `announce` and `appoint` terms are the noise: `appoint` matches *disappoint*, `announce` matches any announcement. **Your tightened list is right**: drop `announce`, make it `appointed`. Against the corpus it returns exactly the two real items and nothing else: *Pennsylvania Democrat says he 'might' challenge Fetterman in 2028* and *John Thune signals he'll pursue a 2028 Senate run*. Both are about 2028 seats, both are dated, both are what the panel exists to show.
- **Architect's recommendation: B with the tightened list.** Landed as one exported constant beside the query: `SEAT_NEWS_TERMS = ["retir", "re-election", "reelection", "won't run", "will not run", "not seek", "candidacy", "special election", "appointed", "2028"]`, each as `o.title LIKE '%…%'` with the apostrophe form matching the corpus (read one `won't` title before choosing the quote character; if none exists, the term stays and is named untested). SKILL names the miss in one sentence: a `LIKE` on titles has no recall figure, and item (b) of the new OPEN LOOPS (the `electoral` extraction tag) is the fix. Two items today is the honest render of the feed, not a thin panel; it grows through 2027 without a code change.
- **The Cassidy → Murkowski attachment is a WATCH line, not yet an error.** Before the block calls it a resolver defect, read that observation's `entities` JSON (`observations.entities` keeps every resolved and unresolved name): if Murkowski is named in the article body the attachment is correct and the title just does not say so; if she is not, it is a unique-surname or full-name false resolve and goes to the backlog with the `obs_id` as its instrument. One read, quoted, then the disposition.
- **The letter itself is Corey's.** It arrives in chat, is recorded in the roadmap block as a verbatim quotation with provenance, and commit 3 is written to it. Under A the constant is not written; under C `getSeatNews` and the NEWS section are not written and the OPEN LOOPS line (b) carries the panel's whole scope.

## 3. F1 — accepted, and it amends the HO 700 floor

Your measurement stands: two same-SHA captures seconds apart differed in text on three of four routes because `CyclingTimestamp` rotates the LAST SYNC zone every four seconds, which the HO 700 strip rules cannot see. The remedy is the reading you already took: `reducedMotion: "reduce"` on the context **and** `<script>` removed from the dump, which read identical on all four routes. Ruled:

- STEP 2's three byte-identical claims are diffed **against a base build of `0262e60` running at the same time** in a throwaway worktree on `:3007` (the HO 712 method), so data drift (relative ages, odds) cannot masquerade as a code delta. The row-13 files stay in the artifacts as the recorded pre-state and are named that in the block.
- The floor moves: wherever SKILL states the HO 700 strip floor (grep `next-route-announcer` and `HO 700`), STEP 3 adds the clause *and the capture is taken with `reducedMotion: "reduce"` and `<script>` elements removed, because a rotating zone is text the strip cannot key on; measured at HO 718 on four routes, three of which differed at one SHA under the old floor*. Own sentence, cites the measurement, not the reasoning.
- One oddity, dated and HO-tagged: *a byte-identical claim measured against a rotating clock: same SHA, different bytes, and the strip floor written to catch the announcer could not see the timestamp*. The reduced-motion form was already the repo's reading discipline for layout (HO 708); this is the same discipline reaching the DOM diff.

## 4. F2 — accepted, one commit added

`scripts/diagnostic/layout-audit-606.ts` gains `{ slug: "electoral-2028", path: "/electoral?cycle=2028" }` in its `ROUTES` beside `electoral`, in **its own `chore(HO 718): layout audit walks electoral-2028` commit**, landing after the `test` commit. A forced consequence of asking for the M1 reading, named as a widening in the block. Commit order becomes: docs(design) · refactor · feat · feat · test · chore · docs(skill) · docs.

## 5. F3 — accepted; the SKILL touch list is yours

- `:321-322` (the `races` schema comments carrying *LIKELY · MAY 2025* and the TBD derivation): amended to what the columns render now (`open_signal = 'indicated'` → `MAY NOT RUN · <MON YYYY>`; `incumbent_running = 0` → `NOT RUNNING · <MON YYYY>` when dated; the appointee qualifier derived from `next_election_year ≠ cycle`).
- `:2310` and `:1871` *renders the seat-outlook list* → *renders the seat-outlook report*.
- The Query helpers section (`:1257`) gains entries for `getSeatNews` and `getCycleMarketCoverage`; the handoff's *amend the `getMemberNews` entry* instruction is dropped, since no such entry exists. The fold is recorded on the RACES-tab paragraph's sentence as already specified, and the `readObservationNews` note in `queries.ts` is where the code-side record lives.
- STEP 3's numstat rule holds: every deletion quoted beside its replacement.

## 6. F4 — ruled: keep `.so-name` and `.so-src:hover`; remove `.so-wrap`, `.so-list`, `.so-party`

`.so-name` (with its `a` and `a:hover`) is the name cell's `min-width: 0` + `overflow-wrap: anywhere`, the HO 682 severance; it stays under the new `.so-name-row`. `.so-src:hover` stays with `.so-src`. `.so-party` goes with the `[R-WI]` bracket: the party group carries the party. `.so-list` goes with the `<ul>`. **`.so-wrap` goes too**: its one rule was a top border on the list container, and the ruled sections carry their own hairlines; a border above the dateline would be a second rule with nothing to separate. The full keep/remove list is written into the block's header comment so the next reader does not re-derive it.

## 7. F5 — accepted, and recorded as a 712 correction

`backlog:95` closed at HO 712 saying its House-row criterion *carries forward on the 120th-Congress rollover checklist*, and no checklist item (`:104-110`) carries it. A close that hands its criterion to a line that does not exist is the method § Gates *criterion names a quantity that isn't there* shape one step removed. Ruled: STEP 4 files **a new checklist item** — *after the first `sync:members` against the 120th and `backfill:races`, `/electoral?cycle=2028` renders a `HOUSE · <n>` section, `n` = the Clerk's sitting voting count on the date read (the `:95` quantity), split by party with qualifiers; fixture-proven at HO 718, prod-unread until the date* — and the roadmap block names the gap as a correction to the HO 712 block, which is where a post-FF correction goes (method § Doc authority).

## 8. F6 — the Thune item is a curation input, and a RUNNING qualifier is Corey's line, not this HO's

Politico 2026-08-04, *John Thune signals he'll pursue a 2028 Senate run*, is a pending input for `backlog:100`'s quarterly re-curation: it resolves to `incumbent_running: 1` on the next pass, the seed's reserved value. **As ruled at HO 710, `incumbent_running = 1` renders nothing, and this HO does not change that.** STEP 4 annotates `:100` with the item and files a **decision line for Corey in OPEN LOOPS, no recommendation:** **(D)** a `RUNNING · <MON YYYY> ↗` qualifier on the name from `incumbent_running = 1` plus the announcement's date and URL, the same recipe as NOT RUNNING with the same dated-copy rule; **(E)** stay as ruled, running renders nothing, and the NEWS panel is where a running announcement shows. Named unmeasured on the line: how many of the 34 have a datable running statement on record (Budd, Wyden, Murray, Scott per HO 710's upstream read; Thune now).

## 9. Two corrections to the handoff from the paste, both mine

- **Row 7:** the ON control (`odds-off.spec.ts:176-199`) navigates to `/`, not the race route; the handoff placed it wrong. The 2028 coverage-line assertion is therefore **its own test** in the same spec, *ON control — the 2028 coverage line is emitted*, navigating to `/electoral?cycle=2028` with the gate cookie and no preference and asserting `[data-market="coverage"]` visible. The existing test is untouched.
- **Row 5(a), the Fetterman coverage:** if those seven items describe a completed party switch, `members.party` for `F000479` must already read the new party for the PA row to file in the right group, and if the roster still reads `[D]` then either the switch has not happened or `sync:members` lags it. **No work in this HO**: the served reading in STEP 2 quotes the PA row's party group beside `SELECT party FROM members WHERE bioguide_id = 'F000479'`, and if they disagree it is a backlog line about the sync, filed with the reading.

## 10. What Corey confirms, and what rides on his word

- **Rows 2, 3 and 4** as read: 34 · 19 R · 15 D, FL and OH at 2026; the one `S-WI-2028` statement row with `last_verified 2026-09-10` (the dateline reads it as *retirement statements last checked 10 SEP 2026*, which is exactly what a hand-run seed's stamp means); coverage 0 · 0 · 0 at 2028 against 469 · 34 · 407 at 2026.
- **The row-5 letter**, A / B / C. The architect's recommendation is **B with the tightened list**.
- **The v1 mock** in `docs/design/`.

Nothing in STEP 1 starts before the word; the letter travels as a verbatim quotation with its provenance and is written into the roadmap block before commit 3 is authored.

read and follow 718-step0-ruling — the file, not this line
