# HO 745: has the Senate vote watermark stranded a roll call? A read-only probe, with the menu as the authority

`docs/backlog.md` OPEN LOOPS, *The Senate vote sync strands a roll call that fails before its `votes` row is written as soon as a later roll in the same session is written (HO 744)*, owner Code, medium. The line was read in code at `252411f` and never measured. Its own words: how often it happens is unknown, and so is whether it has happened at all.

It goes first among the four HO 744 found-in-passing lines because the loss is permanent and silent. A stranded roll has no `votes` row, so the HO 567 heal pass can't see it. The watermark skips it forever, and `cron_runs` reads `success` while it happens.

**This HO measures. It builds nothing.** It answers one question: are there Senate roll calls on senate.gov's menu that the store has skipped past? The remedy, if one is owed, is the next HO, and which remedy is a review call made on this HO's numbers.

## Ground truth (read at `9ba6cec`; re-derive every `:N` by content)

- `lib/senate-votes-sync.ts`
  - `menuUrl` at `:107` builds `https://www.senate.gov/legislative/LIS/roll_call_lists/vote_menu_{congress}_{session}.xml`.
  - The parser is `new XMLParser({ ignoreAttributes: false, trimValues: true })` at `:145`.
  - The sync reaches the current congress and sessions `[1, 2]` (`:380-381`).
  - The menu list is `menu?.vote_summary?.votes?.vote` (`:413`), newest-first, reversed before the loop.
  - `getMaxRollCall` (`:204`, SQL at `:210`) is read once per session at `:420`. Every menu roll at or below it is skipped at `:432`.
  - Failures are counted at `:445` and `:465`; the failed id reaches only the runtime log.
  - The heal pass (`:336-341`, `HEAL_CAP` at `:33`) sees only rolls that have a `votes` row.
- `scripts/migrate.ts:377`, `votes`
  - `id TEXT PRIMARY KEY`, `chamber`, `congress`, `session`, `roll_call INTEGER`, `vote_date`, `question`, `description`, `result`, the tallies, `raw_json`, `update_date`.
  - `member_votes.vote_id REFERENCES votes(id)` at `:403`.
- The schedule is `/api/sync-votes` at `0 10 * * *` (`vercel.json:66-67`), so the Senate store moves once a day at 10:00 UTC.
- `.claude/skills/cbt/SKILL.md:1137` says both vote syncs are "watermark-incremental, so a tick that runs long simply resumes next day." For the Senate, that sentence is what this probe tests. It is not edited here.
- No counts are given here. STEP 0 and the probe measure them.

## STEP 0

1. **HO number.** Take it from the tree: `max(roadmap pointer, highest HO in commit subjects) + 1` (method.md § Handoff discipline). At `9ba6cec` both read 744, so this is 745. If the tree says otherwise, the tree wins and the filenames follow it.
2. **Citations.** Re-read every cited `:N` at HEAD by content. A drift is flagged, not absorbed.
3. **Payload path.** Read one `/api/sync-votes` `cron_runs` row's payload and confirm where the Senate `votesFailed` lives. The line says `$.payload.senate.votesFailed`.
4. **Egress.** Confirm senate.gov answers from local; the CLI path `npm run sync:senate-votes` already depends on it. If local egress is refused, stop and say so. Don't route around it.
5. **Proceed** without a halt unless something above contradicts this file. The probe is read-only and its scope is fixed.

## The instrument: `scripts/diagnostic/senate-roll-gaps-745.ts`

It is read-only against prod: SELECTs only. It never imports the sync's write path, and nothing POSTs `/api/sync-votes`.

1. **Menu, the authority.** For each session the sync reaches (`:380-381`):
   - Fetch the menu from the sync's URL shape, with the sync's parser options, and take `vote_number` as an integer the way the loop does (`rollInt <= 0` skipped).
   - **Parse control, on every read, prod included:** the parsed count must equal a raw count of `<vote_number>` elements in the same bytes. A mismatch stops the probe.
2. **Store.** Read the stored `roll_call` set for `chamber = 'senate'` and that congress and session, with its MIN and MAX.
3. **Classify.** Every menu roll with no stored row falls into exactly one of:
   - **never reached:** below the stored MIN (a backfill boundary, not the line's failure);
   - **stranded:** between MIN and MAX (the line's failure);
   - **pending:** above MAX (the next 10:00 UTC tick fetches it).
   List any stored roll that is absent from the menu separately. None should exist.
4. **The line's own gap query, beside the classification.** Run `SELECT congress, session, MAX(roll_call) - COUNT(*) AS missing FROM votes WHERE chamber = 'senate' GROUP BY congress, session` over the whole table. Any congress or session the sync no longer reaches gets this query only, as context, with no menu read.
5. **Each stranded roll:** its menu date and question, so the cost is legible (a nomination, a cloture vote, a passage vote).
6. **The heal pass's own set, for context:** Senate `votes` rows with a nonzero tally and no `member_votes`, per session. This is the complement the heal pass does cover, and the remedy's design will want both numbers.
7. **History.** Every `/api/sync-votes` `cron_runs` row where Senate `votesFailed > 0`: id, start time, count. Give the total rows scanned and the earliest row, which is the history's horizon. Where a failing row is inside the runtime-log retention, read its failed-id lines. Say where retention stops.

**Run it outside the 10:00 UTC tick.** Read the newest `/api/sync-votes` `cron_runs` row before and after the prod run. If it changed during the run, the store moved under the read: run again.

## Controls: seen red before the prod reading

On a `file:` copy of prod, made the way HO 744's legs made theirs. **The perturbation step refuses any database URL that isn't `file:`,** and prints the URL scheme it ran against.

- In one session of the copy, delete one mid-session roll N and the session's top roll M. Delete their `member_votes` first (the FK at `migrate.ts:403`).
- **Expected:**
  - stranded gains exactly N;
  - pending gains exactly M;
  - that session's gap query reads prod's value + 1.
- If the probe misses N, or files M as stranded, the instrument is wrong. Stop.

## The prod reading

After the controls, run it once against prod. Name the `cron_runs` row it follows. The table is:

`congress · session · menu · stored · MIN · MAX · never reached · stranded · pending · stored-not-in-menu · gap query`

Then the stranded list with dates and questions, the heal-pass set, and the history rows.

**The fork after this reading is a review call, not Code's.**

- **Stranded is zero everywhere:** the mechanism is real and hasn't fired. The line stays open with the reading on it. Its close needs the remedy's two-run leg, which this HO doesn't build.
- **Stranded is above zero:** the remedy is the next HO, and this one only lists what it has to fill.

Either way, the history rows say how often the loop fails at all.

## Commits and docs

- `diag(HO 745)`: the script.
- `docs(HO 745)`:
  - annotate the backlog line in place with the reading: the `cron_runs` row it follows, the per-session numbers, any stranded ids, and the history counts;
  - add the roadmap block.
  - No SKILL change, and no new lines. If the reading finds something outside this line's mechanism, flag it in the paste-back before filing anything.
- Reconcile OPEN LOOPS at open and at close, control `^- \*\*~~` 0 at both.
- Review ref `745-review`. The FF is held for review.

## Gates

Run the cheap gates: typecheck, `check:odds-sites`, `check:design-citations`. No served bytes change, so no captures and no Preview reading are owed. If CI runs one anyway, report it as it comes.

## Paste back

- the STEP 0 readings;
- the control's readings;
- the parse control per session;
- the prod table, the stranded list, the heal-pass set and the history;
- the `cron_runs` row the reading follows, read before and after;
- `--numstat` (the deletions column, not a grep);
- the review ref's sha from `ls-remote`;
- a last cheap-gate run immediately before the paste, with the reading named.
