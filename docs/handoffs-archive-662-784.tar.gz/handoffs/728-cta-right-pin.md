# HO 728 — the `/welcome` CTA block pins to the banner's right margin, and the audit says whether HO 727 left a term behind

Corey ruled this off the rendered page at `f30b597`: with the flourish gone, the CTA block sits left-aligned inside `.right` while every other band on the landing — the rail, BREAKING, the MARKETS tape, the panels, the bottom bar — reaches both page edges. The banner is now the only band that does not, and the void between LOGIN and the right margin is the 190px the flourish used to occupy plus the 14px gap HO 727 freed.

**My chat estimate of "one declaration" was wrong and the handoff corrects it before STEP 0 has to.** `justify-content:end` on `.ctagrid` is right in the base, where `.banner` is two columns and `.right` is the narrow one. At `:261` the banner **stacks to one column** (`grid-template-areas:"head" "lead" "right"`), so `.right` becomes full page width with a left-aligned headline above it — `end` there would fling the buttons to the far right of a single-column page. So it is **two declarations**: `end` in the base, back to `start` in the `@media (max-width:1180px)` block. STEP 0 measures whether the 1180 revert is actually needed rather than taking that reasoning on trust.

**The margin this pins to is not a new number.** `.banner{padding:12px 28px 24px}`, `.rail{padding:14px 28px}`, `.bottom{padding:14px 28px}` — one 28px right margin across all three. Pinning the CTA to `.right`'s right edge puts it on the same line as the rail's clock and the bottom bar's LAST SYNC, which is the idiom HO 722 registered as *residue by ruling* on register line (x). This is the banner joining that idiom, not inventing one.

**The part that makes this more than taste, and the reason it gets a gate.** `.ctagrid` is block-level inside `.right`, so at 2560 it is a ~1045px box whose content now ends ~204px earlier than it did at `72af9a5`. `scripts/diagnostic/layout-audit-606.ts` measures `trailingGapPx = innerRight - rightMost` (`:716`) and scores M1b on a singleton ≥600px wide with ≥2 children on one line and no siblings — which `.ctagrid` satisfies on every clause. It did **not** carry a term at HO 720's crawl or HO 722's re-read, and the likely reason is the container cut: `M1B_MAX_CHILD_H = 60` (`:166`), and `.stats` is plausibly just over it. **So `/welcome` may now be sitting one or two pixels from a new register term that HO 727 created and nobody looked for.** This HO either drives that trailing gap to ~0 and forecloses it, or finds the term already open and prices it. Either outcome is a reading, which is what makes this failable rather than a preference.

**Two commits expected, kinds pure:** `fix` (one path) · `docs`. A `docs(skill)` commit **only if** STEP 0 finds a sentence that goes false — SKILL `:1847` describes the grid's columns, not its alignment, so the expectation is none. No data, no query, no route, no client island.

**The close, as filed:** at 2560 and 1920, `.ctagrid`'s `trailingGapPx` reads ≤ 2 where it read ~204 higher before, `.btnSecondary`'s right edge equals `.right`'s right edge, and that edge equals the rail clock's and LAST SYNC's right edge to the pixel. At ≤1180 every x is unchanged from the pre-state. `--route welcome` reads the same M1a/M1b/M1c counts after as before, or a changed count with the row named. **What it reads if the work never happened:** a `justify-content:start` at `landing.module.css:80` and a three-figure trailing gap at 2560.

## Ground truth (read at `f30b597`, `main`; re-derive every `:N` by content)

- `app/welcome/landing.module.css:56-58` — `.banner{display:grid;grid-template-columns:1.35fr 1fr;column-gap:48px;row-gap:0;padding:12px 28px 24px;align-items:end;grid-template-areas:"head right" "lead right"}`. `:61` `.right{grid-area:right;align-self:end;padding-bottom:4px}`.
- `:79-80` — `.ctagrid{display:grid;grid-template-columns:auto auto;column-gap:14px;row-gap:0;align-items:center;justify-content:start}`. **`justify-content` appears exactly once in this module**, here. The `:77-78` comment now ends *"Two columns, one per button: HO 727 removed a third that held only the decorative line beside ENTER TERMINAL"* and will need one clause for the pin.
- `:114` `.stats{grid-row:1;grid-column:1/3;justify-self:start;margin-bottom:22px;…width:max-content;max-width:100%}` — spanning both tracks, so **`.stats` contributes to track sizing** and the grid's free space is the container minus the wider of the stats strip and the buttons row. `justify-self:start` is kept: the strip stays flush with ENTER TERMINAL's left edge under either `justify-content`.
- `:261-262` — the 1180 block: `.banner{grid-template-columns:1fr;grid-template-areas:"head" "lead" "right"}`, `.right{align-self:start;margin-top:26px;padding-bottom:0}`. `:274` sets `padding-left/right:18px` on the rail, breaking, banner and bottom inside the 900 block, so **the shared margin is 28px above 900 and 18px below** — the pin follows whichever applies, because it pins to `.right`, not to a literal.
- `:315` — the 560 block: `.ctagrid{grid-template-columns:minmax(0,1fr)}`. A single `1fr` track fills the container, so free space is zero and `justify-content` is **inert** there by construction. The 1180 revert covers 560 anyway; this is the second reason it cannot bite.
- `scripts/diagnostic/layout-audit-606.ts`: `GAP_THRESHOLD_PX = 120` (`:155`), `M1B_MAX_CHILD_H = 60` (`:166`), `trailingGapPx` at `:716/:722`, `--route <slug>` / `AUDIT_ROUTE` at `:236`, run form at `:98`. A `--route` run reads 12 legs; it hits prod Turso read-only and measures on hit 2.
- `docs/backlog.md` register line **(x)** (HO 722) carries `/welcome`'s two M1b rows, the rail and the bottom, priced as residue by ruling with variant A costed. Nothing there names the banner or the CTA grid. STEP 0 quotes it to decide whether this HO adds to it, amends it, or leaves it alone.
- **Pointer arithmetic**: roadmap pointer 727, highest HO in commit subjects 727 → **this is 728**. Open loops at the HO 727 close: **260 live / 263 struck**.
- Estimates, not readings: the ~204px and ~360px figures from the rendered screenshot; `.stats` being "just over" 60px tall; the 1180 revert being necessary.

## STEP 0: enumerate and measure, then HALT

| # | check | expected | if the work never happened, this reads |
|---|---|---|---|
| 1 | `git ls-remote --heads origin`; `git status --porcelain`; pointer and highest HO | `main` alone at `f30b597`; clean; 727 / 727 → **728** | a second head means an FF is pending and this waits |
| 2 | Quote `:56-61`, `:79-80`, `:114`, `:261-262`, `:274`, `:315`; `grep -c "justify-content" app/welcome/landing.module.css`; backlog line (x); SKILL `:1847` | one `justify-content` in the module; (x) names only the rail and bottom | a second `justify-content`, or an (x) clause naming the banner, widens this and is named |
| 3 | `npm run build` · `npm run typecheck` | 0 · 0 | not this HO's to fix |
| 4 | **The pre-state, on a local production server bound by PID**, at **2560, 1920, 1440, 1180, 1100, 900, 560, 430, 390**: `.ctagrid`'s rect and `trailingGapPx` (`innerRight − rightMost`, the audit's own formula); the right edges of `.btnSecondary`, `.right`, the rail clock and LAST SYNC; `.stats`'s **height** and its width against the buttons row | a three-figure trailing gap at 2560/1920 shrinking with viewport; the rail and bottom already flush at 28px (18px below 900) | this is the pre-state and every post-fix number is read against it |
| 5 | **Does `.ctagrid` carry a term today?** `npx tsx scripts/diagnostic/layout-audit-606.ts --route welcome`, 2560, hit 2. Report M1a/M1b/M1c with every row's selector, interior and trailing | the two known M1b rows (rail, bottom) | **a third row whose selector is the ctagrid means HO 727 opened a term** — report it, do not fix it here until row 7 rules |
| 6 | **The container cut, measured against its own constant.** `.stats`'s computed height at each width beside `M1B_MAX_CHILD_H = 60` | a number, not a verdict | **within 5px of 60 either way is the finding**, and it is filed regardless of which side it lands on: a term gated on a 60px constant by a pixel or two is a reading that will flip on a font change |
| 7 | **The prediction, in-browser only, nothing edited.** Set `justify-content:end` on `.ctagrid` at each of the nine widths; re-read every rect from row 4. Then, separately, at **1180 and below**, read what `end` does with the banner stacked | trailing ≤ 2 and `.btnSecondary` flush with `.right` above 1180; a large, wrong rightward fling at ≤1180 | **if ≤1180 shows no fling, the 1180 revert is unnecessary** — say so and drop it from STEP 1 rather than landing a rule that does nothing |

HALT here with the seven rows. The go arrives as a file.

## STEP 1: the pin (commit `fix(HO 728)`; one path)

1. `:80` — `justify-content:start` → `justify-content:end`.
2. The `@media (max-width:1180px)` block gains `.ctagrid{justify-content:start}`, **conditional on row 7**. If row 7 read no fling, omit it and record why.
3. The `:77-78` comment gains one clause: the block pins to `.right`'s right edge, which is the banner's own 28px margin and therefore the same line the rail's clock and the bottom bar's LAST SYNC hold — cite `.rail` and `.bottom` by their padding rules so the claim is checkable, and name HO 728. Do not restate the 204px; that number is HO 727's and lives in its roadmap block.

`.stats` keeps `justify-self:start` and is not touched. No other rule changes.

## STEP 2: docs (commit `docs(HO 728)`)

- `docs/roadmap.md` — one `Also (HO 728)` block, pointer 727 → 728: Corey's ruling off the rendered page, the two-declaration correction with the 1180 reasoning and row 7's verdict on it, rows 4 and 7's before/after table, and **rows 5 and 6 in full** — whether `/welcome` carried a third term, and `.stats`'s height against the 60px constant either way.
- `docs/backlog.md` — if row 5 found a third M1b row, either it is closed by this fix (`--route welcome` re-reads the two known rows) and the finding is recorded as opened-and-closed within one HO, or it survives and gets a line. If row 5 found nothing, no entry. Reconcile open loops at open and close; **260 / 263** at open.
- `docs/oddities.md` — row 6 lands here if the height is within 5px of the constant, with the constant cited at `:166` and the consequence named: which side of a term this page falls on is decided by a font metric.

## Gates

Build then typecheck, exit 0, re-run before the paste. Captures before and after at **2560, 1920, 1440, 1180, 900, 430** plus a reduced-motion pass, full page and banner crop, rects beside each — ways-of-working, and this is a pure-geometry change where the capture is the product. `--route welcome` re-run after the fix, counts quoted against row 5. Narrow gate at both widths, named as a prediction of CI's until the Production run reports. `check:design-citations` → `OK` from a fresh clone of the review ref. Explicit path staging. No `/api/sync`, no DB write; the audit's prod reads are read-only.

## Review ref, then FF

Review branch from the start; push the ref; any SKILL diff approved alone and flagged for attach, though none is expected; `HEAD:main` no force; `git ls-remote`; delete the ref; local `main` forwarded with `git rev-parse main` pasted; `verify:deploy` on the tip; the Production `e2e-prod` run read after the FF. Paste-back per `docs/method.md` § Executing a handoff.

---

read and follow 728
