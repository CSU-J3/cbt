# HO 691 — the post-primary race card: what the MI card gets wrong now that the primary is over

Code kind, with a data refresh. The dashboard's S-MI-2026 card reads `AIPAC super PAC · backing Stevens` under a challenger line reading `Abdul El-Sayed† D · leads · Rogers`. Haley Stevens lost the August 4 Democratic primary to El-Sayed; Mike Rogers was unopposed for the Republican nomination. Both statements on the card are true facts about the primary rendered as present-tense claims about the general, and the strip's footnote underneath (`† presumptive — Democratic primary unresolved`) is simply false. The primaries were built for, and the card's shapes were tuned against, a pre-primary field; September has arrived and the card has not.

**Ruled by Corey, 2026-09-03, verbatim:** *"the races on the dashboard needs to say what is currently happening. that can be filed in races idk?"* Read as: the **dashboard card renders the current state of the race only**; history (who a PAC backed in a lost primary) **lives on the races surface** (the `/race/[id]` hub and the `/electoral` expands, which render the linked `full` variant), not on the glance card. The architect makes the "where in races" call: the full variant, past tense, dimmed, still FEC-linked.

**This is a class, not an instance.** All seven seats with UDP rows had their primaries before September (KY-04, IL-07, IN-08, NY-16, CA-34, MO-01, S-MI). Every line is potentially stale the same way, and the fix is a status rule on the target, not an edit to one row.

## Ground truth at authoring

- Clone at `064714e` (HO 690 shipped 2026-09-04), pointer 690, number `max(690, 690) + 1 = 691`. Re-derive at session open. Every anchor below was re-read at `064714e`; HO 690 touched none of these files.
- **The PAC line.** `components/PacSpendingLine.tsx` — `prepare()` `:42–66` dedupes by direction+surname; the `glance` variant `:79–92` renders `backing X, opposing Y` non-linked for the dashboard `RaceCard` (`components/RaceCard.tsx:467`); the `full` variant renders FEC deep-links and rides `RaceListView.tsx:224`, `RaceMapCard.tsx:247`, `RaceHubBody.tsx:127`. Rows come from `getPacIeSpending(cycle)` (`lib/queries.ts:2137–2160`, `unstable_cache` tag `races`, `PacIeRow` at `:2128`) off `pac_ie_spending` (`scripts/migrate.ts:179–194`, UNIQUE on committee/candidate/direction/cycle, `earliest_date`/`latest_date`). The table is written only by the **manual** `npm run sync:pac-ie` (`scripts/sync-pac-ie.ts`, upsert `:96–107`, `dropped` log `:137`), last run 2026-08-11 per SKILL; **the upsert never retires a row**, so a primary-phase IE stays forever unless something classifies it.
- **The matchup.** `lib/race-matchup.ts::deriveMatchup` (`:168–232`): with ≥2 active challengers and no single `NOMINATED` one, the shape is `leader` when the market favourite is a challenger (`:216`), else `nolead` (`:224`, meta `primary (N)`). `NOMINATED = {won_primary, nominee}` (`:43`), `WITHDRAWN` (`:26`). `RaceCard.tsx:287–304` renders `leader` with the dagger; `CompetitiveRacesStrip.tsx:68–77` collects `presumptiveParty` and `:110–116` prints the footnote. For S-MI both challengers are (expected) `won_primary`, so `won.length === 2 ≠ 1`, no single nominee, and the market picks El-Sayed → `leader`. **The shape has no concept of "both parties have their nominee."**
- **Roster + primary statuses.** `race_candidates(race_id, name, party, bioguide_id, status, source_url)` (`migrate.ts:158–166`) is fed by the hand seed and by `npm run backfill:race-challengers`, which harvests **winners only** (`status='won_primary'`, sentinel `source_url='harvest:primary_winner'`) from `primary_candidates` (`migrate.ts:465–475`, `status` running/winner/loser, `vote_pct`), joined by state/chamber/district. So a losing primary candidate is **absent** from `race_candidates` and **present** in `primary_candidates` as `loser`. The classifier below reads both, and reads the roster last.
- **FEC name shape.** `candidate_name` is `LAST, FIRST …` (`lib/pac-ie.ts::pacSurname`, `:51`); roster and primary names are `First Last`. Match on the surname key (`lib/race-colors.ts::nameKey` / `surname` — confirm they fold diacritics and hyphens; `CONYEARS-ERVIN` and `Sánchez`-class names are in the live set).
- **Real-world anchor for the STEP 0 expectations** (Bridge Michigan / CNN / WaPo, 2026-08-05): El-Sayed won; Stevens conceded; Rogers unopposed; UDP's ads *touted Stevens and hammered El-Sayed*. If the opposition was coded `O` on Schedule E against El-Sayed, a fresh read produces a row whose target **is** current, and the MI glance line reads `opposing El-Sayed` rather than nothing. Expectation, not premise: the probe decides.

## STEP 0 — enumerate, then HALT

| # | candidate | expected |
|---|---|---|
| 1 | every `pac_ie_spending` row, cycle 2026 | race_id · candidate_name · S/O · earliest · latest · as_of, all rows (10 / 7 races at the last reading). Quote the table |
| 2 | each target's status, from data not memory | per row: the matching `primary_candidates` rows for the seat (state, chamber, district; `election_round='primary'`), their `status` and `primary_date`; the matching `race_candidates` row if any and its `status`; whether the target is the seat's incumbent. Classify: **NOMINEE** (winner / `won_primary` / `nominee`, or a running incumbent) · **LOST** (`loser`) · **WITHDREW** · **UNKNOWN** (no match either side). Name the surname-key function used and any row it failed to match |
| 3 | fresh Schedule E, read-only | add `--dry-run` to `scripts/sync-pac-ie.ts` (skips the upsert, prints each collapsed group → resolved race → direction → earliest/latest; flag absent = byte-identical behaviour) and run it. Diff against row 1: new groups, moved `latest` dates, new drops. Mind the shared api.data.gov 60/hr tier (SKILL, PAC spending); one walk. **The dry-run rides the STEP 1 commit** (686/687 precedent) |
| 4 | the S-MI-2026 card as rendered | `race_candidates` rows and statuses for the seat; the `ChallengerShape` `deriveMatchup` returns for it (expected `leader`, favourite El-Sayed via Kalshi/Polymarket); the strip footnote text **read off the served DOM of `/`** (expected `† presumptive — Democratic primary unresolved`) |
| 5 | the class across the other six seats | for each UDP seat: which targets are LOST/WITHDREW today; which surfaces render its line (dashboard glance only if featured; hub full always). The count of live lines that are stale by the row-2 classification |
| 6 | roster harvest currency | when `backfill:race-challengers` last ran vs which primaries have resolved since (any `primary_candidates` winner with no `race_candidates` counterpart, across the rated set); whether the six featured seats' rosters carry `NOMINATED` statuses where a primary has resolved |
| 7 | SKILL exposure | the PAC spending section (variants, the `backing Stevens` example, the S-MI coverage figures), the Race surface's matchup sentences, the `/` entry's dagger/K-P clause. Expected three touches |

**HALT.** Corey confirms the row-2 classifications and the row-3 diff before anything is built. The two render rules below are the architect's and are pre-stated so the HALT is a table read, not a design session; Corey can flip either in a word.

## STEP 1 — build (one code commit)

**A. Target status on the row, computed once, in the query layer.** `getPacIeSpending` gains a second read (the seat set is ≤7, one `IN` list) and classifies each row per STEP 0 row 2 into `targetStatus: "active" | "lost" | "withdrew" | "unknown"` on `PacIeRow`. Rules, in order: a `winner`/`won_primary`/`nominee` match → `active`; a `loser` match with no winner match → `lost`; a `withdrew`-class roster match → `withdrew`; otherwise `unknown`. **`unknown` renders exactly as today** (present tense, undimmed) — a classifier's silence is never a reason to hide a stored fact, and that asymmetry is the whole safety property of the rule. Cache tag stays `races` (flushed by `sync:pac-ie` and every Kalshi tick, so a primary-result backfill is reflected within ~2h without new wiring; say so in the code comment).

**B. The two variants diverge on status, deliberately.**
- **`glance` (dashboard):** renders `active` + `unknown` targets only. When none remain, the line is absent — the seat has no current UDP direction, and absence is the signal (the USCPR-badge convention the component already cites). Never `backed`, never dimmed text, never history.
- **`full` (hub + `/electoral` expands):** renders every target, **current first**, then `lost`/`withdrew` in past tense and dimmed: `backed Stevens ↗ · lost primary` / `opposed X ↗ · withdrew`. The FEC deep-link stays on the past-tense item (the dollars are real and the reader can see them), and the `since {month}` cue is computed over the rendered current items when any exist, over all items otherwise.
- `prepare()`'s dedup key becomes direction+surname+status so a target that both lost and (impossibly) won never collapses two facts into one.

**C. The general-election shape.** `ChallengerShape` gains `general: { members: { fullName; party }[] }`, derived when `active.length ≥ 2` **and every active challenger is `NOMINATED`** (party mix irrelevant: a top-two seat can produce two same-party nominees, and `D v D` is the honest label). Precedence: single `nominee` → `general` → `leader` → `nolead`. `presumptiveParty` stays null for `general`, so the footnote cannot fire for it. `RaceCard` renders it as each name with its own party dot, dot-joined (`El-Sayed · Rogers`), meta `D v R · nominees`, **no dagger**; the market favourite still drives the edge accent and the K/P line as before, so nothing the card knew is lost, only the false claim. Mirror the `NOMINATED` comment (`race-matchup.ts:36–43`) and `getRaceCandidates`' ORDER BY comment (`queries.ts:1882–1915`) where they enumerate shapes.

**D. Data refresh through the standing paths, after the HALT:** `npm run sync:pac-ie` (the real run; rows quoted before/after, `rowsAffected` read back); `npm run backfill:race-challengers` if row 6 showed the harvest behind the resolved primaries (sentinel rows only, curated rows untouched, as the script already guarantees); `POST /api/revalidate?tag=races`. **No raw `UPDATE` to any row** — if a roster status is wrong and no standing path corrects it, HALT and say which row.

`tsc` clean, build clean.

## STEP 2 — proof

1. **S-MI-2026 on `/`:** the challenger line reads the `general` shape, no dagger, **no footnote anywhere on the page** (assert `.race-grid-foot` absent, not "not seen"); the glance line absent or reading only current directions (per the row-3 diff). Captures at **1440 / 2560 / 430 + reduced-motion**.
2. **S-MI-2026 on `/race/S-MI-2026`:** the full line with the past-tense dimmed item and its FEC link resolving to a filtered browser (open it). Capture.
3. **The class:** the row-5 table re-read after the build — every UDP seat's rendered line(s), before → after. A seat whose target is `active` is the **control**: its line is byte-identical before and after (quote both).
4. **Classifier falsification:** run the classifier against one row with a deliberately mangled `candidate_name` (in a scratch harness, never a DB write) → `unknown` → the glance line **renders**. State what this reads if the asymmetry were inverted: the line hidden. Then the positive: the Stevens row → `lost` → the glance line drops it.
5. **`general` precedence:** a unit-style harness over `deriveMatchup` with three rosters: two cross-party nominees (→ `general`), one nominee + one running (→ `nominee`), two running same-party with a market favourite (→ `leader`, unchanged). Committed as `scripts/diagnostic/matchup-shapes-691.ts`, tracked.
6. Render budget: `getPacIeSpending`'s second read timed cold and warm (`EXPLAIN` is a plan, not a latency — SKILL); expected single-digit ms on a 7-seat `IN` list.

## STEP 3 — SKILL (own commit, self-mod guard)

Row 7's touches, each landing **after** the sentence it annotates and never inside it (the HO 690 splice rule: attaching provenance to the number it rules is the pull that broke the meta-column bullet twice): the PAC spending section gains the status rule and the variant split (glance = current only; full = history in past tense), re-measured coverage figures with today's date, and retires the `backing Stevens` example for one that is true; the Race surface passage gains the `general` shape and the footnote's narrowed condition; the `/` entry's dagger clause is corrected in full. Diff gitignored, attach-to-chat instruction, approval before `main` moves.

## STEP 4 — docs (one commit)

Roadmap `Also (HO 691)` + pointer, carrying Corey's ruling verbatim with provenance, the class finding (seven seats, one rule), the row-3 diff, and the false-footnote finding as the reason `general` exists. Backlog: a **WATCH** — *primary-phase PAC lines age into the general; the classifier reads `primary_candidates`, so a seat whose primary result was never backfilled classifies `unknown` and keeps rendering present tense* — with the instrument (`SELECT … WHERE targetStatus='unknown'` equivalent, run at each `sync:pac-ie`) and what its zero means. If row 6 found the harvest behind, a second line for that with the re-run recorded. Oddities: the footnote that was false on the primary surface for a month with every gate green is a **content** defect no instrument in the repo can see; file it as such, with the date range, so the next reader knows the class exists.

## STEP 5 — review ref, FF

`691-review`, ls-remote, architect review, SKILL slot, FF, ref deleted, `verify:deploy`, served SHA, and the MI card captured against prod (the `races` cache converges on the next Kalshi tick; use the converge-and-hold read, SKILL "Value-change convergence").

## Paste-back

STEP 0 table with rows 1–5 quoted in full (the HALT's substance). After STEP 2: the before/after line table, the classifier readings, the footnote assertion, captures. SKILL diff attached. After FF: ls-remote, served SHA, prod capture.

read and follow 691
