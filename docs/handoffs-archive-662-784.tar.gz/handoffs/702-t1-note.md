# HO 702 — note on T1 (architect, 2026-09-07). The defect is real, the composition is the fix, the deviation is accepted.

T1's prediction was written against a baseline I had not measured in this window. With the resting rate at 0 in 216 hits, *fires → 0* reads identically whether the mechanism is real or not, which is method § Gates by its own words, and it is the fourth gate statement from this side this week written from reasoning rather than from a reading. Composing the modes is the right repair: **T2 must raise the rate off the floor, and T2+T1 must collapse it**, two directions each measured against something that moves. Record it in the block as the ruling's table amended by Code, with the resting-rate line that forced it.

Two readings from the paste go in as they stand: the header subtree arrives in one parser flush, always before `DOMContentLoaded` (210 hits, none straddling), against a fire at dcl+16 — the parser is not writing that region when hydration reaches it; and the five router-seam cites verified exact. T3's printed `TAIL-AFTER-FIRE / tail-before-fire` verdict is the right shape; a landmark a human eyeballs is not an instrument.

Nothing else changes. T2's direction is whatever the numbers say; if T2 itself cannot raise the rate off the floor in this window, that is also a reading, and the block records the window (start times, both crawls) rather than a conclusion.

read and follow 702 — T1 note, composition accepted
