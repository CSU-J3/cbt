# HO 728 — STEP 0 ruling and go

STEP 0 accepted. Proceed to STEP 1 with both declarations. Your correction is right, verified at my end, and it lands one addition rather than none.

## The premise, verified and conceded

`trailingGapPx` is written into the row at `:722` and **consumed by nothing**. Every use of `GAP_THRESHOLD_PX` — `:1397`, `:1406`, `:1418`, `:1582`, `:1595`, `:1983` — filters on `interiorGapPx`. The total at `:1983` is labelled *M1 rows over 120px* and is built from interior filters alone. So the quantity is recorded and never scored, exactly as you say, and BREAKING at trailing 1809 counting zero is the right worked example: if trailing counted, it would be the largest hit on the page.

**My error was the same shape as HO 727's, and that makes it a pattern worth naming rather than a second apology.** Both times I read where a quantity is *defined* and inferred how it is *used* without following it to its consumer. `trailingGapPx = innerRight - rightMost` is a real line I quoted correctly; I just never grepped for who reads it. `docs/method.md` § Handoff discipline says a mechanism is read and cited, never recalled — I did read it, which is why the rule as written did not catch me. The refinement: **reading a definition is not reading a use, and a handoff that leans on a quantity owes a grep for its consumers.** Two consecutive STEP 0s have caught this, which is the loop working, and the rule exists so it has less to catch.

Row 6 follows: 7.5px over at its nearest is outside the band, **and** your sharper point retires the entry outright — even without the container cut, `.ctagrid` would read interior 14 and score 0. The 60px constant is not load-bearing here in either direction. No oddities entry for it, as you propose.

## The close, rescoped so it can fail

Your geometry close is the right one and it needs its width scope stated, because trailing is nonzero below 1180 **by design**: the single `minmax(0,1fr)` track fills the container while `:320`'s `justify-self:start` leaves the items left inside it, so `innerRight − rightMost` stays large there and always will.

- **Above 1180:** `.ctagrid` trailing ≤ 2, and LOGIN's right edge = `.right`'s = the rail clock's = LAST SYNC's, to the pixel — 2532 / 1892 / 1412 / 1153 at the four widths you read.
- **1180 and below:** every x identical to the pre-state row, trailing unchanged at 720.6 / 640.6 / 460.6 / 148.5 / 18.5 / 0.
- `--route welcome` stays in the gate set and is named for what it is: **a no-change control, not a discriminator.** A control that cannot move is worth running and worthless as proof, and the paste says which it is.

## One addition to STEP 2

**The instrument finding gets an oddities entry, not just a roadmap line.** *The layout audit records a trailing gap it never scores* is a property of a diagnostic this project leans on across HO 606, 719, 720, 722 and 725, and it misled the architect into building a gate on it. Left in a roadmap block it is buried in one HO's narrative; in oddities it is where the next reader of the audit will look. The entry carries: `trailingGapPx` written at `:722`, the six `GAP_THRESHOLD_PX` sites that all test `interiorGapPx`, `:1983`'s label as the plain statement, **BREAKING's trailing 1809 / interior 9–35 / count 0 as the worked example**, and the panel `rmeta` rows at 428–632 as the second. One sentence on the consequence: a row can be visually wide-open on its right and correct by the instrument, so the audit's silence about `/welcome`'s banner was never evidence the banner was tight.

Row 6 goes into the roadmap block as a number with your "would still read interior 14" clause attached, so a future reader does not re-open it as a near-miss.

**Correct one provenance figure while you are in the block.** Trailing at 2560 is **535.5**, and was **331.6** at `72af9a5`. So the void is mostly HO 670's and HO 727 widened it by 204 — this HO is not cleaning up after 727, it is closing something that has been open since the board rebuild. My chat framing implied otherwise and the block should not inherit it.

## STEP 1 and the rest, as written

Both declarations: `end` at `:80`, `start` in the 1180 block. The 560 block untouched. The `:77-78` comment gains the pin clause citing `.rail` and `.bottom` by their padding rules. `.stats` keeps `justify-self:start` — your 434.8-against-509.6 reading is why that matters and belongs in the block.

Backlog: no entry, row 5 found nothing. Open loops **260 / 263** at open, reconciled at close. Captures at the six widths plus reduced motion, before-set already taken. Narrow gate both widths, named as a prediction until the Production run reports. `check:design-citations` → `OK` from a fresh clone of the ref. Two commits, `fix` then `docs`; no SKILL, as row 2 found.

Go.
