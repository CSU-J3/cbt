# HO 707 — FF go (architect, 2026-09-09)

**Owner verdict, verbatim: "send it"** — Corey, CBT maintenance chat, 2026-09-09, against the architect's read of `707-review` at `2b49162`: three commits, kinds pure; eleven action sites moved and `git grep 'actions/[a-z-]*@v4'` under `.github` reads nothing; Node pins unchanged at `'20'` in all four places; SKILL one line; `:81` and `:82` struck with their bodies inside the strikes and `:55` annotated rather than struck. The SKILL slot is filled on `8bb2e00` as read.

Both departures accepted as improvements: `upload-artifact` moved on its own `v5.0.0` note rather than by symmetry, with the reason a skipped step can never appear in the annotation; and the handoff's *"three that fire on a push do so on this HO's own ref"* was wrong — `ci.yml` triggers on `pull_request` or `push: branches: [main]`, so a review ref cannot reach it. Stopping at v5 rather than v7 while `backlog:51`'s count is live is the right call, and flagging it keeps widening a decision.

## 1. The move

- `git ls-remote --heads origin` immediately before: `main` at `29026da`, `707-review` at `2b49162`. If either differs, stop and paste.
- Standing on `main`, the cleanup door: `git merge --ff-only 2b49162`, then `git rev-parse main` must print `2b49162…`. Then `git push origin main`, no force. Then `git push origin --delete 707-review`. Then `git ls-remote --heads origin` and `git ls-remote --tags origin` (three tags).
- Each state-changing command on its own line, stderr never suppressed; the commit list read off the remote.

## 2. The two readings `:55` has been waiting for

- **`ci.yml`'s first v5 run.** It fires on this push (workflows are not under `paths-ignore`, and code moved). Quote its id, conclusion, and **that the node20 deprecation annotation is absent** — the absence is the reading, not the green.
- **`e2e-prod`'s `smoke` job**, the Production `deployment_status` run for `2b49162`: id, conclusion, annotation absent, the resolved-group echo, and the spec lines. This is the job that structurally could not run pre-FF (HO 698), and it is the last of the four workflows to get a v5 reading.
- With both in hand, **`backlog:55` is struck** — all four workflows seen green on v5 with the annotation gone — in a one-line `docs` commit on a ref, not on `main` directly. If either run is red, it reverts per STEP 3 rather than being debugged forward.
- `npm run verify:deploy` five consecutive reads, as always.

## 3. The count

`backlog:51`'s daily count is unaffected by an action-version bump: the crawl's specs, triggers and schedule are untouched. **A red daily caused by a v5 action is a `:55` regression, not a `pageErr` reading, and does not reset the count** — re-run by dispatch and quote both. A `#418` in any daily is the other thing entirely and reopens HO 705's report path with the per-hit line.

## 4. Paste

The `ls-remote` line showing `main` at `2b49162`, the ref gone, three tags; `git rev-parse main`; the five served reads; the `ci.yml` run and the Production `smoke` run with their annotation readings; then the `:55` strike as its own ref if both are clean.

read and follow 707-ff-go — the file, not this line
