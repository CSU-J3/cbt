# HO 772: the fonts move into the repo, so no build asks Google for anything. With HO 771's FF readings, a correction, and two reads due this week

## Rulings on the paste

**HO 771's FF go is done as ruled.** `6f5aa74` and `3785c41` are exactly the go's replacements, so they're approved as landed. `main` is `3785c41`, served, its Production build cold, smoke 141 passed.

**Finding 1, the Preview that failed in `next/font/google`, is fixed here rather than watched.** I read the code that threw:
- Turbopack rewrites each font URL in Google's stylesheet into an internal import. The import's query is the URL's options as JSON, passed through `qstring` (`crates/next-core/src/next_font/google/mod.rs:488-493` at v16.3.4).
- The resolver bails unless that query parses back into exactly one entry (`:642`, your error's text).
- A font URL that carries its own `=` and `&` splits into several entries, so every face in that stylesheet fails at once. That's your 18.
- The code is unchanged on canary (16.5.0-canary.7, `:501` and `:655`), so a Next upgrade wouldn't fix it.

Why only Sans: Google serves IBM Plex Sans from a variable font (`IBMPlexSans[wdth,wght].ttf` in google/fonts' `METADATA.pb`) and IBM Plex Mono from static files. My reading, unverified because the build log doesn't print URLs, is that Google answered that build with dynamically cut `fonts.gstatic.com/l/font?kit=…&skey=…&v=…` URLs for Sans.

Either way the trigger is Google's answer. Since HO 768 every build is cold, so every build asks again. With three weeks to Election Day, a ship shouldn't depend on it. Production already serves these files from our own origin; this HO puts those same bytes in the repo, and the build fetches nothing.

**Finding 2:** the correction rides this HO's block. The route header's *(HO 768)* names the current reader and stands.

**Finding 3:** the block records both stale lines fixed, at `6f5aa74` and `3785c41`.

**Finding 4:** the block records the count as you gave it: 20 entries and 20 path strings, on 19 routes.

**How STEP 0 runs** (method.md, HO 768's rule): the claims are mine and are a check, with no HALT unless one fails or a reading falls outside its bound.

**Base:** `main` at `3785c41`. HO number: the pointer is 771 and the highest HO in commit subjects is 771, so this is 772.

## STEP 0

| # | Claim at `3785c41` | Fails if |
|---|---|---|
| 1 | `app/layout.tsx:2` imports `IBM_Plex_Mono, IBM_Plex_Sans` from `next/font/google`.<br>• `:25-30`: Sans, `subsets: ["latin"]`, weights 400/500/600, `display: "swap"`, `variable: "--font-plex-sans"`.<br>• `:54-59`: Mono, the same with 400/500/600/700 and `--font-plex-mono`.<br>• `:113` puts both variables on `<html>`. | |
| 2 | Outside `docs/` and `.claude/`, nothing else imports `next/font`. The only file naming Google's font hosts is `scripts/diagnostic/mono-features-697.ts:34-36`, a historical probe that loads Google's CSS into its own page. It isn't a build input. | another build input fetches a font |
| 3 | The two variables have two consumers: `--sans` (`app/globals.css:112`) and `--font-mono` (`:198-200`). Neither changes here. | another file reads `--font-plex-*` |
| 4 | `e2e/narrow.spec.ts:177-178`'s `FONT_STATE` checks the families by name (`"IBM Plex Mono"`, `"IBM Plex Sans"`). It's diagnostic text in a failure message, not an assertion. | it asserts |
| 5 | SKILL states the mechanism at `:1945` (*self-hosted via `next/font/google` at weights 400/500/600*) and `:2101` (the mono face, *self-hosted since HO 697*). Each edit's anchor below occurs once. | |
| 6 | `package-lock.json:3880-3881`: next 16.3.4. | |

### Two reads due this week, both SELECT-only

**Delaware** (backlog, *Delaware's 2026-09-15 primary winners are unstored…*):
- The read is dated Monday 10-12, but the visit it waited on, S-DE's Senate slice, fell on 10-06 by the line's own arithmetic. So read it now: `primary_candidates` for `primary_id IN ('house-DE-00-2026-R', 'senate-DE-2026-R')`.
- **If `senate-DE-2026-R` still has no `winner`, run `npm run reingest:primary-slate -- DE 2026-09-15` once.** That's this HO's one authorized prod write.
- Then read the same rows back. The script's header says the primaries surfaces are uncached, so there's no flush.

**The first daily ratings run** (the ratings WATCH's dated field):
- If you start after 2026-10-11 11:00Z, read the first `cron_runs` row for `/api/sync-race-ratings` at or after it.
- Otherwise it's read at the FF go.

## § 1, the fix: the faces come from the repo (`fix`)

Production already serves every face from our own origin. `next/font/google` downloads Google's files at build time and emits them under `/_next/static/media/`. So the source is Production itself: the files it serves at `3785c41`, byte for byte. Nothing new is fetched from Google, and parity is exact by construction.

**What Production serves.** These are estimates; leg A measures them:
- IBM Plex Sans: 18 web faces, 6 subsets (cyrillic-ext, cyrillic, greek, vietnamese, latin-ext, latin) × 400/500/600.
- IBM Plex Mono: 20 web faces, 5 subsets (the same without greek) × 400/500/600/700.
- All are `font-style: normal` and `font-display: swap`, each with a `unicode-range`.
- Two metric fallbacks on `local("Arial")`, one per family.
- `/` preloads the latin files.

If Production's set has another shape, HALT with leg A's table.

**The layout.** `next/font/local` takes `unicode-range` only for a whole call, through `declarations`. So one call per family carries the latin cut, the one that's preloaded, and a CSS file carries the rest.

In `app/layout.tsx`:
- `IBM_Plex_Sans` and `IBM_Plex_Mono` from `next/font/google` become two `localFont` calls from `next/font/local`. The `const` names and the variables stay.
- Each call has one `src` entry per weight: `{ path: "./fonts/ibm-plex-<sans|mono>/<file>", weight, style: "normal" }`. Where Production serves one file across weights, the entries repeat its path.
- Each call has:
  - `display: "swap"`;
  - its `variable`, unchanged;
  - `declarations: [{ prop: "unicode-range", value: "<Production's latin range, verbatim>" }]`;
  - `adjustFontFallback: false`;
  - `fallback: ['"IBM Plex Sans Subsets"', '"IBM Plex Sans Fallback"']`, or Mono's pair. The second name is Production's fallback family, whatever leg A reads it as (expected *IBM Plex Sans Fallback* and *IBM Plex Mono Fallback*), and `ibm-plex.css` uses the same.
- `preload` stays default. Every file of the call is preloaded, and the call holds only the latin cut.
- next/font requires literals in its options, so the range is written into each call.

Beside it:
- **`app/fonts/ibm-plex.css`**, imported from `app/layout.tsx` after `./globals.css`, holds:
  - every non-latin face, with Production's descriptors and in Production's order, the family renamed *IBM Plex Sans Subsets* or *IBM Plex Mono Subsets*, and `src` the vendored file;
  - the two fallback faces, verbatim from Production, named as Production names them.
- **`app/fonts/OFL.txt`:** the SIL Open Font License google/fonts ships for both families. `ofl/ibmplexsans/OFL.txt` and `ofl/ibmplexmono/OFL.txt` are byte-identical: 4,456 bytes, sha256 `7e6b2818edbd8f6a01ae80641cc8f16a51080d08fb4e532be3a0b6f74adb07da`.

So `--font-plex-sans` reads `'<latin family>', "IBM Plex Sans Subsets", "IBM Plex Sans Fallback"`, and `--sans` and `--font-mono` don't change.

**Why this order matches Production character for character:**
- Production's latin faces carry the latin range, so the first family covers exactly what they cover.
- Everything else falls to the Subsets family, whose faces keep Production's order. Where two subsets' ranges overlap, the same face answers.
- The fallback answers last, and it's Production's own, so the swap window is unchanged.
- `adjustFontFallback` is off because `next/font/local` would compute that fallback from a plain average advance, not capsize's weighted width. Turbopack's `local/font_fallback.rs` notes this as a TODO.

**File names:** `app/fonts/ibm-plex-<sans|mono>/<subset>-<weight>.woff2`, or `<subset>.woff2` where one file serves every weight of that subset. Name each subset by its range's first code point:
- U+0000: latin;
- U+0100: latin-ext;
- U+0102: vietnamese;
- U+0301: cyrillic;
- U+0370: greek;
- U+0460: cyrillic-ext.

Compare them as code points: the minifier may drop leading zeros.

**The layout's comment** gains an HO 772 paragraph:
- why the files live here;
- where each piece is;
- that the bytes are Production's at `3785c41`;
- why `adjustFontFallback` is off;
- that `next/font/google` mustn't come back.

HO 633 C1b's preload paragraph stays, because the chain is still Next's.

## `FONT_STATE` reads the family off the variable (`test`)

The latin family's name now comes from `next/font/local`. So `e2e/narrow.spec.ts:177-178` reads it off the variable instead of naming it:

```text
  mono: document.fonts.check('12px ' + getComputedStyle(document.documentElement).getPropertyValue('--font-plex-mono').split(',')[0].trim()),
  sans: document.fonts.check('12px ' + getComputedStyle(document.documentElement).getPropertyValue('--font-plex-sans').split(',')[0].trim()),
```

## Legs

`scripts/diagnostic/fonts-local-772.ts`, committed first, with two modes, `capture` and `compare`.

### Leg A, `capture`, against Production

Run it before the fix commit, once you've confirmed Production still serves `3785c41`.

- **The faces:** from `/`'s stylesheets, record every `@font-face` of the four families (the two web families and their two fallbacks), in Production's order. For each: family, weight, style, display, `unicode-range` (as written and as a code-point set), and the `src` URL.
- **The files:**
  - download every distinct `src` once, and record each file's sha256, its size and the faces it serves;
  - write the files under `app/fonts/`, and write `ibm-plex.css`;
  - print the two calls' `src` arrays and the latin range for the layout, so nothing is typed by hand.
- **The preloads:** `/`'s `<link rel="preload" as="font">` hrefs, with their sha256.
- **The specimen baseline:** open `/` in Chromium (1440×900, DPR 1, reduced motion). After `document.fonts.ready`, inject a block with one span per stack, weight and specimen: `var(--sans)` at 400/500/600 and `var(--font-mono)` at 400/500/600/700, each setting every specimen below.
  - latin: `Hamburgefonstiv 0123456789 “quotes” – — ½ ©`
  - latin-ext: `Łódź Erdoğan Babiš Ţară Őr`
  - greek: `ΔΣΩ αβγδε`
  - cyrillic: `Жизнь Москва Ёё`
  - vietnamese: `Nguyễn Việt Ơ ư`
  - outside every subset: `→ ★ ✓ ∞`

  Wait for every load the block triggers. Then record:
  - each span's width, as the full float;
  - the `document.fonts` faces that read `loaded`;
  - each font request's host;
  - a PNG of the block.

Everything goes into `docs/handoffs/772-artifacts/` as the baseline.

### Leg B, the build

**B1:**
- `npm run build` passes.
- The CSS under `.next/static/` holds the 38 web faces and the 2 fallbacks, with Production's descriptors.
- Nothing under `.next/static/` names `fonts.googleapis.com` or `fonts.gstatic.com`.
- `git grep -n "next/font/google" -- app components lib` finds nothing.
- The red: at `3785c41` that grep finds `app/layout.tsx:2`.

**B2, offline:** build with `HTTPS_PROXY` and `HTTP_PROXY` pointed at a closed local port, for the build process only.
- The red: `3785c41`, in a worktree, fails in `next/font/google`.
- The green: the fix commit passes.
- If `3785c41` passes anyway, the proxy wasn't honored and B2 is void. If the fix commit fails for some other network reason, record it. Either way B1 stands as the proof.

### Leg C, `compare`, the review push's Preview against Production

Run it after the push, once the Preview is READY.

- **C1, faces:** the 38 web faces pair one to one by family role, weight, style and code-point set. Each pair has the same display, and its served bytes have the same sha256. The two fallbacks are equal in every descriptor.
- **C2, preloads:** the same set of preloaded files, by sha256.
- **C3, the stack:** the computed `--font-plex-sans` and `--font-plex-mono` on `<html>` read the latin family, then Subsets, then Fallback, in that order.
- **C4, the specimen:**
  - every width is equal to the bit;
  - the loaded faces pair one to one;
  - the PNGs are pixel-identical;
  - every font request stays on the deployment's own host.

**The controls:**
- Production read against itself is equal in every cell, so the specimen is deterministic.
- On the Preview, a style that drops the Subsets family from both variables must make unequal every cell whose baseline loaded a non-latin face. If one stays equal, the specimen can't see a missing subset, so HALT.

**Also read on the Preview:**
- **The CSS WATCH's reading:** the build log has no *Restored build cache*, and the stylesheet `/` links carries *IBM Plex Sans Subsets*. The WATCH closes on Production's reading, at the FF go.
- **`narrow-preview`.**
- **Screenshots, for the eye, not a gate:** `/` and `/electoral` at 1440, Production and Preview.

**A mismatch:**
- One you can trace to your own copy: fix it, push again (`--force-with-lease`, the ref only), and re-run.
- One that would need a descriptor to differ from Production's: HALT with the table.

## Docs

**roadmap:** the HO 772 block. It opens with HO 771's FF go as taken (your paste):
- the two fixes;
- the FF;
- `verify:deploy`;
- the cold Production build;
- `e2e-prod`;
- the failed Preview.

Then it carries:
- **The correction:** HO 771's block (`docs/roadmap.md:5292`) says MOVED has read `rating_history` since HO 768. It has since HO 272 (`d777c1b`, 2026-06-18, the v2 races-tab MOVES badge), and HO 768 rebuilt the reader around the guard.
- **Fixed:** the two stale lines HO 771's block left (`:5291-5293`), at `6f5aa74` and `3785c41`.
- **The count:** `vercel.json` has 20 entries and 20 path strings, on 19 routes. `/api/cron/markets?source=fmp` shares markets' route.

Then STEP 0 and its two reads, § 1, and legs A and B. Leg C and the FF go open the next block.

**backlog:**
- **Delaware:** the line records the read, and if the reingest ran, the reingest and its read-back. Its dated read is done, and it stays open on its class close.
- **If the 10-11 run was read:** record it in the ratings WATCH and in Sabato's line. If it reads `success` with `stats.raters.sabato` ok in both legs, it closes both. If it doesn't, record its `error_message`.
- Reconcile, with the control at 0.

**oddities**, appended verbatim:

```text
## A Preview built cold failed in `next/font/google` on the commit Production had built two minutes earlier: Turbopack can't carry a Google font URL that has its own query string (HO 772, Oct 2026)

On 2026-10-10 Production built `3785c41` cold in iad1 at 21:11-21:12Z. The Preview of the same commit, cold in the same region, failed at 21:13Z after 10s with 18 errors, one per `src: url(…)` in IBM Plex Sans's generated stylesheet, each reading *next/font/google queries have exactly one entry*. IBM Plex Mono, in the same build, raised none. Turbopack rewrites each font URL in Google's stylesheet into an internal import whose query is the URL's options as JSON, passed through `qstring` (`crates/next-core/src/next_font/google/mod.rs:488-493` at v16.3.4), and the resolver bails unless that query parses back into one entry (`:642`). A URL that carries its own `=` and `&` splits into several, so every face in the stylesheet fails together. Canary had the same code on 2026-10-10. Google serves IBM Plex Sans from a variable font and IBM Plex Mono from static files, which fits only Sans failing; that Google answered with dynamically cut `fonts.gstatic.com/l/font?kit=…` URLs is an inference, since the build log doesn't print URLs. Every build has been cold since HO 768, so every build asked Google again, and Google's answer decided whether a ship landed. HO 772 moved both faces into the repo, Production's own bytes, and no build asks Google for anything now.
```

**SKILL**, in its own `docs(skill)` commit, last. Quote the diff in the paste for approval.

Edit 1, `:1945`:

```text
OLD: **The sans face is IBM Plex Sans, self-hosted via `next/font/google` at weights 400/500/600 — HO 633,
NEW: **The sans face is IBM Plex Sans, self-hosted at weights 400/500/600, from files in `app/fonts/` since HO 772 (`next/font/google` until then) — HO 633,
```

Edit 2, `:2101`: after *the old stack behind it is the fallback, not the face, exactly as on the sans side.* insert a space and:

```text
**Both faces are files in the repo since HO 772,** so the build fetches no font: the latin cut through `next/font/local` in `app/layout.tsx`, which keeps Next's preload, and the other subsets and both metric fallbacks in `app/fonts/ibm-plex.css`, all of them Production's bytes and descriptors as served at `3785c41`. **Don't bring back `next/font/google`:** Turbopack can't carry a Google font URL that has its own query string, and one such answer failed a Preview build (HO 772).
```

## Commits

On `772-review` from `main`, kinds unmixed:
- `diag`: the script;
- `fix`: § 1, `app/fonts/` and `app/layout.tsx`;
- `test`: `FONT_STATE`;
- `docs`;
- `docs(skill)`, alone and last.

No migration. The one prod write is the Delaware reingest, and only if its read calls for it.

## Paste back once, after leg C and `narrow-preview`

- STEP 0 and both reads;
- leg A's table: faces, distinct files, preloads, fallback descriptors;
- legs B and C, with their reds and controls;
- the Preview's cache line and stylesheet reading;
- `narrow-preview`;
- `--stat` per commit, and `--numstat` for docs with every deletion explained;
- the SKILL diff;
- `ls-remote` with `772-review`'s SHA;
- the reconcile;
- a last cheap-gate run.

Build through to the review push without stopping.
