# HO 666 — strip `BillRowList`'s dead `compact` passthrough, delete `BillExpandedPanel`, relocate the panel types (backlog :75, the entry HO 664 opened)

**Read this file in full before executing anything. Execute in order. HALT conditions are hard stops — report and wait, do not improvise past them. Two HALTs: the STEP 0 closure table, and the pre-land review ref. Nothing lands on `main` before the second is approved.**

Base: `main` at `5d7134f` or later. Clone fresh; verify HEAD before starting (concurrent-session rules per `docs/method.md` § Session start). Number derived per method: max(roadmap pointer 665, highest commit-subject HO 665) + 1. Environment: code edit + `npm run typecheck` + `npm run build` (secretless, CI parity — SKILL § Continuous integration), plus one local `npm run start` confirmation that renders six routes (`.env` `TURSO_DATABASE_URL`/`TURSO_AUTH_TOKEN`). Either machine; no WSL/Docker. **Port discipline per SKILL § Process cleanup; the bind check in STEP 3 is mandated (HO 664 oddity → HO 665 procedure). Typecheck immediately after a route/component deletion may go red on stale `.next/types` until a build regenerates them — the HO 665 oddity; run the build before reading typecheck as a code failure.**

## THE FOOTGUN, FIRST

Two components differ by two letters and are opposites:

- **`components/BillExpandPanel.tsx`** — LIVE. HO 317's "ONE shared expanded bill panel + ONE shared stage bar," rendered on `/bills` and the dashboard. It has its **own** HO 298 stage bar and imports **only types** from the dead file. **Nothing in this HO changes its behavior.**
- **`components/BillExpandedPanel.tsx`** — the target. 444 lines, client, HO 191's pipeline-only panel. Its **sole render site** is `BillRowList.tsx:99`, inside the `compact` branch whose last caller died at HO 664.

Every grep, every edit, every SKILL claim in this HO must keep the two names straight. When in doubt, quote the full filename.

## Context (why now)

Backlog `:75` (opened HO 664, the created-by-the-strip entry) is the head of QUEUED. Its own text pins the shape: `BillRowList` is live on six routes (`/bills` · `/changes` · `/stale` · `/president` · `/watchlist` · `/members/[bioguideId]`), so stripping the prop threaded through it is its own change behind its own gates (HO 507); the `compact` branch is the **last consumer of `components/BillExpandedPanel.tsx`**; and **the two `compact`s are different things** — `BillRow`'s OWN `compact` prop stays LIVE and link-only on `SearchResultsBills.tsx:24` · `app/patterns/page.tsx:116` · `app/committee/[systemCode]/page.tsx:453`, none of which route through `BillRowList`. The close: **strip the passthrough — and decide `BillExpandedPanel`'s fate with it — behind gates on the six live routes, or record a keep reason.**

Recon at `5d7134f` (STEP 0 re-derives all of it):

- The passthrough inside `BillRowList.tsx`: prop `:41`/`:51`, the effect guard `:65`/`:79` (`if (compact || …)` — the lazy panel fetch skip), the `compact={compact}` threading to `BillRow` `:90`, and the ternary `:98–105` (`compact ? <BillExpandedPanel …> : <BillExpandPanel …>`). The file's header (`:17–24`) already records HO 664's zero-callers finding and this filing — it becomes the record of the strip.
- `BillExpandedPanel.tsx` exports the component **plus four types**: `PanelCommittee` `:26`, `PanelNews` `:35`, `PanelMeeting` `:48`, `PanelData` `:61` — the `/api/bill/[id]/panel` payload shape. **Live type consumers:** `useSingleOpenPanel.ts:17` (`PanelData`), `BillRowList.tsx:30` (`PanelData`), `BillExpandPanel.tsx:38` (`PanelData`, `PanelMeeting`). The types must survive the file's deletion.
- **Ruled here (non-fork, per method § Roles): the four types relocate verbatim to a new `components/bill-panel-types.ts`** — byte-identical type bodies, a short header recording provenance (HO 191/317 origin, moved at HO 666 when `BillExpandedPanel` was deleted), three importers retargeted. The alternative (folding them into `BillExpandPanel.tsx`) was considered and rejected to keep the live shared component untouched and to end the name-collision class outright. The table may argue against this only with evidence, not preference.
- The local `StagePipeline` renderer (`:287` region) and the `stage-pipeline*` classes render **nowhere else** — the live panel's stage bar is its own HO 298 machinery. The `--stage-*` CSS **variables** are shared and LIVE (both panels' color sources); only `stage-pipeline*` **selectors** are candidates.
- `.bill-expanded-link` is **LIVE** outside the dead file (`BillRow.tsx:120`, `SponsorHoverName.tsx:79` default param) — it stays, and it is the in-family positive control for the CSS excision.
- globals.css carries 52 `bill-expanded|stage-pipeline` matching lines across roughly `:2097–:2481` — the panel block and the pipeline block, plus the `.bill-expanded-link` rules that stay.
- Dangling-comment set found so far: `BillRow.tsx:69` ("IS given `onToggle` (dashboard ACTIVITY via `<BillRowList compact />`) now" — names the dead path as live), `SponsorHoverName.tsx:5` ("shared by the expanded panel (BillExpandedPanel) and the collapsed feed row"), `NewThisWeek.tsx:14` (mentions the dead arm — classify, likely RECORD already from 664), `useSingleOpenPanel.ts` (import retarget + any prose). `ActivityTicker.tsx:28` is already RECORD ("are gone").
- SKILL: `:1974` head claim "**BillExpandedPanel is now the COMPACT path only**" (665 RECORD'd only its parenthetical) and `:1975` — **the client-islands inventory entry for `components/BillExpandedPanel.tsx` (client), HO 191 redesign**. The deletion is a genuine islands-membership change, so **the `:2087` changelog append is CORRECT this time** — the exact inverse of HO 665's B ruling, same criterion (island membership, not commit kind). Say so in the roadmap block.
- No per-render read is removed this time — compact mode self-fetched nothing (`:63`). The win is ~460+ dead lines of component + the CSS block, stated honestly in the close note.
- e2e: one comment (`fit-finish.spec.ts:831`, member-hub Bills tab = `BillRowList` expandable rows) — non-compact behavior, unchanged; record as unaffected, do not run e2e.

## STEP 0 — enumerate; closure table; HALT

Line numbers here are as of `5d7134f` — re-derive every one at your HEAD (HO 652). **Controls first, before any zero is trusted** (HO 664/665: six instrument failures across two HOs, zero code failures). Bare-class-name grep form for CSS (the HO 664 correction). Produce the closure table (candidate · verdict · evidence `file:line` · destination) covering at least:

1. **The passthrough plumbing in `BillRowList.tsx`** — prop + type, effect guard clauses, the `compact={compact}` threading, the ternary collapsing to the `BillExpandPanel` arm unconditionally, the header comment rewritten to record the strip (the HO 664 paragraph gains its close). Verify `watchedIds`/`nowMs`/`daysSinceMode`/`showMomentum` and the non-compact accordion + panel fetch (`:65–79`, `fetch('/api/bill/…/panel')` `:67`) are untouched.
2. **`components/BillExpandedPanel.tsx` — DELETE (444 lines)**, after: (a) component render sites repo-wide = `BillRowList.tsx:99` alone, positive control first (`BillExpandPanel` — no "ed" — must read its own live sites: `BillRowList` non-compact arm + wherever the dashboard mounts it); (b) per-import survivor check for everything the dead file imports (the HO 665 form — name survivors `file:line`; a symbol with zero survivors is a table finding, filed not chased); (c) the four types' relocation target created and importers retargeted.
3. **`components/bill-panel-types.ts` — CREATE** per the ruling above. Types byte-identical; `git show`-able provenance header; three importers (`useSingleOpenPanel.ts`, `BillRowList.tsx`, `BillExpandPanel.tsx`) retargeted and nothing else about them touched.
4. **CSS, per-selector, never prefix.** In-family positive control first: `.bill-expanded-link` must read >0 in TSX (`BillRow.tsx:120`, `SponsorHoverName.tsx:79`) before any zero is trusted. Then per-selector over `app/ components/ lib/` (`*.ts`/`*.tsx`), bare-name form: every `bill-expanded-*` class the dead file rendered (`panel`, `--compact`, `summary`, `body`, `col`, `col-left`, `col-right`, `meta-grid`, `meta-row`, `--stacked`, `meta-label`, `meta-value`, `meta-sub`, `actions`, `action-chip`, `--soft` — enumerate from the file, don't inherit this list) and every `stage-pipeline*` selector. **KEEP:** `.bill-expanded-link` rules; every `--stage-*` variable (live via the HO 298 stage bar — variables are not selectors). Excise dead rules with their comments edited rather than orphaned; mixed comment blocks get the HO 664 §5/E treatment (the dead half dies, the live half stays).
5. **Dangling comments** — `BillRow.tsx:69` EDIT (the `<BillRowList compact />` onToggle claim → RECORD); `SponsorHoverName.tsx:5` EDIT (the live sharer is `BillExpandPanel` post-delete — reconcile without touching behavior); `NewThisWeek.tsx:14` classify per site; `useSingleOpenPanel.ts` import + prose reconcile; anything the fresh grep adds.
6. **SKILL inventory — fresh greps, classify every hit.** `grep -n "BillExpandedPanel" .claude/skills/cbt/SKILL.md` (expect `:1974`, `:1975` at `5d7134f`; re-derive) plus `compact` claims touching `BillRowList` (`:1930`, `:1972`, `:2068` were RECORD-phrased at 664 — the passthrough clauses now gain the strip fact). Expected edits: `:1974` head claim → RECORD (component deleted at HO 666); `:1975` islands entry → RECORD with the deletion; `:1930`/`:1972`/`:2068` passthrough clauses updated minimally; **`:2087` changelog APPEND** — the islands set changed, the 665 criterion cuts the other way here, cite it.
7. **Out-of-scope records, named so they aren't absorbed:** `BillRow`'s own `compact` prop and its three surfaces; `BillExpandPanel.tsx` beyond the one import line; the e2e comment; `docs/` prose.

**HALT.** Paste the table back. If anything reads other than expected — a second `BillExpandedPanel` render site, a type consumer beyond the three, a `stage-pipeline` hit outside the dead file, a `.bill-expanded-link` control failure — that row's verdict changes and the table says so; do not force it. If the table finds a genuine keep reason for the component, that is the entry's alternative close: argue it, don't strip.

## STEP 1 — the chore commit (after the table is approved)

`git checkout -b 666-review-local` first (`main` stays at `origin/main` until approval). One commit, one kind:

`chore(HO 666): strip BillRowList's dead compact passthrough, delete BillExpandedPanel, relocate the panel types`

Expected shape: `BillExpandedPanel.tsx` −444; `bill-panel-types.ts` new (+~60–80); `BillRowList.tsx` strip + header record; three import retargets; the comment reconciles; the CSS excision per the approved table. Nothing else rides.

## STEP 2 — gates

- `npm run build` then `npm run typecheck`, both green — build first, per the stale-`.next/types` oddity; if typecheck went red before the build, re-run after and report both readings.
- Source greps, bare-name form, controls first: `BillExpandedPanel` 0 live references across `app/ components/ lib/ e2e/ scripts/` (RECORD comments reported as "0 live, N RECORD" — the 664/665 form); `compact` inside `BillRowList.tsx` 0; every excised selector 0 in TSX; control `bill-expanded-link` >0.
- **Built-CSS check** (`.next/static/css/*.css` post-build): every excised selector 0; controls `bill-expanded-link` >0 and one live `BillExpandPanel` selector >0 (name it); `stage-pipeline` 0 while `--stage-` remains >0.

## STEP 3 — runtime confirmation (bind check mandated, six routes)

1. `npm run start` on a private port (3100+, `-p`), PID captured; **verify the started PID owns the port** (`lsof -i :<port>` / `ss -ltnp`) before any curl is trusted.
2. All six routes read 200 with a route-specific content assertion each (not bare 200s): `/bills`, `/changes`, `/stale`, `/president`, `/watchlist`, `/members/<real bioguideId>` — pick the member id from the DB or the `/members` HTML, and name each assertion string in the paste.
3. The live expand path: `curl /api/bill/<real bill id>/panel` reads 200 with a JSON body (real id from the DB or a page — the HO 665 real-id rule: a made-up id proves nothing).
4. Kill by PID, port-scoped; foreign PIDs left alone.

## STEP 4 — docs commit (`docs: HO 666 — …`)

4.1 **`docs/backlog.md`** — strike `:75` with the close note: stripped + deleted at <chore SHA>; the types relocated to `bill-panel-types.ts` with the three importers named; the ternary collapsed to the shared `BillExpandPanel` arm; the CSS excision sized (N selectors, ~M lines) with `.bill-expanded-link` kept live and the `--stage-*` vars untouched; the six-route gate green with the panel-API probe; **no per-render read removed — compact self-fetched nothing** (say it; the win is the dead code); `BillRow`'s own compact untouched on its three surfaces. Cite the SKILL edits by description, not SHA (the HO 665 flag-1 convention). Strike = `~~…~~` + close note; do not delete the line.
4.2 **`docs/roadmap.md`** — one `Also (HO 666)` block, append-only, pointer 666: the strip's numbers, the types-relocation ruling and why (name-collision ended), the `:2087` inversion (the 665 criterion applied and cutting the other way — islands membership DID change here), the control set used, and the oddities disposition. No retro-edits.
4.3 **`docs/oddities.md`** — only if something odd emerged; nothing odd → no entry, say so in the roadmap block.

## STEP 5 — SKILL commit (`docs(skill): HO 666 — …`), self-mod guarded

Minimal edits per the approved table: `:1974` head claim → RECORD; `:1975` islands entry → RECORD (deleted HO 666, types live on in `bill-panel-types.ts`); `:1930`/`:1972`/`:2068` passthrough clauses gain the strip; **`:2087` changelog append** (the islands membership change). Touch nothing else; the `/` entry stays flagged stale-as-enumeration (HO 646).

## HALT — the review ref; nothing lands before approval

Push `git push origin HEAD:refs/heads/666-review` (`--force-with-lease` on the ref only; `main` only ever fast-forwards). Paste back: executed table deltas, `git show --stat` of all three commits, STEP 2/3 outputs **including the bind-check evidence, all six route assertions, and the real-id panel probe**, the backlog numstat with every deletion explained (`grep -c '^-[^-]'` is NOT a deletion count — HO 643), and the docs + SKILL diffs. Remote claims via `git ls-remote` only. One swallowed block → gitignored file, never a second paste (method.md § Relay). **The SKILL diff needs explicit approval.** After approval: `git push origin HEAD:main` (no force), delete the ref, verify with `git ls-remote --heads origin`.

## Verification gates (run before the HALT; outputs in the paste)

- STEP 2/3 all green; working tree clean after the three commits.
- Backlog numstat: one in-place strike expected (1 deletion + additions; struck text survives inside `~~…~~`), every deletion explained.
- Anchored greps (HO 637): `grep -cE '^\*\*Also \(HO 666' docs/roadmap.md` = 1; `grep -row "BillExpandedPanel" app components lib e2e scripts` = 0 live (RECORDs reported as such); `grep -rn "bill-panel-types" components` shows exactly the three importers + the module; backlog `:75` struck, not gone.
- Push only after re-checking HEAD ancestry (`git ls-remote --heads origin`).

## Out of scope — named so it isn't absorbed

- **`BillExpandPanel.tsx`** (no "ed" — the live panel) beyond retargeting its one type-import line: no behavior, no classes, no prose beyond that line's own comment if any.
- **`BillRow`'s own `compact` prop** and its three surfaces (`SearchResultsBills` / `/patterns` / `/committee/[systemCode]`) — live, untouched.
- `/api/bill/[id]/panel` and everything under `app/api/`.
- The bare `<MarketsTape />` branch entry (backlog `:416`), the `.pdc*` excision entry, the `isSettled` parent entry, the `/changes` P2 latency — all their own HOs.
- The HO 661 settle-window WATCHes (Aug 20 / Sep 3), the ~Sep 1 per-query ledger glance, the M3 re-arm (post-Sep-15) — none due.
- The `CRON_ROUTES` stale schedule string (rides the next `lib/cron-health.ts` touch).
- e2e execution (the one comment is recorded unaffected; the member-hub test exercises the non-compact path this HO preserves).
