# HO 697 — review reply. Ship the tag and the font; hold the clock. The decision rule was mine and it could not fail.

Read on the ref at `e9e6beb`: five commits, SKILL +7/−3, block, strikes, the matrix as tabulated. The work is right and the honesty in it is right; the ruling the matrix was run under was not, and that is the architect's error to own before anything moves.

## 1. The rule could not fail at the rates in question

*An arm is implicated when its minimum across three runs exceeds A's maximum* needs three non-zero crawls in a row. At a true rate of 0.5 fires per crawl the chance of a single crawl reading zero is about 0.61, so the rule would have flagged that rate about **6% of the time**; at one fire per crawl, about 25%. A gate that passes a real regression nineteen times in twenty is the thing method § Gates says is not a gate, and I wrote it. The block records that in those words, with the arithmetic.

## 2. The reading that counts is pooled, and it implicates the clock arms

Every crawl in this HO, by whether the clock was mounted: **without it, 0 fires in 8 crawls** (`main` 0 · 0 before the matrix, A 0 · 0 · 0, C 0 · 0 · 0); **with it, 9 fires in 8 crawls** (pre-fix D 3 · 3, post-fix B 1 · 0 · 0, D 2 · 0 · 0). Pooling pre- and post-fix is legitimate because the shape fix does not touch hydration, as its own comment now says. Nine fires splitting 9 : 0 between two arms of equal rate happens about once in 250. Post-fix alone is weak (3 : 0, one in four); the pre-fix runs are what make it a reading. So: **the clock raises the local #418 rate, mechanism unknown; the font does not; the tag does not** (C and the tag-bearing halves of B and D carry no signal of their own). That is §4's *C1 implicated, C2 clear* branch, and it applies to the clock alone because the tag is static markup in the same commit.

Corey can override this in one word: **"ship the clock."** It is his ruled feature. The cost, stated for that word: the prod crawl's daily reds rise by an unknown factor, every #418 recovery client-renders the affected boundary on every route the masthead sits on, and the mechanism goes to production unfound. My recommendation is the hold, because the hold costs one HO and the amplifier is exactly what the `:50` hunt has lacked since July.

## 3. The split

- `65f866c` becomes two commits and a held tree. **`feat(HO 697)` — the `IN BETA` tag on every masthead:** `.beta-tag` global, its reduced-motion block, the module move, `page.tsx`, the tag mount in both mastheads at the placement Corey ruled (*"as built"*, 2026-09-06). **`fix(HO 697)` — `WelcomeClock` renders one shape in both states:** the instrument change with its comment as written, minus the *three render sites* paragraph, which is no longer true; the rail is the one site. **The clock mount in both mastheads comes off the ref** and lives at two remote tags: `ho697-prefix-clock` (`40c3397`, the 3-per-crawl amplifier) and `ho697-clock` (the post-fix mount, `65f866c` as it stands). Push both; the ledger cites them by name.
- `88506f7` (the font) unchanged, rebased. The probes commit unchanged; `chrome-shots-697.ts`'s header gains one line saying the clock arm it measured is held.
- **The matrix runner is restored and tracked.** It produced every number in the block and was deleted from `scratch/` under a rule that says the opposite. `scripts/diagnostic/pageerr-matrix-697.ts`, with its arm table and control checks; if it cannot be restored byte-for-byte, it is rewritten to the same behaviour and the header says so. HO 698 runs it.

## 4. SKILL, rewritten where the split makes it false (own commit, slot reopens)

The typography and `--font-mono` paragraphs stand. The `/welcome` RECORD sentence *"took them to every masthead"* becomes *took the tag to every masthead; the clock stays page-local, held at HO 697 (see the `:50` entry)*. The new masthead paragraph keeps the tag and Corey's placement ruling, and its clock clause becomes: *the clock's masthead mount was built, measured and HELD — 9 fires in 8 clock-bearing crawls against 0 in 8 without, mechanism unknown; the mount is preserved at `ho697-clock` / `ho697-prefix-clock` for HO 698.* The `WelcomeClock` paragraph drops *THREE render sites* and keeps the mismatch-safe-says-nothing-about-timing sentence and the MT ruling.

## 5. Docs

Block: the matrix in full, §1's power arithmetic as the architect's error, §2's pooled reading and its odds, the hold and Corey's standing override, the two tags, and the sentence that this is the first reproducible amplifier the `:50` class has had. `backlog:135`: **tag half struck** with provenance; **clock half rewritten** as live, owner Code, carrying the matrix, the tags and *close: HO 698 names the mechanism, or the owner ships it knowing the rate*. `backlog:137` struck as it is. **`backlog:50` gains an annotation, dated:** the clock arm is a local amplifier at 9 in 8 versus 0 in 8; the fire-time snapshot this entry already named as its successor is HO 698, with `ho697-prefix-clock` as its live test case. The oddity stands.

## 6. Gates for the rebuilt ref

Everything as before, plus one crawl matrix leg that can now fail: **three local crawls on the rebuilt tip (tag + fix + font, no clock mount) reading 0 · 0 · 0**, so the shipped tree is measured against the same instrument that held the clock rather than assumed clean by subtraction. Fresh `design-citations` run on the tip. Captures re-taken on `/` and `/bills` at 1440 and 430 without the clock (the sync line is shorter; the tag placement is unchanged).

## 7. Then

Force-with-lease the rebuilt ref, push the two tags, `git ls-remote --heads --tags`. Paste the SHAs, the three crawl readings, the SKILL diff as a gitignored file, the tags on the remote. FF go follows the read.

read and follow 697 — review reply, hold the clock
