# HO 720 — STEP 0 ruling (architect, 2026-09-13). Ten rows accepted, the register disposition stands, five flags ruled, two new lines filed and one one-liner. Go, docs-only.

The crawl did what it was for: the identity the handoff expected was wrong in three places and the table says exactly where. Nothing here is a fork for Corey; the one setting that matters (the pin) he ruled at HO 690 and row 2 confirms the mock says so in its own words. Two of my estimates were wrong in shape, not size (rows 6 and 8), and the ruling records that.

## 1. Line (x) — one class line, two routes, two rows

Accepted as recommended. One line, `div.week-sentences-row`, carrying **2 rows on `/` and `/?stage=committee`**, the StageFunnel (1) form. The row is the same component at the same 995px on both routes, and two lines would price one gap twice. (iv′) counts **2** for the class.

## 2. `/welcome` M1b 2 — filed, not fixed, and the filing names the ruling record as the decider

Its own FIT & FINISH line, owner Code, its own HO: `div.landing-module__…__rail` **1857px** and `__bottom` **1593px**, interior, at 2560, crawl SHA `1cc99b8`, introduced somewhere in the HO 670 board rebuild or the HO 697–699 landing CSS touches (both postdate the HO 634 crawl; the line says *between*, not *which*). The filing carries both readings you named, and a third: **the ruling record decides the disposition before any fix is proposed**, exactly as § 04 decided (x). HO 670's board was ruled off `docs/design/welcome-formats-mock.html` and the HO 670 review reply; if the mock draws the rail as brand-left / actions-right, the bars are residue-by-ruling and join the register priced; if it does not, they are C1 under the rule at SKILL `:1989`. The container-cut reading (children ≤ 60px, so text-scale chrome bars are exactly what M1b was built to see) is the third sentence. Two-way close, the `:552` form.

In (iv′) the `/welcome` term is **filed, not registered**, named as such. That is what balances the identity today: **12 = 4 + 2 + 1 + 1 + 2 + 2**, every term named, the last one carried by a backlog line rather than a register line. HO 634's own form allowed *with-up-to-N-unexplained*; this is stricter, because the two are not unexplained, they are filed.

## 3. `/vote` (2) is a `data-col-flow` candidate — filed as its own line, and the leak line is the pressure

Accepted. Marking `VotePositionList.tsx:93`'s `ul.columns-[240px]` is a product edit with its own applied curve and its own registry entry (10), so it is its own HO, not a rider on a docs HO. File it in OPEN LOOPS, owner Code: the leak line reads **unmarked col-flow 2** on `/vote` every crawl until the marking lands or is declined; register (2)'s own text (*the ragged fill of the final column*) already describes column flow; the close is the marking HO in (9)'s form, after which `/vote` leaves the residue register by reading (M1 0 · M1c 2), or a ruling that keeps it residue with the reason written down. (iv′) cites the `/vote` term as **2, moved 132 → 149 in px, and reading on the unmarked col-flow leak line**.

This is the first time the leak line has named a registered residue. Say so in the roadmap block; it is the instrument's first catch.

## 4. Moved terms — both numbers, no causes

Accepted as proposed. (iv′) states each term's HO 634 reading and its `1cc99b8` reading — `/members` **9 → 4** (knee rows 7 → 2, headers 230 → 217px), `/vote` **2 at 132 → 2 at 149**, `/lobbying` **3 → 1**, header only, inside its (ii) bound of 1–3, `/trades` **1 at 196 → 1 at 188** — and attributes nothing. Register lines (1)–(4) are not edited; a term moving is what (iv′) exists to record. The HO 690 resize and the type ladder are named as *between the crawls*, untested, in one clause.

## 5. Line (x)'s curve is not monotonic — say it

Accepted; the estimates were mine and wrong in shape. The curve reads **2560 → 995 (row 1348) · 1440 → 453 (row 732) · 1100 → 750 (row 1028)**, and the line says why the 1100 reading exceeds the 1440 one: the dashboard grid collapses to one column and the row inherits the full width. The price beside it, from rows 7 and 8: variant A reads **8px** at both widths and shrinks the whole-row hit target **1204 → 217px (−82%) at 2560, 617 → 172px (−72%) at 1440**; variant B reads **492px** at 2560 and changes nothing at 1440 (the row is already under 88ch), so it cannot reach the threshold and is recorded as such, not proposed.

## 6. One more one-liner, so nothing is left in chat

`/electoral` **M2 2**, `races-hero-cell.odds-only`, slack **52px**, at `1cc99b8`. Outside this HO's M1 scope, but the rule is that a finding caught in relay is filed. One WATCH line in FIT & FINISH: route, class, px, SHA, and a close that is either a reading under the M2 threshold or a written reason it stands. Nothing more.

## Amendments to the handoff, collected

- STEP 1 lands: line (x) as § 1 · (iv′) as § 2 and § 4, balanced with the `/welcome` term named as filed · the `/welcome` line (§ 2) · the `/vote` line (§ 3) · the M2 one-liner (§ 6) · `:552` struck on (x).
- The roadmap block records the leak line's first catch (§ 3) and the non-monotonic curve (§ 5).
- STEP 2 unchanged: SKILL `:1690`, one clause, read against the tree first.
- No product code. The branch at the end of the handoff does not apply; no letter was volunteered.
- Anchors as you re-derived them (`:3348`, `:2013`) stand.

Go: STEP 1, then STEP 2, review ref, SKILL approved alone, FF.
