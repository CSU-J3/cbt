# HO 768: STEP 0 ruling. The guard's run is the first after the last history tick, not a run 24 hours back; re-read M1, then build through to the review push without stopping

The HALT was the rule working: M1 sat outside its bound, and the table you pasted is exactly what it needed. Everything else in STEP 0 stands as you read it, including the payload's per-chamber stats one level deeper than claim 8 showed (`$.payload.chambers.<C>…` and, before HO 744, `$.payload.stats…`, per `lib/cron-log.ts:165`) and the House tab at gid `1984730710`, so SKILL edit 6 keeps *its two tab ids*.

## The rule for item 5

Not the 24-hour floor. It fixes 09-21, but it still lets a re-run made a day or more after a catch-up vouch for that catch-up, which is the weakness you named. The run that matters is the first one that could have written the move, so pin S to that:

- **P** is the latest `/api/cron/rating-history` run with status `success` that started before day T. The move is fresh only if P started within 8 days before T. This is unchanged.
- **S** is the **earliest** `/api/sync-race-ratings` run with the chamber's leg ok that started after P and before the end of day T. P's tick would have logged any change written before it, so S is the first reading that could carry the move.
- **S'** is the latest leg-ok run that started before S. The move is fresh only if S and S' both exist and S − S' ≤ 8 days.
- Leg ok, the horizon rule and the fallback to the newest passing move are as § 5 has them, with the payload paths you found.

On your table, it gives:

| Batch | P | S | S' | S − S' | Reads |
|---|---|---|---|---|---|
| 09-21 House | the 09-20 tick | #18881 (09-20 23:35Z) | #14326 (09-02) | ~18.4 d | not fresh |
| 09-23 House | the 09-22 tick | the 09-23 11:00Z run | #18897 | ~2.4 d | fresh |
| 09-24 Senate | the 09-23 tick | the first two-leg run, or none after P | none | | not fresh |
| 09-30 | the 09-29 tick | the 09-30 11:00Z run | 09-23 or 09-24 | ≤ 7 d | fresh |

#18897 is now just a run inside the window. The residual you named fails too: a re-run a day or more after a catch-up sits after S, not at it. **Re-read M1 with this rule.** If the four read as the table says, build on without stopping; if one doesn't, HALT with its rows, as before. The bound stays 8 days. That's a weekly cadence plus a day, so a missed week (14 days) reads not fresh, and should.

**SKILL edit 3's NEW text** becomes this, verbatim (the OLD string is unchanged):

```text
NEW: and a long window would print those as recent. **Since HO 768 a guard holds it by itself** (`lib/move-freshness.ts`, inside `getRecentRaceMoves`, so the dashboard's MOVED reads it too). A move logged on day T counts only when the last rating-history tick before T succeeded within 8 days of it, and the first ratings run after that tick with the move's chamber leg ok (a `success` row in `cron_runs` whose leg scraped rows) came within 8 days of the leg-ok run before it. Pinning that run to the first after the tick keeps a same-night re-run from vouching for a catch-up (HO 742's two runs, 68 minutes apart on 09-20). A race whose newest move fails shows its newest move that passes, and a move older than either route's first `cron_runs` row passes, with nothing to read.
```

Leg E's planted cases gain two:
- a re-run 68 minutes after a post-gap run: not fresh;
- a re-run 30 hours after a post-gap run, with the history tick between them failing: not fresh.

## The 10-07 failure

**File it**, its own OPEN LOOPS line. Lead with #23114's error text, both chambers, at the bpwidget.net fetch, and say whether any earlier run failed the same way (`cron_runs`, `SELECT`). Owner Code, medium. It's a WATCH on the 10-14 11:00Z run: close on that run's `success` with both legs scraping, or on a second failure, which makes it a retry-or-source question. *Reads if never done:* ratings stop moving on `/electoral` with nothing on the page saying so. OPEN LOOPS now goes 68 → 64.

**One manual run now**, so the general window isn't reading ratings nine days old. Send one `POST /api/sync-race-ratings` with `$CRON_SECRET` by env name, after M1's re-read, and paste the `cron_runs` row. If it fails at the same fetch, don't retry: add the reading to the new line and go on. If it succeeds, the next rating-history tick logs its moves, and under the guard they read not fresh (S − S' is about nine days back to 09-30). That's the guard doing its job on a real catch-up; note it in the block.

Everything else in HO 768 stands as written. One paste-back at the review ref.
