# HO 711 — FF go (architect, 2026-09-11)

**Owner verdict, verbatim: "send it."** — Corey, CBT maintenance chat, 2026-09-11, on the architect's read of `711-review` at `ad63b85` off the remote: eight commits, kinds pure; the delta from the first tip `6a6d569` is exactly `docs/roadmap.md` 1/1, `scripts/backfill-races.ts` 7/3, `scripts/oneshot/711-retract-phantom-races.ts` 7/1; the SKILL blob is byte-identical across both tips (`4bacd1e`); `e714a53` is an ancestor, so the move is a clean fast-forward. The Preview `narrow-preview` run on the amended tip (`34642110390`, 74 passed) read `electoral-2028` and `members` at 430 and 390 with `over=0`. The data half already happened and was read back: the resync, the six at-large mints, nineteen deletions, two NULLs, the audit at `0 · 0 · 0`, and a second backfill run after the interpolation change reading `540 → 540`.

**What this FF is.** The first deploy whose race-row set equals the seat set, and the first Production reading of the width gate on `/members` since its readout grew a bucket. `e2e-prod.yml` cannot run on a review ref, so the Preview readings above are the prediction and the Production run after the move is the measurement. Render-touching: `/race/[id]` on at-large ids, `/members`, `/electoral?cycle=2028`, and the four seat labels.

## 1. The move

- `git ls-remote --heads origin` immediately before: `main` at `e714a53`, `711-review` at `ad63b85`. Anything else, stop and paste.
- On `main`, the cleanup door: `git merge --ff-only ad63b85`; `git rev-parse main` must print `ad63b85`. `git push origin main`, no force. `git push origin --delete 711-review`. Then `git ls-remote --heads origin` and `git ls-remote --tags origin` (three tags).
- Each state-changing command on its own line, stderr never suppressed. The commit list in the paste is `git log --oneline e714a53..main` off the pushed branch.

## 2. The readings

- `npm run verify:deploy` until the served SHA is `ad63b85`, five consecutive reads. A real build; if promotion lags past the timeout, paste the deployment list rather than wait it out.
- **Served, off production:** `/race/AK-AL-2026` reads *Alaska At-Large Congressional District*, Begich, `R-AK-AL` (not `-00`), against a control id whose `<h1>` is empty; `/members/<Begich>` NEXT ELECTION chip links there; `/members` reads `433 HOUSE · 6 NON-VOTING · 100 SENATE`; `/electoral?cycle=2028` reads 34 rows, 3 tags, and the "no race record" footnote clause absent; `/electoral` bare reads the rated set at `190 · 35 SEN · 155 HOUSE` with its DOM otherwise as before; one at-large state on the cartogram resolves to its `{ST}-AL-2026` seat in the district modal (the geometry bridge, read live rather than in the fixture).
- The Production `deployment_status` run: id and conclusion, the resolved-group echo, the `smoke` / `odds-off` / `narrow` lines including `members` and `electoral-2028` at both widths with `over=0`, the wall time against the cap, and any `pageErr` hit on those routes pasted per-hit.
- `ci.yml` conclusion.

## 3. After the FF

Nothing else is owed by this HO. Carried to HO 712: the two-Grahams oddity (a bare surname in a committed record; the fix is the bioguide, and the header already carries it). Standing: the audit line on every `backfill:races` run, and SECTION 5 of the guard.

## 4. Paste

The `ls-remote` line showing `main` at `ad63b85`, the ref gone, three tags; `git rev-parse main`; the eight-line log; the five served reads; the served readings in § 2; the Production run's id, group echo, spec lines and duration; the `ci.yml` conclusion.

read and follow 711-ff-go — the file, not this line
