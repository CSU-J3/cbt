# HO 773: the electoral cleanup. AL-01, GA-13 and TN-05 say what happened to their incumbents, four runoffs get their reasons, SC's runoff dates are right, and PAC rung 1b reads the target's own contest. With HO 772's FF readings and the first daily ratings run

**Corey's ruling, 2026-10-10 about 7:45 PM MT:** asked what Code should take on while the ratings wait on Cook and the raters, he picked *Electoral cleanup* over *Records only* and *Wait for Cook*.

**Scope, in:** five OPEN LOOPS lines by title, and the records HO 772's FF go left.
1. *AL-01's Barry Moore is printed on S-AL's ballot with no bioguide, so AL-01's card reads NOT ON THE BALLOT, not RUNNING FOR SENATE (HO 759).*
2. *Seven incumbents who lost a primary … read NOT ON THE BALLOT, not LOST PRIMARY (HO 759).* Two remain: TN-05's Andy Ogles and GA-13's Everton Blair Jr.
3. *Four first rounds with two advancers print no runoff box … AL-01 R, OK-01 R, TX-23 R, TX-32 R (HO 761).*
4. *`lib/pac-target-status.ts`'s rung 1b asks whether the seat has any resulted runoff, not whether the target's own contest has one (HO 761).*
5. *SC's fourteen House first rounds carry `runoff_date` 2026-08-25 … (HO 761).*
6. **The records:** HO 772's FF go, the CSS WATCH's close, HO 772's `MissingSecret` reading, HO 713's oddity, and the first daily ratings run.

**Out:** every other OPEN LOOPS line, the S-SC router (HO 762) and the unsafe repair script (HO 761) among them.

**How STEP 0 runs** (method.md, HO 768's rule): the table is mine and is a check. Go on through the build, the writes, the legs, docs and the review push unless a claim fails or a reading falls outside its bound.

**Base:** `main` at `889c737`. HO number: the pointer is 772 and the highest HO in commit subjects is 772, so this is 773.

## STEP 0

| # | Claim at `889c737` | Fails if |
|---|---|---|
| 1 | `lib/incumbent-qualifier.ts:104`: `lost_primary` needs `tokenCheck(p.name, member).ok` on every row. The primary read (`:135-140`) selects `c.bioguide_id, c.name, c.status` and `decided`, with no `person_key`. | |
| 2 | `lib/ballot-incumbent.ts:121-142`, `tokenCheck`: a first-name token matches whole, or as a prefix of three letters or more either way, so *Andy* against *Andrew* fails both. | |
| 3 | `lib/ballotpedia-title-repair.ts:51`: `kind` is `"stale" \| "missing" \| "moved"`.<br>• `findStaleTitles` (`:64-134`) finds own-ballot rows that the rule took by underline and surname (`:108-116`).<br>• It also finds underlined, untied, printed rows matched to the one sitting House member of the state with no stored title (`:117-131`).<br>• Neither reaches a row that isn't underlined, or a member who is on no ballot. | another class exists |
| 4 | `general_ballot.bioguide_id` is set by identity only (`scripts/migrate.ts:1271-1274`), keyed from `COALESCE(ballotpedia_title_resolved, ballotpedia_title)` (`lib/general-ballot.ts:528-545`).<br>• `primary_candidates` ties by `person_key` the same way (SKILL `:2932`).<br>• `repair:primary-identity` re-matches every stored row (`lib/primary-identity-repair.ts:231-262`), and with `--saved-only` it fetches nothing. | |
| 5 | `lib/pac-target-status.ts:250-252`: `haveRunoff` is `seatContests.some((c) => c.round === "runoff" && c.votePct != null)`, so another party's runoff counts. A runoff row's id is `` `${firstId}-runoff` `` (`lib/primaries-sync.ts:820`). | |
| 6 | No page shows a House first round's `runoff_date`. Its readers:<br>• rung 1b (`lib/pac-target-status.ts:249`);<br>• `lib/electoral-general.ts:645`, jungle contests only;<br>• the calendar (`lib/primaries-sync.ts:1636-1649`), statewide rows only;<br>• the specials' window (`:1201-1214`), Senate specials only;<br>• the runoff repair's date check (`:836-845`).<br>`components/RaceRunoffs.tsx:55` shows the runoff row's own `primary_date`. | a page reads it |
| 7 | SKILL: the repair entry at `:1337` ends *HO 751's dry run: 45 of 45 confirmed (redirect 19, disambiguation 12, ballot 13, ballot-prefix 1).* `:1985` is the *lost_primary* clause, and `:2551` carries the round sentence. Each edit's anchor below occurs once. | |

**Measurements.** Prod by `SELECT` only, except the writes below.

- **M1, the three cards today.**
  - *AL-01-2026* (Barry Moore): his `member_ids` titles, stored and resolved; his S-AL-2026 `general_ballot` row (`person_key`, `bioguide_id`, `on_ballot`, `incumbent_marked`); his S-AL R primary rows (`person_key`, `bioguide_id`, `status`). Expected:
    - stored *Barry Moore (Alabama)*, none resolved;
    - the S-AL row keyed `Barry_Moore_(Alabama_U.S._representative)`, printed, untied and not underlined.
  - *GA-13-2026* (`B001328`): his `member_ids` row, if any; his row in GA-13's decided D primary. Expected: no title, and the row keyed, untied and `running`.
  - *TN-05-2026* (Andy Ogles): `members.first_name` and `name`; his title; his row in TN-05's decided R primary. Expected:
    - first name *Andrew*;
    - the row named *Andy Ogles*, tied to him and `running`, with the route that tied it: identity (its `person_key` is his title's key) or the incumbent gate (the page underlines it). § 2 covers both.
  - `readIncumbentQualifierReadings(db, 2026)` at `889c737`, saved whole as leg D's base. Expected: all three `{ kind: "none", reason: "absent" }`.
  - **HALT** if any of the three doesn't read `absent`: its line's premise has moved.
- **M2, § 1's classes, dry** (after § 1 is built; no fetch). `findStaleTitles` lists:
  - Moore as `senate` on S-AL-2026 with that key;
  - Blair as `primary` on GA-13-2026 with his row's key.

  The bound: at most six cases across all five classes, each printed with its row. More, **HALT**. If Blair's row carries no `person_key`, the class can't learn his title: report it, leave GA-13 open, and go on.
- **M3, trusted ties the name check rejects** (after § 2): every row the new clause reads as `lost_primary` that the old one didn't. Expected: TN-05's Ogles row alone. The bound: at most three, each named with its route. More, **HALT**.
- **M4, SC.** `primaries` rows `house-SC-01-2026-D` through `house-SC-07-2026-R` with `election_round = 'primary'`: 14 rows, each with `runoff_date` 2026-08-25. Anything else, **HALT**.
- **M5, rung 1b's live set** (after § 3): `classifyTarget` over the live targets, as `lib/queries.ts:2637` builds them, at `889c737` and with § 3. Expected: no change, since HO 761 measured the rung dormant. A change is printed with both `why`s, not a HALT.

**The ratings run:**
- If you start after 2026-10-11 11:00Z, read every `cron_runs` row for `/api/sync-race-ratings` started after HO 771's deploy (2026-10-10 21:12Z): its status, its `error_message`, and on a `success` row each leg's `stats.raters.sabato`.
- Otherwise it's read at the FF go.

## The build

### § 1, two more title classes (`feat`)

In `lib/ballotpedia-title-repair.ts`:
- `TitleCase.kind` gains `"senate"` and `"primary"`.
- `findStaleTitles` reads, in the same batch, the cycle's primary rows: `primary_candidates` joined to `primaries` (`primary_id`, `name`, `person_key`, `bioguide_id`, and the primary's `chamber`, `state` and `district`) where `substr(primary_date, 1, 4)` is the cycle.
- **`senate`,** after the moved class. In every `S-` race with a `box` read, take each printed row (`on_ballot = 1`) that's untied, not underlined, and not taken by that race's own rule. If its name passes `tokenCheck` for exactly one sitting House member of the race's state, that member is a case, learning the row's key. Two or more passing go on the ambiguous list with their kind, and aren't cases.
- **`primary`:** a sitting member who is the stored incumbent of a race of the cycle, carries no bioguide on any primary row of the cycle, and isn't already a case.
  - Take their own race's primary rows, both rounds, with the race id derived as `lib/primary-identity-repair.ts:146` derives it.
  - Of those, keep the rows that are keyed (`person_key` set), untied, and pass `tokenCheck` for the member.
  - One distinct key is the case. Two or more go on the ambiguous list.
- `confirmCases` and the writes don't change. A stale title is fetched and confirmed as before. A missing title is confirmed by the name check, so Blair confirms as `ballot` or `ballot-prefix`.
- The module's header comment gains a paragraph for the two classes, naming Moore and Blair as the cases that found them.

In `scripts/repair-ballotpedia-titles.ts`: the lines it prints after a write name the follow-up by kind. A `senate` case's race is re-read (`sync:general-ballot -- --race …`). A `primary` case is tied by `repair:primary-identity -- --saved-only --write`. The header comment gains both classes.

### § 2, a tie the page makes needs no name check (`fix`)

HO 764 ties a primary row to a member two ways only (`lib/primaries-sync.ts:391-409`): by identity, or behind the incumbent gate, where an underlined row is matched by surname to the seat's incumbent, or to a sitting House member of the state for a redrawn seat. The name check was there for the old matcher's namesakes, and both routes rest on the page's own evidence: its link, or its incumbent mark.

In `lib/incumbent-qualifier.ts`:
- The primary read (`:135-140`) adds three fields:
  - `c.person_key` and `c.incumbent` (the underline);
  - the tied member's title, `COALESCE(NULLIF(TRIM(mi.ballotpedia_title_resolved), ''), mi.ballotpedia_title)`, from `member_ids mi` LEFT JOINed on `c.bioguide_id`.
- `QualifierPrimaryRow` gains `trusted`: the row's `person_key` equals `titleKey` of that title, or `c.incumbent` is 1. `titleKey` is `lib/primary-candidates-scrape.ts:165`, which imports no Next module.
- `:104`'s test becomes `p.decided && p.status !== "winner" && (p.trusted || tokenCheck(p.name, member).ok)`.
- The header's *lost_primary* paragraph says why: a row the page links to the member's own title, or underlines in their seat, is the member. The name check stays as the guard for a row tied any other way. TN-05's Andy Ogles, stored first name Andrew, read `absent` until HO 773.

### § 3, rung 1b reads the target's own runoff (`fix`)

At `lib/pac-target-status.ts:250-252`, `haveRunoff` becomes:

```text
seatContests.some((c) => c.primaryId === `${latest.primaryId}-runoff` && c.votePct != null)
```

The comment above it names HO 773 and why: the other party's resulted runoff says nothing about this one.

## The writes, before the review push

The Preview reads prod's database, so the review sees them (HO 754). Run them in this order, reading each back.

**W1, SC's runoff dates.** One statement, with the 14 ids written out and `?` the write's ISO time:

```text
UPDATE primaries SET runoff_date = '2026-06-23', updated_at = ?
 WHERE election_round = 'primary' AND runoff_date = '2026-08-25'
   AND id IN ('house-SC-01-2026-D', 'house-SC-01-2026-R', …, 'house-SC-07-2026-R')
```

- `rowsAffected` must be 14.
- Read back: the 14 at 2026-06-23.

**W2, the titles.**
- First the dry run: `npm run repair:ballotpedia-titles -- --plan-out <plan> --record <dir>`. It fetches each stale title's page once, at 6s.
- Then `--write --plan <plan>`, which writes only the confirmed rows.
- Expected:
  - Moore confirmed by `redirect` or `disambiguation`, or by the name check if his page confirms neither;
  - Blair confirmed by `ballot`.
- An unconfirmed case isn't written. It's reported, and its line stays open.

**W3, the re-read:** `npm run sync:general-ballot -- --race S-AL-2026 --write`, with every other race the write printed comma-listed. Read back: Moore's S-AL row ties to him.

**W4, the primary ties:** `npm run repair:primary-identity -- --saved-only`, dry first.
- Its bioguide changes must be exactly the rows keyed by a title W2 wrote, each NULL → that member: Blair's GA-13 row(s), and Moore's S-AL primary row(s).
- Anything else, **HALT** with the list.
- Then the same with `--write`.

**No flush.** The qualifier reads under `general-ballot` and `races`, and the kalshi cron expires `races` every two hours (`scripts/repair-runoffs.ts:12-16`). The Preview reads fresh.

## Legs

All in `scripts/diagnostic/electoral-cleanup-773.ts`.

**A, the classes:**
- `889c737`'s finder lists neither Moore nor Blair: the red. § 1's lists both, per M2.
- **The controls,** on planted rows:
  - an untied, un-underlined `S-` row whose name passes for no House member: no case;
  - a second House member of the state who also passes for the same row: ambiguous, no case.

**B, the qualifier** (`readQualifier` on planted rows):
- a decided, non-winner row named *Andy Ogles* for a member whose first name is Andrew, tied by identity: `lost_primary`. The red: `889c737` reads `absent`.
- the same row, not keyed to him but underlined: `lost_primary`.
- **The guard:** the same row, neither keyed to him nor underlined: `absent`.
- **The control:** a winner row tied by identity: no `lost_primary`.

**C, rung 1b** (`classifyTarget` on planted contests):
- an R first-round winner with a past runoff date and no R runoff row, in a seat whose D runoff is resulted: `unknown`. The red: `889c737` reads `active`.
- **The controls:**
  - the target in its own resulted runoff as winner: `active`;
  - no runoff anywhere, the date past: `unknown`.
- Then M5.

**D, the cards on prod,** after W1-W4, with the branch's code: `readIncumbentQualifierReadings(db, 2026)` against M1's base.
- Expected changes:
  - AL-01: `absent` → `{ kind: "senate", raceId: "S-AL-2026" }`;
  - GA-13: `absent` → `lost_primary`;
  - TN-05: `absent` → `lost_primary`;
  - plus any race of a case W2 wrote beyond those, each explained.
- Any other change: **HALT**.

**E, the four rounds.**
- **The read:** one GET of each district page (`houseDistrictUrl`): AL-01, OK-01, TX-23 and TX-32. Use the reader's pacing and agent (`pacedIO(liveIO(), MIN_START_GAP_MS)`). The first UNREAD page stops the read and leaves the rest.
- **For each page, report:**
  - the R primary's boxes, header and date;
  - whether an R runoff box exists;
  - every sentence in the R primary's section that mentions a runoff or a withdrawal, quoted;
  - the general box's R candidate.
- **Expected:** no R runoff box on any of the four. Each one's reading, in the page's own words or as *the page prints none*, is its recorded reason.
- **If a page does print an R runoff box:**
  - run `npm run repair:runoffs` dry;
  - if its would-insert list is exactly that box's rows, run it with `--write` and read them back;
  - otherwise **HALT** with both.

**On the Preview, after the review push,** through a share link: the incumbent card's tag on `/race/AL-01-2026`, `/race/GA-13-2026` and `/race/TN-05-2026` (`components/RaceIncumbentCard.tsx:138`) reads:
- RUNNING FOR SENATE;
- LOST PRIMARY;
- LOST PRIMARY.

Then `narrow-preview`.

## Docs

**roadmap:** the HO 773 block. It opens with **HO 772's FF go as taken** (your paste):
- the three fixes;
- their Preview, the gate reading and its runtime log;
- the FF;
- `verify:deploy`;
- the cold Production build;
- the CSS reading;
- `e2e-prod`;
- leg C on Production;
- the anonymous `GET /`.

Then Corey's ruling, STEP 0 with M1-M5 and the ratings reading, the build, the writes, and the legs.

**backlog:**
- **Struck,** each with a one-line close note naming its evidence:
  - AL-01's Moore: W2-W3 and leg D.
  - The seven incumbents: leg D. The nickname ruling: a row the page itself ties to the member, by identity or by its underline, needs no name check, so there's no nickname table.
  - The four first rounds: leg E's four readings.
  - Rung 1b: leg C.
  - SC's runoff dates: W1's read-back.

  A line whose fix didn't land (an unconfirmed title, a key that's missing) stays open, with the reading appended.
- **The CSS WATCH (HO 769),** struck, its close note verbatim:

  ```text
  · **CLOSED 2026-10-11, HO 772's FF go:** Production `dpl_JDTF6KaeoGyY9tBGtuSPye46SUt5` logged no *Restored build cache*, and `/` links `2di1y971kqboc.css`, which carries 15 *IBM Plex Sans Subsets* faces (0 at `3785c41`).
  ```

- **The *NextAuth `MissingSecret`* line** gains, verbatim, at its end:

  ```text
  **HO 772 (2026-10-11):** measured on a Preview: Auth.js logs `[auth][error] MissingSecret` on every request that calls `auth()` (`/`, `/members`, `/electoral` and `OPTIONS /` in one 12-second window), so sign-in can't work on a Preview either. Since `8d052b5` the landing gate tests `session?.user`, so a missing secret no longer opens it. The close is unchanged.
  ```

- **If the ratings run was read:** record it in the ratings WATCH and Sabato's line, closing what their closes say.
- Reconcile, with the control at 0.

**oddities:** HO 713's entry, *A probe that never reached the page reads exactly like a page with nothing on it*, gains a paragraph after its last, verbatim:

```text
**Closed at HO 772 (`8d052b5`).** The gate tested `!session`, and on a configuration error Auth.js's `auth()` resolves to its error body, `{ message }`, which is truthy (`next-auth` 5.0.0-beta.31 `lib/index.js:48`; `@auth/core` 0.41.2 `index.js:85-88`). So wherever `AUTH_SECRET` was missing, locally and on every Preview, the gate saw a session and let the visitor through. It tests `session?.user` now, and a cookieless `/` answers 307 to `/welcome` everywhere; HO 772's Preview logged the `MissingSecret` behind it.
```

**SKILL**, in its own `docs(skill)` commit, last. Quote the diff in the paste for approval.

Edit 1, `:1337`, after *HO 751's dry run: 45 of 45 confirmed (redirect 19, disambiguation 12, ballot 13, ballot-prefix 1).* insert a space and:

```text
**HO 773 adds two classes the ballot rule can't reach:** `senate`, a sitting House member printed on their state's Senate ballot in a row that's untied and not underlined, matched by the name check to exactly one such member (AL-01's Barry Moore on S-AL); and `primary`, a sitting incumbent tied to no primary row of the cycle, whose own race's primaries hold exactly one keyed, untied row that passes the name check for them (GA-13's Everton Blair Jr.). Both confirm by the same three signals. A `senate` case is tied by re-reading its race, and a `primary` case by `repair:primary-identity -- --saved-only --write`.
```

Edit 2, `:1985`:

```text
OLD: and stays as the second guard; identity ties a House member on a Senate primary's row,
NEW: and stays as the second guard for a row tied any other way: a row tied by identity (its `person_key` is the member's own title key) or behind the incumbent gate (the page underlines it) needs no name check (HO 773), so TN-05's *Andy Ogles*, stored first name Andrew, reads it; identity ties a House member on a Senate primary's row,
```

Edit 3, `:2551`:

```text
OLD: so a primary winner whose seat carries a past-dated `runoff_date` with no resulted runoff row is **`unknown`, not `active`**
NEW: so a primary winner whose contest carries a past-dated `runoff_date` with no resulted row in its own runoff (`<primary id>-runoff`; another party's runoff in the seat doesn't count, HO 773) is **`unknown`, not `active`**
```

## Commits

On `773-review` from `main`, kinds unmixed:
- `feat` § 1;
- `fix` § 2;
- `fix` § 3;
- `diag`;
- `docs`;
- `docs(skill)`, alone and last.

No migration. The prod writes are W1-W4, and E's `repair:runoffs` only if a page prints a box.

## Paste back once, after the Preview reading and `narrow-preview`

- `ls-remote` with `773-review`'s SHA;
- STEP 0: each claim, M1-M5, and the ratings reading;
- W1-W4: each output and read-back, and W2's plan;
- legs A-E, with their reds and controls;
- the Preview's three cards, and `narrow-preview`;
- `--stat` per commit, and `--numstat` for docs with every deletion explained;
- the SKILL diff;
- the reconcile;
- a last cheap-gate run.

Build through to the review push without stopping. The FF go follows my read of the ref. It will carry the FF, `verify:deploy`, `e2e-prod`, one `POST /api/revalidate?tag=races` with `$CRON_SECRET` by env name, and the three cards on Production.
