# HO 709 — STEP 0 ruling (architect, 2026-09-10). The HALT clears; three defects in the handoff, all mine, all ruled here.

Six rows read, worktrees built and intact, browser on disk, the bad key still loading 108 tests. Go for STEPs 1–5 as written, with the three corrections below folded in.

## 1. Row 5: the list does not exist, so the set that adjudicates the POST is the list

Accepted as proposed. **Flush all ten `ALLOWED_TAGS` from `app/api/revalidate/route.ts:21-36`** (`bills` · `reports` · `races` · `race-ratings` · `news-breaking` · `race-news` · `member-news` · `member-trades` · `member-fundraising` · `lda`) on both servers, and print the twenty responses. It is a superset of the spec header's rule, it comes from the file that returns the 400s, and the block can name where it came from. Read the route's auth shape from the same file (the header or query the handler checks against `CRON_SECRET`) and send it the way the handler wants; a 401 is a wrong send, not a flushed tag.

**Start commands from `package.json:9`, run inside each worktree:** n15 `npm start` (which is `next start -p 3000`), n16 `npx next start -p 3007`, matching the spec's `CAPTURE_FROM` and `CAPTURE_AGAINST` defaults so no env override is needed. The handoff's "not from memory" was aimed at recalling 706's commands; reading `package.json` is the opposite of that, and the ruling says so in the block. Before either server starts, **check that each worktree has its own `.env`** (presence and the two variable names, never the values), since the main checkout's `.env` does not reach a sibling directory; if one is missing, copy the main checkout's into it and say so. The `.env.production.local` shadowing trap is confirmed absent in the main checkout; check it in both worktrees the same way.

## 2. The commit count is four

STEPs 1, 2, 4 and 5 define the commits; STEP 3 defines none. The handoff's "five" is the error and the list is correct: `fix(HO 709)` · `ci(HO 709)` · `docs(HO 709)` · `docs(skill)`. The block records the miscount as the handoff's.

## 3. `:246` in full

The block quotes the line as it reads, `--retries=2` included. The eligibility argument is the spec list and `--grep-invert "@nonci"`; the retry count is part of the line, not part of the argument, and both go in.

## 4. Two readings the block keeps from this STEP 0

The `grep -c 'slug:'` reading 32 against Playwright's 36 (one line is `...STAGES.map(...)`): Playwright's count is the authority for the route set and the block says why the grep is not. And the row 3 total of 1,304 against the clone's 1,298, explained by `.next/types` and `next-env.d.ts`, with the six pattern counts identical, restating HO 708's seven-of-eight on this HEAD.

## 5. Order and paste, unchanged

STEP 1 with its step 4 red before the `:67` fix; STEP 2's comment-only grep; STEP 3 with the `@1440$` control before the 36, `RM=` counts on both roles, back-to-back on any failure and HTML before PNG on any second failure; STEP 4 and STEP 5 as written. `709-review`, four commits in that order, the paste as § Review ref lists it, `main` still at `918b52b` until the FF go arrives as a file.

read and follow 709-step0-ruling — the file, not this line
