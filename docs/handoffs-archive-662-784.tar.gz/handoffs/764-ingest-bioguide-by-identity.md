# HO 764: the primary ingest assigns a bioguide by identity, or behind the incumbent gate, never by surname alone

`docs/backlog.md` OPEN LOOPS, *`primary_candidates.bioguide_id` is still assigned by surname, so the ingest's review list loses an incumbent a namesake shadows, and SKILL's matcher sentence is false (HO 750)*, owner Code, medium. Two namesakes still carry a senator's and a congressman's bioguides (S-AK's second Dan Sullivan, IL-04's Patty Garcia), Chuy García is off the *Incumbents not found* review list because of it, and SKILL says the incumbent gate prevents exactly this.

The ballot reader already has the right tool: a candidate's Ballotpedia href is their identity, and `member_ids.ballotpedia_title` (resolved at HO 751 for every 2026 incumbent) ties it to a bioguide. The primary parser discards the href today. This HO keeps it and matches on it.

## Ground truth (read at `e91339a`; re-derive every `:N` by content)

- `parseVotebox` (`lib/primary-candidates-scrape.ts:206-207`) matches the row's `https://ballotpedia.org/…` link and keeps the anchor text only; `incumbent` is the `<u>` (`:244`). `general-ballot.ts`'s `hrefKey` and `titleKey` normalise an href and a title to one key; `loadIdentity` maps keys to bioguides from `COALESCE(ballotpedia_title_resolved, ballotpedia_title)`.
- `matchHouseCandidate` (`lib/primaries-sync.ts:313-345`): first test, the candidate's last word contained in the district incumbent's folded name, with no gate; fallback behind the incumbent flag, by surname against the state's delegation, first name to break ties. `buildSenateMatcher` (`:522-549`): the one senator in the state whose lower-cased name contains the candidate's last word, no gate.
- The review list: *Incumbents not found in the candidate scrape*, printed by the sync; a false match removes a real miss from it.
- `primary_candidates` has no href column. Readers of its `bioguide_id` (HO 750's census): the harvest's primary-sourced fallback (races without a `box` read), `RaceRunoffs`' member link, the CLI `--rematch`, the review list, and diagnostics.
- SKILL's *The House incumbent matcher tolerates mid-decade redraws* entry (`:2831` at `ebe8813`) claims the gate means a same-surname challenger is never misattributed.

## STEP 0

1. HO number from the tree: `main` at `e91339a`, pointer 763, so 764. Otherwise stop.
2. Re-read every cited `:N` by content. Flag a drift.
3. Measure, prod, SELECTs only: `primary_candidates` rows with a bioguide, by chamber; rows whose bioguide's member has a different normalised full name than the row (the suspected false matches; the two known among them); incumbents on the review list today and the incumbents a false match hides; `member_ids` identity coverage for the members those rows name.
4. On HO 747's saved pages: how many kept-primary rows carry an href (expected all with a person link), and how many hrefs tie to a member by identity.
5. Carry HO 763's FF-go reading (the three pages and the 28-page count) into this HO's roadmap block.
6. Proceed without a halt.

## The build

1. `parseVotebox` keeps the href as `href` on the candidate (the `hrefKey` form), beside the name. `primary_candidates` gains `person_key TEXT` (nullable); migrate before the review push (a page reads nothing new, but the cron writes it).
2. Both matchers become one rule: a bioguide is assigned by identity when the candidate's `person_key` equals a member's `titleKey` (any chamber, any state: a member running elsewhere still ties); failing identity, only an incumbent-flagged candidate (`<u>`) may match, by surname against the seat's incumbent for the House or the state's senators for the Senate, first name to break ties; a candidate the page doesn't underline gets NULL. The old first test and the old Senate rule are removed.
3. The review list is derived from identity: an incumbent whose key appears in no kept row of their own race's primaries, with the surname route as the fallback it already is for untied titles.
4. `--rematch` runs the same rule over stored rows that carry a `person_key`; rows written before this HO have none and are re-matched by the gated surname rule only, which is what the repair below fixes.
5. The repair, `npm run repair:primary-identity`, dry by default, `--write` to write: from HO 747's saved pages (no fetch) and then from live pages at the reader's pacing for any kept row the saved set lacks, fill `person_key` for every stored `primary_candidates` row it can tie by `(primary_id, name)`, re-match bioguides by the new rule, and print every bioguide that changes, with the old and new member named.

## Legs, on a `file:` copy with HO 747's saved pages, each red first

1. The parser keeps the href: S-AK's two Dan Sullivans have different keys; IL-04's Patty Garcia's key is not García's title.
2. The rule: the senator's row ties by identity to `S001198`; the second Dan Sullivan reads NULL; Patty Garcia reads NULL; a gated fallback case (an underlined incumbent whose title is untied) still ties by surname; an un-underlined namesake of that incumbent reads NULL. Red: today both namesakes carry the incumbents' bioguides.
3. The review list: García is on it on the copy before the repair and off it after, because his own row ties; a planted namesake no longer removes a real miss.
4. The repair: the dry run writes nothing (content hash); `--write` fills `person_key` for the rows the saved pages cover, re-matches, and the list of changed bioguides is exactly STEP 0's suspected false matches plus any gated fallback now resolved by identity, each named.
5. Readers: the harvest's primary-sourced fallback on the copy publishes the same rows before and after, except where a false bioguide is corrected; `RaceRunoffs`' member link follows the corrected bioguide.

## Commits and docs

- `feat(HO 764)`: the parser, the column and migration, the rule, the review list, `--rematch`, the repair.
- `diag(HO 764)`: the legs driver.
- `docs(skill)`, its own commit, approval requested: the matcher entry rewritten (identity first, the gate as the only surname path), `person_key`, the repair, the review list's derivation.
- `docs(HO 764)`: strike the line on legs 2 and 3 with the prod repair owed in the FF go; the roadmap block, pointer 763 → 764, carrying HO 763's reading. Reconcile OPEN LOOPS at open and close, control at 0.
- Review ref `764-review`. The FF is held for the SKILL approval and review. No render change; no captures.

## The prod reading (in the FF go)

Migrate before the deploy. After the FF: the repair's dry run pasted, then `--write`; `SELECT bioguide_id FROM primary_candidates WHERE name IN ('Dan Sullivan', 'Patty Garcia')` reading the senator's bioguide once and NULL twice; the review list with García on it or, if his row now ties, correctly off it with the tie shown; the count of bioguides changed.

## Paste back

- STEP 0's readings;
- the five legs;
- the SKILL diff, for approval;
- `git show --stat` per commit, `--numstat` for the docs commits, the reconcile, the `764-review` SHA from `git ls-remote`, and a last cheap-gate run.
