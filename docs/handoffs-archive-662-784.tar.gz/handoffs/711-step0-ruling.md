# HO 711 — STEP 0 ruling (architect, 2026-09-10). Predicate B stands, the 2027 derivation is fixed inside this HO, and the delete list grows to thirteen. The HALT clears on Corey's word for the list and the two keeps.

Good STEP 0. Row 5 is the one that mattered: the handoff's wrong-cycle predicate was mine and it was wrong, and it would have deleted `S-FL-2026` and `S-OH-2026` — two rated, market-linked rows that HO 710's outlook links to as the TBD deciding contests. The closure-table-before-DELETE rule exists for exactly this, and it worked. Every anchor and count in the paste is accepted, including the :N offset convention (line 1 = `## OPEN LOOPS`), the :29 strike, and row 11's nine diagnostic files.

## 1. D1 — predicate B is the rule; one predicate, one disposition

Accepted. **A Senate race row at cycle *c* is a phantom when no `is_current = 1` senator of that state carries `next_election_year = c`.** That is the members-side derivation read back against the races side, which is the only test that can be right on every special: Moody and Husted stand at 2026 by the special-election overlay, so `S-FL-2026` / `S-OH-2026` pass, and `S-FL-2028` / `S-OH-2028` fail because nobody stands there yet. It collapses the handoff's two kinds into one, as you say. The handoff's predicate A (class residue against the cycle) is recorded in the block as the architect's error with the reading that caught it, and the sentence *the class is fully determined by the cycle* is true of seats and false of special elections, which is precisely why it must never be the audit.

Delete list from B: `S-FL-2028 S-OH-2028 S-MN-2028 S-MS-2028 S-NE-2028 S-NJ-2028 S-AK-2030 S-OR-2030 S-SC-2030`, all zero dependents (row 7). Keeps: `S-FL-2026 S-OH-2026`. Both sets go to Corey unchanged.

## 2. D2 — the House term math is fixed inside this HO

Ruled: fix it here. It is one line, it is the HO 410/411 defect reproduced through House specials, and the HO's title cannot be true while four sitting members are indexed to a year with no election. Overridable in a word.

- `lib/derive-term.ts:93` `houseTermEnd(start) = start + 2` assumes an odd-year start. A House term ends on the January 3 of the first **odd** year strictly after it begins, so **`houseTermEnd(start) = start % 2 === 1 ? start + 2 : start + 1`**; `houseNextElection = termEnd − 1` then reads 2026 for a 2025 start and for a 2026 special start alike. The comment above it (*House terms are exactly 2 years = 1 Congress, so the latest entry's startYear is the current term start directly*) is false for specials and is rewritten. Table in the scratch: `2025 → 2027/2026`, `2026 → 2027/2026`, `2024 → 2025/2024`, `2023 → 2025/2024`.
- Then the standing sequence, each with its read-back: `npm run sync:members` (the routine script, against the 119th, which the API serves; print the before/after `next_election_year` histogram for House and expect **2027: 4 → 0**, and quote the roster diff it reports, since it will also pick up whatever roster churn the last run predates); `npm run backfill:races`, which heals `CA-01-2026 GA-14-2026 NJ-11-2026 TX-18-2026` to their sitting members by its own `ON CONFLICT` (read the four incumbents back) and mints nothing new.
- The four `*-2027` rows are then phantoms under the House rule in § 4 and join the delete list **after their own dependents check**, expected 0. If any carries a dependent, it is listed and held, not deleted.
- This is its own `fix` commit and its own oddity: *House term math drifts through specials the way Senate term math drifted through appointments; HO 410/411's fix was one chamber wide.*

## 3. D3 — `AL` is Alabama too

Accepted. The at-large test is **`chamber = 'house' AND district = 0`**, never a substring on the id; where the id must be matched, the pattern is anchored (`id LIKE '__-AL-____'`), which `S-AL-…` cannot satisfy. One sentence in the Race IDs paragraph, and row 6's true reading (six loose at-large ids in `kalshi_odds`, every one closed by this HO) goes in the block.

## 4. The audit, finalised — SECTION 5 and the backfill's last line, one implementation

Scope: `cycle >= <current year>`; past cycles are history and their departed incumbents are the record of who vacated (the eleven LEAVE rows are excluded by scope, and the block says so).

- **Senate phantom** — no current senator of the state stands at that cycle (§ 1).
- **House phantom** — an odd cycle. No regular House election falls in an odd year, and under the § 2 derivation no sitting member can carry one; a legitimate special produces an even-year row for its winner.
- **Departed incumbent** — `incumbent_bioguide_id` is `is_current = 0`. A reading with three dispositions, never an automatic action: heals on the next backfill if a current member maps to the id; `NULL` if the seat is vacant at a regular cycle; delete if the row is also a phantom.
- **At-large sanity** — House rows with `district = 0` whose id does not carry the `AL` token, and the reverse. Expected 0 both ways.

Output shape, printed by `backfill:races` after its insert line and by `senator-year-audit-410.ts` as SECTION 5: `race rows ≥ 2026: phantoms N [ids] · departed-incumbent N [ids] · at-large mismatches N`. **Before figures, from this STEP 0: phantoms 13 (9 Senate + 4 House odd-cycle), departed-incumbent 11 (3 on phantoms, 4 vacancies, 4 healable). After the pass: 0 / 0 / 0.** Those are the :79 close criterion's numbers now, replacing the handoff's 7 / 2.

## 5. SKILL and docs additions from this STEP 0

- `:2705` (*Things to watch for*) is the **fourth** statement of the id rule and carries both *update both* and the `district IS NULL` exclusion sentence. STEP 3 amends it to match the other three; the block says HO 710's sweep missed it because the grep keyed on the phrase it had just changed.
- `derive-term.ts` header and the `sync:members` SKILL entry gain the § 2 rule.
- Row 11's count for the fold line is **4 in `lib/queries.ts` + 9 diagnostic files**.
- The oddity from § 2, and a second only if the paste shows one: a predicate that reads the right number of rows and the wrong rows (both A and B returned 9).

## 6. What Corey confirms, and what rides on his word

- **The delete list of thirteen:** the nine from § 1 (zero dependents, confirmed) plus `CA-01-2027 GA-14-2027 NJ-11-2027 TX-18-2027`, the latter four conditional on their own zero-dependents reading after § 2's resync.
- **The two keeps** `S-FL-2026 S-OH-2026` and **the four NULLs** `CA-14-2026 FL-20-2026 GA-13-2026 TX-23-2026`.
- **Backlog :35**, one word: *apply* (the HOUSE bucket on `/members` counts voting seats; commit 4 rides) or *leave*.

The at-large token stays off the table. Nothing in STEP 1 starts before the word; the verdict travels as a verbatim quotation with its provenance.

read and follow 711-step0-ruling — the file, not this line
