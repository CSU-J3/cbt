# HO 696 — `docs/design/` custody: the loose mocks come home, `scratch/` for the disposable, and a citation gate that can fail

Chore, docs(design), one comment, test, SKILL (alone), method, docs. Seven commits, kinds never mixed. Closes `docs/backlog.md:110`, opened at the HO 672 close, *ruled its own HO*, and counted rather than absorbed at 689 and 690 while its own figures drifted three times (16·15 → 18·14 → 19·14 → 20·13). Every handoff that rules against a mock has added one more file to the ad-hoc count; this is the directory-scale fix the entry prescribes, in the HO 672 shape it names.

**Why now.** Nothing else on the ledger is actionable before the 15th: the `:50` #418 captures are accumulating and are not yet a cause; M3 re-arms after S-DE-2026 closes; the CRLF finding is filed as an oddity, not a chore, and stays there. This entry is blocked on nothing and its close criterion is already written.

**Three calls made without asking, per method § Roles (none changes the product); say so in the block rather than defending them in chat.** (1) The gate is a **second workflow with no path filter**, not a step in `ci.yml`: that workflow's `paths-ignore` drops `docs/**` and `**/*.md`, which are two of the three ways a design citation dangles (a docs push that cites an uncommitted mock; a mock removed or renamed), so a step there would catch only the code-comment case and a docs-made dangle would surface as a red on the next unrelated code push. (2) The citation grammar is deliberately narrow and its limit is written where a reader meets it: a `docs/design/<file>` path, or a bare `mock-<digits>-…html` name (the ruling-record convention since 629). Pre-629 mocks cited by bare name in old handoffs are outside it; committing what is on disk fixes the ones that can be fixed. (3) The recorded-dangle allowlist lives beside the directory it governs, `docs/design/citations.allowlist.json`, on the `e2e/odds-sites.allowlist.json` pattern (reason vocabulary, stale-entry direction, `_README` key).

**What needs Corey, and only at STEP 0:** the destination of each untracked file. Pre-ruled defaults so the relay carries no empty slot: a loose file **commits** unless Corey names it disposable; a `(N)` browser-download duplicate byte-identical to its tracked twin is **deleted** (`cmp` is the proof); a `(N)` duplicate that differs goes to `scratch/` unless Corey names it the ruled version; **nothing else goes to `scratch/` without his word.**

## Ground truth at authoring (fresh clone at `3b3d167`, HO 695 shipped 2026-09-05)

- Pointer 695 (`docs/roadmap.md:1308`), highest HO in commit subjects 695, number `max(695, 695) + 1 = 696`. Re-derive at session open.
- `docs/design/` **tracked 20** (19 `.html` + `layout-conventions-arc.md`; `git ls-files docs/design`); last mock commit `d47ee1d` (HO 690). Untracked and ignored are unmeasurable from a clone: `~13 · 0 (estimate, backlog:110's post-690 projection; STEP 0 measures on the working tree)`.
- **Citations, resolved in this clone** by `git grep -o 'docs/design/[A-Za-z0-9._()-]*'` over tracked files outside `docs/design/`, trailing punctuation stripped: 20 distinct prefixed targets, **17 resolve, 3 do not**: `ideology-polarization-over-time.html` (`components/PolarizationOverTime.tsx:14`, `docs/backlog.md:110`), `layout-conventions-c1-c8.html` (`.claude/skills/cbt/SKILL.md:1946`), `welcome-670.html` (`docs/roadmap.md:871`, a filename guess the same sentence corrects). Plus one **malformed** token: `docs/design/welcome-formats-` at `app/welcome/page.tsx:20`, the filename wrapped onto `:21` (`// mock.html format 1, …`). Two more sites wrap the other way, directory at line end and the bare `mock-673-sponsor-cosponsor.html` on the next line (`components/BillExpandPanel.tsx:207–208`, `app/globals.css:5109–5110`); the bare name resolves, so they read clean under the grammar below.
- **Bare `mock-<N>-…html` tokens** outside the prefix: `mock-657-races-merge.html` (`docs/roadmap.md:655`, `docs/backlog.md:110`) and `mock-590-dashboard-declutter.html` (`docs/backlog.md:252`, `docs/oddities.md:1116`) do not resolve; every other bare mock-N name does. Bare names outside the grammar and absent: `ideology-cut1-members-insitu.html` (`docs/handoffs/425-members-polarization-dotplot.md:9`), `dashboard-hill-fit.html` (`…/266…:7`), `dashboard-v2-tabbed-words.html` (270–273), and `electoral-pre/post.html` (`docs/oddities.md:2424/2426`, capture files, not mocks). So **six findings are predicted at base**: three dangling prefixed, two dangling bare, one malformed.
- `docs/handoffs/` is ignored (`.gitignore:67`) and **386 files under it are tracked** (`git ls-files docs/handoffs | wc -l`), which is the entry's own point that an ignore rule is not a citation boundary.
- The HO 672 shape: `.gitignore:47–55` (`scripts/diagnostic/scratch/*` + `!…/README.md`) and `scripts/diagnostic/scratch/README.md`, the template. `tsconfig.json` includes `scripts/**/*.ts` and excludes only `scripts/diagnostic/scratch`, so the new script is typechecked.
- CI: `ci.yml` triggers `pull_request` and `push` to `main` with `paths-ignore` `docs/**` · `.claude/**` · `**/*.md` · `LICENSE` (`:19–23`, `:26–30`), concurrency `ci-${{ github.ref }}` (`:34–36`), the odds static step at `:69`. Review refs are `refs/heads/<ho>-review` (SKILL `:2512`), so `ci.yml` never runs on one. The precedent script is `scripts/check-odds-sites.ts` (walk, allowlist, two directions, `OK` or a problem list and exit 1) with `e2e/odds-sites.allowlist.json`.
- `docs/method.md:358` § Doc authority and conventions: bullets for SKILL `:360`, roadmap `:363`, backlog `:372`, oddities `:375`, method `:376`, cross-reference `:377`; **no `docs/design/` bullet.** SKILL `:2568` § Continuous integration: `:2570` says `ci.yml` is *"the first and only CI in the repo"* with *"a single `checks` job"*; `:2573–2574` carry the odds step; `:2576` names `e2e-prod.yml` as the separate crawl. README `:108–119` lists handoffs, the archive, roadmap, backlog, oddities and method under project structure and **not `docs/design/`**.
- The close at `backlog:110`, both halves: **(a)** every mock a tracked file cites resolves in a fresh clone, checked by cloning to a temp dir; **(b)** a throwaway mock cannot be cited by accident, checked by naming the instrument and showing it catch a planted citation. *"A close that only reports '15 files committed' satisfies neither half."*

## STEP 0 — enumerate, then HALT

Two tables, then stop. Nothing is created, moved or committed before Corey's ruling comes back as a quotation.

**Table A: every untracked file under `docs/design/`** (`git ls-files --others --exclude-standard docs/design`), and the three counts `tracked · untracked · ignored` on this tree, dated:

| file | bytes · mtime | sha256 (12) | cited by (tracked `file:line`, prefixed or bare) | twin (`cmp` verdict, if a `(N)` name) | proposed |
|---|---|---|---|---|---|

Proposed is one of **COMMIT** (default) · **DELETE** (byte-identical duplicate only) · **SCRATCH** (only per the pre-ruling above). Expected on disk from the record, named so their absence is a flag and not a shrug: `ideology-polarization-over-time.html`, `mock-657-races-merge.html`, `ideology-cut1-members-insitu.html`, `floor-votes-section(1).html`. If any of the first three is **not** on disk, that row HALTs on its own: the roadmap records a ruling whose evidence exists nowhere, which is an oddity and an allowlist entry, and Corey decides which.

**Table B: every citation finding at base**, from the same greps as the ground truth, run here rather than inherited: the six predicted, plus anything new since `3b3d167`. Columns: `file:line` · token · class (`dangling-prefixed` / `dangling-bare` / `malformed`) · disposition (**resolves once Table A commits** / **allowlist** with reason / **fix the citation**). Predicted dispositions: the two ideology files and `mock-657` resolve at STEP 3; `layout-conventions-c1-c8.html` → allowlist `never-landed`; `welcome-670.html` → `historical-name`; `mock-590-dashboard-declutter.html` → `never-existed`; `page.tsx:20` → fix (STEP 4).

Also enumerate, no halt needed: the SKILL sentences the new workflow makes false (`:2570`, expected two clauses) and the README structure list. Paste both tables, HALT.

## STEP 1 — write the scanner first, and read the base tree with it

`scripts/check-design-citations.ts`, `npm run check:design-citations`. Written before any other change and **run on the base tree before STEP 2**, because that reading is the control: it must report Table B exactly (predicted six). Fewer means the scanner is blind somewhere; more means the grep enumeration missed something; either is a flag, not a rounding.

- **Scope:** every tracked file (`git ls-files -z`), skipping binaries (a NUL in the first 8 KB, plus `.gz .png .jpg .ico .woff .woff2 .pdf .zip`). Tracked only, on purpose: a fresh clone has nothing else. The scanner does **not** exempt itself, the allowlist, `.gitignore` or the two READMEs; those files simply never write a concrete path under `scratch/` (they say *a file in `docs/design/scratch/`* in words, the HO 695 postscript lesson wearing a different costume).
- **Grammar, per line.** (G1) `docs/design/` followed by `[A-Za-z0-9._()/-]+`, trailing `.,;:)` stripped. Empty remainder, or exactly `scratch`/`scratch/`, is a directory mention: skip. Remainder beginning `scratch/` with anything after it other than `README.md` is **FORBIDDEN**, and no allowlist entry can lift it (this is close-half (b)). A remainder whose last segment has no extension is **MALFORMED** (a wrapped or truncated citation, illegible to every grep). Otherwise it must be a tracked path, or allowlisted, else **DANGLING**. (G2) bare `\bmock-\d+-[A-Za-z0-9._-]*\.html\b` not preceded by `docs/design/` must be tracked at `docs/design/<name>`, or allowlisted, else DANGLING.
- **Allowlist** `docs/design/citations.allowlist.json`: `{ "<token>": { "reason": "never-landed | never-existed | historical-name", "note": "…" } }`, `_README` skipped. Direction 2 as the odds gate: an allowlisted token that **now resolves** is `STALE` and fails, so landing `layout-conventions-c1-c8.html` one day removes its entry or reds the run.
- **Self-check:** `citations == 0` exits 1 with *scanner read nothing* (the HO 604 C1 lesson: a grep aimed at the wrong path reads 0 both before and after).
- **Plant hook:** `DESIGN_CITATIONS_PLANT=1` injects one synthetic FORBIDDEN finding attributed `(plant)`; exit 1. Used by the workflow's dispatch input below.
- **Output:** one line per problem `file:line  <token>  <CLASS>`, then `scanned N · citations M (prefixed P, bare B) · resolved R · allowlisted A · problems K`, then `OK` or exit 1. The summary line is what the paste quotes, not a bare exit code.

## STEP 2 — the rule (commit 1, `chore(HO 696)`)

- `.gitignore`: a block beside the HO 672 one, `docs/design/scratch/*` and `!docs/design/scratch/README.md`, with a comment stating the counts from Table A and the rule in one sentence. Verify with `git add --dry-run` on a file placed in `scratch/`, never `check-ignore` (method § Gates, HO 672).
- `docs/design/scratch/README.md`: the opt-in for a mock known disposable when it is saved (a browser-download duplicate, an iteration superseded before it was ruled). Ignored; nothing tracked may cite a file here; `check:design-citations` fails on one. A ruling record never goes here.
- `docs/design/README.md`: design artefacts default to **tracked**; a ruling record is `mock-<HO>-<slug>.html`, committed in the HO that ruled against it with its sha256 in that HO's roadmap block (the 670/673 precedent); `scratch/` is the one ignored location; **cite on one line** (a path wrapped across a comment is illegible to the gate and to grep); recorded dangles live in `citations.allowlist.json` with a reason and go stale loudly; what the gate cannot see (bare pre-629 names, prose mentions of the directory); the count history 16·15 → 18·14 → 19·14 → 20·13 → this HO's after-figure, and the three citations known broken in a fresh clone since 672, 24 handoffs ago (the component's has dangled since HO 428).

## STEP 3 — the files (commit 2, `docs(design HO 696)`)

Per the ruled Table A: `git add` each COMMIT row **by explicit path**; `mv` each SCRATCH row into `docs/design/scratch/` (untracked, so a plain `mv`); `rm` each DELETE row (untracked, so `rm`, never `git rm`) with the `cmp` line in the commit message. After the commit, on the working tree: `untracked 0`, `ignored = SCRATCH count`, `tracked = 20 + COMMIT count`. **Take the counts on this tree, not in a clone**: in a fresh clone tracked equals disk by construction and the check cannot fail (oddities, HO 662). Record `git cat-file -p HEAD:<path> | sha256sum` for every committed mock; the blob, not the CRLF working copy.

## STEP 4 — one citation on one line (commit 3, `chore(HO 696)`)

`app/welcome/page.tsx:20–21`: rewrap the comment so `docs/design/welcome-formats-mock.html` sits on one line; no other byte changes. A forced consequence of the gate, not a widening; the block says which.

## STEP 5 — the gate (commit 4, `test(HO 696)`)

- The script from STEP 1, the allowlist with its three seeded entries (each `note` names the citing `file:line` and the record that explains the dangle), `package.json` `check:design-citations`.
- `.github/workflows/design-citations.yml`: `on: push` with **no branch or path filter** (a review ref is read before FF, and docs pushes are exactly when citations change), `pull_request`, and `workflow_dispatch` with a boolean `plant` input; `concurrency: design-citations-${{ github.event_name }}-${{ github.ref }}`, `cancel-in-progress` (event name in the key so a dispatch never cancels a working push run on the same ref: HO 685); checkout → setup-node 20 with npm cache → `npm ci` → `npm run check:design-citations` with `DESIGN_CITATIONS_PLANT` set from the input. Secretless, deterministic. A header comment states why it is not a `ci.yml` step (the `paths-ignore` reason above) and the HO 685 rule that the concurrency key and any job `if` change together.
- **Falsification before the commit, four exits quoted with their summary lines:** (i) at the base tree the scanner reports Table B and exits 1; (ii) after STEP 3 it reports **exactly** the three allowlisted tokens when run with an empty allowlist, and `OK` with the real one; (iii) a planted `docs/design/scratch/plant-696.html` citation appended to a tracked file (working tree, unstaged) reads FORBIDDEN at its `file:line` and exits 1, and a planted `docs/design/nope-696.html` reads DANGLING; both removed, `OK` restored; (iv) a temporary allowlist entry for `docs/design/landing.html` reads STALE and exits 1; removed, `OK`. Quote (iii) in full; it is close-half (b).

## STEP 6 — SKILL (commit 5, alone, self-mod guard)

§ Continuous integration `:2570`: *first and only CI* becomes *the first CI in the repo and the PR-path build check*; *a single `checks` job* stays true of that file. New bullet after `:2574`:

> - **`design-citations.yml` (HO 696) is the second workflow, and the only one with no path filter.** It runs `npm run check:design-citations` on every push to any ref, every PR and by dispatch: every tracked file is scanned for a `docs/design/<file>` path or a bare `mock-<N>-…html` name, and the run reds on a citation that does not resolve to a tracked file, on a path split across lines, on any file cited under `docs/design/scratch/`, or on a recorded dangle in `docs/design/citations.allowlist.json` that has since landed. A `plant` dispatch input reds it on purpose. It is not a `ci.yml` step because that workflow's `paths-ignore` skips `docs/**` and `**/*.md`, two of the three ways a design citation dangles. It cannot see a pre-629 mock cited by bare name, and does not try to.

Provenance after the sentence. Nothing else in SKILL moves unless STEP 0 found a second false sentence; if it did, it is in the table.

## STEP 7 — method (commit 6, `docs(method HO 696)`) and docs (commit 7, `docs(HO 696)`)

**§ Doc authority and conventions, a bullet after the oddities line `:375`:**

> - **`docs/design/`** — mocks and ruling records, tracked by default. `docs/design/README.md` states the directory's rule: the `mock-<HO>-<slug>.html` name, the one ignored `scratch/`, citations on one line, and what `check:design-citations` reads and cannot. A mock a tracked file cites ships with the repo, or it is a citation waiting to dangle (HO 672 → 696).

Docs: roadmap `Also (HO 696)` + pointer, carrying both tables as executed, the three calls above with their reasons, every committed mock with its sha256, the four falsification exits, and the counts before and after on the working tree. Backlog `:110` **struck with provenance**, both close halves named with the instrument that satisfied each, never deleted; OPEN LOOPS reconciled at open and close. README: one `docs/design/` line under project structure. Oddities: only if STEP 0 surprises (a recorded ruling whose mock exists nowhere would be one). **The block, the strike and the paste describe the two plants in words and never write their literal paths**: the scanner does not exempt the roadmap or the backlog, so a planted `scratch/` path quoted into a tracked file is exactly what it reds.

## Gates

`typecheck` 0 · `build` 0 (a code file changed, even if only a comment) · `check:design-citations` `OK` with its summary line quoted · the four falsification exits · **the fresh-clone read, which is close-half (a):** `git clone --branch 696-review` into a temp dir, `npm ci`, `npm run check:design-citations`, `OK` quoted from *that* tree · the working-tree counts before and after · the `design-citations` run on the review-ref push, green, run id quoted · one `workflow_dispatch` with `plant=true` on the ref, **red**, run id and the FORBIDDEN line quoted (the workflow's rendering of a failure is the half a local run cannot show) · `git diff --numstat` on backlog, method, SKILL and README with every deletion explained (a deletions figure the size of the file means the line endings were rewritten: stop, byte-count, HO 695). Re-run the cheap gates immediately before the paste and say so. No captures owed: nothing renders differently.

## STEP 8 — review ref, FF

`696-review`, `git ls-remote`, architect review of all seven commits (Table A as executed and the SKILL diff are the substance), SKILL slot, FF `HEAD:main` no force, ref deleted, `git ls-remote`. `verify:deploy` for the served SHA only; the bundle strips the comment, so no render check is owed, and the block says so rather than skipping it.

## Paste-back

Both STEP 0 tables. The scanner's base-tree summary line. The counts before and after, dated, on the working tree. The four falsification exits. The fresh-clone `OK`. The two workflow run ids with conclusions. `git show --stat` per commit, the numstats, the SKILL diff attached as a gitignored file. After FF: `git ls-remote`, the served SHA.

read and follow 696
