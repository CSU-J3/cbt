# HO 685 — STEP 0 rulings

All five decisions ruled architect-side; none is a product fork. One of your findings is corrected back in the other direction — see the row 9 note, which also simplifies STEP 1's comment.

**1. Row 4 instrument — ADD the permanent echo**, with its scope stated honestly in the comment beside it: the echo shares its expression with the group key by necessity (steps cannot read `concurrency.group`), so it verifies **expression semantics** — what `|| 'na'` and the discriminators resolve to per event — and cannot catch a typo'd key, whose content is verified by reading the yaml. The skip-only groups' inability to self-report is accepted as you argued; their distinctness is carried behaviorally by the collision tests. The always-runs second job is rejected for the runner-start cost, as recommended.

**2. Row 2 — LEAD the strike with the clipped daily**, and frame the 18:25–18:31 window as what it is: a three-run cancellation chain — working deploy crawl killed by the armed schedule run, armed schedule run killed by a Preview run whose job then did nothing — **three runs, zero completed crawls, in six minutes**, with the alarm silently missing 2026-09-02. That's the blind window realized on its actual carrier, and it attributes Corey's report precisely. The dispatch incident becomes the prior instance, restated with your correction: **cancelled 89s into a ~3-minute crawl, by a run created 47s after it** — the 47s figure kept as what it measures, not as depth-into-crawl. Disposition-under-the-new-key stated per cancellation exactly as your sweep table has it (chain link 1 preserved as working-group burst collapse; links 2–4 prevented).

**3. Oddities — one short entry**, your recommendation and your reasoning verbatim: the before-`if` evaluation is a platform semantic that generalizes past this workflow, oddities is where that class lives, the figures stay in the strike, the entry cross-references it. Different content, one pointer, not a double-carry.

**4. Row 3 — KEEP `state` in the key**, and put your totality line in the workflow comment nearly verbatim: *a group is working iff event ≠ deployment_status or (environment = Production and state = success); the key contains exactly those three discriminators, so a working run and a skipped run can never share a group for any value Vercel might emit, including states never yet observed.* The comment also states that in the 62-status corpus `state` is constant and does no discriminating today — so a future reader knows it's a totality property, not a live distinction.

**5. Row 9 — YES, run the collision pre-FF as well**, with one mechanical change: the mid-crawl Preview event comes from a **scratch branch cut from the 685-review tip** (it carries the new yaml, so per your own finding its run executes the new key), never from an empty commit on the review ref itself — the ref fast-forwards to `main` and must stay clean. STEP 5.5 remains the authoritative gate; the pre-FF pair is quoted as corroboration. Delete the scratch branch after each use.

**Correction back — the transition hazard runs old↔old only, not old→new.** Row 9's closing claim ("a deployment_status from a commit without the fix resolves to bare `e2e-prod` and can still cancel a new-yaml run") is wrong on the mechanism: `cancel-in-progress` cancels occupants of the **same group**, and group matching is exact-string — `e2e-prod` and `e2e-prod-workflow_dispatch-na-na` are different groups, so an old-yaml run can never touch a new-yaml run. The transition residual is only that deploys of pre-fix commits keep pre-fix behavior **among themselves**, bounded by the FF and by concurrent sessions' branches until they rebase past it. State that in one line of the STEP 1 comment; no warning beyond it.

**Also endorsed:** row 7's cross-ref repair — name the entry ("the `e2e-prod.yml` global concurrency group WATCH"), never a line number, and record that `:448` was wrong **when written**, not drifted; row 1's figure correction into the strike; row 8's accounting (3 crawls / 222 documents) into the `:448` and `:50` notes; the skipped-job timestamp inversion stays paste-record only. The concurrency block cite is `:31-33` and the yaml gate is the first dispatch, per your corrections.

**Amended STEP 2 (pre-FF), replacing the handoff's:**

1. Push `refs/heads/685-review`; note its own Preview run's conclusion (`skipped`, new yaml, Preview group).
2. Dispatch on `685-review`; quote the echo line's resolved group.
3. Mid-crawl, push `685-scratch` cut from the 685-review tip → Preview event → skipped run in `…-Preview-success`. The dispatch must complete green, uncancelled. Quote both conclusions.
4. Delete `685-scratch`.

Proceed: STEP 1.
