# HO 715 — can MIA see missed committee votes? A diagnostic-only probe of the upstream, no product code

Probe kind (SKILL § External data sources: probe → wire; the diagnostic-only handoff first). Corey's first question of this arc: *"the mia — are we taking into account missed committees?"* The answer was no, with the upstream as the reason: MIA reads floor roll calls from `member_votes`; committee attendance is recorded nowhere on a useful clock; the only recorded committee absence is a name on a markup roll call, which committees publish each in their own shape. This HO measures that shape instead of asserting it. **It writes no product code, no schema, no sync.** Its output is a findings file, one ledger decision line for Corey, and the block.

**What "missed committee" can and cannot mean, stated before measuring.** Hearing attendance is not recorded by any timely source (GPO transcripts list who was present, a year late). House Rule XI cl. 2(e)(1)(B)(i) requires each committee to post the result of every record vote — names, yeas, nays, present-not-voting — within 48 hours, on its own site; the Senate has no equivalent rule and committee votes surface in committee reports. So the only measurable object is **the markup roll call**, and a "missed committee vote" is a member of the committee recorded not voting on one. That is the unit this probe counts.

## Ground truth at authoring (`main` at `9077492`, 2026-09-11; re-derive at STEP 0)

- **Number.** Pointer 713 → 714 is the band HO authored alongside; this is 715. Independent.
- **What the repo already has.** `committee_meetings` (`scripts/migrate.ts:712-725`: `event_id, congress, chamber, meeting_date, meeting_type, meeting_status, title, location_*, video_url, committee_system_code, update_date`) filled by `lib/meetings-sync.ts` from Congress.gov `committee-meeting/{congress}/{chamber}` list + detail (`:105`, `:151`); the detail type `ApiMeeting` (`:130-144`) models `videos` and `relatedItems.bills` and **discards everything else the payload carries**. `committee_members` is a roster. `member_votes` is floor only. Nothing about committee votes exists.
- **The Congress.gov side is a fact to measure, not recall.** The meeting detail payload may carry a `meetingDocuments[]` array with typed documents; whether any type names a vote tally, and whether the URLs point at committee-hosted PDFs or at the House Committee Repository (`docs.house.gov`), is row 1. The repo's meetings sync already pays for every detail fetch and throws this array away, so the first reading costs nothing new.
- **The House Committee Repository** (`docs.house.gov/Committee`) publishes per-meeting document packages; markup vote records appear there for some committees as uploaded PDFs. Whether it exposes them in a listable, typed form is row 2. Committee sites (`judiciary.house.gov`, `energycommerce.house.gov`, …) each post their own; ~20 standing committees, formats unknown until read.
- **Rate of the object.** House standing committees held on the order of hundreds of markups in the 119th; each markup can carry from zero to dozens of record votes. The yield in *member-not-voting rows per year* is the number this probe exists to produce, because it decides whether a scraper arc is worth building.
- **Absence Watch's shape.** Phase A is a window of 8 floor roll calls per chamber; a committee-vote signal would be a different clock (a committee may hold three markups a month or none), so "missed committee votes" cannot ride the existing streak. It would be a third tier or a separate readout, and that design is not this HO's — the probe only says whether the data exists to design against.

## STEP 0 — the probe

Raw payloads and per-row readings under `docs/handoffs/715-artifacts/`; nothing written to the database; every fetch counted against the Congress.gov key's budget and the count pasted.

| # | probe | what it answers |
|---|---|---|
| 1 | for 119th House meetings with `meeting_type = 'Markup'` in `committee_meetings`, sample 60 event ids stratified across committees (≥ 2 per committee where available); fetch each detail; histogram `meetingDocuments[].documentType` (or whatever the field is named — quote the raw key) and, for any vote-shaped type, the URL host | does Congress.gov already carry a vote-document pointer per markup, and for what share of markups |
| 2 | for the same 60, the Committee Repository package: document list by type; is a vote record present, and is its URL the same the API returned | whether `docs.house.gov` is a second index or the same one |
| 3 | download up to 3 vote PDFs per committee where any exist (≤ 40 files); classify each: text-extractable vs image; layout family (roll-call grid with names down the side, narrative "Ayes: … Noes: … Not voting: …", per-amendment tables); whether member names are full names, surnames, or "Mr. X" | the parse-feasibility class per committee |
| 4 | from the parsed sample, count record votes per markup and not-voting names per vote; scale by the 119th's markup count per committee (from `committee_meetings`) | the yield estimate: member-not-voting rows per year, per committee and total |
| 5 | Senate: for 119th Senate `committee-report`s, does the text carry a *VOTES OF THE COMMITTEE* section, and in what share of reports; one sample parsed for names | whether the Senate side has a comparable object at all, and its lag |
| 6 | name resolution: for the parsed sample, match names to `committee_members` (bioguide) for that committee — hits, misses, ambiguities | whether the join to members is honest without a crosswalk |
| 7 | the rule: House Rule XI cl. 2(e)(1)(B)(i) quoted from the current rules text, with the 48-hour clock and the present-not-voting clause | so the SKILL entry cites the obligation, not a memory of it |
| 8 | budget: total Congress.gov requests made and the key's daily ceiling; total bytes downloaded | the probe's own cost |

**HALT with a findings file** (`docs/handoffs/715-artifacts/findings.md`, and a copy delivered to chat by the review-ref route): coverage share, format classes per committee, parse feasibility, yield estimate with its uncertainty, the Senate answer, the name-resolution rate, and a one-paragraph sizing of the scraper arc it would take (committees × formats × a parser each, the 48-hour clock as the sync cadence, the join). No recommendation on whether to build; that is Corey's line.

## STEP 1 — docs only

- **`docs(skill)`** — External data sources: a *Committee markup votes (probed HO 715)* entry recording what exists upstream, the rule that obliges it, the formats found, and the yield, so the next person does not re-probe.
- **`docs`** — backlog: **one decision line for Corey** — *build the committee-votes arc, or not* — carrying the findings' figures and the design note that it cannot ride Phase A; strike nothing. Oddities only if the probe finds one (a document type that lies, a PDF that is an image of a spreadsheet). Roadmap block with the readings.

## STEP 2

`check:design-citations` is the only gate; no code moves. The findings file is the deliverable and is read on the ref before it lands.

## Paste-back

The eight readings with their counts; the findings file in full; the request budget line; the SKILL and docs diffs with numstats; `git ls-remote --heads origin`.

read and follow 715
