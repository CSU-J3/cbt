# HO 752: has the committees cursor lost anything? A read-only probe of the bills and meetings watermarks, with Congress.gov as the authority

`docs/backlog.md` OPEN LOOPS, *The committees cron's bills cursor moves past a bill whose fetch or write failed…* (HO 744), owner Code, medium. The line was read in code at `252411f` and never measured. Nobody knows how many bills or meeting events the two watermarks have lost, or whether they've lost any, and every tick that could have lost one recorded `success`.

It was written as the next probe on 2026-09-25 (*"lest do that and keep order"*), held while the ballot work took its dated turn (HO 747 to 751), and reissued with the tree's number now that `main` is at `d25e6c8`. It's the HO 745 shape applied to a second watermark: 745 found the Senate vote watermark real and unfired, and the remedy came one HO later on its numbers.

**This HO measures. It builds nothing.** No product code, no write to prod, no POST to `/api/cron/committees`, and no call to `syncCommitteeBills` or `syncMeetings` against prod: both write, `skipCursorAdvance` included. The remedy, if one is owed, is the next HO, and which remedy is a review call made on these numbers.

## Ground truth (read at `d25e6c8`; re-derive every `:N` by content)

`git diff --stat 252411f..d25e6c8 -- lib/committees-sync.ts app/api/cron/committees/route.ts lib/meetings-sync.ts lib/sync.ts lib/cron-log.ts` prints nothing, so every anchor the backlog line carries in those files still points where it did. `vercel.json` gained the general-ballot cron (7 lines), which moves its anchors; `scripts/migrate.ts` gained HO 749's and HO 751's additions after the committee tables, which doesn't.

- `lib/committees-sync.ts`
  - The walk selects `congress = ? AND update_date > ? AND json_extract(raw_json, '$.committees.count') > 0`, ordered `update_date ASC, id ASC`, with a `LIMIT` (`selectBillsSince`, `:164-186`). The cursor is the `dashboard_state` key `committee_bills_sync_cursor` (`:47`), a bare timestamp (`:145-162`).
  - `syncCommitteeBills` (`:226`) selects once (`:232`), then fetches and upserts each bill inside one `try` (`:243-245`). The `catch` counts and warns (`:246-248`), and `billsProcessed++` and `cursorEnd = bill.updateDate` run either way (`:250-251`). The cursor is written once, after the loop (`:253-255`). The deadline break is `:239-241`, and `perTickLimit` defaults to 500 (`:230`).
  - The per-bill fetch is `/bill/{congress}/{type}/{number}/committees` with an 8s abort (`:188-193`, `:43`). `upsertCommitteeBills` (`:195`) writes one row per committee activity, or one null-activity row, and skips a committee with no `systemCode` (`:202-204`). It never deletes, and it is the only writer of `committee_bills` (`:207`; `git grep` finds no other).
- `app/api/cron/committees/route.ts`: the bills deadline is 45s from route start (`:35`, `:74-76`) and the meetings deadline 50s with `perTickLimit: 300` (`:40`, `:86-89`). `payload.bills` and `payload.meetings` ride the success payload (`:119-130`), and fetch errors reach `chronicErr` only as counts (`:134-148`).
- `lib/meetings-sync.ts`
  - `collectNewEvents` keeps `r.updateDate > watermark` and stops at the first event at or below it (`:97-127`).
  - The driver's `catch` counts, then `processed++` and `cursorEnd = item.updateDate` run either way (`:344-362`). A 200 with no `committeeMeeting` returns `null` (`:160`) and still advances the cursor. `getJson` retries non-HTTP failures up to eight times (`:31-32`, `:52-66`).
  - The per-chamber watermark is `meeting_sync_state` (`:70-87`). The stored `committee_meetings.update_date` is the DETAIL's `updateDate` (`:275`), while the watermark advances on the LIST's (`:362`). `upsertMeeting` is the only writer of `committee_meetings` (`:249`).
- `lib/cron-log.ts`: a success row stores `{ ok, elapsedMs, payload }` (`:166-167`), so the bills stats sit at `$.payload.bills.*` and the meetings stats at `$.payload.meetings.*`. An `error` or `timeout` row stores no handler payload (`:171-183`).
- Schema (`scripts/migrate.ts`): `committee_bills` `:550`, with `UNIQUE(bill_id, committee_system_code, activity_type, activity_date)` and an index on `bill_id` (`:559`); `committee_meetings` `:715`; `meeting_sync_state` `:770`; `dashboard_state` `:83`.
- Schedules (`vercel.json`): `/api/cron/committees` at `0 */12 * * *` (`:77-78`) and `/api/sync` at `0 */6 * * *` (`:61-62`), so both fire at 00:00 and 12:00 UTC.
- Estimates from the line, which this HO replaces: 6,250 of 18,305 119th bills share an `update_date` (1,758 groups, max 135), and 24 of 47 read `success` ticks in 30 days had `bills.deadlineHit`, with about 13 ticks unread. Those figures cover every 119th bill, not the walked set.

## STEP 0

1. HO number from the tree. This file assumes `main` at `d25e6c8` (HO 751 landed, pointer 751), so this is 752. If the tree says otherwise, stop and say so rather than take a number.
2. Re-read the cited `:N` at HEAD by content. Flag a drift; don't absorb it.
3. Read one `/api/cron/committees` success row's payload and confirm the paths: `$.payload.bills.cursorStart`, `cursorEnd`, `billsProcessed`, `deadlineHit` and `fetchErrors`, and `$.payload.meetings.perChamber.{house,senate}.cursorEnd`, `fetchErrors` and `deadlineHit`.
4. Print the bills cursor, both meetings watermarks, and the newest `/api/cron/committees` and `/api/sync` rows.
5. Confirm local egress to `api.congress.gov` with `CONGRESS_API_KEY` from `.env`, referenced by name only (method.md § Environment). Print the status, never the URL. If local egress is refused, stop and say so.
6. Proceed without a halt unless something above contradicts this file.

## The instrument: `scripts/diagnostic/committees-cursor-752.ts`

Read-only against prod: SELECTs, and GETs to `api.congress.gov` in the sync's own URL shapes. The bill-committees fetch (`:189`) isn't exported, so copy it and cite it. Space the GETs at least 200ms apart and cap the run at 1,000; say what the cap cut if it binds. A 429 stops the run, with a report of what was read. Every string that could carry a URL goes through `redactSecrets` (`lib/redact.ts:92`) before it's printed or written to an artifact.

1. The no-row candidates: the walked set at or below the cursor with no `committee_bills` row.
   ```sql
   SELECT b.id, b.update_date FROM bills b
   WHERE b.congress = 119 AND b.update_date <= :cursor
     AND json_extract(b.raw_json, '$.committees.count') > 0
     AND NOT EXISTS (SELECT 1 FROM committee_bills cb WHERE cb.bill_id = b.id)
   ```
   Also count the walked set above the cursor, which is pending rather than lost. If the query breaches the client's bound, chunk it by `update_date` month and say so.
2. Resolve each candidate against Congress.gov by fetching its committees endpoint. A candidate is `lost` when the endpoint lists at least one committee with a `systemCode`, since `upsertCommitteeBills` would have written a row for it. It is `empty` when the endpoint lists none (the `:203-204` skip, which is not a loss), and `error` when the GET fails. If there are more than 500 candidates, take a seeded random 500 and report the sample size beside the full count.
3. Attribute each `lost` bill to a path from the tick history. Read every `/api/cron/committees` row, with the bills stats from each success row. For a lost bill with `update_date` U, find the success tick whose `(cursorStart, cursorEnd]` holds U.
   - `truncation`: U equals that tick's `cursorEnd`, and the tick stopped early (`deadlineHit`, or `billsProcessed` at the limit).
   - `failure`: the tick had `fetchErrors > 0`. Inside the runtime-log window, read the tick's `[committees] bill … fetch failed` lines and say whether they name the bill. A log zero counts only once a control string known to be in the same window comes back (method.md § Gates, HO 678). Outside the window it stays a candidate.
   - `race`: U sits strictly inside the range of a tick with no early stop and no fetch errors, so the bill wasn't in that tick's select. That is the `/api/sync` path the line describes: written below the cursor after the walk passed.
   - `unattributed`: no success tick's range holds U, because of a `timeout` hole or because U predates the history.
   This is a reading of the payloads, not proof of mechanism, and the paste says so.
4. The stale class: a seeded random sample of 200 walked-set bills at or below the cursor that do have rows. Fetch each endpoint and list every activity (committee, name, date) with no matching row. Split the stale activities by whether the activity's date is at or before the bill's stored `update_date`, which the walk at that date should have seen, or after it, which means the stored date is behind Congress.gov. The second is `/api/sync`'s frontier, not this cursor's.
5. Meetings. Fetch each chamber's list (`committee-meeting/{N}/{chamber}`, every page) and save it. Compare every event at or below that chamber's watermark with `committee_meetings`:
   - `current`: the row's `update_date` equals the list's;
   - `older`: the row's is older, so a later update was passed over;
   - `newer`: the row's is newer, so the list and the detail disagree;
   - `missing`: no row. Fetch the detail for each: a `committeeMeeting` makes it `lost`, a 200 without one puts it in the `null-detail` class (`:160`), and a failure is `error`.
   Events above the watermark are pending. Then take 50 `current` events at random plus every `older` and `newer` one, fetch their details, and report how often the list's `updateDate` equals the detail's. The line's own diff assumes they agree, and nothing has checked.
6. The census the line carried, re-derived over the walked set: same-`update_date` groups (count, bills in them, largest); success ticks in the last 30 days with `deadlineHit`, with `billsProcessed` at the limit, and with `fetchErrors > 0`; and the tick count by status, so the unread ticks are named.

Run it between ticks: `/api/sync` fires every six hours on the hour, and the committees cron at 00:00 and 12:00 UTC. Read the cursor, both watermarks, and the newest row of each route before and after. If any moved, re-read the database and report both readings.

## Controls, seen red before the prod reading

They run on a `file:` copy seeded from prod the way HO 745's control seeded its copy: only the rows the probe reads (for `bills`, the `id`, `congress`, `update_date` and a minimal `raw_json` carrying `$.committees.count`), the URL built as `file:${abs}` by construction, and a perturbation step that refuses any URL that isn't `file:` and prints the scheme it ran against. Read each control unperturbed and perturbed. The delta is the reading.

1. The candidates and their resolution together. Pick a walked-set bill at or below the cursor that has rows and whose endpoint lists a committee, and name it. Delete its `committee_bills` rows on the copy. Expected: candidates +1, and that bill classified `lost`.
2. The pending boundary. Move a second bill's `update_date` above the copy's cursor. Expected: it leaves the candidates and counts as pending.
3. The stale class. Delete one activity row of a sampled bill. Expected: that bill reads stale, naming the activity.
4. Meetings. Delete one event row below a watermark, and set another row's `update_date` a day older. Expected: `missing` +1, then `lost` on its detail, and `older` +1, both from the saved list with no refetch.
5. Attribution. Feed the attribution function four synthetic ticks, each built to land a bill in one of `truncation`, `failure`, `race` and `unattributed`. Expected: each lands where it was built to.

If any control misses, the instrument is wrong. Stop.

## The prod reading

Name the rows it follows. The tables, as the backlog annotation will carry them:

- bills: cursor · walked set · pending above · candidates · `lost` · `empty` · `error` (and the sample size, if sampled);
- `lost` by path: `truncation` · `failure` (confirmed from logs, or candidate) · `race` · `unattributed`, with every bill id in the artifact;
- the stale sample: bills sampled · bills stale · activities missing, split at-or-before and after the stored `update_date`;
- meetings, per chamber: watermark · events at or below · `current` · `older` · `newer` · `missing` (then `lost`, `null-detail`, `error`) · pending; and the list-versus-detail agreement rate;
- the census, re-derived.

Per-bill and per-event CSVs, the saved lists and `requests.log` go to `docs/handoffs/752-artifacts/` (repo-ignored).

## What follows the reading (review calls, not Code's)

- `lost` is zero everywhere and the stale sample is clean: the mechanism is real and unfired, as HO 745's was. The line stays open with the reading, and whether to build the remedy before it fires is a review call.
- `lost` is above zero: the remedy is the next HO, and this one lists what its repair pass has to fill. The candidate remedies are the line's own, a keyset cursor on `(update_date, id)` and a retry set. The path split says which of them the losses need, and `race` needs something neither of them gives.
- The list-versus-detail agreement rate decides whether the meetings half of the close can use the line's diff at all.

## Commits and docs

- `diag(HO 752)`: the script.
- `docs(HO 752)`: annotate the committees line in place with the reading, the rows it follows and the controls, and add the roadmap block, pointer 751 → 752, carrying HO 751's post-FF reading (`docs/handoffs/751-artifacts/post-ff-reading.md`) as HO 751's block carried HO 750's. No SKILL change and no new lines. If the reading finds something outside the line's mechanism, flag it in the paste-back before filing anything.
- Reconcile OPEN LOOPS at open and close, the control `^- \*\*~~` at 0 both times: 260 live / 306 struck / 566 at `d25e6c8`, unchanged at close. Expected backlog `--numstat` 1+/1−: the one line rewritten in place.
- Review ref `752-review`. The FF is held for review.

## Gates

The cheap gates: `npm run typecheck`, `npm run check:odds-sites` and `npm run check:design-citations`. No served bytes change, so no captures and no Preview reading are owed.

## Paste back

- STEP 0's readings;
- the five controls, unperturbed and perturbed;
- the tables, and the rows read before and after;
- the GET budget used, and a grep of the artifacts for `api_key=` reading 0 beside a control line that reads 1;
- `git show --stat` per commit, and `--numstat` (the deletions column, not a grep);
- the review ref's SHA from `git ls-remote`;
- a last cheap-gate run immediately before the paste, with the reading named.
