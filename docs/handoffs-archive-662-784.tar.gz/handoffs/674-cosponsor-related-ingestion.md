# HO 674 — the cosponsor and related-bills ingestion: two rosters, one sub-resource pattern, priced before it is built

**Read this file in full before executing anything. Execute in order. HALT conditions are hard stops — report and wait, do not improvise past them. Four HALTs: the STEP 0 pricing table, the bounded-slice measurement, the full-backfill authorisation, and the pre-land review ref. Nothing lands on `main` before the last is approved.**

Base: `main` at `15f3af4` (HO 673 landed) or later. Clone fresh; verify HEAD before starting (`docs/method.md` § Session start). Number per method: max(roadmap pointer 673, highest commit-subject 673) + 1. Environment: code edit + `npm run build` then `npm run typecheck` (build first), plus **network access to the Congress.gov API** and **write access to the DB** for the bounded slice. **Bind check mandated on any local server start.** `docs/method.md` § Gates applies in full — this HO is not render-touching, but it is write-heavy, and *a write instrument that does not read back is not an instrument.*

## What HO 673 measured, and why this HO exists

HO 673 was written as three UI rulings. Two of them had nothing to render, and that was established by measurement rather than inference:

- **Cosponsor roster — absent.** 50 `CREATE TABLE` statements in `scripts/migrate.ts`, none a cosponsor roster (control: the amendments table grep returns 1, so the grep discriminates). The only artefact is `bills.cosponsor_count`, an INTEGER at `migrate.ts:1389`. `lib/sync.ts:42` types the API as `cosponsors?: { count?: number }`. `scripts/backfill-cosponsors.ts` is pure SQL extracting `$.cosponsors.count` — no roster, no API call.
- **Related bills — absent.** Zero `relatedBills` / `related_bill` hits in tracked code. Probe against prod: `relatedBills` present on **6,773 of 17,722** bills as `{count, url}`; identities not in `raw_json`. Control: `cosponsors.count` reads 17,722 total / 13,922 with cosponsors, so the instrument works.
- **Both sit behind the identical per-bill sub-endpoint shape.** That is what makes this one data-domain HO rather than two.

Rulings 2 and 3 (cosponsor faces party-split; related bills format R2 with the companion promoted) are **blocked on this HO** and their mocks stand as the ruling record. **This HO ships no UI.**

## Scope

In: `scripts/migrate.ts`, the sync/fetch layer for two sub-resources, a backfill script, and whatever query surface the later UI HO will need — **but only if STEP 0 shows the query is trivial**; otherwise queries are the UI HO's business.

**Out, named so it is not absorbed:**

- **Every component and every route.** No render surface changes. If a panel would show a roster the moment the table has rows, that is a *later* HO's ruling to make, and it must not happen by accident — STEP 0 states explicitly whether any existing consumer would start rendering new data on its own.
- `mock-673-*` and `mock-674-topic-colour.html`. The latter's filename predates this numbering; the topic-colour work lands under whatever number it draws. Do not rename it, do not build it.
- The `docs/design/` tracking policy, the non-atomic summarize write pair, the nine remaining `if (await X.count())` e2e guards, `HeaderBar` `IN BETA` + clock, `--font-mono` → Plex Mono, the `/welcome` tape unification, `/api/version`'s `builtAt: null`. All filed, none due.

## STEP 0 — enumerate and **price**; HALT

This is the largest STEP 0 in recent memory and it is the point of the HO. **Nothing is created until the table is approved.** Controls first, everywhere.

### 0.1 The existing sub-resource pattern — does one exist?

Does anything in `lib/sync.ts` or elsewhere already fetch a **per-bill sub-endpoint** (actions, textVersions, committees, amendments, titles)? If yes, that is the pattern to follow and the table names it with `file:symbol`. If no, say so — this HO establishes the pattern and that raises its stakes.

Also: how does the sync currently page a list endpoint, and what is the max page size it uses?

### 0.2 The API budget — the number this HO lives or dies on

- The rate limit on the Congress.gov key, **read from documentation or a measured 429**, not assumed.
- Requests already spent per sync cycle, and what headroom remains.
- **The backfill's request count, computed:** cosponsors on the bills that have them (13,922 measured) plus related bills (6,773 measured), **times pagination**. Cosponsor lists exceed one page — the corpus is known to contain a bill with **402** cosponsors — so state the page size, the resulting page count distribution, and the total. A single number with no pagination term in it is wrong.
- **Wall-clock estimate** at the rate limit, and whether the backfill must be resumable across sessions. If the answer is more than an hour, it must be.

### 0.3 Schema — two tables, and the questions that decide their shape

Propose `bill_cosponsors` and `bill_related_bills`. For each, state:

- Columns, types, PK, and the FK to `bills`.
- **Ordering.** Cosponsor order is meaningful (original vs later cosponsors, and the API returns a `sponsorshipDate`). Does the roster need a sequence column, or is `sponsorshipDate` sufficient? Ties?
- **Withdrawn cosponsors.** The API exposes `sponsorshipWithdrawnDate`. A roster that silently drops withdrawals is wrong; one that shows them without marking them is worse. Decide and record.
- **The relationship type on related bills** — the field name and the observed value set, read from a real response, not guessed. This is what ruling 3's companion promotion depends on, and HO 673 flagged that an *inferred* companion claims more than the data supports. **If the API returns an explicit relationship type, name it and its values.** If it does not, that changes ruling 3 and the UI HO must be told.
- Indexes, with the query they serve.
- Row-count estimate for each table at full backfill.

### 0.4 Refresh — when does a roster go stale?

Cosponsors accrue continuously; related bills appear late. State the trigger: `update_date` moving, `cosponsor_count` changing against the stored roster size, a TTL, or a combination. **A count/roster mismatch is a free integrity check** — it should be named here whether or not it is used as the trigger.

### 0.5 Cost, measured not modelled

- Rows written at full backfill, per table.
- The steady-state per-cycle cost of the refresh rule from 0.4.
- **Cache tags.** Any new query these tables serve — which tag, and therefore which flush cadence. HO 671/672 measured that a `bills`-tagged entry costs ~89,090 rows per flush at ~7.3 flushes/day; adding rosters to a `bills`-tagged query moves that number. If the answer is "no query lands in this HO", say so and the question defers.

### 0.6 The accidental-render check

Grep every place that reads `cosponsor_count` or would plausibly read a roster. **Does any existing surface change behaviour the moment these tables have rows?** Answer with the grep and a control. A "no" here is the thing that lets this HO ship without a UI ruling.

### 0.7 Out-of-scope confirmations

Confirm nothing under `components/` or `app/` is touched, and that `bills.cosponsor_count` is left alone (the roster does not replace it in this HO; a count column and a roster disagreeing is a *later* reconciliation, and forcing it here doubles the blast radius).

**HALT.** Paste the table. If 0.2's arithmetic comes back at a scale that makes the backfill a multi-day operation, that is a finding and the HO's shape changes — say so rather than starting a job that cannot finish.

## STEP 1 — the chore commit (after the table is approved)

`git checkout -b 674-review-local` first. One commit, one kind:

`chore(HO 674): cosponsor and related-bill rosters — schema, fetch, backfill`

Schema, the sub-resource fetch, and the backfill script. **The backfill is a write instrument and carries the HO 673 treatment:** a header naming exactly what it writes, and **read-only by default** — bare invocation and `--check` report what *would* be written; `--write` is required to mutate. A flag you must remember in order NOT to write is a flag that will be forgotten exactly once.

It must also be **resumable and idempotent**: re-running over an already-backfilled bill produces no duplicate rows and no second API call, proven in STEP 2 rather than asserted.

## STEP 2 — the bounded slice; HALT

**Do not run the full backfill.** Run **50 bills**, chosen to include the hard cases and named in the paste:

- a bill with **zero** cosponsors,
- a bill with **more than one page** of cosponsors (the 402-cosponsor bill is the obvious candidate),
- a bill with a **withdrawn** cosponsor if one can be found, and how you established it if not,
- a bill with related bills, and one with **`relatedBills.count > 0` but an empty list** if such a case exists,
- a bill with **no** related bills.

Report, with read-back on every write:

- Rows written per table; API requests spent; wall clock.
- **Idempotency proof:** run the same 50 twice; the second run writes 0 rows and spends 0 requests, against a control showing the counter can go non-zero.
- **The count cross-check:** stored roster size against `bills.cosponsor_count` for all 50. Disagreements are a *finding*, not a bug to paper over — the count column and the roster are independently sourced and a mismatch means one of them is wrong.
- The relationship-type value set actually observed.

**HALT.** The full backfill is a separate authorisation and I will give it against these numbers.

## STEP 3 — the full backfill, only if authorised

Resumable, progress reported, request count tracked against the rate limit, and a **final read-back**: total rows per table, bills covered, bills skipped and why, and the count cross-check across the whole corpus with the disagreement rate stated as a fraction.

## STEP 4 — docs commit (`docs: HO 674 — …`)

- **`docs/backlog.md`** — strike the ingestion entry opened at HO 673 **only if** the full backfill ran and the close criterion is met (*a named bill's cosponsor roster and related-bill identities readable from the local DB without a network call* — name the bill and show the read). If only the slice ran, the entry stays open and records where it got to. Open entries for: the count-vs-roster disagreement rate, and anything 0.3 could not resolve.
- **`docs/roadmap.md`** — one `Also (HO 674)` block, append-only: the measured API arithmetic, the schema and the two decisions behind it (ordering, withdrawals), the relationship-type finding and **what it means for ruling 3**, the backfill numbers, and the idempotency proof.
- **`docs/oddities.md`** — only if something odd emerged; if nothing, say so in the block.

## STEP 5 — SKILL commit (`docs(skill): HO 674 — …`), self-mod guarded

Its own commit. Minimal edits. Expect the `cosponsor_count` claim — *"the list isn't stored, so count-only"* — to be **falsified by this HO** and to need rewriting rather than appending, plus a new entry for the sub-resource pattern if 0.1 shows this HO establishes it. Classify every hit LIVE-CLAIM vs RECORD first. **No changelog append** unless client-island membership changed, which it does not here.

## HALT — the review ref

`git push origin HEAD:refs/heads/674-review`. Paste: table deltas, `git show --stat`, the STEP 2/3 measurements, the backlog numstat with every deletion explained, and the docs + SKILL diffs.

**Deliver the SKILL diff with `--word-diff=plain`, verify it carries markers before offering it, write it to the gitignored artifacts directory, and tell Corey explicitly to attach it to the chat.** Writing the file is not delivering it.

Remote claims via `git ls-remote`. **The SKILL diff needs explicit approval.** After approval: fast-forward `main`, delete the ref, verify with `git ls-remote --heads origin`.

---

read and follow 674
