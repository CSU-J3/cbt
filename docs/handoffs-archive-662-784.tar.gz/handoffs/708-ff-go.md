# HO 708 — FF go (architect, 2026-09-10)

**Owner verdict, verbatim: "ok send it?"** — Corey, CBT maintenance chat, 2026-09-10, against the architect's read of `708-review` at `918b52b`. The question mark is read as the go: it followed the architect's request for the word and Corey's own question about what to tell Code, and the verdict is recorded as written rather than tidied. Read at `918b52b`, off the remote: three commits, kinds pure (`docs(HO 708)` · `docs(method)` · `docs(skill)`); numstat backlog 1/1, oddities 12/0, roadmap 20/0, method 21/3, SKILL 1/1; `:14`'s original body a strict prefix of the re-emitted line (1,188 chars inside 3,485), proven by comparison rather than by eye; the § Gates header reading twelve with the new clause spliced where ruled and the three deletions being the paragraph's hard wraps re-flowing; the HO 708 bullet verbatim; SKILL `:2577` naming the same ten files `git ls-files e2e playwright.config.ts` returns at that SHA. The SKILL slot is filled on `918b52b` as read.

Both departures on the SKILL line accepted: the check command cited on the line itself, and the stated consequence of a third drift. A list that says it is exhaustive and has drifted twice in fourteen HOs should carry its own audit command.

## 1. The move

- `git ls-remote --heads origin` immediately before: `main` at `61eab63`, `708-review` at `918b52b`. If either differs, stop and paste.
- Standing on `main`, the cleanup door: `git merge --ff-only 918b52b`, then `git rev-parse main` must print `918b52b…`. Then `git push origin main`, no force. Then `git push origin --delete 708-review`. Then `git ls-remote --heads origin` and `git ls-remote --tags origin` (three tags, unchanged).
- Each state-changing command on its own line, stderr never suppressed; the commit list read off the remote.

## 2. The readings after the move

- **`ci.yml` does not fire.** Docs-only under `paths-ignore`; its absence is expected and is stated, not investigated. `design-citations.yml` already ran on the ref push: quote its id and conclusion.
- **The Production `deployment_status` `smoke` run for `918b52b`:** id, conclusion, the resolved-group echo, and the per-route `pageErr=` lines. It is an extra sample on the shipped Turbopack build and **is not one of the seven** `backlog:51` is counting; a `#418` in it is still a `#418`, and reopens HO 705's report path with the per-hit line, same as in a daily.
- `npm run verify:deploy`, five consecutive reads.

## 3. The count

Today is the 10th, and the first daily of the seven fires at 15:00Z. The FF changes no app bytes (three docs files and one SKILL line), so whichever side of 15:00Z the deployment lands, the daily reads the same build and counts as day one. Quote its id and per-route `pageErr=` lines when it exists, as its own item, apart from the `deployment_status` sample above. Nothing in this HO alters what the daily runs.

## 4. Paste

The `ls-remote` line showing `main` at `918b52b`, the ref gone, three tags; `git rev-parse main`; the five served reads; the `design-citations` run; the Production `smoke` run with its per-route lines, labelled as the extra sample; and the first daily's id and lines if it has fired by then. Then hold: HO 709 arrives as a file.

read and follow 708-ff-go — the file, not this line
