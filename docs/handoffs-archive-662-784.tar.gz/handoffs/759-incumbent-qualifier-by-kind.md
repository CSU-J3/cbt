# HO 759: the incumbent who isn't on this ballot, ruled C. A tag by kind, with the reason where the data has one; the Louisiana header; the two ruling mocks committed

`docs/backlog.md` OPEN LOOPS, *A race card names a stored incumbent who is not on that seat's 2026 ballot, with no NOT RUNNING fact beside the name…* (HO 747), owner Corey for the copy. Ruled 2026-09-29 on `mock-moved-incumbent.html`, verbatim: *"C"*: by kind, RUNNING IN <seat> / RUNNING FOR SENATE / NOT ON THE BALLOT, and where the data carries a reason, RETIRING / WITHDREW / LOST PRIMARY in its place. HO 758's STEP 0 counted 94 such incumbents over 461 box races.

Also in this HO, approved 2026-09-29: the Louisiana header (a roster with no majors reads *On the ballot*, not *Also on the ballot*), and the two ruling mocks committed under `docs/design/` as the rulings' records (`mock-election-night.html`, already on disk there; `mock-moved-incumbent.html`, dropped there by Corey).

## Ground truth (read at `d8f1a0a`; re-derive every `:N` by content)

- The kinds are in the data already. `lib/ballot-incumbent.ts` (HO 750) finds a stored incumbent on their own ballot by identity, then underline and surname; `general_ballot.bioguide_id` ties a row to a member by title identity (HO 751 resolved every 2026 incumbent printed anywhere). A stored incumbent printed in another House race of the state, or in an `S-` race, is an `on_ballot = 1` row there with their bioguide. `withdrawn = 1` rows carry a withdrawal from a ballot. `races.incumbent_running = 0` is the curated retirement (HO 221, HO 718: with `open_signal_date` and `open_signal_url`), rendered today as the NOT RUNNING tag. `primary_candidates` holds each 2026 primary's candidates with `status = 'winner'` for marked rows; a decided primary is one with a winner.
- The surfaces that name a 2026 race's incumbent: the race page's incumbent card (`components/RaceHubBody.tsx`), and the compact cards, which STEP 0 enumerates (`CompetitiveRacesBlock`, the `/electoral` strip and district card, the pinned card).
- HO 758 added post-election qualifiers to the card (*re-elected*, *defeated*, *not on the ballot*, *runoff Dec 12*) behind `clockNowMs()`; before election day the card shows only the curated NOT RUNNING.
- The roster header: `components/RaceCandidates.tsx` prints *Also on the ballot* above the `on_ballot` block whenever it exists, including Louisiana's six, whose rosters have no majors block.

## STEP 0

1. HO number from the tree: `main` at `d8f1a0a`, pointer 758, so 759. Otherwise stop.
2. Re-read every cited `:N` by content. Flag a drift.
3. Measure, prod, SELECTs only, the 94 by kind: printed in another House race (with the seat), printed in a Senate race, on no ballot; and the no-ballot set by reason: curated `incumbent_running = 0`, in a withdrawn block anywhere, an unmarked row in a decided 2026 primary matched by bioguide AND normalized full name, else absent. Name the six mock cases' readings (TX-35, IA-02, TN-09, NC-11, TX-09, and one absent) and any incumbent that falls in two kinds.
4. Enumerate the compact surfaces that print a 2026 incumbent's name.
5. Carry HO 758's FF-go readings and HO 756's 06:05Z tick into this HO's roadmap block.
6. Proceed without a halt.

## The build

1. One function, `incumbentQualifier(raceId)`, cached under the `general-ballot` and `races` tags, returning the kind and the reason:
   - kind first: `moved` (a row with the stored bioguide in another House race of the state, with that race id), `senate` (a row in an `S-` race, with its id), else `none`;
   - for `none`, the reason in this order: `retiring` (curated `incumbent_running = 0`), `withdrew` (the bioguide's key in any 2026 withdrawn block), `lost_primary` (an unmarked row in a decided 2026 primary, matched by bioguide and full name), else `absent`;
   - an incumbent on their own ballot returns nothing, and the card is unchanged.
   Kind beats the curated flag: IA-02's Hinson reads RUNNING FOR SENATE, not NOT RUNNING.
2. The tag, the house qualifier style (mono, uppercase, bordered): RUNNING IN <seat> linking to `/race/<id>`; RUNNING FOR SENATE linking to the Senate race; RETIRING; WITHDREW; LOST PRIMARY; NOT ON THE BALLOT. It replaces the NOT RUNNING tag on the race page's card and on every compact surface from STEP 0 item 4, in the same slot the compact cards use for NOT RUNNING today. After election day HO 758's qualifiers take precedence on a decided race; on an undecided one this tag stands.
3. The Louisiana header: when the roster has no majors block, the `on_ballot` block's heading reads *On the ballot*.
4. The two mocks are committed under `docs/design/` unchanged, in the docs commit, with one line each in the roadmap block naming them as the records of the HO 758 and HO 759 rulings.

## Legs, on a `file:` copy, render-touching, each red first

1. The kinds: TX-35 reads `moved` with `TX-37`; IA-02 `senate` with `S-IA`; TN-09 `retiring`; NC-11 `withdrew`; TX-09 `lost_primary`; an absent case `absent`; a control on their own ballot returns nothing. Red: today every one reads either NOT RUNNING or nothing.
2. Precedence: IA-02 with its curated zero reads `senate`, not `retiring`.
3. Namesake guard: a decided primary with an unmarked namesake of the incumbent (name differs) doesn't read `lost_primary`.
4. Post-election: with the clock at Nov 4 and a marked winner, the card shows HO 758's qualifier and not this tag; undecided, this tag.
5. Louisiana: LA-01's roster heading reads *On the ballot*; CO-08's still reads *Also on the ballot*.
6. Captures from local production builds (Preview reads prod, which has no planted rows) at 1440, 2560 and reduced motion: the six cases' race pages, one compact surface showing each tag, and LA-01's header, against HEAD's before.

## Commits and docs

- `feat(HO 759)`: the qualifier function.
- `fix(HO 759)`: the card, the compact surfaces, the Louisiana header.
- `diag(HO 759)`: the legs driver.
- `docs(skill)`, its own commit, approval requested: the qualifier's kinds and reasons and their order, the surfaces, the post-election precedence, the roster heading rule.
- `docs(HO 759)`: strike the class line with the ruling verbatim; annotate the stub line filed at HO 757 (the four pages' cards now carry the tag), and strike it if that answers it; commit the two mocks; the roadmap block, pointer 758 → 759, carrying HO 758's readings and HO 756's tick. Reconcile OPEN LOOPS at open and close, control at 0.
- Review ref `759-review`. The FF is held for the SKILL approval, the captures and review.

## The prod reading (in the FF go)

After the FF: `/race/TX-35-2026`, `/race/IA-02-2026`, `/race/TN-09-2026`, `/race/NC-11-2026`, `/race/TX-09-2026` and `/race/LA-01-2026` on Production, and one dashboard card carrying a tag.

## Paste back

- STEP 0's table by kind and reason;
- the six legs with the captures;
- the SKILL diff, for approval;
- `git show --stat` per commit, `--numstat` for the docs commits, the reconcile, the `759-review` SHA from `git ls-remote`, and a last cheap-gate run.
