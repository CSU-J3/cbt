# HO 726 — STEP 0 ruling (architect, 2026-09-14). Seven rows accepted, the manifest premise is dead and the replacement is ruled in with one addition, three corrections taken. Go.

Row 5 is the handoff's premise failing exactly the way a premise is supposed to fail: read before it was leaned on, in a HALT rather than in a gate that quietly could not fire. `tags-manifest.json` does not exist at `next@16.3.4` because `revalidateTag` writes an in-memory `Map` (`tags-manifest.external.js:27`), so the file I prescribed was the HO 683 shape a second time, an evidence path that never comes into being. The handoff said that kills the instrument; it kills *that* instrument. Running rows 6 and 7 with a replacement was the right call, and the replacement is better than what it replaces, because it reads the flush at the place the flush happens.

## 1. The replacement is ruled in, with one addition and one word

Your four legs, adopted as written, with the debug line standing in for the manifest: the POST's 400 before, the 200 plus `FileSystemCache: revalidateTag [ '<tag>' ] { expire: 0 }` after, the control-GET-then-POST-then-GET regeneration pair, and `tag=nonsense` at 400 with no debug line.

Two things to add, both from what row 7 turned up rather than from the design.

- The control GET is load-bearing, and its zero is the whole gate. Row 7's step B reading 0 rewrites is what makes step D's 3 mean a flush; without it, a rewrite is indistinguishable from a TTL expiry on a cache holding entries from 09-13. The paste prints B and D as a pair for each tag, in that order, with the gap between them in seconds, and the block says in one sentence why B exists. That is the same shape as "controls before zeros" and it is here because the cache's age lives in the file mtime.
- The rewrite claim is mtime only. The FETCH entry stores no timestamp and the bytes are stable unless the data changed, so the reading is *mtime moved on n entries tagged `<tag>`, content hash unchanged*, and the content hash is printed to say so rather than left implied. A changed hash would be a data change during the measurement and is reported, not smoothed.

`NEXT_PRIVATE_DEBUG_CACHE=1` is a departure and is named as one: it changes logging, not behaviour, and the POST's 200 and the regeneration pair read the same without it. Say that in the block.

## 2. The three corrections, taken

- `votes` is **17** readers, not 20. My count came from a grep that counted co-tagged arrays twice; the comment says 17, and STEP 1 prints the grep that produced it so the number carries its own instrument.
- The backlog lines are `:20` (meetings) and `:107` (votes) after HO 725's filing. Re-derive by content, as always.
- The ground-truth wording becomes *mtime moves; the content hash is unchanged unless the data changed*, everywhere the handoff says contents move.

## 3. What the prod half is, stated plainly in the block

Prod is Vercel's cache, not the file-system one, so none of the three local readings transfers. What transfers is the mechanism: `expireTag` is one function (`lib/cache/expire-tag.ts`, HO 706) called by every cron, the allowlist is the only thing standing between the POST and that call, and HO 716's interim practice already relies on `POST /api/revalidate?tag=bills` against a live deployment. The post-FF evidence is therefore the pair of 200s where 400s read today, and the block says that is an allowlist reading rather than a flush reading, with the flush half carried by the local run and the mechanism.

## 4. Two things worth a line each in STEP 3

- `.next/cache/fetch-cache/` survives a build, which is why row 4's GETs rewrote three entries before any POST. Nothing in the tree records that; SKILL `:2619` records the prod sibling (the Data Cache survives deploys, HO 312/555). One oddity entry, HO 726, carrying the local fact, the 09-13 residue, the mtime-not-bytes reading, and the manifest's absence with its `:27` citation, so the next reader reaches for the debug line rather than the file.
- The `MissingSecret` lines in the server log are `backlog`'s known local-dev gap on a production server, and every page still read 200. One clause in the block, no new line.

Everything else stands: the two entries with their comments, the two SKILL sentences, the strikes, the `nonsense` control, and the ref named `726-review`.

Go: the fix, then the four legs per tag, then the docs.
