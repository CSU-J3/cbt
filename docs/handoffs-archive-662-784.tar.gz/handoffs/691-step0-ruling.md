# HO 691 — STEP 0 ruling (architect, 2026-09-04)

All three premise flaws are confirmed as **architect-side errors**, flagged correctly and not absorbed. Record them in the roadmap block as such: the handoff asserted a `loser` status that `primary_candidates` never had (the schema comment was right, the ground-truth paragraph was wrong); it wrote an incumbent clause that the one incumbent in the live set (Massie, KY-04) breaks; and it carried the 2026-07-01 coverage figures as if they were current. The build was a no-op as written. The corrected rule below is what ships.

## 1. Classifier — confirmed, with one refinement

Code's four-rung rule stands **in Code's order**: the primary results beat the roster's `withdrew` on purpose, because `race_candidates` has no eliminated/lost value and `withdrew` is its canonical "out" (HO 174/182), so a roster `withdrew` is ambiguous where a posted result is not.

**Refinement — the round dimension.** Rung 1 and rung 2 must evaluate the target against **their latest resulted contest for the seat**, not the primary round alone. A `winner` in a `primary` round that was followed by a `runoff` round means *advanced*, not *nominee*; the nominee is the `winner` of the runoff, and the runoff's non-winner is `lost`. Top-two seats (CA/WA) are unaffected: both `winner` rows are on the November ballot, so `active` is correct for both, exactly as row 2 read CA-34 and CA-14. Concretely:

| order | test | verdict |
|---|---|---|
| 1 | `winner` in the target's **latest resulted** contest for the seat (`runoff` over `primary` where both exist), or a `won_primary`/`nominee` roster row | `active` |
| 2 | latest resulted contest for the seat is past-dated, has any `vote_pct` posted, and the target is present and not its `winner` | `lost` |
| 3 | roster row `withdrew` | `withdrew` |
| 4 | otherwise | `unknown` → renders exactly as today |

**TX-23 is the case to read before building.** Row 3 classified Herrera `active` on "runoff advanced both". Texas ran its runoffs on 2026-05-26; if a `runoff`-round `primaries` row exists for TX-23 R, Herrera's status is his status **there**, and if he is not its `winner` he is `lost` and UDP's `O Herrera` line goes past tense on the hub. If no runoff row exists in the data, say so and leave him `unknown`-safe as `active` only if the primary round shows him `winner` with no later round — and file the missing round as the WATCH's first instance. Grep every one of the 11 seats for a second round before trusting any `active`.

## 2. Row-2 verdicts — confirmed as read

6 stale · 2 active · 2 unknown, **Massie = `lost`**. An incumbent who loses his primary is out of the race; the handoff's "running incumbent → active" clause was wrong on exactly the case it existed for, and it is deleted, not narrowed. The two `unknown`s (Hostettler, Bowman) are the live asymmetry check the handoff wanted — keep them as STEP 2's controls, byte-identical before and after.

## 3. Refresh — confirmed, run it in STEP 1D

`npm run sync:pac-ie` for real after the code lands: 10 rows → 18, 7 seats → 11, 0 drops. **The intended MI outcome is `AIPAC super PAC · opposing El-Sayed` on the glance**, which is a true present-tense claim about the general and precisely "what is currently happening"; the full variant reads `opposing El-Sayed ↗ · backed Stevens ↗ · lost primary`. The `--dry-run` flag rides the code commit as planned. Re-read the 18 rows after the write (`rowsAffected`, then a SELECT), and re-run the classifier over the fresh set — the 8/6/4 split is a prediction until then.

## 4. Row 6 — accepted

Harvest current via the HO 660 cron; STEP 1D's `backfill:race-challengers` re-run is struck and no second backlog line is owed.

## 5. Row 7 — SKILL, amended

- `:2292–2294`: the status rule, the glance/full split, the false "dormant" claim corrected (S-MI renders the glance line on prod today), and every coverage figure re-measured **after** the refresh (rows / seats / dropped / rated / featured). Provenance lands after the sentence it annotates, never inside it (HO 690's splice rule).
- The `general` shape is a **new clause** in the Race surface passage (there is no dagger clause to correct — the handoff was wrong that one existed), naming all five `ChallengerShape`s and the footnote's narrowed condition. Put it where `deriveMatchup`'s consumers are described, or beside `getRaceCandidates`' status ladder if nothing closer exists.

## 6. STEP 2 additions

- A classifier leg for the round rule: a target `winner` in a primary round with a later resulted runoff round → `active` only if `winner` there (use TX-23 if the row exists; otherwise a scratch pair of rows in the harness, never a DB write, and say the live set had no instance).
- The MI footnote assertion stands: `.race-grid-foot` absent from the served DOM of `/` after the build.

## 7. Docs

Roadmap: the three premise flaws named as architect-side with the corrected rule beside them; the round refinement and its TX-23 reading; the refresh figures. Backlog WATCH as written in the handoff, amended to name the round dimension as a second way a line stays `unknown` (a seat whose runoff round was never scraped). The pattern for method.md's next touch, not this HO: this is the second consecutive HO where STEP 0 corrected the handoff's ground truth on a schema fact the tree stated plainly — the architect must grep the schema comment before asserting a status domain.

Proceed to STEP 1 on this ruling. Nothing here is Corey's; the classifier is a correctness call, the refresh is the standing maintenance path, and Corey's ruling (dashboard = current only, history on the races surface) is what the outcome delivers.

read and follow 691 — STEP 0 ruled, proceed
