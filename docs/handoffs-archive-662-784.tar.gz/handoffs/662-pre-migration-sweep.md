# HO 662 — pre-migration sweep: flush the method layer into the repo

Body assumes **662**. Ground truth taken 2026-08-14 from a fresh clone: HEAD `4923e8c` (`docs(HO 661): SKILL — the settled guard reads decided-or-expired, old form kept as RECORD`), `docs/roadmap.md` reads **notes now run through HO 661**, no open HO. Confirm both before saving; if either moved, renumber and say so in the report.

## Why this HO exists

CBT is moving into a new maintenance project. **Project memory and chat history are project-scoped and do not follow the repo.** Every ruling, correction and convention that currently lives only in this project's memory or in a chat transcript is gone on the day of the move.

The test this HO applies: **could a fresh session with empty memory, given nothing but `git clone`, reconstitute how this project is worked?** Today the answer is no. Not because the repo is thin, but because the split is uneven. `SKILL.md` (2,475 lines, ~60 sections) documents the *product* comprehensively. The *method* — how handoffs are sized, how a session establishes ground truth, how an HO number is derived, what the product refuses to become — is almost entirely memory-resident.

### What the recon already established (don't re-derive)

- `SKILL.md` lives at **`.claude/skills/cbt/SKILL.md`**, not repo root. It is the only tracked file under `.claude/`.
- `docs/handoffs/` is repo-ignored (HO 604, Tailwind build-input parity). **386 files are tracked and they stop at 429** — every handoff 430–661 exists only on Corey's disk. §4 rules on this.
- Two tracked root files are cruft: **`-w`** (14.5 KB of Vercel SSO HTML, the artifact of a mis-parsed `curl -w`) and **`claude-code-handoff-2.md`**.
- Four spot-checks that shape STEP 0's method — see the trap below.

## STEP 0 — coverage enumeration. HALT. (enumerate-first, HO 650/658 precedent)

Produce one table. **No edits, no new files, no commits.**

| candidate rule | verdict | evidence `file:line` | proposed destination |

Verdict is **STATED** (a future reader consulting that doc would find and apply this rule), **NARRATED** (the words appear inside a dated roadmap or oddities block — a record of an event, not a rule anyone looks up), or **ABSENT**.

### The trap, with four measured examples

**A keyword hit is not coverage.** Four candidates grep positive in `SKILL.md` and three of the four are false:

- `ls-remote` → **STATED**, line 2329, in full, including the refspec-limited-fetch corollary. Genuine coverage; leave it alone.
- `scope rule` → **false hit.** Line 1725 is HO 507's *additive-only CSS* rule for `/bill/[id]`. The product scope rule is absent.
- `serializable` → **false hit.** Line 1750 is the map-geometry payload. The `unstable_cache` JSON-only rule is not there.
- `rows-read` → **false hit.** Line 1984 is the markets-tape per-symbol seek. The general Turso read-budget rule is not there.

**Read the sentence, not the match.** And keep STATED separate from NARRATED: `numstat` and `autocrlf` both appear in `oddities.md` and `roadmap.md`, but the roadmap is append-only narrative, and a lesson inside a dated block records what happened rather than stating a rule. Only `SKILL.md` and the new method doc carry standing rules.

### Candidates

**Group A — session and relay (chat-side)**

1. Session start: clone fresh, the repo is ground truth, memory lags HEAD, and a baked pointer is worse than none.
2. HO numbering: next = `max(roadmap pointer, highest HO in commit subjects) + 1`. **Never derived from an on-disk filename.**
3. Handoff artifact sizing: full feature or data spec → numbered file in `docs/handoffs/` + `present_files` + the read-and-follow close; small instruction (plan approval, correction, one-off nudge) → inline block, no ceremony.
4. Enumerate-first protocol: STEP 0 produces a closure table and halts for review before any edit.
5. Probe before build for any new cold query or structurally risky change. A clean `EXPLAIN` says nothing about cold latency.
6. Relay swallow runs **both** directions. After ONE swallowed block, re-deliver as a gitignored file, never re-paste a second time. Ground truth is `git ls-remote --heads origin`, not the pasted transcript.
7. Review-ref preview-dedup side effect: a review-ref push builds that SHA as a preview first, so the later fast-forward can dedup and leave prod on the predecessor. Harmless on docs, a verification blocker on UI.
8. Memory hygiene: memory carries conventions, lessons and open loops. Never HEAD SHAs, never "latest committed handoff", never a next-HO pointer.

**Group B — product scope and roles**

9. Congress-focused; extend downstream along the bill spine. Test for a new data pillar: attaches to a tracked bill or member → theme extension; needs its own spine → separate product.
10. Declined, with reasons: FARA, Treasury/FRED macro, standalone exec-branch tracking. (`FARA` returns **zero** hits repo-wide.)
11. Roles: Corey is product direction and final approval; Claude is architect and handoff author; Code executes. Corey rules on genuine design forks; non-fork architectural calls are made without asking.

**Group C — engineering rules that may be narrated but not stated**

12. `unstable_cache` return types must be JSON-serializable only — never `Map`/`Set`/`Date`/class instance. TypeScript cannot catch it; the cache layer silently round-trips to `{}`.
13. Turso rows-read quota is a live constraint. `turso org usage` before any read-budget optimization. Burn is dev-activity-correlated; reads are event-shaped, not a plateau.
14. `git diff --numstat` (deletion column) is the only verified instrument for append-only doc commits. Both alternatives failed and neither is a fallback: `grep -c '^-[^-]'` misses deleted markdown bullets, and a normal-format diff against `git show HEAD:file` is invalid under `core.autocrlf=true`.
15. CRLF breadth: Python text-mode reads normalize line endings silently, so `split("\r\n")` returns one element. Binary mode required. Checksums via `git cat-file -p <ref>:<path> | md5sum`, never `md5sum` on the working copy.
16. `git branch -f main <sha>` while standing on main exits 128; `2>/dev/null` inside a `;`-compound silences both the message and the status. Fix: `checkout -b <ho>-review-local` first, verify with `git rev-parse`.
17. A table must not derive its writes from an unfiltered aggregate over itself (the `calByState` self-referential MAX defect, HO 576/577).
18. Logged backlog items are claims, not facts, and can hinge on real-world events. Re-verify before scoping a fix.
19. Environment is **per-machine, not per-owner**. The Windows box: WSL present but distros won't run (virtualization enablement broken) — route through native Windows tools or web dashboards, never WSL, Docker, or any VM-dependent path. The MacBook: standard Unix environment, none of those constraints apply. A session establishes which machine it's on before assuming either set.

Anything memory-shaped you hit while grepping that this list misses: add a row rather than skipping it.

### HALT deliverable

The table, counts by verdict, and a one-paragraph recommendation on §4 with its measured byte size. Nothing lands until that's approved.

## §1 — `docs/method.md`

New file holding every **ABSENT** chat-side row. **Cross-reference `SKILL.md` by section name; never duplicate it.** Where SKILL already states a rule (ls-remote, owner verdicts in a relay, the review-ref route, deploy verification, same-as-success), method.md points at the section and stops. A rule written twice is a rule that will drift.

Sections: Roles · Session start · Handoff discipline · Relay · Doc authority and conventions · Product scope · Environment · Memory hygiene.

Terse and rule-shaped, SKILL's register. No history and no narration; the roadmap owns those. Where a rule needs provenance, cite the HO number in parentheses and nothing more.

One README line under "Project structure" pointing at it.

`docs: HO 662 — method.md, the chat-side operating protocol`

## §2 — SKILL.md alone, via review-ref

Only the **ABSENT** rows that are Code-facing (Group C), each as one durable sentence placed in the section that already owns its neighbourhood: the cache-serialization rule beside the cache-tag material, the read-budget rule under Platform facts, the doc instruments under Pre-flight verification. Plus one pointer line — method lives in `docs/method.md`, SKILL still wins ties on implementation.

Self-mod guard applies: own commit, own review ref, diff approved before main moves.

`docs(skill): HO 662 — cache-serialization, read-budget and doc-instrument rules stated`

## §3 — cruft

`git rm -- ./-w claude-code-handoff-2.md`. Grep for references first across `app/ lib/ scripts/ e2e/ docs/ .github/` and report the count even when it's zero — a zero you measured is evidence, a zero you assumed is not.

`chore: HO 662 — drop two root artifacts`

## §4 — the handoff archive — Corey's call, priced at STEP 0

Handoffs 430–661 (~230 files) exist on one disk. They can't simply be committed: `docs/handoffs/` is ignored for a measured reason, and un-ignoring it puts handoff prose back in front of Tailwind's class scanner.

The shape that satisfies both is **one tracked tarball** — `docs/handoffs-archive-430-661.tar.gz`, directory ignore untouched. A gzip is opaque to the scanner, so build-input parity holds. Report the byte size at STEP 0 so the trade is priced rather than assumed. Reversible in either direction.

A second consideration for the pricing: gitignored files don't travel with a clone, so a second dev machine (the MacBook) gets the archive only if it's tracked or hand-copied. That's an argument for the tarball, not a decision.

Build nothing here without an explicit yes.

## §5 — doc sweep

- **Roadmap:** one new **Also (HO 662)** block, pointer **through HO 662**. Never retro-edit a prior block's clause or pointer.
- **Backlog:** reconcile OPEN LOOPS in the same pass. The HO 660 scheduled-fire WATCH and the two settle windows (expiring 2026-08-20 and 2026-09-03) cross the migration boundary and must read correctly on the far side, where no memory will be carrying them.
- **Oddities:** only if something odd emerges. Nothing is expected.

`docs: HO 662 — roadmap block, backlog reconcile`

## Guards

1. **STEP 0 halts.** No file created, no commit, no `git rm` before the table is approved.
2. Commit order §1 → §2 → §3 → §5. Explicit pathspec staging only, `npm run typecheck` even on docs, ancestry eyeball immediately before every push, fast-forward only on main.
3. SKILL never rides with another doc.
4. §4 builds nothing without a yes.
5. Method.md cross-references SKILL rather than restating it.
6. Don't widen. Stale prose found in neighbouring files gets a backlog line, not an edit in this commit.
