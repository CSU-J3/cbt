# HO 771: FF go. The ref read clean, SKILL `350d8eb` approved. Two small fixes land first, then FF and read the deploy

## Rulings on the paste

I read `771-review` at `350d8eb`, all five commits:
- **the feat:** `vercel.json`, the cron-health entry verbatim, the route header, and every claim-3 call as you listed them;
- **the fix:** the refusal's shape, read inside the budget, through `fetchError`, response headers only; a stalled refusal keeps its status, and our own timeout stays status 0;
- **the legs:** the registry, the health window with its red, the guard's edge table, the redaction, the stalled 403 and 200, and the tripwire;
- **the docs:** the block, Sabato's line, the WATCH, `:71` and `:473`, the HO 744 paragraph and the README.

**SKILL `350d8eb`: approved.** I rebuilt it from `12f4228` with the handoff's edit and compared. It's byte-identical.

**The bound's sentence is yours, accepted.** Mine was wrong at its edge: daily, a missed week is an 8-day gap, which sits on the bound. Your table shows it, and your comment says what 8 days means.

**Your two stale lines are findings,** so they're fixed here rather than left. Each fix is small enough to approve by its exact text.

## Two fixes, on `771-review`, before the FF

**1. `chore(HO 771)`, the rating-history route's header.** In `app/api/cron/rating-history/route.ts`, the sentence *No revalidate — nothing reads rating_history yet (the sparkline is a future handoff).* becomes, verbatim, wrapped as its neighbours are:

```text
No revalidate: MOVED reads rating_history through getRecentRaceMoves (HO 768), whose cache holds an hour (`revalidate: 3600`, tag `races`), so a move logged here shows within the hour.
```

**2. `docs(HO 771)`, the README's schedule paragraph.** *`vercel.json` carries all 18 entries* becomes *`vercel.json` carries every entry*. Counts drift, and this one already had: it's 20 entries, 19 paths. The line wrap stays as close as the shorter text allows.

Push both. If the two diffs are exactly these replacements, they're approved as landed. Paste them.

## FF

`771-review`'s new head sits on `main` at `12f4228`, so this is a fast-forward of 7 commits. No migration.

Re-run the cheap gates immediately before the push, and name the reading. Then:
- `git push origin <771-review's head>:main`, no force;
- `git ls-remote --heads origin`;
- delete `771-review`;
- forward local `main` and delete the local review branch;
- paste `git rev-parse main`.

If the classifier blocks the push, Corey runs the same command from your checkout.

Then run `npm run verify:deploy` **in the foreground**, and read:
- the Production build's cache line;
- the Production `e2e-prod` run and its smoke.

**There's no manual POST.** The deployed reading is the first `0 11 * * *` run after the FF (2026-10-11 11:00Z if the FF lands before it). Its `cron_runs` row is read at the next session's open:
- if it reads `success`, it closes the ratings WATCH;
- if not, its `error_message` now says what the refusal looked like.

Paste once, after `e2e-prod`.
