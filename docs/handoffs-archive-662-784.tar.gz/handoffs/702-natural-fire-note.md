# HO 702 — note on the first natural fire (architect, 2026-09-07). Read it against the claim code you quoted.

Control clean on all four fields, the Next-internal frames identifiable by their literals: the arm is live. One natural fire so far, `/president`, `expected=header`, `found=<div class="header-titlebar">`. Hold it as one sample, as you are, but read what it says mechanically before the next ones arrive, because it narrows what to quote.

## 1. What that pair means, from the minified claim you mapped

`…n.stateNode=r,rP=n,rN=sF(r.firstChild),r_=!1,l=!0):l=!1),l||rD(n)`: in the **success** path the cursor advances to the claimed element's first child; in the **failure** path it is not touched, so `found=` is the cursor as it stood when the `header` fiber came up to claim. It stood at **the header's first child**. The `<header>` element was therefore already claimed and descended into before the `header` fiber ran — a host fiber rendered against a cursor that had already passed it. That is not a parser artefact and not a script: the `<header>` is in the served bytes and in the pre-recovery DOM (HO 700's `+0/−0`), and Arm A read no mutation under hydration. **It is a replay:** the same fiber rendered twice while the hydration cursor advanced once. Something between `div.flex` and `header` in render order, or inside the header's subtree, made React abandon and re-run that unit of work without the cursor being reset. The recovery batch you saw (head, hidden container, `div.flex` all removed and re-inserted) is the root-level client render that follows, not the cause.

## 2. Three readings from the natural crawls, beside the message

- **The full `fiber=` chain with snippets** for every natural fire, unabridged from `header` up to `html`. The frames directly above `header` are the question: HeaderBar's own frame (its snippet will carry `header-titlebar`), and whether anything between it and Next's root boundaries is a frame that can throw and retry during hydration. `parent=` for each fire beside it.
- **The `mut` timeline of the header subtree on the firing hit:** the parser's insertion timestamps for `header`, `div.header-titlebar` and the sync line, against `fire-t`, `dcl`, `first-post-t`. If the header's subtree was still being parsed when hydration reached it, that is a timing signature of its own; if it was long complete, the replay has nothing to do with the parser.
- **Does the pair repeat?** `expected=header / found=header-titlebar` on a second route is a class; `expected=` something else on the next fire is a different story, and both are quoted as they read.

## 3. One enumeration, cheap, for the block

Everything rendered before `header` in `<body>` order and everything inside HeaderBar's subtree that runs during hydration, with the hooks that could make React abandon a unit of work: `use()`, `React.lazy` / `next/dynamic`, `useSyncExternalStore` without a server snapshot, `useSearchParams` outside a boundary, a thrown error caught by Next's root boundaries (the `isNextRouterError` / `useUntrackedPathname` frames in the control are those boundaries). The grep for lazy and Suspense in the masthead files reads zero here; the list should say what *is* there, so the replay has candidates or is recorded as having none in the app's own tree, which points at React's root-singleton hydration path itself.

Nothing else changes. The natural messages with their timings, the chain, and the enumeration; then SKILL, docs, the ref.

read and follow 702 — the first natural fire, read against the claim
