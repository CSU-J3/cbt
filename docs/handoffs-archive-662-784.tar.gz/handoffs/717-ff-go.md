# HO 717 — FF go (architect, 2026-09-12)

**Owner verdict, verbatim: "send it"** — Corey, CBT maintenance chat, 2026-09-12, on the architect's read of `717-review` at `d8eee77` off the remote: five commits, kinds pure (`feat` ×3, `docs(skill)` alone, `docs`); `b0e1cf5` is an ancestor, so the move is a clean fast-forward. The predicate is one exported constant read by the sync and the readers; the repository URL is built from the id; the affordance renders nothing at `n = 0`; the SKILL's five deletions are in-place amendments and it now states that MIA is floor-only. Preview `narrow-preview` (`34717855412`, 74 passed) green on every route at both widths, with the new CSS confirmed present in the served chunk before the captures were taken. HO 715's decision line closes on the letter with its provenance.

**What this FF is.** The first deploy that stores what Congress.gov files for every committee meeting and puts each House markup's recorded-vote record one click away, asserting nothing about who voted. It also carries the first `RECORDED VOTES · n` on production rows, and it needs one prod action **after** the deploy that the paste must show.

## 1. The move

- `git ls-remote --heads origin` immediately before: `main` at `b0e1cf5`, `717-review` at `d8eee77`. Anything else, stop and paste.
- On `main`, the cleanup door: `git merge --ff-only d8eee77`; `git rev-parse main` must print `d8eee77`. `git push origin main`, no force. `git push origin --delete 717-review`. Then `git ls-remote --heads origin` and `git ls-remote --tags origin` (three tags).
- Each state-changing command on its own line, stderr never suppressed. The commit list is `git log --oneline b0e1cf5..main` off the pushed branch.

## 2. After the deploy, in this order

- `npm run verify:deploy` until the served SHA is `d8eee77`, five consecutive reads.
- **Re-run `npm run backfill:meeting-documents`** now that the deployed cron writes documents too: paste `events_read / documents_stored / recorded_vote_docs / gone_upstream / soft_404_pages`, the table count before and after (`19,270` documents across `1,802` events before, per the review paste), and `SELECT COUNT(*) FROM committee_meeting_documents WHERE ${RECORDED_VOTE_DOC_SQL}` before and after. This closes the OPEN LOOPS line the review paste filed; strike it in a follow-on docs commit only if Corey wants the ledger moved now — otherwise the block for the next HO records the strike.
- **Cache:** `meetings` is not in `ALLOWED_TAGS`, so no manual flush; the served rows show the link within the 1 h TTL or on the next cron tick. The paste says which it was, with the time.

## 3. The readings

- **Served, off production, after the TTL or the tick:** `/committee/hlig00` — the rows for 119474 (`n = 4`) and 119034 (`n = 3`) carry `RECORDED VOTES · n ↗`, the served `n` equals the DB count for each, and the link resolves to `docs.house.gov/Committee/Calendar/ByEvent.aspx?EventID=…` listing the files; `/bill/119-hr-10152` shows the link with `n = 1`; a committee page with a meeting at `n = 0` shows no link. At 430 and 390 on `/committee/hsvr00` the `↗ 2` stacks under WATCH and the title width is unchanged (the F3 reading, taken off production).
- **The card, one attempt:** if the `/hearings` calendar can be navigated to a week containing a meeting with `n > 0`, open its card and read the *Recorded votes* section; if it cannot, say so in one sentence and state the bound (a static JSX branch over `eventId` and `n`). Either answer is a reading.
- The Production `deployment_status` run: id and conclusion, the group echo, the `home` band line, the HO 716 routes at 390 with the enacted chips read beside them, `hearings` and `committee-detail` at both widths, `pageErr=0` across the log, wall time.
- `ci.yml` and `design-citations` conclusions.

## 4. After the FF

Nothing else is owed by this HO once the backfill re-run is pasted. Filed and standing: the `meetings` allowlist gap, the Senate documents follow-on (515 documents, all nameless and URL-less, none matching), the *Added* time as a stored field, and the WATCH on the hlig00 crawl target's decay.

## 5. Paste

The `ls-remote` line showing `main` at `d8eee77`, the ref gone, three tags; `git rev-parse main`; the five-line log; the five served reads; the backfill re-run's counters and the before/after counts; the served readings in § 3 with the cache timing; the card attempt's answer; the Production run's id, conclusion and lines; `ci.yml` and `design-citations` conclusions.

read and follow 717-ff-go — the file, not this line
