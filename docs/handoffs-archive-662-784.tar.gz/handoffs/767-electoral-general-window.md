# HO 767: /electoral in the general window, as set on mock-767 v18. The race list leads, the open row carries the ballot, the seat and the members on it, the primary calendar folds on top, and the day after shows results

Ruled 2026-10-08 14:28 MT on `mock-767-electoral-general-v18.html`, verbatim: *"as set"*. The line as set:

> **LEAD B · LIST 2 · CHAMBERS tabs · BOX fit · OPEN ROW 2 · TEXT 2 · PHOTO 2 · GRADE 3 · GRADE AS chip · NEWS 2 · WHERE rows+beside · CALENDAR 2 · TOP none**

plus the mock's DAY view *NOV 4* as the page's state once election day has passed. The ask behind it (2026-10-06, not verbatim): the dashboard's races links land on `/electoral`, which opens on a map, carries a primary calendar whose axis ends Sep 30, and names neither Nov 3 nor who is on its ballot.

**The ruling trail, verbatim, each answered by the next version.** v1 to v8's settings were the mock's own defaults and never moved; method.md § Roles makes them rulings. These land in the roadmap block as written:

- v8 (2026-10-07, paraphrase; the words are not on file): the tracker grade on the incumbents where it exists.
- v9: *"whats a better way to get that info across? like just the grade and a hover box? i dont want to say they take care of it if they dont"*
- v10: *"that wording is ass and unprofessional pla change it and add a link to the sheet and whatnot"*
- v11: *"member page and score page are the samthing. remove the "full score card" button."*
- v12: *"needs to be a Month + year. there are tomany Oct 7s to know shat date its reffing"*
- v13: *"lets label this as whos on the ballot.  make a clear divide between head by and whos running."*
- v14: *"this needs proper distinction  between ballot and held by i think"*
- v15: *"needs to say what part of congress they are in currently. ie a house person trying for the Senate set etc.."*
- v16: *"(needs to list that years primaries too)"*
- v17: *"move that under 2026 electoral and above the race line chart thing"*, then *"this could be layedout better making it less cluttered feeling."*
- 2028: *"keep outlook."* When 2028 ratings start, the HO 718 report stays; the list goes on top of it and the report keeps the seats nobody rates. Nothing here builds that; it is the WATCH line's rule (§ Docs).
- v18: *"what does this page look like the  day after elections?"*
- *"as set"*

**The mock.** `docs/design/mock-767-electoral-general-v18.html`, **sha256 `f25f13a0cb14df70f49250955d79e4bc5986070af4427e7c8ca18f0e3e02d67c`, 519,061 bytes. Corey drops it there before STEP 0.** It opens in the ruled state and holds every option from v2 on as toggles; the *what's real in this mock* notes and the option notes (*show controls*) are build notes and are part of this handoff. It is the largest file in `docs/design/` because it embeds 62 public-domain portraits (github.com/unitedstates/images); the build uses none of them. **Its NOV 4 view draws planted results** (a coin flip per seat, California and Alaska uncalled, Georgia's Senate seat to a runoff), said by a banner on the page; it is a layout, not a forecast, and the roadmap block says so in those words.

**Scope.** The 2026 branch of `/electoral`. **Unchanged:** the map and its district drill (one MAP/LIST toggle away), every race page, the dashboard (`Battlefield` gains one prop, off by default), and the `?cycle=2028` report. **App-wide, small:** the copy that names USCPR as the grade's source, and the three `of 47` literals (§ 6). **Out:** reading the tracker's House tab (its own handoff; filed), the 2028 data side (filed), odds on the rows (the mock draws none; the `◆` cell and `KalshiLine` stay where today's list has them, behind the odds switch).

## Ground truth (read at `468e692`; re-derive every `:N` by content)

- **The page.** `app/electoral/page.tsx`: the 2028 branch `:72` → `SeatOutlookPage` `:146`; the 2026 reads `:75-83` pass `2026` literally (`getRacesIndex(2026)` `:76` … `getIncumbentQualifiers(2026)` `:81`); title row `:101-107`; the intro paragraph `:110-119` (it promises *"the primary calendar below"*); `RacesHeroBand` `:121`; `ElectoralBoard` `:128`, list via `listSlot` `:134`.
- **The board.** `components/ElectoralBoard.tsx` owns the calendar's `locked`/`hovered` state that paints the map; it renders `CartogramShell` `:103`, then the calendar band `:121-171`, whose title is the literal `PRIMARY CALENDAR · 2026` `:123`; `PrimaryTimeline` `:139`; the readout `:147-170`.
- **The shell.** `components/CartogramShell.tsx`: map-first by design (`:3-6`), `view` defaults to `"map"` `:143`; a search submit resolves a state and calls `setView("map")` `:209-216`; the control row (toggle, search, `summary`) `:270-301`; `RacesLegend` renders in both views `:303`; the list slot `:493`.
- **The list today.** `components/RaceListView.tsx`: the header's dropped premise `:15-19` (*"there is no race→news linkage in the data layer"*) predates `getSeatNews`; `RaceListRow` `:102-265` leads with the incumbent, then `ConsensusChip`, `SpreadBar`, the odds-gated `◆` cell (a `data-market` site, kept in its grid track by `visibility`), margin, cash; the expand `:243-262` is raters, `KalshiLine` `:252`, `PacSpendingLine` `:253`, *Race hub →* `:259`; `Section` `:267`, the summary line `:336`.
- **The calendar.** `components/PrimaryTimeline.tsx`: `COUNT_LABEL_MIN` `:20`, `DOMAIN_START`/`DOMAIN_END` `2026-03-01`/`2026-09-30` `:23-24` (why Nov 3 falls off), the aria-label `:87`. Its data: `PrimaryCalendarDate` `{ date, states, contestCount }` (`lib/queries.ts:1700-1704`), `getPrimaryCalendar` `:1717`, first rounds only.
- **The band.** `components/Battlefield.tsx`, an async server component: `COMPETITIVE_MAX` `:19`, `ELECTION_DAY_MS = Date.UTC(2026, 10, 3)` `:23`, props `cycle` and `featuredIds` `:69-78`, HO 758's results gate `:81-83`, the head `:122-152`. Mounted on `/` only: `CompetitiveRacesBlock.tsx:168-173` (`showBattlefield`, featured = the dashboard's card races), `app/page.tsx:197`. `.ctl-head` is `justify-content: space-between` (`app/globals.css:3749-3755`).
- **The hero.** `components/RacesHeroBand.tsx`: HOUSE CONTROL · SENATE CONTROL · SEATS IN PLAY (`:1-5`); the two control cells are Kalshi.
- **The grade.** Table `palestine_scorecard` (`scripts/migrate.ts:439-448`; `synced_at` is a column). `getPalestineScorecard` `lib/queries.ts:1455` reads one member and doesn't select `synced_at`. The sync reads the Senate tab only (`scripts/sync-palestine.ts:8-9`, `gid=1260635943`). Copy that names USCPR: `components/PalestineBadge.tsx:17-19` (title), `components/SponsorExpandedPanel.tsx:290` (rail label) and `:312` (not-scored title), `app/members/[bioguideId]/page.tsx:589` (*via USCPR ↗*). `of 47` typed: `PalestineBadge.tsx:18`, `SponsorExpandedPanel.tsx:304`, the member page `:613`. The Tooltip primitive (SKILL § Tooltip primitive) is non-interactive by design: it can't hold a link.
- **Readers the open row draws on** (each per member or per race today; STEP 0 maps the batch): `getRaceCandidatesForCycle` `:2241` (the cycle's whole roster in one query), `getRaceRoster` `:2004`, `getPrimaryForRace` `:1615`, `getRunoffsForRace` `:1683`, `getIncumbentQualifiers` `:2222` (HO 759's tags), `getRecentRaceMoves` `:2396` (over `rating_history`, `scripts/migrate.ts:360`), `getPacIeSpending` `:2465`, `getSeatNews` `:2754` (bioguides in, `SEAT_NEWS_TERMS` `:2741`), `getMember` `:1325`, `getMemberStats` `:1345`, `getMemberFundraising` `:5277`, `getMemberIdeology` `:5332`, `getChamberParticipationContext` (`:9338`, the chamber median).
- **The day after (HO 758).** `lib/race-result.ts`: `readRaceResult` and `raceResultView`, dormant until `daysToElection(cycle) < 0` on `clockNowMs` (`lib/format.ts:128`, `:142`; `lib/clock.ts:11`, honoured only against a `file:` database). Its vocabulary: one mark is a result, two or more a runoff, none *Not yet called*; *re-elected* / *defeated* / *not on the ballot*; *Called by Ballotpedia · read …* / *No call on Ballotpedia · read …*; `--result-elected`. `getElectionResults` `:2113` feeds the band's RESULTS line.
- **Tests that drive this page.** `e2e/smoke.spec.ts:922-952` hard-asserts map cells **on load** (HO 504's reasoning, `:931-936`); `e2e/fit-finish.spec.ts:632-660` (district modal), `:662-686` (calendar bars), `:688-709` (LIST toggle, accordion), all skip-on-empty; routes `e2e/routes.ts:64`, `:67`; the odds-off gate `e2e/odds-off.spec.ts:47`, `:50`. **With LIST as the default and the calendar folded, the smoke test reds, the modal and calendar-bar tests skip green, and the LIST test passes only while its class names hold.**

## Corrections to the mock, named so the record doesn't read as a redraw

1. **C1.** The band's ELECTION DAY line (and HO 758's RESULTS line) sits at the far right of a full-width band (`.ctl-head`, above). On `/electoral` the build packs it left after the legend, through a `Battlefield` prop; the dashboard is unchanged (SKILL § Layout conventions, C1; the HO 718 precedent).
2. **MOVED** is drawn from headlines in the mock (its † note). The build reads `rating_history` through `getRecentRaceMoves`.
3. **One hand note** under a name, AK SEN's *"a second Dan Sullivan, not the senator"*, has no source in the tree. The build prints what the roster holds.
4. **The NOV 4 band** counts the drawn rows only. The build's band is HO 758's, unchanged.
5. **Everything the mock read off live pages** (ballots, cash, FEC dates, primary dates, grades, ages) is read from the tables by the build. STEP 0's table maps each one.

## STEP 0, then HALT

1. HO number from the tree: pointer 766, highest HO in commit subjects 766, `main` at `468e692`, so 767. Otherwise stop.
2. `sha256sum docs/design/mock-767-electoral-general-v18.html` reads the hash above, 519,061 bytes. If absent or different, stop.
3. Re-read every cited `:N` by content. Flag a drift; don't absorb it.
4. **The closure table:** every element of the ruled state (each bullet of § The build) · its source in the tree (query, column, `file:line`) · verdict (*read as is* / *needs a batched reader* / *not in the database*) · destination component. With prod counts (SELECTs only): rated rows by chamber; rows with a sitting member on the ballot and how many members; rows whose holder is off the ballot, by HO 759 tag; scorecard rows by the member's chamber; the oldest and newest FEC coverage dates among those members; rows with a `rating_history` move in 30 days; rows with a PAC glance line; rows with a news item 30 days old or newer under the NEWS 2 rule, and the 7-day RACE NEWS count per chamber; rated rows with no stored incumbent.
5. **Payload:** the serialized size of the open-row data for every rated row, batched at page load. Above ~250 KB, say so and propose a fetch-on-open route (the bill panel precedent) instead.
6. **The test inventory:** every spec and assertion that drives `/electoral`, what it assumes (map default, calendar open, class names), and the change each needs.
7. **The odds sites** on this page (`data-market`, SKILL's sixteen-site list) and where each lands after the build.
8. **The layout audit's `/electoral` reading at HEAD** (M1 and its register lines), the baseline § Legs compares against.
9. **HALT.** The table comes back for review before any file changes.

## The build

### 1. The page

- Order: the title row; the primary calendar, folded (§ 2); the band (`Battlefield`, LEAD B); the controls (§ 3); the rows (§ 4). **TOP none:** the intro paragraph goes, and so does the SEATS IN PLAY cell; `RacesHeroBand` keeps its two Kalshi cells, odds-gated as today, and renders nothing when they hide (C4).
- **LIST is the default view** (LEAD B). MAP is one toggle away and unchanged, both chambers, its legend, its search, its drill.
- The calendar band has to stay inside `ElectoralBoard`, which owns the state it shares with the map. So the board renders the calendar first and takes the band as a slot ahead of `CartogramShell`.
- **Everything in this path reads the cycle, not 2026:** the page's reads, the calendar's title and aria-label, `PrimaryTimeline`'s domain, `Battlefield`'s election day (`electionDay(cycle)`). A 2028 page built later inherits the render as is; the data side doesn't (§ Docs).

### 2. The primary calendar (CALENDAR 2; v16, v17)

- **Folded:** *PRIMARY CALENDAR · {cycle} · {N} contests · {M} voted · NEXT {date} · {states} · {count} ▸*. No separator dot before NEXT (a wrapped phone line would start with it). NEXT hides while the calendar is open and once no date is upcoming.
- **Open:** the bars, with no numbers on them, on an axis that runs past election day (mid-November), the TODAY line; under them the list, every date · its states · its contest count, read down each column (CSS columns, ~210px minimum), the upcoming date in amber. The list container takes `data-col-flow` (SKILL, the column-flow clause; register it). The date locks, the hint and the readout work as today.
- **Data:** the `calendar` prop already carries date, states and count. No new query. Runoffs stay out, as today.

### 3. The controls (LIST 2, CHAMBERS tabs; v17)

- **Line 1:** MAP/LIST and search. The count line (`CartogramShell`'s `summary`) and the map's legend show in MAP only.
- **Line 2:** the tabs, *SENATE {n} · {k} news* and *HOUSE {n} · {k} news*, the active one marked by its underline, no track; then the tier switches *{n} TOSS-UP · {n} LEAN · {n} LIKELY/SOLID*, each a toggle with a 9px square that fills when on (`aria-pressed`), and *showing X of Y* when a tier is off. A search swaps a tab's race count for *{n} match* and drops its news count. Flush with the page's left edge; on a phone the switches drop under the tabs.
- The rows, the switches and RACE NEWS follow the tab; all three tiers start on. Search filters the rows as you type, finds nominees, looks in both chambers and jumps to the tab with the match. MAP keeps today's search.
- RACE NEWS's header drops its item count when it follows the tab (C5: the tab carries it).

### 4. The rows (LIST 1/2) and the box (BOX fit, WHERE rows+beside)

- **The row leads with who's on the ballot:** the majors by surname (*[D] Pappas v [R] Sununu*), *· N others on the ballot* when there is one major, the OPEN pill, then the seat holder who isn't on the ballot, by surname, with their HO 759 tag. Column heads: Seat · On the ballot · Consensus · C · S · I · 2024 House · Inc. cash. Cash shows only for an incumbent running for this seat.
- **The second line:** MOVED, PAC (the dashboard's glance line), NEWS (the newest item 30 days old or newer about a sitting member on this ballot, *+N*; it doesn't wait for *since your last visit*). It moves up beside the facts, under a *Latest* head, where the main column is 1,560px or wider.
- **The box:** the rows scroll inside a box whose top is measured on the client and whose bottom is the window's less the page's bottom padding; column heads stick to its top. RACE NEWS sits beside it with the same bottom edge from 1,150px, stacks above the rows below that; under 900px the box is off and the page scrolls. RACE NEWS: the last 7 days, each item tagged with its seat, a tag opens that row.

### 5. The open row (OPEN ROW 2, TEXT 2, PHOTO 2; v13 to v15)

- **ON THE BALLOT:** every name in full, with how they got there: *won primary {date}*, *advanced {date}*, *nominee*, *won runoff {date}* with its share under it, a third party's printed party; then *Withdrew: …*. **Under a rule, the seat:** SEAT HELD BY when the holder isn't on this ballot (a 30px face, the name, party, grade chip, and why: *retiring*, *lost the primary*, *running in {seat} →*, *running for Senate {XX SEN}*), the special-election line, the three raters as tiles, the AIPAC block.
- **ON THE BALLOT · IN CONGRESS NOW:** each sitting member on the ballot: an 80px portrait (the race page's incumbent-card crop; initials when there's none), name (party) with the grade chip, *MEMBER PAGE →*, **the role line** (*House · NH-01 · running for Senate*, *Senate · running to keep the seat*, *House · FL-23 · running in FL-25*; the chamber and seat from the member's own record, held whole at each dot so a phone breaks there), *took office · born*, then Raised (on hand under it) · On hand · Small-dollar · FEC as of ↗, then Missed · 119th (the chamber median under it) · DW-NOMINATE (its scale) · Sponsored (enacted under it). No member on the ballot: one dim line.
- **NEWS** (up to five, the NEWS 2 rule), then *FULL RACE PAGE →*.
- **Type at TEXT 2:** labels `--fs-12`, the line that explains a name or a number `--fs-13`, names, headlines and figures `--fs-14`, figures in medium weight. **Layout:** the mock's grid; three columns where the main column is 1,560px or wider, two below that, one under 880px; under 900px the row drops 2024 and cash and the open row picks them up.
- **Data:** batched for the page, never a query per row: the roster with statuses, the primary and runoff dates and shares, the members on the ballots and their figures, the scorecard rows, the seat news. STEP 0's payload reading decides load versus open.

### 6. The grade (GRADE 3, GRADE AS chip; v8 to v12)

- **The chip:** `PalestineBadge` by the member's name in the open row and on the seat holder's line, bound to the party so the two never part at a wrap. It draws whoever the table holds: the Senate Democrats today, the House Democrats once the House tab is synced, with no change here.
- **The card:** a new client component; `Tooltip.tsx` is untouched. Placed by `computeTooltipPosition`, styled as `.tooltip-panel`. Content: *Palestine Tracker · as of {Mon YYYY}* (`synced_at`); *[F] 36% · #23 of 47 Senate Democrats*, the pool counted per chamber from the table; *Sponsorship 33% · Voting 37%*; *Grade based on the USCPR metric.*; *View tracker ↗*, on the Senate tab (`#gid=1260635943`) for a senator and the sheet's default tab for a House member. **Behaviour:** opens 400ms after the pointer arrives or at once on focus; 160ms for the pointer to reach the card; a click, a tap or Enter pins it and a second closes it; Tab from the chip reaches the link and then moves on past the chip; Esc closes it and hands focus back; it follows the chip as the box scrolls and closes once the chip is out of sight; a re-render closes it.
- **The copy sweep, its own commit:** no copy names USCPR as the source (*i dont want to say they take care of it if they dont*): PalestineBadge's title, SponsorExpandedPanel's rail label and its not-scored title, the member page's out-label. The three `of 47` literals read the same per-chamber count the card reads.

### 7. The day after (DAY NOV 4; v18, in HO 758's terms)

Dormant until `daysToElection(cycle) < 0` on `clockNowMs`, the race page's gate. Each row reads its race's result (`readRaceResult` / `raceResultView`, batched):

- The consensus chip becomes the result: *{P} HOLD* or *{P} GAIN* by the winner's ballot party against the seat holder's (*{P} WIN* with no stored incumbent; STEP 0 counts those), *RUNOFF* on two marks, *NO CALL* on none. The column head reads Result.
- The winner's surname takes a check in `--result-elected`, bound to the name; the other majors dim. A winner the row doesn't name (one major on the ballot) leads the cell.
- The C · S · I bars dim to 0.55, titled *final calls*.
- **Open row:** the winner leads the ballot with *Elected*, or *re-elected* for the incumbent; a beaten incumbent reads *defeated*; a runoff's two read *runoff*; a primary runoff's shares drop (they would read as the general's). Under the ballot, HO 758's provenance line. The raters sit under *Final calls*, dimmed.
- **The role line:** *re-elected*, *defeated*, *elected to the Senate*, *lost the Senate race*, *elected in {seat}*, *lost in {seat}*, *in the (Senate) runoff*, *not yet called*.
- A called seat's odds hide. The calendar reads all voted with no NEXT (§ 2). The band is HO 758's.

## Legs, on `file:` copies, captures kept (method.md § Gates)

Local production builds on a prod seed, the HO 758 pattern. Captures at 1920, 1440, 1100 and 430, plus a reduced-motion pass.

1. **The page, before election day:** LIST by default on both tabs; NH SEN open (a member, a holder off the ballot, two grade chips); GA SEN (two members); FL-25 (running in another district); MI SEN (no member); MN SEN (holder not on the ballot); the calendar folded and open; the card on hover and pinned; MAP, set beside HEAD's MAP capture, unchanged.
2. **Dormant:** the real clock, no marks. No result chip, no check, no *Final calls* anywhere on the page.
3. **The day after:** `CBT_CLOCK_NOW` = 2026-11-04T15:00Z on a copy with marks planted for at least one HOLD, one GAIN, a runoff, a no-call, an incumbent re-elected and one defeated, a member elected to the Senate and one who lost. A capture of each state; HEAD's build on the same copy shows none of them (the red).
4. **The card:** a Playwright drive of every behaviour in § 6, each with a control that fails it (opening before 400ms, a pointer leaving without reaching the card, a tap in a `hasTouch` context).
5. **The data:** the open-row values for NH SEN, GA SEN, FL-25 and MN SEN equal what their race pages and member pages print on the same copy.
6. **Tests and gates:** the updated `/electoral` specs green, and the smoke spec shown red against the new build before its change (its map assertion is what the default view moved). The map cells and the calendar bars become hard assertions after the click that reveals them (`smoke.spec.ts:931-936`'s reasoning). Build, typecheck, `check:odds-sites`, `check:design-citations`, the 430 narrow crawl for `/electoral` and `/electoral?cycle=2028`, the odds-off pass.
7. **The layout audit** for `/electoral` against STEP 0's baseline: every new M1 fixed or priced, by register line.

## Commits and docs

- `feat(HO 767)`: the batched readers (open-row data, the scorecard pool count and `synced_at`, the per-row results).
- `feat(HO 767)`: the page (order, calendar, controls, rows, box, open row, card, day-after state). Split by area if it reads better; kinds unmixed.
- `fix(HO 767)`: the copy sweep and the three `of 47`.
- The `/electoral` spec changes, their own commit, in the kind the tree uses for e2e work.
- `diag(HO 767)`: the legs driver.
- `docs(skill)`, its own commit, approval requested: Race surface (the general-window `/electoral`, results on the rows, the cycle-driven calendar and band); Tooltip primitive (the card and when to use it rather than the Tooltip); the calendar list's `data-col-flow` registration.
- `docs(HO 767)`:
  - the mock into `docs/design/` under its name;
  - the roadmap block (pointer 766 → 767): the ruling trail verbatim, the mock's sha256, and *the mock's NOV 4 view draws planted results, a layout, not a forecast*;
  - backlog, filed by subject: **the tracker's House tab** (212 graded House Democrats the sync doesn't read; the House tab's gid is unread, it's the sheet's first visible tab; it puts the badge on 212 more member pages and `/members` rows), Code; **WATCH, 2028's data side**: the ratings scrape, the primaries sync and calendar scrape, the ballot reader, the harvest, Kalshi, Polymarket, PAC and FEC are each pinned to 2026 and each converts when its source publishes 2028, probe first; 2028 adds presidential primaries the `primaries` table doesn't model; the rule when ratings start is *"keep outlook."*; **the Tooltip on touch**: a tap opens it by focus and the synthesized mouseleave closes it within ~16ms (Chromium touch emulation), on every Tooltip use, and the panel doesn't follow a scroll, Code, low;
  - HO 758's Nov-4 WATCH gains `/electoral`'s rows in its procedure;
  - oddities: Kiley's member page tags his bills R-CA while its header reads I-CA-3 (a party snapshot per bill);
  - reconcile OPEN LOOPS at open and close, control at 0.
- Review ref `767-review`. No migration expected; STEP 0 confirms. The FF is held for the SKILL approval, the captures and the review.

## The prod reading (in the FF go)

`verify:deploy`; Production `/electoral` at 1440 and 430: LIST by default, the folded calendar line, the band, NH SEN open; the dashboard's links landing there.

## Paste back

- STEP 0's table, the counts, the payload reading, the test inventory, the odds sites and the audit baseline; then HALT.
- After the go: the seven legs with their captures; the SKILL diff for approval; `git show --stat` per commit and `--numstat` for the docs commits; the reconcile; the `767-review` SHA from `git ls-remote`; a last cheap-gate run before the paste.
