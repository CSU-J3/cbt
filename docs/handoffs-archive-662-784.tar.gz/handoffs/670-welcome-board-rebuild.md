# HO 670 — rebuild `/welcome` as the board format: token-consuming type, the `IN BETA` tag, the live-shaped tapes, and the three cycling demo panels

**Read this file in full before executing anything. Execute in order. HALT conditions are hard stops — report and wait, do not improvise past them. Three HALTs: the STEP 0 closure table, the STEP 2 read-budget ruling, and the pre-land review ref. Nothing lands on `main` before the last is approved.**

Base: `main` at the HO 669 land SHA (`d628210` once 669 fast-forwards) or later. Clone fresh; verify HEAD before starting (concurrent-session rules per `docs/method.md` § Session start). Number derived per method: max(roadmap pointer 669, highest commit-subject HO 669) + 1. Environment: code edit + `npm run build` then `npm run typecheck` (build first — the HO 665 stale-`.next/types` oddity), plus local `npm run start` renders of `/welcome` and `/` (`.env` `TURSO_DATABASE_URL`/`TURSO_AUTH_TOKEN`), plus **read-only query measurement** against the live DB. Either machine; no WSL/Docker. **Bind check mandated on every start** (HO 664 → 665 procedure).

## The ruling this HO executes

Corey ruled the `/welcome` redesign in chat on 2026-08-17 against an interactive mock, iterated to sign-off. This is the Code half. The design is **not a fork** — every value below is settled and is reproduced here as the authority. Where this HO and the mock disagree, **this HO wins**; the mock is a picture, this is the spec.

If Corey has placed the mock at `docs/design/welcome-670.html` before the session, STEP 0 reads it as the visual reference and the file is committed in the docs commit. If it is absent, say so and work from the spec — **do not block on it**, and do not attempt to fetch it (handoff artifacts are not in the repo; method.md § Relay).

The page today is `app/welcome/page.tsx` + `app/welcome/landing.module.css`, built from the signed-off `docs/design/landing.html` mock and named in SKILL as having no masthead. HO 669 pinned its current shape on the record: **its own `TAPE_SLOTS` (`:56–65`, eight hardcoded label→symbol pairs), its own `TapeItem` (`:103`), its own `landing.module.css` `.tape`, no `lib/markets` import, and a direct `getLatestMarketTicks` read.** That independence is the thing this HO partly retires.

## Scope, and the three things deliberately NOT in it

In scope: `app/welcome/page.tsx`, `app/welcome/landing.module.css`, and whatever new client component the panels require under `components/`.

**Out, each filed as its own QUEUED entry in the docs commit, each for a stated reason:**

1. **The global `IN BETA` tag + clock on `HeaderBar`.** Corey wants both on the dashboard and every page. `HeaderBar` renders on every route, so per the HO 507 shared-component rule it is its own change behind its own route gates. **File it; do not touch `HeaderBar` here.** `/welcome` has no masthead, so its tag rides its own top rail and nothing is blocked.
2. **`--font-mono` JetBrains → IBM Plex Mono app-wide.** Corey picked Plex Mono in the mock. That is a one-line token change with an every-page visual surface and its own before/after gate. File it. **This HO makes `/welcome` consume `var(--font-mono)` and `var(--sans)`**, so it inherits whatever that token becomes — which is the actual fix for "the welcome page doesn't match the app", independent of which mono wins.
3. **Unifying `/welcome`'s tape with `components/MarketsTape`.** The live island and its hover portal are shared and live on `/`; HO 507 again. This HO instead has `/welcome` **import the symbol config** (`MARKETS_TAPE`, `ODDS_TAPE`, `ODDS_PAIRS`) from `lib/markets` and render it with its own presentational markup — config is what that module is for, and it kills the hardcoded `TAPE_SLOTS` divergence HO 669 recorded. Reading config is not a shared-component edit; say so in the close note. File the full unification.

## Recon (STEP 0 re-derives all of it)

- `app/welcome/page.tsx` — the hero column, the stat readout, the CTA pair, `TAPE_SLOTS` `:56–65`, `TapeItem` `:103`, the `getLatestMarketTicks` read. Server component today; **it must stay a server component** — the panels and tapes are CSS-animated and the clock is the only thing that needs a client boundary.
- `app/welcome/landing.module.css` — its own `.tape` and its own type stack. **Expect it to declare font families that are not `var(--font-mono)` / `var(--sans)`; that is the drift.** Verify per declaration, do not inherit the claim.
- `docs/design/landing.html` — the superseded mock. It stays as history; add a one-line header note that HO 670 superseded it. Do not delete.
- SKILL: the `/welcome` entry, plus any claim about `TAPE_SLOTS`, "no masthead", or the page's copy. Fresh grep at STEP 0.

## The spec — authoritative values

### Structure, top to bottom (one column, full-bleed, 28px side padding)

1. **Top rail** — `Congressional Terminal:\>` (the `:\>` in `--accent-amber`), the `IN BETA` tag, and the clock pinned right. 14px vertical padding, 1px `--border-strong` bottom rule.
2. **BREAKING strip** — full width, directly under the rail, **no top border** (the rail already draws one).
3. **Banner** — two columns, `1.35fr 1fr`, 48px column gap, `align-items:end`, padding `40px 28px 24px`, top padding **12px** when it follows BREAKING. Left column rows: headline, then lead. Right column: the CTA grid.
4. **MARKETS strip**, then **ODDS strip**.
5. **Three panels**, equal thirds, 1px `--border-strong` between.
6. **Bottom rail** — sources left, sync stamp right, 1px top rule, 14px padding.

### Type

- **Headline** — `var(--sans)` (IBM Plex Sans) 600, **68px**, `line-height:1.05`, `letter-spacing:-0.025em`, `max-width:15ch`, `text-wrap:balance`, no hardcoded `<br>`. The amber cursor block (`0.6em × 6px`, baseline-aligned) keeps its 1.1s step blink.
- **Lead** — `var(--sans)`, **16px**, `line-height:1.55`, `max-width:46ch`, `text-wrap:pretty`, `--text-secondary`. **14px** above it (measured from the title's line box, which carries ~10px of descender slack the gap cannot see — do not "correct" for it).
- **Everything else** — `var(--font-mono)`. Sizes inside 9–14px use the `--fs-*` ladder (HO 604); the 68px headline and the 24px stat numerals are outside the ladder and stay literal, joining the existing one-offs.

### Copy — verbatim, do not improve it

- Headline: `WTF is going on in Congress?`
- Lead: `Ever wanted to know the ROI on your Congress Critter? Are they working hard, or hardly working? Here, I've centralized it for ya.`
- Flourish, its own element beside the primary button: `(☞ ͡° ͜ʖ ͡°)☞ 𝓖𝓸 𝓯𝓲𝓷𝓭 '𝓮𝓶! ♥♥`
- Primary button: `ENTER TERMINAL →`. Secondary: `LOGIN` (was `SIGN IN`; **the handler is unchanged**).
- Under primary: `No account needed to poke around.` Under secondary: `↑ Want your own watchlist?`
- Bottom rail: `119th Congress · congress.gov · FRED · Kalshi · Polymarket · FEC · synced 4× daily`

**The flourish is a rendering hazard and must be handled, not pasted.** `𝓖𝓸 𝓯𝓲𝓷𝓭 '𝓮𝓶` is Mathematical Bold Script (U+1D4D0 block); neither Plex Sans nor Plex Mono covers it, and the Lenny face uses U+0361 combining marks that land badly in monospace. Give the flourish its own class with an explicit fallback stack (`'Segoe UI Symbol','Apple Symbols','Noto Sans Symbols 2',serif`) so the substitution is chosen rather than accidental, and `aria-hidden="true"` so it is not read aloud character by character. It is decorative; the sentence above it carries the meaning.

### `IN BETA`

Text `IN BETA`, bracket form — `[` and `]` via `::before`/`::after`, no border box. `--fs-13`, weight 600, `letter-spacing:0.2em`, `--accent-amber-bright`. Soft fade: `opacity 1 → 0.32 → 1`, **2.4s**, `ease-in-out`, infinite. **`@media (prefers-reduced-motion:reduce)` sets `animation:none`** — a persistent pulse is a real problem for photosensitive and vestibular users and the media query costs one line.

### Clock

Top rail, right. Format `MON 17 AUG 2026 · 9:03:29 PM MT`, ticking every second. Date and time in `--text-muted`, zone in `--accent-amber`. **Reuse the existing zone machinery** (`useZoneCycle` / `formatInZone`, HO 183) rather than writing a second one — click cycles the zone exactly as the tape does. This is the only client boundary the page gains: a small `"use client"` clock component, everything else stays server-rendered. **Render nothing on the server for the time itself** (no SSR/client mismatch); the zone label may render, the digits mount on the client.

### The CTA grid

One grid, three columns (`auto auto auto`), 14px column gap, `justify-content:start`, `align-items:center`:

- Row 1: stat readout, **spanning columns 2–3**, 22px bottom margin.
- Row 2: flourish (col 1, `justify-self:end`), `ENTER TERMINAL` (col 2), `LOGIN` (col 3).
- Row 3: empty (col 1), `No account needed…` (col 2), `↑ Want your own watchlist?` (col 3), 11px top margin.

The point is shared column edges: the stats align to the primary button, and each microcopy line sits under the button it describes so the `↑` points at `LOGIN`. Below **1460px**, collapse to two columns and drop the flourish to its own row above the stats.

### The tapes — matched to the live `DashboardV2Header`

Two rows, each: fixed label (`MARKETS` / `ODDS`, `--text-dim`, `letter-spacing:0.16em`), a marquee region, and a fixed right stamp. Items separated by a left 1px `--border-strong` rule.

- **Marquee**: content duplicated exactly twice inside the track, `transform: translateX(0 → -50%)`, `linear infinite`. **MARKETS 64s right-to-left; ODDS 52s left-to-right** (`animation-direction:reverse`). Reduced-motion pins both.
- **MARKETS item**: symbol `--accent-amber`, value `--text-primary`, change carrying **both arrow and sign** (`▲ +3.43%` / `▼ -0.55%`), green/red. Stale entries take an `EOD` badge (`--fs-9`, `--border-strong` box). FRED-cadence entries take a dim cadence tag (`MO`).
- **ODDS item**: symbol amber, then `K <value>` and `P <value>` as two independent readings — **not one blended number**. `K` in `--stage-committee`, `P` in `#a78bfa`. One decimal, `%` suffix. A missing Polymarket half renders `N/A` dim; it does not hide the pair.
- **Right stamp**: `AS OF 12:01 AM UTC · CLOSED` on MARKETS, `AS OF 12:01 AM UTC · ● LIVE` (green dot) on ODDS. **State comes from the data, not a constant** — derive it the way the live tape does; if that derivation lives inside the client island and cannot be reached without touching it, that is a STEP 0 finding: render the stamp without the state suffix and file the suffix, rather than hardcoding `CLOSED`.

Symbols come from `lib/markets` config. `TAPE_SLOTS` and `TapeItem` in `page.tsx` are replaced.

### The three panels

Height **420px** each. Each panel holds **three datasets** that crossfade, and each dataset scrolls vertically on its own loop.

| Panel | Datasets (in cycle order) | Scroll | Direction |
|---|---|---|---|
| 1 | Bills · movers 7d → Stalls · longest since action → Enacted · became law | 26s / 30s / 24s | up |
| 2 | Members · most active 30d → Lobbying · LDA filings Q2 → Hearings · scheduled this week | 31s / 27s / 33s | **down** (`animation-direction:reverse`) |
| 3 | News · matched to bills → Races · 2026 rated → Patterns · corpus | 23s / 28s / 25s | up |

- **Crossfade**: 45s cycle, three phases, `ease-in-out`. Phase boundaries: dataset 1 visible 0–29%, 2 visible 33–62%, 3 visible 66–96%, wrapping 96→100%. Panel delays **0 / −15s / −30s** so no two panels swap together.
- **Header labels swap with their dataset** and must be in the same stacking cell as each other (one grid cell, `grid-area:1/1`) — **not absolutely positioned**, or the header collapses to bare padding and loses its height.
- **The header must paint above the fade overlays** (`z-index` above them, own background) or the top frost samples it and dims the panel title.
- **Vertical scroll**: content duplicated exactly twice per dataset, `translateY(0 → -50%)`, `linear infinite`. **No pause on hover.**
- **Fade and frost are two separate jobs, and this distinction is the whole point:** the rows fade by **alpha, via a mask on the scroll viewport** (`transparent → opaque 7% → opaque 60% → transparent`), so glyphs stay sharp all the way out. The frost is a **separate overlay on the panel surface** — bottom 120px, `backdrop-filter: blur(5px) saturate(0.85)`, itself masked so it only engages past 70% where the text has already faded to nothing. A top frost strip, 34px, offset below the header. **A `backdrop-filter` placed over live text smears the type; that is the bug this arrangement exists to avoid.**
- Reduced-motion: all scrolling and crossfades off, dataset 1 shown, others `display:none`.

### Row shape (all panels)

Grid `66px 1fr`, 9px/16px padding, 1px `--border-soft` bottom rule. Left cell: identifier (bill type+number amber/muted, district code, day, source tag). Right cell: title in `var(--sans)` `--fs-14` `line-height:1.28`, then meta in mono `--fs-11`, `margin-top:3px`. Stage colors reuse the existing `--stage-*` tokens.

### Responsive

Below **1180px** the banner collapses to one column and the panels stack. Below **900px** the page is a single column throughout. `/welcome` is the first page many people see on a phone; a stacked 420px panel per dataset is too much, so **on narrow viewports ship one panel with one dataset and no crossfade** — the table rules which.

## STEP 0 — enumerate; closure table; HALT

Line numbers in the recon are as of the base SHA — re-derive every one at your HEAD (HO 652). **Controls first, before any zero is trusted** (HO 664–669: ten instrument failures, zero code failures). Produce the closure table (candidate · verdict · evidence `file:line` · destination) covering at least:

1. **`app/welcome/page.tsx` inventory** — every element that survives, changes, or dies. `TAPE_SLOTS`, `TapeItem`, the `getLatestMarketTicks` read (survives), the CTA pair, the stat readout, the copy strings. Confirm the page's current server/client status and its caching/revalidate posture; state what the rebuild changes about it.
2. **`landing.module.css` font audit, per declaration.** Every `font-family` in the file, with what it resolves to. Positive control: name one declaration elsewhere in the app that DOES consume `var(--sans)` and show it reading. Verdict per declaration: retarget to a token, or keep with a reason.
3. **The nine datasets — the read-budget table. This is the gate that decides what ships.** For each of Bills/Stalls/Enacted, Members/Lobbying/Hearings, News/Races/Patterns: name the query that would serve it (`file:symbol`), whether it already exists or would be new, its cache tag and TTL if any, and its **measured `rows_read`** on the probe harness. Then state the page total against the **current** `/welcome` total as the baseline. **Budget: the rebuilt page's total `rows_read` may not exceed 3× the current page's.** Over budget → the table cuts datasets, cheapest-value-first, and says which. A dataset with no existing query is a candidate for filing, not for writing a new query inside this HO — unless the table shows it is trivial and says so.
4. **Lobbying, specifically** — the LDA rollup lives in `dashboard_state` (`lda-rollup` blobs, named live at HO 667). Confirm the key, the blob shape, and whether a read helper already exists. If the shape does not carry client/spend/registrant-count, the panel's Lobbying dataset is a **filing, not a build**.
5. **The clock's client boundary** — the smallest component that can carry it, `useZoneCycle`/`formatInZone` reuse confirmed by reading them, and the hydration story stated (no server-rendered digits).
6. **`lib/markets` config import** — confirm `MARKETS_TAPE`, `ODDS_TAPE`, `ODDS_PAIRS` are exported and are pure config. **Nothing in `lib/markets.ts` is edited by this HO** (its last edit was HO 669's `bareTape` retirement; do not reopen it).
7. **The CLOSED/LIVE derivation** — where market-state comes from today. Reachable without touching `MarketsTapeClient` → use it. Not reachable → stamp without the suffix and file it. **Do not hardcode a state string.**
8. **`docs/design/landing.html`** — present? Verdict: keep as history, one-line supersession note.
9. **SKILL inventory — fresh greps**, classify every hit LIVE-CLAIM vs RECORD: `welcome`, `landing.module`, `TAPE_SLOTS`, `TapeItem`, and any claim about the page's copy, its masthead, or its tape. The `/welcome` entry gains the new structure; the `TAPE_SLOTS` claim is falsified by this HO.
10. **Out-of-scope, named so it isn't absorbed:** `HeaderBar` and every other route; `components/MarketsTape*`; `lib/markets.ts`; `lib/queries.ts` except as a *reader*; `--font-mono`'s value; the ANSI block banner (built, rejected for v1, and **not** shipping — the SVG and PNG exist outside the repo if it is ever revived).

**HALT.** Paste the table back. If anything reads other than expected — a font declaration already on-token, a dataset with no query, a read budget blown by one panel, a client boundary bigger than one clock — that row's verdict changes and the table says so; do not force it.

## STEP 1 — the chore commit (after the table is approved)

`git checkout -b 670-review-local` first (`main` stays at `origin/main` until approval). One commit, one kind:

`chore(HO 670): rebuild /welcome as the board layout`

Expected shape: `app/welcome/page.tsx` largely rewritten, `landing.module.css` rewritten to the spec and on-token, one new client clock component, one new panel component if the table calls for it. **No other route, no shared component, no `lib/` edit.**

## STEP 2 — gates, including the read budget

- `npm run build` then `npm run typecheck`, both green — build first per the stale-`.next/types` oddity; report both readings if typecheck ran early and went red.
- **Read budget, re-measured post-build against the STEP 0 baseline.** Paste before/after `rows_read` for the page and per dataset. Over 3× → **HALT**, do not land; the table gets reopened.
- Source greps, controls first: `TAPE_SLOTS` and `TapeItem` read **0** across `app/ components/ lib/` (RECORD comments reported as "0 live, N RECORD"); control `getLatestMarketTicks` >0.
- **Built-CSS check** (`.next/static/css/*.css`): the new module's classes present; any `landing.module.css` selector the rebuild dropped reads 0. Name one surviving control selector reading >0.
- `git show --stat` lists exactly the approved files and **does not list `lib/markets.ts`, `lib/queries.ts`, or any component outside `app/welcome/` and the one or two new files**.

## STEP 3 — runtime confirmation (bind check mandated)

1. `npm run start` on a private port (3100+, `-p`), PID captured; **verify the started PID owns the port** (`lsof -i :<port>` / `ss -ltnp`) before any curl is trusted.
2. `/welcome` reads 200; both stylesheets 200. Content assertions, each named in the paste: the headline string, `IN BETA`, `ENTER TERMINAL`, `LOGIN`, `No account needed`, one real bill title from the Bills dataset, one real symbol from `MARKETS_TAPE`, and one `AS OF` stamp.
3. **The three-panel mount check.** Every dataset that the table approved must be **present in the served HTML**, not merely styled — grep one distinctive string per dataset per panel and report the count. A panel that renders its header but no rows is the failure mode to catch here: it means a dataset mounted empty, and a mid-crossfade screenshot will hide it. **All approved datasets read >0 or it is a HALT.**
4. `/` reads 200 with its masthead assertion — the control proving no shared surface moved.
5. Kill by PID, port-scoped; foreign PIDs left alone.

## STEP 4 — docs commit (`docs: HO 670 — …`)

4.1 **`docs/backlog.md`** — **four new entries**, each with its close criterion:
- **`HeaderBar` `IN BETA` + clock, all routes** — ruled by Corey 2026-08-17, deliberately not taken here (shared component on every route, HO 507). Close: land it behind route gates, with the `prefers-reduced-motion` guard the `/welcome` tag already carries.
- **`--font-mono` → IBM Plex Mono app-wide** — ruled by Corey in the mock. One token, every page. Close: swap with a before/after render gate on a named route set, or record a keep reason.
- **`/welcome` tape unification with `components/MarketsTape`** — this HO removed the config divergence (`TAPE_SLOTS` gone, `lib/markets` is now the single symbol source) but left two renderers. Close: mount the shared component, or record why a landing page keeps a presentational copy.
- **Any dataset the STEP 0 budget cut**, one entry naming the query it needs and the measured cost that cut it.
- Plus, if STEP 0.7 found market-state unreachable: the `CLOSED`/`LIVE` suffix, filed.

4.2 **`docs/roadmap.md`** — one `Also (HO 670)` block, append-only, pointer 670: the ruling and who made it, the rebuild's numbers, **the read-budget measurement stated as arithmetic** (baseline, per-dataset, total, the multiple), the three deliberate exclusions and the rule that produced each, the fade-versus-frost distinction as a design fact worth keeping, and the oddities disposition. No retro-edits to prior blocks.

4.3 **`docs/design/`** — commit the signed-off mock as `welcome-670.html` **only if Corey placed it in the tree**; add the one-line supersession note to `landing.html`. If the mock is absent, say so in the roadmap block and move on.

4.4 **`docs/oddities.md`** — only if something odd emerged. Nothing odd → no entry, and say so in the roadmap block (the HO 659/660 form).

## STEP 5 — SKILL commit (`docs(skill): HO 670 — …`), self-mod guarded

Its own commit, never riding another doc. **Minimal edits** per the approved STEP 0 classification:
- The `/welcome` entry: the new structure (top rail · BREAKING · banner · two tapes · three cycling panels · bottom rail), the copy change, `LOGIN`, the `IN BETA` tag, the token-consuming type.
- The `TAPE_SLOTS` / `TapeItem` claim → RECORD (retired at HO 670; symbols now from `lib/markets`).
- **`:2087` changelog append is CORRECT here** — the page gains a client island (the clock), so island membership changes. That is the HO 665 criterion, cutting the way it cut at HO 666. Cite the pair so it reads as applied, not habitual.
- Nothing else. The `/` entry stays flagged stale-as-enumeration (HO 646).

## HALT — the review ref; nothing lands before approval

Push `git push origin HEAD:refs/heads/670-review` (amend via `--force-with-lease` on the ref only; `main` only ever fast-forwards). Paste back: the executed table deltas, `git show --stat` of all three commits, the STEP 2/3 outputs **including the bind evidence, the read-budget arithmetic, and the per-dataset mount counts**, the backlog numstat with every deletion explained, and the docs + SKILL diffs. Remote claims via `git ls-remote`, never `rev-parse origin/*` (SKILL § Review-ref route). One swallowed block → re-deliver as a gitignored file, never a second paste (method.md § Relay). **The SKILL diff needs explicit approval** — the self-mod guard is satisfied by the ref, not bypassed by it. After approval: fast-forward `main` (`git push origin HEAD:main`, no `--force`), delete the ref, verify with `git ls-remote --heads origin`.

## Verification gates (run before the HALT; outputs in the paste)

- STEP 2/3 all green; working tree clean after the three commits.
- **Backlog numstat:** `git diff --numstat <docs-commit>~1 <docs-commit> -- docs/backlog.md` — insertions only expected (new entries, no strikes); any deletion explained line by line. `grep -c '^-[^-]'` is NOT a deletion count (HO 643).
- **Anchored greps** (HO 637 rule): `grep -cE '^\*\*Also \(HO 670' docs/roadmap.md` = 1; `grep -row "TAPE_SLOTS" app components lib` = 0 live; `grep -c "prefers-reduced-motion" app/welcome/landing.module.css` >0 (the guard exists, not merely intended); `grep -rn "font-family" app/welcome/landing.module.css` shows only token references or the flourish's declared fallback.
- Push only after re-checking HEAD ancestry (`git ls-remote --heads origin`), per method.md § Session start.

## Out of scope — named so it isn't absorbed

- **`HeaderBar`, the global mono token, and the tape unification** — all three filed above, all three deliberate.
- `components/MarketsTape*` and `lib/markets.ts` entirely (config is read, never edited).
- `lib/queries.ts` as anything but a reader; no new query lands here without the table saying it is trivial.
- The ANSI block banner, its SVG and its PNG — built during design, rejected for v1, not in the repo.
- The HO 661 settle-window WATCHes, the ~Sep 1 per-query ledger glance, the M3 re-arm (post-Sep-15) — none due.
- The `CRON_ROUTES` stale schedule string (rides the next `lib/cron-health.ts` touch).
- The method.md dual-write rule and the standing-instructions-block-into-method.md entry — both filed, neither written here.

---

read and follow 670
