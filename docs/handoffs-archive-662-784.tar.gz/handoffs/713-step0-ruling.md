# HO 713 — STEP 0 ruling (architect, 2026-09-11). The premise is false; the HO dissolves to docs. Four things are filed, nothing is built.

Good STEP 0, and the right instinct at the end of it: nothing written on a cause that does not exist. Function 12, local 12, prod 12; the cookieless probe of `/` was reading `/welcome` behind the HO 361 landing gate, on production only, because `AUTH_SECRET` is absent locally and the gate never fires there. The "dark band" was the probe.

Own the chain in the block, both links. Code inferred *no band* from a redirected curl and carried it forward as a local reading; the architect took that inference into the handoff's ground truth as a stated fact (*both rendered `/` with no band*) with a hedge that did not change what the sentence asserted. The disproof — `dom-home-base.html` and `dom-home-branch.html`, 246 `abw-` each — was on disk in `712-artifacts/` before the handoff was written, and neither of us grepped it. Two instruments agreeing is a reading of their agreement, not of the thing.

## 1. Close with no code fix. The two-zeros ruling is deferred, not dropped

Agreed: the ruling the handoff requested loses its incident and should not be decided on a false one. But the property it named is true independently of the incident and is written into the tree already: `lib/queries.ts:5577-5582` says that on this surface an empty array *is the good-news state, which renders nothing at all*, and the HO 598 guard returns exactly that array on a throw. A guarded failure and a quiet week are byte-identical on `/`. That is a design question for Corey, argued on its merits in its own handoff when he wants it; it goes on the ledger now so it is not lost, with the two candidate remedies (a dated one-line empty state from the roll-call date; a smoke assertion that `/` carries cards or that line) and no recommendation attached.

## 2. What is filed, two commits

**`docs(skill)`, alone behind the guard — two lines.** (a) Under the `/` route entry or the Absence Watch section, whichever the exposure grep puts closer: *any probe of `/` carries the `ct_seen` cookie (`GATE_COOKIE`), as every spec in `e2e/` and nine diagnostics already do; a cookieless request is 307-redirected to `/welcome` on production and served the dashboard locally, so it reads a different page in each environment while reporting the same URL.* (b) Under the revalidate route's entry: *`votes` is not in `ALLOWED_TAGS`; its only flush paths are `/api/sync-votes` on an insert, the amendments cron, and the one-hour TTL.* Numstat with deletions quoted, expected 0 deletions.

**`docs` — one commit.**
- **Oddities, one entry, both halves:** *a probe that never reached the page reads exactly like a page with nothing on it* — the gate, the environment split, the URL that does not change; and the second half as you wrote it: the disproof sat in the author's own artifacts, unread, because two sides agreeing was read as two sides being empty.
- **Backlog, two lines.** (1) *`votes` has no manual flush path* — `app/api/revalidate/route.ts` `ALLOWED_TAGS` lacks it; owner Code; close: the tag is allowlisted and a `POST` flushes `getAbsenceWatch` (proved by a before/after read of the band's `refreshed`-shaped field, or by the cache-miss log line); reads *no entry* today. (2) *Absence Watch: a guarded failure and the good-news state render identically on `/`* — owner Corey; the design question and the two remedies from § 1; reads *byte-identical* today by the `:5577-5582` comment's own account.
- **Roadmap `Also (HO 713)` block:** the HO dissolved at STEP 0 and why; the twelve members as the band's live content (MIA 1 · AT RISK 11, McConnell's streak of 60 since 2026-06-11, eleven at 12–14 since the July recess), so the *data movement, not drift* reading is in the record beside HO 623's original two; the chain in the paragraph above; `ABSENCE_WALK_BOUND = 120` re-read, the HO 712 scratch's 400 corrected in passing; row 7's finding; the four filings; pointer to 713. OPEN LOOPS reconciled at open and close: plus two, no strikes.

## 3. Then

Review ref `713-review`, `git ls-remote --heads origin`; gates are `check:design-citations` and the SKILL numstat, since no code moves; the `narrow-preview` reading is not implicated and is said not to be. Paste the two diffs in full. FF go follows the read and Corey's word.

read and follow 713-step0-ruling — the file, not this line
