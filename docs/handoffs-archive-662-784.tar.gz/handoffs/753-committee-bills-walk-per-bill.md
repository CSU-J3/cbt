# HO 753: the bills half of the committees cursor. The walk keys on each bill's own local write, not on a shared `update_date`, so a failed fetch, a cut group and a late `/api/sync` write all come back on their own

`docs/backlog.md` OPEN LOOPS, *The committees cron's bills cursor moves past a bill whose fetch or write failed…* (HO 744), owner Code, medium, measured by HO 752: 103 walked-set bills below the cursor have no committee rows and every one should. By the tick payloads, 14 were cut from a same-`update_date` group at a deadline, at most 10 were failed fetches, 45 were written by `/api/sync` below a cursor that had already passed (30 of them inside ticks that stopped early), and 27 can't be placed. One more class is confirmed once: 119-hr-3857 kept its rows from May and lost two activities to a failed fetch the log names. And a second line, *A bill's committees endpoint pages at 20 and the committees walk reads only the first page…* (HO 752), owner Code, medium: 14 bills list 21 committees, 13 store 20 and 119-hr-9821 stores none.

The line's own candidate remedies were a keyset cursor on `(update_date, id)` and a retry set. Neither reaches the plurality path. A bill `/api/sync` writes with an `update_date` below the cursor is invisible to any walk that keys on `update_date`, however it is ordered. So this HO changes the key: **each bill carries the time of its last local write that changed it, and the time its committees were last walked, and the walk selects bills where the first is newer than the second.** A failed fetch leaves the bill selected. A deadline or the 500 cap leaves the rest selected. A late `/api/sync` write stamps the bill newer than its walk. There is no shared cursor to move past anything. The meetings half is the next HO.

## Ground truth (read at `d173d19`; re-derive every `:N` by content)

- `lib/sync.ts` is the only writer of `bills` (`UPSERT_SQL`, `:178-218`; `upsertBill`, `:221`). Its `ON CONFLICT` already distinguishes a changed bill from a rewrite: `summary = CASE WHEN excluded.update_date != bills.update_date THEN NULL ELSE bills.summary END` (`:197-202`) resets only when `update_date` moved. `bills` has no local write stamp of any kind (`scripts/migrate.ts`, the `bills` table and its `ensureColumn` adds).
- `lib/committees-sync.ts`: `selectBillsSince` (`:164-186`) keys on `update_date > cursor` with `LIMIT`; `syncCommitteeBills` (`:226-256`) advances `cursorEnd` past a bill whose `try` failed (`:243-251`) and writes the cursor once after the loop (`:253-255`); `fetchBillCommittees` (`:188-193`) reads one page and no `pagination.next`; `upsertCommitteeBills` (`:195-224`) is upsert-only. The cursor is `dashboard_state` key `committee_bills_sync_cursor` (`:47`), read at 2026-09-25T17:23:25Z by HO 752.
- `app/api/cron/committees/route.ts`: bills get 45s of the 55s soft timeout (`:35`, `:74-76`), then meetings.
- `scripts/diagnostic/committees-cursor-752.ts` (sha `50c26f27e998`) is the reading instrument: no-row candidates below a cursor, each resolved against the endpoint, and the page-1 count computed from stored committees against the bill's own count. It keys its candidate set on the cursor, so this HO gives it a second mode keyed on the new columns.
- The fetch shim precedent is `scripts/diagnostic/ratings-hang-shim-744.cjs`; the legs run through the real route wrapper.
- api.data.gov answers with `X-RateLimit-Limit` and `X-RateLimit-Remaining` headers. STEP 0 confirms on one response, and the repair paces itself from them rather than from an assumed limit.

## STEP 0

1. HO number from the tree: `main` at `d173d19`, pointer 752, so 753. Otherwise stop.
2. Re-read every cited `:N` by content. Flag a drift.
3. Measure, prod, SELECTs only: the walked set (HO 752 read 17,773 at or below the cursor and 203 above); the 103 and the 14 by id (from HO 752's artifacts, re-derived); `committee_bills` row count; the newest `/api/cron/committees` and `/api/sync` rows.
4. One GET of a bill's committees endpoint: print the rate-limit headers and their values. If they aren't there, say so; the repair then paces at a fixed 1 request per 1.2s and stops on a 429.
5. Proceed without a halt unless something above contradicts this file.

## The build

1. Two columns on `bills` (`scripts/migrate.ts`, the house pattern): `changed_at TEXT` and `committees_walked_at TEXT`. `UPSERT_SQL` stamps `changed_at` on insert and, on conflict, `CASE WHEN excluded.update_date != bills.update_date THEN <now> ELSE bills.changed_at END`, the same shape as the summary reset. An unchanged rewrite leaves it alone.
2. `selectBillsSince` becomes `selectBillsToWalk`: `congress = ? AND json_extract(raw_json, '$.committees.count') > 0 AND (committees_walked_at IS NULL OR committees_walked_at < changed_at)`, ordered by `changed_at, id`, with the same `LIMIT`. A bill whose `changed_at` is NULL (never stamped, every bill today) is selected: that is the repair's set. No cursor is read or written; the `dashboard_state` key is left in place and retired in SKILL.
3. `syncCommitteeBills` stamps `committees_walked_at` for a bill only after its rows are written, in the same batch as the rows. A failed fetch or write stamps nothing, so the bill is selected again next tick. The deadline and the cap stop the loop and stamp nothing else. The payload gains `remaining` (bills still selected after the tick), `failed` (ids, up to 20, and the count) and `gaveUp` (below).
4. The give-up cap: `committee_walk_failures INTEGER` on `bills`, incremented on a failed fetch and reset on success. At 5, the bill is excluded from the walk and named in the payload's `gaveUp` until a later `/api/sync` change re-stamps `changed_at`, which resets the count. A bill that fails forever costs one slot five times, then is visible instead of silent.
5. `fetchBillCommittees` follows `pagination.next` until the page has no next, and the row set is the union. That closes the page-1 line for every bill going forward; the 14 are repaired by item 7.
6. `scripts/diagnostic/committees-cursor-752.ts` gains `--key changed_at`: the candidate set is bills with `committees_walked_at IS NULL OR < changed_at` resolved the same way, and the page-1 count as before. Both modes stay so the before and after are read by one instrument.
7. The repair, `npm run repair:committee-bills`, dry by default and `--write` to write: the same `syncCommitteeBills` with no deadline, paced from the rate-limit headers to stay under the key's limit with a margin (or at 1 request per 1.2s if the headers are absent), stopping on a 429, resumable because every stamped bill drops out of the selection. On today's data it walks every walked-set bill once, since none carries a stamp: about 17,800 requests, some hours, outside the crons' minutes. It writes prod only through `upsertCommitteeBills` and the two stamps.

## Legs, on a `file:` copy with a fetch shim, through the real route wrapper, each red first

Seed the copy the HO 746 way (`bills`, `committee_bills`, `dashboard_state`, `cron_runs`), URL built as `file:${abs}` by construction, perturbations refusing any other scheme. The shim serves recorded endpoint bodies and fails or delays on command.

1. Failure: the shim fails one bill's fetch. Red (today's code): the cursor passes it and it is never selected again. Green: it stays selected, is walked on the next tick when the shim serves it, and its rows land.
2. Truncation: 600 bills sharing one `changed_at`, cap 500. Red: the cursor moves to the shared value and the 100 are lost. Green: the 100 remain selected and are walked next tick.
3. Race: after a tick, upsert a bill through the real `UPSERT_SQL` with an `update_date` below every other bill's. Red: never selected. Green: `changed_at` is newer than its walk, and the next tick takes it.
4. Deadline: the shim delays so the tick stops at 45s. Green: every walked bill is stamped, every unwalked bill still selected, and the `cron_runs` row is `success` with `remaining` above 0.
5. Page two: 119-hr-9821's recorded two pages. Red: 20 rows. Green: 21.
6. Give-up: a bill the shim fails five ticks running is named in `gaveUp` and not selected on the sixth; an upsert that changes its `update_date` puts it back.
7. Idempotence: a rewrite through `UPSERT_SQL` with the same `update_date` leaves `changed_at` alone, and the bill is not re-walked.
8. The repair on the copy: the dry run writes nothing (content hash); the write walks every selected bill; afterwards the 752 instrument in both modes reads candidates 0, lost 0, stored-short 0, and 119-hr-3857 carries its two activities.

## Commits and docs

- `feat(HO 753)`: the columns, `UPSERT_SQL`, the walk, the cap, the pagination, the payload, the repair CLI and its npm line.
- `diag(HO 753)`: the 752 instrument's second mode, the legs driver and shim.
- `docs(skill)`, its own commit, approval requested: the committees cron entry (`:1206`) describes the per-bill key, the stamps, the cap and the payload, retires the `dashboard_state` cursor, and names the repair CLI; the `bills` schema block gains the three columns.
- `docs(HO 753)`: annotate the committees line (the bills half built and its legs; the meetings half owed to the next HO) and the page-1 line (the pagination built; its 14-bill repair owed to the prod repair in the FF go); the roadmap block, pointer 752 → 753. Reconcile OPEN LOOPS at open and close, control at 0. Strikes wait for the prod reading.
- Review ref `753-review`. The FF is held for the SKILL approval and review.

## The prod reading (in the FF go, not here)

Migrate before the deploy. After the FF: the repair's dry run pasted, then `--write` paced from the headers, its duration and request count; then the 752 instrument in both modes against prod (candidates 0, lost 0, stored-short 0); then the first two scheduled ticks' payloads (`remaining` draining, `failed` and `gaveUp` named). The committees line's bills half and the page-1 line strike on that reading, in the next docs commit.

## Gates

The cheap gates. No render code changes, so no captures. The `api_key=` grep over the artifacts reads 0 beside a control that reads 1.

## Paste back

- STEP 0's readings and the rate-limit headers;
- the eight legs, red and green;
- the SKILL diff, for approval;
- `git show --stat` per commit, `--numstat` for the docs commits, the reconcile, the `753-review` SHA from `git ls-remote`, and a last cheap-gate run.
