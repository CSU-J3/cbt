# HO 694 — the narrow viewport: a 430 gate, the overflow it catches, and a threshold re-derived

Test/CI kind plus two render fixes. Three findings from HO 690 sit filed and unrepaired, and they share one cause: **every standing width gate is wide-viewport-only** (`fit-finish` asserts the doc-scroll invariant at 1440 and 2560; the layout audit's M0 runs at 2560), so nothing can see a narrow defect. So the gate goes first, is run against prod **before** any fix so it is seen to fail on live data, and the fixes land under it.

1. **`/members` scrolls horizontally by ~141px at 430**, pre-existing. Attributed at HO 690 to `.mc-r-num` and one `.pol-time-collapsed-hint`; the mechanism is below.
2. **`@container bxp (max-width: 520px)` is stale exactly as its own HO 623 comment predicted**: HO 629 widened the column to 45% and nobody re-derived the threshold. Measured at HO 690: `/bills` 1140/2260px, `/` 598/1102px at 1440/2560 — all four wide, no desktop width stacks `/` any more, and the comment's *"520 keeps 1440 stacked"* is false. **This is not cosmetic after HO 690:** the dashboard panel at 1440 renders the two-column body with a ~254px metabox holding a 136px portrait. Corey ruled that portrait off a mock whose dashboard pane was labelled *stacked*, which the tree no longer did. The re-derivation makes the label true again.
3. **No narrow doc-scroll invariant exists**, which is why (1) shipped and stayed.

## Ground truth at authoring (`409e074`, HO 693 shipped 2026-09-04)

- Clone at `409e074`, pointer 693, number `max(693, 693) + 1 = 694`. Re-derive at session open.
- **The crawl.** `e2e/smoke.spec.ts` holds `ROUTES` as a file-local const (`:119–152`, ~30 routes incl. detail pages on constants `BILL/MEMBER/RACE/COMMITTEE/REPORT/VOTE`), the gate cookie idiom (`:426`), the `@nonci` exclusion. `e2e-prod.yml` runs `smoke.spec.ts e2e/odds-off.spec.ts --grep-invert "@nonci" --retries=2` on `deployment_status` + daily schedule. `fit-finish.spec.ts:482–510` is the doc-scroll idiom (`scrollWidth <= clientWidth` after `setViewportSize`), local only, 1440/2560. `odds-off.spec.ts` (HO 693) already runs five routes at 430 and asserts doc-scroll there — **so a 430 invariant exists for five routes today and for none of the other ~25**; this HO generalises it, it does not invent it.
- **The roster row.** `.mc-row` (`globals.css:6286–6295`) is `grid-template-columns: minmax(0, 240px) 320px 56px 64px 52px`, `column-gap: 12px`, `padding: 7px 14px`. **The fixed tracks alone are 320+56+64+52 = 492px, plus four 12px gaps and 28px padding = 568px; at a 430 viewport that is 138px over before the name column has a single pixel** — the 141 measured. Markup: `app/members/page.tsx:324` (row), `:363` (`MemberTopicBar`, the 320px track — `.mc-bar-track` / `.mc-bar-fill` / `.mc-bar-seg`, widths in `%` of the track), `:366/:372/:380` (`.mc-r-num`), `:416–421` (header row). **`.mc-row` is shared with `/lobbying`'s `FilingRow`**, which overrides the template on `.lob-filing-row` (`:6660`, per its own comment) — so a `.mc-row` mobile rule must be checked on `/lobbying` too, and `/lobbying` is in the crawl. No `@media` touches `.mc-row` today (grep `:6280–6330`); the 700px breakpoint is the app's (15 blocks in the file).
- **`.pol-time-collapsed-hint`** (`globals.css:1572`, `white-space: nowrap`, measured 286px) sits in `.pol-time-head` (`:1539`, `display: flex`, no wrap) beside the title and the segmented control; at 430 the flex row does not wrap and the hint pushes past the edge. `PolarizationOverTime.tsx:144`.
- **The container query.** `.bxp` is the container (`globals.css:4552–4553`, `container-name: bxp`); the HO 623 derivation comment at `:4580–4588`; the query at `:4591` with its three stacked rules; `.bxp-body` is `1.35fr 1fr` (`:4576`), `.bxp-left` `padding-right: 28px`. Meta column width = (panel − 28) / 2.35. The metabox's floor is set by the HO 690 sponsor block: 136px portrait + 11px gap + the name/bracket/state stack.

## STEP 0 — enumerate, then proceed (no HALT expected; flag what surprises)

| # | candidate | expected |
|---|---|---|
| 1 | the gate's baseline, **against prod before any fix** | a scratch run of the new spec (STEP 1) over every crawl route at 430: the pass/fail list. Expected red: `/members` (and `/members/pass-rate` if it shares the row). **Every other red is a finding**, enumerated with its over-edge elements (`document.elementsFromPoint` sweep past `clientWidth`, the HO 690 attribution method) before anything is built |
| 2 | the roster arithmetic | the 568px figure re-read off the computed grid at 430 (`getComputedStyle(row).gridTemplateColumns`, gap, padding); `/lobbying`'s `.lob-filing-row` template read the same way, at 430 and 1440 |
| 3 | the pol head | `.pol-time-head` computed `flex-wrap` and the hint's width at 430; whether the head overflows on its own or only with the segmented control present (collapsed vs expanded state) |
| 4 | the metabox floor | the sponsor block's natural width at HEAD: render `/bills` at 1440 with a row expanded, read `.bxp-sponsor` `scrollWidth` with the text stack at its longest live name (`Rep. ` + the longest sponsor name in the current page; state the name). That figure, not a guess, is `metaboxMin` |
| 5 | the panel widths, re-measured | `.bxp` inline width on `/` and `/bills` at 430 / 1440 / 2560 with a row expanded (the HO 690 figures re-read at HEAD); the current dashboard-@1440 metabox width and a capture of it with the 136px portrait — **the BEFORE for finding 2** |
| 6 | SKILL exposure | the `.bxp` container-query sentences (HO 623 / 629 entries), the `/members` roster row description, the e2e / crawl section (HO 693's new paragraph), the CI section, the "Visual captures mandatory at 1440/2560" rule (it should now say the 430 doc-scroll is a gate, not a capture). Expected five touches |

## STEP 1 — the gate first (test commit + ci commit)

- Extract `ROUTES` and its constants from `smoke.spec.ts` into **`e2e/routes.ts`**, imported by `smoke.spec.ts` (byte-identical behaviour; the smoke pass count unchanged, quoted) and by the new spec. `odds-off.spec.ts` keeps its own five-route list; it tests something else.
- **`e2e/narrow.spec.ts`**: for every route in `ROUTES`, at **430** (`setViewportSize`), gate cookie as smoke does, one navigation (`domcontentloaded` → `load` → the crawl's settle wait), then `scrollWidth <= clientWidth` on `documentElement`, and on failure log the over-edge elements (the row-1 sweep) so a red run names its cause without a local repro. Redirect routes assert the same on the landing page they arrive at. No screenshots, no collectors beyond the read.
- **Falsification is row 1 itself:** the spec is red on `/members` against prod at HEAD. Quote the failure line and its over-edge list. A gate seen failing on live data needs no synthetic leg.
- `e2e-prod.yml`: add `e2e/narrow.spec.ts` to the run. **Wire it only after STEP 2 makes it green**, or the first CI run on this SHA is red by construction; say so in the roadmap block.

## STEP 2 — `/members` at 430 (code commit)

- `@media (max-width: 700px) .mc-row` becomes a **two-row cell**: row 1 `minmax(0, 1fr) 56px 64px 52px` (name + the three numerals, gap 8px), row 2 the topic bar spanning all columns (`grid-column: 1 / -1`, `grid-template-areas` or an explicit `grid-row` on `.mc-bar-track`), the track `width: 100%` so the percentage fills scale to the row. The header row (`:416–421`) follows the same template minus the bar. `/lobbying`'s `.lob-filing-row` keeps its own template — read it at 430 (row 2) and fix it in the same commit **only** if the gate found it red; otherwise leave it and say so.
- `.pol-time-head { flex-wrap: wrap }` at ≤700 (or drop `nowrap` on the hint there); whichever row 3 shows is the cause. Not both unless both are.
- Re-run the gate locally (`BASE_URL=http://localhost:3000` production build): green on `/members`, and the pass/fail list from row 1 fully green or every remaining red named and filed. Captures at **430 only** for these two (plus a 1440 control that nothing moved — the ≤700 scope means the desktop row is byte-identical; measure the computed template at 1440 before and after).

## STEP 3 — the container threshold (code commit)

Re-derive, do not pick: `threshold = ceil((metaboxMin × 2.35 + 28) / 10) × 10` with `metaboxMin` from row 4. Expected in the neighbourhood of **760–800px** (a ~320px floor → 780). Replace `520px` and rewrite the `:4580–4588` comment as a derivation record: the formula, `metaboxMin` with the name it was measured on, the date, and the four panel widths from row 5 with which side of the threshold each lands on — expected `/` @1440 **stacks**, `/` @2560 wide, `/bills` wide at both, 430 stacks. Keep the HO 623 sentence about the threshold moving with its container; it was right and it is the reason this HO exists.

Proof: `/` at 1440 with a row expanded, BEFORE (row 5's capture, 254px metabox) → AFTER (stacked, the metabox full width under the prose), and `/bills` at 1440 unchanged (wide, two columns, byte-identical computed template). Reduced-motion pass on the two changed captures. The `bxp` panel at 2560 on `/` stays wide; capture it so the threshold is seen from both sides.

## Gates

`typecheck`, `build`, `check:odds-sites` exit 0. Local: `smoke` (count unchanged after the `ROUTES` extraction, quoted before/after), `odds-off` unchanged, `narrow` green, `fit-finish` doc-scroll at 1440/2560 unchanged. The 692 ON baseline re-read (`on-baseline-692.ts`) — the container threshold changes geometry on `/` at 1440 with a row **expanded** only; the baseline's cells have no row expanded, so it should be identical; if a cell moves, stop and say which. After FF: one by-hand prod `narrow` run, then the CI run quoted when `deployment_status` fires.

## STEP 4 — SKILL (own commit, self-mod guard) and docs

SKILL: the `.bxp` entries gain the re-derived threshold with its derivation and the record that 520 was false from HO 629 to HO 694 (provenance after the sentence, never inside); the `/members` row gains its ≤700 two-row shape and the shared-with-`/lobbying` caveat; the crawl section gains `narrow.spec.ts` beside the two specs it joins, with the sentence *the doc-scroll invariant is now a prod gate at 430 for every crawl route, and a capture rule at 1440/2560*; the capture rule updated to match. Docs: roadmap `Also (HO 694)` + pointer; backlog — the three HO 690 filings **struck with provenance** (this HO, the gate, the measured figures), never deleted; a new line only if row 1 found reds this HO did not fix.

## STEP 5 — review ref, FF

`694-review`, ls-remote, architect review, SKILL slot, FF, ref deleted, `verify:deploy`, the prod `narrow` run, the CI run.

## Paste-back

STEP 0 table with row 1's full pass/fail list and row 4's `metaboxMin` with its name. After STEP 3: the gate's red line on `/members` before and green after, the derived threshold with its arithmetic, the BEFORE/AFTER dashboard captures, the smoke count before/after the extraction. SKILL diff attached. After FF: ls-remote, served SHA, the prod run, the CI run.

read and follow 694
