# HO 719 — M1c: the layout audit learns column flow, `.so-group-names` carries the marking, and residue line (viii) leaves the register

The ruling this HO executes, verbatim (architect, HO 718 FF go, 2026-09-12; filed at `docs/backlog.md:117`): *"M1 = 2 is the instrument, not the build. Ruled (i), landed as its own HO; this one ships with the residue cited. The handoff's expected 0 assumed the layout audit reads column flow. It does not: the two M1b hits at 2560 are `.so-group-names`, CSS multi-column name lists whose rag is the column gutter, which is the C8 remedy being read as a C1 gap. Nothing is pinned right. (ii) is a per-host tune that cannot reach 0; (iii) is against the ruled mock. (i) stands, in the registry's grammar: the audit learns column flow and counts such containers on their own line, M1c, with an explicit marking on the container and a curve beside it, the way `data-viz-row` earned M1x. That is an instrument HO with a SKILL amendment to the exemption rule, not a ride-along on this ref."*

Four commits, kinds pure: `feat` (the audit and its fixture) · `feat` (the marking, one attribute) · `docs` · `docs(skill)` alone behind the self-mod guard. Read-only on the DB. Nothing under `e2e/` is touched, so the `backlog:51` week's dailies keep crawling the same spec.

**The close, as filed:** M1c exists, the fixture legs are green, and `--route electoral-2028` reads **M1 0 · M1c 2** with the marking in the exemption registry. **What it reads if the work never happened:** M1b 2 on that route, every run, with no line that says why.

## The design, so STEP 0 has something to check the tree against

Three properties, and the second is what keeps `data-col-flow` from becoming a second pressure valve beside `data-viz-row`:

1. **The marking is `data-col-flow`, on the container.** Same grammar as `data-viz-row`: authored in the component, counted by the audit, never inferred. Site today: `components/SeatOutlookList.tsx:244`, the two `div.so-group-names`.
2. **The exemption needs the marking AND the computed style.** An element leaves M1 for M1c only when it carries `[data-col-flow]` **and** `getComputedStyle(el)` reads `columnWidth !== "auto" || columnCount !== "auto"`. A marked element that does not compute multi-column buys nothing: it stays scored and is reported under **marked, not col-flow**. An unmarked multi-column candidate over threshold stays in M1b and is reported under **unmarked col-flow** — that is the leak line, and it is what makes today's M1b 2 legible tomorrow if the marking is ever lost. Both lines print every run, zero or not.
3. **The container leaves M1; the rows inside it do not.** `data-viz-row` uses `closest()` because chart rows are the encoding. Here the licence is the column gutter, and a `.so-name-row` is an ordinary text row whose own far-right anchor would still be a C1 defect. So the test is `el.matches("[data-col-flow]")`, never `el.closest(...)`. State this in the exclusion's comment; it is the one place the two markings differ in mechanism.

**M1c counts CONTAINERS.** Its structural half, beside it, is what the attribute reaches: `colFlowMarkedCount` and `colFlowMarkedKeys`, the `vizMarkedKeys` form (`tag.firstClass`, sorted). Per container the audit records rendered columns (distinct visible-child left edges, ±2px), the computed `column-gap` in px, the container width, and the worst interior gap it would have scored, so the curve below is read off the same object the exemption fires on.

## Ground truth (read at `64c5dbb`; re-derive every `:N` by content)

- `scripts/diagnostic/layout-audit-606.ts` is 1,833 lines. `:7-9` the two M1 modes; `:142` `M1B_MAX_CHILD_H = 60` (a `.so-name-row` is ~24px, so the container cut at `:460-467` does not fire and the group is a candidate); `:150` the fixture path `scripts/diagnostic/fixtures/layout-legc.html`; `:183` `{ slug: "electoral-2028", path: "/electoral?cycle=2028" }`; `:264-295` the DISTRIBUTION marking's curve comment — the form a curve takes in this file; `:429-437` the `Row` type (`mode: "M1a" | "M1b"`); `:440` `let vizExempt = 0`; `:450-452` candidacy (`isM1a`, `wideEnough`); `:468-475` the counted viz exemption (`el.closest("[data-viz-row]")`, `vizExempt++`, `continue`) — the new exclusion goes directly after it; `:1016-1032` the `m1` summary object (`m1aCount`, `m1bCount`, `candidateRows`, `vizExempt`, `vizMarkedCount`, `vizMarkedKeys`); `:1073` `type Measured`; `:1075-1082` leg C's contract — every fixture case has exactly one assertion and every assertion prints the number it read; `:1177-1184` the CAL M1x case (exactly 3, scored 0); `:1440-1497` leg B — the fixture's calibration block plus the live `/` reach (`HOME_VIZ_MARKED = ["ul.stage-funnel", "ul.topic-dist"]`), asserting what the attribute REACHES, not a candidate count; `:1548-1552` the per-route line (`M1a … M1b … M1x`); `:1713` the summary table header and `:1719` the M1x legend line; `:1730-1743` the site totals.
- `scripts/diagnostic/fixtures/layout-legc.html` is 519 lines; `:418-419` the calibration block `<div class="legc-cal-viz" data-viz-row>`; 31 distinct `legc-*` ids today. Count of leg C assertions at HEAD: **~24 (estimate; STEP 0 counts from the run)**.
- `components/SeatOutlookList.tsx:236-249`: `.so-roster` → `.so-group` (one per party) → `.so-group-label` → `<div className="so-group-names">` at `:244`, mapping `NameRow`s. No `data-` attribute on it today.
- `app/globals.css:11273-11276` `.so-group-names { column-width: 17rem; column-gap: var(--space-lg); }`; `:11277-11283` `.so-name-row { break-inside: avoid; … }`. `:11112-11122` is the HO 718 header comment for the block.
- `.claude/skills/cbt/SKILL.md:2000-2007` THE C1 EXEMPTION RULE, four clauses; `:2007` reads *"The live register — seven markings and their curves"* — the register at `docs/backlog.md:323-334` lists **eight** (1)–(8), so the count was stale by one before this HO adds a ninth. `:2358` the roster sentence: *"names in CSS multi-column (`column-width: 17rem`) so a wide screen buys columns (C8)"*. `:2360` the NEWS miss sentence; the ` appointed` leading-space edge is **not** in it yet.
- `docs/backlog.md:117` the M1c line (this HO's close criterion); `:114` the `electoral` tag line whose parenthetical says the ` appointed` edge *lands there on the next SKILL touch of the seat-outlook section*; `:318` the registry (creep guard verbatim, kind annotation at `:320`, unit caveat at `:336`); `:340` the residue register, `(viii)` at `:358`, ending *"Leaves this register when the M1c instrument HO (OPEN LOOPS) lands and re-reads the route as M1 0 · M1c 2."*
- HO 718's readings, from `(viii)`: at 2560 each group is 1,251px, 4 columns at a 317px pitch, within-group gutters 74–182px by a direct per-column ink read, M1 rows 200px and 209px off `m1.rows`. Nothing pinned right.
- `docs/method.md` § Gates (render-touching work captures, and a gate you cannot fail is not a gate); § Environment (CI is Ubuntu; the `narrow-preview` job gives a review ref a real width reading before the FF; the box vs the MacBook).
- Estimates, not readings: columns rendered at 1920 and 1440 are **~3 and ~2**; a `--route` run is ~4 page loads; the fixture opens over `file://` and needs no server.

## STEP 0 — enumerate, HALT

| # | check | expected | if the work never happened, this reads |
|---|---|---|---|
| 1 | `git ls-remote --heads origin`; `git status --porcelain`; pointer and highest HO in commit subjects; which machine | `main` at `64c5dbb`, no other heads; tree clean; 718 / 718 → **719**; box or MacBook named | anything else stops here |
| 2 | quote `layout-audit-606.ts:468-475`, `:1016-1032`, `:1548-1552`, `:1177-1184`; `SeatOutlookList.tsx:244`; `globals.css:11273-11276`; SKILL `:2000-2007`, `:2358`, `:2360`; backlog `:117`, `:114`, `:358` | as in ground truth | a `:2007` that already says eight, or a `:2360` that already carries the ` appointed` edge, changes the SKILL step |
| 3 | `npm run build`, `npm run typecheck` baseline | exit 0 · exit 0 | a red baseline is not this HO's to fix; report it |
| 4 | leg A/B/C at HEAD (the falsification run, no crawl): the assertion count and every reading | all green; count recorded (the ~24 above is an estimate) | the count is the number STEP 1's run must exceed by exactly the cases it adds |
| 5 | `--route electoral-2028` at HEAD, local production build, hit 2, reading `m1.rows` for `.so-group-names` | **M1 2 · M1b 2 · M1x 0**, gaps ~200/209px at 2560 | **this is the pre-state and the control**; a route that already reads 0 here means the geometry moved and the marking has nothing to license |
| 6 | `--route home` at HEAD: M1a · M1b · M1x · M2 | recorded verbatim | the bridge control STEP 1 must reproduce unchanged |
| 7 | `getComputedStyle` on one live `.so-group-names` in the served page: `columnWidth`, `columnCount`, `columnGap`; and the count of distinct child left edges at 2560 | `272px` · `auto` · a px length · 4 | if `columnWidth` reads `auto`, property 2 cannot fire and the design needs re-ruling before code |
| 8 | `.so-group-names` children's own candidacy: for one `.so-name-row`, `kids.length`, `siblings`, its interior gap | 3 · ≥3 · under threshold | this is why property 3 is `matches`, not `closest`: the rows are M1a candidates in their own right and must stay so |

HALT here with the eight rows. The go arrives as a file.

## STEP 1 — the audit and its fixture (commit `feat(HO 719)`; two paths, staged by name)

In this order, because the middle step is the control.

1. **Fixture first.** Add three cases to `scripts/diagnostic/fixtures/layout-legc.html`, each a ≥700px container of ten short two-span rows (`break-inside: avoid`), sized so four columns render at the fixture's width and the inter-column rag exceeds `GAP_THRESHOLD_PX`:
   - `legc-colflow-pos` — `data-col-flow`, `column-width` + `column-gap` set. Must read **M1c 1, scored as M1 0**.
   - `legc-colflow-unmarked` — identical CSS, **no** attribute. Must stay **M1b 1** and read **unmarked col-flow 1**.
   - `legc-colflow-dormant` — `data-col-flow` on a plain wide row with a 300px gap and no column properties. Must stay **M1 1** and read **marked, not col-flow 1**.
   Keep the rows at two children each so no case is an M1a candidate; the container is the unit under test.
2. **Run leg C before the audit changes.** The new positive must read as **M1b 1 with M1c undefined/0** — the instrument in its blind state, on the exact geometry the live page has. Paste this. It is the proof the change can fail.
3. **The audit.** After `:475`: the `data-col-flow` exclusion per properties 1–3, the per-container record, `colFlowExempt`, `colFlowUnmarked`, `colFlowDormant` (each a count and the keys), `colFlowMarkedCount` / `colFlowMarkedKeys`; the `m1` summary object carries all of them; the per-route line gains `M1c`; the table gains an `M1c` column and the legend a line (*M1c = marked CSS multi-column containers, EXEMPTED from M1 and counted here; rows inside stay scored*); the totals gain site M1c and the two leak lines. Leg C gains three assertions (exact readings, paired controls, the `:1075-1082` contract). Leg B gains the live half: open `/electoral?cycle=2028` at 2560 (hit 2), assert every `colFlowMarkedKey` is `div.so-group-names` **and** the marked count equals the count of `.so-group` on the served page (self-consistent, so the 120th-Congress HOUSE groups do not break it), **and** 0 rows whose `selectorPath` matches `so-group-names` are scored as M1; print M1c beside it as an observation, not a gate. Update the header comment's measurement list (`:7-9`) with the M1c line.
4. **Re-run legs A/B/C.** All prior cases unchanged and green; the three new ones exact. **Bridge control:** `--route home` reads M1a · M1b · M1x · M2 identical to row 6, printed side by side.

Neither path is in `e2e/`. `scripts/**` is in the root `tsc` program, so `npm run typecheck` reads the audit.

## STEP 2 — the marking (commit `feat(HO 719)`; one path)

`components/SeatOutlookList.tsx:244` becomes `<div className="so-group-names" data-col-flow>` with a two-line comment in the HO 617/619 form naming the licence (the gap is the column gutter, C8's remedy; the rows inside stay scored) and pointing at the registry. No CSS change.

**Then the close reading, and the curve, both from a local production build of this commit:**

- `--route electoral-2028`: **M1 0 · M1b 0 · M1c 2 · unmarked 0 · dormant 0**, `colFlowMarkedKeys` = `div.so-group-names` × 2. Quote the two container records (columns, gutter px, width, worst gap).
- **The curve, applied in the page and re-read, never modelled** (SKILL `:2002`): at **2560 · 1920 · 1440**, per group: width, rendered columns, computed gutter, every adjacent-column rag (next column's ink-left − this column's ink-right), and the worst interior gap the audit would have scored. Then, at 2560 only, inject `column-width: 14rem` and `20rem` on `.so-group-names` in-page and re-read the same numbers. **This is the measured form of the (ii) price** — the rag persists at every width because a column of short names always ends before the next column starts — and it goes into registry entry (9) as the licence.
- **DOM floor (HO 718 STEP 2 form):** base vs branch captures of `/electoral?cycle=2028` with `reducedMotion: "reduce"` and `<script>` stripped: innerText **+0/−0**; outerHTML differs by exactly the two `data-col-flow` attributes and nothing else. Captures at 1440 / 2560 / 430 kept in the paste for the eye, not asserted identical (the masthead clock moves).
- `npm run check:odds-sites` exit 0, count unchanged (the file is a gated render site; the attribute adds no market reference). `npm run check:design-citations` OK.

## STEP 3 — docs (commit `docs(HO 719)`; `docs/backlog.md`, `docs/roadmap.md`, `docs/oddities.md` if anything surprised)

- **`:117` strikes** on the three readings its criterion names, with STEP 0 row 5 quoted beside them as the pre-state.
- **The registry gains (9)** — `div.so-group-names` × 2 on `/electoral?cycle=2028`, marking `data-col-flow`, kind **flow** (a new kind beside magnitude / shared-axis / sequence: the gap encodes nothing, it is the C8 remedy verified by computed style), units **M1c 2 containers / 2 groups / 34 name rows**, the applied curve from STEP 2, and the two leak lines' zero. Restate the pair's identity in the register's own words: site M1 = named residue + M1x + M1c, nothing unexplained. The creep guard sentence gains its second clause.
- **Residue line (viii) leaves** by its own clause: append the close note with the re-read (M1 0 · M1c 2) and where it went. Cited, never deleted; (iv)'s sum is untouched because (viii) was never in it.
- **`:114`'s parenthetical** annotated: the ` appointed` clause landed in SKILL at this HO (STEP 4).
- **Roadmap:** one `Also (HO 719)` block, pointer 718 → 719, the readings and the curve in it.

## STEP 4 — SKILL, alone (commit `docs(skill)`; four edits)

1. `:2000-2007` — the rule gains the column-flow clause: `data-col-flow`, on the container, exempt only when the marking and the computed multi-column style agree, rows inside stay scored, counted on **M1c**, the two leak lines named. Its own paragraph after clause four; do not fold it into the axis-encoding clauses.
2. `:2007` — *"seven markings"* → the correct count (eight `data-viz-row`, one `data-col-flow`), naming the registry as the live record.
3. `:2358` — one clause after `(C8)`: the container is marked `data-col-flow` for the layout audit (M1c). Forced consequence of STEP 2, named as such.
4. `:2360` — because this HO touches the seat-outlook section, `:114`'s standing instruction fires: one sentence adding the ` appointed` edge (the leading space keeps *disappointed* out and misses a title that begins with *Appointed*; untested). Rides here, one sentence, and nowhere else.

Any SKILL clause that lands verbatim is read against the tree first (method § Handoff discipline).

## Gates

Build then typecheck, both exit 0, re-run immediately before the paste. Legs A/B/C green with the count from row 4 **+3** and every new reading exact. STEP 1.2's blind-state reading pasted. Bridge control on `home` identical. `--route electoral-2028` **M1 0 · M1c 2** against row 5's **M1 2**. The curve at three widths plus two injected column widths. DOM floor +0/−0 with the two-attribute outerHTML delta. `check:odds-sites` and `check:design-citations` exit 0. Bind evidence for every local server. On the ref: the `narrow-preview` run for the Preview deployment, quoting `electoral-2028` at 430 and 390 — the CI width reading that now exists before an FF (method § Environment, HO 703 amendment). The Production smoke and odds-off readings on the shipped bytes are owed after the FF, as always.

## Review ref, then FF

Review branch from the start; push the ref; the SKILL diff approved alone; `HEAD:main` no force; `git ls-remote --heads origin`; delete the ref; `npm run verify:deploy` for the tip. Paste-back per method § Executing a handoff: the closure table as executed, `git show --stat` per commit, gate outputs with bind evidence, `git diff --numstat` on `docs/backlog.md` with every deletion explained (expect the rewritten `:117`, `:114` and `(viii)` lines), the docs and SKILL diffs, every remote claim via `ls-remote`. One swallowed block re-delivers as a gitignored file, never a second paste.
