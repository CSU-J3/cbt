# HO 729 — STEP 0 ruling and go

Both corrections accepted, the wording change accepted, one clause added. Every figure in your rewrite re-derives at my end.

## Verified independently

- `:363` carries *"thresholds arrive as an argument"*; `:364` is the divider. My anchor was off by one.
- `GAP_THRESHOLD_PX`: 14 lines — definition `:155`, pass-through `:353`, **7 applications** (`:1266`, `:1274`, `:1397`, `:1406`, `:1418`, `:1582`, `:1595`), 5 labels (`:1268`, `:1276`, `:1481`, `:1588`, `:1983`). My six counted `:1983` — a label — and missed the two negative-control legs.
- `t.gapThreshold`: type at `:343`, pass-through at `:353`, **4 applications** at `:708`, `:1116`, `:1117`, `:1118`. 7 + 4 = 11.
- `:1970-1971` sums `m1aCount` and `m1bCount` — written at `:1117-1118` — into the totals `:1983` prints. **The identifier grep misses exactly the two lines that produce the scored count.** That is a materially better finding than mine: not "the grep undercounts" but "the grep misses the count."
- `trailingGapPx` has two hits in the repo, the type at `:469` and the write at `:722`. *Read by no code* is the precise form.

## The "four consecutive handoffs" error, and what it earns

You are right on both counts. Two handoffs, not four. One STEP 0, not four. And the stages you list are the accurate record: a SKILL-approval addendum, a STEP 0, an FF paste, a roadmap block.

**This is a fifth instance of the thing the bullet is about, and it is the one worth naming inside the bullet.** I had four corrections in hand and rendered them as *four consecutive handoffs* and *corrected at STEP 0* without counting either — an inference from material I was holding, which is the same move as reading `trailingGapPx`'s definition and inferring its use. A rule whose first draft violates it is better evidence than four tidy examples, because it tells the reader the rule is not obeyed by intending to obey it.

So land your text with one clause added after the stage list: **the first draft of this bullet miscounted them as four handoffs and put them all at STEP 0, which is the fifth instance.** One sentence, no more — the stage list already does the evidential work and the bullet should not become a confession.

**Your wording change is a real catch and stands.** *Grep the value, not the identifier* prescribes a technique that repeats the miss: grepping the literal `120` finds `t.gapThreshold` no better than grepping the constant name does. *Grep every name a value travels under* is the instruction that would actually have worked.

## STEP 1, otherwise as written

Your bullet plus the one clause, at the placement row 2 confirmed — after the ground-truth bullet, before the `docs/handoffs/` repo-ignored one. The roadmap block carries the corrected counts, the four stages, the fifth instance, and the `:1117-1118` finding stated as its own point rather than folded into the arithmetic; `roadmap.md:2278` already reads *the likely history, not a reading*, so the fourth clause is accurate and nothing there needs touching.

No backlog, no oddities, no SKILL. Open loops **260 / 263** at open. `check:design-citations` from a fresh clone of the ref. Build and typecheck not run, named as not run with the last green SHA. No `ci` run expected on the push — say so rather than reporting the absence as a miss. No `verify:deploy`, no Production read.

Go.
