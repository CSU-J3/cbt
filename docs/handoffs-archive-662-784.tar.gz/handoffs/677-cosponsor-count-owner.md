# HO 677 — reconcile `bills.cosponsor_count` with the roster, and give the column an owner

**Read this file in full before executing anything. Execute in order. HALT conditions are hard stops — report and wait, do not improvise past them. Three HALTs: the STEP 0 closure table, the STEP 3 captures, and the pre-land review ref. Nothing lands on `main` before the last is approved.**

Base: `main` at `6d36139` (HO 676 landed, verified serving) or later. Clone fresh; verify HEAD before starting (`docs/method.md` § Session start). Number per method: max(roadmap pointer 676, highest commit-subject 676) + 1. Environment: code edit + `npm run build` then `npm run typecheck` (build first), plus local `npm run start` renders **with captures** — this changes what the panel prints on ~1 bill in 7, so § Gates applies in full. **Bind check mandated on every start.**

## What this closes, and why its premise only just became true

`docs/backlog.md:81` says `bills.cosponsor_count` is stale, and its premise is *once the rosters exist, the roster is the better source.* HO 675 amended it in place to record that the premise now holds; HO 676 made it actually true by giving the rosters a maintenance path. Until then the entry was resting on something that did not exist.

The measurements, all from this arc and all needing re-taking rather than citing:

- **1,905 of 13,931 bills disagree** (HO 676 final; HO 674 read 1,915, HO 675 read 1,910). It moves.
- **Direction is one-way**: roster ahead of count on essentially all of them, because cosponsors accrue without moving `updateDate`, so no upsert fires and the column never learns. Net +4,873 cosponsors the column does not know about.
- **The disagreement is on screen.** HO 675 shipped the COSPONSORS row with the total from `bills.cosponsor_count` and the group headers from the roster, ruled visible rather than repaired. On ~13.7% of bills the panel prints e.g. "24 cosponsors" above groups summing to 26. Median +1, p75 +3, p95 +8, max +50, 56 bills over 10.
- **`bill_roster_state.active_count` already exists** and is maintained by `/api/cron/bill-rosters` — the derived count is materialized per bill as of HO 676.

## The question this HO answers

Not "how do we fix the number" — **who owns the column.** Today `/api/sync` writes it from `$.cosponsors.count` on every upsert and nothing else touches it, so it is a cache with a writer that cannot keep it correct. Any fix that leaves two writers, or leaves the sync writing a value the refresh has just corrected, re-creates the drift on a longer fuse.

## STEP 0 — enumerate; closure table; HALT

**Controls first.** Table (candidate · verdict · evidence `file:line` · destination) covering at least:

### 0.1 Every reader, and what NULL means to each

HO 675 measured six files reading `cosponsor_count`. Re-derive at HEAD and state, per reader: what it does with the value, and **what it does with NULL**. This matters because the column currently carries two meanings in one nullable INTEGER — HO 674 measured NULL as the genuine no-cosponsors case (the API omits the key entirely) on ~97%, with **109 of 3,799 NULL bills carrying a roster anyway.**

Name specifically the panel's `cosponsor_count != null` gate, which is why the COSPONSORS row reaches **five of seven routes** (`getWatchlistBills` and `getMemberBills` omit `SPONSOR_ENRICH_SELECT`). Any change to NULL semantics changes that gate's meaning.

### 0.2 The writer

Where `/api/sync` writes it, inside the `ON CONFLICT DO UPDATE SET`. **The HO 459 rule applies**: a column omitted from that clause is a permanent invariant on the sync, and the omission has to be deliberate and recorded, not discovered later by someone adding a field back.

State what happens to a **new** bill's count if sync stops writing it — HO 676's never-checked trigger is the priority band, so the gap should be ≤ one tick (~3h), but confirm it rather than reasoning it.

### 0.3 Coverage — the constraint on any roster-derived answer

`bill_roster_state.active_count` is only trustworthy where `checked_at` exists. Measure now:

- Bills with a `bill_roster_state` row and a real `checked_at`, against the corpus.
- **The sweep recycles in ~18.5 days**, so at any moment some fraction of `active_count` values are up to ~18.5 days old. State that fraction and its age distribution.
- How many bills have `checked_at` but zero roster rows — the genuine-empty class the watermark exists to represent.

A roster-derived count is only as fresh as the last check, and that is a weaker guarantee than "correct". Say so plainly in the table; the fix is *better* than today, not perfect, and the entry should claim only what it has.

### 0.4 The options, priced

At minimum these three, each with its cost, its blast radius, and what it leaves broken:

- **A — refresh also writes `cosponsor_count`; sync keeps writing it.** Two writers, no owner. Sync re-staleifies on the next upsert. Cheapest diff, and it is the option that re-creates the defect on a longer fuse. Price how often sync would overwrite a corrected value.
- **B — refresh owns it; sync stops writing it.** One writer. Requires the HO 459 omission and a ruling on NULL semantics (see 0.5). New bills carry NULL until the first check.
- **C — drop the column; readers derive from the roster.** Cleanest ownership, largest blast radius. **Price the feed cost** — HO 675 measured roster data on the row payload at **+504 rows per 50-row page render** on a `bills`-tagged entry, which is exactly why the panel reads went to the lazy fetch. If C makes the feed pay that, it is disqualified by a measurement that already exists; say so with the number rather than on instinct.

Recommend one, and say what it does **not** fix.

### 0.5 NULL semantics — rule it explicitly

If the refresh owns the column, does a genuine-zero bill get `0` or `NULL`? Today NULL means "no cosponsors" for ~97% and "we never learned" for the rest, and the panel's gate reads NULL as "hide the row".

- Writing `0` disambiguates and **changes what the gate hides** — a zero-cosponsor bill would start rendering an empty COSPONSORS row on five routes. Is that wanted?
- Keeping NULL preserves the gate and leaves the ambiguity.

Either is defensible; **an unstated choice is not.** Whichever wins, the gate's behaviour is a STEP 3 capture, not a claim.

### 0.6 The 109

109 NULL-count bills carry a roster. Under the recommended option, what do they read? They are the cleanest existing evidence that NULL is not reliably zero, and they should be a named capture case.

### 0.7 Out of scope, named

The roster tables and the refresh cron themselves; `/api/sync`'s unconditional `bills` flush (HO 671, ruled deliberate); the non-atomic summarize write pair; the `docs/design/` tracking policy; the nine `if (await X.count())` e2e guards; the two `SponsorPhoto` implementations; `HeaderBar` `IN BETA` + clock; `--font-mono` → Plex Mono; the `/welcome` tape unification; `/api/version`'s `builtAt: null`; the `lda-rollup` registry gap. All filed, none due.

**HALT.** Paste the table with a recommendation. If 0.3 shows coverage too thin to derive from, that is a finding and the HO's shape changes rather than shipping a number that is fresher-looking but not fresher.

## STEP 1 — the chore commit

`git checkout -b 677-review-local` first. One commit, one kind:

`chore(HO 677): give bills.cosponsor_count an owner`

If the ruling omits the column from sync's `ON CONFLICT DO UPDATE SET`, **the omission carries a comment naming why and pointing at this HO** — the HO 459 rule exists because an unexplained omission gets helpfully re-added.

## STEP 2 — gates

- Build ✓ then typecheck ✓, **re-run immediately before the paste**.
- `git show --stat` lists only approved files.
- **Greps classified, not counted.** `grep -c` counts lines, `git grep -c` counts files, `^---` filters drop deleted SQL comments. Three instances in three consecutive HOs; state what each number means or use `grep -o | sort | uniq -c`.

## STEP 3 — runtime and captures; HALT

Bind check first. Content assertions are necessary and not sufficient.

Captures at a named viewport set plus a separate `prefers-reduced-motion` pass, and specifically **the total-vs-groups agreement**, which is the user-visible point of the HO:

- A bill from the **+1 median** disagreement class — total and groups must now agree.
- A bill from the **tail** (max was +50) — same.
- A bill that **agreed before** and must still agree.
- A bill with **NULL count and a roster** (one of the 109).
- A bill with a **genuine zero**, showing whatever 0.5 ruled — row hidden or row empty.
- A bill **never checked** by the refresh, if any remain, showing what it reads in the meantime.
- One capture on `/watchlist` or `/members/[bioguideId]`, the two routes where the row does not render, proving this HO did not accidentally widen the gate.

Plus a **before/after count of disagreeing bills** — it must move off its measured figure, and *this* is the fraction that belongs to this HO rather than to `:80`.

**HALT.** Paste captures and readings.

## STEP 4 — docs commit (`docs: HO 677 — …`)

- **`docs/backlog.md`** — strike `:81` with its close criterion answered by the before/after count. Open anything STEP 0 surfaced.
- **`docs/roadmap.md`** — one `Also (HO 677)` block, append-only: the option chosen and the two it beat, the NULL ruling, the coverage caveat stated as a fraction and an age, and the before/after disagreement count.
- **`docs/method.md`** — **the second parked § Gates clause lands here**, verbatim as ruled at the HO 676 close: *a close criterion that names the wrong quantity does not close what it claims to; the criterion can be perfectly falsifiable and still measure something other than the capability it was written to gate*, with both citations from `:80`'s own close (leg 1's introduced-vs-ingested, leg 3's fraction belonging to `:81` rather than to roster freshness). **It rides this docs commit and nothing else rides with it.** A parked clause with no named trigger is a filed thing with no path, which is the defect this whole arc has been about — so it lands here rather than waiting for a method HO that may never be written.
- **`docs/oddities.md`** — only if something odd emerged; if nothing, say so in the block.

## STEP 5 — SKILL commit (`docs(skill): HO 677 — …`), self-mod guarded

Its own commit. Every hit classified LIVE-CLAIM vs RECORD first. Expect at minimum: the COSPONSORS row entry, which currently states that the total and the group counts disagree on 13.78% of bills and that the column is `:81`'s to close — **both halves change together**, and this arc has now had three clauses need whole-rewriting because someone corrected one half. Do not make it four.

**No changelog append** unless client-island membership changed, which it should not here.

## HALT — the review ref

`git push origin HEAD:refs/heads/677-review`. Paste: table deltas, `git show --stat`, STEP 2/3 outputs including captures, the backlog numstat with every deletion explained (a strike is an edit), and the docs + SKILL diffs.

**Deliver the SKILL diff with `--word-diff=plain`, verify it carries markers before offering it, write it to the gitignored artifacts directory, and tell Corey explicitly to attach it to the chat.** Writing the file is not delivering it.

Remote claims via `git ls-remote`. **The SKILL diff needs explicit approval.** After approval: fast-forward `main`, delete the ref, verify with `git ls-remote --heads origin`.

---

read and follow 677
