# HO 726 — `votes` and `meetings` join `/api/revalidate`'s allowlist, and the flush is proven on a local production server by reading the Data Cache's own tags manifest, not by the route's 200

The two lines this HO closes share one edit site. `docs/backlog.md:19` (*The `meetings` cache tag has no manual flush path*, HO 717): close is *"`meetings` allowlisted and a `POST` flushes `getMeetingsByCommittee` … or ruled not worth a route change."* `docs/backlog.md:106` (*The `votes` cache tag has no manual flush path*, HO 713): close is *"`votes` allowlisted and a `POST /api/revalidate?tag=votes` shown to move a surface — the honest proof is a before/after read of the band or the strip across a deliberate data change, not the 200 from the route."* Both read, if never done, the tag absent from `ALLOWED_TAGS`.

**The proof is ruled here, and it is neither the 200 nor a prod data change.** A deliberate write to prod `member_votes` or `committee_meetings` to prove a hygiene flush is a cost out of proportion to two low-priority lines, and the line offers the alternative. What can be read instead, without writing anything, is the Data Cache itself: on a self-hosted `next start` the incremental cache lives on disk under `.next/cache/fetch-cache/`, `unstable_cache` entries are files carrying their `tags`, and `expireTag` writes the tag's `revalidatedAt` into `tags-manifest.json` there. So the flush is proven by three readings on a local production build against prod Turso (read-only): the POST returns 400 before the change and 200 after; the manifest gains the tag's `revalidatedAt` on the 200; and the next request to a page that reads the tag rewrites the cache entry file (its mtime and contents move), which is the regeneration the flush exists to cause. The same `expireTag` is what every cron calls, and HO 716's interim practice already trusts `POST /api/revalidate?tag=bills` on prod as a flush, so the prod half follows from the mechanism: post-FF, the POST on prod returns `{ ok: true, tag }` for both tags where it returned 400 before. **The manifest is a premise, and STEP 0 verifies it before the change is written** (method § Handoff discipline: a prescribed method is a premise like any other).

**Two commits, kinds pure:** `fix` (two entries in `ALLOWED_TAGS`, each with its comment) · `docs(skill)` alone behind the self-mod guard (two sentences that go false) · `docs`. Read-only on the DB. No render change. The secret is referenced by env name only (`$CRON_SECRET`, method § Environment).

**The close, as filed:** POST 400 → 200 on both tags at the local server, the manifest carrying both `revalidatedAt`s, one entry per tag regenerated on the next read, and the prod POST reading 200 after the FF. **What it reads if the work never happened:** `ALLOWED_TAGS` without `votes` or `meetings`, and a 400 whose body lists ten tags.

## Ground truth (read at `1a08921`; re-derive every `:N` by content)

- `app/api/revalidate/route.ts` (51 lines): `:6-19` `authorize` (`CRON_SECRET`, `Bearer`); `:21-38` `ALLOWED_TAGS`, ten entries, each later one commented in the HO form (`// HO 437: the /lobbying surface … Flushed by the LDA cron … and by a manual backfill.`); `:40-51` `POST`, the 400 body listing the set, `expireTag(tag)`, `{ ok: true, tag }`.
- `lib/cache/expire-tag.ts` `expireTag(tag)` = `revalidateTag(tag, { expire: 0 })`, the one home for the flush contract (HO 706), immediate expiry.
- Readers tagged `votes` in `lib/queries.ts`: **20** `tags:` arrays (`:4137`, `:4388`, `:4572`, `:4681`, `:5263`, `:5710`, `:7088`, `:7233`, `:8691`, `:8706`, `:8733`, `:8773`, `:8815`, `:8842`, `:8889`, `:8939`, `:9010`, and the amendments/members/committees co-tagged ones among them), including `getAbsenceWatch` (`:5710`), the member vote stats and the participation strip. Readers tagged `meetings`: **7** (`:7601`, `:7730`, `:7782` the weekly band's hearings; `:9372` `getUpcomingMeetings`, `:9393` `getRecentMeetings`, `:9421` `getMeetingsByCommittee`, `:9439` `getMeetingsForBill`). STEP 0 recounts both.
- Flush callers today: `app/api/sync-votes/route.ts:74` `if (house || senate) expireTag("votes")`; `app/api/cron/amendments/route.ts:84`, `:107` on changed Senate materialisation / inserted links; `app/api/cron/committees/route.ts:117` `expireTag("meetings")`. Plus the one-hour TTL on every reader.
- `.claude/skills/cbt/SKILL.md:2168`: *"**`votes` is NOT in `app/api/revalidate/route.ts`'s `ALLOWED_TAGS`** (HO 713), so there is no manual flush for it: the only paths are …"*. `:1710`: *"**`meetings` is NOT in `/api/revalidate`'s `ALLOWED_TAGS`** — its flush paths are the committees cron's `expireTag` and the one-hour TTL, so an entry cached before a reader change serves the old shape (…) for up to an hour."* Both go false on the fix. `:1713` shows the allowlisted form for `lda`.
- `next.config.ts` sets no `cacheHandler`, so `next start` uses the default file-system incremental cache. **Premise, verified at STEP 0 row 5:** after one page load of a `meetings`-tagged page, `.next/cache/fetch-cache/` holds entry files whose JSON carries `"tags"` with `meetings`, and `expireTag` on an allowlisted tag writes `.next/cache/fetch-cache/tags-manifest.json` with `items.<tag>.revalidatedAt`. Read at `next@16.3.4`; if the directory or the manifest is absent the instrument is dead and the HALT names it (the fallback is the mechanism argument alone, weaker, and the block says so).
- `e2e/routes.ts` seeds: `COMMITTEE` `hlig00`, `MEMBER` `A000055`, `VOTE` `senate-119-2-207`; `/committee/hlig00` reads `getMeetingsByCommittee`, `/members/A000055` reads `votes`-tagged helpers.
- The box's `.env` carries `CRON_SECRET` (the local cron routes have been exercised before); it is exported into the shell by name (`set -a; . ./.env; set +a`) and never echoed.
- Estimates, not readings: a local production build **~2 minutes**; the manifest **< 1 KB**; the entry files **~5–50 KB** each.

## STEP 0: enumerate and measure, then HALT

| # | check | expected | if the work never happened, this reads |
|---|---|---|---|
| 1 | `git ls-remote --heads origin`; `git status --porcelain`; pointer and highest HO; machine | `main` at the HO 725 tip alone; clean; 725 / 725 → **726** | `main` still at `1a08921` means HO 725's FF is pending and this HO waits behind it |
| 2 | quote `route.ts:21-38`, `:40-51`; SKILL `:2168` and `:1710` (the two bold sentences); backlog `:19`, `:106`; `grep -c 'tags: \[' lib/queries.ts` split by tag: `votes` **20**, `meetings` **7**; the four flush callers | as in ground truth | a reader tagged `votes` or `meetings` outside `lib/queries.ts` widens the count, named |
| 3 | `npm run build` · `npm run typecheck` | 0 · 0 | not this HO's to fix |
| 4 | local production server bound by PID (`next start -p 3000`); `GET /committee/hlig00` and `GET /members/A000055` once each with the gate cookie, 200 both | 200 · 200 | a 500 here is a data or env problem, not this HO's |
| 5 | **the premise:** `ls .next/cache/fetch-cache/`; `grep -l '"meetings"' .next/cache/fetch-cache/*` and the same for `"votes"`; `cat .next/cache/fetch-cache/tags-manifest.json` | entry files present, at least one per tag; a manifest (possibly with no items yet) | **an empty or absent directory kills the instrument**: HALT with the reading and the fallback named |
| 6 | **the blind state:** `curl -sS -o - -w '\n%{http_code}\n' -X POST -H "Authorization: Bearer $CRON_SECRET" "http://localhost:3000/api/revalidate?tag=meetings"`, then `tag=votes` | **400** each, body listing ten tags | this is the pre-state |
| 7 | **the instrument's positive control on an allowlisted tag:** POST `tag=bills`, then `cat tags-manifest.json`; note the mtime of one entry file tagged `bills`; `GET /bills` once; re-read that entry's mtime and `revalidatedAt` | 200; `items.bills.revalidatedAt` present and ≥ the POST's time; the entry file rewritten after the GET | if the manifest does not move on `bills`, the instrument cannot see a flush and row 5's premise was only half true |

HALT here with the seven rows. The go arrives as a file.

## STEP 1: the fix (commit `fix(HO 726)`; one path)

`ALLOWED_TAGS` gains, in the file's comment form:

- `// HO 713 → 726: the vote surfaces (getAbsenceWatch, the member vote stats, the participation strip, getRecentVotes; 20 readers). Flushed by /api/sync-votes when a chamber inserted and by the amendments cron on changed Senate materialisation; this entry is the manual path after \`npm run sync:votes\` or a participation refresh.` then `"votes",`
- `// HO 717 → 726: the committee-meetings readers (getUpcomingMeetings, getRecentMeetings, getMeetingsByCommittee, getMeetingsForBill, the weekly band's hearings; 7 readers). Flushed by /api/cron/committees every 12 h; this entry is the manual path after a reader change or \`npm run sync:meetings\`.` then `"meetings",`

Reader counts from row 2, not from here. Then, on a local production build of this commit, the three readings per tag:

1. POST `tag=meetings` → **200** `{ ok: true, tag: "meetings" }`; `tags-manifest.json` gains `items.meetings.revalidatedAt`.
2. `GET /committee/hlig00` → the entry file(s) tagged `meetings` rewritten (mtime after the POST; contents changed at least in the cached timestamp fields); quote before/after mtimes.
3. Same for `votes` with `GET /members/A000055`.
4. Control: POST `tag=nonsense` → **400**, manifest unchanged (mtime and contents), so a 200 is the allowlist and not the route.

`app/**` is in the root `tsc` program; build and typecheck at this commit.

## STEP 2: SKILL, alone (commit `docs(skill)`; two edits, read against the tree first)

1. `:2168`: the bold sentence becomes *`votes` is in `ALLOWED_TAGS` since HO 726 (was not, HO 713)*, and the clause *so there is no manual flush for it: the only paths are …* becomes *so `POST /api/revalidate?tag=votes` is the manual flush; the automatic paths are …*, the rest unchanged.
2. `:1710`: the bold sentence becomes *`meetings` is in `ALLOWED_TAGS` since HO 726 (was not, HO 717)* and the flush-paths clause names the POST beside the cron and the TTL; the *serves the old shape … for up to an hour* clause stays, with *unless flushed* added.

## STEP 3: docs (commit `docs(HO 726)`; `docs/backlog.md`, `docs/roadmap.md`, `docs/oddities.md` if anything surprised)

- `:19` and `:106` strike, each with the close note carrying the three readings for its tag and the ruling that the deliberate-data-change proof was declined on cost, with the manifest read-back as what stands in for it.
- The roadmap gains one `Also (HO 726)` block, pointer 725 → 726: the ruling, row 5's premise reading (what the file-system cache looks like at `next@16.3.4`, which nothing in the tree records today), the seven readings, the control.
- Oddities only if something surprised: a manifest that moves without an entry regenerating, an entry keyed in a way the grep could not find, a cache directory in a location other than the one named.

## Gates

Build then typecheck, exit 0, re-run before the paste. The blind-state 400s and the fixed-state 200s on the same server shape. Manifest and entry-file readings quoted with times. The `nonsense` control. Bind evidence for the local server (PID, port). No prod write; the only prod requests are the read-only queries the pages make. Post-FF: `POST /api/revalidate?tag=meetings` and `?tag=votes` against prod with `$CRON_SECRET`, expected 200 each (they read 400 today), quoted as status and body only.

## Review ref, then FF

Review branch from the start; push the ref; the SKILL diff approved alone; `HEAD:main` no force; `git ls-remote --heads origin`; delete the ref; local `main` fast-forwarded and `git rev-parse main` pasted; `npm run verify:deploy` for the tip; the Production `e2e-prod` run as a `deployment_status` sample for the 09-17 ledger re-run; the two prod POSTs. Paste-back per method § Executing a handoff.
