# HO 712 — review reply (architect, 2026-09-11). One amendment before it lands, and it is a design correction to my own C3 ruling; the three weighs are ruled; then re-push.

Read on the ref at `5202735` against `ad63b85`: seven commits, kinds pure, 496+/121−, FF-clean. The roster floor is the right shape and the fixture falsified its own first constant (0.5 → 0.75 against an `is_current` baseline, with the reason for the baseline stated); the five derived seams each carry their disposition in a comment; the Voteview 404 path skips with one line and no write; the delete script is gone; the DOM diffs are +0 / −0 with the comparator proven to fire before the fix. The two instrument failures you surfaced (a backslash lost crossing a template literal, so `/d{3}/` matched three literal `d`s and *zero of zero* read true; a per-server `.next/cache` snapshot read as drift) are exactly the kind of thing the oddities file exists for, and both stay.

## 1. The amendment: a congress label rendered over a number derives from the number's row, never from the clock

C3 as I ruled it reintroduces the defect it removes, for a window at every rollover. The six labels now read `getCurrentCongress()` at render; the numbers under them come from `member_participation`, rebuilt by a daily job, and from `member_ideology`, rebuilt when Voteview publishes. On 2027-01-03 at 00:00Z the labels flip to *120th*; the participation aggregate for the 120th returns 0 rows until the first roll call is synced and the refresh keeps the 119th values (`rows.length === 0 → kept previous values`, `participation-refresh.ts`); the ideology rows stay 119th for the weeks until Voteview's `HS120` file exists, by the very 404-skip I ruled. In both windows a *120th* label sits over 119th numbers. That is the Absence Watch discipline — **the copy is dated, never now** — applied to congress labels, and I wrote the clock form anyway.

The fix is small and lands as fixups into commits 3 and 4:

- **`member_participation` gains `congress INTEGER`** (`ensureColumn` in `scripts/migrate.ts`, comment stating why). The refresh writes it on every row it inserts — the congress it aggregated — and takes an `opts.congress` override beside `opts.simulate`, for the fixture only. The read path (`lib/queries.ts:5134`, `:5326`) surfaces it; because the table is rebuilt atomically every row carries the same value, so the loader returns one `congress` beside the dots.
- **The participation strip, the absence card back and the band that hands the label down read that stored congress**, not `getCurrentCongress(nowMs)`. If it is NULL (a pre-migration row set) the ordinal is omitted — *MISSED* without a congress — which is honest degradation and is exercised in the fixture, never on prod.
- **The ideology strip reads `member_ideology.congress`**, which already exists `NOT NULL` on every row (`migrate.ts:627`); the loader (`:4910` / `:5010` / `:5068`) surfaces it the same way. The tooltip then says which congress Voteview actually analysed.
- **The welcome page's *119th Congress · congress.gov* line stays clock-derived.** It labels the app's current-congress scope, which the masthead already rolls the same way; it sits over no number.

**Prod sequence, before FF:** `npm run migrate` → `PRAGMA table_info(member_participation)` shows the column → run the refresh once (the cron's script path, not a hand-written UPDATE) so every row reads `congress = 119` → read back `SELECT DISTINCT congress FROM member_participation` = `119` only. Only then the DOM diff, which must still read **+0 / −0** on all four routes, since every label still resolves to *119th* from the data.

**Fixture, the rollover scenario:** an in-memory DB with 119th votes and members; `refresh({ congress: 120 })` → skipped, `DISTINCT congress` still 119, the label the strip would render still *119th*; insert one 120th vote with a full member-votes set → `refresh({ congress: 120 })` → rows written at 120, `MIN_RETAIN_RATIO` passes (~535 vs 556), label *120th*. That is the sequence January will actually run, proven now.

## 2. The three weighs

- **Aggregate 3.7× slower, no third index — accepted.** 233 ms on a daily job with a kept-previous-values failure mode, on a filter that shrinks to a handful of roll calls after rollover, does not buy a third index on a DELETE-and-rebuild table. One checklist clause: *if `[participation] refreshed … in N ms` ever approaches the client limit, the covering `(bioguide_id, position, vote_id)` index is the remedy, priced then.*
- **Commit 4 thin — accepted, and correct.** Deriving a label over a number that is not congress-scoped manufactures the C3 defect; the twelve sit on the checklist with their scope question, which is the more useful artifact. The block names the deviation as you did.
- **Six oddities — keep six.** No seventh from § 1: that finding goes into the block and into the SKILL label rule, which is where a rule lives.

## 3. SKILL (fixup into `f8c513d`)

The label rule you wrote for C3 is rewritten to the § 1 form: *a congress label rendered over a number derives from the row that produced the number (`member_participation.congress`, `member_ideology.congress`); the clock (`getCurrentCongress`) labels only what the clock scopes — the masthead, the welcome line, the sync targets.* One sentence on why: at every rollover there is a window in which the two disagree, and a clock label over job data is false for the whole of it. The migration entry gains the column.

## 4. Then

Paste: `git log --oneline ad63b85..HEAD` off the pushed ref (seven); the fixup diffs; the `PRAGMA` and `DISTINCT congress` read-backs; the refresh run's line; the fixture's two-step output; the DOM diffs +0 / −0 after the change; build and typecheck exit codes; the new `narrow-preview` run id; `git ls-remote --heads origin`. FF go follows the read of the amended tip and Corey's word.

read and follow 712-review-reply — the file, not this line
