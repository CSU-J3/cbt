# HO 689 — the week in three sentences

Code kind. The roadmap's framing section defines the 30-second answer to "WTF is going on in Congress," and its first bullet — *three sentences at the top summarizing the week, generated from the underlying data* — is the one still unbuilt. `WeeklyBand.tsx` renders the week's numbers; `lib/report-generation.ts` already assembles week data through `@google/genai`; the summarize pipeline (`lib/summarize.ts`, `gemini-2.5-flash`) owns the model conventions. This HO adds the generation, the storage, and the render: a three-sentence week summary, generated from the same materialized aggregates the band shows, displayed on the primary surface.

**Grounding rule, pinned now because it's the product's integrity:** the generator receives **only materialized numbers and named entities from our own tables** — the band's aggregates, the week's top movers/stalls by transition, enacted titles. It invents nothing. The proof gate is mechanical: **every numeral in the output must appear in the input payload** (script-checked, a gate that can fail). A summary that can't pass that check doesn't render.

**Pinned architect-side (non-fork):** generated at the weekly cadence alongside the report pipeline and stored (never generated on-request — the page render budget doesn't pay for an LLM call); the text carries its own week label so a failed generation degrades to last week's text *honestly labeled* rather than stale-passing-as-current; absent (no row ever) renders nothing; three sentences is a hard cap enforced structurally, not by hoping.

**Corey's forks, held for the HALT with real samples in hand:** placement (inside the band row, a line above it, or also on the welcome board), voice (terminal-dry vs analyst-warm — the samples decide), and cadence (weekly-only vs a mid-week "so far" refresh).

## Ground truth at authoring

- Clone at `2568378`, pointer 688, number `max(688, 688) + 1 = 689`. Re-derive at session open.
- `components/WeeklyBand.tsx` — the strip and its data plumbing; `lib/report-generation.ts:1` (GenAI), `lib/summarize.ts:12` (`gemini-2.5-flash`, the model convention), `lib/enacted-this-week.ts`. The reports cron route and the reports storage shape are **assumed present and unverified** — row 1.
- The screenshots' band ("WEEK OF AUG 31 · 0 ENACTED · 72 NEW BILLS ▲40 · 107 TRANSITIONS OBSERVED · 24 HEARINGS ▲22 · FILLER 16%") is the aggregate inventory's floor, not its ceiling.

## STEP 0 — enumerate, then HALT

| # | candidate | expected |
|---|---|---|
| 1 | the pipeline at HEAD | the reports cron route, its schedule, the reports table shape, and where week aggregates are assembled — cited, since this HO rides that pipeline rather than building a new one |
| 2 | the aggregate inventory | every materialized field available to the prompt, with real values for the last three completed weeks: the band's numbers, top movers/stalls by transitions, enacted list, filler%, hearings count, anything else cheap. This is the prompt's entire world |
| 3 | three real samples | the draft prompt run against each of the last three weeks' payloads — nine sentences total, pasted verbatim, with model, token counts, and cost per generation. Two voice variants per week if the prompt supports it cleanly. These are what Corey rules voice and placement on |
| 4 | the grounding gate, built and validated | the numeral-subset check run against the row-3 samples (expected pass) **and against one deliberately corrupted output** (expected fail) — the known-positive before anything ships |
| 5 | storage decision priced | a column on the existing reports row vs a small table: write path, read path from the band's query, cache-tag implications under the HO 671 conditional-flush regime |
| 6 | sentence-cap enforcement | how three-and-only-three is enforced structurally (parse + reject/retry vs truncate — truncation of sentence 3 mid-thought is worse than absence; propose the rule) |
| 7 | degraded states | no row · stale row · gate-failed generation — what each renders, each named before build |
| 8 | SKILL exposure | the `/` page entry and the cron contract passage — expected one-sentence touches each; self-mod guard |

**HALT. Corey rules: voice (from the samples), placement, cadence. The architect delivers a visual mock of the ruled placement alongside the HALT reply.**

## STEP 1 — build (one code commit)

Schema per row 5, generation wired into the report pipeline with the grounding gate inline (a failed gate stores nothing and logs the failure — never a silent retry loop), the band (or ruled placement) rendering the text with its week label, degraded states per row 7. `tsc` clean, build clean.

## STEP 2 — proof

1. **Backfill the last three weeks** through the shipped path (not the STEP 0 scratch) — the stored rows quoted, gate readings attached.
2. **Grounding gate live:** the corrupted-output control re-run through the shipped gate — still red.
3. **Captures** at 1440 / 2560 / 430 + reduced-motion: the band with text, the no-row state, and the stale-labeled state (manufacture by week-label offset, restore after).
4. **The render budget unchanged:** the page's query cost with the new read, measured against before — the text arrives on the existing week fetch or a named cheap one, never an LLM call in the render path.

## STEP 3 — SKILL (own commit, self-mod guard)

Row 8's touches. Diff gitignored, attach-to-chat instruction, approval before `main` moves.

## STEP 4 — docs (one commit)

Roadmap `Also (HO 689)` + pointer — including that this lands the framing section's first bullet, with a pointer back to that section. Backlog: open a WATCH for the first live cron-generated week (the same shape as HO 685's protected-daily close: quote the row when the real cadence produces one unattended). Oddities only if something surprises.

## STEP 5 — review ref, FF

Standard: `689-review`, ls-remote, architect review, SKILL slot, FF, ref deleted, `verify:deploy`, served SHA, and the ruled placement live in a final capture against prod.

## Paste-back

STEP 0 table with rows 2–4 quoted in full (the samples are the HALT's substance). After STEP 2: stored rows, gate readings, captures, the budget measurement. SKILL diff attached. After FF: ls-remote, served SHA, prod capture.
