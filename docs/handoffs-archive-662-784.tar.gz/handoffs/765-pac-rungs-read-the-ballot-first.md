# HO 765: the PAC-target rungs read the ballot first where a race has one. Printed means active, withdrawn means withdrew, and the contest decides only who the ballot never names

`docs/backlog.md` OPEN LOOPS, *`lib/pac-target-status.ts` consults primary contest evidence before a roster that is now ballot-sourced (HO 750)*, owner Code, medium. Also carried: HO 764's FF-go readings and the six seats' tags, and one chore from HO 764 (`lib/primary-identity-repair.ts:31-33` says the write touches two columns; it touches `updated_at` too).

HO 761 removed the line's worst case: a runoff loser now has a decided runoff row, so rung 1 reads them `lost`. What stays backwards is everything the ballot knows and the contest can't: a nominee who withdrew after winning (the contest says `winner`, the ballot's withdrawn block says gone), a replacement nominee with no primary row, and a first-round advancer in a race whose runoff the page never printed. Where a race has a `box` read, the ballot is the authority on who is running in November, which is the only question a PAC target's status asks.

## Ground truth (read at `b5a6f82`; re-derive every `:N` by content)

- `classifyTarget(fecCandidateName, seatContests, seatRoster, today)` (`lib/pac-target-status.ts:135-196`): rung 1 reads the target's latest resulted contest (runoff over primary), rung 1b holds `unknown` for a first-round winner whose runoff is past and unresulted, rung 2 reads the roster only when the target has no contest row. Its one caller is `lib/queries.ts:2566`. The file's *WHY THE CONTEST BEATS THE ROSTER* note (`:60-77`) was written when the roster was a copy of the contest, and HO 750's comment says the order is left alone.
- `general_ballot` (HO 749/758): `on_ballot`, `withdrawn`, `write_in`, `marked`, `name`, `person_key`, `bioguide_id`, with `general_ballot_reads.status = 'box'` where a race has a ballot. The roster that reaches this file excludes `on_ballot` rows in SQL (HO 757).
- `rosterKey` folds an FEC `LAST, FIRST` name to the roster's key (`:112-126`).
- HO 691 measured the live PAC-target set at 18 targets, 0 changed by HO 761's rounds.

## STEP 0

1. HO number from the tree: `main` at `b5a6f82`, pointer 764, so 765. Otherwise stop.
2. Re-read every cited `:N` by content. Flag a drift.
3. Measure, prod, SELECTs only: the current PAC targets with today's classification and `why`; for each, their race's `box` status and their ballot row (`on_ballot`, `withdrawn`) if any; the classification the ballot-first rule gives; the targets that change and why. Expected small, possibly zero; the legs plant the cases.
4. Carry HO 764's FF-go readings and the six seats' tags into this HO's roadmap block.
5. Proceed without a halt.

## The build

1. `classifyTarget` gains the race's ballot rows (`seatBallot`, from `general_ballot` by the race's seat, the way the caller already gathers contests and roster). Rung 0, only when the race has a `box` read: a ballot row matching the target's key with `on_ballot = 1` and `write_in = 0` reads `active` ("printed on the November ballot"); one with `withdrawn = 1` and `on_ballot = 0` reads `withdrew` ("in the ballot's withdrawn block"). No matching row falls through to today's rungs unchanged, so a lost primary or runoff still reads `lost` from the contest, and a target the ballot never names keeps today's reading.
2. After election day (`clockNowMs()`, HO 758), a `marked` row reads `active` still; what a decided race does to a PAC target is not this HO's question, and the `why` says the race is decided.
3. The *WHY THE CONTEST BEATS THE ROSTER* note is rewritten as *the ballot beats the contest, the contest beats the roster*, with HO 750's deferral paragraph retired.
4. The chore: the repair's header comment names `updated_at`.

## Legs, on a `file:` copy seeded from prod (`general_ballot`, `general_ballot_reads`, `primaries`, `primary_candidates`, `race_candidates`, `races`, the PAC-target tables the caller reads), each red first

1. Withdrawn after winning: a planted target marked `winner` in a decided primary and present in the ballot's withdrawn block reads `withdrew`. Red: `active`.
2. Replacement nominee: a target on the ballot with no contest row reads `active` from rung 0 (today rung 2 also reads `active`; the `why` changes to the ballot).
3. Runoff loser: a target unmarked in a decided runoff and absent from the ballot still reads `lost` (unchanged by this HO).
4. No box: a Louisiana target reads exactly as today.
5. The live set: every current target's classification before and after, with STEP 0's predicted changes and no others.
6. The chore: the header names the three columns.

## Commits and docs

- `fix(HO 765)`: the rung, the caller's ballot read, the note.
- `chore(HO 765)`: the repair header.
- `diag(HO 765)`: the legs driver.
- `docs(skill)`, its own commit, approval requested: the PAC-target rung order (ballot, contest, roster) and what each rung answers.
- `docs(HO 765)`: strike the line on legs 1 and 5; the roadmap block, pointer 764 → 765, carrying HO 764's readings and the six tags. Reconcile OPEN LOOPS at open and close, control at 0.
- Review ref `765-review`. The FF is held for the SKILL approval and review. No render change; no captures.

## The prod reading (in the FF go)

After the FF: the PAC-target panel's statuses on Production against STEP 0's table, every `why` naming its rung.

## Paste back

- STEP 0's table;
- the six legs;
- the SKILL diff, for approval;
- `git show --stat` per commit, `--numstat` for the docs commits, the reconcile, the `765-review` SHA from `git ls-remote`, and a last cheap-gate run.
