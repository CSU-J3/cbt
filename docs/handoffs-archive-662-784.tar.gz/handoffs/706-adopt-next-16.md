# HO 706 — adopt Next 16.3.4: the `#418` cure rides a major

Upgrade kind (`chore`), fix kind (one API, 22 sites), test kind (one instrument port), CI if STEP 0 says so, SKILL, docs. Opened by Corey's **"A"** (2026-09-09) on the HO 705 fork; owner Code. Closes the *adopt Next 16* OPEN LOOP and supplies `backlog:51`'s green after a week of dailies.

**Why a major and not a patch.** The App Router runs the React that Next vendors, not the one in `package.json`. Every Next 15.5 release through 15.5.25 ships a byte-identical hydration client (`19.2.0-canary-0bdb9206-20250818`, sha256 `9bcaacd922795590…`), and react#35494, the fix for HO 702's mechanism, was merged 2026-01-13 and never backported to 19.2. Next 16.3.4 vendors `19.3.0-canary-cbb046ab-20260731`, which carries it, and the HO 705 window read the cure on CBT's own document: `t2(15)` 2 and 6 of 36 around `t2(16)` 0 of 36 with the race intact at 35/36. So the bump is the fix, and everything else in this HO is the price of the bump.

**What is already known about the price (HO 705's throwaway build, `ignoreBuildErrors` on, never merged).** Next 16.3.4 compiles CBT clean on Turbopack in 13.9 s; `next.config.ts` accepted as-is; no root middleware exists, so no `proxy` rename. The entire type-break surface is one API: `revalidateTag(tag)` gained a required second argument. 22 errors across 15 files, every one an `app/api/**/route.ts`; zero in a rendered page or component. The build rewrites `tsconfig.json` (`jsx` → `react-jsx`, declared mandatory; `include` gains `.next/dev/types/**/*.ts`). Turbopack becomes the default bundler, and the seam instrument's `hyd-start` trap is webpack-only.

**The one semantic decision, read from the runtime rather than the docs.** `next@16.3.4` `dist/server/web/spec-extension/revalidate.js:42–53` and `:216–222`, read 2026-09-09: with no profile the call still runs, logs a deprecation warning, and takes the immediate-expiry path; with a string profile such as `"max"` it is stale-while-revalidate, so the first request after a cron sync serves stale data and revalidates behind it; with `{ expire: 0 }` the code takes the same immediate-expiry branch as today (`cacheLife?.expire === 0` is tested alongside `!profile`), and `validateAndNormalizeCacheLifeProfile` accepts `expire` alone (it only rejects `revalidate > expire`). The type is `CacheLifeConfig = { expire?: number }`. **Ruling (architect, non-fork): preserve today's semantics.** Every call becomes immediate expiry via one helper, so the profile has one home and a future move to SWR is a one-line, one-file decision that would be Corey's. Nothing in CBT uses `"use cache"`; `unstable_cache` and `cacheTag` are used throughout (162 lines) and compiled clean on the 16 build.

## Ground truth (fresh clone at `97223d0`, 2026-09-09; re-derive at STEP 0 regardless)

- Pointer 705 after HO 705 lands, highest HO in subjects 705; this is 706. If 705 has not landed when this opens, stop: this HO's docs sit on top of 705's.
- `package.json`: `next ^15.5.15`, `react` / `react-dom` `^19.2.5`, `@playwright/test ^1.61.1`; scripts `build: next build`, `start: next start -p 3000`, `typecheck: tsc --noEmit`, `verify:deploy`. `ci.yml:72` runs `npm run build`; `ci.yml:3–4` states the prerender needs no `TURSO_*`. Vercel builds with the default `next build`, so Production is Turbopack from the first deploy of this ref.
- `next.config.ts`: three permanent redirects (`/feed`, `/sponsors`, `/sponsors/:bioguideId`), nothing else — no `webpack()`, no `images`, no `experimental`.
- `revalidateTag(` appears on 30 lines in 16 files under `app/api/**` (comments included); the 22 executable sites are the 15 route files Code listed plus `app/api/revalidate/route.ts`'s dynamic `revalidateTag(tag)` and `app/api/markets/latest/route.ts`. STEP 0 counts the executable calls, not the grep.
- `scripts/diagnostic/seam-intervene-702.ts:77–87`: the `hyd-start` trap, a setter on `webpackChunk_N_E` stamping `hydStartT` on first assignment; `:186–190` the order comparator and per-hit line. `e2e/smoke.spec.ts`'s mutation channel is bundler-independent.
- `tsconfig.json`: `jsx: "preserve"`; `include` lists `next-env.d.ts`, `app/**/*.ts(x)` and more, not `e2e/**` (`backlog:14`, unchanged by this HO).
- HO 705's worktrees on Code's box: `cbt-705-n15` (15.5.15, webpack build, the live-lever control) and `cbt-705-n16` (16.3.4, throwaway edits in place). The main checkout may still carry `.env.production.local` with empty keys.

## STEP 0 — enumerate, then HALT on rows 4 and 9 only

| # | check | expected |
|---|---|---|
| 1 | engines: Next 16's Node floor (`package.json` `engines` inside the 16.3.4 tarball), the Vercel project's Node setting, `actions/setup-node` versions in `ci.yml` and `e2e-prod.yml`, TypeScript floor | all satisfied, or the exact bump named per file (a `ci(HO 706)` commit if the runners move) |
| 2 | packages pinned to the Next major: `eslint-config-next`, `@next/*`, anything else in `package.json` naming 15 | list; each moves in the same `chore` commit |
| 3 | on a clean install of 16.3.4 in a fresh worktree, `npx tsc --noEmit` **without** `ignoreBuildErrors`: the full error list | exactly the `revalidateTag` sites and nothing else; any other error is a flag, quoted |
| 4 | **the profile decision verified at the runtime**: re-read `revalidate.js:42–53` and `:216–222` and `cache-life-profile.js`'s validator in `node_modules/next` of the fresh install; confirm `{ expire: 0 }` reaches the immediate-expiry branch and validates | as read above; **if the runtime disagrees with the reading, HALT** — the semantics are then a Corey question, not a Code default |
| 5 | Turbopack build output: warnings, the `next build` route table, and whether any route changed from static to dynamic or back against the 15 build's table | identical route table; every warning quoted |
| 6 | `next/image`: every usage, `remotePatterns` (none configured), `unoptimized`, `quality` props; Next 16's `images.qualities` and local-IP defaults | no remote images through the optimizer, or the config change named |
| 7 | the Turbopack chunk-registration hook: grep the 16 build's served chunks (`.next/static/chunks`, and the document's request list at `/members`) for how chunks register (`TURBOPACK` push, or whatever the runtime actually uses) — the thing the trap will hook | the global and the call shape, quoted from a chunk |
| 8 | SKILL exposure: every mention of "15" as a Next version (`grep -n 'Next.js 15\|Next 15\|next 15'`), the `#418` bullet, the *Deploy verification* and *Environment* text naming the bundler, the frontmatter description | the list, with line numbers; this is the `docs(skill)` scope |
| 9 | **Corey's word on shipping Turbopack**: the ruling below is to ship the default bundler with the trap ported; the fallback is `next build --webpack` if row 7's port cannot be made to read within the HO | **HALT only if the fallback is needed**; otherwise proceed |

## STEP 1 — the upgrade (commit 1, `chore(HO 706)`)

Fresh worktree from `main`. `npm install next@16.3.4` plus row 2's packages, `package.json` and lockfile; accept the `tsconfig.json` rewrite the build performs and commit it as it lands; regenerate `next-env.d.ts`. No `ignoreBuildErrors`, ever. Build with the default bundler. If the main checkout still has `.env.production.local` with empty keys, delete it and say so in the block (HO 705 oddity 3).

## STEP 2 — the one API (commit 2, `fix(HO 706)`)

`lib/cache/expire-tag.ts`: `export function expireTag(tag: string) { revalidateTag(tag, { expire: 0 }) }`, with a header stating the decision and its source lines (`revalidate.js:42–53`, `:216–222`), that `"max"` would be stale-while-revalidate, and that changing this file changes every cron's freshness contract at once. Every executable `revalidateTag(` site imports and calls `expireTag`; `app/api/revalidate/route.ts`'s dynamic tag goes through it too. Comments that say `revalidateTag("x") flushes …` are left accurate by the rename or corrected. **Behavioural check, not just types:** on the local 16 build, call one cron-adjacent route locally (the `/api/revalidate` route with its secret is the cheapest) and confirm the server log carries **no** `revalidateTag without the second argument` deprecation line; run one call through a temporarily one-argument variant to see the warning appear, then remove the variant. Both log lines quoted. `typecheck` 0 after this commit.

## STEP 3 — the instrument port (commit 3, `test(HO 706)`)

`seam-intervene-702.ts` learns Turbopack: the `hyd-start` trap hooks row 7's registration global with the same first-assignment semantics, keeps the `webpackChunk_N_E` hook so the n15 worktree still reads, and the per-hit line names which hook fired (`hyd-src=webpack|turbopack`). Header updated: what its zero means now includes the bundler it was read on. Falsification before the window: run the ported script against the 16 build with the Turbopack hook deliberately misnamed; every hit must read `hyd-start=n/a`; corrected, `HYD-BEFORE-TAIL` must be high on `t2`. Both readings quoted.

## STEP 4 — the window and the render gates

- **The window**, one sitting, interleaved, 36 hits per leg, ported instrument: `control(16)` · `t2(16)` · `t2(15)` (the n15 worktree, webpack, the live-lever control) · `t2(16)` again. Pre-stated: `t2(16)` 0 and 0 with `HYD-BEFORE-TAIL` high both times, `t2(15)` ≥ 1 with the race intact, `TIMEOUTS=0`. A `t2(16)` fire is a HALT with the per-hit line: it would mean a shape #35494 does not cover, and HO 705's report path reopens.
- **Render gates, because a bundler change is render-touching** (SKILL, HO 670 rule): captures at 1440 / 2560 / reduced-motion on the 16 build against the same routes on the 15 build, pixel-diffed; any diff named and explained or fixed under HO 694's rule. Local `smoke.spec.ts` (36 routes, console clean — a Next 16 client-side deprecation warning would fail it and must be read, not silenced), `odds-off.spec.ts`, `narrow.spec.ts` at both widths, `fit-finish.spec.ts`. All are the local prediction, named as one.
- **The first CI reading before FF is HO 703's job**: the ref's Preview deployment runs `narrow-preview` on Vercel's build of this tree with Turbopack; quote its id, the version pre-step's served SHA, and the 72 lines.

## STEP 5 — SKILL (alone), docs, CI

SKILL per row 8: Next 16.3.4 everywhere the stack is stated; the bundler is Turbopack and `--webpack` exists as a fallback; the `#418` bullet gains the cure landed (versions, the window, the ported trap) and the `expireTag` rule (*immediate expiry is the freshness contract; one home in `lib/cache/expire-tag.ts`; SWR is a Corey decision*); *Deploy verification* gains that the seam instrument reads both bundlers. Provenance after each. Method § Environment gains one line on the bundler and the two worktrees. Docs: roadmap block with rows 1–9, the error list from row 3, the window, the captures verdict, the Preview run, the local gate lines; the adoption loop annotated *landed, week running from <date>*; `backlog:51` annotated the same; (C) untouched. Pointer to 706. Oddities only if something new turns up; the two known traps are already filed.

## Gates

`typecheck` 0 · `build` 0 (Turbopack) · `check:odds-sites` 0 · `check:design-citations` OK · local smoke / odds-off / narrow ×2 / fit-finish green · captures diffed · the window as pre-stated · the deprecation-warning pair from STEP 2 · `npx playwright test --list` on any edited spec (`tsc` does not read `e2e/**`).

## Review ref, FF, and the week

`706-review`: its Preview run is the first CI reading. Architect read, SKILL slot, FF (from a file, never a line), ref deleted, `verify:deploy` five reads with the served chunk carrying the 19.3 canary string, the Production run's smoke / odds-off / narrow lines quoted. Then seven dailies with the mutation channel at zero strike the adoption loop and close `backlog:51`; a single `#418` in that week reopens HO 705's report path with the per-hit line attached.

read and follow 706
