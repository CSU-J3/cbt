# HO 779: FF go. Both rulings stand, 51 PASS and 0 FAIL. A Production reading first, then the FF, the deploy, a `races` flush and the tags read again

## Rulings on the paste

I read `779-review` at `bae5790`, all six commits:
- `c4d116b`: the card keeps the tag (`qualifier={incumbentTag ? null : result.qualifier}`). The outcome is read from the target race's marked printed rows on its `box` read, `incumbentTagAt` drops it before election day and sets `ran` after, the four merge points apply it on the server, and the holder line reads `holderWords`;
- `9504470`: `data/governor-runs-2026.json` holds the five, each sourced, and the governor kind sits after `moved` and `senate` and before the reasons;
- `e2fcd49` and `b2543a4`: the legs. Two `diag` commits is fine: the kinds stay unmixed, and the block counts six;
- `f26bdd9`: the rulings and Louisiana lines struck, and the WATCH's (c) unblocked. The reconcile reads 264/347 here too, control 0.

**The legs stand** on r3. r1's hover miss and r2's two unread merge points were the instrument's faults, and r3 fixed both.

**SKILL is approved** (`bae5790`): the four places and the fifth, the kinds' lead-in, are true of the tree.

**`/welcome`'s merge point reads `clockNowMs()`,** not the page's `Date.now()`. That's right: the tag's gate is the race page's clock.

**The audit's `TURSO_DATABASE_URL` hit needs nothing.** It's the database's hostname, which SKILL (`:2621`), the backlog and the roadmap carry on purpose, and it's no credential.

## Before the FF, on Production

Read, and keep for the comparison after the flush:
- the cards on `/race/S-AL-2026`, `/race/AZ-05-2026`, `/race/WI-07-2026`, `/race/MI-10-2026` and `/race/FL-19-2026`;
- `/electoral`'s 27 tags, each `data-incumbent-tag` with its text.

## FF

`779-review`'s head sits on `main` at `0d53dae`: a fast-forward of 6 commits. No migration.

Re-run the build and the cheap gates immediately before the push, and name the reading. Then:
- `git push origin <779-review's head>:main`, no force;
- `git ls-remote --heads origin`;
- delete `779-review`, remote and local;
- forward local `main`;
- paste `git rev-parse main`.

If the classifier blocks the push, Corey runs the same command from your checkout.

## The deploy

Run `npm run verify:deploy` **in the foreground**, then read the Production build's cache line.

**`e2e-prod`:** if Vercel's Production record fires `smoke` within a few minutes of READY, read that run. If not, dispatch on `main` and read it. Either way, give both records' times against READY, the Preview's and Production's: that's the Vercel line's Close.

**The flush:** `POST /api/revalidate?tag=races`, Bearer `$CRON_SECRET` read from `.env` by name, as HO 773's go did. `getIncumbentQualifiers` carries the tag, and its cached value predates the governor kind.

**The tags on Production, after the flush:**
- the five cards read RUNNING FOR GOVERNOR;
- `/electoral`'s 27 tags equal the reading before the FF, except MI-10's, now RUNNING FOR GOVERNOR;
- no `data-incumbent-outcome` on `/electoral`, `/`, `/welcome` or the 18 `senate` and `moved` pages, and AL-01 still reads RUNNING FOR SENATE.

A mismatch is a finding, not a HALT: read it and name it.

Paste once, after `e2e-prod` and the tags read. The next HO's roadmap block opens with this go as taken. If both of Vercel's records came within a couple of minutes, its docs strike the Vercel line with them.
