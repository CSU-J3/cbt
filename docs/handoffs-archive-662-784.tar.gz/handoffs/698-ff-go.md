# HO 698 — approved · FF go, after one backlog line

Read on the ref at `4fa3055`: `f9b9d40` test · `0b70a6c` fix · `4fa3055` docs, a clean FF from `c837f4e`, every blob LF, kinds pure. The §1 hypothesis is falsified on the reading that could falsify it (face applied at the failing width, no change after `fonts.ready`), the revert branch never fires, and `999c304` is cleared on evidence rather than by argument. The fix is approved as built: the row stops depending on advance widths at all, and the fatter-face control moving the edge by zero is exactly the kind of gate this repo asks for. The clip-ancestor labelling is what turned the old dump from a list of suspects into a diagnosis; keep it.

Two deviations accepted as named: the §4 clause belongs in `docs/method.md:423` because that is where the sentence it amends lives, and the mono entry is `:138`. Method riding in the docs commit is a departure from the 695/696 precedent, not from a rule; noted, not reworked.

## 1. One line before the FF

The @390 finding is filed nowhere. *A phone narrower than the one width anybody measured was broken on every host, and no gate could see it* is a second reach gap in the same HO, and it is a finding caught in relay. One OPEN LOOP, owner Code: **the narrow gate reads one width**; candidate close, a second width (390) on the same spec with its zero stated, or a reasoned reason not to. Fixup into `4fa3055`, force-with-lease, `git ls-remote`.

## 2. Execute

1. Re-verify immediately before the push: `main = c837f4e`, ref tip as re-pushed. Drift is a HALT.
2. `git push origin HEAD:main`, no force. Confirm. Delete `698-review` and `698-narrow-diag`; the dispatch run keeps its own record and the block carries its id.
3. `verify:deploy` on five consecutive reads.
4. **The gate that reads:** the Production `e2e-prod` run the push triggers, quoted — `narrow /welcome @430` line with `scroll=…/430 over=0` and the `fonts=` field the new dump adds, plus the run's totals.
5. Captures of `/welcome` at **430 and 390** on prod for Corey: the CTA is one column below 560 on a page he ruled, and he sees the arrangement before he is asked anything about it.

## 3. Paste-back

`ls-remote` showing `main` moved and both refs gone; the served SHA; the Production `e2e-prod` id, conclusion and the two quoted lines; the two captures.

read and follow 698 — FF go
