# HO 774: housekeeping. No client bundle carries `lib/queries.ts`, the title repair's two leftovers go, the ratings WATCH closes as read, and AL-01's flip is read. With HO 773's FF readings

**Corey's ruling, 2026-10-11 about 1:30 PM MT:** asked what Code should do while the ratings wait on Cook and the raters, he picked *Housekeeping now* over *Alabama's voided primaries* and *Wait for Cook*.

**Scope, in:**
1. *A client component imports a value from `lib/queries.ts`, so a `node:` import anywhere in that module's import graph fails `next build` on `/search` (HO 773).*
2. *Two leftovers in the title repair, comment and type only … (HO 773's FF go).*
3. **The ratings WATCH,** closed as read (the ruling below).
4. **AL-01's flip,** read once the reader cron has re-read S-AL. That closes Moore's line.
5. **HO 773's FF go,** into this block.

**Out:** every other OPEN LOOPS line, Alabama's voided primaries among them.

**How STEP 0 runs** (method.md, HO 768's rule): the table is mine and is a check. Go on through the build, the legs, docs and the review push unless a claim fails or a reading falls outside its bound.

**Base:** `main` at `042f891`. HO number: the pointer is 773 and the highest HO in commit subjects is 773, so this is 774.

## The ratings WATCH: closed as read

The WATCH's dated run, #24166, came back refused: Cloudflare's managed challenge answered Production's one fetch of Sabato's page from pdx1, both chamber legs failed on it, and nothing was written. That answers what the WATCH was watching. The refusal that's still open belongs to Sabato's line, and Cook's and IE's rows keep their own lines. Two live lines for one blocker would double-count it, so the WATCH closes on this reading.

## STEP 0

| # | Claim at `042f891` | Fails if |
|---|---|---|
| 1 | `components/SearchTabs.tsx:4` (`"use client"`) imports the value `SEARCH_TABS` and `type SearchTab` from `@/lib/queries`. Both are defined at `lib/queries.ts:8641-8642`. Their other users are `lib/queries.ts:8643-8655` (`SEARCH_TABS_SET`, `sanitizeSearchTab`) and `app/search/page.tsx:10-11`, a server page. | another user |
| 2 | 29 `"use client"` modules import from `lib/queries.ts`. Besides `SearchTabs`, each imports only types:<br>• 27 with `import type`, `components/MemberHeader.tsx:7-11` among them;<br>• `components/SortDropdown.tsx:5`, with `import { type SortKey }`, an inline type-only import. `SortKey` is `lib/queries.ts:205`.<br>Followed through value imports, no client module reaches `lib/queries.ts` another way. | a client module imports a value, or reaches it another way |
| 3 | `lib/ballotpedia-key.ts:5-6` says the qualifier reaches client bundles through `lib/queries.ts`, by way of `SearchTabs`' `SEARCH_TABS`. | |
| 4 | `scripts/repair-ballotpedia-titles.ts:16-18` says the primary class's race holds *one keyed, untied row that passes the name check*.<br>`lib/ballotpedia-title-repair.ts:258`: `Verdict` still includes `"not attempted"`, which no path returns since `9045f48`. Its one other mention is leg F's red (`scripts/diagnostic/electoral-cleanup-773.ts:771`), which reads `99026df`'s module through its own `verdict: string` (`:732`), so it stands as it is. | another mention |
| 5 | SKILL `:2341`, *Most client islands exist only to push/replace URL state; **`WatchlistToggle` is the lone POST.***, occurs once. | |

**AL-01's reading**, once the reader cron's 2026-10-12 02:20Z tick has run:
- S-AL-2026's `general_ballot_reads.last_attempt_at`, and the `bioguide_id` on S-AL's row `Barry_Moore_(Alabama_U.S._representative)`;
- leg D of `scripts/diagnostic/electoral-cleanup-773.ts`, re-run;
- the tag on `/race/AL-01-2026` on Production (`components/RaceIncumbentCard.tsx:138`).
- Expected: the row ties to `M001212`, leg D reads 4 of 4, and the tag reads RUNNING FOR SENATE.

If you're ahead of that tick, it's read at the FF go.

## The build

### § 1, no client bundle carries `lib/queries.ts` (`fix`)

- **New `lib/search-tabs.ts`,** which imports nothing. It holds `SEARCH_TABS` and `SearchTab`, moved verbatim from `lib/queries.ts:8641-8642`, under a header saying why: a value import from `lib/queries.ts` bundles that module's whole graph for the browser.
- **`lib/queries.ts`** imports both from it and re-exports them, so `app/search/page.tsx` and every other server importer is unchanged.
- **`components/SearchTabs.tsx`** imports them from `@/lib/search-tabs`.
- **`components/SortDropdown.tsx:5`** becomes `import type { SortKey } from "@/lib/queries";`. `import type` is erased under any compiler setting, while an inline `type` import could survive as a side-effect import if the compiler's settings change.
- **`lib/ballotpedia-key.ts`'s header** moves to the past tense where it speaks of `SearchTabs`: *the qualifier reached client bundles through lib/queries.ts (components/SearchTabs.tsx imported SEARCH_TABS from it until HO 774)*. Rewrap it to its width.

### § 2, the title repair's leftovers (`chore`)

- In `scripts/repair-ballotpedia-titles.ts:17-18`, *own race's primaries hold one keyed, untied row that passes the name check (GA-13's Blair), learning that row's person_key.* becomes *own race's keyed, untied primary rows that pass the name check give one distinct key (GA-13's Blair), learning that key.* That's the rule as `lib/ballotpedia-title-repair.ts:52-57` states it. Rewrap it to the header's width.
- At `lib/ballotpedia-title-repair.ts:258`, `Verdict` drops `"not attempted"`.

## Legs

**A, the build trap.** Use a scratch worktree, and plant at the top of `lib/queries.ts` a `node:fs` import that's used, for example `import { existsSync } from "node:fs"; void existsSync;`. The plant is never committed.
- **The red:** `042f891` with the plant fails `next build` on `/search` with the error HO 773's Preview logged, *the chunking context (unknown) does not support external modules (request: node:fs)*.
- **The green:** § 1 with the plant builds.
- **The control:** § 1 without the plant builds. That's the ordinary gate.
- **If the green fails,** its error names the next client path into `lib/queries.ts`. Fix that path the same way (a leaf module, or `import type`), re-run, and list each one.
- **If the red builds,** the plant isn't reaching the bundle, and the green would prove nothing. Plant HO 773's own shape instead: `lib/incumbent-qualifier.ts:59` importing `titleKey` from `./primary-candidates-scrape`, which re-exports it, in place of `./ballotpedia-key`.

Cold builds (`rm -rf .next`), Node as the gates run it. Keep the three logs.

## Docs

**roadmap:** the HO 774 block. It opens with **HO 773's FF go as taken** (your paste):
- the ratings read;
- fix 1 and leg F;
- W2b and W4b;
- the queue reading;
- the builds and the pushes;
- the deploy;
- the flush;
- the three cards.

Then Corey's ruling, the WATCH's ruling, STEP 0, AL-01's reading, the build and leg A.

**backlog:**
- **The ratings WATCH (HO 768, rewritten HO 770),** struck, its close note verbatim:

  ```text
  · **CLOSED at HO 774, as read (the architect's ruling):** its dated run, #24166 (2026-10-11 11:00:44Z), came back refused. Cloudflare's managed challenge answered Production's one fetch of Sabato's page from pdx1 (403, `cf-ray a48d5ce13a68ccd1-PDX`), both chamber legs failed on it, and nothing was written. That answers what this line watched. Sabato's own line holds the open refusal, and Cook's and Inside Elections' rows keep their own lines.
  ```

- **The `lib/queries.ts` client trap,** struck on leg A.
- **The title repair's two leftovers,** struck on § 2.
- **Moore's line,** struck on AL-01's reading if you took it, with the reading. If not, it stays for the FF go.
- Reconcile, with the control at 0.

**SKILL**, in its own `docs(skill)` commit, last. After *Most client islands exist only to push/replace URL state; **`WatchlistToggle` is the lone POST.*** (`:2341`), add a new line, verbatim:

```text
  - **A client island imports only types from `lib/queries.ts` (HO 774).** A value import bundles the module's whole import graph for the browser, so one `node:` import anywhere in it fails `next build` on that island's route, as `node:fs` did on `/search` at HO 773 through `SearchTabs`' `SEARCH_TABS`. A constant a client needs lives in a leaf module that imports nothing, as `SEARCH_TABS` does in `lib/search-tabs.ts`, and a type import is spelled `import type`, which every compiler setting erases, never `import { type X }`.
```

## Commits

On `774-review` from `main`, kinds unmixed:
- `fix` § 1;
- `chore` § 2;
- `docs`;
- `docs(skill)`, alone and last.

No migration, and no prod write. Build, then the cheap gates, before every push.

## Paste back once, after the Preview and `narrow-preview`

- `ls-remote` with `774-review`'s SHA;
- STEP 0, and AL-01's reading if taken;
- leg A's three builds;
- the Preview, and `narrow-preview`;
- `--stat` per commit, and `--numstat` for docs with every deletion explained;
- the SKILL diff;
- the reconcile;
- a last cheap-gate run.

Build through to the review push without stopping.
