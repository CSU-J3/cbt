# HO 767: FF go. The seven read, both SKILL commits approved, FF to `8752512`, then the prod reading

## Rulings on the paste-back

The seven commits read right on the ref at `8752512`.
- `bdeb313` renders the margin cell on House rows only and the head on the House tab only, and the Senate grid drops the 132px track from 900px up. The open row's narrow 2024 tile was already House-only, so nothing there needed to change. Leg 1's column check has the House tab as its control, and leg 7 reads the seven Senate rows at 64px.
- `1c8f93d`, `4ef16b8` and `2994109` do what the reply asked, each check with its control.
- `49de53c` reads right: lines 67 and 68, the Tooltip line's scroll half, (xi) at 1, (iv⁗) at 11, and the block. I ran the reconcile on the ref and it reads as pasted: OPEN LOOPS 68 live / 98 struck, the file 269 / 327 (596), control 0.

**SKILL `3ff0211` and `8752512`: approved, together.** Nothing below moves either sha.

**`d35e038` is accepted.** It went beyond the list, and it came the right way: its own `diag` commit, flagged, and re-run rather than absorbed. The guard false-failed on prod's own general-ballot cron (#23538), in flight 61s before the window opened. Counting a run still in flight at `t0` is the fix. `ended_at` is a real `cron_runs` column, and the hour bound keeps a dead row that never closed from explaining anything.

**The day-after gate at 00:00Z Nov 4 stays as HO 758 set it.** That's 7 PM EST and 5 PM MST on election night, which is when the Result state is worth having: marks arrive as the ballot cron reads them, uncalled seats keep their odds, and *NO CALL* is true of a seat still voting. The method files findings rather than leaving them in a block, so it goes into oddities with the next HO's docs, beside this FF's readings. The entry says the election clock counts UTC days: the band's countdown and HO 758's gate both turn at 00:00Z, which is 6 PM MDT now and 5 PM MST after Nov 1, so the pages turn to results at 5 PM MST on Nov 3.

## FF

`767-review` is at `8752512` and `main` at `468e692`, so this is a fast-forward of 17 commits. No migration.

Re-run the cheap gates immediately before the push and name the reading. Then:

`git push origin 8752512fff27aa1ee55bfa94438769b9f10d1540:main`, no force · `git ls-remote --heads origin` · delete `767-review` · forward local `main` and paste `git rev-parse main`.

If the classifier blocks the push, Corey runs the same command from your checkout.

Wait for Production to serve `8752512` (`npm run verify:deploy`), then paste the Production `e2e-prod` read and smoke.

## The prod reading

Page reads only, on Production, at 1440 and 430 with `reducedMotion: "reduce"`, each captured:
- `/electoral` opens on LIST, on the Senate tab, with no 2024 column. The House tab has it.
- The calendar's one folded line, with NEXT. Opened: the bars to Nov 15 and the dated list.
- The band. At 1440, the axis with its six featured dots and the ELECTION DAY line after the legend; at 430, the ELECTION DAY line alone. Then the two KALSHI cells.
- NH SEN open: one chip, Shaheen's, on SEAT HELD BY. GA SEN open: Ossoff's chip opens the card with *View tracker ↗* and no title inside it.
- From `/`, the nav's *Electoral* and the races panel's *ALL →* both land on `/electoral`'s LIST.
- MAP is one toggle away, unchanged.

If anything reads off, stop and report before anything else.

## Paste back

- the cheap gates before the push;
- the FF mechanics (`rev-parse`, `ls-remote`, the ref deleted);
- `verify:deploy`;
- the Production `e2e-prod` read and smoke;
- the prod reading with its captures;
- the reconcile on `main` (269 / 327, control 0).

The FF's readings go into the next HO's block, as HO 766's went into 767's, with the oddities entry above.
