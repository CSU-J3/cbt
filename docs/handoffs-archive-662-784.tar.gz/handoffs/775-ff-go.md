# HO 775: FF go. The ref read clean, SKILL `e780d1a` approved with your correction. The stale rating-label line is replaced first, then FF, the deploy, and leg A on Production

## Rulings on the paste

I read `775-review` at `e780d1a`, all four commits:
- § 1: the constant, the chip's anchor and its title rule, `RaterLink` and the tiles, `.rater-link`;
- § 2: leg A's script, with the AZ-01 control and the abort on a rater's host;
- the block and the reading.

**SKILL `e780d1a`: approved.** I rebuilt it from `ca11c35` with my paragraph and your one correction, and it's byte-identical. The correction is right. The reading found 101 seed rows citing the rater's own page, so my premise that every row written before HO 770 cites Ballotpedia was wrong. The decision and the title rule stand without it, as you wrote.

**Your additions stand:** the AZ-01 control, the look reading, and the abort on a rater's host.

**For your eye:**
1. **The clause:** approved, above.
2. **The stale rating-label line is replaced before the FF,** in its own `docs(skill)` commit (below). Your draft folds a new rater into a line about a new label, and a rater's new word also needs its reader's map, so my text names each step.
3. **The MOVED line stays as it is.** It's a change notice inside the row's toggle, and the row opens onto the linked tiles, so the attribution is one click away. Nothing is filed.

## Before the FF, on `775-review`

Build, then the cheap gates, before the push.

**1. `docs(HO 775)`, only if it's after 2026-10-12 02:22Z when you run this.** Take AL-01's reading, HO 774's three reads. Strike Moore's line with the reading, and reconcile with the control at 0. If it's earlier, skip this commit, and the reading carries to the next HO.

**2. `docs(skill)`, alone and last.** At `:2589`, verbatim:

```text
OLD: **Adding a new rater label** is a three-file change: extend `RATING_SCORES` in `scripts/seed-race-ratings.ts` (the integer score), extend `colorFor` + `borderColorFor` in `components/RatingChip.tsx`, and extend `ratingColor` in `components/MemberHeader.tsx`. If any of the three is missed, the chip falls through to a muted gray.
NEW: **Adding a new rating label:** a rater's new word goes in its reader's map (`SABATO_LABEL`, `lib/race-ratings-scrape.ts:382`, for Sabato), and a new normalized label takes a score in `RATING_SCORE` (`:164`), which every upsert needs, and in the seed's `RATING_SCORES` (`scripts/seed-race-ratings.ts:19`), which it mirrors. Its color takes nothing when it ends in ` D` or ` R` or reads `Toss Up`, since `ratingColor` and `ratingBorderColor` (`lib/race-colors.ts:37,47`) key on that, and any other label falls through to a muted gray. A new *rater* also needs its pages in `RACE_RATING_PAGES_2026` (`lib/enums.ts`), or its name renders as plain text. (Corrected at HO 775: since HO 222 the colors live in `lib/race-colors.ts`, not in `RatingChip` or `MemberHeader`.)
```

Push, with no force. If the commit is exactly this replacement, it's approved as landed. Paste the diff.

## FF

`775-review`'s new head sits on `main` at `ca11c35`, so this is a fast-forward of 5 commits, or 6 with AL-01's. No migration.

Re-run the build and the cheap gates immediately before the push, and name the reading. Then:
- `git push origin <775-review's head>:main`, no force;
- `git ls-remote --heads origin`;
- delete `775-review`, remote and local;
- forward local `main`;
- paste `git rev-parse main`.

If the classifier blocks the push, Corey runs the same command from your checkout.

## The deploy

Run `npm run verify:deploy` **in the foreground**, then read:
- the Production build's cache line;
- the Production `e2e-prod` and its smoke;
- **leg A on Production:** `scripts/diagnostic/rater-links-775.ts` with its two races and the control. Expected: 89 of 89 and 18 of 18, and no request to a rater's host.

No flush: this HO changes no data.

Paste once, after leg A. The next HO's roadmap block opens with this go as taken.
