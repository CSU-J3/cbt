# HO 770: S1 ruling. A table directly under a dated table takes its date; build through to the review push

## HO 769

I read `769-review` at `bf383f2`, all four commits:
- the matcher does what § 2 asked;
- leg C carries the red you added;
- the block, both backlog rewrites, the two oddity paragraphs and the method.md bullet read clean.

Nothing to change. The FF go covers it with 770.

## Table 39

**Your rule, adopted:** a table takes the date of the table above it, in the same section, when only whitespace separates the two. Any other table without its own date line still throws.

Two things make this the right reading:
- It's how the page is laid out. Table 39 sits under Sept 10's date line, with nothing between it and Sept 10's table. The date line governs the block.
- It's narrow. A table with any text between it and the table above (a paragraph, a heading) doesn't inherit, so a missing date anywhere else still fails loud.

The alternative is an `error` on every run until Sabato edits the page. That costs every week's ratings to protect two rows the store already holds.

Under the rule:
- table 39 takes Sept. 10;
- the House reads 136 rows, and conflicts drop to 0;
- AL-02 and TX-34 read current, so nothing is written for them.

## What changes

- **§ 1, `parseSabatoChanges`.** The date rule becomes the one above. Put a comment beside it naming table 39 (AL-02, TX-34) and the Sept. 10 table it sits under.
- **Leg A** gains three cases:
  - the served page: table 39 takes Sept. 10. This is the control;
  - a paragraph inserted between tables 38 and 39 makes it throw. This is the rule's edge;
  - the first table of a section with its date line removed throws, because there's no table above it to inherit from.
- **S2 in the paste,** whole and under this rule: all six classes, by chamber. The table in your HALT paste lost its first rows in transit.
- **SKILL edit 2,** the Sabato bullet. After *(governors are skipped).* insert, verbatim:

  ```text
   A table with nothing but whitespace between it and the table above takes that table's date (one does: two House rows directly under Sept. 10's), and any other table without its own date line throws.
  ```

- **The roadmap block** names table 39 and this ruling in the census. No oddity: it's one table, read by a rule.
- **The masked copy** stays the fixture. The masking touched three SVG number runs and nothing inside a table.

Everything else in HO 770 and its STEP 0 ruling stands. **Build through to the review push without stopping, then send the one paste for both HOs.**
