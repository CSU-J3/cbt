# HO 697 — ruling on the §6 failure (architect, 2026-09-06). The reply's attribution is retracted; run the arms that were never run.

The §6 leg did what a gate is for. It was added so the shipped tree would be measured rather than assumed clean by subtraction, it read 1 · 1 · 1 · 1, and it caught an attribution the architect had made **by subtraction**. Owning it plainly: the review reply cleared the tag on arms C, B and D, and none of them varied the tag against a tag-free control — C never carried it, B and D always did. That is the same defect the reply was correcting in the paste before it (a missing arm), and it is the second wrong attribution in this HO from this side. Nothing in the block, SKILL or the ledger is written until the arms below read, and that decision was the right one.

Your rebuild catch is also right: `git checkout <sha> -- <path>` stages, so the "split" was not one; `b1039e3` / `29bd1a6` reverting alone is the property §3 wanted, and E being tag + fix rather than tag alone is stated correctly.

## 1. What is established now

By tag: **16 fires in 13 crawls with it, 0 in 6 without.** By clock: 11 in 9 with, 7 in 13 without, so the clock is no longer the variable that separates firing from clean trees. The font: 0 in 3 alone, and every firing tree carries the tag rather than the font. E's fires sit on `races`, `electoral`, `trades`, routes with no clock and no `WelcomeClock`, so the fix cannot reach them. **The tag, or something that travels with it, raises the local #418 rate.** What travels with it is one static `<span>` in each masthead and one CSS rule with an infinite 2.4s opacity animation on every route from first paint. Those two things have never been separated, and a static span has no hydration content to mismatch; the arms below separate them.

## 2. The arms, interleaved, with the wall clock on every crawl

One confound the first matrix did not control: **the hour.** The `:50` class localises to the markets tape and the races chips, both time-dependent, and this is a Sunday; A and C ran at one hour, E and SHIP at another. So A runs again, **interleaved** with the new arms, and every crawl records its start time. If A fires now, the variable is the clock on the wall and everything above is re-read.

| arm | tree | what it separates | crawls |
|---|---|---|---|
| A′ | `main`, run now, interleaved | the hour | 3 |
| T | tag markup + `.beta-tag` as shipped (animation on); no fix, no clock, no font | tag as built | 3 |
| T0 | T with `animation: none` on `.beta-tag`, nothing else changed | markup from motion | 3 |
| F | `29bd1a6` alone (the `WelcomeClock` shape fix) | the fix, as a control | 3 |
| T3 | **only if T fires and T0 does not:** T with `animation-delay: 3s` on `.beta-tag` | whether motion after hydration is enough | 3 |

Order: A′ · T · T0 · F · A′ · T · T0 · F · A′ · T · T0 · F, then T3 × 3 if earned. Same build procedure and controls as before (tag present in served HTML, `animation-name` computed on a masthead tag: `betafade` / `none` / `betafade` with the delay).

**Decision rule that can fail, with its power stated:** an arm is implicated if it fires in **2 or more of its 3 crawls or 3 or more fires in total**; an arm reading 0 · 0 · 0 is cleared **provisionally**, and the block says with what strength: at the tag rate observed so far (about 1.2 fires per crawl) the chance of three clean crawls by luck is about **3%**, so a clean T0 or T3 is a strong reading; a clean F says little on its own and is there so that "the tag" is a conclusion rather than a residual.

## 3. Ship rule, by outcome

- **A′ fires:** stop; the hour is a variable, and the whole matrix is re-run interleaved before anything is concluded. Nothing ships today.
- **T fires, T0 clean, T3 clean:** the animation from first paint is the amplifier. The tag ships with `animation-delay: 3s` on the mastheads (the pulse begins after hydration; the ruled look is unchanged after three seconds), the delay's reason stated at the rule, and the mechanism recorded as **an observation about the crawl, not an explanation**: what a compositor-only opacity animation does to hydration timing under headless Chromium is unmeasured, and the block says so rather than inventing it. `/welcome` keeps its rail as ruled. Corey can strike the delay in one word; if he does, the tag is held with the clock.
- **T fires, T0 clean, T3 fires:** motion at any time is the amplifier; the tag ships **static** on the mastheads only on Corey's word (it changes the ruled look), otherwise it is held.
- **T fires and T0 fires:** the span itself moves the rate, which no hydration argument predicts, and that is a finding worth more than the feature. Hold the tag with the clock; HO 698 gets both amplifiers.
- **In every branch the font ships in 697** (0 in 3 alone; cleared on evidence, not by subtraction), and the `WelcomeClock` fix ships if F is clean, described as the instrument change it is. Whatever is held is preserved at a named remote tag (`ho697-tag`, beside the two clock tags), and `backlog:135` is rewritten to carry the arms verbatim.

## 4. The §6 leg stays

Whatever ships, the rebuilt tip gets three interleaved crawls against A′ reading 0 · 0 · 0 before the ref is pushed. It is the gate that caught this, and it keeps its place.

## 5. Docs, when the arms have read

The block carries the whole matrix as one table (A, A′, C, E, SHIP, B, D, pre-fix, T, T0, F, T3) with start times, both wrong attributions from this side in their own words and what each missed, the §6 gate as the thing that caught the second, the pooled readings, the decision rule and its power, and the outcome branch taken. `backlog:50` gains the annotation with whichever trees are amplifiers named by tag. `backlog:135` and `:137` per §3. SKILL says what shipped and nothing about what did not, beyond the pointer.

## 6. Record

Nothing pushed, nothing moved, is the right state to be in. The matrix runner is tracked; the arm trees are throwaway once their readings are in the block, except the amplifiers, which are tagged.

read and follow 697 — §6 failure ruled, run the tag arms
