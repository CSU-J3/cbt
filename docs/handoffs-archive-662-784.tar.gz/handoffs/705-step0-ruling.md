# HO 705 — STEP 0 rulings (architect, 2026-09-09)

Arrived against the STEP 0 closure table. Saved per `docs/method.md` § Relay. Verbatim.

---

705 — STEP 0 rulings (Claude, 2026-09-09, against the closure table; row 6 stays parked)

Rows 1, 2, 3, 5 accepted, corrections included: the manifest is the discriminator, not a directory grep; the org is react/react; backlog (b) is :53 and (C) is :90; the second SKILL touch has no target and its correction goes in the block. Row 4 changes the HO and I am ruling on the shape, not Corey: measure before any public act. The jsdom sweep is a good instrument and the wrong table; the browser on CBT's own document is the table this bug was found on.

STEP 1 becomes one thing: CBT itself on Next 16.3.4, against CBT on 15.5.15, in one window.

1. Throwaway branch from 97223d0, never merged: `npm install next@16.3.4`, then `next build` with the minimum flags to get a production build (`--webpack` if Turbopack refuses the config; `middleware`→`proxy` only if the build demands it). Every flag and every edit named in the paste; they are the STEP 0 of a future adoption HO, not this one's. If it does not build inside an hour of config-level changes, stop, list what broke, and fall back to the standalone repro at both versions, calibrated as the handoff's STEP 1 says.

2. Row 1's method on the 16 build: the manifest's framework chunks carry `19.3.0-canary-cbb046ab-20260731`, quoted. That is the proof of which React the window ran.

3. The window, one sitting, interleaved, 36 hits per leg, `seam-intervene-702.ts` unchanged: control(15) · t2(15) · control(16) · t2(16) · t2(15) again as the re-arm. `HYD-BEFORE-TAIL` and `TIMEOUTS` on every leg; no cell quoted without them.

Pre-stated readings. t2(15) ≥ 3 and t2(16) = 0 with `HYD-BEFORE-TAIL` high on both: the fix cures CBT; `backlog:53` is struck citing react#35494 by commit c186624 and this window; nothing is filed; the remedy is a Next 15→16 adoption HO, which is Corey's fork and comes back to him with the build-break list from step 1. t2(16) ≥ 3 with the race intact: the fire is a shape #35494 does not cover; STEP 2 is alive as a report with #35494 and #37551 as siblings, and row 6 unparks then, not before. t2(16) = 0 with `HYD-BEFORE-TAIL` low: the race did not occur and the cell is unread; re-calibrate the lever before drawing anything. t2(15) < 3: the lever is dead today and no cell reads.

Nothing public, nothing in Corey's name, no repo created. HALT after the window with the five summary lines, every fire's per-hit line, the chunk strings from both builds, and the build-break list.

---

## What this changes, as executed

- **STEP 1 is replaced.** The handoff's STEP 1 (a fresh Next repro app, calibrated, plus a
  three-cell version matrix) is superseded by one interleaved window on CBT's own document
  at two Next versions. The standalone repro survives only as the fallback if the 16 build
  cannot be made to run inside an hour of config-level changes.
- **STEP 2 is conditional**, not scheduled: it lives only on the `t2(16) ≥ 3` branch.
- **Row 6 stays parked** and does not go to Corey in this HO unless that branch reads.
- The jsdom sweep already taken is kept as an instrument and as prior art for the report;
  it is not the table any conclusion is drawn from.
