# HO 680 — rotate the two burned keys, then scrub the three rows

Ops plus one data write plus docs. Closes backlog "ROTATE `CONGRESS_API_KEY`" and "ROTATE `CRON_SECRET`" (HO 678). Depends on HO 679 serving: rotating before the sink was live would have written the new key into the next failed run.

## Ground truth at authoring

- Expected `main` `a3b7134` (HO 679), roadmap pointer 679, number `680`. Re-derive at session open; if 679 has not fast-forwarded, STOP, this HO has no precondition to stand on.
- Windows box, Git Bash. `vercel` is the external CLI (53.4.0), logged in as `csu-j3`, project `congressional_terminal`.
- The owner has already: obtained a new Congress key from the api.data.gov signup form, written it to the `CONGRESS_API_KEY=` line of local `.env`, and kept a copy of the OLD key outside the repo for the GSA form.

## The one rule that governs every step

No secret value appears in a command, an argument, an output, a log line, a file under the repo other than `.env`, or the paste-back. Values move by pipe (`... | vercel env add NAME <env> --force`), by file read inside a script, or by owner-side typing. This is method.md § Environment as ruled in HO 678, and it applies to the old values as much as the new ones. Every script written for this HO ends by scanning its own stdout for runs of 40+ alphanumerics and 64 hex characters and exits 1 if it finds any.

Read-back instrument for Vercel is `vercel env ls <env>`: the age column reset from `120d` to seconds is the proof a value changed. There is no other one that doesn't involve reading the value.

## STEP 0 — preconditions, then HALT

Produce this table, then HALT. Nothing is written anywhere before it.

| # | check | instrument | pass |
|---|---|---|---|
| 1 | HO 679 is serving | `curl -s https://congressional-terminal-chi-silk.vercel.app/api/version` | `sha` = `main` by `git ls-remote` |
| 2 | baseline | `SELECT COUNT(*) FROM cron_runs WHERE error_message LIKE '%api_key=%' OR payload LIKE '%api_key=%'` | 3, ids 322/344/8348 |
| 3 | `.env` holds a NEW Congress key | in-process: extract the old value from row 322's `error_message` (`api_key=([^&\s"']+)`), compare to the `.env` value; print only `differs: yes/no`, `new length`, `old length` | differs = yes, both 40 |
| 4 | Vercel still holds the OLD Congress key | `vercel env ls production` and `preview` age for `CONGRESS_API_KEY` | ~121d (not reset) |
| 5 | old `CRON_SECRET` captured for the 401 gate | `grep '^CRON_SECRET=' .env \| cut -d= -f2- \| tr -d '\r\n' > "$TMPDIR/old_cron_680"` (outside the repo), then `wc -c` on it | 64 bytes |
| 6 | `vercel env add --help` | whether `--force` is offered | record; if absent, STEP 1 uses `env rm -y` then `env add` |
| 7 | `vercel redeploy --help` | how a production redeploy is addressed | record the exact flag or form |
| 8 | current production deployment | `vercel ls` (production filter) | one URL, built from `a3b7134` |
| 9 | the two rotation scripts exist and typecheck | see STEP 1 and STEP 3 | `npm run typecheck` clean |

If 1 fails, STOP. If 3 reads `differs: no`, STOP: the owner's `.env` edit has not landed and rotating would push the burned key back to Vercel with a fresh timestamp.

**HALT. Corey confirms the two owner-side steps and rules go.**

## STEP 1 — new values into Vercel and `.env`

Congress key, Production then Preview, by pipe from `.env`:

```
grep '^CONGRESS_API_KEY=' .env | cut -d= -f2- | tr -d '\r\n' | vercel env add CONGRESS_API_KEY production --force
grep '^CONGRESS_API_KEY=' .env | cut -d= -f2- | tr -d '\r\n' | vercel env add CONGRESS_API_KEY preview --force
```

Read back: `vercel env ls production` and `preview`, `CONGRESS_API_KEY` age now seconds, every other row's age unchanged.

`CRON_SECRET`, by `scripts/diagnostic/rotate-cron-secret-680.ts` (tracked; it is next year's tool too): generates `crypto.randomBytes(32).toString("hex")` once, feeds it by stdin to `vercel env add CRON_SECRET production --force` and `... preview --force` (spawn with `shell: true` for the `.cmd` shim, `input:` for stdin), rewrites the `CRON_SECRET=` line of `.env` in place (preserving line endings and every other byte), and prints only: three exit codes, `.env` line count before and after (equal), and the self-scan result. It never logs the value, never writes a temp file, never takes the value as an argument.

Read back: `CRON_SECRET` age seconds in both environments; `grep -c '^CRON_SECRET=' .env` = 1; `.env` byte length changed by exactly 0 (64 hex replaced 64 hex).

## STEP 2 — redeploy, then the gates that can fail

Redeploy the production deployment from STEP 0 row 8 by the form recorded in row 7 (`vercel redeploy <url>`; env is read at deploy, so a new deployment is the only way the new values reach the functions). Then `npm run verify:deploy`; the SHA is unchanged and that is expected, so this gate proves only that the redeploy promoted.

The real gates, run against production, secrets by name only:

```
set -a; source .env; set +a
curl -s -o /dev/null -w '%{http_code}\n' -H "Authorization: Bearer $CRON_SECRET" https://congressional-terminal-chi-silk.vercel.app/api/cron/nominations
curl -s -o /dev/null -w '%{http_code}\n' -H "Authorization: Bearer $(cat "$TMPDIR/old_cron_680")" https://congressional-terminal-chi-silk.vercel.app/api/cron/nominations
```

Expect `200` then `401`. Say what the pair reads if the redeploy did not take: `401` then `200`. Then the row that first call wrote: `SELECT id, route, status, error_message IS NULL FROM cron_runs ORDER BY id DESC LIMIT 1` reads `/api/cron/nominations`, `success`, `1`. That row is the proof the NEW Congress key is accepted by api.data.gov: a bad key would have produced a 403 row, redacted, and the gate reads it. Leave that row alone; it is a real run.

Shred `$TMPDIR/old_cron_680` (`shred -u` or overwrite-then-delete) and read back that it is gone. The old `CRON_SECRET` now exists nowhere reachable.

## STEP 3 — scrub the three rows

`scripts/diagnostic/scrub-cron-runs-680.ts` (tracked). For ids 322, 344, 8348: read `error_message` and `payload`; extract the old key value in-process from `api_key=([^&\s"']+)` (the same extraction as STEP 0 row 3); build the new strings as `redactSecrets(s).split(oldKey).join("[REDACTED:CONGRESS_API_KEY]")`, so the pattern pass removes the parameter and the value pass catches any stray copy the parameter form missed; assert `JSON.parse(newPayload)` succeeds; UPDATE both columns by id; print per row: id, old and new byte lengths, `api_key=` present after (expect `no`), old value present after (expect `no`), payload still valid JSON (expect `yes`).

Read-backs, whole table, not just the three ids:

1. `SELECT COUNT(*) FROM cron_runs WHERE error_message LIKE '%api_key=%' OR payload LIKE '%api_key=%'` = 0. The upstream phrase `An invalid api_key was supplied` has no `=` and survives, by design (SKILL, "Redaction sink").
2. In-process scan of every text column in every table for the old value (the HO 678 probe under `scripts/diagnostic/scratch/`, pointed at the value extracted in STEP 0), printing counts only = 0 everywhere. After this the old key exists in no store the app writes.
3. The three rows still have `status = 'error'`, unchanged `started_at`, and an `error_message` that begins `fetch https://api.congress.gov/` and contains ` -> `.

Any Turso point-in-time window still holds the pre-scrub rows; the GSA disable is what closes that, not the scrub. Say so in the strike.

## STEP 4 — owner action, filed as WATCH

Corey submits the api.data.gov contact form (`https://api.data.gov/contact/#contact`) asking that the old key be disabled, identifying it by the account email and the key itself, both typed by the owner. The old key is valid until GSA acts. Backlog gets a WATCH line: owner Corey, closes on GSA's confirmation, with the submission date. Nothing in the repo carries the old value.

## STEP 5 — docs commit, review ref, FF

One docs commit. Backlog: strike both ROTATE lines (strike, never delete) quoting the readings: env ages before and after per environment, the `200`/`401` pair, the success row id, the three scrub rows, the whole-table 0. Add the GSA WATCH line. Amend the annual-calendar line to name `scripts/diagnostic/rotate-cron-secret-680.ts` and the pipe form used for the Congress key, so next year's rotation starts from a script and not from memory. Oddities: the HO 679 one-sided-gate entry ruled at the 679 FF (a redaction gate with only positives read 11/11 while the helper rewrote `token expired`; review caught it; negatives added). Roadmap `Also (HO 680)`, pointer to 680. No SKILL edit; the scripts' docblocks carry their usage.

Two scripts ride a separate code commit ahead of the docs commit (kinds unmixed), `npm run typecheck` clean before the push. Push both to `refs/heads/680-review`, `git ls-remote` confirm, paste the sha and `git log --oneline a3b7134..HEAD` (two commits). Local `main` stays at `a3b7134` until approval (HO 655: branch first, verify by `git rev-parse main`). On approval: fast-forward, delete the ref, `npm run verify:deploy`, served SHA.

## Paste-back

STEP 0 table at the HALT. After STEP 3: the env-age readings per environment, the `200`/`401` pair, the success row id, the scrub table, the two zero counts, the shred confirmation. After STEP 5: the ls-remote line and the served SHA. Redaction gate on the paste-back before sending: no run of 40+ alphanumerics, no 64-hex run, no `K0Ue`, and the self-scan line from each script quoted.

read and follow 680
