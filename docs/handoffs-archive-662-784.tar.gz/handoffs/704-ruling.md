# HO 704 — the fork ruled: B and then C (architect, 2026-09-08)

**Owner verdict, verbatim: "B and then C"** — Corey, CBT maintenance chat, 2026-09-08, against the HO 704 HALT paste (the STEP 2 window 17:15:48Z → 17:33:13Z and the two throttle tables). Interpretation, stated beside it so a later reader can check the reading rather than inherit it: **B** is candidate (a) declined; nothing from `0c25018` reaches `main`; candidate (b), the upstream repro and report, opens as its own HO. **C** is a reshaped boundary (the masthead into the layout with the boundary around the body, or a designed skeleton as the root boundary's fallback), queued as a design-chat item. "then" is sequencing: (b) first; (C) is not this HO's.

The measured half stands as the record and lands as docs. Nothing render-touching lands.

## 1. Branch topology: the fix stays out

- Leave `704-review-local` where it is, `0c25018` at its tip. Preserve it: `git tag ho704-root-suspense 0c25018`, `git push origin ho704-root-suspense`, and prove it with `git ls-remote --tags origin` (the `ho697-clock` convention: a held tree kept as a remote tag).
- Everything below lands on a new branch from `main`. Re-read `git rev-parse main` and `git ls-remote --heads origin` first (both `bd6621a`), then `git checkout -b 704-docs-local bd6621a`. That branch is the ref that goes up.
- The check that can fail, in the paste: on the branch you push, `git merge-base --is-ancestor 0c25018 HEAD; echo $?` prints `1`, and `git log --oneline bd6621a..HEAD` shows the three commits in § 2 and nothing else.
- `.next` is already gone at teardown; the gate build below runs on the docs branch, whose source is `main`'s.

## 2. Three commits, kinds pure

- **`chore(HO 704)`:** `scripts/diagnostic/suspense-nav-704.ts` tracked, and the throttled row-2 harness tracked beside it. If that measurement was ad hoc rather than a file, write it down as one: a reading that cannot be re-run is a claim. Headers say what each reads; the harness header names `request().sizes()` as the byte source and states the decoded-vs-wire trap, so the instrument carries its own correction. Probes default to tracked (SKILL, Deploy verification); `scripts/**` is in `tsconfig`, so `typecheck` must be clean with them in.
- **`docs(skill)`, alone:** the `#418` bullet gains the outcome. Candidate (a), `<Suspense fallback={null}>` around `{children}` in `app/layout.tsx`, confirmed by intervention (window 17:15:48Z–17:33:13Z 2026-09-08: `t2(unfixed)` 6/36 → `t2(fixed)` 0/36, `HYD-BEFORE-TAIL` 36/36, `TIMEOUTS=0`) and DECLINED on cost: a boundary that suspends on the server defers the page segment into `<div hidden id="S:0">` behind a `$RC` completion, so the segment paints at last byte instead of progressively; measured FCP `/` 184 → 500 ms and `/members` 316 → 784 ms at 10 Mbit/100 ms, `/members` 300 → 2880 ms at 1500 kbit/s. Preserved at tag `ho704-root-suspense`. The standing rule it leaves: **no server-suspending boundary above the page segment without a designed fallback and the throttled FCP reading in the paste.** Next: (b) upstream; (C) a reshaped boundary, design-owned. Provenance after the sentences. One touch; the `/welcome` and masthead entries untouched.
- **`docs(HO 704)`:** roadmap, backlog, oddities, per § 3–5.

## 3. The roadmap block carries

- The row 1 marker reading, the five summary lines in window order, all six fires' per-hit lines, both throttle tables with transfer floors from `request().sizes()`.
- The verdict verbatim with its provenance, and the interpretation from the top of this file.
- Ground-truth corrections: the four stale anchors (react-dom `:2875` / `:11872`, `HeaderBar.tsx:161` / `:171`, versions pinned react-dom 19.2.5 / next 15.5.15) and `backlog:50` → `:51` under the 702 typecheck entry.
- The architect's row 2 expectation (*within noise; +~40 bytes*) falsified, with why the localhost figure was the floor and not the cost: the mechanism is transfer-dependent, so localhost measured parse-and-swap alone. The architect's predicted magnitudes were ~5× high for reading decoded bytes as wire bytes, the same error the first throttled table made and discarded.
- (a′) skipped: the same boundary with the same atomic swap, plus a fallback on every client transition.
- The masthead-boundary variant: a boundary resets the hydration cursor only for what it encloses; the suspending unit is `layout-router.js:276`, above the page; the masthead seam is where a stale cursor is noticed because `<header>` is the segment's first host node. Dead on paper. The discriminator, the suspended thenable's owner in the 702 dumps, is a STEP 0 row of (b); a window is spent on the variant only if that owner sits inside the page.
- The remaining STEP 3 gates not run, and why: STEP 3 was decided rather than measured, and nothing render-touching lands.
- **Notes now run through HO 704.** HO 703 rebases behind this FF.

## 4. Backlog

- **`backlog:51` annotated, never struck.** Headline: *cause NAMED and CONFIRMED (HO 702); remedy (a) CONFIRMED by intervention and DECLINED on cost (HO 704, Corey: "B and then C"); close is still cause plus green, and the green now belongs to (b) or (C).* Body: the window and throttle figures in one paragraph, the tag, a pointer at the block. The fire history stays as written.
- **`backlog:139`** (the held clock) gains one line: the class is live on `main` because 704 declined the remedy, so the clock's amplifier readings stand as taken; re-measure only when a remedy lands.
- **New OPEN LOOP, (b) upstream.** *Owner:* Code. Its HO's STEP 0: React 19.2.x and Next 15.5.x / 15.6 release notes and open issues read for a fix already shipped, and the suspended-thenable owner read from the 702 dumps. Then the minimal repro (Next 15.5.15 / React 19.2.5, a root layout and a page whose flight tail arrives after hydration starts; `t2` lifts it) and the report against React, hydration cursor not reset on a root-level replay, Next cc'd. *Close:* an upstream fix version named and bumped, `t2` on the bumped build reading 0 with `HYD-BEFORE-TAIL` high, then the week of dailies.
- **New QUEUED, (C) reshaped boundary.** *Owner:* Corey/design, behind (b). Two shapes: the masthead into `app/layout.tsx` with the boundary around the body, or a designed skeleton as the root boundary's fallback. Either keeps body paint atomic (transfer time to content) and buys only the chrome arriving early; the throttle tables are the bar it is measured against. Needs a mock.
- Numstat deletions explained line by line.

## 5. Oddities, three entries

1. Marker presence as a fixed/unfixed discriminator: the unfixed build already emits two empty `<!--$--><!--/$-->` pairs (Next's metadata and route-announcer placeholders), so presence read green on the unfixed tree.
2. `<!--$?-->`, React's pending-boundary marker, unknown to the parser, so the fixed build read NO-SEGMENT-BOUNDARY.
3. A transfer floor computed from decoded bytes over a compressed wire: the first throttled table's 2680 ms floor on `/` against a 656 ms FCP would have falsified the mechanism for an instrument reason; the wire is ~5× smaller; `request().sizes()` is the source. The architect's prediction inherited the same unlabelled figure. A byte count without its encoding is a claim.

## 6. Gates, ref, paste

`typecheck` 0 · `build` 0 · `check:odds-sites` 0 · `check:design-citations` OK, run immediately before the paste. Smoke, narrow, fit-finish and captures are not owed: nothing render-touching lands. Numstat deletions column on backlog and roadmap.

Push `HEAD:refs/heads/704-review` from the docs branch, then `git ls-remote --heads origin` and `git ls-remote --tags origin`. Paste: `git show --stat` per commit; the `merge-base --is-ancestor` exit code and the `bd6621a..HEAD` log; the tag line; gate outputs; the numstat with deletions explained. The SKILL diff and the block are read from the ref. Then hold for the SKILL slot and the FF go.

read and follow 704 — ruled B then C, docs only
