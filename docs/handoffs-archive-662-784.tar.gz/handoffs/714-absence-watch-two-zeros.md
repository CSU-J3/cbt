# HO 714 — the Absence Watch band's two zeros become two different renders, and `/` can no longer be silent

Code kind. Closes the backlog line HO 713 deferred to Corey (*Absence Watch: a guarded failure and the good-news state render identically on `/`*). Corey's word: *"lets work on this now."* The property is true in the tree's own words (`lib/queries.ts:5577-5582`: an empty array *is the good-news state, which renders nothing at all*, and the HO 598 guard returns exactly that array on a throw), and HO 713 showed what the consequence looks like from the outside: a reading of nothing that no gate, log or reader can classify. The incident was false; the property is not.

**Ruled by the architect on Corey's engagement, overridable in a word.** The ledger line carried two remedies with no recommendation because it was deferred; now that it is called, the call is **both, and the failure state gets its own render too**: three states, three different strings, and a gate that fails on the one that should never be served.

## Ground truth at authoring (`main` at `9077492`, 2026-09-11; re-derive at STEP 0)

- **Number.** Pointer 713, highest HO in commit subjects 713 → 714. HO 715 (the committee-votes probe) is authored alongside and is independent.
- **The read path.** `app/page.tsx:128` `getAbsenceWatch()` in the home `Promise.all`; `:162` `<AbsenceWatchBand members={absent} nowMs={nowMs} />`; `:40` `force-dynamic`. `lib/queries.ts:5339` `queryAbsenceWatch(): Promise<AbsentMember[]>` reads the last `ABSENCE_WINDOW` roll calls **per chamber** (`:5379` loops `ABSENCE_CHAMBERS`, `:5385-5388` `SELECT id, vote_date FROM votes WHERE chamber = ? ORDER BY vote_date DESC, id DESC LIMIT ?`), so the window's dates are already in hand inside the function and thrown away. `:5572` `unstable_cache(…, { revalidate: 3600, tags: ["votes"] })`; `:5583-5590` `getAbsenceWatch()` catches outside the cache and returns `[]` with `[absence-watch] read failed`.
- **The render.** `components/AbsenceWatchBand.tsx:111` `if (members.length === 0) return null` (C4, per-segment after HO 645: either tier at zero drops its segment and the separator). Classes `abw`, `abw-head`, `abw-title`, `abw-title--warn`, `abw-count`, the cards under `abw-*`. The band is a server component fed `nowMs` for the dated copy discipline (HO 490); the card back's congress label now comes off the row (HO 712).
- **The gate that reaches `/`.** `e2e/smoke.spec.ts:649` one test per `ROUTES` entry, `:653` `context.addCookies([GATE_COOKIE])`, document status asserted at `:781` / `:789` for hit-1 and hit-2; the `pageErr` channel is a reading, not an assertion. `e2e/routes.ts` carries `home` at `/`. Any probe of `/` carries `ct_seen` (SKILL, HO 713).
- **Live content today (HO 713 FF paste, with the cookie):** `abw-` 246 occurrences, MIA (1) · AT RISK (11). The good-news state has not been served since HO 623 shipped the band; the failed state has been served an unknown number of times, indistinguishably.

## The rule, pre-stated

- **Return shape.** `queryAbsenceWatch` returns `{ members: AbsentMember[]; window: { house: string | null; senate: string | null } }` where each `window` date is the `vote_date` of the oldest roll call in that chamber's Phase-A window (the 8th-most-recent), read from the query the function already makes. The guard returns `{ members: [], window: null }` on a throw. One caller (`app/page.tsx`) adapts; the type is exported as `AbsenceWatch`.
- **Three renders.** Cards present → unchanged. `members` empty with a `window` → the **good-news line**: `<section class="abw abw--empty">` carrying one `--text-dim` sentence, *No member has missed the last {ABSENCE_WINDOW} roll calls of their chamber · House through {Mon D} · Senate through {Mon D}*, dates from `window`, no header treatment, no `▲`. `window === null` → the **failed line**: `<section class="abw abw--failed">`, one dim sentence, *Absence Watch could not be read on this request — it retries on the next*. Three states, three distinct class hooks, no two of them byte-identical.
- **The gate.** In `smoke.spec.ts`, for `home` only: after hit-1, `page.locator(".abw-card, .abw--empty").count()` must be ≥ 1 and `.abw--failed` must be 0. A failed read on production `/` is an incident, not a flake to tolerate, and the crawl already runs with the gate cookie so it reads the dashboard. **Overridable** to *report, don't assert* in a word, with the reason written down.
- **Copy is dated from data, never the clock.** The dates are the window's, not `nowMs`; `nowMs` stays for the streak copy it already serves.
- **CSS additive** under `.abw--empty` / `.abw--failed`; the existing band untouched; every other route byte-identical.

## STEP 0 — enumerate, then HALT

| # | check | expected |
|---|---|---|
| 1 | callers of `getAbsenceWatch` / `AbsentMember[]` beyond `app/page.tsx` (`grep -rn "getAbsenceWatch\|AbsentMember\[\]" app lib components e2e scripts`) | one page caller; anything else is a second adapter |
| 2 | the window read: quote `:5379-5390` and confirm the oldest date in the fetched set is the 8th roll's, per chamber, on today's data (`House through …`, `Senate through …` printed) | two dates |
| 3 | the `home` smoke test's current assertions and whether any existing assertion would already fail on an empty band | none does — that is the gap |
| 4 | `ABSENCE_WINDOW`, `ABSENCE_CHAMBERS`, `ABSENCE_WALK_BOUND` values and the SKILL Absence Watch section's C4 sentence, quoted | 8 · house/senate · 120 · the sentence STEP 3 rewrites |
| 5 | the `.abw` CSS block extent in `globals.css` (start/end lines), so the additive rules land beside it | a line range |
| 6 | served `/` with the cookie today: `abw-` count and the two tier counts, as the pre-state | the live reading |

**HALT** with the six readings and the three sentences of copy as they will render. Corey's word, if any, on the gate's *assert* vs *report* and on the two sentences; silence keeps the rule.

## STEP 1 — build

- **Commit 1 — `feat(HO 714): getAbsenceWatch returns its window; the guard returns a null one`** — the return shape, the type, the single page adapter, the guard.
- **Commit 2 — `feat(HO 714): the band renders three states, none of them nothing`** — `AbsenceWatchBand.tsx` C4 rewritten; the two sentences; `.abw--empty` / `.abw--failed` additive CSS; `formatShort` for the dates from the existing date helpers.
- **Commit 3 — `test(HO 714): / is never silent`** — the `home` assertion in `smoke.spec.ts`.
- **`docs(skill)`** — Absence Watch section: C4 rewritten to the three-state rule; the return shape; the gate; the two-zeros sentence naming HO 713 as the incident that was false and the property that was not.
- **`docs`** — strike the deferred backlog line with the reading; roadmap block; oddities only if STEP 0 finds one.

## STEP 2 — proof

- Build then typecheck; `check:design-citations`; `check:odds-sites` unchanged.
- **Fixture, three states, captured at 1440 / 430 and reduced-motion:** the band with today's members; with `members: []` and a real window (the two sentences with today's dates); with `window: null`. Three captures, three different strings, no two DOMs equal — diffed pairwise, counts pasted.
- **The gate proven to fail:** run the `home` smoke test against a local build with the band's return temporarily forced to `{ members: [], window: null }` (a fixture flag, never committed, never prod) → red on `.abw--failed`; restore → green. A gate that has not been red is not a gate.
- **Served `/` unchanged today:** DOM diff against `9077492` reads **+0 / −0** (cards present, so the new branches do not render), and the cookied `abw-` count equals the STEP 0 pre-state.
- Local 430/390 scrollWidth readings named as predictions; the CI reading from `narrow-preview`.

## STEP 3 onward

Review ref `714-review`; `git ls-remote --heads origin`; paste; hold for the go.

## Paste-back

The STEP 0 readings; the three fixture captures with pairwise DOM diffs; the gate red-then-green; the served `+0 / −0`; per-commit `--stat`; the SKILL and docs diffs with numstats; the `narrow-preview` run; `git ls-remote --heads origin`.

read and follow 714
