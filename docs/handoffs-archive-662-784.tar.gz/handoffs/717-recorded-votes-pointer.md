# HO 717 — wire the pointer, not the parse: every markup's recorded-vote documents one click away, nothing asserted that cannot be parsed

Code kind, small extension along the meeting spine (attaches to tracked committees, meetings and bills → theme extension, in scope). **Owner verdict, verbatim: "c"** — Corey, CBT maintenance chat, 2026-09-12, on the HO 715 decision line's three options; read as **(C)** *wire the pointer, not the parse*: link each markup's recorded-vote documents from the meeting rows, no member-level claim. The letter closes the ledger line with its provenance in STEP 4.

## Ground truth at authoring (`main` at `b0e1cf5`, 2026-09-12; re-derive at STEP 0)

- **Number.** Pointer 716, highest HO in commit subjects 716 → 717 (715 landed as the lower number second).
- **The pointer exists and is discarded today.** `lib/meetings-sync.ts:130-144` `ApiMeeting` models `videos` and `relatedItems.bills` and nothing else; `:174` says so (*the messier meetingDocuments PDF-name path is deliberately NOT parsed in v1*). HO 715 measured the field: `meetingDocuments[].documentType`, with `Committee Recorded Vote` on 72% of sampled 119th House markups and 80% once records mistyped `Support Document` are matched by name (Appropriations files every roll call as *"… – Roll Call Votes"*); files at `www.congress.gov/119/meeting/house/{eventId}/documents/{file}`; not every vote-typed document is a roll call (some are voice-vote summaries); a missing file answers HTTP 200 with an HTML *Not Found* body. Full findings: `docs/probes/715-committee-votes-findings.md`.
- **The event page is already in the payload.** `videos[]` carries two entries per event, one of them the `congress.gov` event-page referrer (`api.` or `www.`) that `extractVideoUrl` (`:166-171`) skips on purpose. That referrer is the human-readable index of the meeting's documents and is the natural link target. Its presence rate is a STEP 0 reading.
- **The cursor decides the design.** The sync is a per-chamber `update_date` watermark walk (`:9-21`, `:67`): an event is re-fetched only when its `updateDate` moves past the watermark. Vote files post a median 9.9 h after the meeting starts, 90th percentile 49.4 h (HO 715 row 2). **Whether adding a document moves the event's `updateDate` is unmeasured** (HO 715 named it). If it does, the existing walk collects documents for free; if it does not, past markups need a rolling re-read. STEP 0 row 1 measures it before anything is designed on it.
- **The child-table pattern.** `scripts/migrate.ts:736-741` `meeting_bills(event_id, bill_id, UNIQUE)` with its index, written by `upsertMeeting` (`:178+`) as a delete-then-insert per event inside the meeting's batch, *so a meeting that loses a bill association clears*. The documents table follows it exactly.
- **The surfaces.** `components/HearingRow.tsx` renders the row: `▶ WATCH` as an external link when `videoUrl` and state allow (`:51-61`, `:79-89`), bill links (`:113-115`), the committee link (`:134`). Queries feeding it all select `MEETING_COLS`: `getUpcomingMeetings` `lib/queries.ts:9232`, `getRecentMeetings` `:9266`, `getMeetingsByCommittee` `:9289`, `getMeetingsForBill` `:9315`. Routes in the crawl: `hearings` (`e2e/routes.ts:55`) and `committee-detail` (`:76`); the bill hub mounts meetings through `getMeetingsForBill`.
- **Budget.** `api.congress.gov` 20,000 requests/hour (HO 715 row 8); the House has ~1,600 meetings in the 119th. A one-time backfill of every meeting detail is under a tenth of one hour's budget.

## The rule, pre-stated

- **Store the upstream, derive the view.** New table `committee_meeting_documents (event_id TEXT NOT NULL, name TEXT NOT NULL, document_type TEXT, url TEXT NOT NULL, UNIQUE(event_id, url))` plus an index on `event_id`, written per event as delete-then-insert beside `meeting_bills`, holding **every** `meetingDocuments[]` entry as filed. No parsing, no type normalisation at write time.
- **One predicate names a recorded-vote document, and it lives in one place:** `document_type = 'Committee Recorded Vote' OR (document_type = 'Support Document' AND name LIKE '%Roll Call%')` — the two rules HO 715 measured, as a SQL fragment constant exported from `lib/queries.ts` and used by every reader. A third rule is a SKILL edit, not a second copy.
- **The event page is the link target**, taken from the `congress.gov` referrer in `videos[]` (new `event_page_url` column on `committee_meetings`, nullable) and constructed from the id only if STEP 0 shows the referrer absent on a measurable share; the count on the row is the count of documents matching the predicate, labelled with the upstream's own term.
- **The affordance:** on a meeting row, beside `▶ WATCH`, **`RECORDED VOTES · n ↗`** as an external link to the event page, rendered only when `n > 0`; absence is the signal. Same link shape and tokens as WATCH (`HearingRow.tsx:51-61`), no new chip tier. The `n` is documents, not roll calls, and the SKILL entry says so; the tooltip (`title`) reads *n recorded-vote documents on congress.gov — the committee's own record, not parsed here*.
- **Cursor behaviour by measurement.** If row 1 shows `updateDate` moves on document add: nothing beyond storing documents on the existing walk, plus a one-time `backfill:meeting-documents` for events already synced. If it does not move: the same backfill, plus a rolling re-read inside `sync:meetings` of past markups with `meeting_date` in the last 7 days (bounded, ~a few dozen details per run), with its own counter in the summary line. Either way the summary prints `documents_stored=N recorded_vote_docs=N events_reread=N`.
- **Nothing member-level.** No `member_votes` rows, no MIA input, no attendance claim anywhere. The SKILL Absence Watch section keeps its sentence that MIA is floor-only, and gains the pointer's existence as the reason a reader can check the committee record themselves.

## STEP 0 — measure, then HALT

| # | check | expected / what it decides |
|---|---|---|
| 1 | **the cursor question:** for 10 recent past markups with vote documents (from the HO 715 artifacts), read the API's current `updateDate` and the Committee Repository's per-file *Added* timestamps; is `updateDate` ≥ the last *Added*? | ≥ on all → documents ride the walk; < on any → the rolling re-read is needed; the row's table is pasted |
| 2 | referrer presence: over the same sample plus 20 random meetings, does `videos[]` carry a `www.congress.gov` or `api.congress.gov` event-page entry, and does it resolve 200 with the documents listed? | the rate; if < 100%, the constructed fallback URL pattern is read off a real page and quoted |
| 3 | `MEETING_COLS` and the four readers: the column list, the row type, the four cache tags/TTLs | so the count joins into every reader once |
| 4 | `HearingRow` link states: `WatchState` (`:29`) and when the WATCH slot renders; where the new link sits at ≤ 700 (the row's narrow layout) | the placement, so 430/390 are designed rather than discovered |
| 5 | `e2e/routes.ts:76` `COMMITTEE` value — a committee with recent markups carrying vote documents, so the crawl exercises the affordance | the slug's target has `n > 0` |
| 6 | the sync's summary line today and the cursor state (`dashboard_state` rows for meetings) | the before figures |
| 7 | SKILL exposure: the HO 715 entry (*probed, not wired*), the `sync:meetings` entry, the schema section's `committee_meetings` / `meeting_bills` block, the Absence Watch floor-only sentence, the `/hearings` pages entry | the lines STEP 3 amends |
| 8 | oddities check on the soft-404: the event page itself for a meeting whose vote file is missing on both hosts (HO 715, Appropriations 119200) — does the page still list the file? | whether the link target can itself be a 200-not-found |

**HALT** with row 1's table and the cursor disposition; Corey has no ruling to make here unless STEP 0 finds a fork.

## STEP 1 — build

- **Commit 1 — `feat(HO 717): committee_meeting_documents — the meeting's documents stored as filed`** — migration (table + index + `committee_meetings.event_page_url`), `ApiMeeting` gains `meetingDocuments[]`, `upsertMeeting` writes documents delete-then-insert and the event page URL, the summary counters, the rolling re-read if row 1 requires it (its own flag and counter).
- **Commit 2 — `feat(HO 717): backfill:meeting-documents`** — one pass over every synced 119th meeting, detail re-fetched, documents written, `events_read / documents_stored / recorded_vote_docs / soft_404_pages` printed; idempotent; budget printed.
- **Commit 3 — `feat(HO 717): RECORDED VOTES · n on meeting rows`** — the predicate constant, the count joined into `MEETING_COLS`'s readers (one subquery, one place), the row's link beside WATCH, tooltip copy, additive CSS only if the WATCH tokens do not already cover it; bill hub rows inherit through `getMeetingsForBill`.
- **`test(HO 717)`** — only if a seam exists: a fixture row with `n = 3` and one with `n = 0` proving the link renders for one and not the other.

## STEP 2 — proof

- Build then typecheck; `check:design-citations`; `check:odds-sites` unchanged.
- Prod, in order, every write read back: `npm run migrate` (PRAGMA shows the table and the column); `backfill:meeting-documents` (counts; `SELECT COUNT(*), COUNT(DISTINCT event_id) FROM committee_meeting_documents`; the recorded-vote count under the predicate against HO 715's sampled 43-of-60 rate, stated as a comparison not a criterion); one `sync:meetings` run showing the counters non-zero on at least one event or stating why zero today; `POST /api/revalidate` on the meetings tag(s).
- **The predicate falsified on a fixture:** three synthetic documents — typed `Committee Recorded Vote`, typed `Support Document` named *"Markup – Roll Call Votes"*, typed `Support Document` named *"Witness List"* — read 2 under the predicate, and the reader shows `n = 2`.
- **Served after FF:** `/hearings` rows with `RECORDED VOTES · n ↗` where `n > 0` and none where `n = 0`, counted against the DB (`n` in the DOM equals the predicate's count for that event, three events checked); the link resolves to the event page listing the files; the committee page from row 5 shows the same; a bill hub whose markup carries votes shows it in its meetings block. DOM diff on `/hearings` against `b0e1cf5`: **+N / −0**, N accounted for by the rows with `n > 0`.
- Captures at 1440 / 430 / 390 of a row with and without the affordance, reduced-motion pass; the CI reading from `narrow-preview` on `hearings` and `committee-detail`.

## STEP 3 — SKILL (own commit)

The HO 715 entry: *probed, not wired* → *wired as a pointer (HO 717): documents stored as filed, the recorded-vote predicate, the count is documents not roll calls, nothing parsed, nothing member-level*; the cursor finding from row 1 written as fact; `sync:meetings` and the schema section gain the table and the column; the `/hearings` pages entry gains the affordance; the Absence Watch floor-only sentence gains *the committee record is one click away on the meeting row (HO 717)*; the soft-404 clause stays.

## STEP 4 — docs

Backlog: **close the HO 715 decision line with the letter** — *"c"*, Corey, 2026-09-12, chat — and what it built; new line for the docs.house.gov *Added* timestamp as a second upstream (probe → wire on its own, if ever wanted); WATCH if row 1 forces the rolling re-read (*events_reread should read > 0 within a week of any markup; 0 for a month means the window is wrong*). Oddities: only what STEP 0 finds (row 8 is the candidate). Roadmap block with the readings and the pointer to 717.

## STEP 5 onward

Review ref `717-review`; `git ls-remote --heads origin`; paste with the Preview reading; hold for the go.

## Paste-back

The STEP 0 table with row 1's per-event table; per-commit `--stat`; the prod sequence with read-backs and the budget; the predicate fixture; served counts against the DB; captures; SKILL and docs diffs; `git ls-remote --heads origin`.

read and follow 717
