# HO 667 — retire the orphaned dashboard-lead generation path (backlog :91, ruled RETIRE), closing HO 637 finding 1 with it, and carrying the primaries display-orphan ghost strike (backlog :100, shipped at HO 603)

**Read this file in full before executing anything. Execute in order. HALT conditions are hard stops — report and wait, do not improvise past them. Two HALTs: the STEP 0 closure table, and the pre-land review ref. Nothing lands on `main` before the second is approved. A third, post-land step (the `weekly_lead` row delete) has its own paste-back.**

Base: `main` at `ebea5de` or later. Clone fresh; verify HEAD before starting (concurrent-session rules per `docs/method.md` § Session start). Number derived per method: max(roadmap pointer 666, highest commit-subject HO 666) + 1. Environment: code edit + `npm run build` then `npm run typecheck` (build first — the HO 665 stale-`.next/types` oddity), plus one local `npm run start` render of `/` (`.env` `TURSO_DATABASE_URL`/`TURSO_AUTH_TOKEN`), plus **one post-land read-write DB step** (the row delete) run against the live DB after `verify:deploy` matches. Either machine; no WSL/Docker. Bind check in STEP 3 mandated (HO 664 → 665 procedure).

## The ruling this HO executes

Backlog `:91` is owned by Corey first — "retire-or-restore is a product call" — and Corey ruled **RETIRE** in chat on 2026-08-15. This HO is the Code half. Nothing has rendered the lead since HO 244; `getDashboardLead` has zero consumers outside `lib/queries.ts` (grep-confirmed at HO 637 and re-confirmed at `ebea5de`); the step measured ~25.3s of a 40.4s `/api/sync` run (HO 139) plus one Gemini call and two windowed `bills` reads per tick, four times a day. The entry's close, RETIRE branch: **the generator + `getDashboardLead` + the `weekly_lead` `dashboard_state` row are removed and the SKILL note retired.** Retiring also **closes HO 637 finding 1 outright** — `lib/dashboard-lead.ts:64` and `:103` are the last non-Group-A `datetime('now')` comparisons against `stage_observed_at`; they die with the file. State that in the close note; it's half the reason this is worth doing.

**`lib/queries.ts` IS in scope this time, narrowly** — the entry itself names `getDashboardLead` for removal. That is the difference from HO 664–666's "queries.ts untouched" rule: those HOs didn't own a queries.ts symbol; this entry does. Touch `getDashboardLead` (`~:1072–1090`, its comment header included) and nothing else in that file.

## Recon at `ebea5de` (STEP 0 re-derives all of it)

- **`lib/dashboard-lead.ts`** — 182 lines. DELETE. Imports: `GoogleGenAI` (`@google/genai`), `getDb`, `queryEnactedThisWeek` (survives — `lib/queries.ts:42/6980`), `SUMMARY_MODEL` from `lib/summarize.ts` (survives — `summarize-runner.ts`, `report-generation.ts`, `news-matcher.ts`). Exports `generateDashboardLead` `:149`, `writeDashboardLead` `:172`. Const `LEAD_KEY = "weekly_lead"` `:6`. The two `datetime('now')` sites `:64`/`:103`.
- **`app/api/sync/route.ts`** — the call site: import `:5–7`; the lead step `:112–124` (the `try { generateDashboardLead(); writeDashboardLead(); revalidateTag("bills") } catch` block, `timings.lead`, its `console.log`); the `lead: null` initializer in the timings object `:55`. Removing `timings.lead` **changes the route's returned payload shape** — STEP 0 verifies no consumer reads `.lead` from that payload (`lib/cron-health.ts` and any cron-health component read 0 at `ebea5de`; confirm with a positive control on a key that IS read, e.g. `timings.sync` or `trades`).
- **`lib/queries.ts:1072–1090`** — `getDashboardLead` (`unstable_cache`, tag `bills`, cache key `["getDashboardLead"]`) + its comment header. DELETE. Zero consumers outside the file — re-verify with a positive control (`getEnactedThisWeek` or another exported query must read >0 consumers).
- **`scripts/generate-lead.ts`** — the manual runner. DELETE, with the **`package.json` `"lead"` script (`:54`)**.
- **`scripts/diagnostic/sync-trailing-cost-479.ts`** — **imports `generateDashboardLead` (`:18`) and calls it (`:325–326`)**. `scripts/**` is in `tsconfig.json` `include`, so this **breaks typecheck** post-delete unless handled. Proposed verdict: EDIT — drop the import and the "generateDashboardLead (DB+Gemini)" measurement arm, add a header line recording the arm's removal at HO 667 (the instrument-reconciled-so-it-can't-lie shape, HO 661/663 precedent). The alternative (delete the whole diagnostic) loses the trades/sync arms that are still meaningful; argue it only with evidence.
- **`scripts/diagnostic/check-lead-134.ts`** — its whole purpose is reading the `weekly_lead` row. Proposed: DELETE (a probe of a row this HO deletes is a probe of nothing). Table rules.
- **RECORD prose that stays** (comments/strings, no imports): `scripts/diagnostic/sync-timeout-verify-480.ts` (`:5`, `:56`, `:119`, `:138` — reads the row in a query string; it will report `MISSING` if ever re-run, which is the truth), `sync-trades-margin-482.ts` (`:5`, `:23`, `:254`), `scripts/migrate.ts:80` ("Currently holds key = 'weekly_lead'" — EDIT, one clause: that key was retired at HO 667; the table stays), `lib/enacted-this-week.ts:4` (names the generator as a consumer — EDIT to RECORD), `lib/primaries-sync.ts:1862` (names `getDashboardLead` as the reader — EDIT to RECORD, comment-only), `lib/queries.ts:6975` (compares a cache read to "the cron's raw read in lib/dashboard-lead.ts" — EDIT to RECORD, comment-only, same file as the getDashboardLead delete so it rides the same hunk set).
- **`dashboard_state` other keys are LIVE** — `primaries-sync` cursor, `lda-rollup` blobs, kalshi. The row delete is `WHERE key = 'weekly_lead'` exactly, never a table drop, never a prefix.
- **SKILL** at `ebea5de`: `:217` (dashboard_state key list names `weekly_lead`), `:1119` (the `/api/sync` 40.4s breakdown "sync 5.9s + lead 25.3s + trades 9.0s" — HISTORY figure, gains a RECORD clause: lead step retired at HO 667), `:1588` (`getDashboardLead()` entry with the "deprecated-candidate, do NOT remove" note — **the note this entry retires**; → RECORD deleted at HO 667, the design call was RETIRE), `:1696–1706` (the whole "dashboard lead" section — collapse to a RECORD paragraph: what it was, orphaned HO 244, retired HO 667, where the prompt lives in history; do not delete the section header if other prose anchors on it). **No `:2087` append** — nothing here is a client island (the HO 665 criterion, applied the same way).
- **e2e**: grep at STEP 0; expected 0.

## STEP 0 — enumerate; closure table; HALT

Line numbers are as of `ebea5de` — re-derive at your HEAD (HO 652). **Controls first** (HO 664–666: eight instrument failures, zero code failures). Produce the closure table (candidate · verdict · evidence `file:line` · destination) covering at least:

1. `lib/dashboard-lead.ts` — DELETE; per-import survivor check for `queryEnactedThisWeek` and `SUMMARY_MODEL` (name survivors `file:line`); the two `datetime('now')` sites named as HO 637 finding 1's last product-code residue.
2. `app/api/sync/route.ts` — the import, the step block, `timings.lead` init; the payload-shape check with its positive control; confirm `revalidateTag("bills")` after `runSync` (`:110`) stays — only the lead block's second `revalidateTag` goes.
3. `lib/queries.ts` `getDashboardLead` — DELETE with header; zero-consumer re-verify with control; the `:6975` comment reconcile. **Nothing else in the file.**
4. `scripts/generate-lead.ts` + `package.json` `"lead"` — DELETE both; grep `npm run lead` across `docs/ .claude/ scripts/ .github/` and classify (docs prose stays; SKILL `:1705` is in the section collapse).
5. `scripts/diagnostic/sync-trailing-cost-479.ts` — EDIT per the recon (or argue delete); `check-lead-134.ts` — DELETE (or argue keep); typecheck consequence stated for each.
6. Comment reconciles: `enacted-this-week.ts:4`, `primaries-sync.ts:1862`, `migrate.ts:80`, anything the fresh grep adds. RECORD-and-stay set named: 480, 482.
7. `dashboard_state` live-key census — list every key written anywhere in `lib/` (`primaries-sync`, `lda-rollup`, `kalshi`, …) so the row delete's `WHERE key = 'weekly_lead'` is provably the only casualty. Also read the current row: `SELECT key, updated_at FROM dashboard_state WHERE key = 'weekly_lead'` — expect 1 row with a recent `updated_at` (the cron is still writing it); paste it. That's the pre-state for the post-land delete.
8. SKILL inventory, fresh greps: `dashboard-lead`, `getDashboardLead`, `weekly_lead`, `generate-lead`, `npm run lead`, `DashboardLead`, `deprecated-candidate`. Classify each LIVE-CLAIM vs RECORD.
9. **The carried strike, verified against the tree:** backlog `:100` "Primaries display-orphan sweep (HO 559 → owed)" — every named symbol was deleted at **HO 603 `1adf056`** (2026-08-05, ancestor of HEAD): `PrimaryDistrictCard.tsx` −138, `PrimaryMapCard.tsx` −116, `PrimaryRow.tsx` −271, `getPastPrimaries`/`getUpcomingPrimaries` out of `lib/queries.ts` (−36), `buildPrimariesCartogram`+`PrimaryBand` out of `cartogram-data.ts` (−102), the `variant === "primaries"` fork out of `CartogramShell.tsx` (−116, its header `:14–18` records it); −854 across 9 files; roadmap "Also (HO 603–604)" recorded it; the ledger never struck it. Confirm with `git merge-base --is-ancestor 1adf056 HEAD`, `ls components/Primary*` (only `PrimaryTimeline.tsx` survives), and `grep -rn getPastPrimaries lib/queries.ts` (2 comment hits, 0 definitions). **Fourth never-struck instance in four sessions** — say so.
10. Out-of-scope, named: `lib/enacted-this-week.ts` beyond its one comment; `lib/summarize.ts`; every other `dashboard_state` key; the `/api/sync` trades and rating steps; `lib/cron-health.ts` unless the payload check forces it (then it's a table finding, not a chase); the `CRON_ROUTES` stale string (its own entry).

**HALT.** Paste the table back. If anything reads other than expected — a live `getDashboardLead` consumer, a payload consumer of `timings.lead`, a second row under the key, an import of `dashboard-lead` the recon missed — the verdict changes and the table says so.

## STEP 1 — the chore commit (after the table is approved)

`git checkout -b 667-review-local` first. One commit, one kind:

`chore(HO 667): retire the orphaned dashboard-lead generation path`

Expected shape: `lib/dashboard-lead.ts` −182; `scripts/generate-lead.ts` and (if ruled) `check-lead-134.ts` gone; `package.json` −1; the sync route −~15; `lib/queries.ts` −~20 (the one function + header + the `:6975` clause); `sync-trailing-cost-479.ts` arm removed; the three comment reconciles. Nothing else rides.

## STEP 2 — gates

- `npm run build` then `npm run typecheck`, both green (report both readings if typecheck was run early and went red on stale types).
- Greps, controls first: `dashboard-lead` / `generateDashboardLead` / `writeDashboardLead` / `getDashboardLead` 0 live references across `app/ components/ lib/ scripts/ e2e/` (RECORD comments reported as "0 live, N RECORD"); `weekly_lead` 0 live writes/reads in `lib/ app/` (the 480 diagnostic's query string reported as RECORD); control: `queryEnactedThisWeek` >0.
- Build route manifest still lists `/api/sync` (positive control that the route compiles after the edit).

## STEP 3 — runtime confirmation (bind check mandated)

1. `npm run start -p 31xx`, PID captured, **bind verified** (`lsof`/`ss` maps the socket to your PID).
2. `/` reads 200 with `Cookie: ct_seen=1`, both stylesheets 200, and a content assertion on the masthead stat readout (the HO 244 surface that replaced the lead — name the string). Nothing rendered the lead, so this proves the dashboard didn't depend on it, not that the lead is gone.
3. **Do not hit `/api/sync` locally** — it writes bills to the live DB and calls Gemini. The route's shape is proven by build + typecheck + the manifest; its runtime is proven post-land (below).
4. Kill by PID, port-scoped.

## STEP 4 — docs commit (`docs: HO 667 — …`)

4.1 **`docs/backlog.md`** —
- **`:91`** — strike, with the close note: RETIRE ruled by Corey 2026-08-15; retired at <chore SHA> (files/lines); `getDashboardLead` removed from `lib/queries.ts` (the entry-owned exception to the shared-file rule, stated); the `"lead"` npm script gone; the 479 diagnostic reconciled / 134 deleted per the table; **HO 637 finding 1 closed outright** — the last two non-Group-A `datetime('now')` compares against `stage_observed_at` died at `dashboard-lead.ts:64/:103`, so the mixed-format `'T' > ' '` boundary compare has no product-code residue; the `weekly_lead` row delete recorded as **PENDING post-land** (or DONE with the paste, if the strike is written after STEP 6 — either way the note carries the row's final state); expected `/api/sync` saving ~25s/tick and one Gemini call, filed as a WATCH to verify on the first post-deploy tick.
- **`:100`** — strike, with: DONE **HO 603 `1adf056`** 2026-08-05 (the figures above), recorded in the roadmap 603–604 block, never struck in the ledger; struck here as HO 667 session-open reconciliation, verified against the tree at `ebea5de`. Fourth instance of the never-struck class.
- **New WATCH entry**: first post-deploy `/api/sync` tick — confirm the log/payload carries no `lead` step and total drops on the order of the HO 139 measurement (~25s); close on the observation with the tick's timestamp. Owner: Corey (Vercel logs) or Code (the route's payload via `verify:deploy`-adjacent read, if one exists — say which).
- Strike = `~~…~~` + close note; do not delete the lines.

4.2 **`docs/roadmap.md`** — one `Also (HO 667)` block, append-only, pointer 667: the ruling and who made it, the chore's numbers, HO 637 finding 1 closed, the queries.ts scope exception and why it's principled, the ghost strike as the fourth instance, the WATCH filed, the row-delete disposition, the oddities disposition. No retro-edits.

4.3 **`docs/oddities.md`** — only if something odd emerged; nothing odd → no entry, say so in the roadmap block.

## STEP 5 — SKILL commit (`docs(skill): HO 667 — …`), self-mod guarded

Per the approved STEP 0 classification, minimal: `:217` key list (weekly_lead → RECORD retired), `:1119` gains the RECORD clause, `:1588` → RECORD (deleted HO 667; the "do NOT remove" note retired because the design call was made), `:1696–1706` collapsed to a RECORD paragraph. **No `:2087` append.**

## HALT — the review ref; nothing lands before approval

Push `git push origin HEAD:refs/heads/667-review` (`--force-with-lease` on the ref only). Paste back: table deltas, `git show --stat` ×3, STEP 2/3 outputs incl. bind evidence and the masthead assertion, backlog numstat with every deletion explained (two in-place strikes + one insertion expected; `grep -c '^-[^-]'` is not a deletion count — HO 643), docs + SKILL diffs. `git ls-remote` for remote claims. One swallow → gitignored file. **The SKILL diff needs explicit approval.** After approval: `git push origin HEAD:main` (no force), delete the ref, `git ls-remote --heads origin`.

## STEP 6 — post-land: the row delete (its own paste-back)

**Only after** `main` is fast-forwarded AND `verify:deploy` matches the new SHA (so no deployed cron can rewrite the row):

1. Read: `SELECT key, updated_at FROM dashboard_state WHERE key = 'weekly_lead'` — expect 1 row (paste it).
2. Delete: `DELETE FROM dashboard_state WHERE key = 'weekly_lead'` — expect `rowsAffected: 1`.
3. Re-read: expect 0 rows. Then a control read on a live key (e.g. the `primaries-sync` cursor key, or `SELECT COUNT(*) FROM dashboard_state`) to show the table is otherwise intact — paste before/after counts.
4. Paste all three; if the strike at 4.1 said PENDING, the record of this paste is what closes it (append to the backlog `:91` close note in a one-line follow-up docs commit `docs: HO 667 — weekly_lead row deleted`, or fold it in if you sequenced the strike after this step — say which you did).

Use the project's own hrana/tsx harness (`scripts/diagnostic/*` show the pattern); do not add a migration; do not touch any other key.

## Verification gates (in the paste)

- STEP 2/3 green; tree clean after the commits.
- Backlog numstat explained line-by-line; both struck lines survive inside `~~…~~`.
- Anchored greps: `grep -cE '^\*\*Also \(HO 667' docs/roadmap.md` = 1; `grep -rn "dashboard-lead" app components lib scripts` = 0 live; `grep -n "Primaries display-orphan sweep" docs/backlog.md` shows the line struck, not gone; `grep -n '"lead"' package.json` = 0.
- Push only after re-checking HEAD ancestry.

## Out of scope — named so it isn't absorbed

- Restoring any lead surface — the ruling was RETIRE; a future "glance one-liner" is a new entry if anyone wants it, not this HO's business.
- Every other `dashboard_state` key and every other `/api/sync` step (trades, ratings, summarize).
- `lib/cron-health.ts` and the `CRON_ROUTES` stale schedule string (its own entry, rides the next touch there — this HO does not touch that file unless the payload check forces a table finding).
- The `isSettled` cluster (`:78`/`:85`/`:87` — wants the Aug 20 / Sep 3 settle windows first), the bare-tape branch (`:416`), the `.pdc*` excision, the M3 re-arm — none due.
- The method.md dual-write rule Corey has not ruled on — flagged in chat, not written here.
