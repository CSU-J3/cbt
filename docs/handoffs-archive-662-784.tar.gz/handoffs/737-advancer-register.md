# HO 737 — where a top-N advancer reads as a party's primary winner, measured; then Corey's word, then the roster status that carries it

The register line HO 731 filed (`docs/backlog.md`, OPEN LOOPS, *Register: a top-four advancer renders as "Won"*, owner Corey) named the wrong site. `components/RaceRunoffs.tsx:38` does render `status === "winner"` as *Won*, but that component renders **runoff rows only** and a top-four contest is never a runoff, so the label the line describes never reaches a top-N advancer. **The real site is the race roster.** `lib/harvest-challengers.ts:75-82` harvests every non-incumbent `primary_candidates.status = 'winner'` into `race_candidates` with **`status = 'won_primary'`**, and that status is what renders: `RaceCandidates.tsx:14-17` as *Won primary*, `RaceDistrictCard.tsx:79-81` / `RaceDistrictModal.tsx:25` as *primary winner*, and `lib/queries.ts:1920-1926`, `:1962-1968` rank it at rung 0 as *"the party's general-election nominee."* For Alaska's eight advancers (and every top-two advancer in CA and WA) that is a party nomination nobody received.

**This HO is a measurement that halts, then Corey's one word, then — on one of the two words — a small `feat` whose data path is the harvest's own re-derive.** No one-off `UPDATE`: `harvestChallengers` **DELETEs and re-inserts** its rows on every run (`:68-82`, the `HARVEST_SOURCE` sentinel), so a change to what it writes re-flows on the next scheduled run with zero manual writes to prod.

**The two words:**
- **keep** — a top-N advancer stays `won_primary` and reads *primary winner* / *Won primary*, accepted as courtesy. The line strikes by tombstone with the site corrected and the measured count of rows it applies to.
- **advanced** — a new roster status the harvest writes when the contest's `primary_type` is `top_four` or `top_two`; ranked at rung 0 with `won_primary` and `nominee` (the standing is the same: on the November ballot); labelled *Advanced* / *advanced* in the two registers; treated as nominated by `pac-target-status`. HO 638's precedent is the reason it is a status and not a label: *"a convention nominee never ran in one"* got `nominee` rather than a relabelled `won_primary`, and an advancer never won a party primary.

**No recommendation attached** (the HO 718 form for register lines). The measurement gives Corey the picture; the word is his.

## Ground truth (read at `5f0f3de`; re-derive by content)

- `lib/harvest-challengers.ts`: `runStamp` (`:66`), the DELETE by `source_url = HARVEST_SOURCE` (`:69-72`), the INSERT with the literal `'won_primary'` (`:75-82`) selecting from `HARVEST_FROM_WHERE`, whose JOIN to `primaries` is where `primary_type` is reachable (read the constant). Two callers share one stamp — read which (a cron route and a script, per the comment) and the cron's schedule from `vercel.json`.
- `race_candidates.status TEXT` (`scripts/migrate.ts:158-166`), free vocabulary; values in the tree: `running`, `declared`, `withdrew`, `won_primary`, `nominee` (`RaceCandidates.tsx:14-30`). `statusLabel` there is a `switch` **with a `default:`** — the silent-default site `RaceDistrictCard.tsx:72-78` warns about; a new status must be a `case`. `humanStatus` in the card and modal is a fall-through that renders an unrecognized status verbatim, lowercased register (*running*, *primary winner*), so `advanced` would read *advanced* there with no edit — confirm, don't assume.
- `lib/queries.ts:1920-1926` and `:1962-1968`: two CASE ladders ranking `('won_primary','nominee')` at 0, with the comment *"keep the two CASE ladders in step."* Both change together or neither.
- `lib/pac-target-status.ts:88` `ROSTER_NOMINATED = new Set(["won_primary", "nominee"])` — the roster half of the ladder that decides whether a PAC target is still in the race. `advanced` belongs in that set for the same reason.
- `primaries.primary_type` vocabulary in code: `open` ×27, `top_two` ×3, `top_four` ×3, `jungle` ×1, `closed` ×1 (grep counts, not row counts). **`jungle` is out of scope:** Louisiana's all-party contest is the general with a runoff, a different shape; if the word is *advanced*, `jungle` is named as excluded and measured only.
- Race ids: House at-large `AK-AL-2026` (HO 711, `lib/race-id.ts:4`), Senate `S-AK-2026`. The AK advancers as read at HO 731: House Begich (R, INC), Hill (I), Hafner (D), Williams (D); Senate Peltola (D), D. S. Sullivan (R, INC), Dan Sullivan (R), Leslie (D). Incumbents are on the roster already and are not harvested.
- Estimates: **~10 lines** in the harvest (a CASE in the SELECT), **~6** across the two ladders, **~2** in `statusLabel`, **~1** in `ROSTER_NOMINATED`; harvested `won_primary` rows in top-N contests today **~15–25** (CA top-two is the bulk).

## STEP 0 — measure, then HALT

| # | check | expected | if the work never happened, this reads |
|---|---|---|---|
| 1 | remote / status / pointer / machine | `main` alone at `5f0f3de`; clean; the number the tree gives (**737**, or 736 if the horizon HO has not landed — say which) | anything else stops here |
| 2 | OPEN LOOPS reconcile (HO 735 close read **259 / 272**) | as read | a carried count |
| 3 | quote the register line; `harvest-challengers.ts:75-82` and `HARVEST_FROM_WHERE`; `RaceCandidates.tsx:14-30`; `RaceDistrictCard.tsx:72-81`; `queries.ts:1920-1926`, `:1962-1968`; `pac-target-status.ts:88` | as in ground truth | a moved line |
| 4 | **the rows (read-only):** `SELECT rc.race_id, rc.name, rc.party, rc.status, p.primary_type FROM race_candidates rc JOIN races r ON r.id = rc.race_id JOIN primaries p ON p.race_id = r.id AND p.primary_type IN ('top_four','top_two') WHERE rc.source_url = <HARVEST_SOURCE> AND rc.status = 'won_primary'` — adapt the join to how `HARVEST_FROM_WHERE` actually reaches `primaries` | the AK six (non-incumbents) plus the CA/WA top-two advancers, count stated by `primary_type` | zero rows means the harvest has not run since AK healed (09-15/16) — read its last `cron_runs` row and say so |
| 5 | **the surfaces, on prod or a local production build:** `/race/AK-AL-2026`, `/race/S-AK-2026`, one CA top-two race, and the `/races` district card for each — the label each advancer carries, quoted | *Won primary* on the race page roster, *primary winner* on the card | any surface reading something else is a site this handoff missed |
| 6 | the PAC-target read for any AK or CA advancer who is an IE target (`pac_ie_spending`): `pacTargetStatus` → `active` with `why: winner in …` | `active` — correct standing, the word is the only thing wrong | `unknown` or `lost` on an advancer is a separate defect, filed |
| 7 | `RaceRunoffs`: confirm by reading its caller that only `election_round = 'runoff'` rows reach it | confirmed — the HO 731 line's site was never a top-N site | a top-N row reaching it means the line was right and this handoff is wrong; write what is read |
| 8 | the harvest's callers and schedule; its last run's `cron_runs` row (`started_at`, `status`, `payload` census) | stated, so the re-flow after any `feat` is predicted to the hour | — |
| 9 | the two `default:` sites named at `RaceDistrictCard.tsx:72-78` — what `RaceCandidates.tsx`'s `default` returns for an unknown status today | quoted | this is what *advanced* would render as before the `case` is added |

**HALT with the nine rows and the quoted labels.** Corey's word arrives as a file: **keep** or **advanced**.

## On *keep*: `docs` only

The register line strikes by tombstone with: the site corrected (`RaceRunoffs` never; the harvest's `won_primary` on race cards, yes), the row-4 count by `primary_type`, the row-5 labels as quoted, and Corey's word with its date. Block, pointer advanced, through the ref. OPEN LOOPS reconciled.

## On *advanced*: `feat`, then `docs(skill)` if owed, then `docs`

- **`lib/harvest-challengers.ts`:** the INSERT's literal becomes `CASE WHEN p.primary_type IN ('top_four','top_two') THEN 'advanced' ELSE 'won_primary' END` (aliasing as `HARVEST_FROM_WHERE` requires), with the comment rewritten: why a status and not a label (HO 638), `jungle` excluded and why, the re-derive as the data path. One writer, so one place.
- **`lib/queries.ts`:** both ladders add `'advanced'` to the rung-0 set, the in-step comment kept true. **`components/RaceCandidates.tsx`:** `case "advanced": return "Advanced";` beside `nominee`, with a two-line HO 638-shaped comment. **`components/RaceDistrictCard.tsx` / `RaceDistrictModal.tsx`:** no edit if row 9 confirmed the fall-through renders *advanced*; say so. **`lib/pac-target-status.ts:88`:** `advanced` added to `ROSTER_NOMINATED`, its comment updated.
- **Local proof without prod writes:** the harvest's SELECT (not the INSERT) run read-only against prod with the CASE added, as a `SELECT` that returns what the INSERT *would* write — rows and their new status, pasted; the count must equal row 4's. Build then typecheck. Render the AK race pages locally against prod data: the label still reads *Won primary* until the harvest re-flows, and the paste says so with the row-8 hour.
- **After the FF, on the next scheduled harvest:** row 4's query again — the same rows now `advanced`; `/race/AK-AL-2026` reads *Advanced* on the roster and the card reads *advanced*; ordering unchanged (rung 0); `pacTargetStatus` still `active` for any target. If the run lands after the session, the block names the hour and the read-back opens the next HO. **No manual harvest, no `UPDATE`, no local `/api/sync`.**
- **`docs(skill)`** alone if SKILL names the roster vocabulary or `won_primary` (grep the words, not only the token — the HO 735 lesson); **`docs`**: the register line struck with the word quoted and the sites corrected; the block with the counts, the labels before, the predicted labels after and the re-flow hour; oddities only if surprised.

## Gates

Build and typecheck; the read-only SELECT proof with its count against row 4; captures of the AK race page and card before (this session) and after (the re-flow) at 1440 and 430; `check:design-citations`; numstat with deletions explained. **Every DB command a `SELECT`**, asserted. Bind evidence for the local server.

## Review ref, then FF

Review branch from the start; `docs(skill)` on its own ref if any; the block waits for the read. `HEAD:main` no force, `ls-remote`, delete the refs, `git rev-parse main`, `npm run verify:deploy`. Paste-back per method § Executing a handoff.
