# HO 784: the FF go. It stands. Leg C's 1440 reading is the box's floor, and the bound was wrong, not the build. The FF takes seven commits, then the deploy and one reading on Production

## Rulings on the paste

**At `9784a47`** (read from the branch):
- `getRaterFreshness` is the specified query on the `race-ratings` tag;
- `measure()` subtracts the footer and runs RACE NEWS to its bottom (`components/RaceListView.tsx:367-378`).

**SKILL is approved** (`9784a47`): the four rewrites and the new paragraph are true of the tree, its floor sentence included.

**Leg C at 1440×900: keep the floor, your option (c).** The bound was mine, and it missed `BOX_MIN`, which I read at `:60` and didn't carry into it.
- **The corrected bound:** the page scrolls by `max(0, boxTop + box + line + pad − innerHeight)`, with the box at `max(BOX_MIN, fit)`.
- At 1440×900 that's 543 + 320 + 53 + 16 − 900 = 32, which is what you measured; 2560 reads 0. Leg C stands on it.
- **Why not (a) or (b):** both change mock-767's ruled floor, and neither keeps the line in view in a laptop browser, whose window is ~780px tall (estimate). There HEAD's box already sits at its floor and the page already scrolls; (a) still scrolls the same amount, and (b) would need a floor near 168px, about four rows.

**Note 2, the mock's colours: the build stands.** The cascade bug was mine. v3's rules came earlier in the stylesheet than v1's, at equal specificity, so on `/electoral` and `/race` the mock drew `--text-secondary` names and grey dates.
- The ruling is Corey's words at v2: *"no just this text as of 2026-09-30 · via Ballotpedia"* in the dark orange, and *"keep the ratting site name with the same color associated with it"*. That's what you built, and leg D measured it.
- The next block records that the mock is evidence for placement and text, and that its colours on those two surfaces are the cascade bug.

**Claim 6:** my grep looked for `revalidateTag` and missed `expireTag` (`app/api/sync-race-ratings/route.ts:102`). Your comment and backlog line are right.

**Notes 3 to 6 stand:**
- the spaces outside the hidden dots;
- the general-ballot route-header line;
- the two SKILL sentences;
- the `-- --force` usage.

The dates differ from the mock's 09-30 because AS OF is each rater's newest rating date: Cook 09-29, Inside Elections 09-22, Sabato 09-29. That's the definition working.

## FF

`784-review`'s head (`9784a47`) sits on `main` at `372c433`: a fast-forward of 7 commits. No migration.

Re-run the build and the cheap gates immediately before the push, and name the reading. Then:
- `git push origin <784-review's head>:main`, no force;
- `git ls-remote --heads origin`;
- delete `784-review`, remote and local;
- forward local `main`;
- paste `git rev-parse main`.

If the classifier blocks the push, Corey runs the same command from your checkout.

## The deploy

Run `npm run verify:deploy` **in the foreground**, then read the Production build's cache line.

**`e2e-prod`:**
- read the run Vercel's Production record fires, or dispatch on `main` if none has started a few minutes after READY;
- give the record's time against READY;
- the new smoke test runs against Production here for the first time, so name it in the result.

**No flush.** `getRaterFreshness` is a new cache entry, so its first read is fresh, and no other cached read changed.

**One reading after the deploy,** by plain `curl`, case-insensitive, since the uppercase is CSS:
- Production `/electoral` serves the line with leg A's text: *Ratings · Cook · as of 2026-09-29 · via Ballotpedia · Inside Elections · as of 2026-09-22 · via Ballotpedia · Sabato · as of 2026-09-29 · via Ballotpedia*;
- `/welcome`'s foot reads *ratings as of 2026-09-22 to 2026-09-29*.

Paste once, after `e2e-prod` and the reading. The next HO's roadmap block opens with this go as taken, and records leg C's corrected bound and the mock's cascade note.
