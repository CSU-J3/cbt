# HO 699 — the `/welcome` stats strip: correct under every wrap, not only the one it was drawn for

Fix kind, one CSS commit, one tracked probe, docs. Corey's word on the HO 698 @390 capture: *"fix it"* (2026-09-07, chat, against the capture Code pasted). Not a ledger item; the block records the finding and its origin.

**What it is.** `app/welcome/landing.module.css:80–83`: `.stats` is a flex row with an outer border (`width:max-content; max-width:100%`), and the three `.stat` cells carry dividers as `border-right` with `:last-child{border-right:0}`. The ≤900 block adds `.stats{flex-wrap:wrap}` (`:261`). At 390 the third cell wraps: the second cell, now last on its row, keeps a divider that ends at nothing; the third sits alone on row two at content width; and the container's outer border encloses the space beside it, which reads as an empty bordered cell. The strip was drawn for one arrangement and given permission to wrap without being told how to look when it did.

**The rule this follows (HO 698):** do not pick the breakpoint where the wrap happens, because that is a function of the face's advance widths on the host doing the measuring; make the strip **correct under every wrap outcome**. Dividers come from a 1px `gap` showing the container's background through, so they are right for any row structure; cells `flex: 1 1 auto` so a partial last row stretches to fill instead of leaving an area; nothing depends on how many fit.

**No theme-% change. `/welcome` only. Corey ruled this page's desktop look at HO 670; its phone arrangement was never drawn, so he sees the captures after, as with the 698 CTA.**

## Ground truth at authoring (fresh clone at `1f39942`, HO 698 shipped 2026-09-07)

- Pointer 698, highest HO in commit subjects 698 → 699. Re-derive at session open.
- `landing.module.css:80–81` `.stats{grid-row:1;grid-column:2/4;justify-self:start;margin-bottom:22px;display:flex;border:1px solid var(--border-strong);width:max-content;max-width:100%}`; `:82` `.stat{padding:12px 20px;border-right:1px solid var(--border-strong)}`; `:83` `.stat:last-child{border-right:0}`; `:261` `.stats{flex-wrap:wrap}` inside `@media (max-width:900px)` (`:257`); `:237` and `:301` place the strip in the CTA grid at 1460 and 560 and do not touch its internals. No other rule names `.stat`.
- Markup `app/welcome/page.tsx:288–303`: three `.stat` cells, each `.v` (24px value, `:84`) over `.l`; the second label carries an `<em>` ratio. The banner is transparent over `.page{background:var(--bg-base)}` (`:22`); `--bg-base: #0a0e14`, `--border-strong: #1f2937` (`app/globals.css:4`, `:7`).
- The strip's width at the wrap points is content-sized: values up to six characters at 24px plus 40px padding; the widest cell is the second by its label. At 390 (banner padding 18, content 354) three do not fit and two do, so the shipped arrangement there is 2 + 1 and the arrangement at 360 may be 1 + 1 + 1. The fix is indifferent to which.
- Gate inventory: `e2e/narrow.spec.ts` at 430 (Production reading only, method § Environment as amended at 698); `fit-finish` 1440/2560; the 698 `chrome-shots`-style capture set.

## STEP 0 — enumerate, then proceed (no HALT expected)

| # | check | expected |
|---|---|---|
| 1 | every rule naming `.stats` or `.stat`, with line numbers, at HEAD | the five above; a sixth is a flag |
| 2 | the strip at 1440 before: capture, plus the computed divider geometry (each `border-right` 1px, `--border-strong`) so the after can be compared for identity at desktop | as read |
| 3 | SKILL exposure | the `/welcome` entry describes the CTA grid, not the strip's dividers; expected 0 touches |
| 4 | before-readings of the tiling probe (STEP 2) at 1440 · 900 · 600 · 430 · 390 · 360 | fails at 390 (and 360), passes above; a probe that passes at 390 on `main` is broken and STEP 2 stops |

## STEP 1 — C1, `fix(HO 699)`

`.stats` gains `flex-wrap:wrap; gap:1px; background:var(--border-strong)` (wrap moves here from `:261`, one home; the strip is `max-content` so it never wraps where it fits). `.stat` becomes `padding:12px 20px; background:var(--bg-base); flex:1 1 auto; min-width:0`; `:82`'s `border-right` and `:83` are deleted, the ≤900 `.stats{flex-wrap:wrap}` is deleted. The outer `border` stays. Comment at the rule: the mechanism (dividers are the container showing through the gap, so they are right for any row structure; grow fills a partial row), the 698 rule it follows, the two readings from STEP 0 row 4, and the sentence that a chosen breakpoint would have re-created the dependence.

## STEP 2 — the probe (commit 2, `chore(HO 699)`)

`scripts/diagnostic/stats-tiling-699.ts`, tracked: for `/welcome` at each width above, group the `.stat` boxes by row (`top`), and assert per row **`Σ widths + (n − 1) × 1 = container inner width`** within 1px, and that the rows' heights plus gaps equal the container's inner height — the strip is tiled with no uncovered area, whatever the wrap. It fails on `main` at 390 and passes on C1 at every width; both readings quoted. **Control:** the fatter-face pass from HO 698 (proportional serif, +2px tracking, on the strip's subtree) at 390 and 430 — the tiling assertion must still pass, which is the statement that the fix does not depend on the fonts we ship.

## Gates

`typecheck` 0 · `build` 0 · `check:design-citations` `OK` · **captures of `/welcome` at 1440 (before/after, the strip region identical or the difference named to the pixel: a 1px gap over a 1px `border-right` should be indistinguishable), 900, 600, 430, 390, 360 after** · `narrow` locally at 430 as the prediction, named as one · `fit-finish` unchanged · the probe's before/after at all six widths plus the control · no `pageerror` on `/welcome`. After FF: the Production `e2e-prod` `[narrow welcome]` line quoted, and the 430/390 captures sent to Corey.

## Docs (commit 3)

Roadmap `Also (HO 699)` + pointer: Corey's word and its provenance, the mechanism, the tiling readings, the control, the desktop-identity capture. No backlog line to strike; the block says the finding came off the 698 @390 capture and was fixed on the owner's word rather than filed. SKILL untouched unless row 3 says otherwise. Oddities: none expected.

## Review ref, FF

`699-review`, `git ls-remote`, architect read (the captures and the probe readings are the substance), FF, ref deleted, `verify:deploy`, the Production narrow line.

read and follow 699
