# HO 778: FF go. Both routes stand, 26 PASS and 0 FAIL. narrow-preview reads first through a hand-made Preview record, then a docs commit, the FF, the deploy and Louisiana's first prod read

## Rulings on the paste

I read `778-review` at `7bdae36`, all five commits:
- `1b91062`: `resolveHouseTarget` refuses before any row, and `runPrimariesStateTarget` is the House pass with `bypassCache` and nothing else, its row under `?state=XX`;
- `ca7e349`: `runInFlight` takes a `running` row below its own id inside 300s, a yield returns `emptyRun` with `stop: "yielded"` and flushes nothing, and `wrapCronRoute` hands `{ runId }`, which the other handlers ignore;
- `463f057`: the SELECT-only seed, the `-778-legs.db` copies, and a preload that refuses every host but Ballotpedia's saved pages;
- `3a43ab7`: the WATCH's (a) and (c), the lock line struck, and the rulings line as written. The reconcile reads 265/345 here too, control 0.

**The legs stand,** K and L red on HEAD and green on the tree.

**SKILL is approved** (`7bdae36`): both sentences verbatim, and both ride-alongs are true of the tree (`yielded` in the stop list, `handler({ runId })`).

**HO 750's leg 6 needs nothing.** Legs are records, not gates, and the route still passes no flush of its own.

**narrow-preview takes your option 2,** below, and Corey checks the integration (the new line).

## Before the FF, on `778-review`

**narrow-preview, through a hand-made Preview record:**
- one GitHub deployment for `7bdae36`'s full SHA: `environment` `Preview`, `production_environment` false, `auto_merge` false, `required_contexts` empty;
- one `success` status on it: `environment` `Preview`, `environment_url` the Preview's own URL (`dpl_BvBWYyaidXpz4LUvyyMShm8SCjZy`);
- never a `Production` record.

Read the run it fires. Expected: every cell equal to #38189661717's, since this HO changes no page. A cell that differs HALTs with the run.

**One `docs(HO 778)` commit:**
- **A new line** (OPEN LOOPS, newest-first):
  - what: Vercel has created no GitHub deployment since `e04d68d`'s Preview (2026-10-12 00:52:09Z): none for `7a14df1`, Preview or Production, and none for `7bdae36`'s Preview, though each built READY. `smoke` and `narrow-preview` both fire on `deployment_status`, so neither ran on its own: HO 777's FF smoke was dispatched (#38291731924), and HO 778's narrow-preview fired on a hand-made record;
  - *Owner:* Corey/Code. Corey checks the Vercel app's installation on `CSU-J3/cbt` in GitHub (not suspended, no pending permission request) and the project's Git connection in Vercel; Code reads the next push;
  - *Close:* a push whose Preview and Production each get a `vercel[bot]` deployment and fire their jobs untouched;
  - *Reads if never done:* every FF dispatches its smoke and every review ref makes its Preview's record by hand, and a deploy that breaks prod waits for the 15:00Z daily run.
- **The block ships true:** its *Five commits* line becomes six, and it gains narrow-preview's reading, how it fired, and the new line.
- **Reconcile,** the control at 0.

Build, then the cheap gates, before the push. Push with no force.

## FF

`778-review`'s head will sit on `main` at `7a14df1`, a fast-forward of 6 commits. No migration.

Re-run the build and the cheap gates immediately before the push, and name the reading. Then:
- `git push origin <778-review's head>:main`, no force;
- `git ls-remote --heads origin`;
- delete `778-review`, remote and local;
- forward local `main`;
- paste `git rev-parse main`.

If the classifier blocks the push, Corey runs the same command from your checkout.

## The deploy

Run `npm run verify:deploy` **in the foreground**, then read the Production build's cache line.

**`e2e-prod`:** dispatch it on `main` as HO 777's FF did, and read `smoke`. If a `deployment_status` run for the head has started by the time `verify:deploy` matches, read that one instead and say so.

**Louisiana's first prod read,** which closes the Louisiana line:
- one authorized `POST /api/cron/primaries?state=LA` on Production, clear of :15-:35 of an even UTC hour and of 00:00-00:10 and 12:00-12:10 UTC;
- before it, the six `house-LA-0N-2026-open` rows (roster, dates, type);
- its `cron_runs` row: route `/api/cron/primaries?state=LA`, `success`, unit `house-target`, attempted 6, parsedOk 6, `fetchFailures` and `settledSkipped` empty;
- after it, the six rows, with any difference from before named against the page. A difference is the page's since the cursor's last LA pass, not the route's.

Anything else (a fetch failure, parsedOk under 6, an error row) is a finding, not a HALT: read the row, don't re-send, and the line stays open.

**The lock's prod reading:** the first `20 */2` general-ballot tick after the deploy, if it closes before you paste: `success`, reading, not yielded. If it hasn't closed, the next HO's STEP 0 reads it.

**No flush.** The six rows reach the pages at the 12:30Z harvest, and before Nov 3 they should equal what's there.

Paste once, after `e2e-prod` and the Louisiana read. The next HO's roadmap block opens with this go as taken, and its docs strike the Louisiana line with this read and unblock the WATCH's (c).
