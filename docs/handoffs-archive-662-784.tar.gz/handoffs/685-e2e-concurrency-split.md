# HO 685 — the alarm's blind window: no skipped run may cancel a working one

Code kind. Closes the promoted concurrency finding: `e2e-prod.yml`'s single global group with `cancel-in-progress: true` lets **any** `deployment_status` event — including a Preview deploy from an ordinary review-ref push, whose job the `if` then SKIPS — cancel an in-flight crawl, because **concurrency is evaluated before the job `if`**. Demonstrated live at HO 683 (dispatch `33673317612` cancelled 47s in by `33673395814`, a Preview event, job skipped; re-dispatched clean as `33673524519`). The HO 683 overflow alarm arms only on `schedule` and `workflow_dispatch`, so a cancelled armed run files nothing and is indistinguishable from a quiet day — the alarm's only tractable blind window, and this HO closes it.

The fix is the **group key, not the cancel flag**: key the group on the same discriminators the job `if` reads, so every skipped class only ever collides with itself and no skipped run shares a group with a working one. Production-success bursts (the documented 5-in-a-minute case) still collapse — the original purpose, preserved byte-for-byte within their group.

```yaml
concurrency:
  group: e2e-prod-${{ github.event_name }}-${{ github.event.deployment_status.environment || 'na' }}-${{ github.event.deployment_status.state || 'na' }}
  cancel-in-progress: true
```

`schedule` and `workflow_dispatch` carry no `deployment_status` object, so they resolve to constant singleton groups (`…-schedule-na-na`, `…-workflow_dispatch-na-na`). Per-event alone was weighed and rejected: it closes the alarm window but leaves a skipped Preview run able to cancel a working Production crawl inside a shared deploy group — same mechanism, narrower victim.

## Ground truth at authoring

- Clone at `838dd5c` (HO 684), pointer 684, number `max(684, 684) + 1 = 685`. Re-derive at session open.
- Concurrency block: `.github/workflows/e2e-prod.yml:29-33` (`group: e2e-prod`, `cancel-in-progress: true`, comment states the deploy-burst rationale and nothing about the before-`if` evaluation).
- Job `if`: `:40-43` — gates `deployment_status` to `state == 'success' && environment == 'Production'`; schedule/dispatch fall through. **These are exactly the proposed group-key discriminators**, which is the design's whole argument: the group partitions along the same line the skip decision does.
- The promoted backlog entry (the HO 504 concurrency WATCH, around `:454` at `838dd5c` — line numbers drift, re-derive) carries the incident, both run IDs, the mechanism, and names this fix shape as the one to weigh first. The HO 683 alarm tombstone entry carries the cancellation as **accepted limit (1)** and says "the fix rides [the WATCH], not here" — limit (1) closes with this HO; limit (2), the 24h worst-case latency of a once-daily schedule, remains and is restated as the sole survivor.
- SKILL `:2538` (the CI-wiring bullet) describes the three triggers and says nothing about concurrency; `:2539-2543` is the alarm passage and does not carry the limit. The concurrency contract sentence lands at `:2538` — SKILL edit, self-mod guard.
- GitHub API was rate-limited from the authoring box, so every incident figure above is the backlog's claim re-verified below, not this session's read.
- Carried from the HO 684 close, riding this docs commit: the fit-finish `BASE_URL` / `playwright.config.ts` `baseURL` divergent-defaults FILED line, and the method § Gates sibling sentence (both specified in STEP 4).

## STEP 0 — enumerate, then HALT

Closure table: candidate · verdict · evidence · destination. Nothing edited before the HALT.

| # | candidate | expected |
|---|---|---|
| 1 | the incident, re-verified | `gh run view 33673317612` and `33673395814` — event, conclusion (`cancelled` / the canceller's job skipped), created/updated timestamps showing the 47s overlap. Quote, don't summarize |
| 2 | the 72h sweep | `gh run list --workflow e2e-prod.yml` over the last 72h: every `cancelled` conclusion attributed (what cancelled it, was it armed). **Specifically: did the 15:00 UTC schedule slot on 2026-09-01 or 09-02 get clipped** — Corey reports a live fire "yesterday" in a sharper form than filed; name the run that is |
| 3 | discriminator census | the actual `environment` / `state` values Vercel has emitted to this repo — read the event payloads off recent `deployment_status` runs (`gh run view --json event,displayTitle` or the API), not assumed from the `if` comment. Every observed pair maps to a group; state which groups are working (`Production`+`success`) and which are skip-only |
| 4 | expression semantics | confirm `github.event.deployment_status.environment` renders empty (→ `na`) on schedule/dispatch — read the resolved group name off a run rather than trusting the docs (the run's concurrency group is visible via `gh run view --json` / the UI) |
| 5 | group-name collisions | grep `.github/workflows/` for any other `e2e-prod` group usage (pre-read: none; `ci.yml`'s group is its own) |
| 6 | SKILL placement | `:2538` gains one sentence: concurrency is per-event-class since HO 685, so a skipped run can never cancel a working crawl; the before-`if` evaluation named as the reason the key mirrors the `if` |
| 7 | backlog lines at HEAD | the promoted concurrency entry and the HO 683 alarm tombstone's limit (1) — line numbers for the strike/annotation |
| 8 | `:50` denominator adds | enumerate the full crawls this HO will add (STEP 2 dispatch, the FF's own `deployment_status` run, the post-FF collision dispatch, the next scheduled run) so the pageErr WATCH's denominator stays honest |

**HALT. Corey rules on the table.**

## STEP 1 — implement (one code commit)

The group-key change plus a rewritten comment block: keep the deploy-burst rationale, add the before-`if` rule with the incident IDs, and state the partition-mirrors-the-`if` design so a future editor changes both together or neither. No other file. YAML has no typecheck; per the HO 683 precedent the gate is `actionlint` if present, else the first dispatch.

**Sequencing constraint, stated so it isn't discovered mid-flight:** until the FF, `deployment_status` runs execute **main's old yaml** (old group `e2e-prod`) while branch dispatches execute the branch's new yaml (new groups) — disjoint by transition, not by design. So a branch-phase collision test passes trivially and proves nothing about the end state. **Push the review ref before dispatching anything**, and treat every pre-FF green as yaml-validity evidence only.

## STEP 2 — pre-FF proof (validity only)

1. Push `refs/heads/685-review`; the push's own Preview event fires a run under **old** yaml — expected, harmless, note its conclusion.
2. One `workflow_dispatch` **on the 685-review ref**: green crawl, and the resolved group name read off the run (`…-workflow_dispatch-na-na`) — row 4's evidence. This is one `:50` denominator add.
3. State plainly in the paste that the authoritative collision proof is deferred to STEP 5.5 and why.

## STEP 3 — SKILL (own commit, self-mod guard)

Row 6's sentence at `:2538`. Diff delivered as a gitignored file with the instruction to attach to chat; `main` does not move past it unapproved.

## STEP 4 — docs (one commit)

- **Backlog:** strike the promoted concurrency entry with the fix, the incident quotes from rows 1–2, and the group-key rationale; annotate the HO 683 alarm tombstone — limit (1) CLOSED (HO 685), limit (2) the sole survivor. **New FILED line (HO 684 carry):** `fit-finish.spec.ts` defaults `BASE_URL` to localhost while `playwright.config.ts` defaults `baseURL` to prod, so a prod-pointed run without the env var sets its gate cookie on one origin and navigates to the other — bounced to `/welcome`, a false red indistinguishable at the locator level from BotID or a regression; demonstrated at the HO 684 STEP 5 first prod run, discriminated there by raw fetch. Owner Code; close = one default, or the spec reads the config's `baseURL`.
- **Method § Gates**, one sentence beside the tautology clause (HO 684 carry, written as the sibling it is, not the instance it almost is): *a count invariant whose two sides derive from one upstream gate is blind to upstream staleness — HO 684's `promised = shown` would have read green over chips silently absent had the Data Cache served the old query shape, both sides degrading together; the authoritative read was the served content, not the count.*
- **Roadmap** `Also (HO 685)`, pointer → 685. **Oddities:** one short entry for the platform semantics — *concurrency is evaluated before the job `if`, so a run that does no work cancels the run doing the work* — cross-referencing the backlog strike for the figures, or folded into the strike if Corey judges it a double-carry; flag the choice at the HALT.

## STEP 5 — review ref, FF

`git ls-remote` confirm, paste the sha and `git log --oneline 838dd5c..HEAD` (code · SKILL · docs). On approval: fast-forward, delete the ref. The FF's own Production deploy fires the **first working-group run under new yaml** — quote its resolved group (`…-deployment_status-Production-success`) and conclusion.

## STEP 5.5 — post-FF proof (the gate that can fail)

1. **The collision, end-state:** start a `workflow_dispatch` on `main`; while it crawls, push one empty commit to a scratch branch (`685-scratch`) → Vercel Preview → `deployment_status` run under new yaml → its group is skip-only. **The dispatch must complete green, uncancelled**, with its armed overflow/chips lines quoted; the Preview run shows `skipped` in its own group. Quote both conclusions and both resolved group names. Delete the scratch branch. (Pre-fix, this exact shape is the incident — the red reading already on the record — so the pair is a genuine before/after on one mechanism.)
2. **Burst collapse, by construction:** row 3's census showing `Production`+`success` events carry identical group-key inputs → same group, `cancel-in-progress` semantics unchanged within it. If the FF chain organically produces a same-group cancellation, quote it as the live confirmation; if not, say the census is the reading and what its zero means.
3. **The first protected daily:** the next `schedule` run's conclusion + armed line, quoted when it lands (may trail the paste by up to a day — deliver as a follow-up line, the HO 683 precedent).

## Paste-back

STEP 0 table at the HALT (rows 1–4 quoted, not summarized). After STEP 2: the dispatch's group name and conclusion. SKILL diff attached for approval. After STEP 5/5.5: the ls-remote line, the FF run's group + conclusion, the collision pair, and the trailing schedule line when it exists.
