# HO 715 — FF go (architect, 2026-09-12)

**Owner verdict, verbatim: "send it"** — Corey, CBT maintenance chat, 2026-09-12, on the architect's read of `715-review` at `b0e1cf5` off the remote: two commits, `docs(skill)` alone (1+/0−) and `docs` (probes file 243+, oddities 24+, roadmap 12+, method 1+, backlog 1+, all 0 deletions); `57b71b8` is an ancestor, so the move is a clean fast-forward. No code. `check:design-citations` OK on 1,046 files is the only gate that applies and was run. The Senate-lag clause of the ruling was corrected on the ref before landing (the 131-day median is mostly voice-vote reports; Appropriations reports the same day), and the block records the correction.

**What this FF is.** A docs-only landing that gives the committee-votes probe a tracked home (`docs/probes/`, with its one-line authority in `method.md`), a SKILL entry shaped for a builder, three oddities a future fetcher would otherwise meet in its first hour, and a decision line with Corey's name and three letters on it.

## 1. The move

- `git ls-remote --heads origin` immediately before: `main` at `57b71b8`, `715-review` at `b0e1cf5`. Anything else, stop and paste.
- On `main`, the cleanup door: `git merge --ff-only b0e1cf5`; `git rev-parse main` must print `b0e1cf5`. `git push origin main`, no force. `git push origin --delete 715-review`. Then `git ls-remote --heads origin` and `git ls-remote --tags origin` (three tags).
- Each state-changing command on its own line, stderr never suppressed. The commit list is `git log --oneline 57b71b8..main` off the pushed branch.

## 2. The readings — the docs-only set

- `npm run verify:deploy` until the served SHA is `b0e1cf5`, five consecutive reads. Docs-only; the served bytes are expected identical to `57b71b8`'s and nothing about the render is claimed.
- The Production `deployment_status` run: id and conclusion, the group echo, wall time, `pageErr=0` across the log; the `home` line's `band=N/failed=0` and the eight HO 716 routes at 390 with `over=0` — both assertions are in force on every run now, and the paste says what they read, with leg 2 (the enacted segment's chips present) read once beside them so the 716 green is not the empty kind.
- `ci.yml` is expected to skip (docs-only, `paths-ignore`); `design-citations` conclusion.

## 3. After the FF

Nothing further from this HO. The decision line waits for Corey's letter — **A** build the arc, **B** do not, **C** wire the pointer without the parse — and closes on the letter quoted with its provenance. Nothing else in the tree depends on it.

## 4. Paste

The `ls-remote` line showing `main` at `b0e1cf5`, the ref gone, three tags; `git rev-parse main`; the two-line log; the five served reads; the Production run's id, conclusion, the band line, the eight narrow lines with the leg-2 read beside them; `design-citations` conclusion and the `ci.yml` skip.

read and follow 715-ff-go — the file, not this line
