# HO 776: STEP 0 ruling. The rerun is picked by its date, all eight rows take August 11, and the build resumes

## Rulings on the HALT

The HALT was right: the special box I specified doesn't exist on these pages. Your readings hold, and they change the build in five places.

1. **Your path stands: each party's rerun box is picked by its own results line.** Split the section's boxes the way `parseCandidatesPage` does, take the one box per party whose results line reads *on August 11, 2026*, and parse that box alone, so its marks, shares and person keys are its own. Read the date the way the runoff branch already does (the `results_text` line and `isoFromLongDate` in `lib/primary-candidates-scrape.ts`), not with a new pattern.
2. **The three empty D rows take your (a):** `primary_date` 2026-08-11, `runoff_date` NULL, no roster. The districts' primaries moved to August 11 whether or not a party's was contested, and June 16 belonged to a voided round's runoff, which was canceled. AL-01, 02 and 07 print no D box in either round, and their nominees are on the general ballot, as R2 and R3 read.
3. **Every row's `runoff_date` goes NULL.** The pages say no runoff was scheduled for the reruns, and none is stored.
4. **AL-02-R, AL-06-D and AL-07-R keep their rosters.** The dry run compares each with its picked box (names, marks, shares, person keys). Any difference HALTs, since none is expected.
5. **AL-01-R and AL-06-R take their August boxes' rosters,** with `bioguide_id` NULL until W2.

## The plan, as amended

- **The eight base rows:** `primary_date` 2026-08-11, `runoff_date` NULL, `updated_at` now, and every other column unchanged.
- **Two rosters replaced:**
  - AL-01-R: Carl ✔, Sidwell, Mills and Burger;
  - AL-06-R: Palmer ✔ and Dixon.
- **The other six rosters untouched.**
- **No runoff row and no delete.**
- **HALT** if:
  - the dry run holds anything else;
  - a contested party doesn't have exactly one August 11 box;
  - an uncontested D (AL-01, 02, 07) shows a box after all;
  - one of the three kept rosters differs from its box.

`--write` keeps the backup and the `updated_at` check as written.

## W2, the flush and the readback, as written

W2's expected changes are Palmer on AL-06-R (NULL → `P000609`), and Carl on AL-01-R if his title keys to a member. Anything on a row W1 didn't write HALTs.

## The texts, as amended

**backlog, the merge line's *what it does*:** a House page that prints two first-round boxes for one party has them folded into one roster. This happens to a voided round and its rerun, neither marked special. The parser's dedup folds them, keyed on name and specialness (`lib/primary-candidates-scrape.ts:436`), and then `lib/primaries-sync.ts:1873` takes the party's rows whole. The count is R4's: 2 of 435 saved pages (AL-01 R and AL-06 R), with 0 special boxes.

**oddities:** the heading and first paragraph stay verbatim. After them, from `before.json` and the readings:
- May's marks for AL-01-R and AL-06-R;
- that the store already held August's rosters for AL-02-R, AL-06-D and AL-07-R, under May's dates;
- that the saved pages print no May box for AL-02 or AL-07;
- that AL-01, 02 and 07 have no D box in either round, so those rows carry August 11's date and no roster;
- that the pages never mark the reruns special, and only their results lines carry the date.

**SKILL:** this replaces the HO's paragraph, verbatim:

```text
**A voided round is replaced, not kept (HO 776).** When a state voids a primary and reruns it, the base row (`house-{ST}-{DD}-2026-{party}`) takes the rerun's date, runoff date and roster. `getPrimaryForRace` reads only base rows for a House member (it skips `-special-` ids), and a voided row kept beside the rerun would need every reader taught to skip it, so the voided round goes to `docs/oddities.md`. Alabama's AL-01, 02, 06 and 07 are the case: their May 19 results were voided, and the August 11 reruns chose the nominees (`scripts/repair-al-special-primaries-776.ts`, from HO 747's saved pages). The pages don't mark a rerun special. Its box reads like any primary's, and only its results line's date tells it from the voided round's, so the cursor merges the two: first the parser's dedup, keyed on name and specialness (`lib/primary-candidates-scrape.ts:436`), then the party's roster (`lib/primaries-sync.ts:1873`, filed). A repair picks the rerun by its date once, and the settled freeze keeps it.
```

**The script's header** says the same: the reruns aren't marked special, so it picks them by date.

## Resume

Resume at § 1 and build through to the review push, with the paste as the HO lists it. AL-01's reading keeps its rule: this HO's FF go if that falls after 2026-10-12 02:22Z, and otherwise it carries.
