# HO 710 — FF go (architect, 2026-09-10)

**Owner verdict, verbatim: "SEND IT"** — Corey, CBT maintenance chat, 2026-09-10, on the architect's read of `710-review` at `e714a53` off the remote: seven commits, kinds pure; the delta from the first tip `21ac953` is exactly three files (`app/electoral/page.tsx` 4+/1−, `lib/queries.ts` 5+/1−, `docs/roadmap.md` 1+/1−), zero non-comment code lines among them; the SKILL blob is byte-identical across both tips (`2e86fe7`); `fdce76b` is an ancestor of the tip, so the move is a clean fast-forward. The Preview `narrow-preview` run on the amended tip (`34553131639`, 74 passed) read `electoral-2028` at 430/430 and 390/390 with `landed=/electoral?cycle=2028`. Captures not re-taken for a comment-only amend: correct, and stated.

**What this FF is.** The first render of a cycle the raters have not touched, and the first Production reading of the width gate on `/electoral?cycle=2028` — `e2e-prod.yml` structurally cannot run on a review ref, so the Preview reading above is the prediction and the Production run after the move is the measurement. The data half already happened: the three columns, the WI seed and the revalidate landed against prod before this go, and the live app at `fdce76b` reads none of them.

## 1. The move

- `git ls-remote --heads origin` immediately before: `main` at `fdce76b`, `710-review` at `e714a53`. If either differs, stop and paste.
- Standing on `main`, the cleanup door: `git merge --ff-only e714a53`, then `git rev-parse main` must print `e714a53`. Then `git push origin main`, no force. Then `git push origin --delete 710-review`. Then `git ls-remote --heads origin` and `git ls-remote --tags origin` (three tags: `ho697-clock`, `ho697-prefix-clock`, `ho704-root-suspense`).
- Each state-changing command on its own line, stderr never suppressed. The commit list in the paste is read with `git log --oneline fdce76b..main` off the pushed branch, never assembled from per-commit output.

## 2. The readings

- `npm run verify:deploy` from `main` until the served SHA is `e714a53`, five consecutive reads. This is a real build, not docs: if promotion lags past the timeout, paste the deployment list rather than wait it out (oddities, *Prod can lag the fast-forward*).
- **Served `/electoral?cycle=2028`, read off production, not the local build:** 34 rows; the strip `34 SEATS · SENATE 34 · HOUSE 0 · OPEN 0 · LIKELY 1 · TBD 2`; WI carrying `LIKELY · MAY 2025 ↗` with the ↗ resolving to the stored URL; FL and OH carrying `TBD · 2026 →`, each link checked by **content** (`Florida Senate Seat` / `Ohio Senate Seat` in the hub's `<h1>`), since `/race/S-ZZ-2026` also returns 200; no hero band, board, calendar or list view in the DOM. Every other row untagged.
- **Served bare `/electoral`:** 2026 as before, the toggle present with `2026` current, and the hero band, board and list view all mounted — the byte-identical claim checked once more where it counts.
- The Production `deployment_status` run: id and conclusion, the resolved-group echo, the `smoke` / `odds-off` / `narrow` lines with the `electoral-2028` narrow lines at both widths and `over=0`, and the wall time against the cap. Any `pageErr` hit on `electoral-2028` is pasted per-hit; it is not a FF failure, but it is the first unattended crawl of this route and the channel is the instrument.
- `ci.yml` fires on this push: quote its conclusion.

## 3. After the FF

Nothing else is owed by this HO. Two of its loops are on the calendar rather than on a to-do: the TBD self-clear WATCH fires after the FL/OH specials and the next `sync:members` + `backfill:races`, and the 2028 signal re-curation rides the quarterly seed refresh, with Ballotpedia's 2028 not-running list re-checked each time until it exists. The `sync:members` 119th constant, the backfill retraction pass and the at-large id gap are each their own handoff when Corey calls them.

## 4. Paste

The `ls-remote` line showing `main` at `e714a53`, the ref gone, three tags; `git rev-parse main`; `git log --oneline fdce76b..main` (seven); the five served reads; the served 2028 readings and the bare-`/electoral` reading; the Production run's id, group echo, spec lines and duration; the `ci.yml` conclusion.

read and follow 710-ff-go — the file, not this line
