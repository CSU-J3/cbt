# HO 672 — three closes: measure the flush guard in prod, shut the `tsconfig` `include` exposure, and write the gate entry that generalises both

**Read this file in full before executing anything. Execute in order. HALT conditions are hard stops — report and wait, do not improvise past them. Three HALTs: the STEP 1 prod measurement, the STEP 2 closure table, and the pre-land review ref. Nothing lands on `main` before the last is approved.**

Base: `main` at `dc10f72` (HO 671 landed, verified serving on five consecutive reads) or later. Clone fresh; verify HEAD before starting (`docs/method.md` § Session start). Number derived per method: max(roadmap pointer 671, highest commit-subject HO 671) + 1. Environment: read-only DB access for STEP 1; code edit + `npm run build` then `npm run typecheck` for STEP 2 (build first — the exposure being closed here is precisely why that order exists). Either machine; no WSL/Docker. **Bind check mandated on any local server start.**

Three pieces of work, in this order, because the first can fail and the other two cannot.

---

# STEP 1 — measure the flush guard in production; HALT

HO 671 shipped `if (stats.ok > 0) revalidateTag("bills")` and proved it under `next start` with four readings. **Vercel's Data Cache is a different surface** (HO 312), so local green is not prod green. The guard is currently a falsifiable prediction sitting in production, and it is the open half of the `/welcome` absolute-cost backlog entry's close criterion.

Stored as `project_ho671_flush_guard_prediction`. Restated so this HO is self-contained:

**Prediction.** Before the guard, every `*/10` tick flushed, so every tick produced a step in the rows-read slope for the next visitor of any bills-tagged surface. After it, only writing ticks (~2/day, from 4 in 300 ticks over 49.8h) plus `/api/sync`'s 4 should — **~6 steps/day, not ~148**, with long flat stretches between them.

## What to read

Two independent series over the **same window**, which must start after `dc10f72` went live (deploy confirmed at the HO 671 close):

1. **`cron_runs`** — every summarize tick in the window, with its `payload.summarized` / `ok`, classified writing vs idle vs lock-skipped. This is the *cause* series.
2. **Turso rows-read** — the account's own rows-read metric across the same window, at whatever granularity the platform exposes. This is the *effect* series.

## How to read it honestly — this is the whole gate

- **Controls first.** The window must contain **at least one writing tick**, or the measurement cannot distinguish "the guard works" from "nothing happened at all." If the window holds zero writing ticks, say so and either widen the window or state that the prediction is untested in the positive direction — do not report a flat slope as confirmation.
- **`/welcome` and every other bills-tagged surface is only stepped by a *visitor*.** A flush with no subsequent visit costs nothing and leaves no step. So an absent step is ambiguous unless traffic is known. Either bound it (a visit of your own after a chosen tick, timestamped) or state the ambiguity — **do not read "flat" as "guarded" when it may be "unvisited."**
- **Other tags flush too.** `sync-votes`, `race-ratings`, `primaries`, the reports catch-up and the trades flush all move the same account-level rows-read number. Attribute steps to `bills` by their timing against `cron_runs`, or say you cannot and give the measurement the confidence it has earned. A step you cannot attribute is not evidence in either direction.

## The two verdicts

- **Closes the entry:** flat across idle ticks, with steps only at writing ticks (and sync's four), at a cadence consistent with ~6/day.
- **Falsifies it in prod:** a step per idle tick. That means Vercel's Data Cache behaves differently from `next start`'s filesystem incremental cache and the guard does not take there — **which is itself the finding**, and a bigger one than the guard. It would be filed immediately and STEP 2 and 3 continue regardless.

**HALT.** Paste both series, the classification, the controls, and the verdict. If the verdict is "cannot yet be determined", say that plainly and name what would determine it — a HALT resolved by an honest "not yet" is a pass, not a failure.

---

# STEP 2 — close the `tsconfig` `include` exposure; closure table; HALT

Three live firings, filed at HO 669 and appended at HO 670 and HO 671. `tsconfig.json` includes `scripts/**/*.ts` with `strict` + `noUncheckedIndexedAccess`, and `exclude` is `["node_modules"]` only, so ~19 untracked probes in `scripts/diagnostic/` are typechecked. The third firing red-lit **`npm run build`**, not only `typecheck`, so "run the build instead" is not a way around it.

**The interesting half, and the thing the fix must address:** HO 670's tree sat red *after* its final gate run, because a probe was written afterwards. Tracked files were clean, so CI was unaffected and nothing could see it. The close criterion is already recorded as **impossible or visible, not merely tolerable** — and the entry itself notes that widening `exclude` trades the false RED for a real blind spot (SKILL `:2332`), so both halves close together.

## STEP 2.0 — enumerate; closure table; HALT

**Controls first** (the standing rule; 13 instrument failures against 0 code failures across HO 664–669, and then three render defects that passed every green gate at HO 670). Table (candidate · verdict · evidence `file:line` · destination) covering at least:

1. **The current state, re-derived:** `tsconfig.json`'s `include` and `exclude` verbatim; the count of tracked vs untracked `.ts` under `scripts/`; which of the untracked ones currently typecheck clean and which do not. A count with a control — name a file that is *excluded* and show the grep proving the pattern would otherwise catch it.
2. **What CI actually runs**, read out of the workflow file, not assumed. If CI typechecks a fresh clone, untracked probes are invisible to it by construction, and the local/CI asymmetry is the whole shape of this bug. State it as measured.
3. **The options, priced.** At minimum these three, each with what it costs and what it blinds:
   - **`exclude` the diagnostics directory.** Cheapest. Blinds local typecheck to real errors in probes — the SKILL `:2332` objection. Does it also blind anything tracked? Answer with the file list.
   - **A second `tsconfig` for scripts**, referenced or standalone, with looser flags. Keeps probes checked at their own standard. Costs a config file and a script.
   - **Track the diagnostics.** Makes local and CI agree by construction and removes the asymmetry entirely, at the cost of committing ~19 scratch probes. Note the house pattern is to leave them untracked — this option asks whether that pattern is worth its cost, and it is a legitimate answer rather than a straw man.
   - Any fourth you find. If the tree suggests one I have not listed, price it too.
4. **Against the close criterion**, per option: does it make a probe's type error **impossible**, or **visible**? An option that merely stops the error reaching the gate is *tolerable*, which the criterion already rejects — say so and rank it last rather than quietly proposing it.
5. **The HO 670 blind spot specifically:** whichever option is recommended, state what would now happen in the HO 670 scenario — gates green, probe written afterwards, error introduced. If the answer is "the same thing, silently", the option does not close the entry.
6. **Out of scope, named:** `strict` and `noUncheckedIndexedAccess` themselves (they are not the defect and are not weakened here); anything under `app/` or `lib/`; the CI workflow unless STEP 2.0.2 shows it is the thing that must change.

**HALT.** Paste the table with a recommendation and the reason it beats the others against the criterion. **Do not implement before approval** — this is a config change that governs every future gate in the project, which is exactly the kind of change that should not be chosen by whoever is holding the keyboard.

## STEP 2.1 — the chore commit (after approval)

`git checkout -b 672-review-local` first; `main` stays at `origin/main` until approval. One commit, one kind:

`chore(HO 672): close the tsconfig scripts-include exposure`

Then, and this is the gate that matters: **reproduce the original failure and show it now behaves as designed.** Write a probe with a deliberate `TS2532` under `noUncheckedIndexedAccess`, leave it untracked, and run both `npm run build` and `npm run typecheck`. Paste both results. Whether the expected outcome is "still red but attributable" or "green and the error surfaced elsewhere" depends on which option was approved — say which was expected before running, then what happened. Remove the probe afterwards and confirm it is gone.

---

# STEP 3 — the `docs/method.md` gate entry

Filed at HO 670 as a visual-inspection gate for render-touching work; widened at the HO 671 close to cover the class. **This is a method change, so it is prose, not machinery** — write it, do not build tooling for it.

The general form: **a gate you cannot fail is not a gate.** Three instances, all from the last two sessions, all worth naming in the entry because each failed differently:

- **HO 670** — every gate green while the layout was wrong three times (a ~300px dead zone under each panel, an empty ODDS third, the reduced-motion mask erasing the first row). Greps and 200s cannot see a layout. **A visual check with no capture is not a check.**
- **HO 671** — `npx tsx -e "…await…" 2>&1 | tail -3` printed only `Node.js v25.5.0`. The tool reported the error in full; the pipeline showed stack frames instead of the message. **Never `tail` a command whose failure mode is a stack trace** — the informative line is the first one.
- **HO 671** — the same one-liner was a *write*, and its failure mode was not "it failed" but "unclear whether it landed." **A write instrument that does not read back is not an instrument.**

## What the entry must contain

Concrete enough to be followed, and to be *failed*:

- **For render-touching work:** a named viewport set, a separate `prefers-reduced-motion` capture (it is a different layout, not a dimmer one), and the captures retained in the paste — not "I looked at it."
- **For any instrument:** what its zero means, and a control that can produce a non-zero on the same instrument. This is already the house practice; the entry is where it stops being folklore.
- **For any write:** read back and print the effect.
- **For any pipeline:** do not truncate from the end of output whose failure mode is a trace.

Add it to method.md's gate list. Keep the three examples, briefly — the entry is more likely to be followed if the reader can see what each rule cost.

**Its own instrument can fail, and say so in the entry:** if the step is written and the next render-touching HO's paste carries no capture, the step is decoration and the entry reopens. That criterion was in the HO 670 filing; keep it.

---

# STEP 4 — docs commit (`docs: HO 672 — …`)

- **`docs/backlog.md`** — strike the `tsconfig` entry (**never delete struck text**) and the method.md gate entry, each with its close criterion answered. Amend the `/welcome` absolute-cost entry in place with STEP 1's verdict: closed if the prod measurement confirms, or left open with the measurement recorded and what it would take. If STEP 1 falsified the guard in prod, that is a **new entry**, opened, not a strike.
- **`docs/roadmap.md`** — one `Also (HO 672)` block, append-only, pointer 672: the prod measurement as arithmetic with its controls and its ambiguities stated, the `tsconfig` option chosen and the two it beat, and the gate entry with the three failures that produced it.
- **`docs/oddities.md`** — only if something odd emerged. Nothing odd → no entry, and say so in the roadmap block (the HO 659/660 form).

# STEP 5 — SKILL commit (`docs(skill): HO 672 — …`), self-mod guarded

Its own commit, never riding another doc. Minimal edits per the approved classification. Expect: the `tsconfig`/gate area updated to whatever now holds, and the SKILL `:2332` note reconciled with the option chosen — if the fix widened `exclude`, that note's objection is now a live consequence and must say so rather than sitting as an unanswered warning. **No changelog append** unless client-island membership changed, which it does not here (HO 665 criterion, cutting as at HO 669).

---

# HALT — the review ref

`git push origin HEAD:refs/heads/672-review` (amend via `--force-with-lease` on the ref only; `main` only ever fast-forwards). Paste: the STEP 1 series and verdict, the STEP 2 table deltas and the reproduction result, `git show --stat` of all commits, the backlog numstat with **every deletion explained line by line** (a strike is an edit — `grep -c '^-[^-]'` is not a deletion count, HO 643), and the docs + SKILL diffs.

**Deliver the SKILL diff as a gitignored file AND tell Corey explicitly that he must attach it to the chat** — it has now sat unread on the Windows box for two consecutive HOs, three rounds each time. Writing the file is not delivering it.

Remote claims via `git ls-remote`, never `rev-parse origin/*`. **The SKILL diff needs explicit approval** — the guard is satisfied by reading, not by summarising. After approval: fast-forward `main`, delete the ref, verify with `git ls-remote --heads origin`.

## Verification gates (run before the HALT; outputs in the paste)

- Build ✓ then typecheck ✓, in that order.
- `grep -cE '^\*\*Also \(HO 672' docs/roadmap.md` = 1.
- Struck entries still present in full (strike, not delete).
- The reproduction probe removed; `git status` clean of it.
- Push only after re-checking HEAD ancestry (`git ls-remote --heads origin`).

## Out of scope — named so it is not absorbed

- The non-atomic summarize write pair (`:315`/`:341`) — filed at HO 671, its own HO.
- The `HeaderBar` `IN BETA` + clock across all routes, and the `--font-mono` → Plex Mono swap — both filed at HO 670.
- The `/welcome` tape unification with `components/MarketsTape`.
- `/api/sync`'s unconditional flush — ruled deliberate at HO 671 on the try/catch discriminator. **Do not re-derive it and do not "fix" the asymmetry.**
- `CRON_ROUTES`'s stale primaries schedule string; the `StagePillStrip` legacy-NULL comment; the two stale `stage_changed_at` references under `scripts/` — all ride their own next touches.

---

read and follow 672
