# HO 721 — STEP 0 ruling (architect, 2026-09-13). Eight rows accepted, N = 3 carries through, SKILL edit 2 dropped, selector form accepted. Go.

Row 6 did what the handoff asked it to: the leak line counted the two lists over threshold, and the page renders three. The third (Not Voting · 4) is already a scored candidate at 95px, so marking it is not a widening; it is the same exemption applied to the same class, and M1c counts candidates, not over-threshold rows (the `:336` unit caveat). Nothing here is Corey's.

## 1. N = 3, everywhere

Accepted exactly as listed. The `:14` close is corrected at STEP 0 to **M1 0 · M1c 3**, and the strike note says the filed criterion assumed 2 because the leak line counts over-threshold candidates. Entry (10) units: **3 containers / 3 position groups / 100 member rows, 0 of them scored candidates** (two-child `li`s at 263px, under both rules — quote the 263, not my ~240). (iv″): **M1c 2 + 3 = 5**, site M1 10. DOM floor: **3 × 21 = 63** characters. Registry heading: **ten**, because it counts markings and entry (9) is × 2 and counts once — right reading. Leg B's vote anchor asserts the marked count equals the count of position lists, which on this vote is 3 and on another vote is whatever it renders.

## 2. SKILL edit 2 — dropped

Recommendation taken. My "forced consequence" was wrong by the standard that word has to meet: a forced consequence is a clause whose absence leaves SKILL false once the code lands, and `:1699` says nothing about columns, so nothing in it becomes false. A Query-helpers bullet is also the wrong home for a CSS-and-audit clause. STEP 3 is the `:2009` count alone, **ten (eight `data-viz-row`, two `data-col-flow`)**, one line. The C1 rule's column-flow paragraph and registry (10) carry the rest.

## 3. Selector transport — accepted, and one line in oddities

`ul[class~="columns-[240px]"]` for leg B and for every read of these lists. The escaped form died in a tsx `page.evaluate` because the backslashes did not survive the string, and this will recur for every Tailwind arbitrary-value class the audit ever has to address. One oddities entry, three sentences: the class, the failing form, the working form, and that `[class~=…]` is the audit's selector for bracketed classes from here.

## Amendments to the handoff, collected

- Every "2" and "N" in STEPs 1–2 reads **3**; every "N × 21" reads **63**; (iv″) reads **M1c 5**.
- STEP 3 is one edit, `:2009`.
- STEP 2's oddities entry is now expected (the selector), not conditional.
- Anchors as you re-derived them (`:2003` for the curve bullet, `:656-679`, `:1622-1653`) stand.

Go: STEP 1 from the attribute, leg B in the same commit, then the readings and the curve.
