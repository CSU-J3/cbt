# HO 684 — the badge's referent: NEW/MOVES chips survive the click that acknowledges them, and say what they mean

Code kind. Fixes a user-reported defect on the dashboard races box: the RACES tab shows `MOVES N` / `NEW N` badges, and clicking the tab opens a panel with **zero** markers on it — the badge promises N things and the click destroys the evidence before first paint. The per-card chips (`MOVED · …`, `NEWS`) have existed since HO 272/432, fully styled and mounted, and have been structurally invisible on the primary flow ever since, because the acknowledge stamp and the display predicate share one variable. This HO splits them, and while the chips are finally on screen, makes them carry content: the NEWS chip gains the headline, the MOVED chip gains the actual move (source, from → to).

## Ground truth at authoring

Clone at `960708b` (HO 683 docs), pointer 683, number `max(683, 683) + 1 = 684`. Re-derive at session open.

**The mechanism, cited:**

- `components/RacesBoxTabs.tsx:96-104` — `openTab("races")` stamps `LAST_VIEW_KEY` (`cbt:racesLastView`, `:36`) with `Date.now()` and calls `setLastViewMs(now)` **synchronously in the click handler**.
- `components/RaceMovedIndicator.tsx:25-27` and `RaceNewIndicator.tsx:28-30` — one predicate, `ts > lastViewMs`, drives **both** chip render (`:34`/`:37` return null) and badge registration (the `useEffect` register/unregister).
- Consequence: the state update from the click re-renders the indicators with the new stamp before the panel is painted visible; every chip evaluates false, unmounts, and unregisters. Badge clears (intended) and the panel opens empty of markers (the defect). The only render path left is a move/news revalidating in **while the user already sits on RACES**.
- `components/RaceCard.tsx:334-340` mounts both indicators on every featured card; `app/globals.css:938` (`.rc-moved`, amber) and `:958` (`.rc-new`, `--ticker-closed`) style them. Built, styled, unreachable.
- `e2e/fit-finish.spec.ts:350-374` asserts only that the stamp lands — the one e2e in the area checks the **cause**. HO 670 class: the gates could not see the artifact.
- SKILL `:2262` states the current behavior as the contract ("opening the RACES tab stamps `now`, flipping every indicator false so both badges clear") — so the fix is a SKILL edit too, behind the self-mod guard. `:2264` states "the dashboard's race→news signal is the NEW badge only" — touched by the headline change below.

**Data already in hand (no new fetches for the NEWS chip):**

- `components/CompetitiveRacesStrip.tsx:99` passes `hubs[i]?.news?.[0]?.observedAt` — the same `news[0]` carries `title` / `publisher` / `url` / `obsId` (`lib/queries.ts:2105-2131`, `getRaceNews(incumbent, 3)` fetched in the block's hub prefetch, `CompetitiveRacesBlock.tsx:~113-119`).
- `lib/queries.ts:2014-2039` — `getRecentRaceMoves` returns `{ raceId: lastMoveDate }` only. The from/to/source live in `rating_history` (append-on-change, baseline row per `(race_id, source)` — the query's own comment). Reshaping it is the one query change in this HO.

## The fix, stated before the table

**Split acknowledge from display.** `RacesUpdatesContext` gains `sinceMs: number | null` — what the chips render against. It hydrates equal to the stored stamp; on `openTab("races")` it is **frozen at the value `lastViewMs` held before the restamp**, then `lastViewMs` moves to `now` exactly as today. Registration (→ badges) stays on `lastViewMs`, so the badges clear on open, unchanged, and `fit-finish.spec.ts:350` stays green as written. Chips render against `sinceMs`, so they are visible for the entire visit; a later re-open re-freezes to the previous open's stamp, so each open shows what's new **since the previous open** — same semantic as the badge, one open later. Decided behaviors, so they're rulings rather than accidents: a mid-visit **reload** rehydrates `sinceMs` to the just-written stamp and the chips are gone (reload = new visit, items were acknowledged); the localStorage value stays a single ms epoch, no schema change; `sinceMs` is in-memory only.

**Make the chips say what's new.**

- **NEWS** → `NEWS · <headline>`, one line, inner-span ellipsis so the `NEWS ·` label never truncates. Non-linked glance text — the card is a whole `<Link>` (`RaceCard.tsx:105` comment, the HO 393 constraint), the article link lives on the `/race/[id]` hub, same shape as the PAC SPENDING glance line. Publisher omitted for space.
- **MOVED** → `MOVED · <SOURCE> <from> → <to>` (e.g. `MOVED · SABATO Toss Up → Tilt R`). Today's chip renders `row.consensusRating`, which is the current **consensus**, not the move — when one source moves and the consensus doesn't, the chip echoes an unchanged value and calls it a move. `getRecentRaceMoves` reshapes to return, per race, the **latest** post-baseline move's `{ date, source, to, from }`: baseline exclusion preserved (`observed_at >` the `(race_id, source)` pair's `MIN`), `LAG(rating)` over `(race_id, source ORDER BY observed_at)` for the from-value, latest row per race by `observed_at`. `from` is the baseline rating for a pair's first real move, so it should never be null; render `MOVED · <SOURCE> → <to>` if it somehow is. Return shape stays JSON-plain (the unstable_cache authoring rule). If several sources moved, the latest one shows; the ratings line under the score bar carries all three current values regardless.

**Not built, on the record:** a "what's new" delta strip at the top of the panel was considered and declined — the HO 272/432 architecture already chose per-card chips with the badge as their sum, and this HO completes that design rather than replacing it. A strip is a materially different panel shape; if wanted later, it's its own fork.

## STEP 0 — enumerate, then HALT

Closure table: candidate · verdict · evidence `file:line` · destination. Nothing edited before the HALT.

| # | candidate | expected at HEAD |
|---|---|---|
| 1 | the stamp site + freeze insertion | `RacesBoxTabs.tsx:96-104`; the freeze reads the **current** `lastViewMs` state (may be null pre-hydration — a click before hydration should freeze null, rendering no chips, same as today's hydration guard) before the restamp |
| 2 | context type | `RacesUpdatesContext.tsx:17-24` gains `sinceMs: number \| null`, default null; header comment (`:1-14`) rewritten — it documents the single-stamp contract verbatim |
| 3 | indicator predicate split | both files: render predicate → `sinceMs`, register predicate stays `lastViewMs`; confirm no other consumer of the context exists (`grep -rn RacesUpdatesContext`) |
| 4 | moves query reshape | `lib/queries.ts:2014-2039`; per the EXPLAIN rule, the reshaped query is **probed and timed cold before anything is built on it** — paste the plan and the timing; confirm `rating_history` source-string values (COOK/SABATO/IE display casing) from the table, not assumed |
| 5 | prop plumbing | `CompetitiveRacesBlock` `moves` map → new shape; `CompetitiveRacesStrip.tsx:94-99` passes `move={moves[r.raceId]}` and the news head object (`{observedAt, title}`) instead of the bare timestamp; `RaceCard.tsx:85-100` prop docs updated; `RaceMovedIndicator` drops the `lean` prop |
| 6 | chip CSS | `.rc-new`/`.rc-moved` gain the ellipsis kit on an inner title span (`max-width:100%`, `min-width:0`, `overflow:hidden`, `text-overflow:ellipsis`, `white-space:nowrap`); audit the chip's ancestor chain for the HO 682 signature (grid/flex item at `min-width:auto` over nowrap text) — this HO **adds** nowrap text into the card, so the audit is load-bearing, and M0 + the 1440/2560 fit-finish invariant are the durable gates behind it |
| 7 | every variant branch | the card renders at desktop grid **and** the mobile collapse (RACES inactive is `display:none` on mobile per `RacesBoxTabs.tsx:159-166` comment); per HO 609/619, grep the card/chip CSS for breakpoint branches and name each one the change reaches |
| 8 | e2e | `fit-finish.spec.ts:350` stays green as written; a new assertion in that test (or a sibling): read pre-click badge counts (`.rbx-badge-moves`/`.rbx-badge-new` text, 0 if absent), click RACES, assert visible `.rc-moved` + `.rc-new` count equals the pre-click sum; **log the branch either way** — `chips gate: armed moves=X new=Y` / `chips gate: unarmed (badges 0)` — never a silent skip (the skip-on-empty inversion) |
| 9 | stale comments | `RacesBoxTabs.tsx:28-33` ("Opening RACES marks-viewed → registry clears → badge 0" — still true for the badge, gains the sinceMs sentence), `:107-111`, indicator headers, `RaceCard` prop docs — all ride the code commit |
| 10 | SKILL | `:2262` contract rewrite (badge clears on open; chips persist against the pre-open stamp; the split named) and `:2264` "NEW badge **only**" clause (→ badge + one-line headline glance; content still on the hub). Own commit behind the self-mod guard |

**HALT. Corey rules on the table.** The two content choices — headline on NEWS, source from→to on MOVED — are strikeable here for a minimal mechanism-only fix; rows 4–5 shrink accordingly.

## STEP 1 — implement (one code commit)

1. `RacesUpdatesContext`: add `sinceMs`. `RacesBoxTabs`: state for it, hydrate alongside `lastViewMs` (`:58-61`), freeze-then-stamp in `openTab`.
2. Indicators: split the predicates per row 3. `RaceMovedIndicator` renders from the move object; `RaceNewIndicator` renders label + title span.
3. `getRecentRaceMoves` reshape per row 4, probed first. Plumbing per row 5. CSS per row 6.
4. e2e per row 8. `npm run typecheck` clean; `npm run lint` clean.

## STEP 2 — proof

1. **Control at HEAD (the gate that can fail):** run the new e2e assertion against the pre-fix build — fresh context, stamp hydrates 0, so any featured seat that has *ever* moved or has *any* news arms it. Expected red: pre-click badges N>0, post-click chips 0. Paste the reading.
2. **Fixed build:** same run, green — post-click chip count equals the pre-click badge sum. Paste both numbers.
3. **What a zero means, stated up front:** if no featured seat has any move or news history at run time, both readings are 0 and the check is same-as-success — that reading is **UNAVAILABLE, not green**; the armed/unarmed log line is the discriminator. (Today's prod shows MOVES 3 / NEW 6, so this is a named contingency, not an expectation.)
4. **Captures, retained in the paste:** RACES panel open with chips in frame at **1440 / 2560 / 430**, plus a separate **prefers-reduced-motion** pass. At 430, the capture is of the mobile branch (row 7). Long-headline case included — force or pick a seat whose `news[0].title` overflows, to show the ellipsis holding and no horizontal scroll (the HO 682 class this HO is deliberately poking).
5. **Re-open semantics:** one manual sequence on the fixed build — open RACES (chips visible), to HEARINGS, re-open (chips from the first open gone). One line stating it behaved.

## STEP 3 — SKILL (own commit, self-mod guard)

Row 10's two passages. Deliver the diff as a **gitignored file with an explicit instruction to attach it to chat** — SKILL diffs get their own approval and do not ride the docs commit. `main` does not move past it unapproved.

## STEP 4 — docs (one commit)

- **Roadmap** `Also (HO 684)`, pointer → 684: the mechanism (one variable serving acknowledge and display), the split, the chip content, the control reading from STEP 2.1.
- **Oddities**, one entry: the chips shipped HO 272/432 and were invisible on the primary flow for ~250 HOs because the acknowledge stamp and the display predicate shared a variable — and the only e2e in the area asserted the stamp, i.e. verified the cause. The badge was a count whose referent the click deleted.
- **Backlog** reconciled at close; no strikes expected, FILED lines only for genuine strays.

## STEP 5 — review ref, FF, ship

Push `refs/heads/684-review`, `git ls-remote` confirm, paste the sha and `git log --oneline 960708b..HEAD` (code · SKILL · docs, kinds unmixed). Local `main` holds until approval; on approval fast-forward, delete the ref, `npm run verify:deploy`, served SHA, then the STEP 2 e2e re-run against prod with its armed line quoted.

## Paste-back

STEP 0 table at the HALT (with the query probe reading). After STEP 2: control red, fixed green, both badge/chip numbers, the four captures, the re-open line. SKILL diff attached for approval. After STEP 5: ls-remote line, served SHA, prod armed line.
