# HO 744: 8 s accepted, SKILL approved, Node 24 before the FF, then the first two-leg run and the close

## Rulings on the paste-back

**The 8 s cap is accepted, and it is not a deviation.** The relay said 20 s unless the arithmetic said otherwise, and it did. Checked against the header independently: ~405 round trips at 74 ms is 30 s, and 2 × 8 + 30 = 46 s inside the 55 s race.

**SKILL `af42691`: approved.** Restated from the previous relay. Nothing below moves its sha.

**The legs are accepted as the reading of this change.** Every leg was seen red before green. The control reproduces the failure the change exists to prevent (a green `timeout` at 55,018 ms with nothing written), and the `file:` copy was proven to be the database under test before anything fired. Perturbing a House row so leg a's House write is observable was the right call.

**The flush was not proven, and the run below proves it instead.** A read 7 h after the tick shows `/electoral` current, which the 3600 s backstop explains on its own. A read within two minutes of the Senate leg's POST can only show the SEN move through the route's own `expireTag("race-ratings")`.

**The two TCP connections per hung fetch:** an oddities entry, marked unexplained. No outcome depends on it. Don't chase it.

**The four found in passing: file all four, each its own line, in the close's docs commit.** Nothing is tracked only in chat. Each was read in code, not measured, and its line says so and names the measurement that would test it.

- **committees:** the cursor moves past a bill whose fetch failed, and the strict `>` on the non-unique `update_date` skips the rest of a same-timestamp group at the deadline. Both land on `success` rows. Medium: silent loss on a success row is the HO 503/506/637 shape.
- **sync-votes:** the Senate `MAX(roll_call)` watermark never retries a failed roll call below it. Medium, same shape. The measurement is whether any Senate roll call is missing from `member_votes` today.
- **kalshi:** the route comment says a failed control read keeps the prior blob, and the code writes null over it. Low until someone says which is intended; the close is code and comment agreeing.
- **kalshi and committees:** route headers describing stale schedules. Low, comment-only.

## Before the FF: Node 24, a hard stop

If the Node 24 readings from the previous relay are in, paste them and continue. If not, run them now:

- Leg a with Node 24 as the driver's runtime, so `next start` runs on 24: `error` inside the cap naming the Senate, the House write lands, health unhealthy.
- The body-stall measurement repeated on Node 24: the stalled `res.text()` aborts inside 8 s.

Either one unbounded on 24: stop, no FF. Then re-run the cheap gates immediately before the push and name the reading.

## FF

`744-review` is at `252411f` and `main` at `65c469d`, so this is a fast-forward:

`git push origin 252411f:main`, no force · `git ls-remote --heads origin` · delete `744-review` · forward local `main` and paste `git rev-parse main`.

**Wait for Production to serve `252411f` before the POST** (`npm run verify:deploy`, five consecutive SHA reads). A POST that lands on the old deployment runs House-only code and proves nothing about 744. Paste the Production `e2e-prod` read and smoke.

## The first two-leg run

One `POST /api/sync-race-ratings`, `$CRON_SECRET` by env name. Expected, from the 09-22 dry run:

| | expected |
|---|---|
| House leg | caption 09-22, `upserted 0 · deleted 0`. The 11:00 tick already wrote this widget; anything else means it moved again, so name the moves |
| Senate leg | caption 09-22, `changed 23 · new 0 · unchanged 14 · deleted 68`, every write `rating_date 2026-09-22`, 68 `DEPARTED:` lines at ±3 |
| `race_ratings` | 330 → 262: Senate 105 → 37, House 225 untouched |
| `rating_history` | 705 → 773 |
| `cron_runs` | `success`. Its `elapsed_ms` is the first measured two-leg total, which the route header calls unmeasured until this run: record it |
| `/electoral`, read within two minutes of the POST, delta named | 121 · 35 SEN · 86 HOUSE → 99 · 13 SEN · 86 HOUSE, the same 13 seats as STEP 0. Cartogram state count before and after, naming any state that leaves |

Captures at 1440 with `reducedMotion: "reduce"`: the `/electoral` hero band after the run, and `/race/S-ME-2026` (its IE rating moved since STEP 0). Anything off by more than the widget moving explains: stop and report before any docs.

The next `rating-history` tick (`0 15 * * *`, so Thursday 2026-09-24 15:00 UTC) logs the 23 Senate moves. The 68 departure rows are the sync's own, written today, and the departed pairs are gone from `race_ratings` before that tick looks.

## The close: a docs follow-up on its own ref, SKILL in its own commit

**backlog**

- HO 742 ingest line (`:20`): fix BOTH wrong-date occurrences in place, then strike on #19499 (GET 11:00:40.498Z, deployment at `65c469d`, `success`, `scraped 225`, caption 09-22).
- The Senate seed line: strike on the first two-leg run's payload, with the by-chamber split.
- The `timeout` line: annotate this route's half of the residual. The write term is ~330 sequential Turso round trips per House run, ~405 with the Senate leg's first run. Batching the per-row reads and writes retires it at the source for this route, whatever cron-health decides.
- The redistricting WATCH: TX-09 re-entered the index on 09-23 at IE Likely R. Measured fact only; the hypothesis stays marked as one.
- New WATCH: the first scheduled two-leg run, Wednesday 2026-09-30 11:00 UTC, computed from `0 11 * * 3` with `date -d`. It closes on that `cron_runs` row: GET, `success`, both chambers' stats in the payload. A manual run proves the route, never the schedule (HO 504).
- New: the four lines above.

**roadmap:** the HO 744 block. The date correction names the HO 742 block's three occurrences by content. `:2437` is untouched.

**oddities:** the date entry as decided, and the two-connection entry.

**method:** the one bullet on naming scheduled runs.

**SKILL**, own commit, approval requested in the paste-back: the ratings entry's NOT YET RUN figures (21 upserts, dated 09-15) replaced by the first run's measured ones.

**OPEN LOOPS** reconciled at open and at the FF, control `^- \*\*~~` 0 at both.

Push the close to a review ref and hold its FF for the SKILL approval.

## Paste back

The Node 24 readings; the FF mechanics (`rev-parse`, `ls-remote`, ref deleted); `verify:deploy`; the Production `e2e-prod` read and smoke; the POST response; the `cron_runs` row; the runtime log's `CHANGED:` and `DEPARTED:` lines; the DB counts beside the table's expectations; `/electoral` with the time delta; the captures; the close's `--numstat` (deletions column, not a grep); the SKILL diff; the reconcile; and a last cheap-gate run immediately before the paste, with the reading named.

---

read `744-ff-go`: Node 24 first if it isn't in, then FF, run, and push the close to a review ref
