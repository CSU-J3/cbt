# HO 678 — API-key rotation audit

Read-only. No commits, no env writes, no rotation in this handoff. STEP 0 ends in a HALT with a closure table; the rotation itself, and the one code fix the pre-read turned up, are follow-on handoffs after Corey rules.

## Premise

`CSU-J3/cbt` is a public repository (GitHub API `private: false`, checked 2026-08-31). That sets the rule for the whole audit: any secret value that has ever appeared in any commit is burned, whether or not it matches the value in use today. The audit's job is to find every copy of every secret the app consumes, produce evidence of each copy's exposure and age, and hand back a table Corey can rule on. Verdicts are measured, not asserted (method.md § Gates).

## Ground truth at authoring

- Remote HEAD `4383651` (`docs(skill): HO 677`). Roadmap pointer reads "Notes now run through HO 677" (`docs/roadmap.md:1004`); highest HO in commit subjects is 677. Number is `max(677, 677) + 1 = 678` per method.md § Handoff discipline. Re-derive at session open; if HEAD has moved, renumber and say so.
- Establish the machine first (method.md § Environment). The gitleaks install path differs: `brew install gitleaks` on the MacBook; on the Windows box, `winget install Gitleaks.Gitleaks` or the release binary from `github.com/gitleaks/gitleaks/releases`. Not WSL.
- Local env source of truth is `.env` (backlog `:31`). `.env.production.local` is a `vercel env pull` artifact with blank values and is not evidence of anything.

## Pre-read results to verify

Taken in a fresh clone of `origin/main` at `4383651` on a sandbox holding no `.env`. These are premises for STEP 0, not results. Re-run each on your clone, which may carry refs mine did not (review refs, local branches, stash, reflog).

1. History scan, two instruments, both clean. gitleaks v8.30.1, default rules, `gitleaks git . --log-opts=--all --redact`: 1128 commits scanned, 0 findings. Second instrument, a targeted grep over `git log --all -p` for: assignments to the repo's twelve env names (`CONGRESS_API_KEY GEMINI_API_KEY TURSO_AUTH_TOKEN TURSO_DATABASE_URL CRON_SECRET FMP_API_KEY LDA_API_KEY FEC_API_KEY FRED_API_KEY AUTH_SECRET AUTH_GITHUB_ID AUTH_GITHUB_SECRET`) with a non-placeholder value of 16+ chars; `api_key=` followed by 20+ alnum; JWT shape `eyJ…\.eyJ…`; `AIza[0-9A-Za-z_-]{35}`; GitHub token prefixes (`ghp_ gho_ ghu_ ghs_ ghr_ github_pat_`); `Authorization: Token|Bearer <20+ chars>`; PEM private-key headers; `libsql://…?authToken=`. Result 0 hits. Count gap to reconcile: `git rev-list --all --count` = 1141, gitleaks = 1128, 0 merges, 4 commits with no text diff. Nine unaccounted; the likely cause is gitleaks' default path allowlist (`package-lock.json`) skipping commits that touched only that file. Confirm or correct. A scan whose coverage is asserted is not a scan.
2. Live emission vector, unresolved. Four throw sites put the full fetched URL into an `Error` message, and those URLs carry `api_key=<CONGRESS_API_KEY>`: `lib/bill-rosters-sync.ts:77`, `lib/nominations-sync.ts:125` (URL built by `withKey` at `:431`), `lib/summarize.ts:79` and `:88`. `lib/committees-sync.ts:72,177` and `lib/meetings-sync.ts:49` were written the safe way (status only), so the pattern is inconsistent rather than systemic. Same shape in three tracked diagnostics (`scripts/diagnostic/nominations-source-probe-454.ts:37`, `nominations-detail-probe-458.ts:51`, `amendments-probe-446.ts:36`), dev-run only. `lib/markets.ts:251` puts `FRED_API_KEY` in a URL; its error path was not traced. Several routes surface `err.message` into their JSON response (`app/api/cron/markets/route.ts:84`, `cron/amendments/route.ts:86,109`, `cron/committees/route.ts:91`, `api/sync/route.ts:94`).
3. A four-character prefix of the FEC key (`K0Ue`) sits in tracked `docs/backlog.md:30` and `:603` and `docs/roadmap.md:281`, plus two ignored handoffs (417, 416). Not exploitable on its own; it is the precedent for fragments reaching tracked docs.
4. `.env.example` lacks `FEC_API_KEY`, `LDA_API_KEY`, `FRED_API_KEY`, `AUTH_SECRET`, `AUTH_GITHUB_ID`, `AUTH_GITHUB_SECRET`. Already filed, backlog `:37`, owner Code. Rides the follow-on code HO, not this one.
5. No `NEXT_PUBLIC_` variables exist, and no file reading a secret var carries a `"use client"` directive. Confirm against the built bundle (instrument E), not the source.
6. `REVALIDATE_URL` (`scripts/sync-pac-ie.ts:170`, `scripts/backfill-report-counts.ts:121`) may or may not be secret-bearing. Classify it.

## STEP 0 — inventory and exposure

Produce the closure table, then HALT. Nothing is created, edited, or removed before the HALT.

### 0.1 Enumerate

Build two sets and diff them.

Consumed: every `process.env.<NAME>` under `app/`, `lib/`, `scripts/`, `e2e/`, `auth.ts`, plus the three Auth.js implicit reads (`AUTH_SECRET`, `AUTH_GITHUB_ID`, `AUTH_GITHUB_SECRET`, per the comment at `auth.ts:13-15`). Pre-read count from `grep -rhoE 'process\.env\.[A-Z0-9_]+'`: 35 distinct names. The secret or secret-adjacent ones: `TURSO_AUTH_TOKEN`, `CONGRESS_API_KEY` (also the FEC fallback at `lib/fec.ts:36`), `CRON_SECRET`, `GEMINI_API_KEY`, `FMP_API_KEY`, `LDA_API_KEY`, `FEC_API_KEY`, `FRED_API_KEY`, `REVALIDATE_URL` (classify), and the three auth vars. `TURSO_DATABASE_URL` and `BASE_URL` are configuration, not secrets: list them, don't audit them. The `SEED_*`, `PROBE_*`, `AUDIT_*`, `GATE_*`, `PHANTOM_*` names are diagnostic switches: report the count, skip them.

Held: `vercel env ls` for Production, Preview and Development, recording name, environments and the age column. Then the local `.env`. Then the operator credentials on the box that the loop relies on but the app never reads (Vercel CLI login, the git push credential, Turso CLI login): name them as a separate row group with no inspection. They're Corey's.

Diff: held-but-not-consumed rows are dead secrets (liability with no return). Consumed-but-not-held-in-Production is the `LDA_API_KEY` failure mode from HO 579–581 (backlog `:546`); flag it per environment.

### 0.2 Instruments

Run every instrument against every secret row. Record the instrument, its version where it has one, and the ref set and commit count it ran over.

A. History. gitleaks over all refs with `--redact`, then the targeted grep from pre-read item 1 over `git log --all -p`, plus `git stash list` and `git reflog --all`. Reconcile both commit counts against `git rev-list --all --count` and account for the gap. Any hit on a current value, or on an 8-char prefix of one, is ROTATE NOW regardless of anything else in the row.

B. Tracked tree at HEAD. For each current value compute a sha256 of the value and of its first 8 chars. Scan every tracked file, and `docs/design/*.html`, for both by hash-comparing candidate tokens; never by printing values. Also report whether `K0Ue` still matches the first four characters of the current `FEC_API_KEY`, as a yes/no.

C. Untracked and ignored. `git status --porcelain --untracked-files=all`: an untracked, not-ignored file containing a current value is one `git add` from history; report it as ROTATE RECOMMENDED with its path. Then scan the ignored `docs/handoffs/` for any current value: a hit there means the value was pasted into a chat at some point and a third-party system has a copy. Report the file, not the line.

D. Emission paths. For each secret, trace every route or script that can put its value into a log line, an HTTP response body, or a thrown message. Start from pre-read item 2: for each of the four `lib/` throw sites, follow the caller chain to the route and state whether the message reaches `console.*` (Vercel runtime log), the JSON response, or is swallowed. Do the same for `lib/markets.ts:251`. If runtime logs are reachable this session (HO 581 used `get_runtime_logs`), count non-2xx events on `/api/cron/summarize`, `/api/cron/nominations`, `/api/cron/bill-rosters` and `/api/cron/markets` inside the retention window. A non-zero count on a URL-bearing path is a log copy of the key and moves the row to ROTATE NOW.

E. Client bundle. `next build`, then hash-compare every 8-char prefix against the tokens in `.next/static/**`. Zero is the only pass. A source grep for `NEXT_PUBLIC_` is not the instrument, because it can't see what the bundler inlined.

F. Age. The `vercel env ls` age column per row per environment. For `TURSO_AUTH_TOKEN`, decode the JWT payload from the local `.env` in Node (`Buffer.from(parts[1], "base64url")`, JSON-parse) and print only `iat` and `exp` as ISO dates; a missing `exp` means a non-expiring token. For providers with no local instrument (api.data.gov for Congress and FEC, Google AI Studio, FRED, FMP, Senate LDA, the GitHub OAuth app) leave the age slot as OWNER-SLOT naming the dashboard that would fill it. Do not estimate. A file mtime is not a key age.

G. Scope. From `vercel env ls`, record which environments each secret is present in. HO 581 found the auth vars Production-only, so previews lack them; the converse matters here: a secret present in Preview ships to every review-ref preview build.

### 0.3 Verdict rules

Apply in order; first match wins.

| Verdict | Trigger |
|---|---|
| ROTATE NOW | value or 8-char prefix found in any ref's history, any tracked file, the client bundle, or a runtime log inside retention |
| ROTATE RECOMMENDED | a live emission path exists (D) with no log evidence; or found in an untracked-not-ignored file or in `docs/handoffs/`; or age ≥ 12 months by the best evidence available |
| DELETE | held in Vercel or `.env`, consumed nowhere |
| OWNER-SLOT | no exposure evidence and no age instrument; Corey fills the age from the provider or rules a calendar rotation |
| NO ACTION | none of the above, with age evidence under 12 months |

The 12-month threshold is a proposal, not a repo rule. Corey keeps or strikes it at the HALT.

### 0.4 Paste-back

One table, one row per secret. Columns: name · consumers (`file:line`, first three) · held (Vercel envs / local) · age evidence (with instrument) · A · B · C · D · E · G · verdict · destination (follow-on HO / provider action / delete / none). Under it: the dead-secret list, the diagnostic-switch count, the operator-credential row group, instrument versions and commit counts with the gap accounted for, and the emission-path trace for each of the five URL-bearing sites.

Redaction gate, and it can fail: before pasting, run a literal `grep -F -c '<value>'` for every current secret against the paste-back text and require 0 on every line; report the count line. No value, no prefix, no hash of a value appears in the paste-back. `K0Ue` is the only fragment permitted, because it is already tracked, and only in the yes/no match line.

Values never travel through chat from either side. When a rotation later needs a value moved, it moves by `vercel env add` reading stdin, or by editing `.env` on the box.

**HALT here. Corey rules row by row.**

## STEP 1 — after the ruling: file the ledger

One docs commit, kinds unmixed, through the review-ref route (SKILL, "Review-ref route"), no SKILL edit. Backlog OPEN LOOPS gets one line per ROTATE / DELETE / OWNER-SLOT row with its owner, one line for the emission-path fix naming the four `lib/` sites (owner Code, code HO), and one WATCH line for any OWNER-SLOT ages Corey still has to fetch. Oddities gets one dated entry: a public-repo secret audit needs two history instruments with reconciled commit counts, because the default rule set has no shape for api.data.gov keys (40 alnum, no prefix) and would pass a committed one. Roadmap gets its `Also (HO 678)` block and the pointer moves. No fragment of any secret goes into a ledger line.

## Follow-on, not this handoff

- Code HO: in the four `lib/` throw messages (and the three diagnostics), replace the URL with status plus a key-stripped path, the way `committees-sync.ts:72` already does; refresh `.env.example` per backlog `:37`. Both code kind, diff first, per Corey's standing rule.
- Rotation HO(s), per ruling. Provider ordering is stated when that HO is written. The GitHub OAuth app holds two client secrets at once (add new, deploy, remove old). Turso's `turso db tokens invalidate` kills every token for the database including one just minted, so the order is invalidate → create → `vercel env add` from stdin for each env → `.env` → redeploy → read-back, with a short outage. api.data.gov hands out a new key through the signup form and has no self-serve revoke; the old key stays live until their support disables it (confirm at rotation time). `CRON_SECRET` is set-then-redeploy, since Vercel injects it into cron requests. `AUTH_SECRET` rotation invalidates every session cookie, which is fine for one user.

read and follow 678
