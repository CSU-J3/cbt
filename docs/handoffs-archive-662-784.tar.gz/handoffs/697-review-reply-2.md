# HO 697 — review reply. Not yet: one impure commit, and the block and SKILL still ship the clock in places.

Read on the ref at `8c55c1a`: ancestry clean, both tags on the remote, every touched blob LF, `b1039e3` and `29bd1a6` share no file, the class gate ran interleaved with controls on every leg and read what it should. The code is approved as it stands; nothing below touches a code blob. Three things block the FF, all in history and prose.

## 1. `f6f248d` is not a chore commit

`git show --stat f6f248d`: the four probes **plus** `.claude/skills/cbt/SKILL.md` (10/−), `docs/backlog.md`, `docs/oddities.md`, `docs/roadmap.md`. It carries the pre-split SKILL text (*"HO 697 added the `IN BETA` tag and the live clock to both mastheads"*, *"`WelcomeClock` has THREE render sites"*) and the pre-hold ledger, which `469c34a` and `8c55c1a` then correct on top. So kinds are mixed, a SKILL change lands outside a SKILL-only commit (the self-mod guard has nothing to read), and history records a false SKILL state landing and being fixed one commit later. Same mechanism as the earlier split, most likely: a path checkout from the old commit staged the old docs along with the scripts.

**Rebuild:** `f6f248d` carries the four scripts and nothing else; the SKILL-only commit carries the whole SKILL diff against `main`; the docs commit carries the whole docs diff. **Invariant:** the eleven code and probe blobs are unchanged — `globals.css 1c89a960`, `layout.tsx 45d4094e`, `landing.module.css b7377911`, `page.tsx 148b8065`, `DashboardV2Header.tsx c060248a`, `HeaderBar.tsx b120fb6d`, `WelcomeClock.tsx ce84a15e`, the four scripts `115801ca / 69fee261 / b25a6868 / eedb4175` — quote them from the new tip. Only SKILL and the three docs files change, and only as §2–3 say.

## 2. The block still ships the clock

`docs/roadmap.md:1342` opens *"the two HO 670 rulings reach every route — `IN BETA` and the live clock on both mastheads"*; `:1344` *"the clock follows `LAST SYNC` on both"*; `:1360` *"The clock is MOUNTED, not re-implemented, and now has three render sites."* The hydration section below them says the mount was held. A block that contradicts itself is worse than one that is wrong, because a reader has to pick. The roadmap is mutable until FF: **rewrite the block whole to the shipped state** — the tag reached every route, the font landed, the clock was built and held — with the STEP 0 material kept (placement ruling verbatim, the specimen, the histogram, the two STEP 0 corrections) and the hydration section as written. The pre-hold sentences do not survive as strikethrough; they were never landed text.

## 3. Two clauses in SKILL

The `WelcomeClock` paragraph reads *"…was MEASURED rather than argued, and the answer is "not at n = 3": the honest answer is that it could not be measured this way at all."* Two edits layered; the first clause goes, the second stays. And *"the `CyclingTimestamp` now sitting beside it"* describes the held tree: on the shipped one the clock sits beside nothing, so *the `CyclingTimestamp` it would sit beside on a masthead*. Everything else in the SKILL diff is approved as read: the mono paragraph, the `/welcome` RECORD, the tag paragraph with the ruling and the recommendation declined.

## 4. Then

Rebuild, `--force-with-lease`, `git ls-remote --heads --tags`. Paste: the six SHAs with `--stat` (the chore commit's stat is the proof for §1), the eleven blob hashes, the SKILL diff as a gitignored file, the `design citations` run on the new tip. The class gate does not need re-running: no code blob moves. SKILL and the block are read off the ref; FF go follows.

read and follow 697 — review reply, one impure commit and the block
