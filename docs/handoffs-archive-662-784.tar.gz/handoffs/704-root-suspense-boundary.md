# HO 704 — the `:51` fix: give the hydration replay a boundary to reset at, and prove it with the lever that reproduces the class

Fix kind, one line in the root layout and its comment; SKILL alone; docs. Closes `backlog:51` **only if the gate reads zero**; the entry has been open since 2026-07-29 and its close is *cause plus green*, the cause landed in HO 702, this is the green. Sequenced before HO 703 on Corey's word (*"go 704"*, 2026-09-08); 703 rebases behind it.

**The mechanism this fixes, as confirmed (HO 702, window 00:42–00:53Z on `main`'s unpatched build):** hydration begins while the RSC flight tail is still parsing → `InnerLayoutRouter`'s `use(rsc)` (`node_modules/next/dist/client/components/layout-router.js:276`) suspends on a pending thenable → React replays the suspended unit → **the root has no Suspense boundary to reset the hydration cursor**, so the replayed host fiber claims against a cursor the first attempt already advanced → structural `#418` at site `:7622` on the `<header>` ↔ `div.header-titlebar` seam. Control 0 · t2 10 · t2t1′ 0 of 36, `HYD-BEFORE-TAIL` 25 / 35 / 0, necessary not sufficient.

**The fix, and why it is one line.** React resets hydration state at a Suspense boundary and retries a boundary that suspended during hydration from its own start marker (`resetHydrationState`, `react-dom-client.production.js:2879`; `retryDehydratedSuspenseBoundary`, `:11749`); Next's own `LoadingBoundary` (`layout-router.js:332–353`) renders that boundary **only when a `loading` module exists**, and this app has **no `app/loading.tsx`, no `template.tsx`, and no `<Suspense>` anywhere in `app/` or `components/`** (grep 0). So the page segment's `use(rsc)` has nothing between it and the root. **Candidate (a):** `<Suspense fallback={null}>{children}</Suspense>` inside `<body>` in `app/layout.tsx:128`. Not `app/loading.tsx`: a `loading` boundary is keyed per segment and remounts on navigation, so its fallback shows on every client transition; a layout-level boundary persists across navigations, and a boundary that already shows content keeps showing it when a transition suspends. **Candidate (a) is a hypothesis with a gate, not a fix until the gate reads.**

## Ground truth (re-read in a fresh clone at `bd6621a` = `main`, 2026-09-08, after HO 702's FF; no `704-review` on origin at read time. Re-derive at STEP 0 regardless)

- `app/layout.tsx:113` `<html lang="en" className={…plexSans.variable… plexMono.variable}>`, `:125` `prefBootScript` in `<head>`, **`:128` `<body className="antialiased">{children}</body>`** — the one line. Nothing else wraps `{children}`.
- The pair that is the gate: `scripts/diagnostic/seam-intervene-702.ts`, modes `control` / `t2` / `t2t1` (`:47`, `:52`), `T2_KBPS` default 1500 (`:124`), `t2t1` holds every `_next/static/chunks/**` request until `domcontentloaded` (`applyT1`, `:129–138`), `TIMEOUT` a third state, per-hit `fire-t · hyd-start · last-flight · first-post · dcl · HYD-BEFORE-TAIL | hyd-after-tail`, summary `MODE= hits= FIRES= TIMEOUTS=`. Usage from its header (path corrected at the 702 close).
- The crawl's `mut` channel (`e2e/smoke.spec.ts`, HO 702) prints the same fields per hit on the daily, so the post-FF reading is the same instrument on prod.
- `backlog:51`: live, headline *cause NAMED and CONFIRMED (HO 702), close is cause plus green (HO 704)*. **It was `:50` when HO 700–702 wrote about it; HO 702's typecheck-gap entry now sits above it at `:13`, so every earlier block's `:50` is this line.** `backlog:139` (*The live clock on `HeaderBar` — BUILT and HELD (HO 697)*) is held on the same class and is **not** this HO's; it re-measures after this lands.
- HO 697's finding that `main`'s own rate moves by hour, and HO 702's that `t2` lifts it on demand regardless of hour: the gate below runs under `t2`, so the hour is not a variable in it.

## STEP 0 — enumerate, then proceed (HALT on row 3 only)

| # | check | expected |
|---|---|---|
| 1 | the served HTML of `/`, `/president`, `/members` with the boundary, on a local production build: the `<!--$-->` … `<!--/$-->` markers around the page segment, and whether the segment's content is **inline-complete** inside them or deferred behind a `<template id="B:…">` + `$RC` completion | inline-complete on every route, because the page is rendered synchronously on the server and the boundary only wraps it. **Deferred on any route is a flag, not a HALT:** it means the boundary changed streaming shape, and rows 2 and 4 read what that costs |
| 2 | first-paint and `DOMContentLoaded` before/after on `/` and `/members` (five loads each, medians), and document size delta | within noise; size +~40 bytes |
| 3 | **the gate, dry:** `control → t2 → t2t1` on the **unfixed** build first, one window | `t2` lifts off the floor (≥ 3 fires of 36; HO 702 read 10). **If `t2` reads 0 with `TIMEOUTS=0`, HALT**: the lever is not working in this environment and the fix cannot be measured; the window is recorded and the reason found before anything is built |
| 4 | client-navigation captures on the unfixed build for the after-comparison: `/` → `/bills` → `/members` via the nav row, 1440, three frames each (before click, 150 ms after, settled) | recorded |
| 5 | SKILL exposure | the `:51`-related (`#418`) bullet gains the fix sentence; the `/welcome` and masthead entries unchanged. Expected 1 touch |

## STEP 1 — C1, `fix(HO 704)`

`app/layout.tsx:128` → `<body className="antialiased"><Suspense fallback={null}>{children}</Suspense></body>`, `Suspense` imported from `react`. The comment above it carries the mechanism in three lines with the two React cites and the `layout-router.js` cite, the date, and the sentence that this boundary exists to give a hydration replay a cursor-reset point and for no other reason — so nobody later "cleans it up" as an unused Suspense with a null fallback.

## STEP 2 — the gate, on the fixed build, same window discipline as HO 702

One continuous window, same server procedure (bind-checked port, `.env` sourced, `AUTH_SECRET` present, the served chunk hash verified against the build), **unfixed and fixed builds interleaved**: `control(unfixed) → t2(unfixed) → control(fixed) → t2(fixed) → t2t1(fixed)`. Pre-stated readings:

- **`t2(fixed)` = 0 fires, `TIMEOUTS=0`, while `t2(unfixed)` ≥ 3 in the same window** → the fix holds; both directions measured in one window. Quote all five summary lines and every fire's per-hit line.
- **`t2(fixed)` fires** → candidate (a) does not reach the seam; quote the fires' `mut` lines, and **do not ship**. Candidate (a′) is Next's own boundary, `app/loading.tsx` returning `null`, tested the same way and shipped only with the client-navigation captures showing no fallback flash the transitions rule does not already explain; failing that, the HO lands the two negative readings and candidate (b) opens: a minimal reproduction and the upstream report, after the React 19.2.x and Next 15.5.x changelogs are read for a fix already shipped.
- **`t2(unfixed)` = 0** → the window is dead (row 3 was passed earlier; the hour or the environment moved); the block records it and the window is re-run rather than the fix declared clean against a floor.

**`HYD-BEFORE-TAIL` on `t2(fixed)` must still read high** (HO 702 read 35 of 36): the fix does not remove the race condition, it removes the fire that follows it, and a `t2(fixed)` window with `HYD-BEFORE-TAIL` near 0 has measured the wrong thing (throttle not applied, JS not cached) and is not a pass.

## STEP 3 — the rest of the render gates

`typecheck` 0 · `build` 0 · `check:odds-sites` 0 · `check:design-citations` `OK` · smoke crawl on the fixed build at rest (36 routes, fires and `mut` lines quoted) · **captures on `/`, `/bills`, `/members`, `/welcome` at 1440 and 430, before/after, byte-identical or the difference named** (a null-fallback boundary around already-rendered content must not change a pixel) · the client-navigation frames from row 4 repeated on the fixed build: **no frame shows an empty `<body>`** during the transition (the fallback must never be seen; if a frame shows it, that is a UX regression and the fix does not ship in this shape) · `narrow` locally as the prediction, named as one · `fit-finish` unchanged · no `pageerror` in the capture runs.

## STEP 4 — SKILL (alone), docs

SKILL: one sentence in the `#418` bullet — the boundary, why layout-level and not `loading.tsx`, the window's figures, and that `backlog:51` closed on it (or did not, and why). Provenance after the sentence.

Docs: roadmap block with the window's five summary lines, every fire, the captures' verdict, the client-navigation frames' verdict; **`backlog:51` struck with provenance if and only if STEP 2's first reading held** — *cause: HO 702 · green: HO 704, window <times>, t2(unfixed) N / t2(fixed) 0* — never deleted; the 42-fire history stays as the record it is. If not struck, annotated with the negative reading and the next candidate. `backlog:139` gains one line: re-measure under the fixed build in its own HO (the clock's amplifier arms were measured against a class this HO may have removed). Oddities: none expected.

## Review ref, FF, and the reading that closes it

`704-review`, `git ls-remote`, architect read (the window and the frames are the substance), SKILL slot, FF, ref deleted, `verify:deploy` on five reads. **The green that closes `:51` is the daily prod crawl's fire rate over the following seven days against the dumps since 09-03**, quoted into the block at each daily; the local window is the proof the fix reaches the mechanism, the week is the proof it reaches production. The strike lands now on the window's authority and says the week is owed; if the week fires at the old rate, the strike is reopened with that reading, not deleted.

read and follow 704
