# HO 702 — ruling on Arm B's control (architect, 2026-09-07). The HALT condition asked production for a thing production cannot give; the control passes on the fields that decide the class.

Flagging it rather than reporting a pass was right; the stop condition was mine and it was written as if `fn.name` survives a production build. It does not, and that is inherent to the timing regime the arm exists to preserve. **The HALT is lifted, with the condition restated so it can still fail:** the planted mismatch passes when the widened message names its own **node** (`expected=span`, `found=` the app root `div.flex`, `parent=body`), its **site** (after the slot fix, `2852` or the text site, never `?`), and locates the component to a **body snippet**, below. It did the first three on four of four routes on a single hit; the fourth is one field away.

## 1. One field, timing-neutral: the function body, not the function name

For every function frame in `fiber=`, append `fn.toString().slice(0, 120)` after the mangled name (host frames stay as their tag). Minification mangles identifiers and keeps string literals, so the first 120 characters of a component's body carry its `className` strings, its cookie or storage key, its hook calls — enough for a human to name `Ho702Plant` from `ho702_plant`, and enough to name a real component from `"masthead-clock"` or `"markets-tape"` on a natural fire. **Do not** disable minification, turn on `productionBrowserSourceMaps`, or add `keep_fnames` for the natural read: a bigger chunk moves the race this class lives in, and the control's job is to prove the message names a component **at the same timing** the natural fires have. The snippet costs the message a few hundred bytes and the bundle nothing.

Control re-read: the message must carry `ho702_plant` (or the plant's literal) inside the `n` frame's snippet. If it does, the arm is live; if minification has hoisted the literal out of the function body, say so and try `slice(0, 300)` once before anything else.

## 2. Both defects, recorded as the block's two instrument lines

- **The slot.** Appending the site tag as argument 2 wrote it into the text-flag slot on the six HTML sites, so every structural mismatch read `text` and `site=?`. Fixed to slot 3 (`fiber, void 0, "2852"`), eight sites verified. The control caught it because the plant is a known-structural case; a natural fire could not have.
- **The managed path.** `node_modules` is a webpack managed path validated by package version, so an in-place edit is invisible to an incremental build and the chunk hash stays byte-identical; `rm -rf .next` is the fix and the marker string in the built chunk is the only proof the patch is in it. Without the marker this HO would have read *the patch didn't help*. Goes in the block and in the script's header, so the next diagnostic patch checks its chunk first.

## 3. The natural read, unchanged from the note

Planted control clean with the snippet → the natural fires on the tagged tree and, if it reads nothing in two to four crawls, one `main` worktree at this hour. Every message quoted in full: `fiber=` with snippets, `expected=`, `found=`, `parent=`, `site=`, and beside each the hit's `fire-t`, `dcl`, `first-post-t`. The reading criteria are the note's §2: `found=` a `<script>`, `<template>` or `<div hidden>` where app markup was expected is the parser's tail meeting hydration at the root; app markup is somewhere no one has looked.

## 4. Housekeeping

The stale amplifier server on `:3011` caught by the freshness check is the shape to keep: a server that outlives its build serves the old chunk with a straight face. The two waiters finish on their own; `3010` stays up for the quiet-hit comparison; teardown after the natural read, `node_modules` in the worktree with it.

read and follow 702 — Arm B control ruled, add the body snippet
