# HO 769 + 770: FF go. Both refs read clean, SKILL `12f4228` approved. FF to `12f4228`, check Sabato's origin, POST once, flush the tracker, read prod, then straight into HO 771

## Rulings on the paste

I read `770-review` at `12f4228`, all five commits, and `769-review` at `bf383f2` before that.

**§ 1** does what the STEP 0 and S1 rulings asked:
- `WIRED` and one reader per rater;
- the shared fetch (`newScrapeRun`);
- `parseSabatoChanges`:
  - a table is the chamber's by its heading and its header together;
  - the S1 date rule, with its comment naming table 39;
  - columns found by header text;
  - the floors, the duplicate throw and the non-empty throw;
- the chain check before any write;
- stats per rater;
- the leg's throw after its writes.

**§ 2** is the guard as ruled: `syncLegOk(run, chamber, source?)` and the `date|chamber|source` key.

**SKILL `12f4228`: approved.** I rebuilt SKILL from `140aa77` with the edits as the three rulings give them, the S1 sentence inside edit 2, and compared. It's byte-identical.

**Your deviations are accepted:**
- `race-ratings-shape-742.ts` deleted in § 1's commit, so every commit compiles;
- the route's budget line, 8s for the one fetch, with HO 744's sums kept and marked;
- leg D naming Sabato where the handoff named IE;
- leg B's planted-conflict red and its live read.

**HO 744's second connection, which c1 explained, is a finding,** so it gets filed: HO 771's docs give the HO 744 oddity its answer.

**Sabato's origin stall.** POST as planned, and don't lift the cap: 125s wouldn't have saved it. A stall at 11:00Z on a weekly cron costs a week of ratings, so HO 771 makes the sync daily and a stall costs a day.

## FF

`770-review` at `12f4228` holds HO 769's four commits on `140aa77`, so this is a fast-forward of 9 commits. No migration.

Re-run the cheap gates immediately before the push, and name the reading. Then:
- `git push origin 12f4228e4991222ed6ce2f2a468405395195448f:main`, no force;
- `git ls-remote --heads origin`;
- delete `769-review` and `770-review`;
- forward local `main` and delete the local review branches;
- paste `git rev-parse main`.

If the classifier blocks the push, Corey runs the same command from your checkout.

Then run `npm run verify:deploy` **in the foreground**, and read:
- the Production build's cache line, which should read cold;
- the Production `e2e-prod` run and its smoke.

## The POST

Once Production serves `12f4228`:

1. **Check Sabato's origin.** One plain GET of `SABATO_CHANGES_URL` from your box, with § 1's agent. Paste the status, the ms and `cf-cache-status`.
   - No answer within 8s: wait 15 minutes and try once more.
   - Still none: stop and paste.
2. **POST.** One `POST /api/sync-race-ratings` on Production, with `$CRON_SECRET` by env name.
   - Paste its response and its `cron_runs` row (`SELECT`): `status`, `elapsed_ms` and, per chamber, `stats.raters.sabato` (`scraped`, `upserted`, `changed`, `unchanged`, `deleted`, `conflicts`, `pageAsOf`, `asOf`).
   - Expect `success`: House 16 upserts and 2 departures (CT-05, KS-03), Senate 2 upserts (S-AK, S-SC), and `conflicts` empty in both, as long as the page reads as it has since 10-08.
3. **If it records `error` at the fetch,** POST once more after 15 minutes. A second `error` at the fetch: stop and paste.
4. **Read the writes back,** by `SELECT` after:
   - the changed `sabato` rows, each with its race, rating, `rating_date` and `source_url`;
   - CT-05's and KS-03's departure rows in `rating_history`;
   - the `cook` and `inside_elections` rows' fingerprint, the same before and after.

## The flush

One `POST /api/revalidate?tag=palestine`, with `$CRON_SECRET` by env name. Paste its response.

## The prod reading

Page reads only, on Production, at 1440 and 430, with `reducedMotion: "reduce"`, each one captured:
- **`/electoral`, LIST:**
  - NE-02's Sabato chip reads Likely D, its tooltip *Updated 2026-10-08*;
  - FL-22's reads Toss Up, WI-01's Lean R, PA-07's Lean D;
  - CA-03 carries a Sabato chip, Likely D;
  - CT-05 and KS-03 carry none;
  - S-AK's Sabato chip reads Lean D, dated 2026-10-06.
- **`/electoral`'s MOVED:** the 09-30 rows as before, and none from this POST, since its moves read not fresh back to #21278.
- **`/members/G000606`** (Adelita Grijalva): the Scorecard reads B, rank 9 of 212. **`/members/M001208`** (Lucy McBath): F, rank 191 of 212.
- **`/api/health`:** `/api/sync-race-ratings` healthy.

If anything reads off, stop and paste. Otherwise **don't paste here**. Go straight into HO 771 (`docs/handoffs/771-ratings-daily.md`), and its block opens with this FF's readings.
