HO 768 FF go, amended (architect). Production serves HO 767's stylesheet: both builds of 140aa77 restored 8752512's build cache and emitted the old CSS under its old name, HO 717's oddity on Vercel. Your reading is right; no purge.

1. Corey is doing this in the Vercel dashboard now: VERCEL_FORCE_NO_BUILD_CACHE = 1 for Production and Preview, then Redeploy of the 140aa77 Production deployment with "Use existing Build Cache" unchecked.
2. Poll the stylesheet `/` links every 30s for up to 60 minutes. When its name changes, confirm:
   - the new build's log has no "Restored build cache" line;
   - verify:deploy still reads 140aa77, run in the foreground;
   - the new stylesheet holds `.battlefield .ctl` inside the 700px rule and no `.electoral-band .ctl`.
   Then re-read the 430 band on `/` with the Races tab open, finish the prod reading, and read the new deployment's e2e-prod. If the name doesn't change within 60 minutes, or it changes and still carries the old rule, stop and paste.
3. Then HO 769 as written, with three more docs items:
   - oddities: HO 717's entry ("A production build shipped CSS that omitted a globals.css edit…") gains a paragraph saying it happened on Vercel at HO 768: the Preview and Production builds of 140aa77 restored 8752512's build cache, compiled in ~10s, and linked the old 0757h1anyzt62.css (183,555 bytes, the old rule) while the JS shipped new; a cold redeploy fixed it (give its stylesheet's name and size).
   - method.md § Gates, its own docs commit, verbatim: "- **A CSS change is read in the served stylesheet before any capture is trusted** (HO 717 locally, HO 768 on Vercel). A warm Turbopack build has twice emitted the previous stylesheet under its old name while the build passed, the SHA went live and the markup was new, so the prod reading greps the stylesheet the page links for a token the change adds or removes. Since HO 768 every Vercel build runs cold (`VERCEL_FORCE_NO_BUILD_CACHE=1`, Production and Preview); the read stays, because a cache is a cache."
   - backlog: a WATCH on the next deploy that changes CSS: its build log shows no restored cache, and its stylesheet carries the change. It closes on that reading.
One paste-back at the end of HO 769, covering this FF too.
