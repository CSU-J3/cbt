# HO 679 — redact at the sink, then the sources

Code kind. Closes backlog "Emission-path fix — redact at the SINK first, then the seven sources (HO 678)" and backlog `:37` (`.env.example`). Nothing rotates in this HO; HO 680 rotates both keys once this is serving, because rotating first writes the new key into the next failed run.

## Ground truth at authoring

- Remote `main` `842a705` (HO 678 fix-ups). Roadmap pointer "Notes now run through HO 678"; highest HO in commit subjects 678. Number `max(678, 678) + 1 = 679`. Re-derive at session open.
- Session open per method.md, plus one dated item: the HO 661 per-query ledger glance is due about now. Do it per its backlog line before STEP 0 and report the reading with the closure table.
- Windows box, Git Bash under `!`. Port-bind proof uses `netstat -ano | findstr :3000` (Mac: `lsof -i :3000`).
- Local `.env` points at the production Turso database, so the STEP 2 proof writes to `cron_runs` in production. It writes two rows carrying a fake key, and deletes both, each with a read-back.

## What the fix is

One helper, `lib/redact.ts`, with two functions, applied at three layers.

`redactSecrets(s: string): string`, reading `process.env` at call time (not at module load, so scripts that load `.env` late and the fixture script both work), doing two passes in this order:

1. Pattern pass, regex literals only (method.md § Gates instance 7: never build a regex from a string that had to survive a shell). Remove key-bearing query parameters entirely: `api_key`, `apikey`, `api-key`, `access_token`, `authToken`, `token`, `secret`, case-insensitive, along with their `?`/`&` separator, then repair `?&` → `?` and any trailing `?` or `&`. Replace `Bearer <value>` and `Token <value>` header shapes with `Bearer [REDACTED]` / `Token [REDACTED]`. The parameter is removed, not replaced with a placeholder, so the string carries no `api_key=` at all; that is what makes the ledger's close criterion and HO 680's scrub gate greppable.
2. Value pass. For each of `CONGRESS_API_KEY FEC_API_KEY FRED_API_KEY FMP_API_KEY LDA_API_KEY GEMINI_API_KEY TURSO_AUTH_TOKEN CRON_SECRET AUTH_SECRET AUTH_GITHUB_SECRET`, if the env value exists and is 8+ characters, replace every occurrence with `[REDACTED:<NAME>]`. Unset, empty and short values are skipped, never thrown on. Pattern pass first so a stripped parameter's value never reaches the value pass as a `[REDACTED:...]` token inside a URL.

`fetchError(url: string, status: number, body?: string): Error` returns `new Error(redactSecrets(\`fetch ${url} -> ${status}${body ? ": " + body.slice(0, 300) : ""}\`))`. The eleven sources throw this instead of building their own template.

Layers:

- Row sink. `lib/cron-log.ts` `finishCronRun` is the single writer of `cron_runs.payload` and `cron_runs.error_message` (`:62`). Apply `redactSecrets` to the serialized payload string and to `errorMessage` inside `finishCronRun`. This covers the catch path (`:165`), the success path's `chronicErr` (`:158`), and every handler-level message that rides a success payload (`app/api/sync/route.ts:94`, `cron/committees/route.ts:91`, `cron/markets/route.ts:84`, `health/route.ts:30`), with no change at those four sites.
- Body sink. In `wrapCronRoute`, pass the response body through `JSON.parse(redactSecrets(JSON.stringify(body)))` once, on both return paths, before it is returned. The body is about to be serialized by `NextResponse.json` anyway.
- Sources. The seven `lib/` sites and four diagnostics named in the ledger line throw `fetchError(url, res.status, body)`. The sink does not see these when a script runs locally (`npm run sync` prints to a terminal, and that terminal is a Code transcript), which is why the sources get fixed as well.

Two sites are already safe and are not touched: `lib/summarize.ts:79` (keyless payload URL) and `lib/markets.ts:251` (`keyLen`, no value).

## STEP 0 — enumerate, then HALT

Closure table, columns: candidate · verdict · evidence `file:line` · destination. Nothing is created, edited or removed before the HALT.

| # | candidate class | what to enumerate | expected |
|---|---|---|---|
| 1 | row writers | every `INSERT`/`UPDATE` touching `cron_runs` outside `lib/cron-log.ts` | none; if any, it joins the row sink |
| 2 | body paths | both `return` sites in `wrapCronRoute` | 2 |
| 3 | reaper | `lib/cron-log.ts:97` constant string | NO ACTION |
| 4 | payload-borne messages | `.message` / `String(err)` assignments in `app/api/**/route.ts` | the 4 above, all inside wrapCronRoute callers; NO SOURCE CHANGE |
| 5 | log sinks | `console.(error\|warn\|log)` in `lib/` and `app/api/` whose argument is an error object or message reachable from a keyed fetch | list them; each gets `redactSecrets` at the call site. If more than ~10, HALT with the list for a scope ruling |
| 6 | sources | the 7 `lib/` + 4 `scripts/diagnostic/` sites from the ledger, re-read at HEAD | 11, line numbers confirmed |
| 7 | already safe | `summarize.ts:79`, `markets.ts:251` | DO NOT TOUCH |
| 8 | `.env.example` | names in SKILL § Environment variables ∪ names consumed, minus names present | 7 missing: `FEC_API_KEY LDA_API_KEY FRED_API_KEY AUTH_SECRET AUTH_GITHUB_ID AUTH_GITHUB_SECRET REVALIDATE_URL` |
| 9 | SKILL | § Environment variables block missing names; no redaction convention exists | 6 names + 1 new paragraph |
| 10 | proof vehicle | in `/api/sync`, the first keyed fetch and the first DB write other than `cron_runs` | keyed fetch comes first, so a 403 aborts before data writes; if not, name another wrapCronRoute route where it does |

Also state the fixture list from STEP 2 verbatim in the paste-back so it is ruled before it is coded, and `git status --short` (expect only the pre-existing untracked design mocks).

**HALT. Corey rules on the table, the fixture list, and the vehicle.**

## STEP 1 — implement (one code commit, local, not pushed)

`lib/redact.ts` per "What the fix is". Sink in `finishCronRun` and both body paths. Eleven sources throw `fetchError`. Log sinks from row 5 wrapped. `.env.example` gains the seven names with placeholder values and one-line comments in the file's existing style; keep the existing six lines byte-identical.

`scripts/diagnostic/redact-fixtures-679.ts`, tracked (probes default to tracked; it must typecheck, since `scripts/**` is in `tsconfig` and would fail the Vercel build otherwise). It sets synthetic env values before calling, never reads real ones, and exits 1 on any mismatch, printing the failing fixture. Say what it reads with `lib/redact.ts` stubbed to identity: every fixture fails. That is the gate's failure mode, so it is a gate.

Fixtures (input → expected, byte-exact):

1. `https://api.congress.gov/v3/bill?api_key=SYN123&format=json` → `https://api.congress.gov/v3/bill?format=json`
2. `https://api.congress.gov/v3/bill?format=json&api_key=SYN123` → `https://api.congress.gov/v3/bill?format=json`
3. `https://api.congress.gov/v3/bill?api_key=SYN123` → `https://api.congress.gov/v3/bill`
4. `https://api.stlouisfed.org/fred/series?series_id=DGS10&api_key=SYN123&file_type=json` → same with the `api_key` pair gone and one `&` between the survivors
5. `https://financialmodelingprep.com/api/v3/quote/SPY?apikey=SYN123` → `https://financialmodelingprep.com/api/v3/quote/SPY`
6. `Authorization: Bearer SYN123` → `Authorization: Bearer [REDACTED]`; same for `Token SYN123`
7. with `process.env.CONGRESS_API_KEY = "FIXTURE_CONGRESS_0123456789"`: `body said FIXTURE_CONGRESS_0123456789 twice FIXTURE_CONGRESS_0123456789` → both occurrences become `[REDACTED:CONGRESS_API_KEY]`
8. with `process.env.FEC_API_KEY = ""` and `process.env.LDA_API_KEY = "short"`: an input containing `short` is unchanged, and the call does not throw
9. `fetch https://api.congress.gov/v3/bill/119/hr/1?api_key=SYN123 -> 403: {"error":{"code":"API_KEY_INVALID"}}` → `fetch https://api.congress.gov/v3/bill/119/hr/1 -> 403: {"error":{"code":"API_KEY_INVALID"}}`
10. a string with no URL, no header and no env value → unchanged, byte-identical
11. `fetchError("https://api.congress.gov/v3/bill?api_key=SYN123", 429, "x".repeat(500)).message` → starts with `fetch https://api.congress.gov/v3/bill -> 429: ` and the body part is exactly 300 characters

Then `npm run typecheck` clean, `npm run build` clean, both before any push.

## STEP 2 — proof, with its control

The ledger's close criterion has a control built in: the same forced failure before the fix carries the key, after the fix it does not. Run both. The tracer is a fake key; nothing real is placed on a command line or in a message. `CRON_SECRET` is referenced by name (`set -a; source .env; set +a`, then `-H "Authorization: Bearer $CRON_SECRET"`), per method.md § Environment.

1. Control (pre-fix): `git stash` the STEP 1 changes (or check out `842a705` in a second worktree), start `next dev -p 3000` with `CONGRESS_API_KEY=TRACER679_0123456789abcdef` in the environment, prove the port bind (the PID on 3000 is this process), `curl` the vehicle route. Read back: `SELECT id, status, error_message LIKE '%TRACER679%' AS in_err, payload LIKE '%TRACER679%' AS in_payload FROM cron_runs ORDER BY id DESC LIMIT 1`. Expect `in_err = 1` and `in_payload = 1`; record the `id`. Also record whether the response body carried the tracer (expect yes). If the control does not carry the tracer, STOP: the vehicle is wrong or the mechanism is not what the audit said, and the fix has nothing to prove against.
2. Restore the STEP 1 changes, rebuild the dev server, same tracer, same route. Read back the new row: expect `in_err = 0`, `in_payload = 0`, `error_message` containing the path and `403` and no `api_key=`, response body free of the tracer. Print the redacted `error_message` verbatim; it contains nothing real.
3. Delete both rows by id. Read back: `SELECT COUNT(*) FROM cron_runs WHERE id IN (a, b)` = 0, and `SELECT COUNT(*) FROM cron_runs WHERE error_message LIKE '%TRACER679%' OR payload LIKE '%TRACER679%'` = 0.
4. Baseline for HO 680: `SELECT COUNT(*) FROM cron_runs WHERE error_message LIKE '%api_key=%' OR payload LIKE '%api_key=%'` = 3, and all three `started_at` earlier than today. That count is what HO 680 scrubs to zero.

Kill only the dev server you started, by PID (SKILL, "Process cleanup"), and never while anything else is mid-flow.

## STEP 3 — SKILL commit (alone, never with another doc)

§ Environment variables: add the six missing names to the block in its existing style (`FEC_API_KEY LDA_API_KEY AUTH_SECRET AUTH_GITHUB_ID AUTH_GITHUB_SECRET REVALIDATE_URL`, one comment each, including that the auth trio is Production-only and that LDA is Production + Preview). Add one paragraph, "Redaction sink (HO 679)": any string that can reach a `cron_runs` row, a route response body, or a log line passes through `redactSecrets`; keyed-fetch failures throw `fetchError`; `scripts/diagnostic/redact-fixtures-679.ts` is the gate and must stay green; and the two exceptions (`summarize.ts:79`, `markets.ts:251`) are safe by construction, not by omission. The diff is read on the review ref; that is the self-mod guard, not a bypass.

## STEP 4 — docs commit

Backlog: strike the emission-path line and `:37` (strike, never delete), quoting the STEP 2 readings (control `1/1`, fixed `0/0`, deletions `0`, baseline `3`). Roadmap: `Also (HO 679)` and the pointer moves to 679. Oddities only if something failed a control in this HO.

## STEP 5 — review ref, then ship

`npm run typecheck` clean. Push all commits to `refs/heads/679-review`, confirm with `git ls-remote`, paste the sha and `git log --oneline 842a705..HEAD` (expect three commits: code, SKILL, docs, in that order). I read the ref. On approval: fast-forward `main`, delete the ref, `npm run verify:deploy`, and the ship report's last line is the served SHA. Then one production read-back with no writes: the baseline count from STEP 2.4 is still exactly 3. HO 680 starts from that number.

## Paste-back

STEP 0 table and the HO 661 reading at the HALT. After STEP 2: the four readings, the redacted post-fix `error_message` verbatim, and the two deleted ids. After STEP 5: the ls-remote line, the served SHA, the baseline count. No env value, no prefix, no hash of one appears anywhere in the paste-back; the tracer string is the only key-shaped thing permitted.

read and follow 679
