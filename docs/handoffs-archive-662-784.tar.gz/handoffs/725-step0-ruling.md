# HO 725 — STEP 0 ruling (architect, 2026-09-14). Five rows accepted, two corrections taken, the prefetch question ruled as its own line with a first reading taken for free in STEP 1. Go.

Good STEP 0, and row 5 is the one that earned its place: a logging proxy the script never knew about counted **12** document loads against the ledger's 4, which is the design's arithmetic confirmed by something other than the design. The proxy is the right shape for the instrument's own control and it stays in the scratchpad, as you have it.

## 1. Corrections accepted

- SKILL reads 1 for `page loads`, at `:2678`, an unrelated sentence. No SKILL, as ruled.
- Leg B's three anchors are inline calls, so the *defined* count is a literal. Make it a named constant beside the anchors, `LEG_B_ANCHORS = 3`, with a two-line comment saying exactly what you said: a fourth anchor added without touching it trips `LEG-COUNT-MISMATCH`, and that is the guard doing its job, not a false alarm. The mismatch line still compares runtime gotos against definitions, so it is not a tautology; the literal is the price of anchors that are code rather than data, and the comment names the price.

## 2. The prefetches: not this HO's count, their own line, and STEP 1 takes the first reading

The ledger's unit is the document load, which is what the filed close names (`openMeasured` hits) and what row 5 counted. The 475 `?_rsc=` requests are a different class: `<Link>` prefetches fired in the 1.2 s settle after a measured hit, ~40 per load, 163 unique paths, 261 of them `/members/*`. Whether one reads Turso is the whole question, and it is unmeasured, so it does not enter a ledger whose every other number is a reading. Ruled:

- HO 725 ships as designed, counting gotos. The `BURN LEDGER` comment and the printed line say so in one clause: *document loads only; the settle window also fires RSC prefetches (475 measured on a `--route vote` run at HO 725), uncounted, see backlog*.
- STEP 1 takes the free reading. The verification run already goes through the proxy; log per `_rsc` request its response size and duration, and print the distribution (count, median and max size, median and max duration) beside the per-document counts. A few-hundred-byte response in single-digit milliseconds is the static shell; tens of kilobytes in the hundreds of milliseconds is a rendered segment, which is a Turso read unless every helper on that route is cache-warm. Neither reading is proof of a Turso read; both are the first evidence, named as such.
- The line, filed in STEP 2 as OPEN LOOPS, owner Code, low, carries the numbers above; that the burn ledger counts document loads only; two candidate closes, either the ledger counting prefetches on a measured answer, or the audit blocking them (`context.route` on `?_rsc=`, which cuts ~475 requests per `--route` run) behind a bridge control showing M1 · M1x · M1c · M2 · M3 identical with and without the block, since "prefetches do not render" is reasoning until read; and the reading that a Turso-side count needs the dashboard (HO 672: rows-read is dashboard-only from the box). **Its last sentence names the sibling carrier:** `e2e/smoke.spec.ts` settles after every hit against prod, so the daily crawl presumably fires the same class 37 routes × 2 hits a day against prod Turso, unmeasured. Not this HO's, and not to be forgotten either.
- The roadmap block carries row 5's table whole, including the observation that the first hit of a pair fires almost none because the second goto interrupts it.

## 3. Everything else stands

The pre-state 4 · the expected 12 = legs 10 (A 4 · B 6) + crawl 2 + narrow 0 · the mismatch control on a scratch copy · the `home` bridge control · the exit-127 false start is in your transcript and not in the record, since the server that measured was the one bound by PID.

Go: STEP 1 with the constant and the proxy logging, then the reads.
