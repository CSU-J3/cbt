# HO 681 — one FED CUT in the odds strip

Code kind. The odds strip shows `FED CUT SEP K 2.0% P 0.7%` twice per marquee copy (three times per viewport at 2560, once as an adjacent pair). It is config, not data: `FEDCUT` rolls to the soonest-open FOMC decision and `FEDCUT-SEP` is pinned to `KXFEDDECISION-26SEP`. The pin was added when soonest-open was July so that September could show beside it (`lib/markets.ts:170-172` says so). The July meeting passed, the roller reached September, and the two rows now resolve to the same event with identical values.

## Ground truth at authoring

- Remote `main` `c84c02f` (HO 680), pointer 680, number `681`. Re-derive at session open.
- The header clock cycling CT/PT/ET is by design; nothing about timezones is in scope.
- The September decision is 2026-09-16. After it, the pin would resolve to a settled market anyway; its remaining useful life is two weeks of a duplicated row.

## The fork, ruled by default

Two horizons (this meeting and the next) was the pin's original purpose, and keeping two horizons properly means a second roller ("next-after-next"), which is a feature, not maintenance. Default here is A: delete the pin now, single horizon, and file B (a second roller) as a backlog candidate for Corey to want or strike later. Corey overrides at the HALT if two horizons matter now.

## STEP 0 — enumerate, then HALT

Closure table: candidate · verdict · evidence `file:line` · destination. Nothing edited before the HALT.

| # | candidate | expected at HEAD |
|---|---|---|
| 1 | symbol definitions `FEDCUT-SEP`, `POLY-FEDCUT-SEP` | `lib/markets.ts:153`, `:173`, plus their comments `:149-152`, `:169-172` |
| 2 | dashboard strip config | `components/DashboardV2Header.tsx:51-52` (ODDS_TAPE), `:61` (ODDS_PAIRS), comment `:58-59` |
| 3 | welcome tickers | `app/welcome/page.tsx:71`; confirm whether `/welcome` renders its own strip or reuses the header's |
| 4 | policy hooks | `lib/policy-hooks.ts:30`, and the comment at `:27` that names the JUL/SEP pairing |
| 5 | other readers of the four internal symbols | every `-SEP` string in `lib/ app/ components/ e2e/ scripts/`; the tracked probe `scripts/diagnostic/b2-hover-history-probe-373.ts:37-43` is a string map and stays (it must still typecheck) |
| 6 | DB rows | quotes rows for the two symbols exist and stay; nothing deletes history. Name any reader that iterates all quote symbols and would notice two missing |
| 7 | the discovery function | where `kalshiKind: "cut-sum"` symbols resolve to an event ticker (`lib/markets.ts` ~`:110-130`), and where the Polymarket `polyKind: "fed"` resolves its month; this is where the collision check lands |
| 8 | existing e2e on the tape | any `e2e/*` spec touching the odds strip, so the new assertion joins rather than duplicates |
| 9 | SKILL | whether `FEDCUT-SEP` or the JUL/SEP pairing appears in SKILL; if so, a SKILL commit alone follows the code |
| 10 | MarketsTapeClient comments | `components/MarketsTapeClient.tsx:252`, `:266` describe the month suffix; adjust only if they describe the pin |

**HALT. Corey rules on A vs B and on the table.**

## STEP 1 — implement (one code commit)

1. Delete the two pinned symbol definitions and their comments; delete the two ODDS_TAPE entries, the ODDS_PAIRS row and the `:58-59` comment (the surviving pair keeps `showMonth: true`, so the label still reads `FED CUT SEP` and rolls to `FED CUT OCT` after the 16th); delete the welcome pair; delete the policy-hook entry and rewrite the `:27` comment to describe the roller only.
2. Collision flag at discovery, server side. After every Kalshi symbol in a run resolves to an event ticker, and every Polymarket `fed` symbol to a market id, assert uniqueness per source. On a repeat, do not dedupe and do not throw: add `collisions: [{ symbols: [...], resolved: "<ticker>" }]` to the run's payload (it reaches `cron_runs.payload` through the HO 679 sink, which is where audits read) and `console.warn` the same object. Absent collisions, the field is absent, so the read-back is `payload NOT LIKE '%collisions%'`.
3. e2e assertion in the existing tape spec or a new one: on `/`, count odds items whose text begins `FED CUT`; expect exactly one per marquee copy (state the copy count the DOM actually carries and assert `count === copies`). Same on `/welcome` if it renders its own strip. Say what the assertion reads at `c84c02f` before the change: two per copy. That is the gate's failure mode, so it is a gate.

`npm run typecheck` and `npm run build` clean before anything else.

## STEP 2 — proof

- e2e: the new assertion green on the change, red at `c84c02f` (run it once against a stash or a second worktree, the HO 679 way, and quote both readings).
- Captures, mandatory for render-touching work: `/` and `/welcome` odds strips at 1440 and 2560, plus reduced-motion, each showing `FED CUT SEP` once per copy and the strip's item order intact (`SHUTDOWN · FED CUT · RECESSION`).
- Live read-back after the next markets cron run: the run's `cron_runs.payload` carries no `collisions` field, and the quotes it wrote contain neither `FEDCUT-SEP` nor `POLY-FEDCUT-SEP`. If the cron cadence makes that wait long, trigger `/api/cron/markets` once by name (`Authorization: Bearer $CRON_SECRET`, value by name per method.md § Environment) and read that row.
- Control for the collision flag: in a local run with the two pins temporarily restored (uncommitted, reverted after), the payload carries `collisions` naming both pairs. Quote it. Then confirm the working tree is back to the committed state (`git status --short` shows only the pre-existing design mocks).

## STEP 3 — docs (and SKILL if row 9 says so)

Backlog: one FILED line for B (second FED CUT horizon as a next-after-next roller; owner Corey to want or strike; not a dup fix). Roadmap `Also (HO 681)`, pointer to 681. Oddities only if a control failed. If row 9 found the pin in SKILL, one SKILL commit alone before the docs commit.

## STEP 4 — review ref, FF, ship

Push to `refs/heads/681-review`, `git ls-remote` confirm, paste the sha and `git log --oneline c84c02f..HEAD` (code, then SKILL if any, then docs). Local `main` stays at `c84c02f` until approval (HO 655: branch first, verify by `git rev-parse main`). On approval: fast-forward, delete the ref, `npm run verify:deploy`, served SHA, and one last read: the live `/` strip shows one `FED CUT SEP` per copy.

## Paste-back

STEP 0 table at the HALT. After STEP 2: the two e2e readings, the capture set, the cron read-back, the control payload verbatim. After STEP 4: the ls-remote line and the served SHA.

read and follow 681
