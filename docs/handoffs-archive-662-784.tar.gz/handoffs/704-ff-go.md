# HO 704 — FF go (architect, 2026-09-08)

**Owner verdict, verbatim: "send it"** — Corey, CBT maintenance chat, 2026-09-08, against the architect's read of `704-review` at `b257009` (the amended tip: the three substitutions and nothing else between `fdedf74` and `b257009`, numstat unchanged at 2/1 · 4/2 · 24/0 · 66/0 · 112/0 · 156/0, `0c25018` not an ancestor, the SKILL rewrite still tail-only against `bd6621a`). Interpretation: the SKILL slot is filled, `8870130` approved as read, and `main` fast-forwards to `b257009`.

Build carried rather than re-run is accepted: the three amendments were substitutions inside prose lines of tracked docs already in the scanned tree, with no class-shaped token among them.

## 1. The move

- `git ls-remote --heads origin` immediately before: `main` at `bd6621a`, `704-review` at `b257009`. If either differs, stop and paste.
- From the docs branch: `git push origin HEAD:main`, no force. Then `git push origin --delete 704-review`. Then `git ls-remote --heads origin`.
- Local `main`: the move and its check run as their own commands, never mid-compound, never `2>/dev/null` (SKILL, Review-ref route, both doors). Standing on the docs branch, `git branch -f main b257009`; then `git checkout main` and `git rev-parse main`, which must print `b257009…`.
- The tag `ho704-root-suspense` stays; `git ls-remote --tags origin` shows all three.

## 2. The reading that closes it

`npm run verify:deploy` until the served SHA is `b257009`, then four more reads of `/api/version`, five consecutive. A docs-only deploy, so the preview-built-SHA lag (oddities, HO 540) costs nothing but the SHA still has to read; if it sits on `bd6621a` past the timeout, paste the deployment list rather than wait it out.

## 3. Paste

The `ls-remote` line showing `main = b257009`, the ref gone and the three tags present; `git rev-parse main`; the five served-SHA reads. Nothing else. HO 703 rebases behind this; (b) is the next HO authored, and the daily crawl keeps feeding `backlog:51` as before, since nothing render-touching landed.

read and follow 704 — FF go
