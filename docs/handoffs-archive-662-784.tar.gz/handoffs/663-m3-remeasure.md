# HO 663 — M3 re-measure against the maintained harvest (read-only) + two backlog reconciliation strikes

**Read this file in full before executing anything. Execute in order. HALT conditions are hard stops — report and wait, do not improvise past them. This HO builds NOTHING: it measures, rules, and writes docs.**

Base: `main` at `f83f439` or later. Clone fresh; verify HEAD before starting (concurrent-session rules per `docs/method.md` § Session start). Environment: read-only DB reads + one docs commit — runs on either machine, needs `.env` `TURSO_DATABASE_URL`/`TURSO_AUTH_TOKEN`, no WSL/Docker/browser.

## Context (why now)

The backlog's M3 entry (QUEUED, "M3 re-measure — the build trigger for the queued name-market stale-roster detector") states its own trigger: re-measure after the challenger harvest's **first scheduled fire**, because the detector must calibrate against the maintained regime, not a decaying one-off. That fire happened: `/api/cron/race-challengers` `lastRunAt 2026-08-14T12:30:49.466Z`, `success`, on the `30 12 * * *` schedule (confirmed HO 662; the WATCH is struck). The entry's own words: **"the re-measure is DUE, not pending."**

The recorded decision rule (do not re-derive it): HO 642 measured 88 exhibits of 186 rated seats — an alarm firing on 47% reads harvest staleness, not the defect; those figures are **superseded** by HO 656's post-run state. **Read the number through the HO 656 buckets first; build the detector only if the remainder beyond the buckets holds the ME shape (a handful). If it stays large past that discount, the finding is the data, not a missing detector.** (Backlog, M3 entry + its HO 659 restatement.)

An "exhibit" is precise: a rated seat whose `race_candidates` roster is empty (or names nobody the market names) while a card element — Kalshi/Polymarket favorite or the PAC line — names a person. The instrument's M3 section already computes it.

## STEP 0 — reconcile the instrument before trusting a run

`scripts/diagnostic/roster-coverage-642.ts` pins SQL **verbatim** and says so in its header: the harvest join is copied from `scripts/backfill-race-challengers.ts` `HARVEST_FROM_WHERE` **"at 3de13e6"**. HO 660 moved the harvest to **`lib/harvest-challengers.ts`** (one implementation, two callers — SKILL, `backfill:race-challengers` entry). A verbatim copy is a dependency with no compiler edge; reconcile it or the probe measures a query nothing runs.

0.1 Diff the probe's pinned constants against the live sources:
   - harvest join + sentinel (`harvest:primary_winner`) ↔ `lib/harvest-challengers.ts`
   - rated-set predicate ↔ `lib/queries.ts::getRacesIndex` (INNER JOIN `race_ratings` on race_id + cycle)
   - `WITHDRAWN` set + active-challenger filter ↔ `lib/race-matchup.ts`
   - kalshi close-time gate ↔ `lib/race-colors.ts::kalshiActive`

0.2 **Byte-identical** (HO 660 claimed the SQL moved byte-identical — verify, don't inherit): note "STEP 0 clean, 0 drift" and proceed.

0.3 **Drifted but same meaning** (cosmetic — alias/whitespace/module path): update the pinned copies in the diagnostic to match the live source, update its header provenance line (`at 3de13e6` → the current SHA of `lib/harvest-challengers.ts`), and record the diff in the report. This is the HO 661 `verify-house-settled-guard-577` precedent — an instrument reconciled so it can't lie-twice.

0.4 **HALT** if the drift changes what M3 *means* (a predicate term added/removed, the sentinel renamed, the rated-set join reshaped). Report the diff; do not "fix" the probe to a meaning nobody ruled on.

## STEP 1 — run the probe

```
npx tsx scripts/diagnostic/roster-coverage-642.ts
```

Read-only; raw hrana pipeline (the probe's own harness), no app code touched. Capture the **full output**. The figures this HO needs on the record:

- rated-set size (was 187 at HO 656; re-derive, don't carry)
- zero-roster rated seats (was 36 post-run at HO 656)
- **M3 exhibit count + the per-seat exhibit lines** (seat id, what the card names)
- the featured-seat checks (S-MI-2026, PA-10-2026) as printed

Also pull the harvest's current census for the frame (one query or the HO 659 stamp instrument `scripts/diagnostic/race-candidates-stamp-659.ts`): sentinel rows / seats / distinct `updated_at` stamps — confirm the newest stamp is a **scheduled** fire (~12:30 UTC), which is the whole point of measuring now.

## STEP 2 — bucket every exhibit; the sum must reconcile

Classify each M3 exhibit into exactly one bucket, HO 656 discipline (buckets that SUM, no unnamed remainder):

1. **Future primary** — contest not yet voted; a name market ahead of a primary is normal, not a defect.
2. **Winners exist but all are the incumbent** — correctly excluded by the harvest (NC-07 / S-SD were the 656 instances).
3. **`isSettled` freeze class** — past-dated, scored, uncalled upstream (WA-05, WA-08 were the residuals; the HO 661 window may have moved these — check `status` live, don't assume).
4. **Past-dated, empty roster** — the HO 564 territory (ME-02, NY-02, NY-22 at 656).
5. **Too recent to be called** — voted within days of the run.
6. **ME-shape remainder** — the roster is *maintained and still wrong about a person the market names*: convention nominee, ballot vacancy, genuine staleness the harvest cannot derive. **This bucket is what the detector exists for.**

`buckets 1–5 + bucket 6 = M3 exhibit count`, stated as arithmetic in the report. If a seat fits no bucket, that is a finding — name it, don't force it.

## STEP 3 — disposition, per the recorded rule

- **Bucket 6 is a handful (ME-shape):** GO on the detector. **Do not build it here** — file the GO in the docs commit; the build is its own HO (the detector spec lives in the QUEUED "name-market stale-roster detector" entry: fires on the *name-market branch failing to match*, never on the general `favoredMember` null — bare-party markets are ~65% of matches and gating on the general null mutes the alarm in a week).
- **Bucket 6 is large:** the finding is the data — the maintained harvest still leaves a structural gap; file *that* (what class dominates bucket 6, what would fill it) and the detector stays gated.
- **Borderline** (no clean "handful" reading): HALT and report — that's a Corey call, not an architect's.

## HALT — report before the docs commit

Paste back: the full probe output, the STEP 0 reconcile result, the bucket table with its arithmetic, and the STEP 3 disposition. **Show the docs diff before committing** (no auto-commit; `git add` by explicit pathspec only). If any pasted block is swallowed, re-deliver as a gitignored file after ONE swallow — never re-paste (method.md § Relay).

## STEP 4 — docs commit (one commit; SKILL not touched)

**No SKILL edit is expected.** If STEP 0 found SKILL-relevant drift, that edit is its own commit behind the self-mod guard, its own review ref, diff approved first — it never rides here.

4.1 **`docs/backlog.md`** —
   - **M3 entry (QUEUED):** append the measurement (exhibit count, bucket table summed, date, HEAD SHA) and the disposition. If GO: the entry narrows to the build with the bucket-6 population named. If the finding is the data: restate with the dominant class and what fills it. Figures carry corpus size + date (the measured-number rule).
   - **Strike two stale OPEN LOOPS lines — session-open reconciliation (verified against the tree at HO 663 open, this is the record of that verification):**
     - **"`/dashboard-classic` sunset"** — close-criterion met at HO 608–610: `app/dashboard-classic/` does not exist (verified `f83f439`; roadmap + SKILL record the deletion, `1d9c339`). Strike with the pointer. Its HO 335 note about the 3 ungated reads died with the route.
     - **"v2 click-to-filter decision"** — superseded at HO 320: `app/page.tsx` awaits `searchParams` and threads `DashboardFilters` into the distributions/MOVERS/BREAKING (verified `f83f439`; SKILL `/` entry: "RESTORED; was staticMode… now closed"). There is no staticMode to decide between. Strike with the pointer.
     - Strike = `~~…~~` + a one-line close note, per ledger convention. **Do not delete the lines.**
4.2 **`docs/roadmap.md`** — one `Also (HO 663)` block, append-only, pointer advanced to 663: the trigger that fired, STEP 0's reconcile result, the exhibit count + bucket arithmetic, the disposition, and the two reconciliation strikes named as session-open findings (the ledger's own reconcile-at-open rule doing its job). No retro-edits to prior blocks.
4.3 **`docs/oddities.md`** — only if something odd emerged (a bucket that wouldn't close, an instrument surprise). Nothing odd → no entry, say so in the roadmap block (the HO 659/660 form).
4.4 If STEP 0.3 edited the diagnostic: that edit is **its own commit, before the docs commit** (`diag(HO 663): reconcile roster-coverage pins to lib/harvest-challengers`), kinds never mixed (the HO 645 process note).

## Verification gates

- **Bucket arithmetic** printed and reconciling in the report — the sum IS the check.
- **Backlog strikes:** `git diff --numstat HEAD~1 HEAD -- docs/backlog.md` and read the deletions column — a pure strike-with-annotation should show additions with **0 deletions**; any deletions get explained line-by-line. (`grep -c '^-[^-]'` is NOT a deletion count — the HO 643 WATCH rule; a deleted markdown bullet renders `--` and escapes it.)
- **Anchored greps** (HO 637 rule — `grep -ow`, `\b663\b`, `^\*\*Also \(HO 663\)`): roadmap pointer at 663 exactly once as a block header; `grep -n "dashboard-classic" docs/backlog.md` afterward shows the OPEN LOOPS line struck (line 20 today) — the other mentions (display-orphans entry, DONE tombstones, historical prose) are records and stay.
- Working tree clean after the commit(s); push only after re-checking HEAD ancestry (`git ls-remote --heads origin`), per method.md § Session start.

## Out of scope — named so it isn't absorbed

- Building the detector (its own HO on a GO).
- Editing `isSettled`, the harvest, or any `lib/` code.
- The two HO 661 settle-window WATCHes (Aug 20 / Sep 3 — not due).
- The `CRON_ROUTES` stale schedule string (rides the next `lib/cron-health.ts` touch, per its own entry).
- Any SKILL edit (see 4.0 note).
