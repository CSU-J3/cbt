# HO 717 — STEP 0 ruling (architect, 2026-09-12). The cursor rides the walk; the four design corrections are accepted, two with an adjustment; the HALT clears.

HO 715's close is complete with the Production run in the record (34715504769, success; `band=12/failed=0`; the eight HO 716 routes at 390 `over=0` with the chips present), and nothing further is owed there.

The cursor question is answered the good way: on 12 of 12, `updateDate` is at or after the last *Added*, and on 9 it trails the upload by 0.11–0.22 h, which is a document post moving the record rather than a coincidence. **Documents ride the existing walk; no rolling re-read; the summary counters stay.** The one-time `backfill:meeting-documents` remains, because events already synced were fetched before this HO stored anything.

Four premises of mine were wrong and go in the block as the architect's: the cursor lives in `meeting_sync_state`; `/hearings` renders `HearingsCalendar` with `HearingDetailCard` on hover or click (shared with `/`), and `HearingRow` lives on committee and bill pages; the hearing row has no narrow layout at all; and two SKILL lines STEP 3 was to amend do not exist and become additions.

## F1 — the link target is the House Committee Repository page

Accepted. `docs.house.gov/Committee/Calendar/ByEvent.aspx?EventID={id}` — 200, every file listed by type with its *Added* time, constructed from the id; the `event_page_url` column is dropped. The congress.gov event page is recorded in SKILL for what it measured as: present in `videos[]` on 24 of 33, 403 behind a Cloudflare challenge to any non-browser fetch, unverifiable as an index from here. **House events only in v1.** Senate meetings get no affordance until STEP 1 reads whether any Senate `meetingDocuments` match the predicate at all; if the count is non-zero, the Senate rows are a filed follow-on with the congress.gov page as their only candidate target, not a v1 ride-along. The row's `n` still counts documents from Congress.gov's payload; the link goes to the repository's listing of the same files (HO 715 row 2: identical by filename on 60 of 60).

## F2 — both components, and the widening is named

Accepted: `HearingRow` (committee and bill pages) and `HearingDetailCard` (`/hearings` and `/`). The shared card reaching `/` is a forced widening of exactly one link in a card that already carries WATCH; the block names it. Proof moves as you propose: a DOM diff on the committee page (`/committee/hlig00`, whose 119474 carries 4 documents today) and a scripted hover-or-click on `/hearings` opening one card that has `n > 0` — if no current `/hearings` meeting has one (the two most recent markups read 0), the card is proven on the committee page's fixture and `/hearings` is read as `n = 0 → no link`, which is also a reading.

## F3 — the narrow rule, adjusted

Accepted in shape, with one adjustment. Above 720, the votes link stacks under WATCH in the right column. **At 720 and below the link does not vanish; it moves into the row's expanded panel**, as you propose, *and the collapsed row keeps a bare `↗ n` glyph-count in the WATCH slot* only if that slot already exists at that width with room for two characters — measured, not assumed. If the collapsed row cannot carry even that without squeezing the title, the panel alone is the rule and the SKILL says the affordance is one tap deeper on narrow. The `@media (max-width: 720px)` breakpoint is the hearings CSS's own. 430/390 are CI's readings on `committee-detail`, with the local numbers as predictions.

## F4 — the table stores what upstream files

Accepted: `name TEXT` and `url TEXT` nullable, `UNIQUE(event_id, ord)` with `ord` the array position, so the 18 nameless, 15 URL-less and the one duplicated URL land as filed and the count equals what upstream files. The predicate is unchanged: a NULL name fails `LIKE` and falls through, which is correct — a nameless document cannot be a matched roll-call record. The column comment says why the constraint is positional.

## Filings

- **Oddities:** the index can list a file that does not exist — the repository page for 119200 lists `HMKP-119-AP23-20260417-SD001.pdf`, which answers 200 *Not Found* on both hosts. The link target is honest (it is the committee's own listing); the SKILL entry says a listed file is not a guaranteed file.
- **Backlog, WATCH:** the committee-detail crawl exercises the affordance only while hlig00's recent ten include an event with `n > 0` (today: 119474 as 4th of 10); it drops out after seven more meetings — the HO 716 content-dependence shape. Close: the committed fixture test in STEP 1, if a seam exists, or the content-independent narrow coverage line already filed absorbing this instance.
- **Backlog:** Senate meeting documents (follow-on), and the docs.house.gov *Added* time as a stored field (the probe→wire line already filed absorbs it — the repository page is now the link target, so the time is one click away without being stored).

## Proceed to STEP 1

As the handoff has it, with F1–F4 as ruled: commit 1 the table (positional unique, nullable fields) and the sync's document write, no `event_page_url`; commit 2 the backfill; commit 3 the affordance on both components with the 720 rule and the repository link built from the id. STEP 2's served checks move to the committee page and a scripted card open. STEP 3's two non-existent SKILL lines are written as additions. The backlog closes the HO 715 decision line with *"c"*, Corey, 2026-09-12, chat.

read and follow 717-step0-ruling — the file, not this line
