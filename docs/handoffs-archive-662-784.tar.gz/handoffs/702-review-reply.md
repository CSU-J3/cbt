# HO 702 — review reply and FF go, conditional on two hunks

Read on the ref at `1b1908f`: four commits, kinds pure, a clean FF of `685f922`, every blob LF, the SKILL bullet read in full. **The SKILL slot closes on `a8f94e1` as it stands**: the channel, the mechanism with its five cites, the lever and its off switch, the necessary-not-sufficient sentence, and the paragraph that says the first table was wrong and why. (`t2t1'` with the prime is the block's notation; the script's mode is `t2t1`, and the usage line below is where a reader will type it from.) The test and chore commits are approved as built; tracking the harness was the right deviation for the reason given.

Two non-SKILL fixups before the push, both in text that is wrong on the ref today. Fix them into their owning commits, `--force-with-lease`, and quote `git diff 1b1908f <new tip>`: **if it is exactly these two hunks and the SKILL blob is unchanged (`git rev-parse <tip>:.claude/skills/cbt/SKILL.md` equals `a8f94e1`'s), this file is the FF go and §3 executes without another read.**

## 1. `scripts/diagnostic/seam-intervene-702.ts:40` and `:42` (fixup into `36156d9`)

`:40` still describes `t2t1` as *`t2 + delay every JS chunk 500ms`*; the code at `:127–131` holds the chunks until `domcontentloaded`, and the block's whole point is that the 500 ms version could not collapse anything. `:42`'s usage line names `scripts/diagnostic/scratch/…`, a path the file no longer lives at. A gate script whose header describes a different gate is the HO 700 oddity in a comment. Rewrite `:40` to the hold-until-DCL behaviour with `HYD-BEFORE-TAIL 0 by construction` and `:42` to the tracked path.

## 2. `docs/backlog.md:50`, the headline clause (fixup into `1b1908f`)

The entry opens *"every prod fire is UNATTRIBUTED and the cause COUNT is UNKNOWN"* and closes, forty lines later, with the cause named and confirmed. The most-read sentence in the ledger must not contradict its own tail. Replace the opening clause with *"STILL OPEN; cause NAMED and CONFIRMED BY INTERVENTION (HO 702), close is cause plus green (HO 704)"*, the old clause preserved in the annotation as what the entry said until 702. Nothing else in the line moves.

## 3. Execute, on the condition above

1. Re-verify immediately before the push: `main = 685f922`, ref tip as re-pushed. Drift is a HALT.
2. `git push origin HEAD:main`, no force. Confirm with `git ls-remote --heads`. Delete `702-review`.
3. `verify:deploy` for the served SHA; nothing served changes and the block says so.
4. Quote the `design citations` run and the `ci.yml` run on the `main` push (`e2e/**` and `scripts/**` are outside `paths-ignore`, so `ci.yml` runs this time — read against the tip's file list, not carried).
5. The next daily's smoke result when it lands: the first prod dump with the `mut` line and `hyd-start`, quoted into the block.

read and follow 702 — two hunks, then FF
