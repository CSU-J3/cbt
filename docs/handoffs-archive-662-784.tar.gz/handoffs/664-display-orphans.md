# HO 664 — display-orphans chore, members 2+3 (the dead feed fallback arms + the `.home-grid` dim rule), carrying the searchMembers reconciliation strike

**Read this file in full before executing anything. Execute in order. HALT conditions are hard stops — report and wait, do not improvise past them. Two HALTs: the STEP 0 closure table, and the pre-land review ref. Nothing lands on `main` before the second is approved.**

Base: `main` at `cb52368` or later. Clone fresh; verify HEAD before starting (concurrent-session rules per `docs/method.md` § Session start). Number derived per method: max(roadmap pointer 663, highest commit-subject HO 663) + 1. Environment: code edit + `npm run typecheck` + `npm run build` (secretless, CI parity — SKILL § Continuous integration), plus one local `npm run start` confirmation that reads the DB (`.env` `TURSO_DATABASE_URL`/`TURSO_AUTH_TOKEN`). Either machine; no WSL/Docker; port discipline per SKILL § Process cleanup if anything holds 3000.

## Context (why now)

Two things, one docs commit.

**1. The session-open reconcile killed the queue head.** The prior session's close state named the `searchMembers` `INDEXED BY` hint as the cheap head of QUEUED. The tree says it shipped a week ago: **HO 626, `e9d2aad`** (2026-08-07, `lib/queries.ts` +14/−1, ancestor of `main`) — the hint mirroring `billsAggCte`, `FROM bills INDEXED BY idx_bills_sponsor_agg` now inside `searchMembers` (`lib/queries.ts` ~:7851) under a comment header naming HO 626 and the HO 624 measurement. Gates were run then and recorded in the roadmap **"Also (HO 624–627)"** block: plan flipped to `SEARCH bills USING COVERING INDEX idx_bills_sponsor_agg`, full-statement `rows_read` across five probe terms (`smith` 35,129→18,580, four more in the block), equivalence proven **row-identical on all five**. **The backlog residual (`docs/backlog.md` ~:162, "STILL OPEN, found in passing … not done at HO 624") was never struck** — the third instance of the never-struck class in two sessions (HO 663 struck two). The strike rides this HO's docs commit as session-open reconciliation, the HO 663 form. Do not re-add the hint, re-run its gates, or touch `lib/queries.ts` at all.

**2. The next QUEUED item is the display-orphans entry's remaining members** (entry at `docs/backlog.md` ~:106; member 1, `DashboardTopicTreemap`, closed at HO 650 `ded820a`). **Correct the entry's mechanism before executing on it** — the backlog-claims rule (that file's own header) firing again: the "non-v2 fallback renderer arm" is **not in `V2FeedList`**. It is the else-arm of each of the three server wrappers that choose the renderer — `ActivityTicker.tsx` :94–100 (falls back to `<BillRowList compact … watchedIds …>`), `TopStalls.tsx` :62–66 and `NewThisWeek.tsx` :58–62 (both fall back to `TopStallsList`). Sole caller of all three is `app/page.tsx` (:230/:237/:240), always `variant="v2"` — that half of the claim holds. ActivityTicker's own header (:25–31) already records the fallback arm as "a separate cleanup, noted not done." This is it.

## STEP 0 — enumerate; closure table; HALT

Line numbers here are as of `cb52368` — re-derive every one at your HEAD; a line-number anchor is invalidated by any edit above it (HO 652). Produce the closure table (candidate · verdict · evidence `file:line` · destination) covering at least:

1. **The three else-arms + the `variant` plumbing.** The arms; the `variant?: "v2"` props (ActivityTicker :47/:56, TopStalls :36/:43, NewThisWeek :28/:35); the three `variant="v2"` in `app/page.tsx`; ActivityTicker's "noted not done" comment; the TopStalls :30–31 / NewThisWeek :19–21 "No variant split — see the ActivityTicker note" sentences (trim or RECORD per site).
2. **`getWatchedBillIds()` in ActivityTicker** (import :9, `Promise.all` :60/:81, sole consumer the dead arm at :99). Goes with the arm — one read per dashboard render removed. Verify sole-consumer within the file before claiming it.
3. **`TopStallsList`** — pre-verified at `cb52368`: consumers are exactly the two dead arms plus comments (`useSingleOpenPanel.ts` :4/:9/:23; the two importing wrappers). Post-strip it is a zero-caller component → delete `components/TopStallsList.tsx`. Enumerate every class it renders (expected: Tailwind utilities only, no `globals.css` excision — verify, don't inherit) and the comment edits its deletion forces.
4. **`BillRowList`'s `compact` passthrough** — the sole `<BillRowList compact>` caller is the ActivityTicker dead arm. **Do not chase** (BillRowList is live on 6+ routes; HO 507 shared-component rule). Pin the distinction with grep evidence: `BillRow`'s own compact/link-only mode keeps other consumers (SKILL :1930/:1972 name `SearchResultsBills` / `/patterns` / `/committee/[systemCode]` — cite how each actually renders). Destination: a **new QUEUED entry** in the docs commit.
5. **CSS, per-selector, never prefix.** Plain-substring grep each selector across `app/ components/ lib/` (`*.ts`/`*.tsx`), **positive control first**: `.breaking-row` must read >0 (at `cb52368`: 7 — `BreakingRow.tsx` / `BreakingNewsBlock.tsx`) before any zero is trusted. Then `.home-grid` (0 at cb52368) and `.home-col-right` (0). Candidates: the named member `:986` `.home-grid:has(.breaking-row:hover) .home-col-right`; the `.home-grid` base rule `:705` and media rule `:1686` — dead by the same read; recommend taking them in the same excision (the `.pdc`-entry adjacent-orphan shape), present it and let the HALT rule; the mixed HO 178 comment block `:976–982` (edit — its dim half dies, its overflow half describes a live rule); **keep** `:983` `.home-quadrant.home-breaking-panel` (both selectors live: 7 and 1 TSX hits — the worked negative control); `.home-grid` comment references `:109`/`:380`/`:723` (edit or RECORD per site).
6. **SKILL inventory for STEP 5** — grep fresh; known at `cb52368`: :1578 (`NewThisWeek variant="v2"`), :1741 (`variant="v2"` ×3 in the `/` entry; its TopStallsList clause is already RECORD-phrased), :1930 + :1972 (ActivityTicker in the compact-consumers lists), :2068 (`<BillRowList compact>` as the live MOVERS path; `TopStallsList` in the live-island list), :2087 (changelog — the deletion is appended there).

**HALT.** Paste the table back. If anything reads other than expected — a live TopStallsList consumer, a nonzero `.home-grid`, a failed control — that row's verdict changes and the table says so; do not force it.

## STEP 1 — the chore commit (after the table is approved)

Work on a review branch from the start: `git checkout -b 664-review-local` first (the HO 655 lesson — local `main` stays at `origin/main` until approval). One commit, one kind:

`chore(HO 664): strip dead non-v2 feed arms, delete TopStallsList, excise the .home-grid dim rule`

Per the approved table. Expected shape: three else-arms and `variant` props gone; three `variant="v2"` gone from `app/page.tsx`; `getWatchedBillIds` + `watchedIds` + the `BillRowList` import gone from ActivityTicker; `components/TopStallsList.tsx` deleted; `useSingleOpenPanel.ts` comments reconciled; CSS excision per the table, with the comments edited rather than orphaned.

## STEP 2 — gates

- `npm run typecheck` and `npm run build` green.
- Source greps read 0 under `app/ components/ lib/`: `TopStallsList`; `variant` in the three wrappers and at their `app/page.tsx` call sites; every removed selector.
- **Built-CSS check** (`.next/static/css/*.css` after the build): every removed selector reads 0; control `.breaking-row` reads >0. Same instrument, post-artifact — the HO 658 served-bundle shape, run locally.

## STEP 3 — runtime confirmation

`npm run start` (port 3000), then: `curl -s -o /dev/null -w "%{http_code}" -H "Cookie: ct_seen=1" http://localhost:3000/` reads 200, and the same request's body greps >0 for `v2f` (the three tabs' feed renderer, unbroken). Kill by PID, port-scoped, per SKILL § Process cleanup.

## STEP 4 — docs commit (`docs: HO 664 — …`)

4.1 **`docs/backlog.md`** —
- **Display-orphans entry (~:106):** strike, with the close note: members 2+3 landed at <chore SHA> (the three wrapper arms + variant plumbing stripped, `TopStallsList` deleted, the dim rule excised, plus whatever the approved table added); member 1 was HO 650 `ded820a`. Name the mechanism correction (the arm lived in the three wrappers, not `V2FeedList`) so the entry's own claim doesn't outlive it.
- **searchMembers residual (~:162):** strike, with: DONE **HO 626 `e9d2aad`** 2026-08-07 — the hint mirrors `billsAggCte`, plan `SEARCH bills USING COVERING INDEX idx_bills_sponsor_agg`, `rows_read` `smith` 35,129→18,580 (one of five terms, all in the roadmap 624–627 block), equivalence row-identical on all five; the line was never struck at 626; struck here as HO 664 session-open reconciliation, verified against the tree at `cb52368`.
- **New QUEUED entry:** `BillRowList`'s `compact` passthrough has zero callers as of the HO 664 strip — **created by it, not found by it**. `BillRow`'s own compact mode stays live (consumers as pinned in STEP 0). Filed, not chased, per the HO 507 shared-component rule. Close: strip the passthrough behind its own gates on the live BillRowList routes, or record a keep reason.
- Strike = `~~…~~` + a one-line close note, per ledger convention. **Do not delete the lines.**

4.2 **`docs/roadmap.md`** — one `Also (HO 664)` block, append-only, pointer advanced to 664: the reconcile finding (the queue head had already shipped at HO 626; where the record was — roadmap, code comment — and where it wasn't — the ledger), the mechanism correction, the chore's numbers (files, deletion counts, the per-render read removed, the built-CSS selector counts), the filed BillRowList entry, and the oddities disposition. No retro-edits to prior blocks.

4.3 **`docs/oddities.md`** — only if something odd emerged. Nothing odd → no entry, and say so in the roadmap block (the HO 659/660 form).

## STEP 5 — SKILL commit (`docs(skill): HO 664 — …`), self-mod guarded

Its own commit, never riding another doc. Per the STEP 0 inventory: the `variant="v2"` mentions drop the prop; :1930/:1972 lose ActivityTicker from the compact-consumer lists (or gain RECORD phrasing); :2068 moves `TopStallsList` out of the live-island list and re-phrases the `<BillRowList compact>` dashboard claim as RECORD; :2087 changelog appends the `TopStallsList` deletion at HO 664. **Minimal edits** — the `/` entry is already flagged stale-as-enumeration (HO 646); do not rewrite it, touch only the claims this HO falsified.

## HALT — the review ref; nothing lands before approval

Push the branch: `git push origin HEAD:refs/heads/664-review` (amend via `--force-with-lease` on the ref only; `main` only ever fast-forwards). Paste back: the executed table deltas, `git show --stat` of all three commits, the STEP 2/3 gate outputs, the backlog numstat with every deletion explained, and the docs + SKILL diffs. Remote claims via `git ls-remote`, never `rev-parse origin/*` (SKILL § Review-ref route). One swallowed block → re-deliver as a gitignored file, never a second paste (method.md § Relay). **The SKILL diff needs explicit approval** — the self-mod guard is satisfied by the ref, not bypassed by it. After approval: fast-forward `main` (`git push origin HEAD:main`, no `--force`), delete the ref, verify with `git ls-remote --heads origin`.

## Verification gates (run before the HALT; outputs in the paste)

- STEP 2/3 all green; working tree clean after the three commits.
- **Backlog numstat:** `git diff --numstat <docs-commit>~1 <docs-commit> -- docs/backlog.md` — every deletion explained line-by-line (an in-place strike reads as 1 deletion + additions; the struck text must survive inside `~~…~~`). `grep -c '^-[^-]'` is NOT a deletion count (HO 643).
- **Anchored greps** (HO 637 rule): `grep -cE '^\*\*Also \(HO 664' docs/roadmap.md` = 1; `grep -row "TopStallsList" app components lib | wc -l` = 0; `grep -n "STILL OPEN, found in passing" docs/backlog.md` shows the line struck, not gone.

## Out of scope — named so it isn't absorbed

- The `BillRowList` compact-passthrough strip (filed above — shared component, its own gates).
- The paired `/api/race/[id]/hub` route deletion + `/dashboard-classic` SKILL prose sweep (next in QUEUED; those two travel together, and not here, even though STEP 5 has SKILL open).
- The `.pdc*` excision entry (its own change, its own byte-identical `/electoral` gate).
- The HO 661 settle-window WATCHes (Aug 20 / Sep 3), the ~Sep 1 per-query ledger glance, the M3 re-arm (post-Sep-15) — none due.
- The `CRON_ROUTES` stale schedule string (rides the next `lib/cron-health.ts` touch, per its own entry).
- `lib/queries.ts` entirely — the searchMembers work is done; this HO only records it.
