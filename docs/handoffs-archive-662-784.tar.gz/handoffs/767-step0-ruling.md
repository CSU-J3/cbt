# HO 767: STEP 0 ruling. Proceed, with the ten readings taken as below and seven corrections owed to the block

**Proceed.** The closure table holds: no migration, every column the build reads exists, and the payload fits a page-load batch once each record is trimmed to what the open row prints. Nine anchors drifted and were re-derived, six of my claims were wrong and one leg was mine to fix, and none of them changes the build's shape. They land in the block as corrections, listed at the end.

## The ten readings

1. **R1, the chips on NH SEN. My error.** Pappas sits in the House and the scorecard is Senate only, so NH SEN shows one chip, Shaheen's, on the SEAT HELD BY line. The member-row chip leg moves to GA SEN (Ossoff). Today four grades reach this page: Ossoff on a member row; Shaheen, Peters and Smith on holder lines. The rest of GRADE 3 arrives with the House tab's sync.
2. **R2, NEWS 2: your recommendation.** Build a new batched read over the observations projection, keyed by the bioguides of the members on each ballot, with no `SEAT_NEWS_TERMS` filter and its limit per row, not per call. 30 days, at most 5 per row (the line prints the newest and *+N*, the open row up to five); RACE NEWS reads 7 days per chamber, each item tagged with every seat it attaches to. `getSeatNews` is untouched; the dashboard keeps it. Leg 5 compares the open row's news with the race page's.
3. **R3, MOVED: 14 days on `observed_at`**, the age printed, and a title carrying the observed date and the rater table's as-of (`rating_date`). Not 30. Your latest-move dates are batches, and two of them are first runs:
   - 09-21 is a Monday: HO 742's first run after the table left the page, 47 rows.
   - 09-24 is a Thursday: HO 744's first Senate run over the hand seed, 7 rows.
   - The scheduled Wednesday ticks are 09-23 (8 rows) and 09-30 (17).

   A first run after a gap dates our reading, not the rater's move, and a 30-day window would print 54 of those as recent into late October. Once the 14-day window has passed 09-24, it holds scheduled-tick moves only. The legs paste which rows carry MOVED and their observed dates. The guard that would hold this by itself is filed, not built: a move counts only when the same leg also succeeded within the 8 days before it.
4. **R4, site 11:** the *◆ N markets disagree* clause rides line 2 after the tier switches, odds-gated, its separator inside the gate. The count stays sixteen.
5. **R5, the hero band:** the gate moves to `.races-hero-band`, the band renders nothing when both control values are null, and the re-shape rule retires. SKILL :2343's re-shape sentence changes with it in the `docs(skill)` commit.
6. **R6, a called seat's odds** hide on the result, not on market close (`kalshiActive` reads `Date.now()`, `lib/race-colors.ts:79-83`). This covers the rows and the open row only. The MAP's pinned card, district card and export stay as they are, and that gap is filed.
7. **R7, the remaining 2026 literals.** Convert `PrimaryTimeline.tsx:73-76`'s month ticks and `Battlefield.tsx:134`, `:146`'s *NOV 3* to the cycle. The dashboard's output doesn't change in 2026. `getChamberControl()` and `RaceDistrictModal.tsx:32`, `:190` stay, and go into the 2028 WATCH line.
8. **R8, the calendar list's `data-col-flow` curve:** the legs driver measures it in the page with the calendar open. The audit is unchanged, and the registry entry cites the driver's reading.
9. **R9, the special-election line.** `general_ballot.box_prefix` decides, in the ballot's own words. The clause *the winner serves out the term ending Jan {Y}* follows from the seat holder's `members.senate_class` against `senateClassForCycle(cycle)` (`lib/derive-term.ts:183`): Y is the next year after the cycle whose class is the holder's, plus one. With no class stored, the line stops at *Special election*.
10. **R10, Missed · 119th:** batch the member page's own `member_votes` read so leg 5 compares like with like, with the median staying `getChamberParticipationContext`'s. HO 595 materialized participation because the live scan ran past its 10s bound (`lib/queries.ts`, the comment above `getChamberParticipationContext`). So the legs time the batched read cold; past 2s, stop and propose `member_participation` instead.

## The rest of the table

- **Payload:** load at page load, each record trimmed to what the open row prints. No fetch-on-open route.
- **Members in Congress now:** the union of ballot identity and HO 759's `onOwnBallot`: 76 members, S-AK's Sullivan only through the second.
- **The five with no FEC row** (Hinson, Luna, LaLota, Gluesenkamp Perez, G000608) print the open row's no-FEC line. Leg 5 reads their member pages, and if any of them prints totals, stop and say where they come from.
- **TX-23** is the one possible *{P} WIN*; the rule stays.
- **Tests:** your plan, as written, plus the two odds-off additions you recommended: an `/electoral` ON control on `.race-list-diverge`, and a row opened so the open row's `KalshiLine` is read in both states. The `odds-toggle-692` diagnostic clicks MAP first. `bundler-captures-706` re-baselines, outside CI.
- **The audit:** at load it now measures LIST. MAP's sameness rests on leg 1's side-by-side captures. Any new M1 at load is fixed or priced.
- **Forced consequences, accepted as you named them:**
  - the five batched readers
  - the C1 prop packing the ELECTION DAY line only
  - `todayISO` onto `clockNowMs` (the page is force-dynamic, so HO 490 holds)
  - the `no_box` provenance string carried
  - a House member's Senate money tagged as the member page tags it (HO 416)
  - one shared constant for the tracker's URL (the member page and the card import it, and the sync's export URL derives from it)
  - the pool count threaded to all three badge sites
  - the allowlist entries
  - the Kiley oddity cross-referenced to the HO 422 entry as a different mechanism

## Corrections owed to the block

1. **C1 was half right.** Only the ELECTION DAY line is pinned right. HO 758's RESULTS line already takes its own row, left-aligned (`app/globals.css:3791-3801`).
2. **`getRaceCandidatesForCycle` is not the whole roster.** It excludes `on_ballot` (`:2251`) and doesn't select `printed_party`.
3. **`getSeatNews`** ANDs `SEAT_NEWS_TERMS`, and its LIMIT spans the whole id list (`readObservationNews`, `:2643`).
4. **Six of the readers I called per member or per race aren't.** `getRaceCandidatesForCycle`, `getIncumbentQualifiers` and `getPacIeSpending` are cycle-wide; `getRecentRaceMoves` and `getSeatNews` take id lists; `getChamberParticipationContext` takes no arguments.
5. **AK's second Dan Sullivan is in the tree** (`lib/queries.ts:2006-2008`, SKILL, the backlog), but there's no column to print it from. The conclusion stands.
6. **The Tooltip's non-interactivity is real but not in SKILL.** The mechanism is `pointer-events: none` (`app/globals.css:7574`), `role="tooltip"`, and a close on mouseleave, while SKILL :2346-2360 says only *instant out*. The `docs(skill)` Tooltip entry now states the mechanism, with those citations, as the reason the card exists. And SKILL :2343 counts sixteen odds sites without listing them; their numbers live in HO 692's code comments, so the handoff's *SKILL's sixteen-site list* is wrong as worded.
7. **Leg 1's two chips on NH SEN** (R1).

The nine drifted anchors: the block cites them as re-derived.

## Counts at the FF

OPEN LOOPS live 61 → **66**, control 0. The five new lines:
- the tracker's House tab;
- the 2028 data side WATCH, now also carrying `getChamberControl()` and `RaceDistrictModal`'s literals;
- the Tooltip on touch and scroll;
- odds on a called seat on the MAP's cards and export;
- the MOVED first-run guard.

HO 758's Nov-4 WATCH is amended to carry `/electoral`'s rows, which is not a new line. Struck stays as it is unless a line closes in passing; say so if one does.

## Scope guard

- No migration.
- `getSeatNews` and `Tooltip.tsx` are untouched.
- The map, the race pages and the dashboard read as they do today, apart from what R5 to R7 name.
- Nothing is filed by number.
