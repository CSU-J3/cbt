# HO 703 — FF go, one clause first (architect, 2026-09-08)

**Owner verdict, verbatim: "use what would be logical"** — Corey, CBT maintenance chat, 2026-09-08, against the architect's read of `703-review` at `ddd6d48` (five commits, kinds pure; SKILL, method and backlog byte-identical to the `de5762c` read; a four-line executable delta between the two tips; Preview run `34299650134` on the final bytes, 72 passed, served SHA equal to the deployment's). Interpretation: a delegation, recorded as one. The SKILL slot is filled on `e3dbfd3` as read, and the go is given with the mechanics the architect proposed: the one false clause in the oddities entry is fixed on the ref first and checked mechanically, then `main` fast-forwards.

## 1. The clause (docs commit amended, kinds unchanged)

- `docs/oddities.md`, the HO 703 entry, the sentence beginning **"The fix is one home, not a smarter fallback"**: replace *"and the spec holds the only literal widths"* with *"and `e2e/narrow.spec.ts:118` holds the only literal width the narrow gate reads; `odds-off.spec.ts:41` and `fit-finish.spec.ts:1012` carry their own independent viewport sets, which this invariant does not govern"*. The roadmap block already says this correctly; the oddities paragraph dropped the scope.
- Nothing else moves. SKILL, method and backlog stay byte-identical: `sha256sum` each against `ddd6d48`'s copy and paste the three SAME lines.
- Re-push with `--force-with-lease`. The check that can fail, read from the pushed ref: `git grep -c 'the spec holds the only literal widths' origin/703-review -- docs/oddities.md` → `0`; `git grep -c 'only literal width the narrow gate reads' origin/703-review -- docs/oddities.md` → `1`. Both readings in the paste before anything touches `main`.
- This push produces one more Preview run. It owes nothing (docs-only), but quote its id and conclusion; the block already names why a ref cannot cite its own last run.

## 2. The move

- `git ls-remote --heads origin` immediately before: `main` at `b257009`, `703-review` at the amended tip. If either differs, stop and paste.
- From the branch: `git push origin HEAD:main`, no force. Then `git push origin --delete 703-review`. Then `git ls-remote --heads origin`.
- Local `main`: the move and its check as their own commands, never mid-compound, never `2>/dev/null` (SKILL, Review-ref route, both doors). `git branch -f main <tip>` from the branch; `git checkout main`; `git rev-parse main` must print the tip.
- Tags unchanged; `git ls-remote --tags origin` shows the three.

## 3. The readings that close it

- `npm run verify:deploy` until the served SHA is the tip, then four more reads of `/api/version`, five consecutive.
- **The Production run after the FF is the reading no review could reach, and it is the proof of the env fix on the shipped bytes.** The `e2e-prod` `deployment_status` Production run for the tip: its id and conclusion; the resolved-group echo (`…-Production-success-na`); **the `[narrow …]` lines tabulated from the log, not the conclusion, with the underscore-safe route census: 36 at 430 and 36 at 390, every one `over=0`**; and the job's wall time against the 20-minute cap, which is the budget note's first live reading. **If that run prints 36 narrow lines instead of 72, the fallback path is still pinned somewhere: stop, paste, and it becomes a fix-forward HO rather than a footnote.**
- Tomorrow's `0 15 * * *` schedule run is the daily's first reading at both widths; not owed in this HO, cited when it lands.

## 4. Paste

The `ls-remote` line showing `main` at the tip, the ref gone and the three tags present; `git rev-parse main`; the five served-SHA reads; the Production run's id, group echo, both-width table and duration. Then (b) is authored as HO 705, and the pointer stands at 704 on this block, the 700/701 shape recorded.

read and follow 703 — FF go
