# HO 688 — the gap-state spot-check lands: instrument run, WATCH amended, hold cleared

Docs kind, small. Discharges the item held from the HO 686 close: verifying AZ-03's floor and WA's top-two date incidentally ran the 15-gap-state WATCH's own instrument ("spot-check two of the fifteen against the public primary calendar"), and both passed at source. This HO makes that observation durable, bounds the remaining risk with one cheap read, and clears the hold from both memories carrying it.

**Framing, ruled up front:** this is an **amendment, not a strike**. The WATCH's subject is a living staleness — `calByState` reads only clean regular statewide Senate rows, so the fifteen no-2026-Senate states' House dates COALESCE and never refresh. A passed spot-check doesn't remove that mechanism, and a close criterion that cannot become false again does not close a living thing. The entry keeps its promote trigger verbatim.

## Ground truth at authoring

- Clone at `dce1dbb`, pointer 687, number `max(687, 687) + 1 = 688`. Re-derive at session open.
- The WATCH at HEAD: "The 15 gap-state house primary dates are frozen (HO 577)" — fifteen states **AZ CA CT HI IN MD MO ND NV NY PA UT VT WA WI**, instrument "spot-check two of the fifteen," promote trigger "if any gap state's real primary date moves."
- The observations, with provenance to cite: HO 686 STEP 0 row 3, read through `scripts/diagnostic/settle-upstream-686.ts` (the scrape path the recovery itself uses, control-validated on WA-08 that session). **AZ:** the live page carries "July 21, 2026" and all 18 AZ rows agree with our frozen date. **WA:** frozen 2026-08-04 matches the real top-two date. Both states are members of the fifteen. Dated 2026-09-03.
- The hold currently lives in exactly two places — Code's project memory (filed at the 686 close, "say the word and it rides the next HO that touches primaries") and the architect's carry ledger. Both clear when this lands; a discharged hold left standing tells a future session it still rides.

## STEP 0 — enumerate, then proceed (no HALT expected; flag if any row surprises)

| # | candidate | expected |
|---|---|---|
| 1 | the entry at HEAD | located, text as quoted above; line number for the amendment |
| 2 | membership + provenance | AZ, WA ∈ the fifteen confirmed against the entry's own list; the 686 readings restated with instrument + date |
| 3 | the bounding read | one query over the fifteen states' stored House primary dates: are all fifteen `< 2026-09-04`? If yes, the amendment carries the bounding sentence — the latent staleness now targets the **2028-cycle refresh**, since no live 2026 date remains for a real-world move to diverge from. If any stored date is future, name it and **omit** the bounding sentence — a future stored date is exactly where the staleness could still bite this cycle |
| 4 | SKILL exposure | grep the primaries section for any claim the gap-state dates are *unverified*; expected none. If a line exists, it joins as a guarded SKILL touch — otherwise no SKILL commit |
| 5 | memory hold | the project-memory note located, quoted, and its post-landing edit drafted (points at the amended entry, not at a pending ride) |

## STEP 1 — docs (one commit; expected the only commit)

Amend the WATCH in place: **instrument RUN 2026-09-03 and PASSED on two of fifteen (AZ 18/18 at "July 21, 2026"; WA 2026-08-04 top-two), via the HO 686 upstream reads** — mechanism unchanged, promote trigger unchanged, the row-3 bounding sentence if it measured true, and one line on why this amends rather than strikes. Roadmap `Also (HO 688)`, pointer → 688 — including the note that this discharges the hold filed at the HO 686 close. No oddity.

## STEP 2 — review ref, FF, memory

`refs/heads/688-review`, ls-remote, architect review, FF on approval, ref deleted. `verify:deploy` as the standing step. **After the FF lands:** apply row 5's memory edit and confirm it in the paste — the hold is cleared everywhere it lived.

## Paste-back

The STEP 0 table (row 3's fifteen-date reading quoted), the amendment text as committed, the ls-remote line after FF, and the memory-edit confirmation.
