# HO 708 — `backlog:14` STEP 0: what `typecheck` cannot see, measured

Read-only. Nothing under `app/`, `components/`, `lib/`, `scripts/`, `e2e/`, `.github/` or `tsconfig.json` changes. The outputs are a closure table, one docs commit, and one SKILL list correction; the fix is HO 709. It runs inside the `#418` week because it touches no workflow and no crawl file; the FF's `deployment_status` smoke run is recorded as an extra sample, never as one of the seven.

**Why this one is different from the usual STEP 0.** The architect took every reading below in a fresh clone at `61eab63` (Node 22.22.2, `typescript` 5.9.3, `@playwright/test` 1.61.1 as the lockfile resolves them) and the instrument was tested before it was prescribed, which is the HO 680 / 683 / 685 lesson applied in advance. STEP 0 re-takes the readings on the box, because the box has a `.next/` and a `next-env.d.ts` the clone does not, and takes the one reading a sandbox cannot: the browser-level one in row 5. Where the box disagrees with a figure here, the box wins and the disagreement is pasted, not reconciled by hand.

**What it found, so the table is read with the headline already known.** Adding `e2e/**` to the program surfaces exactly **one** error, and it is in the HO 706 capture spec: `e2e/bundler-captures-706.spec.ts:67` sets `reducedMotion` in `test.use()`, which is not a Playwright test option. The runner registers it as a fixture nothing reads, so the `1440-reduced` third of the 706 capture gate ran with no reduced-motion emulation: 36 captures per role that were 1440 captures under another tag. `smoke.spec.ts` reads clean, which is what decides the scheduling question below.

## Ground truth (fresh clone at `61eab63`, 2026-09-09; re-derive at STEP 0 regardless)

- Pointer 707, highest HO in commit subjects 707; this is 708.
- `tsconfig.json:36-48` `include`: `next-env.d.ts`, `app/**/*.ts(x)`, `components/**/*.ts(x)`, `lib/**/*.ts`, `scripts/**/*.ts`, `types/**/*.d.ts`, `auth.ts`, `.next/types/**/*.ts`, `.next/dev/types/**/*.ts`. `:49-52` `exclude`: `node_modules`, `scripts/diagnostic/scratch`. Not included: `e2e/**`, `playwright.config.ts`, `next.config.ts` (the root-level `.ts` files are `auth.ts`, `next.config.ts`, `playwright.config.ts`; only `auth.ts` is named).
- `package.json:59` `"typecheck": "tsc --noEmit"`; `:8` `"build": "next build"`; `engines` absent (HO 707).
- `.github/workflows/ci.yml:11-13`: *"scripts/** and e2e/** are deliberately NOT ignored (they're TypeScript, covered by typecheck — scripts/ is exactly what broke at 3ed533c)"*. True for `scripts/`, false for `e2e/`.
- `e2e/` holds eight `.ts` files (3,114 lines) and `odds-sites.allowlist.json`; `playwright.config.ts:10` `testDir: "./e2e"`, `:15` `globalSetup: "./e2e/preserve-dumps.ts"`.
- **`e2e/routes.ts` is already in the root program**, pulled in by `import { ROUTES } from "../../e2e/routes"` at `scripts/diagnostic/seam-intervene-702.ts:49` and `scripts/diagnostic/mono-weights-697.ts:40`. So the gap is seven of eight, not eight of eight, and it is the mirror of the caveat `scripts/diagnostic/scratch/README.md` states about `exclude`: `include` selects by glob, but an `import` from an included file brings a file in regardless.
- Baseline `npx tsc --noEmit`: exit 0, 0 errors; `--listFiles` 1,298 files (a fresh-clone figure: no `.next/types`, no `next-env.d.ts`; compare the pattern counts in row 1, not the total). Pattern counts: `e2e[\\/]smoke.spec.ts` **0**, `e2e[\\/]` **1** (`routes.ts`), `playwright.config.ts` **0**, `[\\/]next.config.ts` **0**, `diagnostic[\\/]scratch` **0**, `scripts[\\/]check-odds-sites.ts` **1** (the coverage control).
- Probe (i), e2e + `playwright.config.ts` alone under the root `compilerOptions`: exit 2, **1 error**, `e2e/bundler-captures-706.spec.ts(67,9): error TS2353: Object literal may only specify known properties, and 'reducedMotion' does not exist in type 'Fixtures<…>'`; `--listFiles` 184 files, all 8 `e2e/*.ts` + `playwright.config.ts` present.
- Probe (ii), the root program plus `e2e/**`, `playwright.config.ts` and `next.config.ts`: exit 2, the **same 1 error** and nothing else; 1,308 files (baseline + 10). `next.config.ts` and `playwright.config.ts` compile clean.
- Control, probe (i) plus a bait file carrying one `noUncheckedIndexedAccess` violation: exit 2, **2 errors**, the bait's `TS2322` plus the one above. The instrument can read a non-zero, and its zero on `smoke.spec.ts` is therefore a reading.
- The TS2353's runtime meaning, read from the installed package: `node_modules/playwright/types/test.d.ts` declares no `reducedMotion` member on `TestOptions`; its only mention is the doc example at `:7538`, under `contextOptions`. `BrowserContextOptions.reducedMotion` exists (`playwright-core/types/types.d.ts:2618`). `node_modules/playwright/lib/` contains the string `reducedMotion` **zero times**, so the runner can only pass it to the browser via `contextOptions`. `npx playwright test --list e2e/bundler-captures-706.spec.ts` exits 0 and lists 36 `@1440-reduced` tests, so the key is accepted at load. Row 5 measures what the browser actually saw; the source reading predicts `false`.
- HO 706's block, as landed: *"108 captures · 3 viewport configs … `home-stage-introduced @1440-reduced` were live drift"*. The comparator ran `animations: "disabled"` on every capture, so what the third config would have added is the `prefers-reduced-motion` **layout** (the HO 670 mask class), not frozen animation. That is the thing that went unmeasured across the bundler change, on 36 routes.
- `scripts/diagnostic/scratch` is excluded on purpose: `.gitignore:47-55`, `scripts/diagnostic/scratch/README.md`, `tsconfig.json:51`, all HO 672. `:14`'s clause *"`scripts/diagnostic/scratch` is excluded too (same class, one directory over)"* describes a documented opt-out as if it were the defect. Same shape as `:82`: wrong when filed, in one clause.
- SKILL `:2577` lists the tracked harness files and its parenthetical says the list *"is read as exhaustive"*; `git ls-files e2e playwright.config.ts` returns two files it does not name: `e2e/bundler-captures-706.spec.ts`, `e2e/preserve-dumps.ts`. SKILL `:2511` (*"`scripts/**` is in `tsconfig`, so a throwaway probe that doesn't typecheck fails the Vercel build"*) and `:2584` (*"CI is typecheck + `check:odds-sites` + build"*) are true today and are the sentences HO 709 extends.
- `docs/handoffs/` is repo-ignored (`.gitignore:79`); `git add --dry-run docs/handoffs/708-artifacts/` refuses it. Every artifact below lives there.

## STEP 0 — enumerate, HALT before any tracked file moves

Every command writes its raw output to `docs/handoffs/708-artifacts/` and prints the command's own exit code before anything is grepped (`$?` in bash, `$LASTEXITCODE` in PowerShell). Never `tail` tsc; its informative line is the first one.

| # | check | expected | if the work never happened, this reads |
|---|---|---|---|
| 1 | baseline: `npm run typecheck`, exit and error count; then `npx tsc --noEmit --listFiles > listfiles-root.txt` and the six pattern counts from ground truth | exit 0 · 0 errors · `smoke.spec.ts` **0**, `e2e[\\/]` **1**, `playwright.config` **0**, `next.config` **0**, `scratch` **0**, `check-odds-sites` **1** | the same six numbers: this row re-measures the defect, so its expected reading *is* the nothing-happened reading, stated so a match is not read as a fix. If the baseline reds on the box, the likely cause is a stale `.next/types` after the 706 bump; run `npm run build`, re-take, paste both. Do not delete `.next/` in the shared checkout |
| 2 | probe (i): write `tsconfig.e2e-probe.json` (below), `npx tsc --noEmit -p … > probe-e2e.txt`, exit, count, **full error list pasted**, then `--listFiles` e2e count and `playwright.config` count | exit 2 · **1** · `bundler-captures-706.spec.ts(67,9) TS2353` · 8 · 1 | 0 errors with 8 files listed would mean the box's spec differs from `61eab63`'s; 0 errors with 0 files listed means the config did not resolve and the reading is void |
| 3 | probe (ii): write `tsconfig.root-plus-e2e-probe.json` (below), same three reads | exit 2 · the **same 1** · listed = row 1 total + 10 | a second error here that probe (i) lacks is an interaction between the root program and the e2e files (a duplicate global, a `lib` conflict) and is the finding that would rule shape (A) out on evidence |
| 4 | control: write `bait-708.ts` and `tsconfig.e2e-probe-control.json` (below), run, paste the list | exit 2 · **2** · the bait's `TS2322` plus row 2's | 1 error means the bait was not in the program and rows 2–3 are unproven; 2 means the instrument can fail |
| 5 | the browser reading: write `playwright.rm-probe.config.ts` and `rm-probe-708.spec.ts` (below); `npx playwright test -c docs/handoffs/708-artifacts/playwright.rm-probe.config.ts > rm-probe.txt 2>&1`; exit; then `grep -E 'RM-SHIPPED|RM-CONTEXT|passed|failed' rm-probe.txt` | `RM-SHIPPED=false` · `RM-CONTEXT=true` · 2 passed | `RM-CONTEXT` is the control and must read `true` or the instrument is blind; `RM-SHIPPED=true` would mean the runner does consume the key after all, the 706 third was a real reduced capture, and the finding downgrades to type-only. Paste whichever it reads |
| 6 | the scratch clause: `sed -n '47,55p' .gitignore`, `sed -n '49,52p' tsconfig.json`, first 12 lines of `scripts/diagnostic/scratch/README.md`; `grep -rn 'diagnostic/scratch' app components lib scripts --include=*.ts --include=*.tsx \| grep -c import` | the three reads agree it is a deliberate opt-out; the import grep **0** (the README's own caveat, held) | a non-zero import grep is the README's caveat being violated and is filed as its own finding |
| 7 | SKILL exposure: `git ls-files e2e playwright.config.ts` against the `:2577` list; re-read `:2511`, `:2584`, `:2588` | two tracked files missing from `:2577`; the other three lines true today | a list that matches `ls-files` means the box's SKILL is not `61eab63`'s |
| 8 | `sed -n '8,13p' .github/workflows/ci.yml`, quoted verbatim | the *"covered by typecheck"* clause as in ground truth | it is HO 709's target; row 8 exists so the block can quote what was true when the gap was measured |

**Locate every `:N` by content at your HEAD; the line numbers above are as of `61eab63`.**

HALT here: paste the table with the eight readings, the row 2 error list, and the row 5 pair. The go for the rest arrives as a file.

### Probe files (verbatim, all under `docs/handoffs/708-artifacts/`)

`tsconfig.e2e-probe.json`
```json
{
  "extends": "../../../tsconfig.json",
  "compilerOptions": { "incremental": false },
  "include": ["../../../e2e/**/*.ts", "../../../playwright.config.ts"],
  "exclude": ["../../../node_modules"]
}
```

`tsconfig.root-plus-e2e-probe.json`
```json
{
  "extends": "../../../tsconfig.json",
  "compilerOptions": { "incremental": false },
  "include": [
    "../../../next-env.d.ts",
    "../../../app/**/*.ts", "../../../app/**/*.tsx",
    "../../../components/**/*.ts", "../../../components/**/*.tsx",
    "../../../lib/**/*.ts",
    "../../../scripts/**/*.ts",
    "../../../types/**/*.d.ts",
    "../../../auth.ts",
    "../../../.next/types/**/*.ts",
    "../../../.next/dev/types/**/*.ts",
    "../../../e2e/**/*.ts",
    "../../../playwright.config.ts",
    "../../../next.config.ts"
  ],
  "exclude": ["../../../node_modules", "../../../scripts/diagnostic/scratch"]
}
```

`bait-708.ts`
```ts
// HO 708 control: exactly one TS2322 under the probe config, or the instrument is blind.
const names: string[] = [];
export const first: string = names[0];
```

`tsconfig.e2e-probe-control.json`
```json
{
  "extends": "./tsconfig.e2e-probe.json",
  "include": ["../../../e2e/**/*.ts", "../../../playwright.config.ts", "./bait-708.ts"]
}
```

`playwright.rm-probe.config.ts`
```ts
import { defineConfig } from "@playwright/test";
// HO 708 row 5. about:blank only; no network, no prod, no fixtures from the repo config.
export default defineConfig({
  testDir: ".",
  testMatch: /rm-probe-708\.spec\.ts/,
  reporter: [["list"]],
  workers: 1,
  projects: [{ name: "chromium" }],
});
```

`rm-probe-708.spec.ts`
```ts
import { test, expect, type Page } from "@playwright/test";

const reduced = (page: Page) =>
  page.evaluate(() => matchMedia("(prefers-reduced-motion: reduce)").matches);

test.describe("shipped form, e2e/bundler-captures-706.spec.ts:67", () => {
  // The key tsc rejects (TS2353). Playwright transpiles without type-checking, so it loads;
  // the question is what the browser saw.
  test.use({ reducedMotion: "reduce" } as never);
  test("RM-SHIPPED", async ({ page }) => {
    await page.goto("about:blank");
    console.log(`RM-SHIPPED=${await reduced(page)}`);
  });
});

test.describe("contextOptions form, the documented one", () => {
  test.use({ contextOptions: { reducedMotion: "reduce" } });
  test("RM-CONTEXT", async ({ page }) => {
    await page.goto("about:blank");
    const v = await reduced(page);
    console.log(`RM-CONTEXT=${v}`);
    expect(v).toBe(true); // the control: this instrument must be able to read true
  });
});
```

Remove nothing after the run: the artifacts dir is ignored and stays as the evidence of record, as `702-artifacts/` does.

## STEP 1 — file it (commit 1, `docs(HO 708)`; only after the HALT clears)

No code. Three docs, backlog first.

- **`docs/backlog.md` `:14`, annotated in place, not struck.** The close criterion still stands and HO 709 meets it. The annotation carries: measured at `61eab63` and re-measured at the STEP 0 HEAD; one error in `e2e/**`, its site and code, and the row 5 pair as the runtime meaning; seven of eight files uncovered, `routes.ts` covered by import from two named diagnostics; `playwright.config.ts` and `next.config.ts` named into the same class and both clean; the scratch clause corrected as *wrong when filed*, HO 672's three documents cited; and the shape and eligibility decided below. Original body contained verbatim inside the re-emitted line.
- **`docs/oddities.md`, one dated HO-tagged note:** an instrument that names a property it does not measure. The 706 capture gate's third config carried `-reduced` in every filename and 36 tests per role, and emulated nothing; the comparator's `animations: "disabled"` hid the difference from the eye, and the only gate that reads the difference in under a second, `tsc`, was the one not pointed at the file. Conditional on row 5 reading `RM-SHIPPED=false`; if it read `true`, the note is the type-only finding instead.
- **`docs/roadmap.md`, `Also (HO 708)` block:** rows 1–8 with the box's readings beside the architect's, the row 2 error verbatim, the row 5 pair, the seven-of-eight fact, the scratch correction, the SKILL list drift, and the decision paragraph below. Pointer to 708.
- **`docs/method.md` (commit `docs(method)`, its own kind, conditional on row 5):** the Gates list's twelfth instance, in the list's own form. Eleven were about instruments read wrongly or unable to fire; this one is an instrument whose *label* asserts a condition its *configuration* never set, and whose output was indistinguishable from the honest version by construction. If row 5 reads `true`, this commit does not exist.

## STEP 2 — SKILL, alone (commit `docs(skill)`)

One line. `:2577`'s harness list gains `e2e/bundler-captures-706.spec.ts` and `e2e/preserve-dumps.ts`, and its parenthetical records the second drift in the same voice as the first (*"corrected at HO 708 rather than extended"*), because the list says it is read as exhaustive and it was two files short again within eight HOs. Nothing else in SKILL moves in 708; the CI bullet is 709's.

## The decision, made here so HO 709 opens with it (override at the HALT with a letter)

**Shape (B′) for the fix, not (A).** (A) adds `e2e/**` and `playwright.config.ts` to the root `include`. Its cost is SKILL `:2511`'s own fact: the root program is what `next build` type-checks, so under (A) a typo in a crawl spec fails the Vercel Production build and prod stays on the previous deploy. That couples the harness's typing to product deploys, and nothing in `:14` asked for that. (B′): a `tsconfig.e2e.json` extending the root (`include` = `e2e/**/*.ts` + `playwright.config.ts`, `incremental: false` so no stray `.tsbuildinfo` lands outside `.gitignore:9`), and `"typecheck": "tsc --noEmit && tsc --noEmit -p tsconfig.e2e.json"`, so the pre-push habit and CI's existing step both cover the harness with **no workflow edit**, and `ci.yml:11-13`'s clause becomes true as written once the comment names the second config. `next.config.ts` joins the root `include` (app config, clean in probe (ii)). The `:67` fix is one line: `contextOptions: { reducedMotion: v.reduced ? "reduce" : "no-preference" }`. Row 3 is the reading that can overturn this: an interaction error there is evidence for keeping e2e out of the root program, which (B′) already does.

**Eligibility inside the week.** HO 709's only `e2e/` edit is that one line in `bundler-captures-706.spec.ts`; `smoke.spec.ts` reads clean and is not touched, and no workflow moves. So 709 does not wait for the 16th.

**The re-take, and its clock.** With the key fixed, the `1440-reduced` third of the 706 captures can be taken for real against `cbt-705-n15` and `cbt-705-n16`, which still exist (method.md § Environment) and are scheduled to go when `backlog:51` closes on the week. That is a 36-route, two-role run whose window closes on the 16th. HO 709 either takes it or records the decline in its block; 708 only puts the date on the table.

## Gates

`typecheck` 0 · `build` 0 · `check:odds-sites` 0 · `check:design-citations` OK, run immediately before the paste; regression gates on a docs-only tree, and named as such. No render-touching change, so no captures, stated so the absence is not read as an omission. Backlog numstat: **1** deletion (`:14` re-emitted, original contained; prove containment, do not eye it); roadmap and oddities **0**; SKILL **1/1** (the `:2577` line rewritten in place); method (if it exists) **0**. No struck text removed anywhere.

## Review ref, FF

`708-review`. Docs-only, so `ci.yml` does not fire (`paths-ignore`) and `design-citations.yml` is the one pre-FF run. Architect read; SKILL slot; FF from a file; `verify:deploy` five reads; then the Production `deployment_status` smoke run's id, conclusion and per-route `pageErr=` lines, recorded in the closing paste as an extra sample on the shipped build and **not** counted among the seven dailies `backlog:51` is waiting on.

read and follow 708
