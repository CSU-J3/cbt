# HO 712 — the 120th-Congress rollover: `sync:members` stops hardcoding 119, and every other seam is named before January

Code kind, enumerate-first. Closes backlog :77 (`sync:members` hardcodes the 119th Congress, so the 2028 House half cannot arrive) and produces the one thing the repo does not have: a list of what happens on 2027-01-03 to every congress-scoped path, each with a decision attached. Independent of HO 711; either lands first.

## Ground truth at authoring (`main` at `e714a53`, 2026-09-10; re-derive at STEP 0)

- **Number and base.** Authored 2026-09-10 at `e714a53` beside HO 711; **re-issued 2026-09-11 with `main` at `ad63b85`** after HO 711 landed. Pointer 711, highest HO in commit subjects 711 → 712. Every anchor below was re-read at `ad63b85` and holds (`sync-members.ts:37`, `committees-sync.ts:27`, `meetings-sync.ts:19`, `sync-career-votes.ts:32`, `votes-sync.ts:51`, `queries.ts:1026`); HO 711 did not touch these files. It did run `sync:members` on 2026-09-11 (2 added, 16 marked departed), so the row-4 counts are post-resync, and the ledger stands at 249 live / 250 struck.
- **The repo already knows the date.** `lib/congress.ts:1-8` `getCurrentCongress(date)` rolls at January 3 of the odd year (2027-01-03 → 120); `currentCongressLabel` feeds the breadcrumb (`components/BreadcrumbMasthead.tsx`). The syncs that already derive: `lib/sync.ts` (bills), `lib/votes-sync.ts`, `lib/senate-votes-sync.ts`, `lib/amendments-sync.ts`, `lib/nominations-sync.ts`, `lib/lda-sync.ts`, `lib/bill-id-extract.ts`, and four diagnostics. The established pattern is derivation; the hardcodes are the anomalies.
- **The hardcodes.** `scripts/sync-members.ts:37` `const CONGRESS = 119` (and its summary copy at `:422` *119th members marked is_current = false*); `lib/committees-sync.ts:27` `const CONGRESS = 119`; `lib/meetings-sync.ts:19` `const CONGRESS = 119`; `scripts/sync-career-votes.ts:32` `const LATEST_CONGRESS = 119`; `lib/votes-sync.ts:51` `CONGRESS_119_START = "2025-01-03T00:00:00Z"` (a dated floor beside a derived congress — read how it is used); `lib/queries.ts:1026` `congress: 118 | 119` with `CONGRESS_START` at `:1033` and literal `119` at `:1059` / `:1090` (a two-congress comparison series; a product question at rollover, not a constant to flip). `scripts/backfill-historical-laws.ts:17` is a deliberate one-shot at 118 and is not a seam.
- **What `sync:members` does with the number.** Pages `/member/congress/{CONGRESS}` and `?currentMember=true` (`:12-13`, `:250`), upserts the roster, marks roster-absent rows `is_current = 0` (`:407-409`), derives `next_election_year` from class or term (`derive-term.ts`) with the special-election overlay. Manual, quarterly-plus (SKILL, `sync:members`). On 2027-01-03 the same script against 120 is exactly the rollover: new members added, defeated and retired members marked non-current, every House `next_election_year` rolling to 2028, which is what mints the 2028 House rows through `backfill:races` and what `/electoral?cycle=2028` waits on (HO 710).
- **The API side is a fact to measure at the time, not now.** Whether `/member/congress/120` is populated on the morning of January 3 is unknown today; the derivation must not turn an empty roster into 536 rows marked non-current. `:407` runs `UPDATE members SET is_current = 0 WHERE bioguide_id NOT IN (roster)` — with an empty roster that inactivates everyone. No guard exists.

## The rule, pre-stated

- **Derive by date, override by flag, refuse the empty roster.** `sync:members` takes `getCurrentCongress()` by default and `--congress N` to pin; before any write it requires the fetched roster to be at least a floor (a fraction of the prior current count read from the table, not a literal) and aborts with the counts otherwise. The summary copy names the congress it ran (`${congress}th members marked …`). This is the fix for :77 and it is small.
- **The other seams are decided one by one, not flipped together.** For each hardcoded site STEP 0 states what the path fetches, what the API returns for a congress that has just begun, and what the cron would do with an empty or partial answer. Three dispositions are possible: **derive now** (safe on an empty answer, or not a cron), **derive with a guard** (like the roster floor), or **keep and list** (a product question or an API-timing risk that wants a human on the day). The list becomes one dated backlog line, *120th-Congress rollover checklist, 2027-01-03*, owner Corey/Code, with every seam, its disposition, and its instrument reading.
- **The comparison series is a product question.** `congress: 118 | 119` chooses which two congresses the enacted-laws chart compares; after rollover the honest default is probably 119 vs 120 with 120 near-empty for months. Not decided here; named on the checklist for Corey.

## STEP 0 — enumerate, then HALT

| # | check | expected | reads if nothing happens |
|---|---|---|---|
| 1 | `grep -rn "119" --include=*.ts --include=*.tsx app lib scripts \| grep -v "CD119\|119-hr\|119-s-\|119-h\|// "` and a second pass for `118`; classify every hit: derived / hardcoded seam / literal in test data / historical one-shot | the six seams above plus whatever this finds | a seam missed today is a silent wrong pull in January |
| 2 | for each seam: the endpoint it hits, read from the code; what an empty response does to the table (any `UPDATE … NOT IN`, any cursor reset, any delete) | a per-seam sentence | — |
| 3 | `getCurrentCongress` at `2027-01-02T23:59Z`, `2027-01-03T00:00Z`, `2027-01-03T12:00Z` (UTC boundary vs the noon ET swearing-in): the function returns 120 from UTC midnight on the 3rd; state whether any seam cares about the twelve-hour gap | 119, 120, 120 | — |
| 4 | `sync:members` current counts: `SELECT COUNT(*) FROM members WHERE is_current=1` and the roster size the script last read (`:13` says 536) | the floor's basis | — |
| 5 | `lib/votes-sync.ts:51` usage: what `CONGRESS_119_START` floors and whether it pairs with a derived congress | a sentence | a votes pull floored at 2025 in 2027 |
| 6 | `lib/queries.ts:1026-1090`: which route renders the series and what it would show with `congress` = 120 near-empty | the product question stated | — |
| 7 | SKILL exposure: `grep -n "sync:members\|119th\|/member/congress\|committees-sync\|meetings-sync\|career-votes" .claude/skills/cbt/SKILL.md` | the entries to amend | — |

**HALT** with the closure table: seam · what it fetches · empty-answer behaviour · disposition · instrument. Corey reads it; STEP 1 builds the *derive now* and *derive with a guard* rows and lists the rest.

## STEP 1 — build

- **Commit 1 — `feat(HO 712): sync:members derives the congress, takes --congress, refuses an empty roster`** — `scripts/sync-members.ts`: `getCurrentCongress()` default, flag override, the floor guard with its counts printed, summary copy parameterised; the header comment (`:12-13`) rewritten to the derived form.
- **Commit 2 — `feat(HO 712): <seams the table marks derive>`** — one commit for the set, each site's comment naming its disposition and the date it was decided; guards where the table says so.
- **Commit 3 — `test(HO 712)`** if the harness reaches these; otherwise the STEP 2 scratch carries the assertions and the commit is skipped and said so.

## STEP 2 — proof

- Build then typecheck, exit codes. No render is touched unless a seam is a page; captures only if so.
- `sync:members --congress 119` against prod: a **no-op run** — `Newly added: none`, `marked is_current = false: none`, row count unchanged, `next_election_year` histogram unchanged (read before and after). The derived default must equal 119 today (`getCurrentCongress()` printed in the run header).
- **The guard is proven from a fixture, not by starving prod:** a scratch calls the roster-floor check with an empty array and with a half-size array against the table's current count and shows both abort with the counts in the message; the full-size case passes. Never run the real script against a congress the API has no roster for.
- For each *derive* seam: a dry read of the endpoint at the derived number equals today's hardcoded pull (same congress, so byte-identical response shape), quoted.

## STEP 3 — SKILL (own commit)

`sync:members` entry: the derivation, the flag, the floor guard, the rollover paragraph (what one run on 2027-01-03 does and what it mints downstream). Each amended seam's entry gains its disposition sentence. A new standing paragraph under the data-sources or scripts section: *Congress rollover* — the checklist's location and the rule that a hardcoded congress number is a seam to be named, not a constant to be trusted.

## STEP 4 — docs

Backlog: strike :77 with the run reading; new line *120th-Congress rollover checklist (2027-01-03)* carrying the closure table's *keep and list* rows, the comparison-series question for Corey, and the instrument each reads if untouched. Roadmap `Also (HO 712)` block. Oddities: two entries **carried from HO 711**, filed here because 711's ref had already been read when they surfaced. (1) *Two Grahams* — the one-shot's draft header read `S-SC-2030 — Graham, is_current = 0` and the review took the bare surname for the sitting senator; the row's incumbent was Lindsey Graham `G000359`, departed, while Darline Graham `G000608` holds the seat. A committed record carries the bioguide, never the bare surname; the same shape as the `-AL-` substring entry. (2) *The RSC flight payload doubles a class-name count* — a raw `so-tag--*` sweep over served HTML read 0 / 2 / 4 where three tags rendered, because the flight payload repeats every `className`; anchoring on `class="so-tag so-tag--x"` separates the two populations and they halve exactly. Instrument-shape, same family as the swallowed `catch {}`. A third entry only if STEP 0 finds a seam whose empty-answer behaviour is destructive and quiet.

## STEP 5 — review ref, FF

`712-review`, `git ls-remote --heads origin`, paste, hold for the go.

## Paste-back

The closure table; per-commit `--stat`; the no-op run's before/after readings; the guard's three fixture cases; the seam dry reads; SKILL and docs diffs with numstats; `git ls-remote --heads origin`.

read and follow 712
