# HO 725 — FF go (architect, 2026-09-14). Read off the ref; one live string still lies by a number and lands as a second `chore` before the FF; then `HEAD:main`.

Read off `review/725` at `d1d9342`, `main` `1a08921` its ancestor. The chore diff is the ruling as written: the counter increments before each goto in `openMeasured` and the ladder, the crawl's guessed `+= 1` and the constant `+ 2` are gone, the planned line carries the legs term first, the ledger prints the sum and its parts with `legs N (counted) / M (defined)` beside it, and the uncounted classes are named on the line and in the comment. The readings are the ones the handoff asked for and one it did not: 4 → 12 on the same route, the proxy's independent 12 on both runs, the mismatch control firing at 9 / 10 with the proxy reading 11, the `home` bridge identical to `1813c9e`. Every departure is accepted, and two of them are corrections of the handoff: the `LEG_A`-filter control could never fire because the defined count moves with the filter, and the constant had to live at module scope because the planned line prints before leg B runs. The prefetch line reads as ruled, first evidence named as evidence, the sibling carrier named last.

## 1. The `FALSIFICATION: FAIL` message computes its number

*"halting before the crawl. 80 page loads against a broken instrument"* is a live message, printed on the branch this instrument exists to take, and 80 is not a number the tree can produce any more (the crawl after the legs is 54 + 18 = 72, and 2 under `--route`). The header's *"~80"* at `:48` and `:108` describes why the design falsifies first and reads as history; it stays. The message does not: it prints the loads the halt saves, `ACTIVE_ROUTES.length * 2 + narrowLoads`, the same expression the planned line already uses, in the same sentence shape.

Land it as a **second `chore(HO 725)` commit before the docs commit**, so `5834bc2` and the readings the block quotes against it stand:

1. `git reset --soft 5834bc2` is not the move, because the docs changes would land in the index beside a code change. Instead: `git checkout -b review/725-2 5834bc2`; make the one-line change; commit `chore(HO 725): the falsification halt names the loads it saves, computed`; `git cherry-pick d1d9342`.
2. Amend the replayed docs commit's block: *three commits*, the new SHA, and the *Stale and left* bullet rewritten to say the message now computes and the header's `~80` stays as history. Nothing else in the block moves.
3. No re-run: the changed branch is not taken on a green falsification, the expression is the planned line's, and `npm run typecheck` reads the template. Build and typecheck at the new tip, plus `check:design-citations`; the paste carries those readings.
4. `git push --force-with-lease origin HEAD:refs/heads/review/725`; `git ls-remote --heads origin` is the claim.

## 2. One convention, for next time

The ref is `review/725`; SKILL's route names it `<ho>-review` (`725-review`). Nothing here depends on the name, so leave it for this HO and use the documented form on 726.

## 3. Then the FF

`git push origin HEAD:main`, no force; `git ls-remote --heads origin`; delete the ref; local `main` fast-forwarded and `git rev-parse main` pasted; `npm run verify:deploy` on five consecutive reads; the Production `e2e-prod` run's id and its `pageErr=` readings, named as a `deployment_status` sample for the 09-17 ledger re-run. HO 726 then opens with `main` at this tip.

Go.
