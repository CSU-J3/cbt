# HO 693 — the OFF pass: the odds gate becomes a gate

Test/CI kind, with a small code commit carrying a marker. HO 692 gated fifteen prediction-market render sites behind `html[data-odds="off"]` and left one WATCH: a sixteenth site shipped without the class is invisible to every gate the repo has, because the crawl never sets the preference and CI therefore measures the ON path only. A WATCH is a review rule; this HO makes it two instruments that can fail, and retires the WATCH with provenance.

**Why now, and why before 694:** the narrow-viewport work queued next touches races and the bill panel, which is exactly where the WATCH says to re-grep. The gate goes in first so 694 is measured by it rather than remembered against it.

**Two gates, because there are two ways a site slips:**

1. **Static, in `ci.yml`:** a file-level allowlist grep. Every file under `components/`, `app/`, `lib/` whose source matches the market regex must be listed, with a one-word reason (`gated` · `not-a-render-site` · `consumer-of-gated-primitive`). An unlisted match fails the build with a message that says what to do. This catches a from-scratch site in a new file at typecheck time, with no browser.
2. **Dynamic, in the prod crawl:** an OFF-state pass. Market render elements carry a `data-market` attribute; with the preference set before paint, the pass asserts **no visible `[data-market]` element** on each route, plus the doc-scroll invariant in the OFF state. This catches a site built from a primitive (`SourceTag`, `KalshiLine`, the signals tape) that forgot the class, because the primitives emit the marker themselves.

Neither gate catches a from-scratch site in an already-listed file that uses no primitive. Say so in SKILL; do not claim more than the instruments measure.

## Ground truth at authoring (`1adb7a9`, HO 692 shipped 2026-09-04)

- Clone at `1adb7a9`, pointer 692, number `max(692, 692) + 1 = 693`. Re-derive at session open.
- **CI shape.** `.github/workflows/ci.yml` runs `npm ci` → `typecheck` → `build` (`:53–59`) and **no Playwright**. `.github/workflows/e2e-prod.yml` runs the crawl **against prod** on `deployment_status` and a daily schedule (`cron '0 15 * * *'`, `:13`), as `npx playwright test e2e/smoke.spec.ts --grep-invert "@nonci" --retries=2` (`:153`), with the overflow alarm armed on schedule/dispatch only (`:151`). So the static gate belongs in `ci.yml` (pre-merge, no network) and the OFF pass belongs in `e2e-prod.yml` beside the smoke spec.
- **Playwright.** One `chromium` project (`playwright.config.ts`, Desktop Chrome, `retries: 0`, `BASE_URL` defaulting to the prod host). Viewport changes are done in-test with `page.setViewportSize` (the `fit-finish.spec.ts:482–510` doc-scroll loop is the idiom). Anonymous crawl uses `context.addCookies([GATE_COOKIE])` (`smoke.spec.ts:426`) to pass the `ct_seen` gate. `@nonci` in a test title excludes it from CI.
- **The preference.** `lib/prefs.ts` — `odds` row: key `cbt:pref:odds`, attr `data-odds`, values `on|off`, default `on` (absent). The boot script in `app/layout.tsx:96` applies it pre-paint; a Playwright `addInitScript` that sets `localStorage` before navigation is exactly a returning reader.
- **The fifteen sites** (`globals.css` odds block, ~`:3070–3110`, and the 692 roadmap block) and their DOM handles at HEAD: ODDS tape root (`MarketsTape` `className` prop → `MarketsTapeClient` three root branches, `:598/:854/:977`); `/welcome` `styles.taperow` (`app/welcome/page.tsx:367`); `.rc-kpline` (`RaceCard.tsx:97`); `.sb-mkt-kals/.sb-mkt-poly` (`:443/:452`); the `.rc-diverge` wrapper span (`:473`); `.rc-line--edge` via `--rc-edge` (`globals.css:4048`) — **a colour, not an element, so it carries no marker and the OFF pass does not test it**; the `leader` `odds-only` span (`RaceCard.tsx:314–340`); `.race-grid-foot` (`CompetitiveRacesStrip.tsx:111`); two `.races-hero-cell` (`RacesHeroBand.tsx:52/61`); `.race-list-diverge` (`RaceListView.tsx:184`, `visibility: hidden` on OFF — **`:visible` treats `visibility:hidden` as not visible, so the same assertion covers it**); the readout clause span (`:324`); `.racecard-kalshi` (`race-cells.tsx:68`, three consumers); the modal export string (`RaceDistrictModal.tsx:38`, **text not DOM — covered by `odds-toggle-692.ts`, not by this pass**); the bill-panel ODDS block (`BillExpandPanel.tsx:829–831`).
- **Primitives that can emit the marker for every present and future consumer:** `SourceTag` (`components/SourceTag.tsx:17`, the K/P letters), `KalshiLine` (`race-cells.tsx:51`), `MarketsTapeClient` when `kind === "signals"`.
- **The 692 STEP 0 grep** (`kalshi|polymarket|SourceTag|impliedPct|favoriteLabel`, `--include=*.tsx`) returned the gated files plus four more, all classified: `app/welcome/panels.tsx` (news `sourceTag()`, a false positive on the word), `CompetitiveRacesBlock.tsx` (comment only), `RaceMapCard.tsx` / `RaceDistrictCard.tsx` (consumers of `KalshiLine`). That set is the allowlist's first draft.
- **BotID withholds the tape headless on prod** (SKILL, e2e). The OFF assertion "no visible marker" holds whether the tape rendered or not; the **ON control** must therefore anchor on an element BotID does not withhold — the K/P line on `/` — never on the tape.

## STEP 0 — enumerate, then proceed (no HALT expected; flag what surprises)

| # | candidate | expected |
|---|---|---|
| 1 | CI shape at HEAD | `ci.yml` typecheck+build only; `e2e-prod.yml:153` the single Playwright line; both as cited. If the smoke line has grown a second spec, show it |
| 2 | the regex over the tree | `grep -rniE "kalshi\|polymarket\|SourceTag\|impliedPct\|favoriteLabel" components app lib --include=*.tsx --include=*.ts -l` — every file classified into the three allowlist reasons; the count vs 692's reading; anything new since `1adb7a9`, named |
| 3 | marker plan per site | for each of the fifteen: **primitive emits** (SourceTag / KalshiLine / signals tape) or **explicit attribute** on the gated element; the edge accent and the export string listed as not-DOM-testable with why |
| 4 | `:visible` semantics | Playwright's `:visible` excludes `display:none`, `visibility:hidden`, and zero-size boxes — confirm against the installed version's docs, since the diverge column relies on the middle case |
| 5 | ON control anchor | `.rc-kpline [data-market]` on `/` renders headless against prod (BotID does not touch it); count > 0 in the ON state is the control |
| 6 | SKILL exposure | the 692 standing-rule sentence (adding a site), the e2e / smoke-crawler section, the CI section (HO 573), the `SourceTag` mention in the `/` entry; the 692 WATCH text in the backlog. Expected four touches |

## STEP 1 — the marker (code commit)

- `data-market` (value: the venue where one is known — `kalshi` · `polymarket` · `signals`; otherwise `1`) emitted by: `SourceTag` on its span; `KalshiLine` on its root; `MarketsTapeClient` on all three root branches when `kind === "signals"`. Explicit on: the two diamond spans, the `.rc-diverge` wrapper span, the `leader` `odds-only` span, `.race-grid-foot`, both `.races-hero-cell`s, `.race-list-diverge`, the readout clause span, the bill-panel ODDS block, `/welcome`'s ODDS `taperow`. `.rc-kpline` gets it too (belt for the primitive inside it). **No behaviour change; no CSS reads the attribute.** `tsc` clean, build clean; the 692 ON baseline (`on-baseline-692.ts` against `on-AFTER.json`) re-read and identical — a marker is not geometry.

## STEP 2 — the static gate (test commit + ci commit)

- `scripts/check-odds-sites.ts` + `npm run check:odds-sites`: runs the row-2 regex over `components/ app/ lib/` (`.ts`/`.tsx`, excluding `scripts/` and `e2e/`), loads `e2e/odds-sites.allowlist.json` (`{ "path": { "reason": "gated|not-a-render-site|consumer-of-gated-primitive", "note": "…" } }`), and exits 1 for any matching file not listed — printing the file, the matching line, and the sentence: *gate it (`odds-only` + `data-market`) and list it, or list it as not-a-render-site with a note.* Also exits 1 for a **listed file that no longer matches** (a stale allowlist is the same disease in reverse). Deterministic, no network, no DB.
- `ci.yml`: a step after `typecheck`, before `build`.
- **Falsification, both directions, before the commit:** a scratch `components/Scratch693.tsx` containing `kalshi` in JSX → exit 1 with the message; a scratch allowlist entry for a file that does not match → exit 1; both removed, exit 0 restored. Quote the three exits.

## STEP 3 — the OFF pass (test commit + ci commit)

- `e2e/odds-off.spec.ts`. Routes: `/`, `/electoral`, `/bills` (then expand the first row so the panel's ODDS block is in the DOM), `/race/${RACE}` (smoke's constant), `/welcome` (no gate cookie — it is the anonymous landing). Per route, at **1440 and 430** via `setViewportSize`:
  - `context.addInitScript(() => localStorage.setItem("cbt:pref:odds", "off"))` **before** navigation; gate cookie as smoke does (except `/welcome`).
  - at `domcontentloaded`: `document.documentElement.dataset.odds === "off"` — the pre-paint proof, on prod, every run.
  - `await expect(page.locator("[data-market]:visible")).toHaveCount(0)` after `load` + the smoke crawl's settle wait.
  - doc-scroll: `scrollWidth <= clientWidth` (the fit-finish idiom) in the OFF state.
  - collectors as smoke attaches them: zero `pageerror` in the OFF state (a `data-odds` attribute set pre-hydration must be invisible to React; 692 proved it locally, this proves it on prod each run).
- **ON control, one test:** `/` with no preference, `[data-market]:visible` count **> 0** and `.rc-kpline [data-market]` present. This is what makes a green OFF pass mean something: if the marker were never emitted, OFF would pass vacuously and ON would fail.
- **Falsification before the commit:** remove `odds-only` from one site locally (the bill-panel ODDS block), run against a local production build → the `/bills` OFF test fails naming the visible element; restore. Quote the failure line. Then the tag semantics: the spec carries no `@nonci`; it runs in CI.
- `e2e-prod.yml:153`: `npx playwright test e2e/smoke.spec.ts e2e/odds-off.spec.ts --grep-invert "@nonci" --retries=2`. The overflow alarm's plumbing (HO 683) reads smoke's writer only — confirm the OFF pass does not feed it and does not need to; a failing OFF test is a red run, which is the alarm.

## Gates

`typecheck`, `build`, `check:odds-sites` (new) all exit 0, read not inferred. Local run of `smoke` + `odds-off` against a local production build (`BASE_URL=http://localhost:3000`): pass counts quoted before and after. One prod run of `odds-off.spec.ts` by hand after FF (`BASE_URL` default) so the first CI reading is not the first reading. No captures owed beyond the ON-baseline re-read; nothing renders differently.

## STEP 4 — SKILL (own commit, self-mod guard) and docs

SKILL: the 692 standing-rule sentence becomes *a new market render site carries `odds-only` AND `data-market`, and its file is listed in `e2e/odds-sites.allowlist.json`; `check:odds-sites` fails CI otherwise, and `odds-off.spec.ts` fails the prod crawl if a marked element is visible with the preference off*, plus the stated limit (a from-scratch site in a listed file that uses no primitive is caught by neither). The e2e section gains the OFF pass beside the smoke crawler; the CI section gains the static step; `SourceTag` gains its marker sentence. Provenance after the sentence, never inside.

Docs: roadmap `Also (HO 693)` + pointer; backlog — the 692 WATCH **struck with provenance** (this HO, both instruments, the stated limit), never deleted; oddities only if something surprises.

## STEP 5 — review ref, FF

`693-review`, ls-remote, architect review, SKILL slot, FF, ref deleted, `verify:deploy`, then the by-hand prod `odds-off` run and the next `e2e-prod` result quoted when it lands (the `deployment_status` trigger fires on this deploy, so it should be the same hour).

## Paste-back

STEP 0 table with row 2's classified file list. After STEP 3: the three falsification exits, the OFF-pass failure line and its restore, local pass counts, the ON-control count. SKILL diff attached. After FF: ls-remote, served SHA, the prod run, the CI run.

read and follow 693
