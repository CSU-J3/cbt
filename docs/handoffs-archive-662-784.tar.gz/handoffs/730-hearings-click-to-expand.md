# HO 730 — `/hearings` meetings expand in place; the floating card keeps the dashboard alone, and gets the third placement it never had

**The popup box is not mispositioned by accident — it has nowhere to go.** `HearingDetailCard` places itself beside its anchor: right of it, else flipped to the left of it, else clamped into the viewport (`components/HearingDetailCard.tsx:71-73`). That logic was written for the pre-HO-611 `/hearings`, where an entry was a cell in a five-column week grid and "beside" meant something. HO 611 made the entry a **full-width one-line row** (`app/globals.css:9981-9990`), so `anchor.right` is now within a few px of the viewport's right edge and `anchor.left` within a few px of its left: the right placement overflows, the flip computes a negative left, the clamp puts the 340px card (`:10056`) at x≈8 — **on top of the rows it is supposed to annotate**, which is exactly what the screenshot shows. No width fixes this. A side-anchored card and a full-width row are incompatible shapes.

So `/hearings` stops using it. **The treatment that replaces it already ships in this repo and needs no mock** — `HearingRow`'s click-to-expand panel (`components/HearingRow.tsx:103-217`, live on `/bill/[id]` and `/committee/[systemCode]` via `HearingMeetingsEmbed`) carries Watch, Recorded votes, Bills covered, Committee and Details: every section the card carries, in a shape that cannot be misplaced because it occupies flow instead of hovering over it. This HO extracts that panel and renders it under the open entry.

**The card is not deleted.** `HearingsDaySchedule` (the dashboard HEARINGS tab) keeps it, and keeping it is deliberate: that schedule sits in a height-pinned glance panel where expanding a row in flow is the `backlog:682` blowout class. What the dashboard does get is the placement the card has always lacked — a below-the-anchor third case for when neither side fits — **conditional on STEP 0 reproducing the overlap there**, because asserting that a defect seen on one surface occurs on another is the unmeasured claim § Handoff discipline names.

**Five commits, kinds unmixed:** `refactor` (three helpers get one home, the panel comes out of the row) · `feat` (the conversion) · `fix` (the card's third placement) · `docs(skill)` · `docs(HO 730)`.

**What the tree reads if this work never happened:** opening any entry on `/hearings` creates a `div.hcal-card` in `<body>`, and `document.querySelectorAll(".hearing-panel")` on that route reads 0 in every state.

## Ground truth (read at `8712236`, `main`; re-derive every `:N` by content)

- **`components/HearingsCalendar.tsx`** — `Entry`, `:106-159`. It opens on `onMouseEnter` / `onClick` / `onFocus` and closes on `onMouseLeave` / `onBlur` (`:138-142`), measuring itself with `getBoundingClientRect()` and handing the rect up. The parent holds `open: {m, rect} | null` (`:178-180`), a 140ms close timer (`:187-198`) and a `pointerdown` tap-elsewhere effect (`:208-218`), and renders the card at `:438-451`.
- **The week-stat tooltip is a different popup and is NOT in scope.** `.hcal-stat-tip` (`:453-481`) positions *below* its anchor and clamps horizontally; it works, and it is why `createPortal` stays imported after the card goes.
- **`components/HearingDetailCard.tsx`** — the flip at `:71-73`; `liveStatus` exported at `:29` and imported by both calendars. `locationText` (`:40-43`) is **byte-identical** to `HearingRow.tsx:40-43`, and `:127`'s inline `m.chamber === "house" && m.recordedVoteDocs > 0` is a second copy of `HearingRow.tsx:76-78`'s `hasRecordedVotes`. `lib/meeting-documents.ts:1-6` asks for exactly the opposite: *"the predicate has exactly one copy. A third rule is a SKILL edit here, not a second copy anywhere."*
- **`app/globals.css`** — the twelve `.hearing-panel*` rules run `:9318-9397` and **every one is element-owned**; no ancestor-scoped selector reaches them, so the panel is safe to render outside a `.hearing-row`. `.hearing-panel`'s `grid-column: 1 / -1` (`:9319`) is inert in a non-grid parent and must **not** be "cleaned up". Its `padding: 4px 12px 16px 38px` (`:9323`) is an indent tuned to the `.hearing-row-btn` caret+time tracks and is wrong for the agenda — hence the modifier in STEP 2.
- **Nothing outside the two calendars touches these selectors.** `grep -rn "hcal-entry\|hcal-card\|hearing-panel" e2e scripts docs/design` returns **zero** hits (the only hits in that sweep are `.hsch-row` in `scripts/diagnostic/hsch-shots-682.ts:88,104`, the dashboard's row, untouched here).
- **`/hearings` is in the narrow gate's route list** (`e2e/routes.ts:55`), so 390 and 430 are a real reading on anything added to the entry row.
- **SKILL `:1870` is the entry to rewrite, and it carries a second stale clause beyond the one this HO creates:** it calls `HearingsCalendar` *"the week grid"*, which `HearingsCalendar.tsx:3-6` corrected to the agenda at HO 611 — *"It is no longer a Mon–Fri grid; that description survived one commit past the grid's removal."*
- **Pointer arithmetic**: roadmap pointer 729 (`docs/roadmap.md:2328`), highest HO in commit subjects 729 → **this is 730**. Open loops at open: **260 live / 263 struck**.
- **Estimates, marked as such.** The card's rendered `left`/`top` on `/hearings` is Corey's screenshot (~2000px viewport, card at the left edge over ~9 rows), **not a reading I took** — STEP 0 takes it. Whether the dashboard's narrower `.hsch-row` reproduces the overlap is **unmeasured**. The post-caret narrow widths are **unmeasured**.

## STEP 0: measure the defect, then HALT

Nothing executes before the table is read. Local production build (`npm run build && npm start`), `ct_seen` cookie on any `/` hit.

| # | check | expected | if it fails |
|---|---|---|---|
| 1 | `git ls-remote --heads origin`; `git status --porcelain`; pointer and highest HO | `main` alone at `8712236`; clean; 729 / 729 → **730** | a second head means an FF is pending |
| 2 | **Reproduce it.** On `/hearings` at 1440 and 2560, open one entry by script and read the card's `getBoundingClientRect()` against the anchor entry's. Report both rects and the overlap area | the card's box intersects the entry list; at 2560 its `left` clamps to ~8 | **no overlap at either width means the premise is wrong — HALT and say so.** Do not proceed on the screenshot alone |
| 3 | **Does the dashboard reproduce?** Same read on `/` (HEARINGS tab), one `.hsch-row`, at 1440 and 2560 | **unknown — this is the measurement** | either answer is fine; it decides whether STEP 3 lands (see STEP 3) |
| 4 | Census the helpers: `locationText` bodies in `HearingRow.tsx` and `HearingDetailCard.tsx`; every site applying `chamber === "house" && recordedVoteDocs > 0` | two identical `locationText`; two copies of the vote predicate | a third copy of either widens STEP 1 — report it, don't absorb it |
| 5 | `grep -rn "hcal-entry\|hcal-card\|hearing-panel" e2e scripts docs/design app components lib` with a **positive control** (`hearing-row` must read > 0 on the same invocation) | the consumers named in ground truth and no others | an unnamed consumer is a scope finding — table it |
| 6 | Baseline the narrow gate **before** the change: `/hearings` at 390 and 430, `over=` per width | `over=0` both (the route's standing reading) | a pre-existing red is filed, not fixed here |

HALT with the six rows and the two rects from row 2. The go arrives as a file.

## STEP 1 — `refactor(HO 730)`: one home for three helpers, and the panel leaves the row

Pure moves. **No render change anywhere**, and that is the commit's own gate.

- `lib/hearings.ts` gains `WATCH_LABEL` (the `Record<Exclude<WatchState,"none">, string>` now at `HearingRow.tsx:30-34`) and `locationText(m)`. It already owns `watchState` and `WatchState`, which is why the labels for them belong there.
- `lib/meeting-documents.ts` gains `hasRecordedVotes(m)`, moved from `HearingRow.tsx:76-78`. `HearingDetailCard.tsx:127`'s inline duplicate is replaced by a call. This is the file's own stated rule arriving, not a new convention.
- **`components/HearingPanel.tsx`** (new) exports `HearingPanel`, the body of `HearingRow.tsx`'s `ExpandedPanel` moved **verbatim** apart from its imports and one added prop: `variant?: "row" | "agenda"`, which selects the container class (`hearing-panel` / `hearing-panel hearing-panel--agenda`). The prop sets a class **on the component**, never an ancestor-scoped override — SKILL's shared-component layout rule.
- `HearingRow.tsx` imports it, drops `ExpandedPanel`, and drops `etDayLabel` from its own imports (only the panel used it).

**Proof this commit is inert:** DOM-identical `/committee/hlig00` and one `/bill/[id]` with meetings, before and after — same element count, same class list, same text, with one meeting row open in both captures. A diff of the serialized open-row subtree is the read, not a screenshot comparison.

## STEP 2 — `feat(HO 730)`: `/hearings` expands in place

**`components/HearingsCalendar.tsx`:**

- `Entry` takes `isOpen: boolean` / `onToggle: () => void` in place of `onOpen` / `onLeave`. Drop the `ref`, the `getBoundingClientRect` call, and `onMouseEnter` / `onMouseLeave` / `onFocus` / `onBlur` (`:138-142`). **`onClick` and `onKeyDown` stay as written**; add `aria-expanded={isOpen}`.
- A caret leads the row — `<span className={`hearing-caret${isOpen ? " is-open" : ""}`} aria-hidden>▸</span>`, the same glyph and class `HearingRow.tsx:255-257` uses. Reusing the class is the HO 611 precedent (the agenda ribbon reuses `.hsch-cell`): a click-to-expand row with no affordance reads as inert.
- `Entry` returns a fragment — the row `div`, then `{isOpen ? <HearingPanel variant="agenda" … /> : null}` as a **sibling**. `.hcal-agenda-day` is a plain block `section`, so no wrapper is needed.
- **State: single-open, client-side, keyed on `eventId`.** `useState<string | null>`, toggling to `null` when the open id is clicked again. Single-open is the repo's idiom on every expanding list (`HearingRow`'s parents, `BillRowList`, `/members`' `?expanded=`); client state rather than a URL param is this surface's own model, where TYPE and CHAMBER are already client state and the route is `force-dynamic`. **A filter change can leave an open id whose entry is filtered out. That is correct and needs no effect** — nothing renders, and clearing the filter restores it.
- **Delete, in this commit, everything the change orphans:** the `HearingDetailCard` import, the `open: {m, rect}` state, `closeTimer` / `clearClose` / `scheduleClose` (`:187-198`), the `pointerdown` effect (`:208-218`), and the card render (`:438-451`). **`createPortal` and `liveStatus` stay** — the week-stat tooltip and `Entry`'s `is-past` class still need them.

**`components/HearingPanel.tsx`:** the Details block gains a fifth key, `Chamber`, reading `m.chamber`. **This renders on every consumer, including the two committee/bill surfaces where the collapsed row already shows chamber** — accepted as mild redundancy rather than adding a prop, because the alternative is either a per-surface flag on a shared component or losing on `/hearings` the one field the card showed that no agenda row carries. Plain text under the existing `.hearing-panel-details .k` styling; the colored `.chamber-h`/`.chamber-s` treatment is scoped to `.hearing-meta` (`globals.css:9212-9217`) and is deliberately not extended here.

**`app/globals.css`**, additive, two rules:

- `.hearing-panel--agenda { padding: 2px 8px 12px 51px; }` — the agenda's own indent, landing the panel under the entry's kind column rather than the row grid's 38px. **Tune this against the STEP 0 capture and report the number you shipped**; the value here is the arithmetic from `.hcal-entry`'s `2px` border + `7px` padding + `3.6em` time cell + `10px` gap, and it is an estimate until it is seen.
- `.hcal-entry.is-open { background-color: var(--bg-row-hover); }` — the `.hearing-row.is-open` idiom (`:9127-9129`).

## STEP 3 — `fix(HO 730)`: the card's third placement — **only if STEP 0 row 3 reproduced it**

If the dashboard overlaps, `HearingDetailCard.tsx`'s `useLayoutEffect` gains a third case: when the flipped-left placement would be clamped into the anchor's own horizontal span, place the card **below** the anchor instead (`top = anchor.bottom + gap`, left clamped to the viewport, the existing vertical clamp still applying). The two existing placements are unchanged, so a card that fits beside its anchor today renders byte-identically.

**If STEP 0 row 3 found no overlap on `/`, this commit does not land.** File the latent case as a WATCH line in `docs/backlog.md` naming the arithmetic and the width at which it would fire, and say in the paste that you skipped it and why. A fix landed on a defect nobody measured is the thing § Handoff discipline was written against.

## STEP 4 — `docs(skill)`, its own review ref and its own explicit approval

`SKILL.md:1870`, the `/hearings` entry. Three corrections, and the diff is approved alone before `main` moves:

1. **The mechanism.** A meeting's detail is now `HearingPanel`, rendered **in flow under the clicked entry**, single-open, client state. `HearingDetailCard` is no longer on this route — it serves `/` alone. Keep the operationally useful half of the old clause with its new referent: the panel mounts on toggle, so it is still absent from the SSR DOM and a served-markup grep still cannot see it.
2. **HO 717's pointer moved with it.** On `/hearings` the recorded-vote link is now the panel's `a.hearing-panel-link`, not `a.hcal-card-votes`; the card's section survives on `/` only.
3. **The stale grid.** `HearingsCalendar` is the two-week agenda, not the week grid — `HearingsCalendar.tsx:3-6` has said so since HO 611.

Also fold the STEP 1 moves into wherever SKILL names the helpers' homes, and note the panel's new `Chamber` line in the `/committee/[systemCode]` entry (`:1868`) so the extra row is documented rather than discovered.

## STEP 5 — `docs(HO 730)`: roadmap block, backlog reconcile

One `Also (HO 730)` block, pointer 729 → 730: the flip arithmetic and why a full-width row has no side, the STEP 0 rects as measured, the dashboard reading and whether STEP 3 landed, the shipped `--agenda` padding, the `Chamber` redundancy as a decision, and the card's surviving consumer. Reconcile OPEN LOOPS at open and close — **260 / 263** at open.

## Gates

- **`npm run build`, then `npm run typecheck`** (build first — a stale `.next/types` reads as a code failure).
- **Captures, not greps.** This is render-touching, so § Gates' own instrument applies: `/hearings` at 1440 and 2560 with an entry open, `/committee/hlig00` and one `/bill/[id]` with a meeting row open, `/` HEARINGS tab with a card open. A paste with no capture reopens the backlog entry that criterion sits on.
- **The freshness discriminator is one selector read on two routes, opposite directions.** After the change, with an entry open: `/hearings` reads `.hcal-card` **0** and `.hearing-panel` **1**; `/` reads `.hcal-card` **1** with a card open. The control is the second half — if `/` also reads 0, the build is stale or the dashboard broke, and the `/hearings` zero proves nothing on its own. Report both numbers.
- **Narrow gate, both widths, against the STEP 0 baseline.** `/hearings` at 390 and 430 with an entry **open**, since the caret is new width on the collapsed row and the panel is new content in flow. Local is a prediction of the CI reading, named as one; the review ref's `narrow-preview` job is a real Ubuntu reading before the FF (method § Environment, HO 703) — take it.
- **Bind check before any curl is trusted;** kill by PID, port-scoped. Never `/api/sync` locally.
- Re-run the cheap gates immediately before the paste and say which reading the paste carries.

## Review ref, then FF

Review branch from the start; explicit path staging; the SKILL diff approved on its own ref; `--force-with-lease` on the ref only; then `HEAD:main` with no force, `git ls-remote --heads origin`, delete the ref, local `main` forwarded with `git rev-parse main` pasted. After the push, the Production `e2e-prod` read and `verify:deploy` — this one changes served bytes, so both are real.

---

read and follow 730
