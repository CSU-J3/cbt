# HO 696 — review reply. Do not fast-forward yet.

Read on the ref, not the paste: `696-review` at `a6e06e5`, seven commits on `3b3d167`, every touched blob LF (carriage returns byte-counted at 0 in all twelve). The scanner, the workflow, the rewrap, the method bullet and the twelve mocks are approved as built; the twelve blob hashes match Table A exactly. Reading the STEP 0 close line as the handoff's pre-ruled defaults was correct, and the soft-reset reorder was the right call.

**The STEP 0 ruling did not reach you.** The relay carried its last line and none of its ten sections; the block says as much. Its items are re-issued here as amendments, with one addition that came from reading two of the committed mocks on the ref. The ref is a workspace until FF, so these are fixups into their owning commits, `--force-with-lease` on the ref only.

## 1. `mock-591-conventions.html` is the C1–C8 dictionary, and its companion is already on the tree

Read on the ref, not inferred. `docs/design/mock-591-conventions.html:6` is `<title>MOCK 591 · layout conventions C1–C8</title>`; its mockbar at `:165` reads `LAYOUT CONVENTIONS C1–C8 · defect ⇄ fixed`; it carries eight `DEFECT`/`FIXED` pairs. That is the artifact `layout-conventions-arc.md:31` describes as *the defect/fixed dictionary* and the HO 604 block recorded as *did not land*: the sweep looked for the name the handoff assigned, `layout-conventions-c1-c8.html`, and the file on disk carried its own (the `welcome-670` shape, HO 670). Its mtime is 08-06, the day of that sweep. And the companion it names at `:166`, `mock-591-dashboard-layout.html`, is `docs/design/dashboard-layout-target.html`: `:5` reads `<title>MOCK 591 · dashboard layout reference</title>`, same mockbar CSS, landed HO 604 C0 under the name it had in `~/Downloads`. So the allowlist's *zero commits touch that path* answered whether the **name** was ever committed, not whether the **artifact** exists, and reproduced the 604 mistake inside the fix for it.

Consequences: SKILL `:1946` is corrected (the visual dictionary is `docs/design/mock-591-conventions.html`, landed HO 696 at the name it carried on disk, title quoted; the 604 expectation recorded as a name mismatch); `layout-conventions-arc.md:31` gets a one-line pointer correction with provenance, riding the `docs(design)` commit; the `layout-conventions-c1-c8.html` allowlist entry is **removed** (no prefixed citation of it remains; `roadmap:425` is bare and outside the grammar); `mock-591-dashboard-layout.html` becomes `historical-name`, its note naming `dashboard-layout-target.html` and the title that identifies it. Four seeded entries, not five. Where a "missing artifact" is recorded from now on, the instrument is the file's own `<title>` read from disk, not a filename grep; that sentence goes in the oddities entry as a third boundary and in the block.

## 2. Reorder once more: SKILL before the gate

With the c1-c8 entry gone, the gate commit only passes as of itself if SKILL `:1946` is already corrected when it lands. So: rule → files → rewrap → **SKILL** → gate → method → docs. Every commit from the gate onward still passes the gate as of itself; say so in the block, with the reason.

## 3. The scanner gains one class: `ORPHAN`

An allowlist entry no tracked file cites is a hole waiting for that name to be cited again, and the c1-c8 removal in §1 is exactly the case that would leave one behind if forgotten. After the walk, every key except `_README` absent from `allowlistHit` is a problem at the allowlist's `file:line`, exit 1. This is the odds gate's second direction (a listed file that no longer matches) in this gate's terms. Falsification **(v)**: a temporary entry for a token cited nowhere reads `ORPHAN`, exit 1; removed, `OK`. Re-run (ii) as *exactly the four tokens*. The README table, the scanner header and the SKILL bullet name the class.

## 4. "Pre-629" is the wrong descriptor, in three places

Table A carried `mock-507`, `mock-509`, `mock-510`, `mock-591`, so the `mock-<HO>-` name has been in use since HO 507 and was first *committed* at 629; G2 sees a 507 mock cited bare. The blind spot is **a mock named outside the convention**, and not every mock follows it (`welcome-formats-mock.html`, `dashboard-layout-target.html`), which is why rule 2 exists. Fix the phrase in `docs/design/README.md`, the scanner header and the new SKILL bullet; fix README rule 2's *"the convention since HO 629"* to *in use since HO 507 (`mock-507-bill-detail.html` is the oldest on disk); first committed at HO 629*.

## 5. Arithmetic and provenance in the shipped prose

- **"24 handoffs before the defect was even filed"** appears in `docs/design/README.md`, the `e750c1f` message and the block. 672 − 428 is **244**; the 24 is 696 − 672, the span from filing to fix. Say both, correctly.
- `.gitignore` comment: *"At the HO 672 close this directory held 20 tracked and 13 untracked"* is false; 672 measured **16 · 15**, and 20 · 13 is what HO 696 found at open. Drop *"four tracked files"* for what Table B measured.
- README "How it got here": 689 and 690 did **not** flag the entry as due; each counted its own mock as one more ad-hoc instance and said the fix was larger than a rider. And *"Four tracked-file citations were broken"* restates against Table B: five dangling tokens at base, two unrecorded (the component's, the 657 record), one recorded as never landed that had sat on disk under another name since 08-06, two whose own sentence says the file does not exist; plus one wrapped path.

## 6. Method: the widening sentence, marked as a widening

Append to the ground-truth bullet in § Handoff discipline, so Corey can strike it in one read:

> The same holds for every factual clause in text a handoff asks to land verbatim: STEP 0 reads it against the tree before it lands (HO 695 and HO 696 each proposed a SKILL sentence naming a repo state the repo contradicted).

## 7. `backlog:45`, the stale momentum layer: annotate, do not close

`stale-momentum-row.html` (2026-06-26, two days after that entry opened) commits at `e750c1f`. Its close is *an enriched-row design mock lands*; whether this file is the ruled row presentation is unrecorded, so one dated annotation line naming the file and that the ruling is unrecorded, and the entry stays in the design chat's court. Caught in relay, filed.

## 8. The `startup_failure` with an empty workflow name: attribute it before FF

A run that fails at startup is the HO 685 shape, a run that exists and does no work, and the one new workflow file is the obvious suspect even though it does not listen to `deployment_status`. `gh run view <id> --json name,path,event,conclusion,headSha,createdAt` names the file; `gh run view <id>` carries the startup error text. If `path` is `design-citations.yml`, it is a defect in this HO and blocks. If it is `e2e-prod.yml` on a Preview event, check whether the same appears on a prior review ref (`gh run list --branch 695-review`); pre-existing is a WATCH, new is a finding. Quote the attribution in the block either way; unattributed does not FF.

## 9. Three shells, twice now

Name them and kill by PID what is yours (SKILL, "Process cleanup"). If they are Claude Code's own background shells from the hash loops, say so; a process supposed to have stopped is verified stopped (method § Gates, HO 672).

## 10. The block and the strike

Roadmap block, amended on the ref: four entries not five, and §1 in full with the two titles quoted; the 244; `ORPHAN` and exit (v); the new order and why; §8's attribution; the method sentence named as a widening. Oddities: Boundary 2 corrected (the companion exists under the name HO 604 gave it; *zero commits touch that path* asked the wrong question) and a third boundary added, *the name the handoff assigned*, with the `<title>` rule and `welcome-670` as the first instance. Backlog `:110` strike: *five entries, not three* becomes four, plus one clause that the never-landed dictionary was on disk.

## Then

Force-with-lease the ref, `git ls-remote`. Paste: the seven new SHAs with `--stat`; the SKILL diff as a gitignored file (the slot reopens on it); the summary lines for exits (i)–(v); the fresh-clone `OK` on the new tip; the `design citations` run on the new tip with its conclusion; §8's attribution; §9's answer. FF go follows the read of the SKILL diff.

read and follow 696 — review reply, amend on the ref
