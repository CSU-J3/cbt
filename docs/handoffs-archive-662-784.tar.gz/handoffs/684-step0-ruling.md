# HO 684 — STEP 0 ruling and scope amendment

**Verdict (Corey, 2026-09-02, verbatim):**

> lets go with The tightest box · 400px grid floor · 95-ch headline (the live max on the board)
> The single-column width the grid bottoms out at. With the clamp, the full 95-ch headline resolves in two lines here; the ellipsis only fires past ~120 ch (corpus max 123). Still the row-6 fix under its worst live load.

The quoted section is the v2 mock's tightest-box card, which wears the full B-side combo. The reference render is `mock-684-badge-chips-v2.html` (chat-side, uncommitted — the `b2-tape-labels.html` precedent); that card is the spec.

**The five decisions, all B:**

1. **NEWS chip** — `NEWS · <headline>`, non-linked glance text, article link stays on the `/race/[id]` hub.
2. **MOVED chip** — `MOVED · <SOURCE> <from> → <to>`; the query reshape proceeds exactly as probed (LAG for from, baseline exclusion preserved, latest-per-race, JSON-plain return).
3. **Casing** — labels stay caps, content span renders as written (`SABATO Toss Up → Tilt R`); source label inside the content span stays caps.
4. **K/P block** — collapsed to one line (scope amendment below).
5. **NEWS body depth** — 2-line clamp, not single-line ellipsis (scope amendment below).

**Code's three defaults, endorsed with one upgrade:** the source short-label map (`cook`→COOK, `sabato`→SABATO, `inside_elections`→IE) stays local to the indicator — but the third-site duplication (`RaceCard.tsx:180-184` + `lib/enums.ts:214` + `RatingChip.tsx:19-28` + now this) gets a **backlog FILED line**, not a comment-only flag. The from-is-null fallback ships unexercised with that stated in its comment. `RacesBoxTabs.tsx:157-164`'s stale HO 282 comment is corrected in the row-9 sweep.

## Scope amendment — Decisions 4 and 5

STEP 1 gains two items, same code commit:

**5. K/P collapse.** `.rc-stats` two-column block → single `.rc-kpline`, the ODDS-tape dual-source idiom (HO 287/303): `K <name> x% · P y%` — K/P letters brand-colored (`--kalshi` / `--poly`), percentages `--text-primary`, favorite name party-colored as today. **Name deduped when both venues name the same favorite** (all six live cards today); both names rendered when they differ; dim `n/a` for an absent venue. `border-top` + `margin-top:auto` retained — still the card's bottom-pinned block.

**6. NEWS clamp.** The NEWS chip body goes `white-space:normal` + `display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden; line-height:1.4`, chip `align-items:flex-start` so the label top-aligns. **MOVED body stays single-line nowrap + ellipsis.**

**Row 6 (overflow audit) amended accordingly:** the clamp takes the NEWS body out of the nowrap class (wrapping text's min-content is its longest word), but the amendment **adds** one nowrap line — the kpline — and MOVED stays nowrap. So `min-width: 0` lands at the card and both chips, the kpline sits inside `max-width: 100%`, and the fit-finish 1440/2560 doc-scroll invariant + M0 remain the durable gates behind all of it.

**Addendum verification — fill inline during STEP 1, flag-don't-absorb; no second HALT unless a row breaks:**

| # | candidate | expected |
|---|---|---|
| 11 | rc-stats JSX site | the KALSHI/POLYMARKET block in `RaceCard.tsx` — confirm one render site and no other consumer of `.rc-stats` / `.rc-stat-*` before touching them (grep) |
| 12 | K/P name fields | the rich row carries per-venue favorite label + pct (the current columns render them); dedupe compares the two labels case-insensitively |
| 13 | SKILL K/P passage | whether the card-anatomy passage describes the two-column K/P block; if yes it joins the `:2262`/`:2264` rewrite in the same SKILL commit |
| 14 | .rc-stats CSS retirement | `globals.css` `.rc-stats` / `.rc-stat` / `.rc-stat-k` / `.rc-stat-v` — delete if row 11's grep shows single-consumer, else leave and note |

**STEP 2 amended:** captures now also evidence the kpline and the clamp — the 430/400px capture must show the 95-ch headline resolved in two lines; the ruling's own sentence is the criterion. The e2e chip-count gate is unchanged (visible `.rc-moved` + `.rc-new` = 9 at a fresh context, control red at HEAD first).

**STEP 3 (SKILL)** gains row 13's passage if present — still one SKILL commit, self-mod guard, diff delivered gitignored for approval.

**STEP 4 (docs)** gains: the height math for the roadmap block (K/P −11px, clamp +14px, net ≈ +3px against the v1 spec card while the full live-max headline resolves); the source-label-map FILED line.

Proceed: STEP 1.
