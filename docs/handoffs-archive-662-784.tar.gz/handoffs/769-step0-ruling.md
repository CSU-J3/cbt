# HO 769: STEP 0 ruling. No token replay. The ratings source moves to HO 770, and 769 ships the tracker's last two rows and the docs

This ruling first went out as a paste and never reached you. This file replaces that paste, trimmed to what still applies after HO 770's STEP 0.

## The source

P1-P3 stand as you pasted them:
- the plain GET answers 404;
- the table now comes only from a POST to `bpwidget.net/multiwidget`, which carries a signed per-page bearer token and a script-built `loadId`.

**No token replay.** That token is a credential minted for a browser session on Ballotpedia's page. Carrying it into a cron job gets around the gate, however long the token lives.

So § 1 leaves HO 769, and the source question belongs to HO 770. HO 770's STEP 0 ruling, `docs/handoffs/770-step0-ruling.md`, comes in this same relay. P4 and P5 are dropped, because my census and 770's M4 already covered them. Legs A and B leave with § 1.

## What 769 ships

**§ 2, the tracker's matcher, as written:**
- a first-name tie-break;
- a fallback to the state, printed as *matched by state*;
- everything else stays unmatched.

Write to prod before the review push, through HO 768's four gates. Expect House 212 matched; your dry run read 212 and 0.

**Leg C, as written,** in `scripts/diagnostic/tracker-match-769.ts`. The name the handoff gave, `ratings-source-769.ts`, would no longer describe anything in the file.

**Docs:**
- **roadmap:** the HO 769 block. It opens with HO 768's FF readings as you took them, the cold redeploy included. The amended FF go's three docs items land as that go wrote them:
  - the HO 717 oddity paragraph with its corrections;
  - the method.md § Gates CSS-read bullet;
  - the CSS WATCH.

  Then P1-P3, then the tracker.
- **backlog:**
  - The ratings WATCH gains P1-P3's reading and the note *source being replaced (HO 770)*. It isn't struck.
  - The tracker line's unmatched sentence is rewritten whole.
  - Reconcile, control 0.
- **oddities:** one entry, *Ballotpedia's ratings widget moved behind a signed per-page token (HO 769, Oct 2026)*, written from P1-P3. It covers:
  - the 13-byte 404;
  - the POST, with its bearer token, the token's lifetime and the `loadId`;
  - the 435 House and 35 Senate rows the POST returned, as of Oct 6;
  - the ruling that replaying it is out.
- **SKILL:** nothing. HO 770 carries the ratings edits.

**Commits on `769-review`:** `fix` for § 2, then `diag`, then `docs`.

## Then

Push `769-review` and don't paste back. Go straight into HO 770 under its STEP 0 ruling, branched from `769-review`. Paste back once for both, as 770's list has it, with 769's own items:
- the tracker write's output;
- leg C;
- `--stat` per commit;
- `--numstat` for docs, with every deletion explained.

Your two leftover worktrees (`8752512`, `468e692`): keep anything the matcher needs, then remove them.
