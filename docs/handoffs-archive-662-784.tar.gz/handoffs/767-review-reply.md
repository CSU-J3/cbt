# HO 767: review reply. Keep `member_votes`; the Senate tab drops its 2024 column; `8483000` stands; two small fixes, two lines filed and one rewritten; a SKILL fix-up. The SKILL approval and the FF go follow my read of the new commits

The push landed, and `767-review` reads `3ff02111b6a1f228173d3c19fc27b21b60495430`. Everything below goes on top of it as new commits. Nothing is amended and nothing is forced, so the ref only moves forward. If the classifier blocks your push again, Corey runs `git push origin HEAD:refs/heads/767-review` from your checkout, then `git ls-remote --heads origin`.

I read all ten commits on the ref: the readers, the page and its components, the copy sweep, the sync constant, the band fix and its comment, the specs, the legs driver, the block with its backlog and oddities lines, and the SKILL diff. The shared components (`Battlefield`, `CompetitiveRacesBlock`'s `featuredRaces`, `SpreadBar`'s `final`, `CartogramShell`'s `initialView`) leave the dashboard's 2026 output as it was, and `RacesHeroBand` mounts on `/electoral` alone. `getBallotNews` reading 31 days for a page that shows 30 is right: the cache entry can be an hour old at its edge. What follows is what changes.

## R10: keep `member_votes`

The 2s line was there to catch HO 595's full scan. Your later readings show that isn't what happened:
- the first cold run for 101 members took 4,435 ms;
- the rerun took 445 ms;
- connect plus `SELECT 1` took 168 ms;
- the same read over 71 members no earlier run had touched took 254 ms.

A scan wouldn't read 254 ms over untouched members, so the first run's cost was startup, not the read. The read stays, and leg 5 keeps comparing like with like.

The departure goes in the block in these words: *the R10 stop tripped on the first cold read (4,435 ms); Code built on through it and flagged it at the paste-back rather than at the stop; the review kept the read on the 254 ms reading.* method.md § Executing says flag, don't absorb. The flag arrived after the build, and the block says so.

## The Senate tab drops its 2024 House column

Seven of the eight new M1 terms are Senate rows. Their 2024 House cell reads `— senate` on every row of that tab, which makes it a column that's empty for the whole tab (C4: empty states collapse). The ruled mock drew it because today's list mixes the chambers; with tabs, the Senate tab never needs it.
- On the Senate tab the column and its head go. The House tab keeps both.
- Re-run leg 7 on both tabs, using your scratch copy that clicks the tab, and leg 1's Senate captures.
- Re-price register line (xi) with what's left (the heads row at 411px on each tab, and any Senate row still over on Inc. cash's `—`), cited and not subtracted, and restate (iv⁗)'s total from it. Both lines are this HO's and haven't reached `main`, so a new commit edits them.
- The change goes in its own `fix(HO 767)` commit.

## `8483000` stands

It's a correction to the ruled mock (the HO 718 precedent), not a departure to undo. The mock's stand-in band draws its six labels 9% apart, which is the real band's `FEATURED_MIN_GAP`, so it collides at 430 too. Measured on the mock at 430: MI-SEN overlaps AK-SEN and AK-SEN overlaps IA-SEN by 3px each, and two more pairs touch. My checks at 430 read the rows and missed the band. On the same mock the labels clear from 500px up, so the 700px breakpoint (the band's own, as `.races-hero-band`'s) holds with room. The tier counts ran together on the real band only; the mock's, at the same five positions, clear at 430.

## Two small fixes

- In its own `fix(HO 767)` commit: the badge inside the grade card renders with its native `title` (*Palestine Tracker: F (#23)*, no pool), so a pointer resting on it raises a second tooltip over the card. That's what `PalestineBadge`'s trigger branch exists to prevent. The card's badge carries no title, and leg 4 gains a check that it has none.
- In a `chore(HO 767)` commit: `GradeCard.tsx`'s header comment calls the synthesized-leave case *the Tooltip's touch defect*. Leg 4 didn't reproduce that defect, so the parenthetical goes. The guard itself (a touch never opens the card by hover) stays.

## Filed, and corrected

- Line 67 is yours, filed as proposed. The dashboard band's labels and tier counts run together at 430 once the Races tab is open (`captures/band-430-dashboard.png`); it predates this HO. The line also names `/electoral`'s under-700px rule (`.electoral-band`, `8483000`) as the stopgap that a fix to the shared `Battlefield` retires. Code, low.
- Line 68 is new. `/electoral`'s calendar locks paint the MAP only. In LIST, the default since this HO, clicking a bar outlines it and moves the readout, and the states it stacks show only after a switch to MAP. The hint (*click primary dates to stack which states vote then*) promises what LIST doesn't draw. The build did what the handoff said (*the date locks, the hint and the readout work as today*); LIST-first is what opened the gap, and that's on the handoff. The fork for whoever takes it: the readout names the stacked states in LIST, or a lock in LIST switches to MAP. Code, low; Corey rules the fork.
- The Tooltip line doesn't stand as filed. Rewrite it to carry the scroll half only: the panel neither follows nor closes on a scroll, which holds by code (`components/Tooltip.tsx` places it once per open). The touch half becomes one sentence of record. It was the architect's reading on a stripped page (the four handlers alone, Chromium touch emulation), and on the app's Tooltip at leg 4 it didn't reproduce: Playwright's tap opened the panel at 56ms and it stayed through 700ms, and DevTools-style emulation never opened it. *Close* becomes the scroll half alone.
- OPEN LOOPS live goes 66 → 68, control 0.

## The SKILL commit

A second `docs(skill)` commit on top of `3ff0211`, alone like the first, not an amend:
- The general-window subsection states the payload as measured (236 KB of board props in the RSC flight; the page's HTML 210.9 → 156.6 KB gzip; read on local production builds against prod), not STEP 0's 146 KB estimate.
- Where it says the row drops 2024 and cash under 900px, it says the Senate tab has no 2024 column.
- The Tooltip paragraph ends with the line *read at HO 767 and unreproduced as filed*. Only the touch half didn't reproduce; the scroll half holds by code. The sentence says so.
- *opening the grade card (Tooltip primitive)* reads as if the card were the Tooltip, which the paragraph you added says it isn't. Make it a pointer: *(see the Tooltip primitive)*.

I read both SKILL commits on the ref and approve them together. I don't approve a diff I haven't read.

## The block, before the FF

Along with what it already names, the block carries:
- R10's numbers and the departure, worded as above, and the ruling: keep `member_votes`;
- the Senate tab's column, as a correction to the ruled mock (the HO 718 precedent);
- `8483000` as a correction to the ruled mock too, with the mock's 3px overlaps at 430 and its clear from 500px;
- (5)'s *a line for it is proposed in the paste, not filed* corrected to filed at review as line 67, with line 68 beside it;
- the Tooltip line's correction and the two small fixes;
- the measured payload against STEP 0's estimate;
- `8483000`'s wrong commit-message sentence. It stays in history, and the block names it.

## Paste back

- `git ls-remote --heads origin` with the ref's new SHA;
- the Preview `narrow-preview` reading on that SHA;
- leg 7 re-run on both tabs, leg 1's Senate captures, and leg 4 with the badge check;
- `git show --stat` for every new commit, and `--numstat` for the docs commits;
- the reconcile (68 live);
- a last cheap-gate run before the paste.
