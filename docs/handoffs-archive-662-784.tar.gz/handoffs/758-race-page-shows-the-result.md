# HO 758: a decided race shows its result, ruled C. The winner marked from Ballotpedia's box with source and time, the calls kept as history, the odds retired, and the dashboard band turns to results

`docs/backlog.md` OPEN LOOPS, *What a race page shows once its race is decided is unruled, and the general election is 2026-11-03…* (HO 747), owner Corey. Ruled 2026-09-29 on `mock-election-night.html`, verbatim: *"C"*: the result. Nothing renders differently until Ballotpedia marks a winner or election day passes, so this lands dormant and wakes on Nov 4.

**Scope.** The race page (`/race/[id]`) and the dashboard's battlefield band. Out of scope: the `/electoral` hero band's chamber-control pcts (the kalshi ruling governs what a settled market shows), the pre-election copy for a moved or retiring incumbent (*A race card names a stored incumbent who is not on that seat's 2026 ballot…*, still Corey's), and any result beyond Ballotpedia's mark.

## Ground truth (read at `f021528`; re-derive every `:N` by content)

- The reader (`lib/general-ballot.ts`) parses each row's `winner` class and stores only a per-race count, `general_ballot_reads.marked`, by HO 749's ruling that results wait for this one. `general_ballot.read_at` is the read's time. HO 747's census and every pass since read `marked` 0 everywhere.
- Louisiana's six House races have no general box: their Nov-3 contest is a Ballotpedia *Nonpartisan primary* box (`HOUSE_PRIMARY_OVERRIDES`, `lib/primaries-sync.ts`, `jungle`, runoff 2026-12-12), read by `/api/cron/primaries`, whose winners land in `primary_candidates`. HO 748 made the harvest skip `jungle` rows pending this ruling, so those six pages publish no roster today.
- The race page: `components/RaceHeader.tsx:32-38` prints *Election today* / *Election concluded* from `daysToElection` (`lib/format.ts:139`); rating chips render from `race_ratings`; the odds chip from the Kalshi seat market, already dropped past `close_time`; the incumbent card from `races.incumbent_bioguide_id`; the roster from `getRaceRoster` (HO 757), whose statuses are `won_primary`, `nominee`, `advanced`, `on_ballot`, `withdrew`.
- `components/Battlefield.tsx:19-22` hardcodes `Date.UTC(2026, 10, 3)` and clamps at 0, and `:123` prints *ELECTION DAY · NOV 3 · N DAYS · ~M competitive seats*.
- `race_candidates` names for ballot-sourced rows equal `general_ballot.name` for the same race, so a join on `(race_id, name)` reaches the mark.

## STEP 0

1. HO number from the tree: `main` at `f021528`, pointer 757, so 758. Otherwise stop.
2. Re-read every cited `:N` by content. Flag a drift.
3. Measure, prod, SELECTs only: `marked` is 0 on every read (the premise this lands dormant on); the rated index size (the band's *of M*); the six Louisiana races' `primary_candidates` rows and statuses; the races whose stored incumbent is not on their own ballot (the class line's count), which are the *not on the ballot* qualifier's set once decided.
4. Carry HO 757's POST and HO 756's two `:05` tick readings into this HO's roadmap block.
5. Proceed without a halt.

## The build

1. The reader stores the mark: `general_ballot.marked INTEGER NOT NULL DEFAULT 0` from the row's `winner` class. The count column stays. Migrate before the review push, since a page reads the column (method.md § Environment).
2. Louisiana: the harvest's `jungle` rule replaces the skip. Before a mark, every candidate in the Nov-3 box publishes as `on_ballot`. With exactly one `winner` marked, that row is the result; with two, both publish as `advanced` and the page reads *Runoff Dec 12* from the override's `runoffDate`. The LA line struck at HO 748 is re-opened as annotated, and closes again on this build's legs.
3. `getRaceRoster` joins `general_ballot` on `(race_id, name)` for `marked` and the read's `read_at`, and for Louisiana reads the jungle box's marks from `primary_candidates`.
4. The race page, once `daysToElection(cycle) < 0`:
   - header: *Decided · Nov 3, 2026* when any roster row is marked, *Runoff Dec 12* for Louisiana's two-marked shape, otherwise *Not yet called*;
   - rating chips dimmed and prefixed *final call ·*; the odds chip not rendered;
   - the incumbent card gains one qualifier: *re-elected* when the incumbent's row is marked; *defeated* when the race is decided and the incumbent was on the ballot unmarked; *not on the ballot* when the incumbent isn't on the race's ballot (the class line's fact, computed at HO 750); *runoff Dec 12* for the Louisiana shape;
   - the roster: the marked row's status reads *Elected* in the OK colour; every other row keeps its status;
   - a provenance line under the roster: *Called by Ballotpedia · read <read_at, MT>* when decided, otherwise *No call on Ballotpedia · read <read_at, MT>*.
   Before election day nothing on the page changes.
5. The battlefield band, once election day has passed: *RESULTS · NOV 3 · N of M competitive seats called · House R x · D y · z open · Ballotpedia, read <latest read_at, MT>*, where N counts rated seats with a marked row, x and y count marked House rows by party letter (a fusion line by its first party, an `I`/`L`/`G`/`O` winner as *other*, shown when nonzero), and z is 435 less the called seats. Before election day the band is unchanged.
6. A clock seam for the legs: `daysToElection` and the band read *now* from one helper that a test can set; production never sets it.

## Legs, on a `file:` copy, render-touching, each red first

Seed the copy from prod (`races`, `race_candidates`, `general_ballot`, `general_ballot_reads`, `race_ratings`, `primaries`, `primary_candidates`, `members`), plant marks by hand (no prod row is marked), and set the clock to Nov 4.

1. Dormant: with the clock at today and no marks, every page and the band render byte-identical to HEAD. Red would be any difference.
2. Re-elected: an incumbent's row marked; header *Decided*, chips dimmed, no odds, *re-elected*, *Elected* on the row, the provenance line with the read time.
3. Open seat: a challenger marked on a race with no incumbent on the ballot; *Elected* on that row, *not on the ballot* on the card.
4. Defeated: an incumbent on the ballot, another row marked; *defeated*.
5. Not called: the clock past election day, no marks; *Not yet called*, chips dimmed, the *No call* provenance line.
6. Louisiana: two marked in the jungle box, *Runoff Dec 12*, both `advanced`; one marked, that row *Elected*.
7. The band: with 61 of 94 rated seats marked and planted House totals, the RESULTS line reads those numbers; before election day it reads today's.
8. Captures from the review ref's Preview at 1440, 2560 and reduced motion for legs 2, 3, 5 and 6, and the band, against HEAD's before. Nine or more shots.

## Commits and docs

- `feat(HO 758)`: the column and migration, the Louisiana rule, the roster join, the clock seam.
- `fix(HO 758)`: the race page, the incumbent qualifier, the band.
- `diag(HO 758)`: the legs driver.
- `docs(skill)`, its own commit, approval requested: the race page's decided state and provenance, the band's results line, `general_ballot.marked`, the Louisiana rule, the clock seam.
- `docs(HO 758)`: strike the election-night line with the ruling verbatim; annotate the Louisiana line (skip replaced by the rule) and the class line (the post-election qualifier lands here, pre-election copy still Corey's); file one WATCH: the first Nov-4 read, owner Code, dated Wed 2026-11-04 (`date -u -d 2026-11-04 +%A`): a manual `sync:general-ballot -- --all --write` at 6s pacing after 8am MT, then the harvest POST, then the pages and the band read on Production; the roadmap block, pointer 757 → 758, carrying HO 757's and HO 756's readings. Reconcile OPEN LOOPS at open and close, control at 0.
- Review ref `758-review`. The FF is held for the SKILL approval, the captures and review.

## Paste back

- STEP 0's readings;
- the eight legs with the captures;
- the SKILL diff, for approval;
- `git show --stat` per commit, `--numstat` for the docs commits, the reconcile, the `758-review` SHA from `git ls-remote`, and a last cheap-gate run.
