# HO 700 — the `:50` successor: a snapshot at fire time from inside the page, and the amplifier in dev mode

Test kind (the crawl's dump gains a channel), one probe, SKILL alone, docs. Closes nothing by itself; it is the instrument the `:50` entry named as its successor's first question, pointed at the first tree this repo has that fires on demand. Two arms, cheapest first; either can name the node, and the second is the durable one.

**Why now.** HO 687's dump reads the SSR bytes exactly and the DOM **after settle**, so its `addedInDom` is a superset of the mismatch: the two live captures localize to the markets tape and the races NEW/MOVED chips, and both regions also change legitimately after mount (the marquee `copies` fill, the chips' localStorage read), so the dump cannot say which of the two it is seeing (`backlog:50`, the caveat paragraph). HO 697 left `ho697-prefix-clock` (`40c3397`), a tree that fired 3 · 3 on consecutive local production crawls while `main` read 0 · 0 in the same window, and the finding that `main`'s own rate moves within a day (0 in 3 at one hour, 3 in 4 at 21:45–21:53Z). So there is now something to point an instrument at, and an hour to do it in.

**Two facts from the entry that bound the design, so they are not re-derived:** every prod fire is `args[]=HTML`, the **structural** variant (a node present on one side and not the other), never `text`; and production React's message is byte-identical for every structural mismatch anywhere in the app, so only development React can name a component (`react-dom-client.development.js` appends the owner tree; the HO 590 harness already parses it, `scripts/diagnostic/hydration-clock-harness-590.ts:8–9`, `:71`).

## Ground truth at authoring (fresh clone at `15cde5e`, HO 699 shipped 2026-09-07)

- Pointer 699, highest HO in commit subjects 699 → 700. Re-derive at session open.
- `e2e/smoke.spec.ts`: `page.on("console")` `:256`, `page.on("pageerror")` `:263`; `dumpPageErrFire` `:278`, run after `nav()` returns (`load` + 2.5s settle, `:381–384`); the SSR↔DOM alignment is an LCS over element tokens (`:120–200`, `addedInDom` / `removedFromSsr` / `lcsIns` / `lcsDel`, `GUARD-SKIPPED` above a size cap), evaluated in-page via `new Function("ssrHtml", src)` (`:307`); dumps gzipped under `test-results/`, uploaded on file presence. `GATE_COOKIE` `:94`, applied `:364` / `:561`. `playwright.config.ts:16` `retries: 0` locally; `--retries=2` on the unattended run absorbs fires into `flaky` and a green conclusion (the entry's own method note).
- The 590 harness: `BASE_URL` default `localhost:3000`, **refuses non-localhost** (`:127`); its `control(+0)` arm installs no skew; it captures `pageerror` messages with stacks and `console` errors (`:82–83`), parses the DEV owner tree (`:71`), classifies `HTML` / `text` (`:57`, `:92`). It has only ever been run with manufactured skew; `control(+0)` on `main` at 589/590 never fired.
- The two tags: `ho697-prefix-clock` = `40c3397` (tag + clock, pre-shape-fix, + font; 3 · 3), `ho697-clock` = `65f866c` (post-fix mount). Both on the remote.
- React 19 reports a recoverable hydration error from the commit that client-renders the failed boundary; `reportError` dispatches an `ErrorEvent` on `window` **synchronously**, in the same task as the commit. Passive effects (`useEffect`) flush in a later task; layout effects flush inside the commit. **Consequence, stated as a hypothesis this HO measures rather than assumes:** an in-page `error` listener installed before hydration sees the client-rendered boundary **before any `useEffect` output exists**, so a snapshot taken there contains the mismatch and none of the marquee fill or the localStorage-driven chip changes — provided those are passive effects, which STEP 0 row 1 reads off the components.

## STEP 0 — enumerate, then proceed (HALT only on row 3)

| # | check | expected |
|---|---|---|
| 1 | every post-mount DOM change in `MarketsTapeClient` and the HO 684 chip components, with the hook that produces it (`useEffect` vs `useLayoutEffect`) | the marquee `copies` fill and the chips' localStorage read are `useEffect`; a `useLayoutEffect` among them changes the subset test in STEP 1 and is named |
| 2 | `git worktree add` of `40c3397`, `.env` sourced, `next build && next start` on a bind-checked port; two production crawls of the route set to confirm the amplifier still fires at this hour | ≥ 2 fires across the two crawls (estimate from 697); **0 · 0 is a HALT** — the arm has nothing to snapshot and the hour is the first suspect |
| 3 | `main` at `15cde5e`, same procedure, two crawls, interleaved with row 2 | recorded, not gated; this is the same-hour control |
| 4 | SKILL exposure | *Playwright smoke crawler* carries the dump contract and the measured floor; a new channel is a SKILL sentence. Expected 1–2 touches |

## STEP 1 — the dev-mode arm (probe, commit 1, `chore(HO 700)`)

`scripts/diagnostic/pageerr-dev-700.ts`, tracked: a thin driver over the 590 harness's capture path (import or lift `ownerFrames` / `variantOf`; do not duplicate the skew arms) that runs **`control(+0)` only**, N loops over `['/', '/dashboard-v2', '/president', '/members', '/bills']`, hit 1 and hit 2 each, against `next dev` of the amplifier worktree; then the same against `next dev` of `main`. N = 10. Every fire is written with its **full DEV message and owner tree**, variant, route, hit and wall clock. Output: fires per tree, and for each fire the first owner frame that is an app component.

Three readings: **fires in dev with an owner tree** → the node is named and the rest of this HO becomes confirmation; **dev never fires on the amplifier** while row 2 fires it in production mode → dev-mode timing hides the class, recorded, and the durable arm below carries the HO; **dev fires on `main` too** → the same-hour control read, the tree it names is the finding either way.

## STEP 2 — the durable arm: the fire-time snapshot (commit 2, `test(HO 700)`)

- `page.addInitScript` on every crawl page, before the cookie: a `window.addEventListener("error", …)` that, on the first `ErrorEvent` whose message carries `Minified React error #418` or `Hydration failed`, stores `{ t: performance.now(), message, html: document.documentElement.outerHTML }` on `window.__ctFire` (first fire only; later ones counted). Installed before any page script runs, so it precedes hydration by construction.
- `dumpPageErrFire` reads `window.__ctFire` after settle and adds a **second alignment**, SSR ↔ fire-time DOM, computed by the **same** LCS function (`:307` pattern, one implementation), reported beside the existing one as `fire-added=[…] fire-removed=[…]`, with `fire-t` (ms from navigation start). The gzip grows by one HTML; state the new size against the `:318` budget.
- **Falsification, on the amplifier tree in production mode (row 2's server), before the commit:** on every fire, `fire-added` must be a **proper subset** of `addedInDom`, and must **not** contain the row 1 items (marquee copies, chip localStorage changes). If it equals the settled set on any fire, the snapshot is landing after passive effects and this instrument is the wrong tool — said plainly, the commit not made, and the reason recorded. If it is empty while `addedInDom` is not, the listener is missing the event (installed too late, or the message pattern is wrong) — also a failure, also said.
- **What a passing reading means:** `fire-added` is the structural mismatch and nothing else. Name its elements by tag and class in the paste; that list is the first attributable prod-compatible reading the class has ever had, and it ships to the daily crawl on FF.

## STEP 3 — SKILL (alone), docs

SKILL, *Playwright smoke crawler*: the dump's second alignment, what `fire-added` is and is not, the subset property as the measured guarantee, and the sentence that `addedInDom` remains a superset and is kept for continuity. Provenance after the sentence.

Docs: roadmap `Also (HO 700)` + pointer, both arms with their readings and the wall clock. `backlog:50` **annotated, not struck**: the fire-time channel and its measured subset property; the dev-arm reading; if STEP 1 named a node, *a named node, not yet a named cause* (the close is cause plus green, and stays). If a node is named, the fix is its own HO with the amplifier as its gate.

## Gates

`typecheck` 0 · `build` 0 · `check:odds-sites` 0 · `check:design-citations` `OK` · the smoke crawl on a local production build of the **tip** (the instrument changes the crawl, not the app; any fire it records is a bonus, and its `fire-added` is quoted) · the STEP 2 subset readings on every amplifier fire, quoted · dump gzip size vs budget · worktree removed, ports freed by port, verified.

## Review ref, FF

`700-review`, `git ls-remote`, architect read (the subset readings and the SKILL diff are the substance), SKILL slot, FF, ref deleted, `verify:deploy`. After FF the instrument is live on the daily; the first prod fire's `fire-added` line is quoted into the block when it lands, however many days that takes, and the block says so.

read and follow 700
