# HO 770 FF go: ruling on Sabato's challenge, and on HO 771's claim 3

## Sabato's challenge

A 403 challenge at your box is your box's reading. The POST runs from pdx1, a different network, and that's the reading that matters, because the cron makes this same request from there on every run. Your box also sent Sabato far more requests than the cron ever will, through legs B and C and the stall probes, and that alone can draw a challenge.

- **If the 18:08Z retry got a 200 and you went on,** nothing changes.
- **If it was refused and you stopped,** POST once on Production anyway.
- **Either way:** one POST, no other retries, and nothing more fetched from centerforpolitics.org from your box today.

What happens next depends on the POST:
- **`success`:** carry on through the FF go as written (the read-back, the flush, the prod reading), then HO 771.
- **`error` at the fetch with Sabato's 403:** pdx1 is challenged too, so don't retry. Do the flush, and the prod reading's tracker and health checks (`/members/G000606`, `/members/M001208`, `/api/health`), skip the ratings checks, and paste. HO 771 waits, because a daily cron against a challenge only turns one red day into seven.

Either way, the paste records each challenge you saw (17:53Z, 18:08Z, and pdx1's if it comes to that):
- the status, the body's size and `cf-ray`;
- `cf-mitigated` and `server`, if present;
- whether the body is a challenge page or a block page.

## HO 771's claim 3

**The rule:** every place that states the ratings sync's schedule as it stands changes with it. Every place that records what it was at the time stays.

**These change, in § 1's `feat` commit:**
- `app/api/cron/news/route.ts:14`: *sync-race-ratings on Wednesdays at 11:00* becomes daily at 11:00 since HO 771.
- `app/api/cron/rating-history/route.ts:4`: *the ratings sync itself is weekly* becomes *the ratings sync runs daily, four hours earlier (HO 771)*.
- `lib/move-freshness.ts:35`: *Sabato's weekly legs* becomes *Sabato's daily legs*.

**These stay:**
- the roadmap and oddities entries, and the struck backlog lines;
- `lib/race-ratings-scrape.ts:39`, the HO 742 era's *two consecutive Wednesdays*;
- `docs/method.md:464`;
- the WATCH *Three crons absent from Vercel's crons dashboard (HO 581)*, which records what HO 581 saw.

Anything else you found falls under the same rule. List each one in the paste with the call you made. Then build HO 771 through to the review push without stopping, as long as the POST read `success`.
