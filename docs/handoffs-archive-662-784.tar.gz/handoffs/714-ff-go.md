# HO 714 — FF go (architect, 2026-09-11)

**Owner verdict, verbatim: "send  it"** — Corey, CBT maintenance chat, 2026-09-11, on the architect's read of `714-review` at `489c414` off the remote: five commits, kinds pure (`feat`, `feat`, `test`, `docs`, `docs(skill)` alone); `9077492` is an ancestor, so the move is a clean fast-forward. The gate was red on both clauses before it was green, the three fixture states differ pairwise in all eighteen comparisons across three viewport configs with the reduced-motion flag read back inside the page, and the served band subtree at `9077492` is byte-identical to the local build at `489c414`. Neither flippable was flipped: the gate asserts, the two sentences stand.

**What this FF is.** The first deploy on which `/` cannot be silent about the Absence Watch, and the first Production run of a smoke assertion that counts a class hook. The rendered bytes today are unchanged (cards present, so neither new branch renders); what changes is what a failed read and a quiet week look like from now on.

## 1. The move

- `git ls-remote --heads origin` immediately before: `main` at `9077492`, `714-review` at `489c414`. Anything else, stop and paste.
- On `main`, the cleanup door: `git merge --ff-only 489c414`; `git rev-parse main` must print `489c414`. `git push origin main`, no force. `git push origin --delete 714-review`. Then `git ls-remote --heads origin` and `git ls-remote --tags origin` (three tags).
- Each state-changing command on its own line, stderr never suppressed. The commit list is `git log --oneline 9077492..main` off the pushed branch.

## 2. The readings

- `npm run verify:deploy` until the served SHA is `489c414`, five consecutive reads; if promotion lags past the timeout, paste the deployment list.
- **Served `/`, with the gate cookie:** `.abw-card` count (12 today, or the day's number), `.abw--empty` 0, `.abw--failed` 0, the header `▲ MIA (n) · AT RISK (n)`; and the band subtree diffed against the STEP 2 capture, zero bytes. Cookieless: `307 → /welcome`, as the rule now says.
- **The Production `deployment_status` run is the point of this FF:** id and conclusion, the group echo, and the `home` line carrying the new `band=N/failed=0` reading, so the first Production pass of the assertion is in the record with its number. `narrow` lines for `home` at both widths, `pageErr=0` across the log, wall time against the cap.
- `ci.yml` conclusion (code moved, so it runs).

## 3. After the FF

Nothing else is owed by this HO. HO 715 is in flight on its own ref with no code; when it lands its two docs commits rebase behind this one. The `votes` allowlist gap stands as filed for Code when called.

## 4. Paste

The `ls-remote` line showing `main` at `489c414`, the ref gone, three tags; `git rev-parse main`; the five-line log; the five served reads; the cookied and cookieless reads of `/`; the Production run's id, conclusion, `home` band line and duration; the `ci.yml` conclusion.

read and follow 714-ff-go — the file, not this line
