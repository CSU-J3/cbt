# HO 710 — review reply (architect, 2026-09-10). Approved as read; two amendments before it lands, one of them in the append-only block.

Read on the ref at `21ac953` against `fdce76b`: seven commits, kinds pure; 802+/13−. The SKILL diff was read by word-diff, and all seven deletions are the in-place amendments the paste says they are (`INTEGER` → `INTEGER,`, `them` → `all three`, `sync.` → `sync (…)`, `function` → `function, and so is …`, `both.` → `all three`, plus the two pure insertions into the `seed:races` and pinned-card bullets). Every clause in the new sub-section matches a STEP 0 reading or the ruling; the two clauses landed as their opposite are the two the ruling flipped, with the reason in the text. Backlog 7+/0−, oddities 32+/0−, roadmap 18+/0−; the OPEN LOOPS figures tie to HO 709's close (246 / 246 → 252 / 246, six additions).

The code: the eight bound parameters were counted against the eight placeholders and the order holds (string, string, number, string, string, number, class, number). The `d` join's `<> ?` and `r.cycle = ?` compare INTEGER columns to a REAL parameter, which SQLite compares numerically, so only the two concatenations needed the string form — your fix is exactly as wide as the defect. Precedence and sort as ruled; the at-large arm as ruled; `partyColor` takes the short abbreviation `members.party` stores. The CSS is additive under `.so-*`, `white-space: normal` on the tag, `min-width: 0` on row and name, no `nowrap`; the C1 fix reads as the rule says it should. The REAL-affinity catch and its proof at 2026 (35 = 35) are the best finding of the HO and the oddity states the general form correctly.

## 1. Two amendments, then re-push the ref

- **`docs/roadmap.md`, the block's first sentence: *Six commits* → *Seven commits*.** The sentence enumerates four `feat`/`test`, one `fix`, `docs(skill)`, `docs`: that is seven, and `git log --oneline fdce76b..21ac953` reads seven. The block is append-only, so a wrong count there is correctable only by a later block; this is the read-before-land route doing its job. Amend `21ac953` in place. Expected numstat on the amend: **1 / 1**.
- **Two code comments overstate the cycle constant.** `lib/queries.ts` says a third cycle *is a one-line change in one place* and `app/electoral/page.tsx` says *one edit in one place*. Neither is true: the 2028 branch is gated on `cycle === 2028`, and its description hard-codes *34*, *Class 3*, *120th* and *2026 contest*. Soften both to the fact: the constant plus the branch and its copy in `app/electoral/page.tsx`. **Fix them up into the commits that introduced them** (`a790562`, `f0cb0c2`) with `rebase -i`, so the count stays seven and the kinds stay pure; the ref is inert and a rewrite there is the sanctioned kind. Comment-only, so the emitted bundle is byte-identical; still run `npm run build` and `npm run typecheck` on the new tip and read their own exit codes, and say the captures were not re-taken because no rendered byte moved.

`--force-with-lease` on `710-review` only; `git ls-remote --heads origin` is the claim.

## 2. Two lines for the paste, no work

- The STEP 0 paste opened with *29 live / 41 struck* and the block reconciles on *246 / 246*. Say in one line what the first pair counted, so the two figures do not sit unreconciled in the record.
- The seeded `open_signal_url` carries a trailing slash; the handoff's ground-truth URL did not. One `curl -sI` on the exact string read back from `S-WI-2028`, status only, so the rendered ↗ is known to resolve as stored.

## 3. Approved as read, for the record

Members-first with the measurement as its reason; the derived TBD and its WATCH; `open_signal` with the guard proven on three bad entries and the `clear` round-trip; the at-large six as `{ST}-AL` with the footnote gated on their presence; the fixture as the falsification surface for the two branches prod cannot show; the content-checked TBD links (`/race/S-ZZ-2026` is 200 too, so a status code was never the discriminator); the `narrow-preview` reading at both widths with `landed=` proving the branch was reached; the six OPEN LOOPS, each with what its instrument reads if nothing happens; the three oddities.

## 4. Then

Paste: `git log --oneline fdce76b..HEAD` off the pushed ref (seven), the amend's 1/1 numstat, the two comment diffs, build and typecheck exit codes on the new tip, the new `narrow-preview` run id and its two `electoral-2028` lines, the `curl -sI` status, the reconciliation line, `git ls-remote --heads origin`. FF go follows the read of the amended tip and Corey's word.

read and follow 710-review-reply — the file, not this line
