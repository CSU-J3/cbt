# HO 686 — the settle windows close today: four reads, one already owed

Ops kind, time-critical: run today, 2026-09-03. Under HO 661's decided-or-expired predicate (`SETTLE_WINDOW_DAYS = 30`, `lib/primaries-sync.ts:541`, floor derivation `:543-548`), an unfrozen contest is re-check-eligible until its floor passes, then settles regardless of whether anyone marked a winner. Four rows are in play: `house-AZ-03-2026-R` floored **2026-08-20** (the read is 14 days late — this HO pays that debt), and `house-VA-10-2026-R`, `house-WA-05-2026-open`, `house-WA-08-2026-open` all floor **today**. The owed read per row, per the filed entry: did Ballotpedia mark a winner before the floor passed? Healed → nothing owed. Unhealed → the row settled (or settles today) wrong, and the recovery is `backfill:primary-results` / `reingest:primary-slate`, scoped to that contest.

Expected commit shape: possibly docs-only. If the reads all come back healed, this HO writes nothing but the strike.

## Ground truth at authoring

- Clone at `ab44d3d`, pointer 685, number `max(685, 685) + 1 = 686`. Re-derive at session open.
- The filed entry is in `docs/backlog.md` (the "Two HO 661 settle windows expire" line — locate at HEAD, numbers drift). Its four floor dates are **claims to re-derive**, not facts: recompute each floor from the row's unfreeze date + the predicate before trusting 08-20 / 09-03.
- The designed read instrument exists: `scripts/diagnostic/settle-predicate-661.ts`. Per the house rule, validate it against a known-positive first — one contest known settled-and-healed — before trusting its readings on the four.
- `race_candidates.updated_at` was wired after HO 661 (the struck QUEUED entry), so "did the winner land before the floor" is decidable post-hoc for AZ-03, not just bracketed. Confirm the column's presence and semantics before leaning on it.
- Both recovery scripts exist (`scripts/backfill-primary-results.ts`, `scripts/reingest-primary-slate.ts`, package.json:21-22). Their **write scope and targeting arguments are unverified** — row 4 below.
- Adjacent open families these reads may produce evidence for — **file, don't chase:** the `isSettled` scored-instant freeze ("parent of the 11"), the HO 560/601 structurally-unreachable substitution freeze, the convention-nominee ingestion gap.

## STEP 0 — enumerate, then HALT

| # | candidate | expected |
|---|---|---|
| 1 | instrument validation | `settle-predicate-661.ts` run against one known-healed settled contest; its reading matches the DB read taken independently. Quote both |
| 2 | the four rows, full state | per row: status rows, `vote_pct`, winner presence, frozen?, `updated_at` values, and the **re-derived floor date**. Any divergence from the filed dates is a finding, not a correction to absorb |
| 3 | upstream truth | per row: does Ballotpedia carry a winner now, and — where `updated_at` permits — did ours land before the floor? Name the instrument used for the upstream read (the existing scrape path or a raw fetch), and validate it on a control contest too |
| 4 | recovery write scope | what each script writes, whether it accepts contest-scoped targeting, and what an unscoped run would touch. **If either script cannot be scoped to one contest id, that is a HALT-worthy finding on its own** |
| 5 | verdict table | per row: HEALED (nothing owed) / UNHEALED (recovery named, scoped) / UNDECIDABLE (say what's missing). AZ-03's late read included with its timing reconstruction |

**HALT. The verdict table is the authorization point:** recovery runs proceed only for rows the table marks UNHEALED, scoped to those contest ids exactly, nothing wider. A zero-recovery outcome (all healed) skips STEP 1 entirely.

## STEP 1 — recovery (only if owed)

Per UNHEALED row: the scoped recovery run, then the same instrument re-read showing the heal. Quote before/after per row. Any row that does not heal on its designed recovery is a HALT, not a retry loop.

## STEP 2 — proof

1. Post-recovery read of all four via the validated instrument: final states quoted.
2. The predicate's settled behavior confirmed on one healed-past-floor row: it stays settled, nothing re-opens (the HO 661 contract holding at its first live boundary).

## STEP 3 — docs (one commit; likely the only commit)

- **Backlog:** strike the settle-windows entry with all four readings and their dates — including the honest sentence about AZ-03's read being 14 days late and what the reconstruction showed. File any evidence produced for the adjacent families as riders on their existing entries, not new lines.
- **Roadmap** `Also (HO 686)`, pointer → 686: the four verdicts, one line each, and whether the decided-or-expired predicate's first live window crossing behaved as designed.
- **Oddities:** only if a mechanism surprised — a healed-before-floor row that the freeze blocked, a floor date that re-derived differently than filed. Otherwise none.

## STEP 4 — review ref, FF

Standard route even for docs-only: push `refs/heads/686-review`, ls-remote confirm, architect review, FF on approval, delete the ref. If STEP 1 ran, its writes are prod-DB state changes — name them in the roadmap block with row counts.

## Paste-back

STEP 0 verdict table at the HALT (rows 1–3 quoted). If recoveries ran: per-row before/after. The ls-remote line after FF.
