# HO 665 — delete the orphaned `/api/race/[id]/hub` route + the `/dashboard-classic` SKILL prose sweep (the paired entries), carrying the `:1741` CompetitiveRacesBlock rider

**Read this file in full before executing anything. Execute in order. HALT conditions are hard stops — report and wait, do not improvise past them. Two HALTs: the STEP 0 closure table, and the pre-land review ref. Nothing lands on `main` before the second is approved.**

Base: `main` at `3b49bf9` or later. Clone fresh; verify HEAD before starting (concurrent-session rules per `docs/method.md` § Session start). Number derived per method: max(roadmap pointer 664, highest commit-subject HO 664) + 1. Environment: code edit + `npm run typecheck` + `npm run build` (secretless, CI parity — SKILL § Continuous integration), plus one local `npm run start` confirmation (`.env` `TURSO_DATABASE_URL`/`TURSO_AUTH_TOKEN` for the page render). Either machine; no WSL/Docker. **Port discipline per SKILL § Process cleanup, hardened by the HO 664 oddity: the bind check in STEP 3 is a mandated step, not an incidental catch.**

## Context (why now)

These two entries travel together by their own text — the sweep entry (`docs/backlog.md` :415 at `3b49bf9`) says **"Whichever entry is picked up first takes the other with it, so the two ages never diverge."** This HO is both, plus the rider that entry took on at HO 664.

**1. The route (`docs/backlog.md` :414).** `GET /api/race/[id]/hub` — zero callers confirmed at HO 658, a **pre-existing orphan since HO 178** (deliberately not dragged into the HO 658 deletion, which would have widened a scoped commit past its boundary). The file is 34 lines at `app/api/race/[id]/hub/route.ts`; its header (`:1-6`) still describes HO 166's competitive-races drawer and its per-raceId client cache as live. The entry's close: **delete the route and its comment, or find a consumer and record it.** It imports four functions from `lib/queries` (`getMember`, `getRace`, `getRaceCandidates`, `getRunoffsForRace`) — all verified live elsewhere at `3b49bf9` (STEP 0 re-derives). One code comment dangles at the path post-deletion: `components/CompetitiveRacesBlock.tsx:98` ("This no longer mirrors `/api/race/[id]/hub`; the full-hub shape lives on `/race/[id]`").

**2. The sweep (`docs/backlog.md` :415).** SKILL still presents `/dashboard-classic` in present tense outside the HO 658 sweep's scope; the entry's close: **the sweep runs, or the set is measured and accepted on the record.** The known instance is the MarketsTape passage (entry says ~`:1976`; at `3b49bf9` it sits at ~`:1996–1999` — "It renders on two surfaces … Bare `<MarketsTape />` on `/dashboard-classic` (HomeHeader, the preserved legacy dashboard) ONLY"). Expect the LIVE-CLAIM set to be **small**: HO 658 and HO 664 already RECORD-phrased most mentions (`:1278–1280` is a claim + RECORD pair, `:1741`'s two `/dashboard-classic` clauses are RECORD, `:2194` is "RESOLVED AT HO 658"). Sizing the set on the record IS the close criterion — a small result is a finding, not a disappointment.

**3. The rider.** The same `:415` entry carries, since HO 664: SKILL `:1741` still describes `<CompetitiveRacesBlock showBattlefield variant="v2" />`, but the component **has no `variant` prop** (`grep -n variant components/CompetitiveRacesBlock.tsx` returns nothing) — stale since HO 658, deliberately untouched at 664 under its minimal-edits rule. **Rides this sweep**, per the entry.

## STEP 0 — enumerate; closure table; HALT

Line numbers here are as of `3b49bf9` — re-derive every one at your HEAD; a line-number anchor is invalidated by any edit above it (HO 652). **Controls first, before any zero is trusted** (the HO 664 instrument lesson — four instrument failures, zero code failures, caught only by controls). Produce the closure table (candidate · verdict · evidence `file:line` · destination) covering at least:

1. **The route file.** `app/api/race/[id]/hub/route.ts` (34 lines incl. the header comment) — DELETE; the emptied `hub/`, `[id]/`, `race/` dirs go with it (`app/api/races/` — plural — is a different, live tree; do not touch it).
2. **Caller re-verify, control first.** Positive control: `api/bill/` must read >0 with a real fetch site (`components/BillRowList.tsx:67` `fetch(\`/api/bill/…/panel\`)` expected). Then `api/race/[id]/hub` (escape the brackets) across `app/ components/ lib/ e2e/ scripts/`: expected hits are the route file itself + the `CompetitiveRacesBlock.tsx:98` comment + nothing else. Also verify config surfaces: `vercel.json` (no `hub` entry expected; only `sync-race-ratings` + `cron/race-challengers` reference `race`), no `middleware.ts` at root, `next.config.*` clean.
3. **Import-orphan check, per symbol.** For each of `getRace`, `getRaceCandidates`, `getRunoffsForRace`, `getMember`: name the surviving consumers with `file:line`. Expected at `3b49bf9`: `getRace` — `app/race/[id]/page.tsx:29`, `CompetitiveRacesBlock.tsx:103`; `getRaceCandidates` — `app/race/[id]/page.tsx:64`, `CompetitiveRacesBlock.tsx:111`; `getRunoffsForRace` — **narrows to `app/race/[id]/page.tsx:69` alone** (still live; name it in the close note); `getMember` — many. **`lib/queries.ts` is untouched either way** — if a symbol reads zero surviving consumers, that's a table finding destined for a QUEUED filing, not a chase (the HO 507/HO 664 shared-file rule).
4. **`CompetitiveRacesBlock.tsx:98`** — EDIT. The clause "This no longer mirrors `/api/race/[id]/hub`" dangles at a deleted path post-chore; re-phrase so the sentence records the deletion (route deleted HO 665) instead of pointing at it as extant. Comment-only; the surrounding HO 658/HO 432 prose stays.
5. **SKILL inventory — fresh greps, classify every hit.** `grep -n "dashboard-classic" .claude/skills/cbt/SKILL.md` (9 hits at `3b49bf9`: 1278, 1280, 1741, 1974, 1996, 1999, 2002-adjacent block, 2194 — re-derive) and `grep -n "api/race" …` (3 hits: 1592, 1767, 1776). Classify each **LIVE-CLAIM (edit → RECORD)** vs **RECORD/HISTORY (untouched)**:
   - Expected LIVE-CLAIM: the MarketsTape passage — `:1996` "renders on two surfaces" (false since HO 608–610; it renders on one) and `:1999` the `/dashboard-classic` (HomeHeader) bullet → RECORD; `:1592`'s clause "**the endpoint has zero callers**" (present tense about an endpoint this HO deletes) → gains the deletion fact.
   - Classify on site: `:1974`'s "dashboard-classic ACTIVITY ticker, `compact` variant" clause — if it sits inside HO 664's RECORD-phrased compact lists, untouched; if it's a live claim, edit.
   - Expected RECORD/untouched: `:1278–1280` (claim + HO 658 RECORD pair), `:1741`'s two `/dashboard-classic` clauses ("until HO 608-610 deleted that route — RECORD" / "went at HO 608-610"), `:2194`, `:1767`, `:1776` (district-geo, unrelated).
   - **The rider:** `:1741`'s `<CompetitiveRacesBlock showBattlefield variant="v2" />` — drop the prop from the claim or RECORD it, with the grep evidence (`variant` absent from the component) in the table row.
6. **Changelog append target** (~`:2087` region) — the route deletion + the sweep, appended, never rewritten.
7. **Out-of-sweep records, named so they aren't absorbed:** the three code comments naming `/dashboard-classic` are RECORDs and stay (`ActivityTicker.tsx:23`, `CompetitiveRacesStrip.tsx:25`, `NewThisWeek.tsx:20`); `docs/` prose is the ledger's own history and stays.

**HALT.** Paste the table back. If anything reads other than expected — a live hub caller, a query symbol with zero survivors, a LIVE-CLAIM set larger than the sketch — that row's verdict changes and the table says so; do not force it.

## STEP 1 — the chore commit (after the table is approved)

Work on a review branch from the start: `git checkout -b 665-review-local` first (`main` stays at `origin/main` until approval). One commit, one kind:

`chore(HO 665): delete the orphaned /api/race/[id]/hub route`

Expected shape: the route file gone (dirs collapse with it), the `CompetitiveRacesBlock.tsx:98` clause reconciled. ~2 files, roughly −34/+small. Nothing else rides.

## STEP 2 — gates

- `npm run typecheck` and `npm run build` green.
- **Build route manifest:** the build output's route list no longer contains `/api/race/[id]/hub`; positive control: `/api/bill/[id]/panel` (or another API route) present in the same list. Capture both lines.
- Source greps: `api/race/[id]/hub` reads 0 live-code references across `app/ components/ lib/ e2e/ scripts/` — RECORD comments (the reconciled CRB clause; SKILL after STEP 5) reported as "0 live, N RECORD", the HO 664 form, not gutted to satisfy a substring count.

## STEP 3 — runtime confirmation (bind check mandated)

1. `npm run start` on a **private port** (3100+, `-p`), foregrounded or with the PID captured.
2. **Before any curl is trusted:** verify the started PID owns the port — `lsof -i :<port>` (or `ss -ltnp`) maps the socket to *your* PID. A failed bind that a foreign server answers for is the HO 664 false-200; the check is the procedure now.
3. `curl -s -o /dev/null -w "%{http_code}" -H "Cookie: ct_seen=1" http://localhost:<port>/` reads 200; both stylesheets 200.
4. **The 404 probe doubles as a build-freshness check:** `curl … http://localhost:<port>/api/race/<REAL race id>/hub` reads **404**. Use a race id that exists in the DB (e.g. `S-MI-2026`, a featured seat since HO 642) — on a stale server the real id would 200, so the 404 discriminates fresh-build-without-route from stale-build-with-route. A made-up id 404s on both and proves nothing.
5. Kill by PID, port-scoped; foreign PIDs are left alone (HO 664 precedent).

## STEP 4 — docs commit (`docs: HO 665 — …`)

4.1 **`docs/backlog.md`** —
- **Hub-route entry (:414):** strike, with the close note: deleted at <chore SHA>, the HO 166 header comment died with the file, zero callers re-verified at <HEAD> with the positive control named, the four imported queries' surviving consumers named (`getRunoffsForRace` narrowed to `app/race/[id]/page.tsx`), the CRB `:98` comment reconciled rather than orphaned.
- **Sweep entry (:415):** strike, with the close note: the sweep ran at <skill SHA> — residual set sized on the record (N `dashboard-classic` hits + 3 `api/race` hits → M edited to RECORD, the rest already RECORD from HO 658/664, per the entry's own "measured and accepted" criterion), the MarketsTape passage corrected (two surfaces → one), `:1592`'s endpoint clause updated, **and the `:1741` rider resolved** (prop dropped from the claim / RECORD, grep evidence cited). The pairing clause honored — both entries close in one HO, ages never diverged.
- Strike = `~~…~~` + a one-line close note, per ledger convention. **Do not delete the lines.**

4.2 **`docs/roadmap.md`** — one `Also (HO 665)` block, append-only, pointer advanced to 665: the pairing honored per the entries' own text, the chore's numbers (files, the −34, the manifest check), the sweep census (hits / edited / already-RECORD), the rider closed, the freshness-probe design (real-id 404) if it earned its keep, and the oddities disposition. No retro-edits to prior blocks.

4.3 **`docs/oddities.md`** — only if something odd emerged. Nothing odd → no entry, and say so in the roadmap block (the HO 659/660 form).

## STEP 5 — SKILL commit (`docs(skill): HO 665 — …`), self-mod guarded

Its own commit, never riding another doc. Per the approved STEP 0 classification, **minimal edits** — the `/` entry stays flagged stale-as-enumeration (HO 646); touch only the claims this HO falsifies or the entry's close criterion requires:
- The MarketsTape passage: two surfaces → one; the `/dashboard-classic` (HomeHeader) bullet → RECORD.
- `:1592`: the endpoint clause gains the deletion (zero callers → deleted at HO 665).
- `:1741`: the CompetitiveRacesBlock claim loses `variant="v2"` (or gains RECORD phrasing), per the rider.
- `:1974` only if the table classified it LIVE.
- Changelog append: the route deletion + the sweep at HO 665.

## HALT — the review ref; nothing lands before approval

Push the branch: `git push origin HEAD:refs/heads/665-review` (amend via `--force-with-lease` on the ref only; `main` only ever fast-forwards). Paste back: the executed table deltas, `git show --stat` of all three commits, the STEP 2/3 gate outputs **including the bind-check evidence and the real-id 404 probe**, the backlog numstat with every deletion explained, and the docs + SKILL diffs. Remote claims via `git ls-remote`, never `rev-parse origin/*` (SKILL § Review-ref route). One swallowed block → re-deliver as a gitignored file, never a second paste (method.md § Relay). **The SKILL diff needs explicit approval** — the self-mod guard is satisfied by the ref, not bypassed by it. After approval: fast-forward `main` (`git push origin HEAD:main`, no `--force`), delete the ref, verify with `git ls-remote --heads origin`.

## Verification gates (run before the HALT; outputs in the paste)

- STEP 2/3 all green; working tree clean after the three commits.
- **Backlog numstat:** `git diff --numstat <docs-commit>~1 <docs-commit> -- docs/backlog.md` — every deletion explained line-by-line (two in-place strikes expected: 2 deletions + additions; the struck text must survive inside `~~…~~`). `grep -c '^-[^-]'` is NOT a deletion count (HO 643).
- **Anchored greps** (HO 637 rule): `grep -cE '^\*\*Also \(HO 665' docs/roadmap.md` = 1; `grep -rn "api/race/\[id\]/hub" app components lib e2e scripts` = 0 hits in live code (RECORD comments reported as such); `grep -n "hub" docs/backlog.md` shows the :414 line struck, not gone.
- Working tree clean; push only after re-checking HEAD ancestry (`git ls-remote --heads origin`), per method.md § Session start.

## Out of scope — named so it isn't absorbed

- **`lib/queries.ts` entirely** — all four imported functions stay live; no edits, no hints, nothing.
- The `.pdc*` excision entry (its own change, its own byte-identical `/electoral` gate).
- The `BillRowList` compact-passthrough entry (backlog :75, opened at HO 664 — its own HO with gates on the six live routes; the cascade into `BillExpandedPanel` is pinned there).
- The three code RECORD comments naming `/dashboard-classic` (`ActivityTicker.tsx:23`, `CompetitiveRacesStrip.tsx:25`, `NewThisWeek.tsx:20`) and all `docs/` prose — records, not claims.
- The HO 661 settle-window WATCHes (Aug 20 / Sep 3), the ~Sep 1 per-query ledger glance, the M3 re-arm (post-Sep-15) — none due.
- The `CRON_ROUTES` stale schedule string (rides the next `lib/cron-health.ts` touch, per its own entry).
- `app/api/races/` (plural — district-geo) and everything under it.
