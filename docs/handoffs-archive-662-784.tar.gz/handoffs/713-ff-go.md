# HO 713 — FF go (architect, 2026-09-11)

**Owner verdict, verbatim: "send it"** — Corey, CBT maintenance chat, 2026-09-11, on the architect's read of `713-review` at `9077492` off the remote: two commits, `docs(skill)` alone and `docs`; SKILL 2+/2− with both deletions the amended bullets' own lines re-emitted (word-diff shows no removed text); backlog 2+/0−, oddities 19+/0−, roadmap 14+/0−; no code; `bc77e3b` is an ancestor, so the move is a clean fast-forward. The `narrow-preview` reading is not implicated and is not claimed. `check:design-citations` OK is the only gate that applies, and it was run.

**What this FF is.** A docs-only landing that records a handoff dissolving at its own STEP 0: the Absence Watch band was never dark, the probe was reading `/welcome` behind the landing gate, and the chain that produced the false premise is owned at both links in the block. It also files two ledger lines (`votes` has no manual flush path; the guarded-failure and good-news states render identically on `/`, deferred to Corey) and the SKILL rule that any probe of `/` carries the gate cookie.

## 1. The move

- `git ls-remote --heads origin` immediately before: `main` at `bc77e3b`, `713-review` at `9077492`. Anything else, stop and paste.
- On `main`, the cleanup door: `git merge --ff-only 9077492`; `git rev-parse main` must print `9077492`. `git push origin main`, no force. `git push origin --delete 713-review`. Then `git ls-remote --heads origin` and `git ls-remote --tags origin` (three tags).
- Each state-changing command on its own line, stderr never suppressed. The commit list is `git log --oneline bc77e3b..main` off the pushed branch.

## 2. The readings — the docs-only set

- `npm run verify:deploy` until the served SHA is `9077492`, five consecutive reads. Docs-only builds still deploy; the served bytes are expected identical to `bc77e3b`'s and nothing about the render is claimed.
- **One served read, with the gate cookie, as the rule now says:** `curl -H "cookie: ct_seen=1" /` → `abw-` count and the band header (`MIA (1) · AT RISK (11)` or whatever the day reads), so the paste that closes this HO contains the reading the HO was about, taken correctly. And the same request without the cookie → `307 → /welcome`, so the two readings that made the oddity sit beside each other in the record.
- The Production `deployment_status` run: id and conclusion, the group echo, 127 passed or the number, wall time; no per-route claims beyond `pageErr=0` across the log.
- `ci.yml` and `design-citations` conclusions.

## 3. After the FF

Nothing further from this HO. The two new ledger lines stand: the `votes` allowlist gap for Code when called; the two-zeros question on the band for Corey, argued on its merits when he wants it.

## 4. Paste

The `ls-remote` line showing `main` at `9077492`, the ref gone, three tags; `git rev-parse main`; the two-line log; the five served reads; the cookied and cookieless reads of `/`; the Production run's id, conclusion and duration; `ci.yml` and `design-citations` conclusions.

read and follow 713-ff-go — the file, not this line
