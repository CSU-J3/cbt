# HO 756: the committees cron off the shared :00 minute, on a 240s budget, with steps that fail alone

The first two scheduled ticks of HO 753's walk, read on 2026-09-29: the 00:00Z tick walked 31 bills in 54.2s, 0.8s inside the soft timeout, and the 12:00Z tick errored at 8.0s before any step ran ("The operation was aborted due to timeout"). Owed bills went from 5 to 118 in a day, because `/api/sync` stamped about 150 changed bills and the walk managed 31. `/api/health` reads 503 on the route until a tick succeeds. The walk itself is right; its slot and its budget are wrong.

The cause is the minute. `0 */12 * * *` fires at 00:00 and 12:00 alongside `/api/sync`, `/api/cron/primaries`, `/api/cron/markets`, `/api/cron/summarize` and `/api/cron/news` (`vercel.json`), six routes sharing one minute, Congress.gov, Turso and the function pool. At 1.7s a bill in that minute, a 45s budget walks about 30; the repair walked the same endpoint at about 0.3s a bill off-peak. The 8s abort that killed the 12:00Z tick is the committees list fetch's own timeout (`PER_BILL_HTTP_TIMEOUT_MS`, `lib/committees-sync.ts:49`, `:97`), and one abort in step 1 errors the whole tick. This is the line *The committees cron errored on 17 of 60 ticks in 30 days…* (HO 754), now with its mechanism read.

**Three changes, no walk logic touched:** the schedule moves to `5 */6 * * *`, a minute nothing else uses; the route gets `maxDuration = 300`, a 240s bills budget and a 3s cap on a fetch caught at the deadline, the shape HO 754 gave the meetings route; and the three steps (committees list, members, bills) fail alone, so an aborted list refresh is recorded in `chronicErr` and the bills walk still runs.

## Ground truth (read at `4ebb191`; re-derive every `:N` by content)

- `app/api/cron/committees/route.ts`: `maxDuration = 60` (`:33`), `BILLS_BUDGET_MS = 45_000` (`:38`), the deadline passed as `routeStart + BILLS_BUDGET_MS` (`:73`), the default 55s soft timeout, and the three steps run in sequence inside one `try`.
- `lib/committees-sync.ts`: `PER_BILL_HTTP_TIMEOUT_MS = 8_000` (`:49`) governs the committees list (`:97`), each bill's endpoint (`:258`) and the membership YAML (`:419`). The walk (HO 753) stops starting bills at the deadline; a fetch already in flight keeps its full 8s, which is how the 00:00Z step ran 53.1s on a 45s budget.
- `vercel.json`: `/api/cron/committees` at `0 */12 * * *` (`:81`); the five routes that share 00:00 and 12:00 are listed above. No cron uses minute :05.
- `lib/cron-health.ts:73`: `{ path: "/api/cron/committees", schedule: "0 */12 * * *", maxStaleMs: 25 * HOUR }`.
- The readings: `docs/handoffs/753-artifacts/tick1-753.txt`, `tick2-753.txt`, `754-artifacts/owed-rate-754.txt`, `health-ticks-754.txt`. The 00:00Z row's `chronicErr` also names four unknown committee codes from the members step (`SSCM39`, `SSJU27`, `HSZS`, and one more), a case-folding mismatch this HO files and doesn't fix.

## STEP 0

1. HO number from the tree: `main` at `4ebb191`, pointer 755, so 756. Otherwise stop.
2. Re-read every cited `:N` by content. Flag a drift.
3. Measure, prod, SELECTs only:
   - every `/api/cron/committees` row of the last 30 days: started minute, status, elapsed, `error_message`. Expected: the errors all at :00 and all 8.0s aborts, which reads the line's mechanism;
   - per-bill time from each success row's walked count and elapsed, and the same from the repair's log, so the :00 penalty is a number;
   - the inflow: `changed_at` stamps per day over the last 7 days, and the owed count now;
   - the four unknown committee codes and where they come from.
4. Carry the four tick readings of 2026-09-29 and the `/api/health` 503 into this HO's roadmap block.
5. Proceed without a halt.

## The build

1. `vercel.json`: `5 */6 * * *`, and `maxDuration: 300` for the route. `lib/cron-health.ts`: the new schedule, `maxStaleMs: 13 * HOUR`, and the count comment left true.
2. The route: `maxDuration = 300`, `BILLS_BUDGET_MS = 240_000`, `softTimeoutMs: 290_000`; the three steps each in their own `try`, each failure recorded by name in `chronicErr`, the tick's status `success` when the bills walk ran; the payload names which steps ran.
3. The walk: a fetch in flight at the deadline is capped at 3s (the HO 754 pattern), so the step ends within 3s of its budget. Nothing else in the walk changes.
4. File one line for the unknown committee codes (owner Code, low): the members step compares codes case-sensitively against a table that stores them lower-case, and names them unknown.

## Legs, on a `file:` copy with a fetch shim, through the real route wrapper, each red first

1. The deadline cap: a fetch the shim holds past the budget is cut at 3s, and the tick finishes inside the soft timeout as `success`. Red: today's route ends 8s past its budget.
2. Steps fail alone: the shim aborts the committees list fetch; the bills walk still runs, `chronicErr` names step 1, the row reads `success`. Red: today's route errors before the walk.
3. Capacity: with the shim answering in 0.5s, a 240s budget walks at least 400 bills. Red: 45s walks under 90.
4. The registry: `lib/cron-health.ts` carries the new schedule and stale limit, and its count comment matches `vercel.json`.

## Commits and docs

- `fix(HO 756)`: `vercel.json`, the route, the walk's cap, `lib/cron-health.ts`.
- `diag(HO 756)`: the legs driver and shim.
- `docs(skill)`, its own commit, approval requested: the committees entry's schedule, budget, `maxDuration` and step independence; the neighbour-minute text HO 755 wrote for the routes that shared :00 loses committees.
- `docs(HO 756)`: annotate the 17-errored-ticks line with the mechanism and the remedy, and file a WATCH: 28 ticks (7 days) at 0 errors, `remaining` draining to 0 and staying there, read then; file the committee-codes line; the roadmap block, pointer 755 → 756, carrying the four tick readings and the 503. Reconcile OPEN LOOPS at open and close, control at 0.
- Review ref `756-review`. The FF is held for the SKILL approval and review. Nothing served changes, so no captures.

## The prod reading (in the FF go)

After the FF: `/api/health` reading 200 once the first `:05` tick succeeds (one authorized POST right after the deploy clears it sooner and drains the 118); the first two scheduled ticks' payloads with walked, `remaining`, elapsed and per-bill time; the WATCH then runs its week.

## Paste back

- STEP 0's readings, with the error rows tabulated by minute;
- the four legs, red and green;
- the SKILL diff, for approval;
- `git show --stat` per commit, `--numstat` for the docs commits, the reconcile, the `756-review` SHA from `git ls-remote`, and a last cheap-gate run.
